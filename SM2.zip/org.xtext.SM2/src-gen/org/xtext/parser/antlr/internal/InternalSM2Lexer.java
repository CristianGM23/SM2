package org.xtext.parser.antlr.internal;

// Hack: Use our own Lexer superclass by means of import. 
// Currently there is no other way to specify the superclass for the lexer.
import org.eclipse.xtext.parser.antlr.Lexer;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSM2Lexer extends Lexer {
    public static final int T__50=50;
    public static final int RULE_OPENPARENTHESIS=11;
    public static final int RULE_EOLINE=5;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int RULE_CLOSEKEY=8;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_PARAMSLONGCOMENT=17;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=6;
    public static final int RULE_COMMA=15;
    public static final int RULE_RETURNSLONGCOMENT=19;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=16;
    public static final int T__29=29;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=22;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int RULE_SEMICOLON=4;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_TITLELONGCOMENT=20;
    public static final int RULE_STRING=13;
    public static final int RULE_EMAIL=14;
    public static final int RULE_NOTICELONGCOMENT=21;
    public static final int RULE_SL_COMMENT=23;
    public static final int T__37=37;
    public static final int RULE_OPENKEY=7;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int RULE_CLOSEPARENTHESIS=12;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__73=73;
    public static final int RULE_DOT=10;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__74=74;
    public static final int T__31=31;
    public static final int T__75=75;
    public static final int T__32=32;
    public static final int T__76=76;
    public static final int RULE_WS=24;
    public static final int RULE_ANY_OTHER=25;
    public static final int RULE_NUMBER=9;
    public static final int RULE_DEVLONGCOMENT=18;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators

    public InternalSM2Lexer() {;} 
    public InternalSM2Lexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public InternalSM2Lexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "InternalSM2.g"; }

    // $ANTLR start "T__26"
    public final void mT__26() throws RecognitionException {
        try {
            int _type = T__26;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:11:7: ( 'pragma' )
            // InternalSM2.g:11:9: 'pragma'
            {
            match("pragma"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__26"

    // $ANTLR start "T__27"
    public final void mT__27() throws RecognitionException {
        try {
            int _type = T__27;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:12:7: ( 'solidity' )
            // InternalSM2.g:12:9: 'solidity'
            {
            match("solidity"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__27"

    // $ANTLR start "T__28"
    public final void mT__28() throws RecognitionException {
        try {
            int _type = T__28;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:13:7: ( 'contract' )
            // InternalSM2.g:13:9: 'contract'
            {
            match("contract"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__28"

    // $ANTLR start "T__29"
    public final void mT__29() throws RecognitionException {
        try {
            int _type = T__29;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:14:7: ( 'is' )
            // InternalSM2.g:14:9: 'is'
            {
            match("is"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__29"

    // $ANTLR start "T__30"
    public final void mT__30() throws RecognitionException {
        try {
            int _type = T__30;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:15:7: ( '^' )
            // InternalSM2.g:15:9: '^'
            {
            match('^'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__30"

    // $ANTLR start "T__31"
    public final void mT__31() throws RecognitionException {
        try {
            int _type = T__31;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:16:7: ( '>' )
            // InternalSM2.g:16:9: '>'
            {
            match('>'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__31"

    // $ANTLR start "T__32"
    public final void mT__32() throws RecognitionException {
        try {
            int _type = T__32;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:17:7: ( '>=' )
            // InternalSM2.g:17:9: '>='
            {
            match(">="); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__32"

    // $ANTLR start "T__33"
    public final void mT__33() throws RecognitionException {
        try {
            int _type = T__33;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:18:7: ( '<' )
            // InternalSM2.g:18:9: '<'
            {
            match('<'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__33"

    // $ANTLR start "T__34"
    public final void mT__34() throws RecognitionException {
        try {
            int _type = T__34;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:19:7: ( '<=' )
            // InternalSM2.g:19:9: '<='
            {
            match("<="); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__34"

    // $ANTLR start "T__35"
    public final void mT__35() throws RecognitionException {
        try {
            int _type = T__35;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:20:7: ( 'import' )
            // InternalSM2.g:20:9: 'import'
            {
            match("import"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__35"

    // $ANTLR start "T__36"
    public final void mT__36() throws RecognitionException {
        try {
            int _type = T__36;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:21:7: ( 'as' )
            // InternalSM2.g:21:9: 'as'
            {
            match("as"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__36"

    // $ANTLR start "T__37"
    public final void mT__37() throws RecognitionException {
        try {
            int _type = T__37;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:22:7: ( 'event' )
            // InternalSM2.g:22:9: 'event'
            {
            match("event"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__37"

    // $ANTLR start "T__38"
    public final void mT__38() throws RecognitionException {
        try {
            int _type = T__38;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:23:7: ( 'modifier' )
            // InternalSM2.g:23:9: 'modifier'
            {
            match("modifier"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__38"

    // $ANTLR start "T__39"
    public final void mT__39() throws RecognitionException {
        try {
            int _type = T__39;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:24:7: ( '_;' )
            // InternalSM2.g:24:9: '_;'
            {
            match("_;"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__39"

    // $ANTLR start "T__40"
    public final void mT__40() throws RecognitionException {
        try {
            int _type = T__40;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:25:7: ( 'mapping' )
            // InternalSM2.g:25:9: 'mapping'
            {
            match("mapping"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__40"

    // $ANTLR start "T__41"
    public final void mT__41() throws RecognitionException {
        try {
            int _type = T__41;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:26:7: ( '=>' )
            // InternalSM2.g:26:9: '=>'
            {
            match("=>"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__41"

    // $ANTLR start "T__42"
    public final void mT__42() throws RecognitionException {
        try {
            int _type = T__42;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:27:7: ( 'struct' )
            // InternalSM2.g:27:9: 'struct'
            {
            match("struct"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__42"

    // $ANTLR start "T__43"
    public final void mT__43() throws RecognitionException {
        try {
            int _type = T__43;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:28:7: ( 'address' )
            // InternalSM2.g:28:9: 'address'
            {
            match("address"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__43"

    // $ANTLR start "T__44"
    public final void mT__44() throws RecognitionException {
        try {
            int _type = T__44;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:29:7: ( '=' )
            // InternalSM2.g:29:9: '='
            {
            match('='); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__44"

    // $ANTLR start "T__45"
    public final void mT__45() throws RecognitionException {
        try {
            int _type = T__45;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:30:7: ( 'string' )
            // InternalSM2.g:30:9: 'string'
            {
            match("string"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__45"

    // $ANTLR start "T__46"
    public final void mT__46() throws RecognitionException {
        try {
            int _type = T__46;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:31:7: ( 'uint' )
            // InternalSM2.g:31:9: 'uint'
            {
            match("uint"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__46"

    // $ANTLR start "T__47"
    public final void mT__47() throws RecognitionException {
        try {
            int _type = T__47;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:32:7: ( 'enum' )
            // InternalSM2.g:32:9: 'enum'
            {
            match("enum"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__47"

    // $ANTLR start "T__48"
    public final void mT__48() throws RecognitionException {
        try {
            int _type = T__48;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:33:7: ( 'require' )
            // InternalSM2.g:33:9: 'require'
            {
            match("require"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__48"

    // $ANTLR start "T__49"
    public final void mT__49() throws RecognitionException {
        try {
            int _type = T__49;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:34:7: ( 'function' )
            // InternalSM2.g:34:9: 'function'
            {
            match("function"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__49"

    // $ANTLR start "T__50"
    public final void mT__50() throws RecognitionException {
        try {
            int _type = T__50;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:35:7: ( '//' )
            // InternalSM2.g:35:9: '//'
            {
            match("//"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__50"

    // $ANTLR start "T__51"
    public final void mT__51() throws RecognitionException {
        try {
            int _type = T__51;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:36:7: ( '/*' )
            // InternalSM2.g:36:9: '/*'
            {
            match("/*"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__51"

    // $ANTLR start "T__52"
    public final void mT__52() throws RecognitionException {
        try {
            int _type = T__52;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:37:7: ( '*/' )
            // InternalSM2.g:37:9: '*/'
            {
            match("*/"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__52"

    // $ANTLR start "T__53"
    public final void mT__53() throws RecognitionException {
        try {
            int _type = T__53;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:38:7: ( 'int' )
            // InternalSM2.g:38:9: 'int'
            {
            match("int"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__53"

    // $ANTLR start "T__54"
    public final void mT__54() throws RecognitionException {
        try {
            int _type = T__54;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:39:7: ( 'uint8' )
            // InternalSM2.g:39:9: 'uint8'
            {
            match("uint8"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__54"

    // $ANTLR start "T__55"
    public final void mT__55() throws RecognitionException {
        try {
            int _type = T__55;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:40:7: ( 'uint256' )
            // InternalSM2.g:40:9: 'uint256'
            {
            match("uint256"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__55"

    // $ANTLR start "T__56"
    public final void mT__56() throws RecognitionException {
        try {
            int _type = T__56;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:41:7: ( 'address payable' )
            // InternalSM2.g:41:9: 'address payable'
            {
            match("address payable"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__56"

    // $ANTLR start "T__57"
    public final void mT__57() throws RecognitionException {
        try {
            int _type = T__57;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:42:7: ( 'double' )
            // InternalSM2.g:42:9: 'double'
            {
            match("double"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__57"

    // $ANTLR start "T__58"
    public final void mT__58() throws RecognitionException {
        try {
            int _type = T__58;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:43:7: ( 'bool' )
            // InternalSM2.g:43:9: 'bool'
            {
            match("bool"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__58"

    // $ANTLR start "T__59"
    public final void mT__59() throws RecognitionException {
        try {
            int _type = T__59;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:44:7: ( 'public' )
            // InternalSM2.g:44:9: 'public'
            {
            match("public"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__59"

    // $ANTLR start "T__60"
    public final void mT__60() throws RecognitionException {
        try {
            int _type = T__60;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:45:7: ( 'private' )
            // InternalSM2.g:45:9: 'private'
            {
            match("private"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__60"

    // $ANTLR start "T__61"
    public final void mT__61() throws RecognitionException {
        try {
            int _type = T__61;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:46:7: ( 'internal' )
            // InternalSM2.g:46:9: 'internal'
            {
            match("internal"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__61"

    // $ANTLR start "T__62"
    public final void mT__62() throws RecognitionException {
        try {
            int _type = T__62;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:47:7: ( 'external' )
            // InternalSM2.g:47:9: 'external'
            {
            match("external"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__62"

    // $ANTLR start "T__63"
    public final void mT__63() throws RecognitionException {
        try {
            int _type = T__63;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:48:7: ( 'ether' )
            // InternalSM2.g:48:9: 'ether'
            {
            match("ether"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__63"

    // $ANTLR start "T__64"
    public final void mT__64() throws RecognitionException {
        try {
            int _type = T__64;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:49:7: ( 'wei' )
            // InternalSM2.g:49:9: 'wei'
            {
            match("wei"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__64"

    // $ANTLR start "T__65"
    public final void mT__65() throws RecognitionException {
        try {
            int _type = T__65;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:50:7: ( 'gwei' )
            // InternalSM2.g:50:9: 'gwei'
            {
            match("gwei"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__65"

    // $ANTLR start "T__66"
    public final void mT__66() throws RecognitionException {
        try {
            int _type = T__66;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:51:7: ( 'pwei' )
            // InternalSM2.g:51:9: 'pwei'
            {
            match("pwei"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__66"

    // $ANTLR start "T__67"
    public final void mT__67() throws RecognitionException {
        try {
            int _type = T__67;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:52:7: ( 'finney' )
            // InternalSM2.g:52:9: 'finney'
            {
            match("finney"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__67"

    // $ANTLR start "T__68"
    public final void mT__68() throws RecognitionException {
        try {
            int _type = T__68;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:53:7: ( 'szabo' )
            // InternalSM2.g:53:9: 'szabo'
            {
            match("szabo"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__68"

    // $ANTLR start "T__69"
    public final void mT__69() throws RecognitionException {
        try {
            int _type = T__69;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:54:7: ( '==' )
            // InternalSM2.g:54:9: '=='
            {
            match("=="); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__69"

    // $ANTLR start "T__70"
    public final void mT__70() throws RecognitionException {
        try {
            int _type = T__70;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:55:7: ( '!=' )
            // InternalSM2.g:55:9: '!='
            {
            match("!="); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__70"

    // $ANTLR start "T__71"
    public final void mT__71() throws RecognitionException {
        try {
            int _type = T__71;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:56:7: ( '&&' )
            // InternalSM2.g:56:9: '&&'
            {
            match("&&"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__71"

    // $ANTLR start "T__72"
    public final void mT__72() throws RecognitionException {
        try {
            int _type = T__72;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:57:7: ( '||' )
            // InternalSM2.g:57:9: '||'
            {
            match("||"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__72"

    // $ANTLR start "T__73"
    public final void mT__73() throws RecognitionException {
        try {
            int _type = T__73;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:58:7: ( '+' )
            // InternalSM2.g:58:9: '+'
            {
            match('+'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__73"

    // $ANTLR start "T__74"
    public final void mT__74() throws RecognitionException {
        try {
            int _type = T__74;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:59:7: ( '-' )
            // InternalSM2.g:59:9: '-'
            {
            match('-'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__74"

    // $ANTLR start "T__75"
    public final void mT__75() throws RecognitionException {
        try {
            int _type = T__75;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:60:7: ( '*' )
            // InternalSM2.g:60:9: '*'
            {
            match('*'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__75"

    // $ANTLR start "T__76"
    public final void mT__76() throws RecognitionException {
        try {
            int _type = T__76;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:61:7: ( '/' )
            // InternalSM2.g:61:9: '/'
            {
            match('/'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__76"

    // $ANTLR start "RULE_NUMBER"
    public final void mRULE_NUMBER() throws RecognitionException {
        try {
            int _type = RULE_NUMBER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2900:13: ( '0' .. '9' )
            // InternalSM2.g:2900:15: '0' .. '9'
            {
            matchRange('0','9'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_NUMBER"

    // $ANTLR start "RULE_CLOSEKEY"
    public final void mRULE_CLOSEKEY() throws RecognitionException {
        try {
            int _type = RULE_CLOSEKEY;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2902:15: ( '}' )
            // InternalSM2.g:2902:17: '}'
            {
            match('}'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_CLOSEKEY"

    // $ANTLR start "RULE_OPENKEY"
    public final void mRULE_OPENKEY() throws RecognitionException {
        try {
            int _type = RULE_OPENKEY;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2904:14: ( '{' )
            // InternalSM2.g:2904:16: '{'
            {
            match('{'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_OPENKEY"

    // $ANTLR start "RULE_OPENPARENTHESIS"
    public final void mRULE_OPENPARENTHESIS() throws RecognitionException {
        try {
            int _type = RULE_OPENPARENTHESIS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2906:22: ( '(' )
            // InternalSM2.g:2906:24: '('
            {
            match('('); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_OPENPARENTHESIS"

    // $ANTLR start "RULE_CLOSEPARENTHESIS"
    public final void mRULE_CLOSEPARENTHESIS() throws RecognitionException {
        try {
            int _type = RULE_CLOSEPARENTHESIS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2908:23: ( ')' )
            // InternalSM2.g:2908:25: ')'
            {
            match(')'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_CLOSEPARENTHESIS"

    // $ANTLR start "RULE_EOLINE"
    public final void mRULE_EOLINE() throws RecognitionException {
        try {
            int _type = RULE_EOLINE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2910:13: ( '/n' )
            // InternalSM2.g:2910:15: '/n'
            {
            match("/n"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_EOLINE"

    // $ANTLR start "RULE_SEMICOLON"
    public final void mRULE_SEMICOLON() throws RecognitionException {
        try {
            int _type = RULE_SEMICOLON;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2912:16: ( ';' )
            // InternalSM2.g:2912:18: ';'
            {
            match(';'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_SEMICOLON"

    // $ANTLR start "RULE_DOT"
    public final void mRULE_DOT() throws RecognitionException {
        try {
            int _type = RULE_DOT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2914:10: ( '.' )
            // InternalSM2.g:2914:12: '.'
            {
            match('.'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_DOT"

    // $ANTLR start "RULE_COMMA"
    public final void mRULE_COMMA() throws RecognitionException {
        try {
            int _type = RULE_COMMA;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2916:12: ( ',' )
            // InternalSM2.g:2916:14: ','
            {
            match(','); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_COMMA"

    // $ANTLR start "RULE_PARAMSLONGCOMENT"
    public final void mRULE_PARAMSLONGCOMENT() throws RecognitionException {
        try {
            int _type = RULE_PARAMSLONGCOMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2918:23: ( '@param' ( 'a' .. 'z' )+ RULE_EOLINE )
            // InternalSM2.g:2918:25: '@param' ( 'a' .. 'z' )+ RULE_EOLINE
            {
            match("@param"); 

            // InternalSM2.g:2918:34: ( 'a' .. 'z' )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>='a' && LA1_0<='z')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalSM2.g:2918:35: 'a' .. 'z'
            	    {
            	    matchRange('a','z'); 

            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);

            mRULE_EOLINE(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_PARAMSLONGCOMENT"

    // $ANTLR start "RULE_DEVLONGCOMENT"
    public final void mRULE_DEVLONGCOMENT() throws RecognitionException {
        try {
            int _type = RULE_DEVLONGCOMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2920:20: ( '@dev' ( 'a' .. 'z' )+ RULE_EOLINE )
            // InternalSM2.g:2920:22: '@dev' ( 'a' .. 'z' )+ RULE_EOLINE
            {
            match("@dev"); 

            // InternalSM2.g:2920:29: ( 'a' .. 'z' )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>='a' && LA2_0<='z')) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSM2.g:2920:30: 'a' .. 'z'
            	    {
            	    matchRange('a','z'); 

            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);

            mRULE_EOLINE(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_DEVLONGCOMENT"

    // $ANTLR start "RULE_NOTICELONGCOMENT"
    public final void mRULE_NOTICELONGCOMENT() throws RecognitionException {
        try {
            int _type = RULE_NOTICELONGCOMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2922:23: ( '@notice' ( 'a' .. 'z' )+ RULE_EOLINE )
            // InternalSM2.g:2922:25: '@notice' ( 'a' .. 'z' )+ RULE_EOLINE
            {
            match("@notice"); 

            // InternalSM2.g:2922:35: ( 'a' .. 'z' )+
            int cnt3=0;
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( ((LA3_0>='a' && LA3_0<='z')) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalSM2.g:2922:36: 'a' .. 'z'
            	    {
            	    matchRange('a','z'); 

            	    }
            	    break;

            	default :
            	    if ( cnt3 >= 1 ) break loop3;
                        EarlyExitException eee =
                            new EarlyExitException(3, input);
                        throw eee;
                }
                cnt3++;
            } while (true);

            mRULE_EOLINE(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_NOTICELONGCOMENT"

    // $ANTLR start "RULE_RETURNSLONGCOMENT"
    public final void mRULE_RETURNSLONGCOMENT() throws RecognitionException {
        try {
            int _type = RULE_RETURNSLONGCOMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2924:24: ( '@returns' ( 'a' .. 'z' )+ RULE_EOLINE )
            // InternalSM2.g:2924:26: '@returns' ( 'a' .. 'z' )+ RULE_EOLINE
            {
            match("@returns"); 

            // InternalSM2.g:2924:37: ( 'a' .. 'z' )+
            int cnt4=0;
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( ((LA4_0>='a' && LA4_0<='z')) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalSM2.g:2924:38: 'a' .. 'z'
            	    {
            	    matchRange('a','z'); 

            	    }
            	    break;

            	default :
            	    if ( cnt4 >= 1 ) break loop4;
                        EarlyExitException eee =
                            new EarlyExitException(4, input);
                        throw eee;
                }
                cnt4++;
            } while (true);

            mRULE_EOLINE(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_RETURNSLONGCOMENT"

    // $ANTLR start "RULE_TITLELONGCOMENT"
    public final void mRULE_TITLELONGCOMENT() throws RecognitionException {
        try {
            int _type = RULE_TITLELONGCOMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2926:22: ( '@title' ( 'a' .. 'z' )+ RULE_EOLINE )
            // InternalSM2.g:2926:24: '@title' ( 'a' .. 'z' )+ RULE_EOLINE
            {
            match("@title"); 

            // InternalSM2.g:2926:33: ( 'a' .. 'z' )+
            int cnt5=0;
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( ((LA5_0>='a' && LA5_0<='z')) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalSM2.g:2926:34: 'a' .. 'z'
            	    {
            	    matchRange('a','z'); 

            	    }
            	    break;

            	default :
            	    if ( cnt5 >= 1 ) break loop5;
                        EarlyExitException eee =
                            new EarlyExitException(5, input);
                        throw eee;
                }
                cnt5++;
            } while (true);

            mRULE_EOLINE(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_TITLELONGCOMENT"

    // $ANTLR start "RULE_EMAIL"
    public final void mRULE_EMAIL() throws RecognitionException {
        try {
            int _type = RULE_EMAIL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2928:12: ( ( 'a' .. 'z' )+ ( '0' .. '9' )+ '@' ( 'a' .. 'z' )+ '.' 'a' .. 'z' 'a' .. 'z' ( 'a' .. 'z' )? )
            // InternalSM2.g:2928:14: ( 'a' .. 'z' )+ ( '0' .. '9' )+ '@' ( 'a' .. 'z' )+ '.' 'a' .. 'z' 'a' .. 'z' ( 'a' .. 'z' )?
            {
            // InternalSM2.g:2928:14: ( 'a' .. 'z' )+
            int cnt6=0;
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( ((LA6_0>='a' && LA6_0<='z')) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalSM2.g:2928:15: 'a' .. 'z'
            	    {
            	    matchRange('a','z'); 

            	    }
            	    break;

            	default :
            	    if ( cnt6 >= 1 ) break loop6;
                        EarlyExitException eee =
                            new EarlyExitException(6, input);
                        throw eee;
                }
                cnt6++;
            } while (true);

            // InternalSM2.g:2928:26: ( '0' .. '9' )+
            int cnt7=0;
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( ((LA7_0>='0' && LA7_0<='9')) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalSM2.g:2928:27: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt7 >= 1 ) break loop7;
                        EarlyExitException eee =
                            new EarlyExitException(7, input);
                        throw eee;
                }
                cnt7++;
            } while (true);

            match('@'); 
            // InternalSM2.g:2928:42: ( 'a' .. 'z' )+
            int cnt8=0;
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( ((LA8_0>='a' && LA8_0<='z')) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalSM2.g:2928:43: 'a' .. 'z'
            	    {
            	    matchRange('a','z'); 

            	    }
            	    break;

            	default :
            	    if ( cnt8 >= 1 ) break loop8;
                        EarlyExitException eee =
                            new EarlyExitException(8, input);
                        throw eee;
                }
                cnt8++;
            } while (true);

            match('.'); 
            matchRange('a','z'); 
            matchRange('a','z'); 
            // InternalSM2.g:2928:76: ( 'a' .. 'z' )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( ((LA9_0>='a' && LA9_0<='z')) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalSM2.g:2928:77: 'a' .. 'z'
                    {
                    matchRange('a','z'); 

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_EMAIL"

    // $ANTLR start "RULE_ID"
    public final void mRULE_ID() throws RecognitionException {
        try {
            int _type = RULE_ID;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2930:9: ( ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )* )
            // InternalSM2.g:2930:11: ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
            {
            // InternalSM2.g:2930:11: ( '^' )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0=='^') ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalSM2.g:2930:11: '^'
                    {
                    match('^'); 

                    }
                    break;

            }

            if ( (input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            // InternalSM2.g:2930:40: ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( ((LA11_0>='0' && LA11_0<='9')||(LA11_0>='A' && LA11_0<='Z')||LA11_0=='_'||(LA11_0>='a' && LA11_0<='z')) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalSM2.g:
            	    {
            	    if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_ID"

    // $ANTLR start "RULE_INT"
    public final void mRULE_INT() throws RecognitionException {
        try {
            int _type = RULE_INT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2932:10: ( ( '0' .. '9' )+ )
            // InternalSM2.g:2932:12: ( '0' .. '9' )+
            {
            // InternalSM2.g:2932:12: ( '0' .. '9' )+
            int cnt12=0;
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( ((LA12_0>='0' && LA12_0<='9')) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalSM2.g:2932:13: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt12 >= 1 ) break loop12;
                        EarlyExitException eee =
                            new EarlyExitException(12, input);
                        throw eee;
                }
                cnt12++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_INT"

    // $ANTLR start "RULE_STRING"
    public final void mRULE_STRING() throws RecognitionException {
        try {
            int _type = RULE_STRING;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2934:13: ( ( '\"' ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )* '\"' | '\\'' ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )* '\\'' ) )
            // InternalSM2.g:2934:15: ( '\"' ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )* '\"' | '\\'' ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )* '\\'' )
            {
            // InternalSM2.g:2934:15: ( '\"' ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )* '\"' | '\\'' ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )* '\\'' )
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0=='\"') ) {
                alt15=1;
            }
            else if ( (LA15_0=='\'') ) {
                alt15=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }
            switch (alt15) {
                case 1 :
                    // InternalSM2.g:2934:16: '\"' ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )* '\"'
                    {
                    match('\"'); 
                    // InternalSM2.g:2934:20: ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )*
                    loop13:
                    do {
                        int alt13=3;
                        int LA13_0 = input.LA(1);

                        if ( (LA13_0=='\\') ) {
                            alt13=1;
                        }
                        else if ( ((LA13_0>='\u0000' && LA13_0<='!')||(LA13_0>='#' && LA13_0<='[')||(LA13_0>=']' && LA13_0<='\uFFFF')) ) {
                            alt13=2;
                        }


                        switch (alt13) {
                    	case 1 :
                    	    // InternalSM2.g:2934:21: '\\\\' .
                    	    {
                    	    match('\\'); 
                    	    matchAny(); 

                    	    }
                    	    break;
                    	case 2 :
                    	    // InternalSM2.g:2934:28: ~ ( ( '\\\\' | '\"' ) )
                    	    {
                    	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFF') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse = new MismatchedSetException(null,input);
                    	        recover(mse);
                    	        throw mse;}


                    	    }
                    	    break;

                    	default :
                    	    break loop13;
                        }
                    } while (true);

                    match('\"'); 

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2934:48: '\\'' ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )* '\\''
                    {
                    match('\''); 
                    // InternalSM2.g:2934:53: ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )*
                    loop14:
                    do {
                        int alt14=3;
                        int LA14_0 = input.LA(1);

                        if ( (LA14_0=='\\') ) {
                            alt14=1;
                        }
                        else if ( ((LA14_0>='\u0000' && LA14_0<='&')||(LA14_0>='(' && LA14_0<='[')||(LA14_0>=']' && LA14_0<='\uFFFF')) ) {
                            alt14=2;
                        }


                        switch (alt14) {
                    	case 1 :
                    	    // InternalSM2.g:2934:54: '\\\\' .
                    	    {
                    	    match('\\'); 
                    	    matchAny(); 

                    	    }
                    	    break;
                    	case 2 :
                    	    // InternalSM2.g:2934:61: ~ ( ( '\\\\' | '\\'' ) )
                    	    {
                    	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='&')||(input.LA(1)>='(' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFF') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse = new MismatchedSetException(null,input);
                    	        recover(mse);
                    	        throw mse;}


                    	    }
                    	    break;

                    	default :
                    	    break loop14;
                        }
                    } while (true);

                    match('\''); 

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_STRING"

    // $ANTLR start "RULE_ML_COMMENT"
    public final void mRULE_ML_COMMENT() throws RecognitionException {
        try {
            int _type = RULE_ML_COMMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2936:17: ( '/*' ( options {greedy=false; } : . )* '*/' )
            // InternalSM2.g:2936:19: '/*' ( options {greedy=false; } : . )* '*/'
            {
            match("/*"); 

            // InternalSM2.g:2936:24: ( options {greedy=false; } : . )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( (LA16_0=='*') ) {
                    int LA16_1 = input.LA(2);

                    if ( (LA16_1=='/') ) {
                        alt16=2;
                    }
                    else if ( ((LA16_1>='\u0000' && LA16_1<='.')||(LA16_1>='0' && LA16_1<='\uFFFF')) ) {
                        alt16=1;
                    }


                }
                else if ( ((LA16_0>='\u0000' && LA16_0<=')')||(LA16_0>='+' && LA16_0<='\uFFFF')) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // InternalSM2.g:2936:52: .
            	    {
            	    matchAny(); 

            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);

            match("*/"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_ML_COMMENT"

    // $ANTLR start "RULE_SL_COMMENT"
    public final void mRULE_SL_COMMENT() throws RecognitionException {
        try {
            int _type = RULE_SL_COMMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2938:17: ( '//' (~ ( ( '\\n' | '\\r' ) ) )* ( ( '\\r' )? '\\n' )? )
            // InternalSM2.g:2938:19: '//' (~ ( ( '\\n' | '\\r' ) ) )* ( ( '\\r' )? '\\n' )?
            {
            match("//"); 

            // InternalSM2.g:2938:24: (~ ( ( '\\n' | '\\r' ) ) )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( ((LA17_0>='\u0000' && LA17_0<='\t')||(LA17_0>='\u000B' && LA17_0<='\f')||(LA17_0>='\u000E' && LA17_0<='\uFFFF')) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalSM2.g:2938:24: ~ ( ( '\\n' | '\\r' ) )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

            // InternalSM2.g:2938:40: ( ( '\\r' )? '\\n' )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0=='\n'||LA19_0=='\r') ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalSM2.g:2938:41: ( '\\r' )? '\\n'
                    {
                    // InternalSM2.g:2938:41: ( '\\r' )?
                    int alt18=2;
                    int LA18_0 = input.LA(1);

                    if ( (LA18_0=='\r') ) {
                        alt18=1;
                    }
                    switch (alt18) {
                        case 1 :
                            // InternalSM2.g:2938:41: '\\r'
                            {
                            match('\r'); 

                            }
                            break;

                    }

                    match('\n'); 

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_SL_COMMENT"

    // $ANTLR start "RULE_WS"
    public final void mRULE_WS() throws RecognitionException {
        try {
            int _type = RULE_WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2940:9: ( ( ' ' | '\\t' | '\\r' | '\\n' )+ )
            // InternalSM2.g:2940:11: ( ' ' | '\\t' | '\\r' | '\\n' )+
            {
            // InternalSM2.g:2940:11: ( ' ' | '\\t' | '\\r' | '\\n' )+
            int cnt20=0;
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( ((LA20_0>='\t' && LA20_0<='\n')||LA20_0=='\r'||LA20_0==' ') ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalSM2.g:
            	    {
            	    if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||input.LA(1)=='\r'||input.LA(1)==' ' ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    if ( cnt20 >= 1 ) break loop20;
                        EarlyExitException eee =
                            new EarlyExitException(20, input);
                        throw eee;
                }
                cnt20++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_WS"

    // $ANTLR start "RULE_ANY_OTHER"
    public final void mRULE_ANY_OTHER() throws RecognitionException {
        try {
            int _type = RULE_ANY_OTHER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:2942:16: ( . )
            // InternalSM2.g:2942:18: .
            {
            matchAny(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_ANY_OTHER"

    public void mTokens() throws RecognitionException {
        // InternalSM2.g:1:8: ( T__26 | T__27 | T__28 | T__29 | T__30 | T__31 | T__32 | T__33 | T__34 | T__35 | T__36 | T__37 | T__38 | T__39 | T__40 | T__41 | T__42 | T__43 | T__44 | T__45 | T__46 | T__47 | T__48 | T__49 | T__50 | T__51 | T__52 | T__53 | T__54 | T__55 | T__56 | T__57 | T__58 | T__59 | T__60 | T__61 | T__62 | T__63 | T__64 | T__65 | T__66 | T__67 | T__68 | T__69 | T__70 | T__71 | T__72 | T__73 | T__74 | T__75 | T__76 | RULE_NUMBER | RULE_CLOSEKEY | RULE_OPENKEY | RULE_OPENPARENTHESIS | RULE_CLOSEPARENTHESIS | RULE_EOLINE | RULE_SEMICOLON | RULE_DOT | RULE_COMMA | RULE_PARAMSLONGCOMENT | RULE_DEVLONGCOMENT | RULE_NOTICELONGCOMENT | RULE_RETURNSLONGCOMENT | RULE_TITLELONGCOMENT | RULE_EMAIL | RULE_ID | RULE_INT | RULE_STRING | RULE_ML_COMMENT | RULE_SL_COMMENT | RULE_WS | RULE_ANY_OTHER )
        int alt21=73;
        alt21 = dfa21.predict(input);
        switch (alt21) {
            case 1 :
                // InternalSM2.g:1:10: T__26
                {
                mT__26(); 

                }
                break;
            case 2 :
                // InternalSM2.g:1:16: T__27
                {
                mT__27(); 

                }
                break;
            case 3 :
                // InternalSM2.g:1:22: T__28
                {
                mT__28(); 

                }
                break;
            case 4 :
                // InternalSM2.g:1:28: T__29
                {
                mT__29(); 

                }
                break;
            case 5 :
                // InternalSM2.g:1:34: T__30
                {
                mT__30(); 

                }
                break;
            case 6 :
                // InternalSM2.g:1:40: T__31
                {
                mT__31(); 

                }
                break;
            case 7 :
                // InternalSM2.g:1:46: T__32
                {
                mT__32(); 

                }
                break;
            case 8 :
                // InternalSM2.g:1:52: T__33
                {
                mT__33(); 

                }
                break;
            case 9 :
                // InternalSM2.g:1:58: T__34
                {
                mT__34(); 

                }
                break;
            case 10 :
                // InternalSM2.g:1:64: T__35
                {
                mT__35(); 

                }
                break;
            case 11 :
                // InternalSM2.g:1:70: T__36
                {
                mT__36(); 

                }
                break;
            case 12 :
                // InternalSM2.g:1:76: T__37
                {
                mT__37(); 

                }
                break;
            case 13 :
                // InternalSM2.g:1:82: T__38
                {
                mT__38(); 

                }
                break;
            case 14 :
                // InternalSM2.g:1:88: T__39
                {
                mT__39(); 

                }
                break;
            case 15 :
                // InternalSM2.g:1:94: T__40
                {
                mT__40(); 

                }
                break;
            case 16 :
                // InternalSM2.g:1:100: T__41
                {
                mT__41(); 

                }
                break;
            case 17 :
                // InternalSM2.g:1:106: T__42
                {
                mT__42(); 

                }
                break;
            case 18 :
                // InternalSM2.g:1:112: T__43
                {
                mT__43(); 

                }
                break;
            case 19 :
                // InternalSM2.g:1:118: T__44
                {
                mT__44(); 

                }
                break;
            case 20 :
                // InternalSM2.g:1:124: T__45
                {
                mT__45(); 

                }
                break;
            case 21 :
                // InternalSM2.g:1:130: T__46
                {
                mT__46(); 

                }
                break;
            case 22 :
                // InternalSM2.g:1:136: T__47
                {
                mT__47(); 

                }
                break;
            case 23 :
                // InternalSM2.g:1:142: T__48
                {
                mT__48(); 

                }
                break;
            case 24 :
                // InternalSM2.g:1:148: T__49
                {
                mT__49(); 

                }
                break;
            case 25 :
                // InternalSM2.g:1:154: T__50
                {
                mT__50(); 

                }
                break;
            case 26 :
                // InternalSM2.g:1:160: T__51
                {
                mT__51(); 

                }
                break;
            case 27 :
                // InternalSM2.g:1:166: T__52
                {
                mT__52(); 

                }
                break;
            case 28 :
                // InternalSM2.g:1:172: T__53
                {
                mT__53(); 

                }
                break;
            case 29 :
                // InternalSM2.g:1:178: T__54
                {
                mT__54(); 

                }
                break;
            case 30 :
                // InternalSM2.g:1:184: T__55
                {
                mT__55(); 

                }
                break;
            case 31 :
                // InternalSM2.g:1:190: T__56
                {
                mT__56(); 

                }
                break;
            case 32 :
                // InternalSM2.g:1:196: T__57
                {
                mT__57(); 

                }
                break;
            case 33 :
                // InternalSM2.g:1:202: T__58
                {
                mT__58(); 

                }
                break;
            case 34 :
                // InternalSM2.g:1:208: T__59
                {
                mT__59(); 

                }
                break;
            case 35 :
                // InternalSM2.g:1:214: T__60
                {
                mT__60(); 

                }
                break;
            case 36 :
                // InternalSM2.g:1:220: T__61
                {
                mT__61(); 

                }
                break;
            case 37 :
                // InternalSM2.g:1:226: T__62
                {
                mT__62(); 

                }
                break;
            case 38 :
                // InternalSM2.g:1:232: T__63
                {
                mT__63(); 

                }
                break;
            case 39 :
                // InternalSM2.g:1:238: T__64
                {
                mT__64(); 

                }
                break;
            case 40 :
                // InternalSM2.g:1:244: T__65
                {
                mT__65(); 

                }
                break;
            case 41 :
                // InternalSM2.g:1:250: T__66
                {
                mT__66(); 

                }
                break;
            case 42 :
                // InternalSM2.g:1:256: T__67
                {
                mT__67(); 

                }
                break;
            case 43 :
                // InternalSM2.g:1:262: T__68
                {
                mT__68(); 

                }
                break;
            case 44 :
                // InternalSM2.g:1:268: T__69
                {
                mT__69(); 

                }
                break;
            case 45 :
                // InternalSM2.g:1:274: T__70
                {
                mT__70(); 

                }
                break;
            case 46 :
                // InternalSM2.g:1:280: T__71
                {
                mT__71(); 

                }
                break;
            case 47 :
                // InternalSM2.g:1:286: T__72
                {
                mT__72(); 

                }
                break;
            case 48 :
                // InternalSM2.g:1:292: T__73
                {
                mT__73(); 

                }
                break;
            case 49 :
                // InternalSM2.g:1:298: T__74
                {
                mT__74(); 

                }
                break;
            case 50 :
                // InternalSM2.g:1:304: T__75
                {
                mT__75(); 

                }
                break;
            case 51 :
                // InternalSM2.g:1:310: T__76
                {
                mT__76(); 

                }
                break;
            case 52 :
                // InternalSM2.g:1:316: RULE_NUMBER
                {
                mRULE_NUMBER(); 

                }
                break;
            case 53 :
                // InternalSM2.g:1:328: RULE_CLOSEKEY
                {
                mRULE_CLOSEKEY(); 

                }
                break;
            case 54 :
                // InternalSM2.g:1:342: RULE_OPENKEY
                {
                mRULE_OPENKEY(); 

                }
                break;
            case 55 :
                // InternalSM2.g:1:355: RULE_OPENPARENTHESIS
                {
                mRULE_OPENPARENTHESIS(); 

                }
                break;
            case 56 :
                // InternalSM2.g:1:376: RULE_CLOSEPARENTHESIS
                {
                mRULE_CLOSEPARENTHESIS(); 

                }
                break;
            case 57 :
                // InternalSM2.g:1:398: RULE_EOLINE
                {
                mRULE_EOLINE(); 

                }
                break;
            case 58 :
                // InternalSM2.g:1:410: RULE_SEMICOLON
                {
                mRULE_SEMICOLON(); 

                }
                break;
            case 59 :
                // InternalSM2.g:1:425: RULE_DOT
                {
                mRULE_DOT(); 

                }
                break;
            case 60 :
                // InternalSM2.g:1:434: RULE_COMMA
                {
                mRULE_COMMA(); 

                }
                break;
            case 61 :
                // InternalSM2.g:1:445: RULE_PARAMSLONGCOMENT
                {
                mRULE_PARAMSLONGCOMENT(); 

                }
                break;
            case 62 :
                // InternalSM2.g:1:467: RULE_DEVLONGCOMENT
                {
                mRULE_DEVLONGCOMENT(); 

                }
                break;
            case 63 :
                // InternalSM2.g:1:486: RULE_NOTICELONGCOMENT
                {
                mRULE_NOTICELONGCOMENT(); 

                }
                break;
            case 64 :
                // InternalSM2.g:1:508: RULE_RETURNSLONGCOMENT
                {
                mRULE_RETURNSLONGCOMENT(); 

                }
                break;
            case 65 :
                // InternalSM2.g:1:531: RULE_TITLELONGCOMENT
                {
                mRULE_TITLELONGCOMENT(); 

                }
                break;
            case 66 :
                // InternalSM2.g:1:552: RULE_EMAIL
                {
                mRULE_EMAIL(); 

                }
                break;
            case 67 :
                // InternalSM2.g:1:563: RULE_ID
                {
                mRULE_ID(); 

                }
                break;
            case 68 :
                // InternalSM2.g:1:571: RULE_INT
                {
                mRULE_INT(); 

                }
                break;
            case 69 :
                // InternalSM2.g:1:580: RULE_STRING
                {
                mRULE_STRING(); 

                }
                break;
            case 70 :
                // InternalSM2.g:1:592: RULE_ML_COMMENT
                {
                mRULE_ML_COMMENT(); 

                }
                break;
            case 71 :
                // InternalSM2.g:1:608: RULE_SL_COMMENT
                {
                mRULE_SL_COMMENT(); 

                }
                break;
            case 72 :
                // InternalSM2.g:1:624: RULE_WS
                {
                mRULE_WS(); 

                }
                break;
            case 73 :
                // InternalSM2.g:1:632: RULE_ANY_OTHER
                {
                mRULE_ANY_OTHER(); 

                }
                break;

        }

    }


    protected DFA21 dfa21 = new DFA21(this);
    static final String DFA21_eotS =
        "\1\uffff\4\56\1\67\1\71\1\73\4\56\1\107\3\56\1\117\1\121\4\56\3\51\2\uffff\1\133\7\uffff\1\51\1\56\1\uffff\2\51\2\uffff\4\56\1\uffff\5\56\1\164\2\56\5\uffff\1\167\7\56\4\uffff\4\56\1\u0083\1\u0086\4\uffff\4\56\25\uffff\4\56\1\uffff\4\56\1\uffff\1\56\1\u0096\1\uffff\13\56\4\uffff\2\56\1\u00a4\4\56\1\u00a9\7\56\1\uffff\2\56\1\u00b3\4\56\1\u00ba\4\56\1\u00bf\1\uffff\1\u00c0\3\56\1\uffff\3\56\1\u00c7\4\56\1\u00cc\1\uffff\1\56\1\u00ce\2\56\1\u00d1\1\56\1\uffff\4\56\2\uffff\1\u00d7\1\56\1\u00d9\1\56\1\u00db\1\u00dc\1\uffff\1\56\1\u00de\2\56\1\uffff\1\56\1\uffff\2\56\1\uffff\3\56\1\u00e7\1\u00e8\1\uffff\1\u00e9\1\uffff\1\56\2\uffff\1\56\1\uffff\1\56\1\u00ee\2\56\1\u00f1\1\u00f2\1\u00f3\1\56\3\uffff\1\u00f5\1\u00f6\1\u00f7\2\uffff\1\u00f8\1\u00f9\3\uffff\1\u00fa\6\uffff";
    static final String DFA21_eofS =
        "\u00fb\uffff";
    static final String DFA21_minS =
        "\1\0\4\60\1\101\2\75\3\60\1\73\1\75\3\60\1\52\1\57\4\60\1\75\1\46\1\174\2\uffff\1\60\7\uffff\1\144\1\60\1\uffff\2\0\2\uffff\4\60\1\uffff\10\60\5\uffff\10\60\4\uffff\4\60\2\0\4\uffff\4\60\25\uffff\4\60\1\uffff\4\60\1\uffff\2\60\1\uffff\13\60\4\uffff\17\60\1\uffff\15\60\1\uffff\4\60\1\uffff\11\60\1\uffff\6\60\1\uffff\4\60\2\uffff\6\60\1\uffff\4\60\1\uffff\1\60\1\uffff\2\60\1\uffff\5\60\1\uffff\1\60\1\uffff\1\60\2\uffff\1\60\1\uffff\1\60\1\40\6\60\3\uffff\3\60\2\uffff\2\60\3\uffff\1\60\6\uffff";
    static final String DFA21_maxS =
        "\1\uffff\5\172\2\75\3\172\1\73\1\76\3\172\1\156\1\57\4\172\1\75\1\46\1\174\2\uffff\1\71\7\uffff\1\164\1\172\1\uffff\2\uffff\2\uffff\3\172\1\100\1\uffff\10\172\5\uffff\10\172\4\uffff\4\172\2\uffff\4\uffff\4\172\25\uffff\4\172\1\uffff\4\172\1\uffff\2\172\1\uffff\13\172\4\uffff\17\172\1\uffff\15\172\1\uffff\4\172\1\uffff\11\172\1\uffff\5\172\1\100\1\uffff\4\172\2\uffff\6\172\1\uffff\4\172\1\uffff\1\172\1\uffff\2\172\1\uffff\1\100\4\172\1\uffff\1\172\1\uffff\1\172\2\uffff\1\172\1\uffff\10\172\3\uffff\3\172\2\uffff\2\172\3\uffff\1\172\6\uffff";
    static final String DFA21_acceptS =
        "\31\uffff\1\60\1\61\1\uffff\1\65\1\66\1\67\1\70\1\72\1\73\1\74\2\uffff\1\103\2\uffff\1\110\1\111\4\uffff\1\103\10\uffff\1\5\1\7\1\6\1\11\1\10\10\uffff\1\16\1\20\1\54\1\23\6\uffff\1\71\1\63\1\33\1\62\4\uffff\1\55\1\56\1\57\1\60\1\61\1\64\1\104\1\65\1\66\1\67\1\70\1\72\1\73\1\74\1\75\1\76\1\77\1\100\1\101\1\105\1\110\4\uffff\1\102\4\uffff\1\4\2\uffff\1\13\13\uffff\1\31\1\107\1\106\1\32\17\uffff\1\34\15\uffff\1\47\4\uffff\1\51\11\uffff\1\26\6\uffff\1\25\4\uffff\1\41\1\50\6\uffff\1\53\4\uffff\1\14\1\uffff\1\46\2\uffff\1\35\5\uffff\1\1\1\uffff\1\42\1\uffff\1\21\1\24\1\uffff\1\12\10\uffff\1\52\1\40\1\43\3\uffff\1\37\1\22\2\uffff\1\17\1\36\1\27\1\uffff\1\2\1\3\1\44\1\45\1\15\1\30";
    static final String DFA21_specialS =
        "\1\1\45\uffff\1\0\1\4\44\uffff\1\3\1\2\u00ad\uffff}>";
    static final String[] DFA21_transitionS = {
            "\11\51\2\50\2\51\1\50\22\51\1\50\1\26\1\46\3\51\1\27\1\47\1\36\1\37\1\21\1\31\1\42\1\32\1\41\1\20\12\33\1\51\1\40\1\7\1\14\1\6\1\51\1\43\32\45\3\51\1\5\1\13\1\51\1\10\1\23\1\3\1\22\1\11\1\17\1\25\1\44\1\4\3\44\1\12\2\44\1\1\1\44\1\16\1\2\1\44\1\15\1\44\1\24\3\44\1\35\1\30\1\34\uff82\51",
            "\12\55\47\uffff\21\57\1\52\2\57\1\53\1\57\1\54\3\57",
            "\12\55\47\uffff\16\57\1\60\4\57\1\61\5\57\1\62",
            "\12\55\47\uffff\16\57\1\63\13\57",
            "\12\55\47\uffff\14\57\1\65\1\66\4\57\1\64\7\57",
            "\32\56\4\uffff\1\56\1\uffff\32\56",
            "\1\70",
            "\1\72",
            "\12\55\47\uffff\3\57\1\75\16\57\1\74\7\57",
            "\12\55\47\uffff\15\57\1\77\5\57\1\101\1\57\1\76\1\57\1\100\2\57",
            "\12\55\47\uffff\1\103\15\57\1\102\13\57",
            "\1\104",
            "\1\106\1\105",
            "\12\55\47\uffff\10\57\1\110\21\57",
            "\12\55\47\uffff\4\57\1\111\25\57",
            "\12\55\47\uffff\10\57\1\113\13\57\1\112\5\57",
            "\1\115\4\uffff\1\114\76\uffff\1\116",
            "\1\120",
            "\12\55\47\uffff\16\57\1\122\13\57",
            "\12\55\47\uffff\16\57\1\123\13\57",
            "\12\55\47\uffff\4\57\1\124\25\57",
            "\12\55\47\uffff\26\57\1\125\3\57",
            "\1\126",
            "\1\127",
            "\1\130",
            "",
            "",
            "\12\134",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\145\11\uffff\1\146\1\uffff\1\144\1\uffff\1\147\1\uffff\1\150",
            "\12\55\47\uffff\32\57",
            "",
            "\0\151",
            "\0\151",
            "",
            "",
            "\12\55\47\uffff\1\153\7\57\1\154\21\57",
            "\12\55\47\uffff\1\57\1\155\30\57",
            "\12\55\47\uffff\4\57\1\156\25\57",
            "\12\55\6\uffff\1\157",
            "",
            "\12\55\47\uffff\32\57",
            "\12\55\47\uffff\13\57\1\160\16\57",
            "\12\55\47\uffff\21\57\1\161\10\57",
            "\12\55\47\uffff\1\162\31\57",
            "\12\55\47\uffff\15\57\1\163\14\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\47\uffff\17\57\1\165\12\57",
            "\12\55\47\uffff\23\57\1\166\6\57",
            "",
            "",
            "",
            "",
            "",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\47\uffff\3\57\1\170\26\57",
            "\12\55\47\uffff\4\57\1\171\25\57",
            "\12\55\47\uffff\24\57\1\172\5\57",
            "\12\55\47\uffff\23\57\1\173\6\57",
            "\12\55\47\uffff\7\57\1\174\22\57",
            "\12\55\47\uffff\3\57\1\175\26\57",
            "\12\55\47\uffff\17\57\1\176\12\57",
            "",
            "",
            "",
            "",
            "\12\55\47\uffff\15\57\1\177\14\57",
            "\12\55\47\uffff\20\57\1\u0080\11\57",
            "\12\55\47\uffff\15\57\1\u0081\14\57",
            "\12\55\47\uffff\15\57\1\u0082\14\57",
            "\0\u0084",
            "\0\u0085",
            "",
            "",
            "",
            "",
            "\12\55\47\uffff\24\57\1\u0087\5\57",
            "\12\55\47\uffff\16\57\1\u0088\13\57",
            "\12\55\47\uffff\10\57\1\u0089\21\57",
            "\12\55\47\uffff\4\57\1\u008a\25\57",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\12\55\47\uffff\6\57\1\u008b\23\57",
            "\12\55\47\uffff\25\57\1\u008c\4\57",
            "\12\55\47\uffff\13\57\1\u008d\16\57",
            "\12\55\47\uffff\10\57\1\u008e\21\57",
            "",
            "\12\55\47\uffff\10\57\1\u008f\21\57",
            "\12\55\47\uffff\10\57\1\u0091\13\57\1\u0090\5\57",
            "\12\55\47\uffff\1\57\1\u0092\30\57",
            "\12\55\47\uffff\23\57\1\u0093\6\57",
            "",
            "\12\55\47\uffff\16\57\1\u0094\13\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\4\57\1\u0095\25\57",
            "",
            "\12\55\47\uffff\21\57\1\u0097\10\57",
            "\12\55\47\uffff\15\57\1\u0098\14\57",
            "\12\55\47\uffff\14\57\1\u0099\15\57",
            "\12\55\47\uffff\4\57\1\u009a\25\57",
            "\12\55\47\uffff\4\57\1\u009b\25\57",
            "\12\55\47\uffff\10\57\1\u009c\21\57",
            "\12\55\47\uffff\17\57\1\u009d\12\57",
            "\12\55\47\uffff\23\57\1\u009e\6\57",
            "\12\55\47\uffff\24\57\1\u009f\5\57",
            "\12\55\47\uffff\2\57\1\u00a0\27\57",
            "\12\55\47\uffff\15\57\1\u00a1\14\57",
            "",
            "",
            "",
            "",
            "\12\55\47\uffff\1\57\1\u00a2\30\57",
            "\12\55\47\uffff\13\57\1\u00a3\16\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\47\uffff\10\57\1\u00a5\21\57",
            "\12\55\47\uffff\14\57\1\u00a6\15\57",
            "\12\55\47\uffff\1\u00a7\31\57",
            "\12\55\47\uffff\10\57\1\u00a8\21\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\47\uffff\3\57\1\u00aa\26\57",
            "\12\55\47\uffff\2\57\1\u00ab\27\57",
            "\12\55\47\uffff\15\57\1\u00ac\14\57",
            "\12\55\47\uffff\16\57\1\u00ad\13\57",
            "\12\55\47\uffff\21\57\1\u00ae\10\57",
            "\12\55\47\uffff\21\57\1\u00af\10\57",
            "\12\55\47\uffff\21\57\1\u00b0\10\57",
            "",
            "\12\55\47\uffff\4\57\1\u00b1\25\57",
            "\12\55\47\uffff\23\57\1\u00b2\6\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\47\uffff\21\57\1\u00b4\10\57",
            "\12\55\47\uffff\21\57\1\u00b5\10\57",
            "\12\55\47\uffff\5\57\1\u00b6\24\57",
            "\12\55\47\uffff\10\57\1\u00b7\21\57",
            "\2\55\1\u00b9\5\55\1\u00b8\1\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\47\uffff\10\57\1\u00bb\21\57",
            "\12\55\47\uffff\23\57\1\u00bc\6\57",
            "\12\55\47\uffff\4\57\1\u00bd\25\57",
            "\12\55\47\uffff\13\57\1\u00be\16\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\47\uffff\1\u00c1\31\57",
            "\12\55\47\uffff\23\57\1\u00c2\6\57",
            "\12\55\47\uffff\2\57\1\u00c3\27\57",
            "",
            "\12\55\47\uffff\10\57\1\u00c4\21\57",
            "\12\55\47\uffff\23\57\1\u00c5\6\57",
            "\12\55\47\uffff\6\57\1\u00c6\23\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\47\uffff\1\u00c8\31\57",
            "\12\55\47\uffff\23\57\1\u00c9\6\57",
            "\12\55\47\uffff\15\57\1\u00ca\14\57",
            "\12\55\47\uffff\22\57\1\u00cb\7\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "",
            "\12\55\47\uffff\15\57\1\u00cd\14\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\47\uffff\10\57\1\u00cf\21\57",
            "\12\55\47\uffff\15\57\1\u00d0\14\57",
            "\12\55\6\uffff\1\157\32\56\4\uffff\1\56\1\uffff\32\56",
            "\5\55\1\u00d2\4\55\6\uffff\1\157",
            "",
            "\12\55\47\uffff\21\57\1\u00d3\10\57",
            "\12\55\47\uffff\10\57\1\u00d4\21\57",
            "\12\55\47\uffff\30\57\1\u00d5\1\57",
            "\12\55\47\uffff\4\57\1\u00d6\25\57",
            "",
            "",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\47\uffff\4\57\1\u00d8\25\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\47\uffff\23\57\1\u00da\6\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "",
            "\12\55\47\uffff\2\57\1\u00dd\27\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\47\uffff\1\u00df\31\57",
            "\12\55\47\uffff\22\57\1\u00e0\7\57",
            "",
            "\12\55\47\uffff\1\u00e1\31\57",
            "",
            "\12\55\47\uffff\4\57\1\u00e2\25\57",
            "\12\55\47\uffff\6\57\1\u00e3\23\57",
            "",
            "\6\55\1\u00e4\3\55\6\uffff\1\157",
            "\12\55\47\uffff\4\57\1\u00e5\25\57",
            "\12\55\47\uffff\16\57\1\u00e6\13\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "",
            "\12\55\47\uffff\30\57\1\u00ea\1\57",
            "",
            "",
            "\12\55\47\uffff\23\57\1\u00eb\6\57",
            "",
            "\12\55\47\uffff\13\57\1\u00ec\16\57",
            "\1\u00ed\17\uffff\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\47\uffff\13\57\1\u00ef\16\57",
            "\12\55\47\uffff\21\57\1\u00f0\10\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\6\uffff\1\157\32\56\4\uffff\1\56\1\uffff\32\56",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\47\uffff\15\57\1\u00f4\14\57",
            "",
            "",
            "",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "",
            "",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "",
            "",
            "",
            "\12\55\7\uffff\32\56\4\uffff\1\56\1\uffff\32\57",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA21_eot = DFA.unpackEncodedString(DFA21_eotS);
    static final short[] DFA21_eof = DFA.unpackEncodedString(DFA21_eofS);
    static final char[] DFA21_min = DFA.unpackEncodedStringToUnsignedChars(DFA21_minS);
    static final char[] DFA21_max = DFA.unpackEncodedStringToUnsignedChars(DFA21_maxS);
    static final short[] DFA21_accept = DFA.unpackEncodedString(DFA21_acceptS);
    static final short[] DFA21_special = DFA.unpackEncodedString(DFA21_specialS);
    static final short[][] DFA21_transition;

    static {
        int numStates = DFA21_transitionS.length;
        DFA21_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA21_transition[i] = DFA.unpackEncodedString(DFA21_transitionS[i]);
        }
    }

    class DFA21 extends DFA {

        public DFA21(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 21;
            this.eot = DFA21_eot;
            this.eof = DFA21_eof;
            this.min = DFA21_min;
            this.max = DFA21_max;
            this.accept = DFA21_accept;
            this.special = DFA21_special;
            this.transition = DFA21_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( T__26 | T__27 | T__28 | T__29 | T__30 | T__31 | T__32 | T__33 | T__34 | T__35 | T__36 | T__37 | T__38 | T__39 | T__40 | T__41 | T__42 | T__43 | T__44 | T__45 | T__46 | T__47 | T__48 | T__49 | T__50 | T__51 | T__52 | T__53 | T__54 | T__55 | T__56 | T__57 | T__58 | T__59 | T__60 | T__61 | T__62 | T__63 | T__64 | T__65 | T__66 | T__67 | T__68 | T__69 | T__70 | T__71 | T__72 | T__73 | T__74 | T__75 | T__76 | RULE_NUMBER | RULE_CLOSEKEY | RULE_OPENKEY | RULE_OPENPARENTHESIS | RULE_CLOSEPARENTHESIS | RULE_EOLINE | RULE_SEMICOLON | RULE_DOT | RULE_COMMA | RULE_PARAMSLONGCOMENT | RULE_DEVLONGCOMENT | RULE_NOTICELONGCOMENT | RULE_RETURNSLONGCOMENT | RULE_TITLELONGCOMENT | RULE_EMAIL | RULE_ID | RULE_INT | RULE_STRING | RULE_ML_COMMENT | RULE_SL_COMMENT | RULE_WS | RULE_ANY_OTHER );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            IntStream input = _input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA21_38 = input.LA(1);

                        s = -1;
                        if ( ((LA21_38>='\u0000' && LA21_38<='\uFFFF')) ) {s = 105;}

                        else s = 41;

                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA21_0 = input.LA(1);

                        s = -1;
                        if ( (LA21_0=='p') ) {s = 1;}

                        else if ( (LA21_0=='s') ) {s = 2;}

                        else if ( (LA21_0=='c') ) {s = 3;}

                        else if ( (LA21_0=='i') ) {s = 4;}

                        else if ( (LA21_0=='^') ) {s = 5;}

                        else if ( (LA21_0=='>') ) {s = 6;}

                        else if ( (LA21_0=='<') ) {s = 7;}

                        else if ( (LA21_0=='a') ) {s = 8;}

                        else if ( (LA21_0=='e') ) {s = 9;}

                        else if ( (LA21_0=='m') ) {s = 10;}

                        else if ( (LA21_0=='_') ) {s = 11;}

                        else if ( (LA21_0=='=') ) {s = 12;}

                        else if ( (LA21_0=='u') ) {s = 13;}

                        else if ( (LA21_0=='r') ) {s = 14;}

                        else if ( (LA21_0=='f') ) {s = 15;}

                        else if ( (LA21_0=='/') ) {s = 16;}

                        else if ( (LA21_0=='*') ) {s = 17;}

                        else if ( (LA21_0=='d') ) {s = 18;}

                        else if ( (LA21_0=='b') ) {s = 19;}

                        else if ( (LA21_0=='w') ) {s = 20;}

                        else if ( (LA21_0=='g') ) {s = 21;}

                        else if ( (LA21_0=='!') ) {s = 22;}

                        else if ( (LA21_0=='&') ) {s = 23;}

                        else if ( (LA21_0=='|') ) {s = 24;}

                        else if ( (LA21_0=='+') ) {s = 25;}

                        else if ( (LA21_0=='-') ) {s = 26;}

                        else if ( ((LA21_0>='0' && LA21_0<='9')) ) {s = 27;}

                        else if ( (LA21_0=='}') ) {s = 28;}

                        else if ( (LA21_0=='{') ) {s = 29;}

                        else if ( (LA21_0=='(') ) {s = 30;}

                        else if ( (LA21_0==')') ) {s = 31;}

                        else if ( (LA21_0==';') ) {s = 32;}

                        else if ( (LA21_0=='.') ) {s = 33;}

                        else if ( (LA21_0==',') ) {s = 34;}

                        else if ( (LA21_0=='@') ) {s = 35;}

                        else if ( (LA21_0=='h'||(LA21_0>='j' && LA21_0<='l')||(LA21_0>='n' && LA21_0<='o')||LA21_0=='q'||LA21_0=='t'||LA21_0=='v'||(LA21_0>='x' && LA21_0<='z')) ) {s = 36;}

                        else if ( ((LA21_0>='A' && LA21_0<='Z')) ) {s = 37;}

                        else if ( (LA21_0=='\"') ) {s = 38;}

                        else if ( (LA21_0=='\'') ) {s = 39;}

                        else if ( ((LA21_0>='\t' && LA21_0<='\n')||LA21_0=='\r'||LA21_0==' ') ) {s = 40;}

                        else if ( ((LA21_0>='\u0000' && LA21_0<='\b')||(LA21_0>='\u000B' && LA21_0<='\f')||(LA21_0>='\u000E' && LA21_0<='\u001F')||(LA21_0>='#' && LA21_0<='%')||LA21_0==':'||LA21_0=='?'||(LA21_0>='[' && LA21_0<=']')||LA21_0=='`'||(LA21_0>='~' && LA21_0<='\uFFFF')) ) {s = 41;}

                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA21_77 = input.LA(1);

                        s = -1;
                        if ( ((LA21_77>='\u0000' && LA21_77<='\uFFFF')) ) {s = 133;}

                        else s = 134;

                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA21_76 = input.LA(1);

                        s = -1;
                        if ( ((LA21_76>='\u0000' && LA21_76<='\uFFFF')) ) {s = 132;}

                        else s = 131;

                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA21_39 = input.LA(1);

                        s = -1;
                        if ( ((LA21_39>='\u0000' && LA21_39<='\uFFFF')) ) {s = 105;}

                        else s = 41;

                        if ( s>=0 ) return s;
                        break;
            }
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 21, _s, input);
            error(nvae);
            throw nvae;
        }
    }
 

}