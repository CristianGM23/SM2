package org.xtext.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_DOT", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_ID", "RULE_OPENKEY", "RULE_CLOSEKEY", "RULE_NUMVERSION1", "RULE_NUMVERSION2", "RULE_NUMVERSION3", "RULE_STRING", "RULE_EMAIL", "RULE_COMMA", "RULE_INT", "RULE_CONSTANT", "RULE_FLOAT", "RULE_BOOLVALUE", "RULE_HEXEXPRESSION", "RULE_NEW", "RULE_PARAMSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_DELETE", "RULE_EMIT", "RULE_RETURNS", "RULE_IF", "RULE_ELSE", "RULE_RETURN", "RULE_BREAK", "RULE_CONTINUE", "RULE_NOTICELONGCOMENT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'msg'", "'data'", "'value'", "'gas'", "'sender'", "'sig'", "'block'", "'difficulty'", "'number'", "'timestamp'", "'coinbase'", "'gaslimit'", "'blockhash'", "'now'", "'tx'", "'gasprice'", "'origin'", "'this'", "'balance'", "'contract'", "'is'", "'pragma'", "'solidity'", "'^'", "'>'", "'>='", "'constructor'", "'public'", "'internal'", "'event'", "'indexed'", "'import'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'address'", "'msg.sender'", "'string'", "'='", "'enum'", "'int'", "'uint'", "'uint8'", "'address payable'", "'double'", "'bool'", "'bytes'", "'bytes2'", "'bytes3'", "'bytes4'", "'bytes5'", "'bytes6'", "'bytes7'", "'bytes8'", "'bytes10'", "'bytes12'", "'bytes14'", "'bytes16'", "'bytes18'", "'bytes20'", "'bytes24'", "'bytes28'", "'bytes30'", "'bytes32'", "'[]'", "'['", "']'", "'memory'", "'storage'", "'Insert text here'", "'int2'", "'int4'", "'int8'", "'int16'", "'int24'", "'int32'", "'int40'", "'int48'", "'int56'", "'int64'", "'int80'", "'int88'", "'int96'", "'int104'", "'int128'", "'int160'", "'int256'", "'uint2'", "'uint4'", "'uint16'", "'uint24'", "'uint32'", "'uint40'", "'uint48'", "'uint56'", "'uint64'", "'uint80'", "'uint88'", "'uint96'", "'uint104'", "'uint128'", "'uint160'", "'uint256'", "'float'", "'0x'", "'/r'", "'require'", "'function'", "'selfdestruct'", "'keccack256'", "'sha256'", "'sha3'", "'//'", "'/*'", "'*/'", "'!'", "'view'", "'pure'", "'payable'", "'private'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'<'", "'<='", "'=='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'", "'%'", "'byte'"
    };
    public static final int T__144=144;
    public static final int T__143=143;
    public static final int T__146=146;
    public static final int T__50=50;
    public static final int T__145=145;
    public static final int T__140=140;
    public static final int T__142=142;
    public static final int T__141=141;
    public static final int RULE_RETURNS=30;
    public static final int RULE_OPENPARENTHESIS=5;
    public static final int RULE_EOLINE=8;
    public static final int T__59=59;
    public static final int RULE_EMIT=29;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__137=137;
    public static final int T__52=52;
    public static final int T__136=136;
    public static final int T__53=53;
    public static final int T__139=139;
    public static final int T__54=54;
    public static final int T__138=138;
    public static final int T__133=133;
    public static final int T__132=132;
    public static final int RULE_PARAMSLONGCOMENT=24;
    public static final int T__60=60;
    public static final int T__135=135;
    public static final int T__61=61;
    public static final int T__134=134;
    public static final int RULE_ID=9;
    public static final int RULE_RETURN=33;
    public static final int T__131=131;
    public static final int T__130=130;
    public static final int RULE_INT=18;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=37;
    public static final int T__67=67;
    public static final int T__129=129;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__126=126;
    public static final int T__63=63;
    public static final int T__125=125;
    public static final int T__64=64;
    public static final int T__128=128;
    public static final int T__65=65;
    public static final int T__127=127;
    public static final int T__166=166;
    public static final int T__165=165;
    public static final int RULE_DELETE=28;
    public static final int T__168=168;
    public static final int T__167=167;
    public static final int T__162=162;
    public static final int T__161=161;
    public static final int T__164=164;
    public static final int T__163=163;
    public static final int RULE_TITLELONGCOMENT=25;
    public static final int T__160=160;
    public static final int RULE_EMAIL=16;
    public static final int RULE_NOTICELONGCOMENT=36;
    public static final int RULE_CONSTANT=19;
    public static final int RULE_OPENKEY=10;
    public static final int RULE_CLOSEPARENTHESIS=6;
    public static final int RULE_IF=31;
    public static final int T__159=159;
    public static final int RULE_DOT=4;
    public static final int T__158=158;
    public static final int T__155=155;
    public static final int T__154=154;
    public static final int T__157=157;
    public static final int T__156=156;
    public static final int T__151=151;
    public static final int T__150=150;
    public static final int T__153=153;
    public static final int T__152=152;
    public static final int RULE_CONTINUE=35;
    public static final int RULE_DEVLONGCOMENT=26;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int RULE_FLOAT=20;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__148=148;
    public static final int T__41=41;
    public static final int T__147=147;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__149=149;
    public static final int T__91=91;
    public static final int T__100=100;
    public static final int T__92=92;
    public static final int T__93=93;
    public static final int T__102=102;
    public static final int T__94=94;
    public static final int T__101=101;
    public static final int RULE_NEW=23;
    public static final int T__90=90;
    public static final int T__180=180;
    public static final int T__99=99;
    public static final int RULE_CLOSEKEY=11;
    public static final int T__95=95;
    public static final int T__96=96;
    public static final int T__97=97;
    public static final int T__98=98;
    public static final int T__177=177;
    public static final int T__176=176;
    public static final int T__179=179;
    public static final int T__178=178;
    public static final int T__173=173;
    public static final int T__172=172;
    public static final int RULE_COMMA=17;
    public static final int T__175=175;
    public static final int T__174=174;
    public static final int T__171=171;
    public static final int T__170=170;
    public static final int RULE_RETURNSLONGCOMENT=27;
    public static final int RULE_SEMICOLON=7;
    public static final int T__169=169;
    public static final int RULE_NUMVERSION3=14;
    public static final int RULE_NUMVERSION2=13;
    public static final int RULE_ELSE=32;
    public static final int RULE_NUMVERSION1=12;
    public static final int T__122=122;
    public static final int T__70=70;
    public static final int T__121=121;
    public static final int T__71=71;
    public static final int T__124=124;
    public static final int RULE_BOOLVALUE=21;
    public static final int T__72=72;
    public static final int T__123=123;
    public static final int T__120=120;
    public static final int RULE_STRING=15;
    public static final int RULE_HEXEXPRESSION=22;
    public static final int RULE_SL_COMMENT=38;
    public static final int RULE_BREAK=34;
    public static final int T__77=77;
    public static final int T__119=119;
    public static final int T__78=78;
    public static final int T__118=118;
    public static final int T__79=79;
    public static final int T__73=73;
    public static final int T__115=115;
    public static final int EOF=-1;
    public static final int T__74=74;
    public static final int T__114=114;
    public static final int T__75=75;
    public static final int T__117=117;
    public static final int T__76=76;
    public static final int T__116=116;
    public static final int T__80=80;
    public static final int T__111=111;
    public static final int T__81=81;
    public static final int T__110=110;
    public static final int T__82=82;
    public static final int T__113=113;
    public static final int T__83=83;
    public static final int T__112=112;
    public static final int RULE_WS=39;
    public static final int RULE_ANY_OTHER=40;
    public static final int T__88=88;
    public static final int T__108=108;
    public static final int T__89=89;
    public static final int T__107=107;
    public static final int T__109=109;
    public static final int T__84=84;
    public static final int T__104=104;
    public static final int T__85=85;
    public static final int T__103=103;
    public static final int T__86=86;
    public static final int T__106=106;
    public static final int T__87=87;
    public static final int T__105=105;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }



     	private SM2GrammarAccess grammarAccess;

        public InternalSM2Parser(TokenStream input, SM2GrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "File";
       	}

       	@Override
       	protected SM2GrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleFile"
    // InternalSM2.g:65:1: entryRuleFile returns [EObject current=null] : iv_ruleFile= ruleFile EOF ;
    public final EObject entryRuleFile() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFile = null;


        try {
            // InternalSM2.g:65:45: (iv_ruleFile= ruleFile EOF )
            // InternalSM2.g:66:2: iv_ruleFile= ruleFile EOF
            {
             newCompositeNode(grammarAccess.getFileRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFile=ruleFile();

            state._fsp--;

             current =iv_ruleFile; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFile"


    // $ANTLR start "ruleFile"
    // InternalSM2.g:72:1: ruleFile returns [EObject current=null] : ( ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_properties_2_0= ruleProperties ) )* ( (lv_events_3_0= ruleEvent ) )* ( (lv_contract_4_0= ruleContract ) ) ( (lv_comments_5_0= ruleComment ) )* ) ;
    public final EObject ruleFile() throws RecognitionException {
        EObject current = null;

        EObject lv_version_0_0 = null;

        EObject lv_properties_2_0 = null;

        EObject lv_events_3_0 = null;

        EObject lv_contract_4_0 = null;

        EObject lv_comments_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:78:2: ( ( ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_properties_2_0= ruleProperties ) )* ( (lv_events_3_0= ruleEvent ) )* ( (lv_contract_4_0= ruleContract ) ) ( (lv_comments_5_0= ruleComment ) )* ) )
            // InternalSM2.g:79:2: ( ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_properties_2_0= ruleProperties ) )* ( (lv_events_3_0= ruleEvent ) )* ( (lv_contract_4_0= ruleContract ) ) ( (lv_comments_5_0= ruleComment ) )* )
            {
            // InternalSM2.g:79:2: ( ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_properties_2_0= ruleProperties ) )* ( (lv_events_3_0= ruleEvent ) )* ( (lv_contract_4_0= ruleContract ) ) ( (lv_comments_5_0= ruleComment ) )* )
            // InternalSM2.g:80:3: ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_properties_2_0= ruleProperties ) )* ( (lv_events_3_0= ruleEvent ) )* ( (lv_contract_4_0= ruleContract ) ) ( (lv_comments_5_0= ruleComment ) )*
            {
            // InternalSM2.g:80:3: ( (lv_version_0_0= ruleVersion ) )
            // InternalSM2.g:81:4: (lv_version_0_0= ruleVersion )
            {
            // InternalSM2.g:81:4: (lv_version_0_0= ruleVersion )
            // InternalSM2.g:82:5: lv_version_0_0= ruleVersion
            {

            					newCompositeNode(grammarAccess.getFileAccess().getVersionVersionParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_3);
            lv_version_0_0=ruleVersion();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFileRule());
            					}
            					set(
            						current,
            						"version",
            						lv_version_0_0,
            						"org.xtext.SM2.Version");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            			newCompositeNode(grammarAccess.getFileAccess().getImportParserRuleCall_1());
            		
            pushFollow(FOLLOW_4);
            ruleImport();

            state._fsp--;


            			afterParserOrEnumRuleCall();
            		
            // InternalSM2.g:106:3: ( (lv_properties_2_0= ruleProperties ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=77 && LA1_0<=78)||LA1_0==80||(LA1_0>=83 && LA1_0<=86)||(LA1_0>=88 && LA1_0<=106)||(LA1_0>=113 && LA1_0<=146)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalSM2.g:107:4: (lv_properties_2_0= ruleProperties )
            	    {
            	    // InternalSM2.g:107:4: (lv_properties_2_0= ruleProperties )
            	    // InternalSM2.g:108:5: lv_properties_2_0= ruleProperties
            	    {

            	    					newCompositeNode(grammarAccess.getFileAccess().getPropertiesPropertiesParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_4);
            	    lv_properties_2_0=ruleProperties();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFileRule());
            	    					}
            	    					add(
            	    						current,
            	    						"properties",
            	    						lv_properties_2_0,
            	    						"org.xtext.SM2.Properties");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            // InternalSM2.g:125:3: ( (lv_events_3_0= ruleEvent ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==70) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSM2.g:126:4: (lv_events_3_0= ruleEvent )
            	    {
            	    // InternalSM2.g:126:4: (lv_events_3_0= ruleEvent )
            	    // InternalSM2.g:127:5: lv_events_3_0= ruleEvent
            	    {

            	    					newCompositeNode(grammarAccess.getFileAccess().getEventsEventParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_4);
            	    lv_events_3_0=ruleEvent();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFileRule());
            	    					}
            	    					add(
            	    						current,
            	    						"events",
            	    						lv_events_3_0,
            	    						"org.xtext.SM2.Event");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalSM2.g:144:3: ( (lv_contract_4_0= ruleContract ) )
            // InternalSM2.g:145:4: (lv_contract_4_0= ruleContract )
            {
            // InternalSM2.g:145:4: (lv_contract_4_0= ruleContract )
            // InternalSM2.g:146:5: lv_contract_4_0= ruleContract
            {

            					newCompositeNode(grammarAccess.getFileAccess().getContractContractParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_5);
            lv_contract_4_0=ruleContract();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFileRule());
            					}
            					set(
            						current,
            						"contract",
            						lv_contract_4_0,
            						"org.xtext.SM2.Contract");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:163:3: ( (lv_comments_5_0= ruleComment ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( ((LA3_0>=155 && LA3_0<=156)) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalSM2.g:164:4: (lv_comments_5_0= ruleComment )
            	    {
            	    // InternalSM2.g:164:4: (lv_comments_5_0= ruleComment )
            	    // InternalSM2.g:165:5: lv_comments_5_0= ruleComment
            	    {

            	    					newCompositeNode(grammarAccess.getFileAccess().getCommentsCommentParserRuleCall_5_0());
            	    				
            	    pushFollow(FOLLOW_5);
            	    lv_comments_5_0=ruleComment();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFileRule());
            	    					}
            	    					add(
            	    						current,
            	    						"comments",
            	    						lv_comments_5_0,
            	    						"org.xtext.SM2.Comment");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFile"


    // $ANTLR start "entryRuleMSGVariables"
    // InternalSM2.g:186:1: entryRuleMSGVariables returns [EObject current=null] : iv_ruleMSGVariables= ruleMSGVariables EOF ;
    public final EObject entryRuleMSGVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMSGVariables = null;


        try {
            // InternalSM2.g:186:53: (iv_ruleMSGVariables= ruleMSGVariables EOF )
            // InternalSM2.g:187:2: iv_ruleMSGVariables= ruleMSGVariables EOF
            {
             newCompositeNode(grammarAccess.getMSGVariablesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMSGVariables=ruleMSGVariables();

            state._fsp--;

             current =iv_ruleMSGVariables; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMSGVariables"


    // $ANTLR start "ruleMSGVariables"
    // InternalSM2.g:193:1: ruleMSGVariables returns [EObject current=null] : (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation ) ;
    public final EObject ruleMSGVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_MSGOperation_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:199:2: ( (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation ) )
            // InternalSM2.g:200:2: (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation )
            {
            // InternalSM2.g:200:2: (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation )
            // InternalSM2.g:201:3: otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation
            {
            otherlv_0=(Token)match(input,41,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getMSGVariablesAccess().getMsgKeyword_0());
            		

            			newCompositeNode(grammarAccess.getMSGVariablesAccess().getMSGOperationParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_MSGOperation_1=ruleMSGOperation();

            state._fsp--;


            			current = this_MSGOperation_1;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMSGVariables"


    // $ANTLR start "entryRuleMSGOperation"
    // InternalSM2.g:217:1: entryRuleMSGOperation returns [EObject current=null] : iv_ruleMSGOperation= ruleMSGOperation EOF ;
    public final EObject entryRuleMSGOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMSGOperation = null;


        try {
            // InternalSM2.g:217:53: (iv_ruleMSGOperation= ruleMSGOperation EOF )
            // InternalSM2.g:218:2: iv_ruleMSGOperation= ruleMSGOperation EOF
            {
             newCompositeNode(grammarAccess.getMSGOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMSGOperation=ruleMSGOperation();

            state._fsp--;

             current =iv_ruleMSGOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMSGOperation"


    // $ANTLR start "ruleMSGOperation"
    // InternalSM2.g:224:1: ruleMSGOperation returns [EObject current=null] : (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? ) ;
    public final EObject ruleMSGOperation() throws RecognitionException {
        EObject current = null;

        Token this_DOT_0=null;
        Token otherlv_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token this_OPENPARENTHESIS_7=null;
        Token this_CLOSEPARENTHESIS_9=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token this_OPENPARENTHESIS_12=null;
        Token this_CLOSEPARENTHESIS_14=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token this_OPENPARENTHESIS_17=null;
        Token this_CLOSEPARENTHESIS_19=null;
        Token otherlv_20=null;
        Token otherlv_21=null;
        Token this_OPENPARENTHESIS_22=null;
        Token this_CLOSEPARENTHESIS_24=null;
        Token otherlv_25=null;
        Token this_SEMICOLON_26=null;
        Token this_EOLINE_27=null;


        	enterRule();

        try {
            // InternalSM2.g:230:2: ( (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? ) )
            // InternalSM2.g:231:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? )
            {
            // InternalSM2.g:231:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? )
            // InternalSM2.g:232:3: this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )?
            {
            this_DOT_0=(Token)match(input,RULE_DOT,FOLLOW_7); 

            			newLeafNode(this_DOT_0, grammarAccess.getMSGOperationAccess().getDOTTerminalRuleCall_0());
            		
            // InternalSM2.g:236:3: ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) )
            int alt9=5;
            switch ( input.LA(1) ) {
            case 42:
                {
                alt9=1;
                }
                break;
            case 43:
                {
                alt9=2;
                }
                break;
            case 44:
                {
                alt9=3;
                }
                break;
            case 45:
                {
                alt9=4;
                }
                break;
            case 46:
                {
                alt9=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalSM2.g:237:4: ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' )
                    {
                    // InternalSM2.g:237:4: ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' )
                    int alt4=2;
                    int LA4_0 = input.LA(1);

                    if ( (LA4_0==42) ) {
                        int LA4_1 = input.LA(2);

                        if ( (LA4_1==EOF||LA4_1==RULE_SEMICOLON) ) {
                            alt4=2;
                        }
                        else if ( (LA4_1==RULE_OPENPARENTHESIS) ) {
                            alt4=1;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 4, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 0, input);

                        throw nvae;
                    }
                    switch (alt4) {
                        case 1 :
                            // InternalSM2.g:238:5: (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:238:5: (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:239:6: otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_1=(Token)match(input,42,FOLLOW_8); 

                            						newLeafNode(otherlv_1, grammarAccess.getMSGOperationAccess().getDataKeyword_1_0_0_0());
                            					
                            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_0_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_0_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:260:5: otherlv_5= 'data'
                            {
                            otherlv_5=(Token)match(input,42,FOLLOW_11); 

                            					newLeafNode(otherlv_5, grammarAccess.getMSGOperationAccess().getDataKeyword_1_0_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:266:4: ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' )
                    {
                    // InternalSM2.g:266:4: ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' )
                    int alt5=2;
                    int LA5_0 = input.LA(1);

                    if ( (LA5_0==43) ) {
                        int LA5_1 = input.LA(2);

                        if ( (LA5_1==RULE_OPENPARENTHESIS) ) {
                            alt5=1;
                        }
                        else if ( (LA5_1==EOF||LA5_1==RULE_SEMICOLON) ) {
                            alt5=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 5, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 5, 0, input);

                        throw nvae;
                    }
                    switch (alt5) {
                        case 1 :
                            // InternalSM2.g:267:5: (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:267:5: (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:268:6: otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_6=(Token)match(input,43,FOLLOW_8); 

                            						newLeafNode(otherlv_6, grammarAccess.getMSGOperationAccess().getValueKeyword_1_1_0_0());
                            					
                            this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_1_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_9=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_9, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:289:5: otherlv_10= 'value'
                            {
                            otherlv_10=(Token)match(input,43,FOLLOW_11); 

                            					newLeafNode(otherlv_10, grammarAccess.getMSGOperationAccess().getValueKeyword_1_1_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:295:4: ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' )
                    {
                    // InternalSM2.g:295:4: ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' )
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( (LA6_0==44) ) {
                        int LA6_1 = input.LA(2);

                        if ( (LA6_1==RULE_OPENPARENTHESIS) ) {
                            alt6=1;
                        }
                        else if ( (LA6_1==EOF||LA6_1==RULE_SEMICOLON) ) {
                            alt6=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 6, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 6, 0, input);

                        throw nvae;
                    }
                    switch (alt6) {
                        case 1 :
                            // InternalSM2.g:296:5: (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:296:5: (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:297:6: otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_11=(Token)match(input,44,FOLLOW_8); 

                            						newLeafNode(otherlv_11, grammarAccess.getMSGOperationAccess().getGasKeyword_1_2_0_0());
                            					
                            this_OPENPARENTHESIS_12=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_12, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_2_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_2_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_14=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_14, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_2_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:318:5: otherlv_15= 'gas'
                            {
                            otherlv_15=(Token)match(input,44,FOLLOW_11); 

                            					newLeafNode(otherlv_15, grammarAccess.getMSGOperationAccess().getGasKeyword_1_2_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:324:4: ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' )
                    {
                    // InternalSM2.g:324:4: ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' )
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==45) ) {
                        int LA7_1 = input.LA(2);

                        if ( (LA7_1==EOF||LA7_1==RULE_SEMICOLON) ) {
                            alt7=2;
                        }
                        else if ( (LA7_1==RULE_OPENPARENTHESIS) ) {
                            alt7=1;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 7, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 7, 0, input);

                        throw nvae;
                    }
                    switch (alt7) {
                        case 1 :
                            // InternalSM2.g:325:5: (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:325:5: (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:326:6: otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_16=(Token)match(input,45,FOLLOW_8); 

                            						newLeafNode(otherlv_16, grammarAccess.getMSGOperationAccess().getSenderKeyword_1_3_0_0());
                            					
                            this_OPENPARENTHESIS_17=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_17, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_3_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_3_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_19=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_19, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:347:5: otherlv_20= 'sender'
                            {
                            otherlv_20=(Token)match(input,45,FOLLOW_11); 

                            					newLeafNode(otherlv_20, grammarAccess.getMSGOperationAccess().getSenderKeyword_1_3_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:353:4: ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' )
                    {
                    // InternalSM2.g:353:4: ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' )
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==46) ) {
                        int LA8_1 = input.LA(2);

                        if ( (LA8_1==RULE_OPENPARENTHESIS) ) {
                            alt8=1;
                        }
                        else if ( (LA8_1==EOF||LA8_1==RULE_SEMICOLON) ) {
                            alt8=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 8, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 8, 0, input);

                        throw nvae;
                    }
                    switch (alt8) {
                        case 1 :
                            // InternalSM2.g:354:5: (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:354:5: (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:355:6: otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_21=(Token)match(input,46,FOLLOW_8); 

                            						newLeafNode(otherlv_21, grammarAccess.getMSGOperationAccess().getSigKeyword_1_4_0_0());
                            					
                            this_OPENPARENTHESIS_22=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_22, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_4_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_4_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_24=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_24, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_4_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:376:5: otherlv_25= 'sig'
                            {
                            otherlv_25=(Token)match(input,46,FOLLOW_11); 

                            					newLeafNode(otherlv_25, grammarAccess.getMSGOperationAccess().getSigKeyword_1_4_1());
                            				

                            }
                            break;

                    }


                    }
                    break;

            }

            // InternalSM2.g:382:3: (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==RULE_SEMICOLON) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalSM2.g:383:4: this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE
                    {
                    this_SEMICOLON_26=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

                    				newLeafNode(this_SEMICOLON_26, grammarAccess.getMSGOperationAccess().getSEMICOLONTerminalRuleCall_2_0());
                    			
                    this_EOLINE_27=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_27, grammarAccess.getMSGOperationAccess().getEOLINETerminalRuleCall_2_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMSGOperation"


    // $ANTLR start "entryRuleBlockVariables"
    // InternalSM2.g:396:1: entryRuleBlockVariables returns [EObject current=null] : iv_ruleBlockVariables= ruleBlockVariables EOF ;
    public final EObject entryRuleBlockVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBlockVariables = null;


        try {
            // InternalSM2.g:396:55: (iv_ruleBlockVariables= ruleBlockVariables EOF )
            // InternalSM2.g:397:2: iv_ruleBlockVariables= ruleBlockVariables EOF
            {
             newCompositeNode(grammarAccess.getBlockVariablesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBlockVariables=ruleBlockVariables();

            state._fsp--;

             current =iv_ruleBlockVariables; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBlockVariables"


    // $ANTLR start "ruleBlockVariables"
    // InternalSM2.g:403:1: ruleBlockVariables returns [EObject current=null] : (otherlv_0= 'block' this_BlockOperation_1= ruleBlockOperation ) ;
    public final EObject ruleBlockVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_BlockOperation_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:409:2: ( (otherlv_0= 'block' this_BlockOperation_1= ruleBlockOperation ) )
            // InternalSM2.g:410:2: (otherlv_0= 'block' this_BlockOperation_1= ruleBlockOperation )
            {
            // InternalSM2.g:410:2: (otherlv_0= 'block' this_BlockOperation_1= ruleBlockOperation )
            // InternalSM2.g:411:3: otherlv_0= 'block' this_BlockOperation_1= ruleBlockOperation
            {
            otherlv_0=(Token)match(input,47,FOLLOW_13); 

            			newLeafNode(otherlv_0, grammarAccess.getBlockVariablesAccess().getBlockKeyword_0());
            		

            			newCompositeNode(grammarAccess.getBlockVariablesAccess().getBlockOperationParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_BlockOperation_1=ruleBlockOperation();

            state._fsp--;


            			current = this_BlockOperation_1;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBlockVariables"


    // $ANTLR start "entryRuleBlockOperation"
    // InternalSM2.g:427:1: entryRuleBlockOperation returns [EObject current=null] : iv_ruleBlockOperation= ruleBlockOperation EOF ;
    public final EObject entryRuleBlockOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBlockOperation = null;


        try {
            // InternalSM2.g:427:55: (iv_ruleBlockOperation= ruleBlockOperation EOF )
            // InternalSM2.g:428:2: iv_ruleBlockOperation= ruleBlockOperation EOF
            {
             newCompositeNode(grammarAccess.getBlockOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBlockOperation=ruleBlockOperation();

            state._fsp--;

             current =iv_ruleBlockOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBlockOperation"


    // $ANTLR start "ruleBlockOperation"
    // InternalSM2.g:434:1: ruleBlockOperation returns [EObject current=null] : ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? ) ) ;
    public final EObject ruleBlockOperation() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_DOT_1=null;
        Token otherlv_2=null;
        Token this_OPENPARENTHESIS_3=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token this_OPENPARENTHESIS_8=null;
        Token this_CLOSEPARENTHESIS_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token this_OPENPARENTHESIS_13=null;
        Token this_CLOSEPARENTHESIS_15=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token this_OPENPARENTHESIS_18=null;
        Token this_CLOSEPARENTHESIS_20=null;
        Token otherlv_21=null;
        Token otherlv_22=null;
        Token this_OPENPARENTHESIS_23=null;
        Token this_CLOSEPARENTHESIS_25=null;
        Token otherlv_26=null;
        Token otherlv_27=null;
        Token this_OPENPARENTHESIS_28=null;
        Token this_CLOSEPARENTHESIS_30=null;
        Token otherlv_31=null;
        Token otherlv_32=null;
        Token this_OPENPARENTHESIS_33=null;
        Token this_CLOSEPARENTHESIS_35=null;
        Token this_SEMICOLON_36=null;


        	enterRule();

        try {
            // InternalSM2.g:440:2: ( ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? ) ) )
            // InternalSM2.g:441:2: ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? ) )
            {
            // InternalSM2.g:441:2: ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? ) )
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==47) ) {
                alt19=1;
            }
            else if ( (LA19_0==54) ) {
                alt19=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }
            switch (alt19) {
                case 1 :
                    // InternalSM2.g:442:3: (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) )
                    {
                    // InternalSM2.g:442:3: (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) )
                    // InternalSM2.g:443:4: otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) )
                    {
                    otherlv_0=(Token)match(input,47,FOLLOW_6); 

                    				newLeafNode(otherlv_0, grammarAccess.getBlockOperationAccess().getBlockKeyword_0_0());
                    			
                    this_DOT_1=(Token)match(input,RULE_DOT,FOLLOW_14); 

                    				newLeafNode(this_DOT_1, grammarAccess.getBlockOperationAccess().getDOTTerminalRuleCall_0_1());
                    			
                    // InternalSM2.g:451:4: ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) )
                    int alt17=6;
                    switch ( input.LA(1) ) {
                    case 48:
                        {
                        alt17=1;
                        }
                        break;
                    case 49:
                        {
                        alt17=2;
                        }
                        break;
                    case 50:
                        {
                        alt17=3;
                        }
                        break;
                    case 51:
                        {
                        alt17=4;
                        }
                        break;
                    case 52:
                        {
                        alt17=5;
                        }
                        break;
                    case 53:
                        {
                        alt17=6;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 17, 0, input);

                        throw nvae;
                    }

                    switch (alt17) {
                        case 1 :
                            // InternalSM2.g:452:5: ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' )
                            {
                            // InternalSM2.g:452:5: ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' )
                            int alt11=2;
                            int LA11_0 = input.LA(1);

                            if ( (LA11_0==48) ) {
                                int LA11_1 = input.LA(2);

                                if ( (LA11_1==EOF) ) {
                                    alt11=2;
                                }
                                else if ( (LA11_1==RULE_OPENPARENTHESIS) ) {
                                    alt11=1;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 11, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 11, 0, input);

                                throw nvae;
                            }
                            switch (alt11) {
                                case 1 :
                                    // InternalSM2.g:453:6: (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:453:6: (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:454:7: otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_2=(Token)match(input,48,FOLLOW_8); 

                                    							newLeafNode(otherlv_2, grammarAccess.getBlockOperationAccess().getDifficultyKeyword_0_2_0_0_0());
                                    						
                                    this_OPENPARENTHESIS_3=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                                    							newLeafNode(this_OPENPARENTHESIS_3, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_0_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_0_0_2());
                                    						
                                    pushFollow(FOLLOW_10);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_0_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:475:6: otherlv_6= 'difficulty'
                                    {
                                    otherlv_6=(Token)match(input,48,FOLLOW_2); 

                                    						newLeafNode(otherlv_6, grammarAccess.getBlockOperationAccess().getDifficultyKeyword_0_2_0_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:481:5: ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' )
                            {
                            // InternalSM2.g:481:5: ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' )
                            int alt12=2;
                            int LA12_0 = input.LA(1);

                            if ( (LA12_0==49) ) {
                                int LA12_1 = input.LA(2);

                                if ( (LA12_1==RULE_OPENPARENTHESIS) ) {
                                    alt12=1;
                                }
                                else if ( (LA12_1==EOF) ) {
                                    alt12=2;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 12, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 12, 0, input);

                                throw nvae;
                            }
                            switch (alt12) {
                                case 1 :
                                    // InternalSM2.g:482:6: (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:482:6: (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:483:7: otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_7=(Token)match(input,49,FOLLOW_8); 

                                    							newLeafNode(otherlv_7, grammarAccess.getBlockOperationAccess().getNumberKeyword_0_2_1_0_0());
                                    						
                                    this_OPENPARENTHESIS_8=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                                    							newLeafNode(this_OPENPARENTHESIS_8, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_1_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_1_0_2());
                                    						
                                    pushFollow(FOLLOW_10);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_10=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_10, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_1_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:504:6: otherlv_11= 'number'
                                    {
                                    otherlv_11=(Token)match(input,49,FOLLOW_2); 

                                    						newLeafNode(otherlv_11, grammarAccess.getBlockOperationAccess().getNumberKeyword_0_2_1_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 3 :
                            // InternalSM2.g:510:5: ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' )
                            {
                            // InternalSM2.g:510:5: ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' )
                            int alt13=2;
                            int LA13_0 = input.LA(1);

                            if ( (LA13_0==50) ) {
                                int LA13_1 = input.LA(2);

                                if ( (LA13_1==RULE_OPENPARENTHESIS) ) {
                                    alt13=1;
                                }
                                else if ( (LA13_1==EOF) ) {
                                    alt13=2;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 13, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 13, 0, input);

                                throw nvae;
                            }
                            switch (alt13) {
                                case 1 :
                                    // InternalSM2.g:511:6: (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:511:6: (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:512:7: otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_12=(Token)match(input,50,FOLLOW_8); 

                                    							newLeafNode(otherlv_12, grammarAccess.getBlockOperationAccess().getTimestampKeyword_0_2_2_0_0());
                                    						
                                    this_OPENPARENTHESIS_13=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                                    							newLeafNode(this_OPENPARENTHESIS_13, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_2_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_2_0_2());
                                    						
                                    pushFollow(FOLLOW_10);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_15=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_15, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_2_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:533:6: otherlv_16= 'timestamp'
                                    {
                                    otherlv_16=(Token)match(input,50,FOLLOW_2); 

                                    						newLeafNode(otherlv_16, grammarAccess.getBlockOperationAccess().getTimestampKeyword_0_2_2_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 4 :
                            // InternalSM2.g:539:5: ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' )
                            {
                            // InternalSM2.g:539:5: ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' )
                            int alt14=2;
                            int LA14_0 = input.LA(1);

                            if ( (LA14_0==51) ) {
                                int LA14_1 = input.LA(2);

                                if ( (LA14_1==EOF) ) {
                                    alt14=2;
                                }
                                else if ( (LA14_1==RULE_OPENPARENTHESIS) ) {
                                    alt14=1;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 14, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 14, 0, input);

                                throw nvae;
                            }
                            switch (alt14) {
                                case 1 :
                                    // InternalSM2.g:540:6: (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:540:6: (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:541:7: otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_17=(Token)match(input,51,FOLLOW_8); 

                                    							newLeafNode(otherlv_17, grammarAccess.getBlockOperationAccess().getCoinbaseKeyword_0_2_3_0_0());
                                    						
                                    this_OPENPARENTHESIS_18=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                                    							newLeafNode(this_OPENPARENTHESIS_18, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_3_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_3_0_2());
                                    						
                                    pushFollow(FOLLOW_10);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_20=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_20, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_3_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:562:6: otherlv_21= 'coinbase'
                                    {
                                    otherlv_21=(Token)match(input,51,FOLLOW_2); 

                                    						newLeafNode(otherlv_21, grammarAccess.getBlockOperationAccess().getCoinbaseKeyword_0_2_3_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 5 :
                            // InternalSM2.g:568:5: ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' )
                            {
                            // InternalSM2.g:568:5: ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' )
                            int alt15=2;
                            int LA15_0 = input.LA(1);

                            if ( (LA15_0==52) ) {
                                int LA15_1 = input.LA(2);

                                if ( (LA15_1==RULE_OPENPARENTHESIS) ) {
                                    alt15=1;
                                }
                                else if ( (LA15_1==EOF) ) {
                                    alt15=2;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 15, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 15, 0, input);

                                throw nvae;
                            }
                            switch (alt15) {
                                case 1 :
                                    // InternalSM2.g:569:6: (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:569:6: (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:570:7: otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_22=(Token)match(input,52,FOLLOW_8); 

                                    							newLeafNode(otherlv_22, grammarAccess.getBlockOperationAccess().getGaslimitKeyword_0_2_4_0_0());
                                    						
                                    this_OPENPARENTHESIS_23=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                                    							newLeafNode(this_OPENPARENTHESIS_23, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_4_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_4_0_2());
                                    						
                                    pushFollow(FOLLOW_10);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_25=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_25, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_4_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:591:6: otherlv_26= 'gaslimit'
                                    {
                                    otherlv_26=(Token)match(input,52,FOLLOW_2); 

                                    						newLeafNode(otherlv_26, grammarAccess.getBlockOperationAccess().getGaslimitKeyword_0_2_4_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 6 :
                            // InternalSM2.g:597:5: ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' )
                            {
                            // InternalSM2.g:597:5: ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' )
                            int alt16=2;
                            int LA16_0 = input.LA(1);

                            if ( (LA16_0==53) ) {
                                int LA16_1 = input.LA(2);

                                if ( (LA16_1==RULE_OPENPARENTHESIS) ) {
                                    alt16=1;
                                }
                                else if ( (LA16_1==EOF) ) {
                                    alt16=2;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 16, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 16, 0, input);

                                throw nvae;
                            }
                            switch (alt16) {
                                case 1 :
                                    // InternalSM2.g:598:6: (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:598:6: (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:599:7: otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_27=(Token)match(input,53,FOLLOW_8); 

                                    							newLeafNode(otherlv_27, grammarAccess.getBlockOperationAccess().getBlockhashKeyword_0_2_5_0_0());
                                    						
                                    this_OPENPARENTHESIS_28=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                                    							newLeafNode(this_OPENPARENTHESIS_28, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_5_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_5_0_2());
                                    						
                                    pushFollow(FOLLOW_10);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_30=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_30, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_5_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:620:6: otherlv_31= 'blockhash'
                                    {
                                    otherlv_31=(Token)match(input,53,FOLLOW_2); 

                                    						newLeafNode(otherlv_31, grammarAccess.getBlockOperationAccess().getBlockhashKeyword_0_2_5_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:628:3: (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:628:3: (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? )
                    // InternalSM2.g:629:4: otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )?
                    {
                    otherlv_32=(Token)match(input,54,FOLLOW_8); 

                    				newLeafNode(otherlv_32, grammarAccess.getBlockOperationAccess().getNowKeyword_1_0());
                    			
                    this_OPENPARENTHESIS_33=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                    				newLeafNode(this_OPENPARENTHESIS_33, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1());
                    			

                    				newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_1_2());
                    			
                    pushFollow(FOLLOW_10);
                    ruleExpression();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			
                    this_CLOSEPARENTHESIS_35=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                    				newLeafNode(this_CLOSEPARENTHESIS_35, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3());
                    			
                    // InternalSM2.g:648:4: (this_SEMICOLON_36= RULE_SEMICOLON )?
                    int alt18=2;
                    int LA18_0 = input.LA(1);

                    if ( (LA18_0==RULE_SEMICOLON) ) {
                        alt18=1;
                    }
                    switch (alt18) {
                        case 1 :
                            // InternalSM2.g:649:5: this_SEMICOLON_36= RULE_SEMICOLON
                            {
                            this_SEMICOLON_36=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_36, grammarAccess.getBlockOperationAccess().getSEMICOLONTerminalRuleCall_1_4());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBlockOperation"


    // $ANTLR start "entryRuleTxVariables"
    // InternalSM2.g:659:1: entryRuleTxVariables returns [EObject current=null] : iv_ruleTxVariables= ruleTxVariables EOF ;
    public final EObject entryRuleTxVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTxVariables = null;


        try {
            // InternalSM2.g:659:52: (iv_ruleTxVariables= ruleTxVariables EOF )
            // InternalSM2.g:660:2: iv_ruleTxVariables= ruleTxVariables EOF
            {
             newCompositeNode(grammarAccess.getTxVariablesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTxVariables=ruleTxVariables();

            state._fsp--;

             current =iv_ruleTxVariables; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTxVariables"


    // $ANTLR start "ruleTxVariables"
    // InternalSM2.g:666:1: ruleTxVariables returns [EObject current=null] : (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation ) ;
    public final EObject ruleTxVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_TxOperation_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:672:2: ( (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation ) )
            // InternalSM2.g:673:2: (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation )
            {
            // InternalSM2.g:673:2: (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation )
            // InternalSM2.g:674:3: otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation
            {
            otherlv_0=(Token)match(input,55,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getTxVariablesAccess().getTxKeyword_0());
            		

            			newCompositeNode(grammarAccess.getTxVariablesAccess().getTxOperationParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_TxOperation_1=ruleTxOperation();

            state._fsp--;


            			current = this_TxOperation_1;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTxVariables"


    // $ANTLR start "entryRuleTxOperation"
    // InternalSM2.g:690:1: entryRuleTxOperation returns [EObject current=null] : iv_ruleTxOperation= ruleTxOperation EOF ;
    public final EObject entryRuleTxOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTxOperation = null;


        try {
            // InternalSM2.g:690:52: (iv_ruleTxOperation= ruleTxOperation EOF )
            // InternalSM2.g:691:2: iv_ruleTxOperation= ruleTxOperation EOF
            {
             newCompositeNode(grammarAccess.getTxOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTxOperation=ruleTxOperation();

            state._fsp--;

             current =iv_ruleTxOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTxOperation"


    // $ANTLR start "ruleTxOperation"
    // InternalSM2.g:697:1: ruleTxOperation returns [EObject current=null] : (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? ) ;
    public final EObject ruleTxOperation() throws RecognitionException {
        EObject current = null;

        Token this_DOT_0=null;
        Token otherlv_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token this_OPENPARENTHESIS_7=null;
        Token this_CLOSEPARENTHESIS_9=null;
        Token otherlv_10=null;
        Token this_SEMICOLON_11=null;
        Token this_EOLINE_12=null;


        	enterRule();

        try {
            // InternalSM2.g:703:2: ( (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? ) )
            // InternalSM2.g:704:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? )
            {
            // InternalSM2.g:704:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? )
            // InternalSM2.g:705:3: this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )?
            {
            this_DOT_0=(Token)match(input,RULE_DOT,FOLLOW_15); 

            			newLeafNode(this_DOT_0, grammarAccess.getTxOperationAccess().getDOTTerminalRuleCall_0());
            		
            // InternalSM2.g:709:3: ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' )
            int alt21=3;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==56) ) {
                alt21=1;
            }
            else if ( (LA21_0==57) ) {
                int LA21_2 = input.LA(2);

                if ( (LA21_2==RULE_OPENPARENTHESIS) ) {
                    alt21=2;
                }
                else if ( (LA21_2==EOF||LA21_2==RULE_SEMICOLON) ) {
                    alt21=3;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 21, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }
            switch (alt21) {
                case 1 :
                    // InternalSM2.g:710:4: ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' )
                    {
                    // InternalSM2.g:710:4: ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' )
                    int alt20=2;
                    int LA20_0 = input.LA(1);

                    if ( (LA20_0==56) ) {
                        int LA20_1 = input.LA(2);

                        if ( (LA20_1==RULE_OPENPARENTHESIS) ) {
                            alt20=1;
                        }
                        else if ( (LA20_1==EOF||LA20_1==RULE_SEMICOLON) ) {
                            alt20=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 20, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 20, 0, input);

                        throw nvae;
                    }
                    switch (alt20) {
                        case 1 :
                            // InternalSM2.g:711:5: (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:711:5: (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:712:6: otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_1=(Token)match(input,56,FOLLOW_8); 

                            						newLeafNode(otherlv_1, grammarAccess.getTxOperationAccess().getGaspriceKeyword_1_0_0_0());
                            					
                            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getTxOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_0_0_1());
                            					

                            						newCompositeNode(grammarAccess.getTxOperationAccess().getExpressionParserRuleCall_1_0_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getTxOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:733:5: otherlv_5= 'gasprice'
                            {
                            otherlv_5=(Token)match(input,56,FOLLOW_11); 

                            					newLeafNode(otherlv_5, grammarAccess.getTxOperationAccess().getGaspriceKeyword_1_0_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:739:4: ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:739:4: ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:740:5: (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS
                    {
                    // InternalSM2.g:740:5: (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression )
                    // InternalSM2.g:741:6: otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression
                    {
                    otherlv_6=(Token)match(input,57,FOLLOW_8); 

                    						newLeafNode(otherlv_6, grammarAccess.getTxOperationAccess().getOriginKeyword_1_1_0_0());
                    					
                    this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                    						newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getTxOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1_0_1());
                    					

                    						newCompositeNode(grammarAccess.getTxOperationAccess().getExpressionParserRuleCall_1_1_0_2());
                    					
                    pushFollow(FOLLOW_10);
                    ruleExpression();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }

                    this_CLOSEPARENTHESIS_9=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                    					newLeafNode(this_CLOSEPARENTHESIS_9, grammarAccess.getTxOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_1());
                    				

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:763:4: otherlv_10= 'origin'
                    {
                    otherlv_10=(Token)match(input,57,FOLLOW_11); 

                    				newLeafNode(otherlv_10, grammarAccess.getTxOperationAccess().getOriginKeyword_1_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:768:3: (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==RULE_SEMICOLON) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalSM2.g:769:4: this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE
                    {
                    this_SEMICOLON_11=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

                    				newLeafNode(this_SEMICOLON_11, grammarAccess.getTxOperationAccess().getSEMICOLONTerminalRuleCall_2_0());
                    			
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_12, grammarAccess.getTxOperationAccess().getEOLINETerminalRuleCall_2_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTxOperation"


    // $ANTLR start "entryRuleThisVariables"
    // InternalSM2.g:782:1: entryRuleThisVariables returns [EObject current=null] : iv_ruleThisVariables= ruleThisVariables EOF ;
    public final EObject entryRuleThisVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleThisVariables = null;


        try {
            // InternalSM2.g:782:54: (iv_ruleThisVariables= ruleThisVariables EOF )
            // InternalSM2.g:783:2: iv_ruleThisVariables= ruleThisVariables EOF
            {
             newCompositeNode(grammarAccess.getThisVariablesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleThisVariables=ruleThisVariables();

            state._fsp--;

             current =iv_ruleThisVariables; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleThisVariables"


    // $ANTLR start "ruleThisVariables"
    // InternalSM2.g:789:1: ruleThisVariables returns [EObject current=null] : (otherlv_0= 'this' this_ThisOperation_1= ruleThisOperation ) ;
    public final EObject ruleThisVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_ThisOperation_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:795:2: ( (otherlv_0= 'this' this_ThisOperation_1= ruleThisOperation ) )
            // InternalSM2.g:796:2: (otherlv_0= 'this' this_ThisOperation_1= ruleThisOperation )
            {
            // InternalSM2.g:796:2: (otherlv_0= 'this' this_ThisOperation_1= ruleThisOperation )
            // InternalSM2.g:797:3: otherlv_0= 'this' this_ThisOperation_1= ruleThisOperation
            {
            otherlv_0=(Token)match(input,58,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getThisVariablesAccess().getThisKeyword_0());
            		

            			newCompositeNode(grammarAccess.getThisVariablesAccess().getThisOperationParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_ThisOperation_1=ruleThisOperation();

            state._fsp--;


            			current = this_ThisOperation_1;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleThisVariables"


    // $ANTLR start "entryRuleThisOperation"
    // InternalSM2.g:813:1: entryRuleThisOperation returns [EObject current=null] : iv_ruleThisOperation= ruleThisOperation EOF ;
    public final EObject entryRuleThisOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleThisOperation = null;


        try {
            // InternalSM2.g:813:54: (iv_ruleThisOperation= ruleThisOperation EOF )
            // InternalSM2.g:814:2: iv_ruleThisOperation= ruleThisOperation EOF
            {
             newCompositeNode(grammarAccess.getThisOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleThisOperation=ruleThisOperation();

            state._fsp--;

             current =iv_ruleThisOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleThisOperation"


    // $ANTLR start "ruleThisOperation"
    // InternalSM2.g:820:1: ruleThisOperation returns [EObject current=null] : (this_DOT_0= RULE_DOT otherlv_1= 'balance' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject ruleThisOperation() throws RecognitionException {
        EObject current = null;

        Token this_DOT_0=null;
        Token otherlv_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;


        	enterRule();

        try {
            // InternalSM2.g:826:2: ( (this_DOT_0= RULE_DOT otherlv_1= 'balance' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:827:2: (this_DOT_0= RULE_DOT otherlv_1= 'balance' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:827:2: (this_DOT_0= RULE_DOT otherlv_1= 'balance' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:828:3: this_DOT_0= RULE_DOT otherlv_1= 'balance' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE )?
            {
            this_DOT_0=(Token)match(input,RULE_DOT,FOLLOW_16); 

            			newLeafNode(this_DOT_0, grammarAccess.getThisOperationAccess().getDOTTerminalRuleCall_0());
            		
            otherlv_1=(Token)match(input,59,FOLLOW_8); 

            			newLeafNode(otherlv_1, grammarAccess.getThisOperationAccess().getBalanceKeyword_1());
            		
            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getThisOperationAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		

            			newCompositeNode(grammarAccess.getThisOperationAccess().getExpressionParserRuleCall_3());
            		
            pushFollow(FOLLOW_10);
            ruleExpression();

            state._fsp--;


            			afterParserOrEnumRuleCall();
            		
            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

            			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getThisOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
            		
            // InternalSM2.g:851:3: (this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==RULE_SEMICOLON) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalSM2.g:852:4: this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE
                    {
                    this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

                    				newLeafNode(this_SEMICOLON_5, grammarAccess.getThisOperationAccess().getSEMICOLONTerminalRuleCall_5_0());
                    			
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_6, grammarAccess.getThisOperationAccess().getEOLINETerminalRuleCall_5_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleThisOperation"


    // $ANTLR start "entryRuleContract"
    // InternalSM2.g:865:1: entryRuleContract returns [EObject current=null] : iv_ruleContract= ruleContract EOF ;
    public final EObject entryRuleContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleContract = null;


        try {
            // InternalSM2.g:865:49: (iv_ruleContract= ruleContract EOF )
            // InternalSM2.g:866:2: iv_ruleContract= ruleContract EOF
            {
             newCompositeNode(grammarAccess.getContractRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleContract=ruleContract();

            state._fsp--;

             current =iv_ruleContract; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleContract"


    // $ANTLR start "ruleContract"
    // InternalSM2.g:872:1: ruleContract returns [EObject current=null] : (otherlv_0= 'contract' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY ) ;
    public final EObject ruleContract() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token this_OPENKEY_4=null;
        Token this_EOLINE_5=null;
        Token this_CLOSEKEY_11=null;
        EObject lv_constructor_6_0 = null;

        EObject lv_comments_7_0 = null;

        EObject lv_attributes_8_0 = null;

        EObject lv_modifier_9_0 = null;

        EObject lv_clauses_10_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:878:2: ( (otherlv_0= 'contract' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY ) )
            // InternalSM2.g:879:2: (otherlv_0= 'contract' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY )
            {
            // InternalSM2.g:879:2: (otherlv_0= 'contract' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY )
            // InternalSM2.g:880:3: otherlv_0= 'contract' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,60,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getContractAccess().getContractKeyword_0());
            		
            // InternalSM2.g:884:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSM2.g:885:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSM2.g:885:4: (lv_name_1_0= RULE_ID )
            // InternalSM2.g:886:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_18); 

            					newLeafNode(lv_name_1_0, grammarAccess.getContractAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getContractRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:902:3: (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==61) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalSM2.g:903:4: otherlv_2= 'is' ( (otherlv_3= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,61,FOLLOW_17); 

                    				newLeafNode(otherlv_2, grammarAccess.getContractAccess().getIsKeyword_2_0());
                    			
                    // InternalSM2.g:907:4: ( (otherlv_3= RULE_ID ) )
                    // InternalSM2.g:908:5: (otherlv_3= RULE_ID )
                    {
                    // InternalSM2.g:908:5: (otherlv_3= RULE_ID )
                    // InternalSM2.g:909:6: otherlv_3= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getContractRule());
                    						}
                    					
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_19); 

                    						newLeafNode(otherlv_3, grammarAccess.getContractAccess().getNameContractFatherContractCrossReference_2_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            this_OPENKEY_4=(Token)match(input,RULE_OPENKEY,FOLLOW_20); 

            			newLeafNode(this_OPENKEY_4, grammarAccess.getContractAccess().getOPENKEYTerminalRuleCall_3());
            		
            // InternalSM2.g:925:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==RULE_EOLINE) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalSM2.g:926:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_20); 

                    				newLeafNode(this_EOLINE_5, grammarAccess.getContractAccess().getEOLINETerminalRuleCall_4());
                    			

                    }
                    break;

            }

            // InternalSM2.g:931:3: ( (lv_constructor_6_0= ruleConstructor ) )
            // InternalSM2.g:932:4: (lv_constructor_6_0= ruleConstructor )
            {
            // InternalSM2.g:932:4: (lv_constructor_6_0= ruleConstructor )
            // InternalSM2.g:933:5: lv_constructor_6_0= ruleConstructor
            {

            					newCompositeNode(grammarAccess.getContractAccess().getConstructorConstructorParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_21);
            lv_constructor_6_0=ruleConstructor();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getContractRule());
            					}
            					add(
            						current,
            						"constructor",
            						lv_constructor_6_0,
            						"org.xtext.SM2.Constructor");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:950:3: ( (lv_comments_7_0= ruleComment ) )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( ((LA26_0>=155 && LA26_0<=156)) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalSM2.g:951:4: (lv_comments_7_0= ruleComment )
            	    {
            	    // InternalSM2.g:951:4: (lv_comments_7_0= ruleComment )
            	    // InternalSM2.g:952:5: lv_comments_7_0= ruleComment
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getCommentsCommentParserRuleCall_6_0());
            	    				
            	    pushFollow(FOLLOW_21);
            	    lv_comments_7_0=ruleComment();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"comments",
            	    						lv_comments_7_0,
            	    						"org.xtext.SM2.Comment");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

            // InternalSM2.g:969:3: ( (lv_attributes_8_0= ruleAttributes ) )*
            loop27:
            do {
                int alt27=2;
                int LA27_0 = input.LA(1);

                if ( (LA27_0==RULE_ID||LA27_0==75||(LA27_0>=77 && LA27_0<=78)||LA27_0==82||LA27_0==86||(LA27_0>=89 && LA27_0<=106)) ) {
                    alt27=1;
                }


                switch (alt27) {
            	case 1 :
            	    // InternalSM2.g:970:4: (lv_attributes_8_0= ruleAttributes )
            	    {
            	    // InternalSM2.g:970:4: (lv_attributes_8_0= ruleAttributes )
            	    // InternalSM2.g:971:5: lv_attributes_8_0= ruleAttributes
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getAttributesAttributesParserRuleCall_7_0());
            	    				
            	    pushFollow(FOLLOW_22);
            	    lv_attributes_8_0=ruleAttributes();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"attributes",
            	    						lv_attributes_8_0,
            	    						"org.xtext.SM2.Attributes");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop27;
                }
            } while (true);

            // InternalSM2.g:988:3: ( (lv_modifier_9_0= ruleModifier ) )*
            loop28:
            do {
                int alt28=2;
                int LA28_0 = input.LA(1);

                if ( (LA28_0==73) ) {
                    alt28=1;
                }


                switch (alt28) {
            	case 1 :
            	    // InternalSM2.g:989:4: (lv_modifier_9_0= ruleModifier )
            	    {
            	    // InternalSM2.g:989:4: (lv_modifier_9_0= ruleModifier )
            	    // InternalSM2.g:990:5: lv_modifier_9_0= ruleModifier
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getModifierModifierParserRuleCall_8_0());
            	    				
            	    pushFollow(FOLLOW_23);
            	    lv_modifier_9_0=ruleModifier();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"modifier",
            	    						lv_modifier_9_0,
            	    						"org.xtext.SM2.Modifier");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop28;
                }
            } while (true);

            // InternalSM2.g:1007:3: ( (lv_clauses_10_0= ruleClause ) )*
            loop29:
            do {
                int alt29=2;
                int LA29_0 = input.LA(1);

                if ( (LA29_0==150) ) {
                    alt29=1;
                }


                switch (alt29) {
            	case 1 :
            	    // InternalSM2.g:1008:4: (lv_clauses_10_0= ruleClause )
            	    {
            	    // InternalSM2.g:1008:4: (lv_clauses_10_0= ruleClause )
            	    // InternalSM2.g:1009:5: lv_clauses_10_0= ruleClause
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getClausesClauseParserRuleCall_9_0());
            	    				
            	    pushFollow(FOLLOW_24);
            	    lv_clauses_10_0=ruleClause();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"clauses",
            	    						lv_clauses_10_0,
            	    						"org.xtext.SM2.Clause");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop29;
                }
            } while (true);

            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); 

            			newLeafNode(this_CLOSEKEY_11, grammarAccess.getContractAccess().getCLOSEKEYTerminalRuleCall_10());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:1034:1: entryRuleVersion returns [EObject current=null] : iv_ruleVersion= ruleVersion EOF ;
    public final EObject entryRuleVersion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVersion = null;


        try {
            // InternalSM2.g:1034:48: (iv_ruleVersion= ruleVersion EOF )
            // InternalSM2.g:1035:2: iv_ruleVersion= ruleVersion EOF
            {
             newCompositeNode(grammarAccess.getVersionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVersion=ruleVersion();

            state._fsp--;

             current =iv_ruleVersion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:1041:1: ruleVersion returns [EObject current=null] : (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) (this_SEMICOLON_8= RULE_SEMICOLON | ( (otherlv_9= RULE_ID ) ) ) this_EOLINE_10= RULE_EOLINE ) ;
    public final EObject ruleVersion() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_symbol_2_1=null;
        Token lv_symbol_2_2=null;
        Token lv_symbol_2_3=null;
        Token lv_numberVersion_3_0=null;
        Token this_DOT_4=null;
        Token lv_numberVersion2_5_0=null;
        Token this_DOT_6=null;
        Token lv_numberVersion3_7_0=null;
        Token this_SEMICOLON_8=null;
        Token otherlv_9=null;
        Token this_EOLINE_10=null;


        	enterRule();

        try {
            // InternalSM2.g:1047:2: ( (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) (this_SEMICOLON_8= RULE_SEMICOLON | ( (otherlv_9= RULE_ID ) ) ) this_EOLINE_10= RULE_EOLINE ) )
            // InternalSM2.g:1048:2: (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) (this_SEMICOLON_8= RULE_SEMICOLON | ( (otherlv_9= RULE_ID ) ) ) this_EOLINE_10= RULE_EOLINE )
            {
            // InternalSM2.g:1048:2: (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) (this_SEMICOLON_8= RULE_SEMICOLON | ( (otherlv_9= RULE_ID ) ) ) this_EOLINE_10= RULE_EOLINE )
            // InternalSM2.g:1049:3: otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) (this_SEMICOLON_8= RULE_SEMICOLON | ( (otherlv_9= RULE_ID ) ) ) this_EOLINE_10= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,62,FOLLOW_25); 

            			newLeafNode(otherlv_0, grammarAccess.getVersionAccess().getPragmaKeyword_0());
            		
            otherlv_1=(Token)match(input,63,FOLLOW_26); 

            			newLeafNode(otherlv_1, grammarAccess.getVersionAccess().getSolidityKeyword_1());
            		
            // InternalSM2.g:1057:3: ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) )
            // InternalSM2.g:1058:4: ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) )
            {
            // InternalSM2.g:1058:4: ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) )
            // InternalSM2.g:1059:5: (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' )
            {
            // InternalSM2.g:1059:5: (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' )
            int alt30=3;
            switch ( input.LA(1) ) {
            case 64:
                {
                alt30=1;
                }
                break;
            case 65:
                {
                alt30=2;
                }
                break;
            case 66:
                {
                alt30=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 30, 0, input);

                throw nvae;
            }

            switch (alt30) {
                case 1 :
                    // InternalSM2.g:1060:6: lv_symbol_2_1= '^'
                    {
                    lv_symbol_2_1=(Token)match(input,64,FOLLOW_27); 

                    						newLeafNode(lv_symbol_2_1, grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_2_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_2_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1071:6: lv_symbol_2_2= '>'
                    {
                    lv_symbol_2_2=(Token)match(input,65,FOLLOW_27); 

                    						newLeafNode(lv_symbol_2_2, grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_2_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_2_2, null);
                    					

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1082:6: lv_symbol_2_3= '>='
                    {
                    lv_symbol_2_3=(Token)match(input,66,FOLLOW_27); 

                    						newLeafNode(lv_symbol_2_3, grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_2_0_2());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_2_3, null);
                    					

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:1095:3: ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) )
            // InternalSM2.g:1096:4: (lv_numberVersion_3_0= RULE_NUMVERSION1 )
            {
            // InternalSM2.g:1096:4: (lv_numberVersion_3_0= RULE_NUMVERSION1 )
            // InternalSM2.g:1097:5: lv_numberVersion_3_0= RULE_NUMVERSION1
            {
            lv_numberVersion_3_0=(Token)match(input,RULE_NUMVERSION1,FOLLOW_6); 

            					newLeafNode(lv_numberVersion_3_0, grammarAccess.getVersionAccess().getNumberVersionNUMVERSION1TerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVersionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"numberVersion",
            						lv_numberVersion_3_0,
            						"org.xtext.SM2.NUMVERSION1");
            				

            }


            }

            this_DOT_4=(Token)match(input,RULE_DOT,FOLLOW_28); 

            			newLeafNode(this_DOT_4, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_4());
            		
            // InternalSM2.g:1117:3: ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) )
            // InternalSM2.g:1118:4: (lv_numberVersion2_5_0= RULE_NUMVERSION2 )
            {
            // InternalSM2.g:1118:4: (lv_numberVersion2_5_0= RULE_NUMVERSION2 )
            // InternalSM2.g:1119:5: lv_numberVersion2_5_0= RULE_NUMVERSION2
            {
            lv_numberVersion2_5_0=(Token)match(input,RULE_NUMVERSION2,FOLLOW_6); 

            					newLeafNode(lv_numberVersion2_5_0, grammarAccess.getVersionAccess().getNumberVersion2NUMVERSION2TerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVersionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"numberVersion2",
            						lv_numberVersion2_5_0,
            						"org.xtext.SM2.NUMVERSION2");
            				

            }


            }

            this_DOT_6=(Token)match(input,RULE_DOT,FOLLOW_29); 

            			newLeafNode(this_DOT_6, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_6());
            		
            // InternalSM2.g:1139:3: ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) )
            // InternalSM2.g:1140:4: (lv_numberVersion3_7_0= RULE_NUMVERSION3 )
            {
            // InternalSM2.g:1140:4: (lv_numberVersion3_7_0= RULE_NUMVERSION3 )
            // InternalSM2.g:1141:5: lv_numberVersion3_7_0= RULE_NUMVERSION3
            {
            lv_numberVersion3_7_0=(Token)match(input,RULE_NUMVERSION3,FOLLOW_30); 

            					newLeafNode(lv_numberVersion3_7_0, grammarAccess.getVersionAccess().getNumberVersion3NUMVERSION3TerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVersionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"numberVersion3",
            						lv_numberVersion3_7_0,
            						"org.xtext.SM2.NUMVERSION3");
            				

            }


            }

            // InternalSM2.g:1157:3: (this_SEMICOLON_8= RULE_SEMICOLON | ( (otherlv_9= RULE_ID ) ) )
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==RULE_SEMICOLON) ) {
                alt31=1;
            }
            else if ( (LA31_0==RULE_ID) ) {
                alt31=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 31, 0, input);

                throw nvae;
            }
            switch (alt31) {
                case 1 :
                    // InternalSM2.g:1158:4: this_SEMICOLON_8= RULE_SEMICOLON
                    {
                    this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

                    				newLeafNode(this_SEMICOLON_8, grammarAccess.getVersionAccess().getSEMICOLONTerminalRuleCall_8_0());
                    			

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1163:4: ( (otherlv_9= RULE_ID ) )
                    {
                    // InternalSM2.g:1163:4: ( (otherlv_9= RULE_ID ) )
                    // InternalSM2.g:1164:5: (otherlv_9= RULE_ID )
                    {
                    // InternalSM2.g:1164:5: (otherlv_9= RULE_ID )
                    // InternalSM2.g:1165:6: otherlv_9= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    					
                    otherlv_9=(Token)match(input,RULE_ID,FOLLOW_12); 

                    						newLeafNode(otherlv_9, grammarAccess.getVersionAccess().getOptionalversionVersionCrossReference_8_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_10, grammarAccess.getVersionAccess().getEOLINETerminalRuleCall_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleConstructor"
    // InternalSM2.g:1185:1: entryRuleConstructor returns [EObject current=null] : iv_ruleConstructor= ruleConstructor EOF ;
    public final EObject entryRuleConstructor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConstructor = null;


        try {
            // InternalSM2.g:1185:52: (iv_ruleConstructor= ruleConstructor EOF )
            // InternalSM2.g:1186:2: iv_ruleConstructor= ruleConstructor EOF
            {
             newCompositeNode(grammarAccess.getConstructorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConstructor=ruleConstructor();

            state._fsp--;

             current =iv_ruleConstructor; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConstructor"


    // $ANTLR start "ruleConstructor"
    // InternalSM2.g:1192:1: ruleConstructor returns [EObject current=null] : (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS ( ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) ) ) this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY ) ;
    public final EObject ruleConstructor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token lv_type_4_1=null;
        Token lv_type_4_2=null;
        Token this_OPENKEY_5=null;
        Token this_CLOSEKEY_7=null;
        EObject lv_inputParams_2_0 = null;

        EObject lv_Attributes_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1198:2: ( (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS ( ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) ) ) this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY ) )
            // InternalSM2.g:1199:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS ( ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) ) ) this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY )
            {
            // InternalSM2.g:1199:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS ( ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) ) ) this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY )
            // InternalSM2.g:1200:3: otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS ( ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) ) ) this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,67,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getConstructorAccess().getConstructorKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_31); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConstructorAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:1208:3: ( (lv_inputParams_2_0= ruleInputParam ) )*
            loop32:
            do {
                int alt32=2;
                int LA32_0 = input.LA(1);

                if ( (LA32_0==78||LA32_0==80||(LA32_0>=83 && LA32_0<=88)) ) {
                    alt32=1;
                }


                switch (alt32) {
            	case 1 :
            	    // InternalSM2.g:1209:4: (lv_inputParams_2_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1209:4: (lv_inputParams_2_0= ruleInputParam )
            	    // InternalSM2.g:1210:5: lv_inputParams_2_0= ruleInputParam
            	    {

            	    					newCompositeNode(grammarAccess.getConstructorAccess().getInputParamsInputParamParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_31);
            	    lv_inputParams_2_0=ruleInputParam();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConstructorRule());
            	    					}
            	    					add(
            	    						current,
            	    						"inputParams",
            	    						lv_inputParams_2_0,
            	    						"org.xtext.SM2.InputParam");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop32;
                }
            } while (true);

            this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_32); 

            			newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getConstructorAccess().getCLOSEPARENTHESISTerminalRuleCall_3());
            		
            // InternalSM2.g:1231:3: ( ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) ) )
            // InternalSM2.g:1232:4: ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) )
            {
            // InternalSM2.g:1232:4: ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) )
            // InternalSM2.g:1233:5: (lv_type_4_1= 'public' | lv_type_4_2= 'internal' )
            {
            // InternalSM2.g:1233:5: (lv_type_4_1= 'public' | lv_type_4_2= 'internal' )
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==68) ) {
                alt33=1;
            }
            else if ( (LA33_0==69) ) {
                alt33=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 33, 0, input);

                throw nvae;
            }
            switch (alt33) {
                case 1 :
                    // InternalSM2.g:1234:6: lv_type_4_1= 'public'
                    {
                    lv_type_4_1=(Token)match(input,68,FOLLOW_19); 

                    						newLeafNode(lv_type_4_1, grammarAccess.getConstructorAccess().getTypePublicKeyword_4_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getConstructorRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_4_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1245:6: lv_type_4_2= 'internal'
                    {
                    lv_type_4_2=(Token)match(input,69,FOLLOW_19); 

                    						newLeafNode(lv_type_4_2, grammarAccess.getConstructorAccess().getTypeInternalKeyword_4_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getConstructorRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_4_2, null);
                    					

                    }
                    break;

            }


            }


            }

            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_33); 

            			newLeafNode(this_OPENKEY_5, grammarAccess.getConstructorAccess().getOPENKEYTerminalRuleCall_5());
            		
            // InternalSM2.g:1262:3: ( (lv_Attributes_6_0= ruleAttributes ) )
            // InternalSM2.g:1263:4: (lv_Attributes_6_0= ruleAttributes )
            {
            // InternalSM2.g:1263:4: (lv_Attributes_6_0= ruleAttributes )
            // InternalSM2.g:1264:5: lv_Attributes_6_0= ruleAttributes
            {

            					newCompositeNode(grammarAccess.getConstructorAccess().getAttributesAttributesParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_34);
            lv_Attributes_6_0=ruleAttributes();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getConstructorRule());
            					}
            					add(
            						current,
            						"Attributes",
            						lv_Attributes_6_0,
            						"org.xtext.SM2.Attributes");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); 

            			newLeafNode(this_CLOSEKEY_7, grammarAccess.getConstructorAccess().getCLOSEKEYTerminalRuleCall_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConstructor"


    // $ANTLR start "entryRuleEvent"
    // InternalSM2.g:1289:1: entryRuleEvent returns [EObject current=null] : iv_ruleEvent= ruleEvent EOF ;
    public final EObject entryRuleEvent() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvent = null;


        try {
            // InternalSM2.g:1289:46: (iv_ruleEvent= ruleEvent EOF )
            // InternalSM2.g:1290:2: iv_ruleEvent= ruleEvent EOF
            {
             newCompositeNode(grammarAccess.getEventRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEvent=ruleEvent();

            state._fsp--;

             current =iv_ruleEvent; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalSM2.g:1296:1: ruleEvent returns [EObject current=null] : (otherlv_0= 'event' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( ( (lv_type_3_0= ruleBasicType ) ) ( ruleArray )? (otherlv_5= 'indexed' )? ( (lv_inputparam_6_0= ruleInputParam ) ) )* this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) ;
    public final EObject ruleEvent() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token otherlv_5=null;
        Token this_CLOSEPARENTHESIS_7=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Enumerator lv_type_3_0 = null;

        EObject lv_inputparam_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1302:2: ( (otherlv_0= 'event' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( ( (lv_type_3_0= ruleBasicType ) ) ( ruleArray )? (otherlv_5= 'indexed' )? ( (lv_inputparam_6_0= ruleInputParam ) ) )* this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) )
            // InternalSM2.g:1303:2: (otherlv_0= 'event' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( ( (lv_type_3_0= ruleBasicType ) ) ( ruleArray )? (otherlv_5= 'indexed' )? ( (lv_inputparam_6_0= ruleInputParam ) ) )* this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            {
            // InternalSM2.g:1303:2: (otherlv_0= 'event' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( ( (lv_type_3_0= ruleBasicType ) ) ( ruleArray )? (otherlv_5= 'indexed' )? ( (lv_inputparam_6_0= ruleInputParam ) ) )* this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            // InternalSM2.g:1304:3: otherlv_0= 'event' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( ( (lv_type_3_0= ruleBasicType ) ) ( ruleArray )? (otherlv_5= 'indexed' )? ( (lv_inputparam_6_0= ruleInputParam ) ) )* this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,70,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getEventAccess().getEventKeyword_0());
            		
            // InternalSM2.g:1308:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSM2.g:1309:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSM2.g:1309:4: (lv_name_1_0= RULE_ID )
            // InternalSM2.g:1310:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_8); 

            					newLeafNode(lv_name_1_0, grammarAccess.getEventAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEventRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_35); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		
            // InternalSM2.g:1330:3: ( ( (lv_type_3_0= ruleBasicType ) ) ( ruleArray )? (otherlv_5= 'indexed' )? ( (lv_inputparam_6_0= ruleInputParam ) ) )*
            loop36:
            do {
                int alt36=2;
                int LA36_0 = input.LA(1);

                if ( (LA36_0==78||LA36_0==80||(LA36_0>=83 && LA36_0<=88)||(LA36_0>=90 && LA36_0<=96)||LA36_0==100||LA36_0==106||(LA36_0>=130 && LA36_0<=134)||LA36_0==138||(LA36_0>=143 && LA36_0<=145)||LA36_0==180) ) {
                    alt36=1;
                }


                switch (alt36) {
            	case 1 :
            	    // InternalSM2.g:1331:4: ( (lv_type_3_0= ruleBasicType ) ) ( ruleArray )? (otherlv_5= 'indexed' )? ( (lv_inputparam_6_0= ruleInputParam ) )
            	    {
            	    // InternalSM2.g:1331:4: ( (lv_type_3_0= ruleBasicType ) )
            	    // InternalSM2.g:1332:5: (lv_type_3_0= ruleBasicType )
            	    {
            	    // InternalSM2.g:1332:5: (lv_type_3_0= ruleBasicType )
            	    // InternalSM2.g:1333:6: lv_type_3_0= ruleBasicType
            	    {

            	    						newCompositeNode(grammarAccess.getEventAccess().getTypeBasicTypeEnumRuleCall_3_0_0());
            	    					
            	    pushFollow(FOLLOW_36);
            	    lv_type_3_0=ruleBasicType();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getEventRule());
            	    						}
            	    						set(
            	    							current,
            	    							"type",
            	    							lv_type_3_0,
            	    							"org.xtext.SM2.BasicType");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }

            	    // InternalSM2.g:1350:4: ( ruleArray )?
            	    int alt34=2;
            	    int LA34_0 = input.LA(1);

            	    if ( ((LA34_0>=107 && LA34_0<=108)) ) {
            	        alt34=1;
            	    }
            	    switch (alt34) {
            	        case 1 :
            	            // InternalSM2.g:1351:5: ruleArray
            	            {

            	            					newCompositeNode(grammarAccess.getEventAccess().getArrayParserRuleCall_3_1());
            	            				
            	            pushFollow(FOLLOW_37);
            	            ruleArray();

            	            state._fsp--;


            	            					afterParserOrEnumRuleCall();
            	            				

            	            }
            	            break;

            	    }

            	    // InternalSM2.g:1359:4: (otherlv_5= 'indexed' )?
            	    int alt35=2;
            	    int LA35_0 = input.LA(1);

            	    if ( (LA35_0==71) ) {
            	        alt35=1;
            	    }
            	    switch (alt35) {
            	        case 1 :
            	            // InternalSM2.g:1360:5: otherlv_5= 'indexed'
            	            {
            	            otherlv_5=(Token)match(input,71,FOLLOW_38); 

            	            					newLeafNode(otherlv_5, grammarAccess.getEventAccess().getIndexedKeyword_3_2());
            	            				

            	            }
            	            break;

            	    }

            	    // InternalSM2.g:1365:4: ( (lv_inputparam_6_0= ruleInputParam ) )
            	    // InternalSM2.g:1366:5: (lv_inputparam_6_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1366:5: (lv_inputparam_6_0= ruleInputParam )
            	    // InternalSM2.g:1367:6: lv_inputparam_6_0= ruleInputParam
            	    {

            	    						newCompositeNode(grammarAccess.getEventAccess().getInputparamInputParamParserRuleCall_3_3_0());
            	    					
            	    pushFollow(FOLLOW_35);
            	    lv_inputparam_6_0=ruleInputParam();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getEventRule());
            	    						}
            	    						add(
            	    							current,
            	    							"inputparam",
            	    							lv_inputparam_6_0,
            	    							"org.xtext.SM2.InputParam");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop36;
                }
            } while (true);

            this_CLOSEPARENTHESIS_7=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_39); 

            			newLeafNode(this_CLOSEPARENTHESIS_7, grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
            		
            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5());
            		
            // InternalSM2.g:1393:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==RULE_EOLINE) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalSM2.g:1394:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_9, grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleImport"
    // InternalSM2.g:1403:1: entryRuleImport returns [String current=null] : iv_ruleImport= ruleImport EOF ;
    public final String entryRuleImport() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleImport = null;


        try {
            // InternalSM2.g:1403:46: (iv_ruleImport= ruleImport EOF )
            // InternalSM2.g:1404:2: iv_ruleImport= ruleImport EOF
            {
             newCompositeNode(grammarAccess.getImportRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleImport=ruleImport();

            state._fsp--;

             current =iv_ruleImport.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2.g:1410:1: ruleImport returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? ) ;
    public final AntlrDatatypeRuleToken ruleImport() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_STRING_1=null;
        Token this_SEMICOLON_2=null;
        Token this_EOLINE_3=null;


        	enterRule();

        try {
            // InternalSM2.g:1416:2: ( (kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? ) )
            // InternalSM2.g:1417:2: (kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? )
            {
            // InternalSM2.g:1417:2: (kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? )
            // InternalSM2.g:1418:3: kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )?
            {
            kw=(Token)match(input,72,FOLLOW_41); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getImportAccess().getImportKeyword_0());
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_39); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getImportAccess().getSTRINGTerminalRuleCall_1());
            		
            this_SEMICOLON_2=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			current.merge(this_SEMICOLON_2);
            		

            			newLeafNode(this_SEMICOLON_2, grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_2());
            		
            // InternalSM2.g:1437:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==RULE_EOLINE) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:1438:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				current.merge(this_EOLINE_3);
                    			

                    				newLeafNode(this_EOLINE_3, grammarAccess.getImportAccess().getEOLINETerminalRuleCall_3());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:1450:1: entryRuleAttributes returns [EObject current=null] : iv_ruleAttributes= ruleAttributes EOF ;
    public final EObject entryRuleAttributes() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttributes = null;


        try {
            // InternalSM2.g:1450:51: (iv_ruleAttributes= ruleAttributes EOF )
            // InternalSM2.g:1451:2: iv_ruleAttributes= ruleAttributes EOF
            {
             newCompositeNode(grammarAccess.getAttributesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAttributes=ruleAttributes();

            state._fsp--;

             current =iv_ruleAttributes; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:1457:1: ruleAttributes returns [EObject current=null] : this_DataType_0= ruleDataType ;
    public final EObject ruleAttributes() throws RecognitionException {
        EObject current = null;

        EObject this_DataType_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1463:2: (this_DataType_0= ruleDataType )
            // InternalSM2.g:1464:2: this_DataType_0= ruleDataType
            {

            		newCompositeNode(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall());
            	
            pushFollow(FOLLOW_2);
            this_DataType_0=ruleDataType();

            state._fsp--;


            		current = this_DataType_0;
            		afterParserOrEnumRuleCall();
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:1475:1: entryRuleModifier returns [EObject current=null] : iv_ruleModifier= ruleModifier EOF ;
    public final EObject entryRuleModifier() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModifier = null;


        try {
            // InternalSM2.g:1475:49: (iv_ruleModifier= ruleModifier EOF )
            // InternalSM2.g:1476:2: iv_ruleModifier= ruleModifier EOF
            {
             newCompositeNode(grammarAccess.getModifierRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModifier=ruleModifier();

            state._fsp--;

             current =iv_ruleModifier; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:1482:1: ruleModifier returns [EObject current=null] : (otherlv_0= 'modifier' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= ruleSyntaxExpression ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? ) ;
    public final EObject ruleModifier() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_EOLINE_6=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Token otherlv_10=null;
        Token this_CLOSEKEY_11=null;
        Token this_EOLINE_12=null;
        EObject lv_inputParams_3_0 = null;

        AntlrDatatypeRuleToken lv_expr_7_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1488:2: ( (otherlv_0= 'modifier' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= ruleSyntaxExpression ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? ) )
            // InternalSM2.g:1489:2: (otherlv_0= 'modifier' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= ruleSyntaxExpression ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? )
            {
            // InternalSM2.g:1489:2: (otherlv_0= 'modifier' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= ruleSyntaxExpression ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? )
            // InternalSM2.g:1490:3: otherlv_0= 'modifier' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= ruleSyntaxExpression ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,73,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getModifierAccess().getModifierKeyword_0());
            		
            // InternalSM2.g:1494:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSM2.g:1495:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSM2.g:1495:4: (lv_name_1_0= RULE_ID )
            // InternalSM2.g:1496:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_8); 

            					newLeafNode(lv_name_1_0, grammarAccess.getModifierAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getModifierRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_31); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		
            // InternalSM2.g:1516:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop39:
            do {
                int alt39=2;
                int LA39_0 = input.LA(1);

                if ( (LA39_0==78||LA39_0==80||(LA39_0>=83 && LA39_0<=88)) ) {
                    alt39=1;
                }


                switch (alt39) {
            	case 1 :
            	    // InternalSM2.g:1517:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1517:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:1518:5: lv_inputParams_3_0= ruleInputParam
            	    {

            	    					newCompositeNode(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_31);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModifierRule());
            	    					}
            	    					add(
            	    						current,
            	    						"inputParams",
            	    						lv_inputParams_3_0,
            	    						"org.xtext.SM2.InputParam");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop39;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_19); 

            			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
            		
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_42); 

            			newLeafNode(this_OPENKEY_5, grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5());
            		
            // InternalSM2.g:1543:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==RULE_EOLINE) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalSM2.g:1544:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_41); 

                    				newLeafNode(this_EOLINE_6, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }

            // InternalSM2.g:1549:3: ( (lv_expr_7_0= ruleSyntaxExpression ) )
            // InternalSM2.g:1550:4: (lv_expr_7_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:1550:4: (lv_expr_7_0= ruleSyntaxExpression )
            // InternalSM2.g:1551:5: lv_expr_7_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getModifierAccess().getExprSyntaxExpressionParserRuleCall_7_0());
            				
            pushFollow(FOLLOW_39);
            lv_expr_7_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getModifierRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_7_0,
            						"org.xtext.SM2.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_43); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8());
            		
            // InternalSM2.g:1572:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==RULE_EOLINE) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalSM2.g:1573:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_44); 

                    				newLeafNode(this_EOLINE_9, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9());
                    			

                    }
                    break;

            }

            otherlv_10=(Token)match(input,74,FOLLOW_34); 

            			newLeafNode(otherlv_10, grammarAccess.getModifierAccess().get_Keyword_10());
            		
            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_40); 

            			newLeafNode(this_CLOSEKEY_11, grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11());
            		
            // InternalSM2.g:1586:3: (this_EOLINE_12= RULE_EOLINE )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==RULE_EOLINE) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalSM2.g:1587:4: this_EOLINE_12= RULE_EOLINE
                    {
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_12, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:1596:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalSM2.g:1596:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalSM2.g:1597:2: iv_ruleDataType= ruleDataType EOF
            {
             newCompositeNode(grammarAccess.getDataTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;

             current =iv_ruleDataType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:1603:1: ruleDataType returns [EObject current=null] : (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID | ruleTypeAddress | ruleTypeBytes ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        Token this_ID_2=null;
        EObject this_CompositeType_0 = null;

        EObject this_Enum_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1609:2: ( (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID | ruleTypeAddress | ruleTypeBytes ) )
            // InternalSM2.g:1610:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID | ruleTypeAddress | ruleTypeBytes )
            {
            // InternalSM2.g:1610:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID | ruleTypeAddress | ruleTypeBytes )
            int alt43=5;
            switch ( input.LA(1) ) {
            case 75:
            case 77:
                {
                alt43=1;
                }
                break;
            case 82:
                {
                alt43=2;
                }
                break;
            case RULE_ID:
                {
                alt43=3;
                }
                break;
            case 78:
            case 86:
                {
                alt43=4;
                }
                break;
            case 89:
            case 90:
            case 91:
            case 92:
            case 93:
            case 94:
            case 95:
            case 96:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:
            case 103:
            case 104:
            case 105:
            case 106:
                {
                alt43=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 43, 0, input);

                throw nvae;
            }

            switch (alt43) {
                case 1 :
                    // InternalSM2.g:1611:3: this_CompositeType_0= ruleCompositeType
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_CompositeType_0=ruleCompositeType();

                    state._fsp--;


                    			current = this_CompositeType_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1620:3: this_Enum_1= ruleEnum
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Enum_1=ruleEnum();

                    state._fsp--;


                    			current = this_Enum_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1629:3: this_ID_2= RULE_ID
                    {
                    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			newLeafNode(this_ID_2, grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:1634:3: ruleTypeAddress
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getTypeAddressParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    ruleTypeAddress();

                    state._fsp--;


                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:1642:3: ruleTypeBytes
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getTypeBytesParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    ruleTypeBytes();

                    state._fsp--;


                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2.g:1653:1: entryRuleCompositeType returns [EObject current=null] : iv_ruleCompositeType= ruleCompositeType EOF ;
    public final EObject entryRuleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompositeType = null;


        try {
            // InternalSM2.g:1653:54: (iv_ruleCompositeType= ruleCompositeType EOF )
            // InternalSM2.g:1654:2: iv_ruleCompositeType= ruleCompositeType EOF
            {
             newCompositeNode(grammarAccess.getCompositeTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCompositeType=ruleCompositeType();

            state._fsp--;

             current =iv_ruleCompositeType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2.g:1660:1: ruleCompositeType returns [EObject current=null] : (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) ;
    public final EObject ruleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject this_Mapping_0 = null;

        EObject this_Struct_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1666:2: ( (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) )
            // InternalSM2.g:1667:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            {
            // InternalSM2.g:1667:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==75) ) {
                alt44=1;
            }
            else if ( (LA44_0==77) ) {
                alt44=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 44, 0, input);

                throw nvae;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:1668:3: this_Mapping_0= ruleMapping
                    {

                    			newCompositeNode(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Mapping_0=ruleMapping();

                    state._fsp--;


                    			current = this_Mapping_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1677:3: this_Struct_1= ruleStruct
                    {

                    			newCompositeNode(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Struct_1=ruleStruct();

                    state._fsp--;


                    			current = this_Struct_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:1689:1: entryRuleMapping returns [EObject current=null] : iv_ruleMapping= ruleMapping EOF ;
    public final EObject entryRuleMapping() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMapping = null;


        try {
            // InternalSM2.g:1689:48: (iv_ruleMapping= ruleMapping EOF )
            // InternalSM2.g:1690:2: iv_ruleMapping= ruleMapping EOF
            {
             newCompositeNode(grammarAccess.getMappingRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMapping=ruleMapping();

            state._fsp--;

             current =iv_ruleMapping; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:1696:1: ruleMapping returns [EObject current=null] : (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_name_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON ) ;
    public final EObject ruleMapping() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_3=null;
        Token lv_expr_4_0=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token lv_name_7_0=null;
        Token this_SEMICOLON_8=null;
        EObject lv_type_2_0 = null;

        Enumerator lv_visibility_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1702:2: ( (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_name_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON ) )
            // InternalSM2.g:1703:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_name_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON )
            {
            // InternalSM2.g:1703:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_name_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON )
            // InternalSM2.g:1704:3: otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_name_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON
            {
            otherlv_0=(Token)match(input,75,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getMappingAccess().getMappingKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_38); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:1712:3: ( (lv_type_2_0= ruleSingularType ) )
            // InternalSM2.g:1713:4: (lv_type_2_0= ruleSingularType )
            {
            // InternalSM2.g:1713:4: (lv_type_2_0= ruleSingularType )
            // InternalSM2.g:1714:5: lv_type_2_0= ruleSingularType
            {

            					newCompositeNode(grammarAccess.getMappingAccess().getTypeSingularTypeParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_45);
            lv_type_2_0=ruleSingularType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMappingRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_2_0,
            						"org.xtext.SM2.SingularType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,76,FOLLOW_41); 

            			newLeafNode(otherlv_3, grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3());
            		
            // InternalSM2.g:1735:3: ( (lv_expr_4_0= RULE_STRING ) )
            // InternalSM2.g:1736:4: (lv_expr_4_0= RULE_STRING )
            {
            // InternalSM2.g:1736:4: (lv_expr_4_0= RULE_STRING )
            // InternalSM2.g:1737:5: lv_expr_4_0= RULE_STRING
            {
            lv_expr_4_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_expr_4_0, grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMappingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_4_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_46); 

            			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
            		
            // InternalSM2.g:1757:3: ( (lv_visibility_6_0= ruleVisibility ) )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( ((LA45_0>=68 && LA45_0<=69)||LA45_0==162) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalSM2.g:1758:4: (lv_visibility_6_0= ruleVisibility )
                    {
                    // InternalSM2.g:1758:4: (lv_visibility_6_0= ruleVisibility )
                    // InternalSM2.g:1759:5: lv_visibility_6_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0());
                    				
                    pushFollow(FOLLOW_17);
                    lv_visibility_6_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getMappingRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_6_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:1776:3: ( (lv_name_7_0= RULE_ID ) )
            // InternalSM2.g:1777:4: (lv_name_7_0= RULE_ID )
            {
            // InternalSM2.g:1777:4: (lv_name_7_0= RULE_ID )
            // InternalSM2.g:1778:5: lv_name_7_0= RULE_ID
            {
            lv_name_7_0=(Token)match(input,RULE_ID,FOLLOW_39); 

            					newLeafNode(lv_name_7_0, grammarAccess.getMappingAccess().getNameIDTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMappingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_7_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:1802:1: entryRuleStruct returns [EObject current=null] : iv_ruleStruct= ruleStruct EOF ;
    public final EObject entryRuleStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStruct = null;


        try {
            // InternalSM2.g:1802:47: (iv_ruleStruct= ruleStruct EOF )
            // InternalSM2.g:1803:2: iv_ruleStruct= ruleStruct EOF
            {
             newCompositeNode(grammarAccess.getStructRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStruct=ruleStruct();

            state._fsp--;

             current =iv_ruleStruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:1809:1: ruleStruct returns [EObject current=null] : (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany ) ;
    public final EObject ruleStruct() throws RecognitionException {
        EObject current = null;

        EObject this_PersonalizedStruct_0 = null;

        EObject this_User_1 = null;

        EObject this_Company_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:1815:2: ( (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany ) )
            // InternalSM2.g:1816:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )
            {
            // InternalSM2.g:1816:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )
            int alt46=3;
            alt46 = dfa46.predict(input);
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:1817:3: this_PersonalizedStruct_0= rulePersonalizedStruct
                    {

                    			newCompositeNode(grammarAccess.getStructAccess().getPersonalizedStructParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_PersonalizedStruct_0=rulePersonalizedStruct();

                    state._fsp--;


                    			current = this_PersonalizedStruct_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1826:3: this_User_1= ruleUser
                    {

                    			newCompositeNode(grammarAccess.getStructAccess().getUserParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_User_1=ruleUser();

                    state._fsp--;


                    			current = this_User_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1835:3: this_Company_2= ruleCompany
                    {

                    			newCompositeNode(grammarAccess.getStructAccess().getCompanyParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_Company_2=ruleCompany();

                    state._fsp--;


                    			current = this_Company_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRulePersonalizedStruct"
    // InternalSM2.g:1847:1: entryRulePersonalizedStruct returns [EObject current=null] : iv_rulePersonalizedStruct= rulePersonalizedStruct EOF ;
    public final EObject entryRulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonalizedStruct = null;


        try {
            // InternalSM2.g:1847:59: (iv_rulePersonalizedStruct= rulePersonalizedStruct EOF )
            // InternalSM2.g:1848:2: iv_rulePersonalizedStruct= rulePersonalizedStruct EOF
            {
             newCompositeNode(grammarAccess.getPersonalizedStructRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePersonalizedStruct=rulePersonalizedStruct();

            state._fsp--;

             current =iv_rulePersonalizedStruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonalizedStruct"


    // $ANTLR start "rulePersonalizedStruct"
    // InternalSM2.g:1854:1: rulePersonalizedStruct returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject rulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_CLOSEKEY_5=null;
        Token this_EOLINE_6=null;
        EObject lv_properties_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1860:2: ( (otherlv_0= 'struct' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1861:2: (otherlv_0= 'struct' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1861:2: (otherlv_0= 'struct' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1862:3: otherlv_0= 'struct' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,77,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getPersonalizedStructAccess().getStructKeyword_0());
            		
            // InternalSM2.g:1866:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSM2.g:1867:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSM2.g:1867:4: (lv_name_1_0= RULE_ID )
            // InternalSM2.g:1868:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_19); 

            					newLeafNode(lv_name_1_0, grammarAccess.getPersonalizedStructAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPersonalizedStructRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_47); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2());
            		
            // InternalSM2.g:1888:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==RULE_EOLINE) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalSM2.g:1889:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_48); 

                    				newLeafNode(this_EOLINE_3, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3());
                    			

                    }
                    break;

            }

            // InternalSM2.g:1894:3: ( (lv_properties_4_0= ruleProperty ) )
            // InternalSM2.g:1895:4: (lv_properties_4_0= ruleProperty )
            {
            // InternalSM2.g:1895:4: (lv_properties_4_0= ruleProperty )
            // InternalSM2.g:1896:5: lv_properties_4_0= ruleProperty
            {

            					newCompositeNode(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_34);
            lv_properties_4_0=ruleProperty();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPersonalizedStructRule());
            					}
            					add(
            						current,
            						"properties",
            						lv_properties_4_0,
            						"org.xtext.SM2.Property");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_40); 

            			newLeafNode(this_CLOSEKEY_5, grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5());
            		
            // InternalSM2.g:1917:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==RULE_EOLINE) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalSM2.g:1918:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_6, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonalizedStruct"


    // $ANTLR start "entryRuleUser"
    // InternalSM2.g:1927:1: entryRuleUser returns [EObject current=null] : iv_ruleUser= ruleUser EOF ;
    public final EObject entryRuleUser() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUser = null;


        try {
            // InternalSM2.g:1927:45: (iv_ruleUser= ruleUser EOF )
            // InternalSM2.g:1928:2: iv_ruleUser= ruleUser EOF
            {
             newCompositeNode(grammarAccess.getUserRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleUser=ruleUser();

            state._fsp--;

             current =iv_ruleUser; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUser"


    // $ANTLR start "ruleUser"
    // InternalSM2.g:1934:1: ruleUser returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )? ) ;
    public final EObject ruleUser() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_1=null;
        Token lv_idAdress_5_2=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        Token otherlv_8=null;
        Token lv_nameUser_9_0=null;
        Token otherlv_10=null;
        Token this_STRING_11=null;
        Token this_SEMICOLON_12=null;
        Token this_EOLINE_13=null;
        Token otherlv_14=null;
        Token lv_surnameUser_15_0=null;
        Token otherlv_16=null;
        Token this_STRING_17=null;
        Token this_SEMICOLON_18=null;
        Token this_EOLINE_19=null;
        Token otherlv_20=null;
        Token lv_email_21_0=null;
        Token otherlv_22=null;
        Token this_EMAIL_23=null;
        Token this_SEMICOLON_24=null;
        Token this_EOLINE_25=null;
        Token this_CLOSEKEY_26=null;
        Token this_EOLINE_27=null;


        	enterRule();

        try {
            // InternalSM2.g:1940:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )? ) )
            // InternalSM2.g:1941:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )? )
            {
            // InternalSM2.g:1941:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )? )
            // InternalSM2.g:1942:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,77,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getUserAccess().getStructKeyword_0());
            		
            // InternalSM2.g:1946:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1947:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1947:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1948:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_19); 

            					newLeafNode(lv_nameStruct_1_0, grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameStruct",
            						lv_nameStruct_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_49); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2());
            		
            // InternalSM2.g:1968:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==RULE_EOLINE) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // InternalSM2.g:1969:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_50); 

                    				newLeafNode(this_EOLINE_3, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3());
                    			

                    }
                    break;

            }

            otherlv_4=(Token)match(input,78,FOLLOW_51); 

            			newLeafNode(otherlv_4, grammarAccess.getUserAccess().getAddressKeyword_4());
            		
            // InternalSM2.g:1978:3: ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) )
            // InternalSM2.g:1979:4: ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) )
            {
            // InternalSM2.g:1979:4: ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) )
            // InternalSM2.g:1980:5: (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' )
            {
            // InternalSM2.g:1980:5: (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' )
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==RULE_ID) ) {
                alt50=1;
            }
            else if ( (LA50_0==79) ) {
                alt50=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 50, 0, input);

                throw nvae;
            }
            switch (alt50) {
                case 1 :
                    // InternalSM2.g:1981:6: lv_idAdress_5_1= RULE_ID
                    {
                    lv_idAdress_5_1=(Token)match(input,RULE_ID,FOLLOW_39); 

                    						newLeafNode(lv_idAdress_5_1, grammarAccess.getUserAccess().getIdAdressIDTerminalRuleCall_5_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getUserRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"idAdress",
                    							lv_idAdress_5_1,
                    							"org.eclipse.xtext.common.Terminals.ID");
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1996:6: lv_idAdress_5_2= 'msg.sender'
                    {
                    lv_idAdress_5_2=(Token)match(input,79,FOLLOW_39); 

                    						newLeafNode(lv_idAdress_5_2, grammarAccess.getUserAccess().getIdAdressMsgSenderKeyword_5_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getUserRule());
                    						}
                    						setWithLastConsumed(current, "idAdress", lv_idAdress_5_2, null);
                    					

                    }
                    break;

            }


            }


            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_52); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:2013:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt51=2;
            int LA51_0 = input.LA(1);

            if ( (LA51_0==RULE_EOLINE) ) {
                alt51=1;
            }
            switch (alt51) {
                case 1 :
                    // InternalSM2.g:2014:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_53); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }

            otherlv_8=(Token)match(input,80,FOLLOW_41); 

            			newLeafNode(otherlv_8, grammarAccess.getUserAccess().getStringKeyword_8());
            		
            // InternalSM2.g:2023:3: ( (lv_nameUser_9_0= RULE_STRING ) )
            // InternalSM2.g:2024:4: (lv_nameUser_9_0= RULE_STRING )
            {
            // InternalSM2.g:2024:4: (lv_nameUser_9_0= RULE_STRING )
            // InternalSM2.g:2025:5: lv_nameUser_9_0= RULE_STRING
            {
            lv_nameUser_9_0=(Token)match(input,RULE_STRING,FOLLOW_54); 

            					newLeafNode(lv_nameUser_9_0, grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameUser",
            						lv_nameUser_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:2041:3: (otherlv_10= '=' this_STRING_11= RULE_STRING )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==81) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalSM2.g:2042:4: otherlv_10= '=' this_STRING_11= RULE_STRING
                    {
                    otherlv_10=(Token)match(input,81,FOLLOW_41); 

                    				newLeafNode(otherlv_10, grammarAccess.getUserAccess().getEqualsSignKeyword_10_0());
                    			
                    this_STRING_11=(Token)match(input,RULE_STRING,FOLLOW_39); 

                    				newLeafNode(this_STRING_11, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_10_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_12=(Token)match(input,RULE_SEMICOLON,FOLLOW_52); 

            			newLeafNode(this_SEMICOLON_12, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_11());
            		
            // InternalSM2.g:2055:3: (this_EOLINE_13= RULE_EOLINE )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==RULE_EOLINE) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // InternalSM2.g:2056:4: this_EOLINE_13= RULE_EOLINE
                    {
                    this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_53); 

                    				newLeafNode(this_EOLINE_13, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_12());
                    			

                    }
                    break;

            }

            otherlv_14=(Token)match(input,80,FOLLOW_41); 

            			newLeafNode(otherlv_14, grammarAccess.getUserAccess().getStringKeyword_13());
            		
            // InternalSM2.g:2065:3: ( (lv_surnameUser_15_0= RULE_STRING ) )
            // InternalSM2.g:2066:4: (lv_surnameUser_15_0= RULE_STRING )
            {
            // InternalSM2.g:2066:4: (lv_surnameUser_15_0= RULE_STRING )
            // InternalSM2.g:2067:5: lv_surnameUser_15_0= RULE_STRING
            {
            lv_surnameUser_15_0=(Token)match(input,RULE_STRING,FOLLOW_54); 

            					newLeafNode(lv_surnameUser_15_0, grammarAccess.getUserAccess().getSurnameUserSTRINGTerminalRuleCall_14_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"surnameUser",
            						lv_surnameUser_15_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:2083:3: (otherlv_16= '=' this_STRING_17= RULE_STRING )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==81) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalSM2.g:2084:4: otherlv_16= '=' this_STRING_17= RULE_STRING
                    {
                    otherlv_16=(Token)match(input,81,FOLLOW_41); 

                    				newLeafNode(otherlv_16, grammarAccess.getUserAccess().getEqualsSignKeyword_15_0());
                    			
                    this_STRING_17=(Token)match(input,RULE_STRING,FOLLOW_39); 

                    				newLeafNode(this_STRING_17, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_15_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_18=(Token)match(input,RULE_SEMICOLON,FOLLOW_52); 

            			newLeafNode(this_SEMICOLON_18, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_16());
            		
            // InternalSM2.g:2097:3: (this_EOLINE_19= RULE_EOLINE )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==RULE_EOLINE) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // InternalSM2.g:2098:4: this_EOLINE_19= RULE_EOLINE
                    {
                    this_EOLINE_19=(Token)match(input,RULE_EOLINE,FOLLOW_53); 

                    				newLeafNode(this_EOLINE_19, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_17());
                    			

                    }
                    break;

            }

            otherlv_20=(Token)match(input,80,FOLLOW_41); 

            			newLeafNode(otherlv_20, grammarAccess.getUserAccess().getStringKeyword_18());
            		
            // InternalSM2.g:2107:3: ( (lv_email_21_0= RULE_STRING ) )
            // InternalSM2.g:2108:4: (lv_email_21_0= RULE_STRING )
            {
            // InternalSM2.g:2108:4: (lv_email_21_0= RULE_STRING )
            // InternalSM2.g:2109:5: lv_email_21_0= RULE_STRING
            {
            lv_email_21_0=(Token)match(input,RULE_STRING,FOLLOW_54); 

            					newLeafNode(lv_email_21_0, grammarAccess.getUserAccess().getEmailSTRINGTerminalRuleCall_19_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"email",
            						lv_email_21_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:2125:3: (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==81) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalSM2.g:2126:4: otherlv_22= '=' this_EMAIL_23= RULE_EMAIL
                    {
                    otherlv_22=(Token)match(input,81,FOLLOW_55); 

                    				newLeafNode(otherlv_22, grammarAccess.getUserAccess().getEqualsSignKeyword_20_0());
                    			
                    this_EMAIL_23=(Token)match(input,RULE_EMAIL,FOLLOW_39); 

                    				newLeafNode(this_EMAIL_23, grammarAccess.getUserAccess().getEMAILTerminalRuleCall_20_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_24=(Token)match(input,RULE_SEMICOLON,FOLLOW_56); 

            			newLeafNode(this_SEMICOLON_24, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_21());
            		
            // InternalSM2.g:2139:3: (this_EOLINE_25= RULE_EOLINE )?
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==RULE_EOLINE) ) {
                alt57=1;
            }
            switch (alt57) {
                case 1 :
                    // InternalSM2.g:2140:4: this_EOLINE_25= RULE_EOLINE
                    {
                    this_EOLINE_25=(Token)match(input,RULE_EOLINE,FOLLOW_34); 

                    				newLeafNode(this_EOLINE_25, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_22());
                    			

                    }
                    break;

            }

            this_CLOSEKEY_26=(Token)match(input,RULE_CLOSEKEY,FOLLOW_40); 

            			newLeafNode(this_CLOSEKEY_26, grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_23());
            		
            // InternalSM2.g:2149:3: (this_EOLINE_27= RULE_EOLINE )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==RULE_EOLINE) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // InternalSM2.g:2150:4: this_EOLINE_27= RULE_EOLINE
                    {
                    this_EOLINE_27=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_27, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_24());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUser"


    // $ANTLR start "entryRuleCompany"
    // InternalSM2.g:2159:1: entryRuleCompany returns [EObject current=null] : iv_ruleCompany= ruleCompany EOF ;
    public final EObject entryRuleCompany() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompany = null;


        try {
            // InternalSM2.g:2159:48: (iv_ruleCompany= ruleCompany EOF )
            // InternalSM2.g:2160:2: iv_ruleCompany= ruleCompany EOF
            {
             newCompositeNode(grammarAccess.getCompanyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCompany=ruleCompany();

            state._fsp--;

             current =iv_ruleCompany; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompany"


    // $ANTLR start "ruleCompany"
    // InternalSM2.g:2166:1: ruleCompany returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? this_CLOSEKEY_32= RULE_CLOSEKEY (this_EOLINE_33= RULE_EOLINE )? ) ;
    public final EObject ruleCompany() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_1=null;
        Token lv_idAdress_5_2=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        Token otherlv_8=null;
        Token lv_nameCompany_9_0=null;
        Token otherlv_10=null;
        Token this_STRING_11=null;
        Token this_SEMICOLON_12=null;
        Token this_EOLINE_13=null;
        Token otherlv_14=null;
        Token lv_city_15_0=null;
        Token otherlv_16=null;
        Token this_STRING_17=null;
        Token this_SEMICOLON_18=null;
        Token this_EOLINE_19=null;
        Token otherlv_20=null;
        Token lv_email_21_0=null;
        Token otherlv_22=null;
        Token this_EMAIL_23=null;
        Token this_SEMICOLON_24=null;
        Token this_EOLINE_25=null;
        Token otherlv_26=null;
        Token lv_telf_27_0=null;
        Token otherlv_28=null;
        Token this_STRING_29=null;
        Token this_SEMICOLON_30=null;
        Token this_EOLINE_31=null;
        Token this_CLOSEKEY_32=null;
        Token this_EOLINE_33=null;


        	enterRule();

        try {
            // InternalSM2.g:2172:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? this_CLOSEKEY_32= RULE_CLOSEKEY (this_EOLINE_33= RULE_EOLINE )? ) )
            // InternalSM2.g:2173:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? this_CLOSEKEY_32= RULE_CLOSEKEY (this_EOLINE_33= RULE_EOLINE )? )
            {
            // InternalSM2.g:2173:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? this_CLOSEKEY_32= RULE_CLOSEKEY (this_EOLINE_33= RULE_EOLINE )? )
            // InternalSM2.g:2174:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? this_CLOSEKEY_32= RULE_CLOSEKEY (this_EOLINE_33= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,77,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getCompanyAccess().getStructKeyword_0());
            		
            // InternalSM2.g:2178:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:2179:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:2179:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:2180:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_19); 

            					newLeafNode(lv_nameStruct_1_0, grammarAccess.getCompanyAccess().getNameStructIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCompanyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameStruct",
            						lv_nameStruct_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_49); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getCompanyAccess().getOPENKEYTerminalRuleCall_2());
            		
            // InternalSM2.g:2200:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==RULE_EOLINE) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // InternalSM2.g:2201:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_50); 

                    				newLeafNode(this_EOLINE_3, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_3());
                    			

                    }
                    break;

            }

            otherlv_4=(Token)match(input,78,FOLLOW_51); 

            			newLeafNode(otherlv_4, grammarAccess.getCompanyAccess().getAddressKeyword_4());
            		
            // InternalSM2.g:2210:3: ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) )
            // InternalSM2.g:2211:4: ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) )
            {
            // InternalSM2.g:2211:4: ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) )
            // InternalSM2.g:2212:5: (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' )
            {
            // InternalSM2.g:2212:5: (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' )
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==RULE_ID) ) {
                alt60=1;
            }
            else if ( (LA60_0==79) ) {
                alt60=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 60, 0, input);

                throw nvae;
            }
            switch (alt60) {
                case 1 :
                    // InternalSM2.g:2213:6: lv_idAdress_5_1= RULE_ID
                    {
                    lv_idAdress_5_1=(Token)match(input,RULE_ID,FOLLOW_39); 

                    						newLeafNode(lv_idAdress_5_1, grammarAccess.getCompanyAccess().getIdAdressIDTerminalRuleCall_5_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCompanyRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"idAdress",
                    							lv_idAdress_5_1,
                    							"org.eclipse.xtext.common.Terminals.ID");
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2228:6: lv_idAdress_5_2= 'msg.sender'
                    {
                    lv_idAdress_5_2=(Token)match(input,79,FOLLOW_39); 

                    						newLeafNode(lv_idAdress_5_2, grammarAccess.getCompanyAccess().getIdAdressMsgSenderKeyword_5_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCompanyRule());
                    						}
                    						setWithLastConsumed(current, "idAdress", lv_idAdress_5_2, null);
                    					

                    }
                    break;

            }


            }


            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_52); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:2245:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt61=2;
            int LA61_0 = input.LA(1);

            if ( (LA61_0==RULE_EOLINE) ) {
                alt61=1;
            }
            switch (alt61) {
                case 1 :
                    // InternalSM2.g:2246:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_53); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }

            otherlv_8=(Token)match(input,80,FOLLOW_41); 

            			newLeafNode(otherlv_8, grammarAccess.getCompanyAccess().getStringKeyword_8());
            		
            // InternalSM2.g:2255:3: ( (lv_nameCompany_9_0= RULE_STRING ) )
            // InternalSM2.g:2256:4: (lv_nameCompany_9_0= RULE_STRING )
            {
            // InternalSM2.g:2256:4: (lv_nameCompany_9_0= RULE_STRING )
            // InternalSM2.g:2257:5: lv_nameCompany_9_0= RULE_STRING
            {
            lv_nameCompany_9_0=(Token)match(input,RULE_STRING,FOLLOW_54); 

            					newLeafNode(lv_nameCompany_9_0, grammarAccess.getCompanyAccess().getNameCompanySTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCompanyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameCompany",
            						lv_nameCompany_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:2273:3: (otherlv_10= '=' this_STRING_11= RULE_STRING )?
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==81) ) {
                alt62=1;
            }
            switch (alt62) {
                case 1 :
                    // InternalSM2.g:2274:4: otherlv_10= '=' this_STRING_11= RULE_STRING
                    {
                    otherlv_10=(Token)match(input,81,FOLLOW_41); 

                    				newLeafNode(otherlv_10, grammarAccess.getCompanyAccess().getEqualsSignKeyword_10_0());
                    			
                    this_STRING_11=(Token)match(input,RULE_STRING,FOLLOW_39); 

                    				newLeafNode(this_STRING_11, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_10_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_12=(Token)match(input,RULE_SEMICOLON,FOLLOW_52); 

            			newLeafNode(this_SEMICOLON_12, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_11());
            		
            // InternalSM2.g:2287:3: (this_EOLINE_13= RULE_EOLINE )?
            int alt63=2;
            int LA63_0 = input.LA(1);

            if ( (LA63_0==RULE_EOLINE) ) {
                alt63=1;
            }
            switch (alt63) {
                case 1 :
                    // InternalSM2.g:2288:4: this_EOLINE_13= RULE_EOLINE
                    {
                    this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_53); 

                    				newLeafNode(this_EOLINE_13, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_12());
                    			

                    }
                    break;

            }

            otherlv_14=(Token)match(input,80,FOLLOW_41); 

            			newLeafNode(otherlv_14, grammarAccess.getCompanyAccess().getStringKeyword_13());
            		
            // InternalSM2.g:2297:3: ( (lv_city_15_0= RULE_STRING ) )
            // InternalSM2.g:2298:4: (lv_city_15_0= RULE_STRING )
            {
            // InternalSM2.g:2298:4: (lv_city_15_0= RULE_STRING )
            // InternalSM2.g:2299:5: lv_city_15_0= RULE_STRING
            {
            lv_city_15_0=(Token)match(input,RULE_STRING,FOLLOW_54); 

            					newLeafNode(lv_city_15_0, grammarAccess.getCompanyAccess().getCitySTRINGTerminalRuleCall_14_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCompanyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"city",
            						lv_city_15_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:2315:3: (otherlv_16= '=' this_STRING_17= RULE_STRING )?
            int alt64=2;
            int LA64_0 = input.LA(1);

            if ( (LA64_0==81) ) {
                alt64=1;
            }
            switch (alt64) {
                case 1 :
                    // InternalSM2.g:2316:4: otherlv_16= '=' this_STRING_17= RULE_STRING
                    {
                    otherlv_16=(Token)match(input,81,FOLLOW_41); 

                    				newLeafNode(otherlv_16, grammarAccess.getCompanyAccess().getEqualsSignKeyword_15_0());
                    			
                    this_STRING_17=(Token)match(input,RULE_STRING,FOLLOW_39); 

                    				newLeafNode(this_STRING_17, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_15_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_18=(Token)match(input,RULE_SEMICOLON,FOLLOW_52); 

            			newLeafNode(this_SEMICOLON_18, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_16());
            		
            // InternalSM2.g:2329:3: (this_EOLINE_19= RULE_EOLINE )?
            int alt65=2;
            int LA65_0 = input.LA(1);

            if ( (LA65_0==RULE_EOLINE) ) {
                alt65=1;
            }
            switch (alt65) {
                case 1 :
                    // InternalSM2.g:2330:4: this_EOLINE_19= RULE_EOLINE
                    {
                    this_EOLINE_19=(Token)match(input,RULE_EOLINE,FOLLOW_53); 

                    				newLeafNode(this_EOLINE_19, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_17());
                    			

                    }
                    break;

            }

            otherlv_20=(Token)match(input,80,FOLLOW_41); 

            			newLeafNode(otherlv_20, grammarAccess.getCompanyAccess().getStringKeyword_18());
            		
            // InternalSM2.g:2339:3: ( (lv_email_21_0= RULE_STRING ) )
            // InternalSM2.g:2340:4: (lv_email_21_0= RULE_STRING )
            {
            // InternalSM2.g:2340:4: (lv_email_21_0= RULE_STRING )
            // InternalSM2.g:2341:5: lv_email_21_0= RULE_STRING
            {
            lv_email_21_0=(Token)match(input,RULE_STRING,FOLLOW_54); 

            					newLeafNode(lv_email_21_0, grammarAccess.getCompanyAccess().getEmailSTRINGTerminalRuleCall_19_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCompanyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"email",
            						lv_email_21_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:2357:3: (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )?
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==81) ) {
                alt66=1;
            }
            switch (alt66) {
                case 1 :
                    // InternalSM2.g:2358:4: otherlv_22= '=' this_EMAIL_23= RULE_EMAIL
                    {
                    otherlv_22=(Token)match(input,81,FOLLOW_55); 

                    				newLeafNode(otherlv_22, grammarAccess.getCompanyAccess().getEqualsSignKeyword_20_0());
                    			
                    this_EMAIL_23=(Token)match(input,RULE_EMAIL,FOLLOW_39); 

                    				newLeafNode(this_EMAIL_23, grammarAccess.getCompanyAccess().getEMAILTerminalRuleCall_20_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_24=(Token)match(input,RULE_SEMICOLON,FOLLOW_52); 

            			newLeafNode(this_SEMICOLON_24, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_21());
            		
            // InternalSM2.g:2371:3: (this_EOLINE_25= RULE_EOLINE )?
            int alt67=2;
            int LA67_0 = input.LA(1);

            if ( (LA67_0==RULE_EOLINE) ) {
                alt67=1;
            }
            switch (alt67) {
                case 1 :
                    // InternalSM2.g:2372:4: this_EOLINE_25= RULE_EOLINE
                    {
                    this_EOLINE_25=(Token)match(input,RULE_EOLINE,FOLLOW_53); 

                    				newLeafNode(this_EOLINE_25, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_22());
                    			

                    }
                    break;

            }

            otherlv_26=(Token)match(input,80,FOLLOW_41); 

            			newLeafNode(otherlv_26, grammarAccess.getCompanyAccess().getStringKeyword_23());
            		
            // InternalSM2.g:2381:3: ( (lv_telf_27_0= RULE_STRING ) )
            // InternalSM2.g:2382:4: (lv_telf_27_0= RULE_STRING )
            {
            // InternalSM2.g:2382:4: (lv_telf_27_0= RULE_STRING )
            // InternalSM2.g:2383:5: lv_telf_27_0= RULE_STRING
            {
            lv_telf_27_0=(Token)match(input,RULE_STRING,FOLLOW_54); 

            					newLeafNode(lv_telf_27_0, grammarAccess.getCompanyAccess().getTelfSTRINGTerminalRuleCall_24_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCompanyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"telf",
            						lv_telf_27_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:2399:3: (otherlv_28= '=' this_STRING_29= RULE_STRING )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==81) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // InternalSM2.g:2400:4: otherlv_28= '=' this_STRING_29= RULE_STRING
                    {
                    otherlv_28=(Token)match(input,81,FOLLOW_41); 

                    				newLeafNode(otherlv_28, grammarAccess.getCompanyAccess().getEqualsSignKeyword_25_0());
                    			
                    this_STRING_29=(Token)match(input,RULE_STRING,FOLLOW_39); 

                    				newLeafNode(this_STRING_29, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_25_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_30=(Token)match(input,RULE_SEMICOLON,FOLLOW_56); 

            			newLeafNode(this_SEMICOLON_30, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_26());
            		
            // InternalSM2.g:2413:3: (this_EOLINE_31= RULE_EOLINE )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==RULE_EOLINE) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // InternalSM2.g:2414:4: this_EOLINE_31= RULE_EOLINE
                    {
                    this_EOLINE_31=(Token)match(input,RULE_EOLINE,FOLLOW_34); 

                    				newLeafNode(this_EOLINE_31, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_27());
                    			

                    }
                    break;

            }

            this_CLOSEKEY_32=(Token)match(input,RULE_CLOSEKEY,FOLLOW_40); 

            			newLeafNode(this_CLOSEKEY_32, grammarAccess.getCompanyAccess().getCLOSEKEYTerminalRuleCall_28());
            		
            // InternalSM2.g:2423:3: (this_EOLINE_33= RULE_EOLINE )?
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( (LA70_0==RULE_EOLINE) ) {
                alt70=1;
            }
            switch (alt70) {
                case 1 :
                    // InternalSM2.g:2424:4: this_EOLINE_33= RULE_EOLINE
                    {
                    this_EOLINE_33=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_33, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_29());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompany"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:2433:1: entryRuleEnum returns [EObject current=null] : iv_ruleEnum= ruleEnum EOF ;
    public final EObject entryRuleEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnum = null;


        try {
            // InternalSM2.g:2433:45: (iv_ruleEnum= ruleEnum EOF )
            // InternalSM2.g:2434:2: iv_ruleEnum= ruleEnum EOF
            {
             newCompositeNode(grammarAccess.getEnumRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEnum=ruleEnum();

            state._fsp--;

             current =iv_ruleEnum; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:2440:1: ruleEnum returns [EObject current=null] : (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_ID_1=null;
        Token this_OPENKEY_2=null;
        Token this_STRING_3=null;
        Token this_COMMA_4=null;
        Token this_CLOSEKEY_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;


        	enterRule();

        try {
            // InternalSM2.g:2446:2: ( (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2447:2: (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2447:2: (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2448:3: otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,82,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getEnumAccess().getEnumKeyword_0());
            		
            this_ID_1=(Token)match(input,RULE_ID,FOLLOW_19); 

            			newLeafNode(this_ID_1, grammarAccess.getEnumAccess().getIDTerminalRuleCall_1());
            		
            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_41); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2());
            		
            this_STRING_3=(Token)match(input,RULE_STRING,FOLLOW_57); 

            			newLeafNode(this_STRING_3, grammarAccess.getEnumAccess().getSTRINGTerminalRuleCall_3());
            		
            // InternalSM2.g:2464:3: (this_COMMA_4= RULE_COMMA )?
            int alt71=2;
            int LA71_0 = input.LA(1);

            if ( (LA71_0==RULE_COMMA) ) {
                alt71=1;
            }
            switch (alt71) {
                case 1 :
                    // InternalSM2.g:2465:4: this_COMMA_4= RULE_COMMA
                    {
                    this_COMMA_4=(Token)match(input,RULE_COMMA,FOLLOW_34); 

                    				newLeafNode(this_COMMA_4, grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_4());
                    			

                    }
                    break;

            }

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_39); 

            			newLeafNode(this_CLOSEKEY_5, grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_5());
            		
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:2478:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==RULE_EOLINE) ) {
                alt72=1;
            }
            switch (alt72) {
                case 1 :
                    // InternalSM2.g:2479:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleSingularType"
    // InternalSM2.g:2488:1: entryRuleSingularType returns [EObject current=null] : iv_ruleSingularType= ruleSingularType EOF ;
    public final EObject entryRuleSingularType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSingularType = null;


        try {
            // InternalSM2.g:2488:53: (iv_ruleSingularType= ruleSingularType EOF )
            // InternalSM2.g:2489:2: iv_ruleSingularType= ruleSingularType EOF
            {
             newCompositeNode(grammarAccess.getSingularTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSingularType=ruleSingularType();

            state._fsp--;

             current =iv_ruleSingularType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSingularType"


    // $ANTLR start "ruleSingularType"
    // InternalSM2.g:2495:1: ruleSingularType returns [EObject current=null] : (otherlv_0= 'int' | otherlv_1= 'uint' | otherlv_2= 'uint8' | otherlv_3= 'string' | otherlv_4= 'address' | otherlv_5= 'address payable' | otherlv_6= 'double' | otherlv_7= 'bool' ) ;
    public final EObject ruleSingularType() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;


        	enterRule();

        try {
            // InternalSM2.g:2501:2: ( (otherlv_0= 'int' | otherlv_1= 'uint' | otherlv_2= 'uint8' | otherlv_3= 'string' | otherlv_4= 'address' | otherlv_5= 'address payable' | otherlv_6= 'double' | otherlv_7= 'bool' ) )
            // InternalSM2.g:2502:2: (otherlv_0= 'int' | otherlv_1= 'uint' | otherlv_2= 'uint8' | otherlv_3= 'string' | otherlv_4= 'address' | otherlv_5= 'address payable' | otherlv_6= 'double' | otherlv_7= 'bool' )
            {
            // InternalSM2.g:2502:2: (otherlv_0= 'int' | otherlv_1= 'uint' | otherlv_2= 'uint8' | otherlv_3= 'string' | otherlv_4= 'address' | otherlv_5= 'address payable' | otherlv_6= 'double' | otherlv_7= 'bool' )
            int alt73=8;
            switch ( input.LA(1) ) {
            case 83:
                {
                alt73=1;
                }
                break;
            case 84:
                {
                alt73=2;
                }
                break;
            case 85:
                {
                alt73=3;
                }
                break;
            case 80:
                {
                alt73=4;
                }
                break;
            case 78:
                {
                alt73=5;
                }
                break;
            case 86:
                {
                alt73=6;
                }
                break;
            case 87:
                {
                alt73=7;
                }
                break;
            case 88:
                {
                alt73=8;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 73, 0, input);

                throw nvae;
            }

            switch (alt73) {
                case 1 :
                    // InternalSM2.g:2503:3: otherlv_0= 'int'
                    {
                    otherlv_0=(Token)match(input,83,FOLLOW_2); 

                    			newLeafNode(otherlv_0, grammarAccess.getSingularTypeAccess().getIntKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2508:3: otherlv_1= 'uint'
                    {
                    otherlv_1=(Token)match(input,84,FOLLOW_2); 

                    			newLeafNode(otherlv_1, grammarAccess.getSingularTypeAccess().getUintKeyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2513:3: otherlv_2= 'uint8'
                    {
                    otherlv_2=(Token)match(input,85,FOLLOW_2); 

                    			newLeafNode(otherlv_2, grammarAccess.getSingularTypeAccess().getUint8Keyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:2518:3: otherlv_3= 'string'
                    {
                    otherlv_3=(Token)match(input,80,FOLLOW_2); 

                    			newLeafNode(otherlv_3, grammarAccess.getSingularTypeAccess().getStringKeyword_3());
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:2523:3: otherlv_4= 'address'
                    {
                    otherlv_4=(Token)match(input,78,FOLLOW_2); 

                    			newLeafNode(otherlv_4, grammarAccess.getSingularTypeAccess().getAddressKeyword_4());
                    		

                    }
                    break;
                case 6 :
                    // InternalSM2.g:2528:3: otherlv_5= 'address payable'
                    {
                    otherlv_5=(Token)match(input,86,FOLLOW_2); 

                    			newLeafNode(otherlv_5, grammarAccess.getSingularTypeAccess().getAddressPayableKeyword_5());
                    		

                    }
                    break;
                case 7 :
                    // InternalSM2.g:2533:3: otherlv_6= 'double'
                    {
                    otherlv_6=(Token)match(input,87,FOLLOW_2); 

                    			newLeafNode(otherlv_6, grammarAccess.getSingularTypeAccess().getDoubleKeyword_6());
                    		

                    }
                    break;
                case 8 :
                    // InternalSM2.g:2538:3: otherlv_7= 'bool'
                    {
                    otherlv_7=(Token)match(input,88,FOLLOW_2); 

                    			newLeafNode(otherlv_7, grammarAccess.getSingularTypeAccess().getBoolKeyword_7());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "entryRuleTypeAddress"
    // InternalSM2.g:2546:1: entryRuleTypeAddress returns [String current=null] : iv_ruleTypeAddress= ruleTypeAddress EOF ;
    public final String entryRuleTypeAddress() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeAddress = null;


        try {
            // InternalSM2.g:2546:51: (iv_ruleTypeAddress= ruleTypeAddress EOF )
            // InternalSM2.g:2547:2: iv_ruleTypeAddress= ruleTypeAddress EOF
            {
             newCompositeNode(grammarAccess.getTypeAddressRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeAddress=ruleTypeAddress();

            state._fsp--;

             current =iv_ruleTypeAddress.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeAddress"


    // $ANTLR start "ruleTypeAddress"
    // InternalSM2.g:2553:1: ruleTypeAddress returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'address' | kw= 'address payable' ) ;
    public final AntlrDatatypeRuleToken ruleTypeAddress() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSM2.g:2559:2: ( (kw= 'address' | kw= 'address payable' ) )
            // InternalSM2.g:2560:2: (kw= 'address' | kw= 'address payable' )
            {
            // InternalSM2.g:2560:2: (kw= 'address' | kw= 'address payable' )
            int alt74=2;
            int LA74_0 = input.LA(1);

            if ( (LA74_0==78) ) {
                alt74=1;
            }
            else if ( (LA74_0==86) ) {
                alt74=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 74, 0, input);

                throw nvae;
            }
            switch (alt74) {
                case 1 :
                    // InternalSM2.g:2561:3: kw= 'address'
                    {
                    kw=(Token)match(input,78,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAddressAccess().getAddressKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2567:3: kw= 'address payable'
                    {
                    kw=(Token)match(input,86,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAddressAccess().getAddressPayableKeyword_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeAddress"


    // $ANTLR start "entryRuleTypeBytes"
    // InternalSM2.g:2576:1: entryRuleTypeBytes returns [String current=null] : iv_ruleTypeBytes= ruleTypeBytes EOF ;
    public final String entryRuleTypeBytes() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeBytes = null;


        try {
            // InternalSM2.g:2576:49: (iv_ruleTypeBytes= ruleTypeBytes EOF )
            // InternalSM2.g:2577:2: iv_ruleTypeBytes= ruleTypeBytes EOF
            {
             newCompositeNode(grammarAccess.getTypeBytesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeBytes=ruleTypeBytes();

            state._fsp--;

             current =iv_ruleTypeBytes.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeBytes"


    // $ANTLR start "ruleTypeBytes"
    // InternalSM2.g:2583:1: ruleTypeBytes returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'bytes' | kw= 'bytes2' | kw= 'bytes3' | kw= 'bytes4' | kw= 'bytes5' | kw= 'bytes6' | kw= 'bytes7' | kw= 'bytes8' | kw= 'bytes10' | kw= 'bytes12' | kw= 'bytes14' | kw= 'bytes16' | kw= 'bytes18' | kw= 'bytes20' | kw= 'bytes24' | kw= 'bytes28' | kw= 'bytes30' | kw= 'bytes32' ) ;
    public final AntlrDatatypeRuleToken ruleTypeBytes() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSM2.g:2589:2: ( (kw= 'bytes' | kw= 'bytes2' | kw= 'bytes3' | kw= 'bytes4' | kw= 'bytes5' | kw= 'bytes6' | kw= 'bytes7' | kw= 'bytes8' | kw= 'bytes10' | kw= 'bytes12' | kw= 'bytes14' | kw= 'bytes16' | kw= 'bytes18' | kw= 'bytes20' | kw= 'bytes24' | kw= 'bytes28' | kw= 'bytes30' | kw= 'bytes32' ) )
            // InternalSM2.g:2590:2: (kw= 'bytes' | kw= 'bytes2' | kw= 'bytes3' | kw= 'bytes4' | kw= 'bytes5' | kw= 'bytes6' | kw= 'bytes7' | kw= 'bytes8' | kw= 'bytes10' | kw= 'bytes12' | kw= 'bytes14' | kw= 'bytes16' | kw= 'bytes18' | kw= 'bytes20' | kw= 'bytes24' | kw= 'bytes28' | kw= 'bytes30' | kw= 'bytes32' )
            {
            // InternalSM2.g:2590:2: (kw= 'bytes' | kw= 'bytes2' | kw= 'bytes3' | kw= 'bytes4' | kw= 'bytes5' | kw= 'bytes6' | kw= 'bytes7' | kw= 'bytes8' | kw= 'bytes10' | kw= 'bytes12' | kw= 'bytes14' | kw= 'bytes16' | kw= 'bytes18' | kw= 'bytes20' | kw= 'bytes24' | kw= 'bytes28' | kw= 'bytes30' | kw= 'bytes32' )
            int alt75=18;
            switch ( input.LA(1) ) {
            case 89:
                {
                alt75=1;
                }
                break;
            case 90:
                {
                alt75=2;
                }
                break;
            case 91:
                {
                alt75=3;
                }
                break;
            case 92:
                {
                alt75=4;
                }
                break;
            case 93:
                {
                alt75=5;
                }
                break;
            case 94:
                {
                alt75=6;
                }
                break;
            case 95:
                {
                alt75=7;
                }
                break;
            case 96:
                {
                alt75=8;
                }
                break;
            case 97:
                {
                alt75=9;
                }
                break;
            case 98:
                {
                alt75=10;
                }
                break;
            case 99:
                {
                alt75=11;
                }
                break;
            case 100:
                {
                alt75=12;
                }
                break;
            case 101:
                {
                alt75=13;
                }
                break;
            case 102:
                {
                alt75=14;
                }
                break;
            case 103:
                {
                alt75=15;
                }
                break;
            case 104:
                {
                alt75=16;
                }
                break;
            case 105:
                {
                alt75=17;
                }
                break;
            case 106:
                {
                alt75=18;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 75, 0, input);

                throw nvae;
            }

            switch (alt75) {
                case 1 :
                    // InternalSM2.g:2591:3: kw= 'bytes'
                    {
                    kw=(Token)match(input,89,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytesKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2597:3: kw= 'bytes2'
                    {
                    kw=(Token)match(input,90,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes2Keyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2603:3: kw= 'bytes3'
                    {
                    kw=(Token)match(input,91,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes3Keyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:2609:3: kw= 'bytes4'
                    {
                    kw=(Token)match(input,92,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes4Keyword_3());
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:2615:3: kw= 'bytes5'
                    {
                    kw=(Token)match(input,93,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes5Keyword_4());
                    		

                    }
                    break;
                case 6 :
                    // InternalSM2.g:2621:3: kw= 'bytes6'
                    {
                    kw=(Token)match(input,94,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes6Keyword_5());
                    		

                    }
                    break;
                case 7 :
                    // InternalSM2.g:2627:3: kw= 'bytes7'
                    {
                    kw=(Token)match(input,95,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes7Keyword_6());
                    		

                    }
                    break;
                case 8 :
                    // InternalSM2.g:2633:3: kw= 'bytes8'
                    {
                    kw=(Token)match(input,96,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes8Keyword_7());
                    		

                    }
                    break;
                case 9 :
                    // InternalSM2.g:2639:3: kw= 'bytes10'
                    {
                    kw=(Token)match(input,97,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes10Keyword_8());
                    		

                    }
                    break;
                case 10 :
                    // InternalSM2.g:2645:3: kw= 'bytes12'
                    {
                    kw=(Token)match(input,98,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes12Keyword_9());
                    		

                    }
                    break;
                case 11 :
                    // InternalSM2.g:2651:3: kw= 'bytes14'
                    {
                    kw=(Token)match(input,99,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes14Keyword_10());
                    		

                    }
                    break;
                case 12 :
                    // InternalSM2.g:2657:3: kw= 'bytes16'
                    {
                    kw=(Token)match(input,100,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes16Keyword_11());
                    		

                    }
                    break;
                case 13 :
                    // InternalSM2.g:2663:3: kw= 'bytes18'
                    {
                    kw=(Token)match(input,101,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes18Keyword_12());
                    		

                    }
                    break;
                case 14 :
                    // InternalSM2.g:2669:3: kw= 'bytes20'
                    {
                    kw=(Token)match(input,102,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes20Keyword_13());
                    		

                    }
                    break;
                case 15 :
                    // InternalSM2.g:2675:3: kw= 'bytes24'
                    {
                    kw=(Token)match(input,103,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes24Keyword_14());
                    		

                    }
                    break;
                case 16 :
                    // InternalSM2.g:2681:3: kw= 'bytes28'
                    {
                    kw=(Token)match(input,104,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes28Keyword_15());
                    		

                    }
                    break;
                case 17 :
                    // InternalSM2.g:2687:3: kw= 'bytes30'
                    {
                    kw=(Token)match(input,105,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes30Keyword_16());
                    		

                    }
                    break;
                case 18 :
                    // InternalSM2.g:2693:3: kw= 'bytes32'
                    {
                    kw=(Token)match(input,106,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes32Keyword_17());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeBytes"


    // $ANTLR start "entryRuleArray"
    // InternalSM2.g:2702:1: entryRuleArray returns [String current=null] : iv_ruleArray= ruleArray EOF ;
    public final String entryRuleArray() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleArray = null;


        try {
            // InternalSM2.g:2702:45: (iv_ruleArray= ruleArray EOF )
            // InternalSM2.g:2703:2: iv_ruleArray= ruleArray EOF
            {
             newCompositeNode(grammarAccess.getArrayRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleArray=ruleArray();

            state._fsp--;

             current =iv_ruleArray.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArray"


    // $ANTLR start "ruleArray"
    // InternalSM2.g:2709:1: ruleArray returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )* ) ;
    public final AntlrDatatypeRuleToken ruleArray() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_2=null;
        Token this_INT_6=null;


        	enterRule();

        try {
            // InternalSM2.g:2715:2: ( ( (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )* ) )
            // InternalSM2.g:2716:2: ( (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )* )
            {
            // InternalSM2.g:2716:2: ( (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )* )
            // InternalSM2.g:2717:3: (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )*
            {
            // InternalSM2.g:2717:3: (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) )
            int alt76=2;
            int LA76_0 = input.LA(1);

            if ( (LA76_0==107) ) {
                alt76=1;
            }
            else if ( (LA76_0==108) ) {
                alt76=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 76, 0, input);

                throw nvae;
            }
            switch (alt76) {
                case 1 :
                    // InternalSM2.g:2718:4: kw= '[]'
                    {
                    kw=(Token)match(input,107,FOLLOW_58); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_0_0());
                    			

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2724:4: (kw= '[' this_INT_2= RULE_INT kw= ']' )
                    {
                    // InternalSM2.g:2724:4: (kw= '[' this_INT_2= RULE_INT kw= ']' )
                    // InternalSM2.g:2725:5: kw= '[' this_INT_2= RULE_INT kw= ']'
                    {
                    kw=(Token)match(input,108,FOLLOW_59); 

                    					current.merge(kw);
                    					newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_0_1_0());
                    				
                    this_INT_2=(Token)match(input,RULE_INT,FOLLOW_60); 

                    					current.merge(this_INT_2);
                    				

                    					newLeafNode(this_INT_2, grammarAccess.getArrayAccess().getINTTerminalRuleCall_0_1_1());
                    				
                    kw=(Token)match(input,109,FOLLOW_58); 

                    					current.merge(kw);
                    					newLeafNode(kw, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_0_1_2());
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:2744:3: (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )*
            loop77:
            do {
                int alt77=3;
                int LA77_0 = input.LA(1);

                if ( (LA77_0==107) ) {
                    alt77=1;
                }
                else if ( (LA77_0==108) ) {
                    alt77=2;
                }


                switch (alt77) {
            	case 1 :
            	    // InternalSM2.g:2745:4: kw= '[]'
            	    {
            	    kw=(Token)match(input,107,FOLLOW_58); 

            	    				current.merge(kw);
            	    				newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_1_0());
            	    			

            	    }
            	    break;
            	case 2 :
            	    // InternalSM2.g:2751:4: (kw= '[' this_INT_6= RULE_INT kw= ']' )
            	    {
            	    // InternalSM2.g:2751:4: (kw= '[' this_INT_6= RULE_INT kw= ']' )
            	    // InternalSM2.g:2752:5: kw= '[' this_INT_6= RULE_INT kw= ']'
            	    {
            	    kw=(Token)match(input,108,FOLLOW_59); 

            	    					current.merge(kw);
            	    					newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_1_1_0());
            	    				
            	    this_INT_6=(Token)match(input,RULE_INT,FOLLOW_60); 

            	    					current.merge(this_INT_6);
            	    				

            	    					newLeafNode(this_INT_6, grammarAccess.getArrayAccess().getINTTerminalRuleCall_1_1_1());
            	    				
            	    kw=(Token)match(input,109,FOLLOW_58); 

            	    					current.merge(kw);
            	    					newLeafNode(kw, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_1_1_2());
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop77;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArray"


    // $ANTLR start "entryRuleProperties"
    // InternalSM2.g:2775:1: entryRuleProperties returns [EObject current=null] : iv_ruleProperties= ruleProperties EOF ;
    public final EObject entryRuleProperties() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperties = null;


        try {
            // InternalSM2.g:2775:51: (iv_ruleProperties= ruleProperties EOF )
            // InternalSM2.g:2776:2: iv_ruleProperties= ruleProperties EOF
            {
             newCompositeNode(grammarAccess.getPropertiesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleProperties=ruleProperties();

            state._fsp--;

             current =iv_ruleProperties; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperties"


    // $ANTLR start "ruleProperties"
    // InternalSM2.g:2782:1: ruleProperties returns [EObject current=null] : this_Property_0= ruleProperty ;
    public final EObject ruleProperties() throws RecognitionException {
        EObject current = null;

        EObject this_Property_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2788:2: (this_Property_0= ruleProperty )
            // InternalSM2.g:2789:2: this_Property_0= ruleProperty
            {

            		newCompositeNode(grammarAccess.getPropertiesAccess().getPropertyParserRuleCall());
            	
            pushFollow(FOLLOW_2);
            this_Property_0=ruleProperty();

            state._fsp--;


            		current = this_Property_0;
            		afterParserOrEnumRuleCall();
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperties"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:2800:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // InternalSM2.g:2800:49: (iv_ruleProperty= ruleProperty EOF )
            // InternalSM2.g:2801:2: iv_ruleProperty= ruleProperty EOF
            {
             newCompositeNode(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleProperty=ruleProperty();

            state._fsp--;

             current =iv_ruleProperty; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:2807:1: ruleProperty returns [EObject current=null] : (this_PropertyString_0= rulePropertyString | this_PropertyBoolean_1= rulePropertyBoolean | this_PropertyInteger_2= rulePropertyInteger | this_PropertyUInteger_3= rulePropertyUInteger | this_PropertyFloat_4= rulePropertyFloat | this_PropertyAddress_5= rulePropertyAddress | this_PropertyBytes_6= rulePropertyBytes | this_PropertyStruct_7= rulePropertyStruct ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        EObject this_PropertyString_0 = null;

        EObject this_PropertyBoolean_1 = null;

        EObject this_PropertyInteger_2 = null;

        EObject this_PropertyUInteger_3 = null;

        EObject this_PropertyFloat_4 = null;

        EObject this_PropertyAddress_5 = null;

        EObject this_PropertyBytes_6 = null;

        EObject this_PropertyStruct_7 = null;



        	enterRule();

        try {
            // InternalSM2.g:2813:2: ( (this_PropertyString_0= rulePropertyString | this_PropertyBoolean_1= rulePropertyBoolean | this_PropertyInteger_2= rulePropertyInteger | this_PropertyUInteger_3= rulePropertyUInteger | this_PropertyFloat_4= rulePropertyFloat | this_PropertyAddress_5= rulePropertyAddress | this_PropertyBytes_6= rulePropertyBytes | this_PropertyStruct_7= rulePropertyStruct ) )
            // InternalSM2.g:2814:2: (this_PropertyString_0= rulePropertyString | this_PropertyBoolean_1= rulePropertyBoolean | this_PropertyInteger_2= rulePropertyInteger | this_PropertyUInteger_3= rulePropertyUInteger | this_PropertyFloat_4= rulePropertyFloat | this_PropertyAddress_5= rulePropertyAddress | this_PropertyBytes_6= rulePropertyBytes | this_PropertyStruct_7= rulePropertyStruct )
            {
            // InternalSM2.g:2814:2: (this_PropertyString_0= rulePropertyString | this_PropertyBoolean_1= rulePropertyBoolean | this_PropertyInteger_2= rulePropertyInteger | this_PropertyUInteger_3= rulePropertyUInteger | this_PropertyFloat_4= rulePropertyFloat | this_PropertyAddress_5= rulePropertyAddress | this_PropertyBytes_6= rulePropertyBytes | this_PropertyStruct_7= rulePropertyStruct )
            int alt78=8;
            switch ( input.LA(1) ) {
            case 80:
                {
                alt78=1;
                }
                break;
            case 88:
                {
                alt78=2;
                }
                break;
            case 83:
            case 113:
            case 114:
            case 115:
            case 116:
            case 117:
            case 118:
            case 119:
            case 120:
            case 121:
            case 122:
            case 123:
            case 124:
            case 125:
            case 126:
            case 127:
            case 128:
            case 129:
                {
                alt78=3;
                }
                break;
            case 84:
            case 85:
            case 130:
            case 131:
            case 132:
            case 133:
            case 134:
            case 135:
            case 136:
            case 137:
            case 138:
            case 139:
            case 140:
            case 141:
            case 142:
            case 143:
            case 144:
            case 145:
                {
                alt78=4;
                }
                break;
            case 146:
                {
                alt78=5;
                }
                break;
            case 78:
            case 86:
                {
                alt78=6;
                }
                break;
            case 89:
            case 90:
            case 91:
            case 92:
            case 93:
            case 94:
            case 95:
            case 96:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:
            case 103:
            case 104:
            case 105:
            case 106:
                {
                alt78=7;
                }
                break;
            case 77:
                {
                alt78=8;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 78, 0, input);

                throw nvae;
            }

            switch (alt78) {
                case 1 :
                    // InternalSM2.g:2815:3: this_PropertyString_0= rulePropertyString
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyStringParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyString_0=rulePropertyString();

                    state._fsp--;


                    			current = this_PropertyString_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2824:3: this_PropertyBoolean_1= rulePropertyBoolean
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyBooleanParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyBoolean_1=rulePropertyBoolean();

                    state._fsp--;


                    			current = this_PropertyBoolean_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2833:3: this_PropertyInteger_2= rulePropertyInteger
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyIntegerParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyInteger_2=rulePropertyInteger();

                    state._fsp--;


                    			current = this_PropertyInteger_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:2842:3: this_PropertyUInteger_3= rulePropertyUInteger
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyUIntegerParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyUInteger_3=rulePropertyUInteger();

                    state._fsp--;


                    			current = this_PropertyUInteger_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:2851:3: this_PropertyFloat_4= rulePropertyFloat
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyFloatParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyFloat_4=rulePropertyFloat();

                    state._fsp--;


                    			current = this_PropertyFloat_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalSM2.g:2860:3: this_PropertyAddress_5= rulePropertyAddress
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyAddressParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyAddress_5=rulePropertyAddress();

                    state._fsp--;


                    			current = this_PropertyAddress_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 7 :
                    // InternalSM2.g:2869:3: this_PropertyBytes_6= rulePropertyBytes
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyBytesParserRuleCall_6());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyBytes_6=rulePropertyBytes();

                    state._fsp--;


                    			current = this_PropertyBytes_6;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 8 :
                    // InternalSM2.g:2878:3: this_PropertyStruct_7= rulePropertyStruct
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyStructParserRuleCall_7());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyStruct_7=rulePropertyStruct();

                    state._fsp--;


                    			current = this_PropertyStruct_7;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRulePropertyString"
    // InternalSM2.g:2890:1: entryRulePropertyString returns [EObject current=null] : iv_rulePropertyString= rulePropertyString EOF ;
    public final EObject entryRulePropertyString() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyString = null;


        try {
            // InternalSM2.g:2890:55: (iv_rulePropertyString= rulePropertyString EOF )
            // InternalSM2.g:2891:2: iv_rulePropertyString= rulePropertyString EOF
            {
             newCompositeNode(grammarAccess.getPropertyStringRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyString=rulePropertyString();

            state._fsp--;

             current =iv_rulePropertyString; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyString"


    // $ANTLR start "rulePropertyString"
    // InternalSM2.g:2897:1: rulePropertyString returns [EObject current=null] : ( ( (lv_type_0_0= 'string' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_STRING ) ) ( (lv_defaultValue_8_0= 'Insert text here' ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? ) ;
    public final EObject rulePropertyString() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token this_CONSTANT_2=null;
        Token lv_storageData_3_0=null;
        Token otherlv_4=null;
        Token lv_name_5_0=null;
        Token otherlv_6=null;
        Token lv_inicialization_7_0=null;
        Token lv_defaultValue_8_0=null;
        Token this_SEMICOLON_9=null;
        Token this_EOLINE_10=null;


        	enterRule();

        try {
            // InternalSM2.g:2903:2: ( ( ( (lv_type_0_0= 'string' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_STRING ) ) ( (lv_defaultValue_8_0= 'Insert text here' ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? ) )
            // InternalSM2.g:2904:2: ( ( (lv_type_0_0= 'string' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_STRING ) ) ( (lv_defaultValue_8_0= 'Insert text here' ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? )
            {
            // InternalSM2.g:2904:2: ( ( (lv_type_0_0= 'string' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_STRING ) ) ( (lv_defaultValue_8_0= 'Insert text here' ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? )
            // InternalSM2.g:2905:3: ( (lv_type_0_0= 'string' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_STRING ) ) ( (lv_defaultValue_8_0= 'Insert text here' ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )?
            {
            // InternalSM2.g:2905:3: ( (lv_type_0_0= 'string' ) )
            // InternalSM2.g:2906:4: (lv_type_0_0= 'string' )
            {
            // InternalSM2.g:2906:4: (lv_type_0_0= 'string' )
            // InternalSM2.g:2907:5: lv_type_0_0= 'string'
            {
            lv_type_0_0=(Token)match(input,80,FOLLOW_61); 

            					newLeafNode(lv_type_0_0, grammarAccess.getPropertyStringAccess().getTypeStringKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyStringRule());
            					}
            					setWithLastConsumed(current, "type", lv_type_0_0, "string");
            				

            }


            }

            // InternalSM2.g:2919:3: ( ruleArray )?
            int alt79=2;
            int LA79_0 = input.LA(1);

            if ( ((LA79_0>=107 && LA79_0<=108)) ) {
                alt79=1;
            }
            switch (alt79) {
                case 1 :
                    // InternalSM2.g:2920:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyStringAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_62);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:2928:3: (this_CONSTANT_2= RULE_CONSTANT )?
            int alt80=2;
            int LA80_0 = input.LA(1);

            if ( (LA80_0==RULE_CONSTANT) ) {
                alt80=1;
            }
            switch (alt80) {
                case 1 :
                    // InternalSM2.g:2929:4: this_CONSTANT_2= RULE_CONSTANT
                    {
                    this_CONSTANT_2=(Token)match(input,RULE_CONSTANT,FOLLOW_63); 

                    				newLeafNode(this_CONSTANT_2, grammarAccess.getPropertyStringAccess().getCONSTANTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:2934:3: ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )?
            int alt81=3;
            int LA81_0 = input.LA(1);

            if ( (LA81_0==110) ) {
                alt81=1;
            }
            else if ( (LA81_0==111) ) {
                alt81=2;
            }
            switch (alt81) {
                case 1 :
                    // InternalSM2.g:2935:4: ( (lv_storageData_3_0= 'memory' ) )
                    {
                    // InternalSM2.g:2935:4: ( (lv_storageData_3_0= 'memory' ) )
                    // InternalSM2.g:2936:5: (lv_storageData_3_0= 'memory' )
                    {
                    // InternalSM2.g:2936:5: (lv_storageData_3_0= 'memory' )
                    // InternalSM2.g:2937:6: lv_storageData_3_0= 'memory'
                    {
                    lv_storageData_3_0=(Token)match(input,110,FOLLOW_17); 

                    						newLeafNode(lv_storageData_3_0, grammarAccess.getPropertyStringAccess().getStorageDataMemoryKeyword_3_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyStringRule());
                    						}
                    						setWithLastConsumed(current, "storageData", lv_storageData_3_0, "memory");
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2950:4: otherlv_4= 'storage'
                    {
                    otherlv_4=(Token)match(input,111,FOLLOW_17); 

                    				newLeafNode(otherlv_4, grammarAccess.getPropertyStringAccess().getStorageKeyword_3_1());
                    			

                    }
                    break;

            }

            // InternalSM2.g:2955:3: ( (lv_name_5_0= RULE_ID ) )
            // InternalSM2.g:2956:4: (lv_name_5_0= RULE_ID )
            {
            // InternalSM2.g:2956:4: (lv_name_5_0= RULE_ID )
            // InternalSM2.g:2957:5: lv_name_5_0= RULE_ID
            {
            lv_name_5_0=(Token)match(input,RULE_ID,FOLLOW_54); 

            					newLeafNode(lv_name_5_0, grammarAccess.getPropertyStringAccess().getNameIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyStringRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_5_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:2973:3: (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_STRING ) ) ( (lv_defaultValue_8_0= 'Insert text here' ) ) )?
            int alt82=2;
            int LA82_0 = input.LA(1);

            if ( (LA82_0==81) ) {
                alt82=1;
            }
            switch (alt82) {
                case 1 :
                    // InternalSM2.g:2974:4: otherlv_6= '=' ( (lv_inicialization_7_0= RULE_STRING ) ) ( (lv_defaultValue_8_0= 'Insert text here' ) )
                    {
                    otherlv_6=(Token)match(input,81,FOLLOW_41); 

                    				newLeafNode(otherlv_6, grammarAccess.getPropertyStringAccess().getEqualsSignKeyword_5_0());
                    			
                    // InternalSM2.g:2978:4: ( (lv_inicialization_7_0= RULE_STRING ) )
                    // InternalSM2.g:2979:5: (lv_inicialization_7_0= RULE_STRING )
                    {
                    // InternalSM2.g:2979:5: (lv_inicialization_7_0= RULE_STRING )
                    // InternalSM2.g:2980:6: lv_inicialization_7_0= RULE_STRING
                    {
                    lv_inicialization_7_0=(Token)match(input,RULE_STRING,FOLLOW_64); 

                    						newLeafNode(lv_inicialization_7_0, grammarAccess.getPropertyStringAccess().getInicializationSTRINGTerminalRuleCall_5_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyStringRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"inicialization",
                    							lv_inicialization_7_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }

                    // InternalSM2.g:2996:4: ( (lv_defaultValue_8_0= 'Insert text here' ) )
                    // InternalSM2.g:2997:5: (lv_defaultValue_8_0= 'Insert text here' )
                    {
                    // InternalSM2.g:2997:5: (lv_defaultValue_8_0= 'Insert text here' )
                    // InternalSM2.g:2998:6: lv_defaultValue_8_0= 'Insert text here'
                    {
                    lv_defaultValue_8_0=(Token)match(input,112,FOLLOW_39); 

                    						newLeafNode(lv_defaultValue_8_0, grammarAccess.getPropertyStringAccess().getDefaultValueInsertTextHereKeyword_5_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyStringRule());
                    						}
                    						setWithLastConsumed(current, "defaultValue", lv_defaultValue_8_0, "Insert text here");
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			newLeafNode(this_SEMICOLON_9, grammarAccess.getPropertyStringAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:3015:3: (this_EOLINE_10= RULE_EOLINE )?
            int alt83=2;
            int LA83_0 = input.LA(1);

            if ( (LA83_0==RULE_EOLINE) ) {
                alt83=1;
            }
            switch (alt83) {
                case 1 :
                    // InternalSM2.g:3016:4: this_EOLINE_10= RULE_EOLINE
                    {
                    this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_10, grammarAccess.getPropertyStringAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyString"


    // $ANTLR start "entryRulePropertyInteger"
    // InternalSM2.g:3025:1: entryRulePropertyInteger returns [EObject current=null] : iv_rulePropertyInteger= rulePropertyInteger EOF ;
    public final EObject entryRulePropertyInteger() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyInteger = null;


        try {
            // InternalSM2.g:3025:56: (iv_rulePropertyInteger= rulePropertyInteger EOF )
            // InternalSM2.g:3026:2: iv_rulePropertyInteger= rulePropertyInteger EOF
            {
             newCompositeNode(grammarAccess.getPropertyIntegerRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyInteger=rulePropertyInteger();

            state._fsp--;

             current =iv_rulePropertyInteger; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyInteger"


    // $ANTLR start "rulePropertyInteger"
    // InternalSM2.g:3032:1: rulePropertyInteger returns [EObject current=null] : ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'int2' | lv_type_0_3= 'int4' | lv_type_0_4= 'int8' | lv_type_0_5= 'int16' | lv_type_0_6= 'int24' | lv_type_0_7= 'int32' | lv_type_0_8= 'int40' | lv_type_0_9= 'int48' | lv_type_0_10= 'int56' | lv_type_0_11= 'int64' | lv_type_0_12= 'int80' | lv_type_0_13= 'int88' | lv_type_0_14= 'int96' | lv_type_0_15= 'int104' | lv_type_0_16= 'int128' | lv_type_0_17= 'int160' | lv_type_0_18= 'int256' ) ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) ;
    public final EObject rulePropertyInteger() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_1=null;
        Token lv_type_0_2=null;
        Token lv_type_0_3=null;
        Token lv_type_0_4=null;
        Token lv_type_0_5=null;
        Token lv_type_0_6=null;
        Token lv_type_0_7=null;
        Token lv_type_0_8=null;
        Token lv_type_0_9=null;
        Token lv_type_0_10=null;
        Token lv_type_0_11=null;
        Token lv_type_0_12=null;
        Token lv_type_0_13=null;
        Token lv_type_0_14=null;
        Token lv_type_0_15=null;
        Token lv_type_0_16=null;
        Token lv_type_0_17=null;
        Token lv_type_0_18=null;
        Token this_CONSTANT_2=null;
        Token lv_name_4_0=null;
        Token otherlv_5=null;
        Token lv_inicialization_6_0=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        Enumerator lv_visibility_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3038:2: ( ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'int2' | lv_type_0_3= 'int4' | lv_type_0_4= 'int8' | lv_type_0_5= 'int16' | lv_type_0_6= 'int24' | lv_type_0_7= 'int32' | lv_type_0_8= 'int40' | lv_type_0_9= 'int48' | lv_type_0_10= 'int56' | lv_type_0_11= 'int64' | lv_type_0_12= 'int80' | lv_type_0_13= 'int88' | lv_type_0_14= 'int96' | lv_type_0_15= 'int104' | lv_type_0_16= 'int128' | lv_type_0_17= 'int160' | lv_type_0_18= 'int256' ) ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) )
            // InternalSM2.g:3039:2: ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'int2' | lv_type_0_3= 'int4' | lv_type_0_4= 'int8' | lv_type_0_5= 'int16' | lv_type_0_6= 'int24' | lv_type_0_7= 'int32' | lv_type_0_8= 'int40' | lv_type_0_9= 'int48' | lv_type_0_10= 'int56' | lv_type_0_11= 'int64' | lv_type_0_12= 'int80' | lv_type_0_13= 'int88' | lv_type_0_14= 'int96' | lv_type_0_15= 'int104' | lv_type_0_16= 'int128' | lv_type_0_17= 'int160' | lv_type_0_18= 'int256' ) ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            {
            // InternalSM2.g:3039:2: ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'int2' | lv_type_0_3= 'int4' | lv_type_0_4= 'int8' | lv_type_0_5= 'int16' | lv_type_0_6= 'int24' | lv_type_0_7= 'int32' | lv_type_0_8= 'int40' | lv_type_0_9= 'int48' | lv_type_0_10= 'int56' | lv_type_0_11= 'int64' | lv_type_0_12= 'int80' | lv_type_0_13= 'int88' | lv_type_0_14= 'int96' | lv_type_0_15= 'int104' | lv_type_0_16= 'int128' | lv_type_0_17= 'int160' | lv_type_0_18= 'int256' ) ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            // InternalSM2.g:3040:3: ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'int2' | lv_type_0_3= 'int4' | lv_type_0_4= 'int8' | lv_type_0_5= 'int16' | lv_type_0_6= 'int24' | lv_type_0_7= 'int32' | lv_type_0_8= 'int40' | lv_type_0_9= 'int48' | lv_type_0_10= 'int56' | lv_type_0_11= 'int64' | lv_type_0_12= 'int80' | lv_type_0_13= 'int88' | lv_type_0_14= 'int96' | lv_type_0_15= 'int104' | lv_type_0_16= 'int128' | lv_type_0_17= 'int160' | lv_type_0_18= 'int256' ) ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )?
            {
            // InternalSM2.g:3040:3: ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'int2' | lv_type_0_3= 'int4' | lv_type_0_4= 'int8' | lv_type_0_5= 'int16' | lv_type_0_6= 'int24' | lv_type_0_7= 'int32' | lv_type_0_8= 'int40' | lv_type_0_9= 'int48' | lv_type_0_10= 'int56' | lv_type_0_11= 'int64' | lv_type_0_12= 'int80' | lv_type_0_13= 'int88' | lv_type_0_14= 'int96' | lv_type_0_15= 'int104' | lv_type_0_16= 'int128' | lv_type_0_17= 'int160' | lv_type_0_18= 'int256' ) ) )
            // InternalSM2.g:3041:4: ( (lv_type_0_1= 'int' | lv_type_0_2= 'int2' | lv_type_0_3= 'int4' | lv_type_0_4= 'int8' | lv_type_0_5= 'int16' | lv_type_0_6= 'int24' | lv_type_0_7= 'int32' | lv_type_0_8= 'int40' | lv_type_0_9= 'int48' | lv_type_0_10= 'int56' | lv_type_0_11= 'int64' | lv_type_0_12= 'int80' | lv_type_0_13= 'int88' | lv_type_0_14= 'int96' | lv_type_0_15= 'int104' | lv_type_0_16= 'int128' | lv_type_0_17= 'int160' | lv_type_0_18= 'int256' ) )
            {
            // InternalSM2.g:3041:4: ( (lv_type_0_1= 'int' | lv_type_0_2= 'int2' | lv_type_0_3= 'int4' | lv_type_0_4= 'int8' | lv_type_0_5= 'int16' | lv_type_0_6= 'int24' | lv_type_0_7= 'int32' | lv_type_0_8= 'int40' | lv_type_0_9= 'int48' | lv_type_0_10= 'int56' | lv_type_0_11= 'int64' | lv_type_0_12= 'int80' | lv_type_0_13= 'int88' | lv_type_0_14= 'int96' | lv_type_0_15= 'int104' | lv_type_0_16= 'int128' | lv_type_0_17= 'int160' | lv_type_0_18= 'int256' ) )
            // InternalSM2.g:3042:5: (lv_type_0_1= 'int' | lv_type_0_2= 'int2' | lv_type_0_3= 'int4' | lv_type_0_4= 'int8' | lv_type_0_5= 'int16' | lv_type_0_6= 'int24' | lv_type_0_7= 'int32' | lv_type_0_8= 'int40' | lv_type_0_9= 'int48' | lv_type_0_10= 'int56' | lv_type_0_11= 'int64' | lv_type_0_12= 'int80' | lv_type_0_13= 'int88' | lv_type_0_14= 'int96' | lv_type_0_15= 'int104' | lv_type_0_16= 'int128' | lv_type_0_17= 'int160' | lv_type_0_18= 'int256' )
            {
            // InternalSM2.g:3042:5: (lv_type_0_1= 'int' | lv_type_0_2= 'int2' | lv_type_0_3= 'int4' | lv_type_0_4= 'int8' | lv_type_0_5= 'int16' | lv_type_0_6= 'int24' | lv_type_0_7= 'int32' | lv_type_0_8= 'int40' | lv_type_0_9= 'int48' | lv_type_0_10= 'int56' | lv_type_0_11= 'int64' | lv_type_0_12= 'int80' | lv_type_0_13= 'int88' | lv_type_0_14= 'int96' | lv_type_0_15= 'int104' | lv_type_0_16= 'int128' | lv_type_0_17= 'int160' | lv_type_0_18= 'int256' )
            int alt84=18;
            switch ( input.LA(1) ) {
            case 83:
                {
                alt84=1;
                }
                break;
            case 113:
                {
                alt84=2;
                }
                break;
            case 114:
                {
                alt84=3;
                }
                break;
            case 115:
                {
                alt84=4;
                }
                break;
            case 116:
                {
                alt84=5;
                }
                break;
            case 117:
                {
                alt84=6;
                }
                break;
            case 118:
                {
                alt84=7;
                }
                break;
            case 119:
                {
                alt84=8;
                }
                break;
            case 120:
                {
                alt84=9;
                }
                break;
            case 121:
                {
                alt84=10;
                }
                break;
            case 122:
                {
                alt84=11;
                }
                break;
            case 123:
                {
                alt84=12;
                }
                break;
            case 124:
                {
                alt84=13;
                }
                break;
            case 125:
                {
                alt84=14;
                }
                break;
            case 126:
                {
                alt84=15;
                }
                break;
            case 127:
                {
                alt84=16;
                }
                break;
            case 128:
                {
                alt84=17;
                }
                break;
            case 129:
                {
                alt84=18;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 84, 0, input);

                throw nvae;
            }

            switch (alt84) {
                case 1 :
                    // InternalSM2.g:3043:6: lv_type_0_1= 'int'
                    {
                    lv_type_0_1=(Token)match(input,83,FOLLOW_65); 

                    						newLeafNode(lv_type_0_1, grammarAccess.getPropertyIntegerAccess().getTypeIntKeyword_0_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3054:6: lv_type_0_2= 'int2'
                    {
                    lv_type_0_2=(Token)match(input,113,FOLLOW_65); 

                    						newLeafNode(lv_type_0_2, grammarAccess.getPropertyIntegerAccess().getTypeInt2Keyword_0_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_2, null);
                    					

                    }
                    break;
                case 3 :
                    // InternalSM2.g:3065:6: lv_type_0_3= 'int4'
                    {
                    lv_type_0_3=(Token)match(input,114,FOLLOW_65); 

                    						newLeafNode(lv_type_0_3, grammarAccess.getPropertyIntegerAccess().getTypeInt4Keyword_0_0_2());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_3, null);
                    					

                    }
                    break;
                case 4 :
                    // InternalSM2.g:3076:6: lv_type_0_4= 'int8'
                    {
                    lv_type_0_4=(Token)match(input,115,FOLLOW_65); 

                    						newLeafNode(lv_type_0_4, grammarAccess.getPropertyIntegerAccess().getTypeInt8Keyword_0_0_3());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_4, null);
                    					

                    }
                    break;
                case 5 :
                    // InternalSM2.g:3087:6: lv_type_0_5= 'int16'
                    {
                    lv_type_0_5=(Token)match(input,116,FOLLOW_65); 

                    						newLeafNode(lv_type_0_5, grammarAccess.getPropertyIntegerAccess().getTypeInt16Keyword_0_0_4());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_5, null);
                    					

                    }
                    break;
                case 6 :
                    // InternalSM2.g:3098:6: lv_type_0_6= 'int24'
                    {
                    lv_type_0_6=(Token)match(input,117,FOLLOW_65); 

                    						newLeafNode(lv_type_0_6, grammarAccess.getPropertyIntegerAccess().getTypeInt24Keyword_0_0_5());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_6, null);
                    					

                    }
                    break;
                case 7 :
                    // InternalSM2.g:3109:6: lv_type_0_7= 'int32'
                    {
                    lv_type_0_7=(Token)match(input,118,FOLLOW_65); 

                    						newLeafNode(lv_type_0_7, grammarAccess.getPropertyIntegerAccess().getTypeInt32Keyword_0_0_6());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_7, null);
                    					

                    }
                    break;
                case 8 :
                    // InternalSM2.g:3120:6: lv_type_0_8= 'int40'
                    {
                    lv_type_0_8=(Token)match(input,119,FOLLOW_65); 

                    						newLeafNode(lv_type_0_8, grammarAccess.getPropertyIntegerAccess().getTypeInt40Keyword_0_0_7());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_8, null);
                    					

                    }
                    break;
                case 9 :
                    // InternalSM2.g:3131:6: lv_type_0_9= 'int48'
                    {
                    lv_type_0_9=(Token)match(input,120,FOLLOW_65); 

                    						newLeafNode(lv_type_0_9, grammarAccess.getPropertyIntegerAccess().getTypeInt48Keyword_0_0_8());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_9, null);
                    					

                    }
                    break;
                case 10 :
                    // InternalSM2.g:3142:6: lv_type_0_10= 'int56'
                    {
                    lv_type_0_10=(Token)match(input,121,FOLLOW_65); 

                    						newLeafNode(lv_type_0_10, grammarAccess.getPropertyIntegerAccess().getTypeInt56Keyword_0_0_9());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_10, null);
                    					

                    }
                    break;
                case 11 :
                    // InternalSM2.g:3153:6: lv_type_0_11= 'int64'
                    {
                    lv_type_0_11=(Token)match(input,122,FOLLOW_65); 

                    						newLeafNode(lv_type_0_11, grammarAccess.getPropertyIntegerAccess().getTypeInt64Keyword_0_0_10());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_11, null);
                    					

                    }
                    break;
                case 12 :
                    // InternalSM2.g:3164:6: lv_type_0_12= 'int80'
                    {
                    lv_type_0_12=(Token)match(input,123,FOLLOW_65); 

                    						newLeafNode(lv_type_0_12, grammarAccess.getPropertyIntegerAccess().getTypeInt80Keyword_0_0_11());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_12, null);
                    					

                    }
                    break;
                case 13 :
                    // InternalSM2.g:3175:6: lv_type_0_13= 'int88'
                    {
                    lv_type_0_13=(Token)match(input,124,FOLLOW_65); 

                    						newLeafNode(lv_type_0_13, grammarAccess.getPropertyIntegerAccess().getTypeInt88Keyword_0_0_12());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_13, null);
                    					

                    }
                    break;
                case 14 :
                    // InternalSM2.g:3186:6: lv_type_0_14= 'int96'
                    {
                    lv_type_0_14=(Token)match(input,125,FOLLOW_65); 

                    						newLeafNode(lv_type_0_14, grammarAccess.getPropertyIntegerAccess().getTypeInt96Keyword_0_0_13());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_14, null);
                    					

                    }
                    break;
                case 15 :
                    // InternalSM2.g:3197:6: lv_type_0_15= 'int104'
                    {
                    lv_type_0_15=(Token)match(input,126,FOLLOW_65); 

                    						newLeafNode(lv_type_0_15, grammarAccess.getPropertyIntegerAccess().getTypeInt104Keyword_0_0_14());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_15, null);
                    					

                    }
                    break;
                case 16 :
                    // InternalSM2.g:3208:6: lv_type_0_16= 'int128'
                    {
                    lv_type_0_16=(Token)match(input,127,FOLLOW_65); 

                    						newLeafNode(lv_type_0_16, grammarAccess.getPropertyIntegerAccess().getTypeInt128Keyword_0_0_15());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_16, null);
                    					

                    }
                    break;
                case 17 :
                    // InternalSM2.g:3219:6: lv_type_0_17= 'int160'
                    {
                    lv_type_0_17=(Token)match(input,128,FOLLOW_65); 

                    						newLeafNode(lv_type_0_17, grammarAccess.getPropertyIntegerAccess().getTypeInt160Keyword_0_0_16());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_17, null);
                    					

                    }
                    break;
                case 18 :
                    // InternalSM2.g:3230:6: lv_type_0_18= 'int256'
                    {
                    lv_type_0_18=(Token)match(input,129,FOLLOW_65); 

                    						newLeafNode(lv_type_0_18, grammarAccess.getPropertyIntegerAccess().getTypeInt256Keyword_0_0_17());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_18, null);
                    					

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:3243:3: ( ruleArray )?
            int alt85=2;
            int LA85_0 = input.LA(1);

            if ( ((LA85_0>=107 && LA85_0<=108)) ) {
                alt85=1;
            }
            switch (alt85) {
                case 1 :
                    // InternalSM2.g:3244:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyIntegerAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_66);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:3252:3: (this_CONSTANT_2= RULE_CONSTANT )?
            int alt86=2;
            int LA86_0 = input.LA(1);

            if ( (LA86_0==RULE_CONSTANT) ) {
                alt86=1;
            }
            switch (alt86) {
                case 1 :
                    // InternalSM2.g:3253:4: this_CONSTANT_2= RULE_CONSTANT
                    {
                    this_CONSTANT_2=(Token)match(input,RULE_CONSTANT,FOLLOW_46); 

                    				newLeafNode(this_CONSTANT_2, grammarAccess.getPropertyIntegerAccess().getCONSTANTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:3258:3: ( (lv_visibility_3_0= ruleVisibility ) )?
            int alt87=2;
            int LA87_0 = input.LA(1);

            if ( ((LA87_0>=68 && LA87_0<=69)||LA87_0==162) ) {
                alt87=1;
            }
            switch (alt87) {
                case 1 :
                    // InternalSM2.g:3259:4: (lv_visibility_3_0= ruleVisibility )
                    {
                    // InternalSM2.g:3259:4: (lv_visibility_3_0= ruleVisibility )
                    // InternalSM2.g:3260:5: lv_visibility_3_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyIntegerAccess().getVisibilityVisibilityEnumRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_17);
                    lv_visibility_3_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyIntegerRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_3_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:3277:3: ( (lv_name_4_0= RULE_ID ) )
            // InternalSM2.g:3278:4: (lv_name_4_0= RULE_ID )
            {
            // InternalSM2.g:3278:4: (lv_name_4_0= RULE_ID )
            // InternalSM2.g:3279:5: lv_name_4_0= RULE_ID
            {
            lv_name_4_0=(Token)match(input,RULE_ID,FOLLOW_67); 

            					newLeafNode(lv_name_4_0, grammarAccess.getPropertyIntegerAccess().getNameIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyIntegerRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_4_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_5=(Token)match(input,81,FOLLOW_68); 

            			newLeafNode(otherlv_5, grammarAccess.getPropertyIntegerAccess().getEqualsSignKeyword_5());
            		
            // InternalSM2.g:3299:3: ( (lv_inicialization_6_0= RULE_INT ) )?
            int alt88=2;
            int LA88_0 = input.LA(1);

            if ( (LA88_0==RULE_INT) ) {
                alt88=1;
            }
            switch (alt88) {
                case 1 :
                    // InternalSM2.g:3300:4: (lv_inicialization_6_0= RULE_INT )
                    {
                    // InternalSM2.g:3300:4: (lv_inicialization_6_0= RULE_INT )
                    // InternalSM2.g:3301:5: lv_inicialization_6_0= RULE_INT
                    {
                    lv_inicialization_6_0=(Token)match(input,RULE_INT,FOLLOW_39); 

                    					newLeafNode(lv_inicialization_6_0, grammarAccess.getPropertyIntegerAccess().getInicializationINTTerminalRuleCall_6_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"inicialization",
                    						lv_inicialization_6_0,
                    						"org.eclipse.xtext.common.Terminals.INT");
                    				

                    }


                    }
                    break;

            }

            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getPropertyIntegerAccess().getSEMICOLONTerminalRuleCall_7());
            		
            // InternalSM2.g:3321:3: (this_EOLINE_8= RULE_EOLINE )?
            int alt89=2;
            int LA89_0 = input.LA(1);

            if ( (LA89_0==RULE_EOLINE) ) {
                alt89=1;
            }
            switch (alt89) {
                case 1 :
                    // InternalSM2.g:3322:4: this_EOLINE_8= RULE_EOLINE
                    {
                    this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_8, grammarAccess.getPropertyIntegerAccess().getEOLINETerminalRuleCall_8());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyInteger"


    // $ANTLR start "entryRulePropertyUInteger"
    // InternalSM2.g:3331:1: entryRulePropertyUInteger returns [EObject current=null] : iv_rulePropertyUInteger= rulePropertyUInteger EOF ;
    public final EObject entryRulePropertyUInteger() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyUInteger = null;


        try {
            // InternalSM2.g:3331:57: (iv_rulePropertyUInteger= rulePropertyUInteger EOF )
            // InternalSM2.g:3332:2: iv_rulePropertyUInteger= rulePropertyUInteger EOF
            {
             newCompositeNode(grammarAccess.getPropertyUIntegerRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyUInteger=rulePropertyUInteger();

            state._fsp--;

             current =iv_rulePropertyUInteger; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyUInteger"


    // $ANTLR start "rulePropertyUInteger"
    // InternalSM2.g:3338:1: rulePropertyUInteger returns [EObject current=null] : ( ( ( (lv_type_0_1= 'uint' | lv_type_0_2= 'uint2' | lv_type_0_3= 'uint4' | lv_type_0_4= 'uint8' | lv_type_0_5= 'uint16' | lv_type_0_6= 'uint24' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint40' | lv_type_0_9= 'uint48' | lv_type_0_10= 'uint56' | lv_type_0_11= 'uint64' | lv_type_0_12= 'uint80' | lv_type_0_13= 'uint88' | lv_type_0_14= 'uint96' | lv_type_0_15= 'uint104' | lv_type_0_16= 'uint128' | lv_type_0_17= 'uint160' | lv_type_0_18= 'uint256' ) ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) ;
    public final EObject rulePropertyUInteger() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_1=null;
        Token lv_type_0_2=null;
        Token lv_type_0_3=null;
        Token lv_type_0_4=null;
        Token lv_type_0_5=null;
        Token lv_type_0_6=null;
        Token lv_type_0_7=null;
        Token lv_type_0_8=null;
        Token lv_type_0_9=null;
        Token lv_type_0_10=null;
        Token lv_type_0_11=null;
        Token lv_type_0_12=null;
        Token lv_type_0_13=null;
        Token lv_type_0_14=null;
        Token lv_type_0_15=null;
        Token lv_type_0_16=null;
        Token lv_type_0_17=null;
        Token lv_type_0_18=null;
        Token this_CONSTANT_2=null;
        Token lv_name_4_0=null;
        Token otherlv_5=null;
        Token lv_inicialization_6_0=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        Enumerator lv_visibility_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3344:2: ( ( ( ( (lv_type_0_1= 'uint' | lv_type_0_2= 'uint2' | lv_type_0_3= 'uint4' | lv_type_0_4= 'uint8' | lv_type_0_5= 'uint16' | lv_type_0_6= 'uint24' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint40' | lv_type_0_9= 'uint48' | lv_type_0_10= 'uint56' | lv_type_0_11= 'uint64' | lv_type_0_12= 'uint80' | lv_type_0_13= 'uint88' | lv_type_0_14= 'uint96' | lv_type_0_15= 'uint104' | lv_type_0_16= 'uint128' | lv_type_0_17= 'uint160' | lv_type_0_18= 'uint256' ) ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) )
            // InternalSM2.g:3345:2: ( ( ( (lv_type_0_1= 'uint' | lv_type_0_2= 'uint2' | lv_type_0_3= 'uint4' | lv_type_0_4= 'uint8' | lv_type_0_5= 'uint16' | lv_type_0_6= 'uint24' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint40' | lv_type_0_9= 'uint48' | lv_type_0_10= 'uint56' | lv_type_0_11= 'uint64' | lv_type_0_12= 'uint80' | lv_type_0_13= 'uint88' | lv_type_0_14= 'uint96' | lv_type_0_15= 'uint104' | lv_type_0_16= 'uint128' | lv_type_0_17= 'uint160' | lv_type_0_18= 'uint256' ) ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            {
            // InternalSM2.g:3345:2: ( ( ( (lv_type_0_1= 'uint' | lv_type_0_2= 'uint2' | lv_type_0_3= 'uint4' | lv_type_0_4= 'uint8' | lv_type_0_5= 'uint16' | lv_type_0_6= 'uint24' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint40' | lv_type_0_9= 'uint48' | lv_type_0_10= 'uint56' | lv_type_0_11= 'uint64' | lv_type_0_12= 'uint80' | lv_type_0_13= 'uint88' | lv_type_0_14= 'uint96' | lv_type_0_15= 'uint104' | lv_type_0_16= 'uint128' | lv_type_0_17= 'uint160' | lv_type_0_18= 'uint256' ) ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            // InternalSM2.g:3346:3: ( ( (lv_type_0_1= 'uint' | lv_type_0_2= 'uint2' | lv_type_0_3= 'uint4' | lv_type_0_4= 'uint8' | lv_type_0_5= 'uint16' | lv_type_0_6= 'uint24' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint40' | lv_type_0_9= 'uint48' | lv_type_0_10= 'uint56' | lv_type_0_11= 'uint64' | lv_type_0_12= 'uint80' | lv_type_0_13= 'uint88' | lv_type_0_14= 'uint96' | lv_type_0_15= 'uint104' | lv_type_0_16= 'uint128' | lv_type_0_17= 'uint160' | lv_type_0_18= 'uint256' ) ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )?
            {
            // InternalSM2.g:3346:3: ( ( (lv_type_0_1= 'uint' | lv_type_0_2= 'uint2' | lv_type_0_3= 'uint4' | lv_type_0_4= 'uint8' | lv_type_0_5= 'uint16' | lv_type_0_6= 'uint24' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint40' | lv_type_0_9= 'uint48' | lv_type_0_10= 'uint56' | lv_type_0_11= 'uint64' | lv_type_0_12= 'uint80' | lv_type_0_13= 'uint88' | lv_type_0_14= 'uint96' | lv_type_0_15= 'uint104' | lv_type_0_16= 'uint128' | lv_type_0_17= 'uint160' | lv_type_0_18= 'uint256' ) ) )
            // InternalSM2.g:3347:4: ( (lv_type_0_1= 'uint' | lv_type_0_2= 'uint2' | lv_type_0_3= 'uint4' | lv_type_0_4= 'uint8' | lv_type_0_5= 'uint16' | lv_type_0_6= 'uint24' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint40' | lv_type_0_9= 'uint48' | lv_type_0_10= 'uint56' | lv_type_0_11= 'uint64' | lv_type_0_12= 'uint80' | lv_type_0_13= 'uint88' | lv_type_0_14= 'uint96' | lv_type_0_15= 'uint104' | lv_type_0_16= 'uint128' | lv_type_0_17= 'uint160' | lv_type_0_18= 'uint256' ) )
            {
            // InternalSM2.g:3347:4: ( (lv_type_0_1= 'uint' | lv_type_0_2= 'uint2' | lv_type_0_3= 'uint4' | lv_type_0_4= 'uint8' | lv_type_0_5= 'uint16' | lv_type_0_6= 'uint24' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint40' | lv_type_0_9= 'uint48' | lv_type_0_10= 'uint56' | lv_type_0_11= 'uint64' | lv_type_0_12= 'uint80' | lv_type_0_13= 'uint88' | lv_type_0_14= 'uint96' | lv_type_0_15= 'uint104' | lv_type_0_16= 'uint128' | lv_type_0_17= 'uint160' | lv_type_0_18= 'uint256' ) )
            // InternalSM2.g:3348:5: (lv_type_0_1= 'uint' | lv_type_0_2= 'uint2' | lv_type_0_3= 'uint4' | lv_type_0_4= 'uint8' | lv_type_0_5= 'uint16' | lv_type_0_6= 'uint24' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint40' | lv_type_0_9= 'uint48' | lv_type_0_10= 'uint56' | lv_type_0_11= 'uint64' | lv_type_0_12= 'uint80' | lv_type_0_13= 'uint88' | lv_type_0_14= 'uint96' | lv_type_0_15= 'uint104' | lv_type_0_16= 'uint128' | lv_type_0_17= 'uint160' | lv_type_0_18= 'uint256' )
            {
            // InternalSM2.g:3348:5: (lv_type_0_1= 'uint' | lv_type_0_2= 'uint2' | lv_type_0_3= 'uint4' | lv_type_0_4= 'uint8' | lv_type_0_5= 'uint16' | lv_type_0_6= 'uint24' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint40' | lv_type_0_9= 'uint48' | lv_type_0_10= 'uint56' | lv_type_0_11= 'uint64' | lv_type_0_12= 'uint80' | lv_type_0_13= 'uint88' | lv_type_0_14= 'uint96' | lv_type_0_15= 'uint104' | lv_type_0_16= 'uint128' | lv_type_0_17= 'uint160' | lv_type_0_18= 'uint256' )
            int alt90=18;
            switch ( input.LA(1) ) {
            case 84:
                {
                alt90=1;
                }
                break;
            case 130:
                {
                alt90=2;
                }
                break;
            case 131:
                {
                alt90=3;
                }
                break;
            case 85:
                {
                alt90=4;
                }
                break;
            case 132:
                {
                alt90=5;
                }
                break;
            case 133:
                {
                alt90=6;
                }
                break;
            case 134:
                {
                alt90=7;
                }
                break;
            case 135:
                {
                alt90=8;
                }
                break;
            case 136:
                {
                alt90=9;
                }
                break;
            case 137:
                {
                alt90=10;
                }
                break;
            case 138:
                {
                alt90=11;
                }
                break;
            case 139:
                {
                alt90=12;
                }
                break;
            case 140:
                {
                alt90=13;
                }
                break;
            case 141:
                {
                alt90=14;
                }
                break;
            case 142:
                {
                alt90=15;
                }
                break;
            case 143:
                {
                alt90=16;
                }
                break;
            case 144:
                {
                alt90=17;
                }
                break;
            case 145:
                {
                alt90=18;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 90, 0, input);

                throw nvae;
            }

            switch (alt90) {
                case 1 :
                    // InternalSM2.g:3349:6: lv_type_0_1= 'uint'
                    {
                    lv_type_0_1=(Token)match(input,84,FOLLOW_65); 

                    						newLeafNode(lv_type_0_1, grammarAccess.getPropertyUIntegerAccess().getTypeUintKeyword_0_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3360:6: lv_type_0_2= 'uint2'
                    {
                    lv_type_0_2=(Token)match(input,130,FOLLOW_65); 

                    						newLeafNode(lv_type_0_2, grammarAccess.getPropertyUIntegerAccess().getTypeUint2Keyword_0_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_2, null);
                    					

                    }
                    break;
                case 3 :
                    // InternalSM2.g:3371:6: lv_type_0_3= 'uint4'
                    {
                    lv_type_0_3=(Token)match(input,131,FOLLOW_65); 

                    						newLeafNode(lv_type_0_3, grammarAccess.getPropertyUIntegerAccess().getTypeUint4Keyword_0_0_2());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_3, null);
                    					

                    }
                    break;
                case 4 :
                    // InternalSM2.g:3382:6: lv_type_0_4= 'uint8'
                    {
                    lv_type_0_4=(Token)match(input,85,FOLLOW_65); 

                    						newLeafNode(lv_type_0_4, grammarAccess.getPropertyUIntegerAccess().getTypeUint8Keyword_0_0_3());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_4, null);
                    					

                    }
                    break;
                case 5 :
                    // InternalSM2.g:3393:6: lv_type_0_5= 'uint16'
                    {
                    lv_type_0_5=(Token)match(input,132,FOLLOW_65); 

                    						newLeafNode(lv_type_0_5, grammarAccess.getPropertyUIntegerAccess().getTypeUint16Keyword_0_0_4());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_5, null);
                    					

                    }
                    break;
                case 6 :
                    // InternalSM2.g:3404:6: lv_type_0_6= 'uint24'
                    {
                    lv_type_0_6=(Token)match(input,133,FOLLOW_65); 

                    						newLeafNode(lv_type_0_6, grammarAccess.getPropertyUIntegerAccess().getTypeUint24Keyword_0_0_5());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_6, null);
                    					

                    }
                    break;
                case 7 :
                    // InternalSM2.g:3415:6: lv_type_0_7= 'uint32'
                    {
                    lv_type_0_7=(Token)match(input,134,FOLLOW_65); 

                    						newLeafNode(lv_type_0_7, grammarAccess.getPropertyUIntegerAccess().getTypeUint32Keyword_0_0_6());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_7, null);
                    					

                    }
                    break;
                case 8 :
                    // InternalSM2.g:3426:6: lv_type_0_8= 'uint40'
                    {
                    lv_type_0_8=(Token)match(input,135,FOLLOW_65); 

                    						newLeafNode(lv_type_0_8, grammarAccess.getPropertyUIntegerAccess().getTypeUint40Keyword_0_0_7());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_8, null);
                    					

                    }
                    break;
                case 9 :
                    // InternalSM2.g:3437:6: lv_type_0_9= 'uint48'
                    {
                    lv_type_0_9=(Token)match(input,136,FOLLOW_65); 

                    						newLeafNode(lv_type_0_9, grammarAccess.getPropertyUIntegerAccess().getTypeUint48Keyword_0_0_8());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_9, null);
                    					

                    }
                    break;
                case 10 :
                    // InternalSM2.g:3448:6: lv_type_0_10= 'uint56'
                    {
                    lv_type_0_10=(Token)match(input,137,FOLLOW_65); 

                    						newLeafNode(lv_type_0_10, grammarAccess.getPropertyUIntegerAccess().getTypeUint56Keyword_0_0_9());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_10, null);
                    					

                    }
                    break;
                case 11 :
                    // InternalSM2.g:3459:6: lv_type_0_11= 'uint64'
                    {
                    lv_type_0_11=(Token)match(input,138,FOLLOW_65); 

                    						newLeafNode(lv_type_0_11, grammarAccess.getPropertyUIntegerAccess().getTypeUint64Keyword_0_0_10());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_11, null);
                    					

                    }
                    break;
                case 12 :
                    // InternalSM2.g:3470:6: lv_type_0_12= 'uint80'
                    {
                    lv_type_0_12=(Token)match(input,139,FOLLOW_65); 

                    						newLeafNode(lv_type_0_12, grammarAccess.getPropertyUIntegerAccess().getTypeUint80Keyword_0_0_11());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_12, null);
                    					

                    }
                    break;
                case 13 :
                    // InternalSM2.g:3481:6: lv_type_0_13= 'uint88'
                    {
                    lv_type_0_13=(Token)match(input,140,FOLLOW_65); 

                    						newLeafNode(lv_type_0_13, grammarAccess.getPropertyUIntegerAccess().getTypeUint88Keyword_0_0_12());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_13, null);
                    					

                    }
                    break;
                case 14 :
                    // InternalSM2.g:3492:6: lv_type_0_14= 'uint96'
                    {
                    lv_type_0_14=(Token)match(input,141,FOLLOW_65); 

                    						newLeafNode(lv_type_0_14, grammarAccess.getPropertyUIntegerAccess().getTypeUint96Keyword_0_0_13());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_14, null);
                    					

                    }
                    break;
                case 15 :
                    // InternalSM2.g:3503:6: lv_type_0_15= 'uint104'
                    {
                    lv_type_0_15=(Token)match(input,142,FOLLOW_65); 

                    						newLeafNode(lv_type_0_15, grammarAccess.getPropertyUIntegerAccess().getTypeUint104Keyword_0_0_14());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_15, null);
                    					

                    }
                    break;
                case 16 :
                    // InternalSM2.g:3514:6: lv_type_0_16= 'uint128'
                    {
                    lv_type_0_16=(Token)match(input,143,FOLLOW_65); 

                    						newLeafNode(lv_type_0_16, grammarAccess.getPropertyUIntegerAccess().getTypeUint128Keyword_0_0_15());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_16, null);
                    					

                    }
                    break;
                case 17 :
                    // InternalSM2.g:3525:6: lv_type_0_17= 'uint160'
                    {
                    lv_type_0_17=(Token)match(input,144,FOLLOW_65); 

                    						newLeafNode(lv_type_0_17, grammarAccess.getPropertyUIntegerAccess().getTypeUint160Keyword_0_0_16());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_17, null);
                    					

                    }
                    break;
                case 18 :
                    // InternalSM2.g:3536:6: lv_type_0_18= 'uint256'
                    {
                    lv_type_0_18=(Token)match(input,145,FOLLOW_65); 

                    						newLeafNode(lv_type_0_18, grammarAccess.getPropertyUIntegerAccess().getTypeUint256Keyword_0_0_17());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_18, null);
                    					

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:3549:3: ( ruleArray )?
            int alt91=2;
            int LA91_0 = input.LA(1);

            if ( ((LA91_0>=107 && LA91_0<=108)) ) {
                alt91=1;
            }
            switch (alt91) {
                case 1 :
                    // InternalSM2.g:3550:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyUIntegerAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_66);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:3558:3: (this_CONSTANT_2= RULE_CONSTANT )?
            int alt92=2;
            int LA92_0 = input.LA(1);

            if ( (LA92_0==RULE_CONSTANT) ) {
                alt92=1;
            }
            switch (alt92) {
                case 1 :
                    // InternalSM2.g:3559:4: this_CONSTANT_2= RULE_CONSTANT
                    {
                    this_CONSTANT_2=(Token)match(input,RULE_CONSTANT,FOLLOW_46); 

                    				newLeafNode(this_CONSTANT_2, grammarAccess.getPropertyUIntegerAccess().getCONSTANTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:3564:3: ( (lv_visibility_3_0= ruleVisibility ) )?
            int alt93=2;
            int LA93_0 = input.LA(1);

            if ( ((LA93_0>=68 && LA93_0<=69)||LA93_0==162) ) {
                alt93=1;
            }
            switch (alt93) {
                case 1 :
                    // InternalSM2.g:3565:4: (lv_visibility_3_0= ruleVisibility )
                    {
                    // InternalSM2.g:3565:4: (lv_visibility_3_0= ruleVisibility )
                    // InternalSM2.g:3566:5: lv_visibility_3_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyUIntegerAccess().getVisibilityVisibilityEnumRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_17);
                    lv_visibility_3_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyUIntegerRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_3_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:3583:3: ( (lv_name_4_0= RULE_ID ) )
            // InternalSM2.g:3584:4: (lv_name_4_0= RULE_ID )
            {
            // InternalSM2.g:3584:4: (lv_name_4_0= RULE_ID )
            // InternalSM2.g:3585:5: lv_name_4_0= RULE_ID
            {
            lv_name_4_0=(Token)match(input,RULE_ID,FOLLOW_67); 

            					newLeafNode(lv_name_4_0, grammarAccess.getPropertyUIntegerAccess().getNameIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyUIntegerRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_4_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_5=(Token)match(input,81,FOLLOW_68); 

            			newLeafNode(otherlv_5, grammarAccess.getPropertyUIntegerAccess().getEqualsSignKeyword_5());
            		
            // InternalSM2.g:3605:3: ( (lv_inicialization_6_0= RULE_INT ) )?
            int alt94=2;
            int LA94_0 = input.LA(1);

            if ( (LA94_0==RULE_INT) ) {
                alt94=1;
            }
            switch (alt94) {
                case 1 :
                    // InternalSM2.g:3606:4: (lv_inicialization_6_0= RULE_INT )
                    {
                    // InternalSM2.g:3606:4: (lv_inicialization_6_0= RULE_INT )
                    // InternalSM2.g:3607:5: lv_inicialization_6_0= RULE_INT
                    {
                    lv_inicialization_6_0=(Token)match(input,RULE_INT,FOLLOW_39); 

                    					newLeafNode(lv_inicialization_6_0, grammarAccess.getPropertyUIntegerAccess().getInicializationINTTerminalRuleCall_6_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"inicialization",
                    						lv_inicialization_6_0,
                    						"org.eclipse.xtext.common.Terminals.INT");
                    				

                    }


                    }
                    break;

            }

            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getPropertyUIntegerAccess().getSEMICOLONTerminalRuleCall_7());
            		
            // InternalSM2.g:3627:3: (this_EOLINE_8= RULE_EOLINE )?
            int alt95=2;
            int LA95_0 = input.LA(1);

            if ( (LA95_0==RULE_EOLINE) ) {
                alt95=1;
            }
            switch (alt95) {
                case 1 :
                    // InternalSM2.g:3628:4: this_EOLINE_8= RULE_EOLINE
                    {
                    this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_8, grammarAccess.getPropertyUIntegerAccess().getEOLINETerminalRuleCall_8());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyUInteger"


    // $ANTLR start "entryRulePropertyFloat"
    // InternalSM2.g:3637:1: entryRulePropertyFloat returns [EObject current=null] : iv_rulePropertyFloat= rulePropertyFloat EOF ;
    public final EObject entryRulePropertyFloat() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyFloat = null;


        try {
            // InternalSM2.g:3637:54: (iv_rulePropertyFloat= rulePropertyFloat EOF )
            // InternalSM2.g:3638:2: iv_rulePropertyFloat= rulePropertyFloat EOF
            {
             newCompositeNode(grammarAccess.getPropertyFloatRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyFloat=rulePropertyFloat();

            state._fsp--;

             current =iv_rulePropertyFloat; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyFloat"


    // $ANTLR start "rulePropertyFloat"
    // InternalSM2.g:3644:1: rulePropertyFloat returns [EObject current=null] : ( ( (lv_type_0_0= 'float' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_inicialization_8_0= RULE_FLOAT ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? ) ;
    public final EObject rulePropertyFloat() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token this_CONSTANT_2=null;
        Token lv_storageData_4_0=null;
        Token otherlv_5=null;
        Token lv_name_6_0=null;
        Token otherlv_7=null;
        Token lv_inicialization_8_0=null;
        Token this_SEMICOLON_9=null;
        Token this_EOLINE_10=null;
        Enumerator lv_visibility_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3650:2: ( ( ( (lv_type_0_0= 'float' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_inicialization_8_0= RULE_FLOAT ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? ) )
            // InternalSM2.g:3651:2: ( ( (lv_type_0_0= 'float' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_inicialization_8_0= RULE_FLOAT ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? )
            {
            // InternalSM2.g:3651:2: ( ( (lv_type_0_0= 'float' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_inicialization_8_0= RULE_FLOAT ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? )
            // InternalSM2.g:3652:3: ( (lv_type_0_0= 'float' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_inicialization_8_0= RULE_FLOAT ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )?
            {
            // InternalSM2.g:3652:3: ( (lv_type_0_0= 'float' ) )
            // InternalSM2.g:3653:4: (lv_type_0_0= 'float' )
            {
            // InternalSM2.g:3653:4: (lv_type_0_0= 'float' )
            // InternalSM2.g:3654:5: lv_type_0_0= 'float'
            {
            lv_type_0_0=(Token)match(input,146,FOLLOW_69); 

            					newLeafNode(lv_type_0_0, grammarAccess.getPropertyFloatAccess().getTypeFloatKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyFloatRule());
            					}
            					setWithLastConsumed(current, "type", lv_type_0_0, "float");
            				

            }


            }

            // InternalSM2.g:3666:3: ( ruleArray )?
            int alt96=2;
            int LA96_0 = input.LA(1);

            if ( ((LA96_0>=107 && LA96_0<=108)) ) {
                alt96=1;
            }
            switch (alt96) {
                case 1 :
                    // InternalSM2.g:3667:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyFloatAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_70);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:3675:3: (this_CONSTANT_2= RULE_CONSTANT )?
            int alt97=2;
            int LA97_0 = input.LA(1);

            if ( (LA97_0==RULE_CONSTANT) ) {
                alt97=1;
            }
            switch (alt97) {
                case 1 :
                    // InternalSM2.g:3676:4: this_CONSTANT_2= RULE_CONSTANT
                    {
                    this_CONSTANT_2=(Token)match(input,RULE_CONSTANT,FOLLOW_71); 

                    				newLeafNode(this_CONSTANT_2, grammarAccess.getPropertyFloatAccess().getCONSTANTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:3681:3: ( (lv_visibility_3_0= ruleVisibility ) )?
            int alt98=2;
            int LA98_0 = input.LA(1);

            if ( ((LA98_0>=68 && LA98_0<=69)||LA98_0==162) ) {
                alt98=1;
            }
            switch (alt98) {
                case 1 :
                    // InternalSM2.g:3682:4: (lv_visibility_3_0= ruleVisibility )
                    {
                    // InternalSM2.g:3682:4: (lv_visibility_3_0= ruleVisibility )
                    // InternalSM2.g:3683:5: lv_visibility_3_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyFloatAccess().getVisibilityVisibilityEnumRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_63);
                    lv_visibility_3_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyFloatRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_3_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:3700:3: ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )?
            int alt99=3;
            int LA99_0 = input.LA(1);

            if ( (LA99_0==110) ) {
                alt99=1;
            }
            else if ( (LA99_0==111) ) {
                alt99=2;
            }
            switch (alt99) {
                case 1 :
                    // InternalSM2.g:3701:4: ( (lv_storageData_4_0= 'memory' ) )
                    {
                    // InternalSM2.g:3701:4: ( (lv_storageData_4_0= 'memory' ) )
                    // InternalSM2.g:3702:5: (lv_storageData_4_0= 'memory' )
                    {
                    // InternalSM2.g:3702:5: (lv_storageData_4_0= 'memory' )
                    // InternalSM2.g:3703:6: lv_storageData_4_0= 'memory'
                    {
                    lv_storageData_4_0=(Token)match(input,110,FOLLOW_17); 

                    						newLeafNode(lv_storageData_4_0, grammarAccess.getPropertyFloatAccess().getStorageDataMemoryKeyword_4_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyFloatRule());
                    						}
                    						setWithLastConsumed(current, "storageData", lv_storageData_4_0, "memory");
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3716:4: otherlv_5= 'storage'
                    {
                    otherlv_5=(Token)match(input,111,FOLLOW_17); 

                    				newLeafNode(otherlv_5, grammarAccess.getPropertyFloatAccess().getStorageKeyword_4_1());
                    			

                    }
                    break;

            }

            // InternalSM2.g:3721:3: ( (lv_name_6_0= RULE_ID ) )
            // InternalSM2.g:3722:4: (lv_name_6_0= RULE_ID )
            {
            // InternalSM2.g:3722:4: (lv_name_6_0= RULE_ID )
            // InternalSM2.g:3723:5: lv_name_6_0= RULE_ID
            {
            lv_name_6_0=(Token)match(input,RULE_ID,FOLLOW_54); 

            					newLeafNode(lv_name_6_0, grammarAccess.getPropertyFloatAccess().getNameIDTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyFloatRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_6_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:3739:3: (otherlv_7= '=' ( (lv_inicialization_8_0= RULE_FLOAT ) ) )?
            int alt100=2;
            int LA100_0 = input.LA(1);

            if ( (LA100_0==81) ) {
                alt100=1;
            }
            switch (alt100) {
                case 1 :
                    // InternalSM2.g:3740:4: otherlv_7= '=' ( (lv_inicialization_8_0= RULE_FLOAT ) )
                    {
                    otherlv_7=(Token)match(input,81,FOLLOW_72); 

                    				newLeafNode(otherlv_7, grammarAccess.getPropertyFloatAccess().getEqualsSignKeyword_6_0());
                    			
                    // InternalSM2.g:3744:4: ( (lv_inicialization_8_0= RULE_FLOAT ) )
                    // InternalSM2.g:3745:5: (lv_inicialization_8_0= RULE_FLOAT )
                    {
                    // InternalSM2.g:3745:5: (lv_inicialization_8_0= RULE_FLOAT )
                    // InternalSM2.g:3746:6: lv_inicialization_8_0= RULE_FLOAT
                    {
                    lv_inicialization_8_0=(Token)match(input,RULE_FLOAT,FOLLOW_39); 

                    						newLeafNode(lv_inicialization_8_0, grammarAccess.getPropertyFloatAccess().getInicializationFLOATTerminalRuleCall_6_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyFloatRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"inicialization",
                    							lv_inicialization_8_0,
                    							"org.xtext.SM2.FLOAT");
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			newLeafNode(this_SEMICOLON_9, grammarAccess.getPropertyFloatAccess().getSEMICOLONTerminalRuleCall_7());
            		
            // InternalSM2.g:3767:3: (this_EOLINE_10= RULE_EOLINE )?
            int alt101=2;
            int LA101_0 = input.LA(1);

            if ( (LA101_0==RULE_EOLINE) ) {
                alt101=1;
            }
            switch (alt101) {
                case 1 :
                    // InternalSM2.g:3768:4: this_EOLINE_10= RULE_EOLINE
                    {
                    this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_10, grammarAccess.getPropertyFloatAccess().getEOLINETerminalRuleCall_8());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyFloat"


    // $ANTLR start "entryRulePropertyBoolean"
    // InternalSM2.g:3777:1: entryRulePropertyBoolean returns [EObject current=null] : iv_rulePropertyBoolean= rulePropertyBoolean EOF ;
    public final EObject entryRulePropertyBoolean() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyBoolean = null;


        try {
            // InternalSM2.g:3777:56: (iv_rulePropertyBoolean= rulePropertyBoolean EOF )
            // InternalSM2.g:3778:2: iv_rulePropertyBoolean= rulePropertyBoolean EOF
            {
             newCompositeNode(grammarAccess.getPropertyBooleanRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyBoolean=rulePropertyBoolean();

            state._fsp--;

             current =iv_rulePropertyBoolean; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyBoolean"


    // $ANTLR start "rulePropertyBoolean"
    // InternalSM2.g:3784:1: rulePropertyBoolean returns [EObject current=null] : ( ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_inicialization_8_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? ) ;
    public final EObject rulePropertyBoolean() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token this_CONSTANT_2=null;
        Token lv_storageData_4_0=null;
        Token otherlv_5=null;
        Token lv_name_6_0=null;
        Token otherlv_7=null;
        Token lv_inicialization_8_0=null;
        Token this_SEMICOLON_9=null;
        Token this_EOLINE_10=null;
        Enumerator lv_visibility_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3790:2: ( ( ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_inicialization_8_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? ) )
            // InternalSM2.g:3791:2: ( ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_inicialization_8_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? )
            {
            // InternalSM2.g:3791:2: ( ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_inicialization_8_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? )
            // InternalSM2.g:3792:3: ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_inicialization_8_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )?
            {
            // InternalSM2.g:3792:3: ( (lv_type_0_0= 'bool' ) )
            // InternalSM2.g:3793:4: (lv_type_0_0= 'bool' )
            {
            // InternalSM2.g:3793:4: (lv_type_0_0= 'bool' )
            // InternalSM2.g:3794:5: lv_type_0_0= 'bool'
            {
            lv_type_0_0=(Token)match(input,88,FOLLOW_69); 

            					newLeafNode(lv_type_0_0, grammarAccess.getPropertyBooleanAccess().getTypeBoolKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyBooleanRule());
            					}
            					setWithLastConsumed(current, "type", lv_type_0_0, "bool");
            				

            }


            }

            // InternalSM2.g:3806:3: ( ruleArray )?
            int alt102=2;
            int LA102_0 = input.LA(1);

            if ( ((LA102_0>=107 && LA102_0<=108)) ) {
                alt102=1;
            }
            switch (alt102) {
                case 1 :
                    // InternalSM2.g:3807:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyBooleanAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_70);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:3815:3: (this_CONSTANT_2= RULE_CONSTANT )?
            int alt103=2;
            int LA103_0 = input.LA(1);

            if ( (LA103_0==RULE_CONSTANT) ) {
                alt103=1;
            }
            switch (alt103) {
                case 1 :
                    // InternalSM2.g:3816:4: this_CONSTANT_2= RULE_CONSTANT
                    {
                    this_CONSTANT_2=(Token)match(input,RULE_CONSTANT,FOLLOW_71); 

                    				newLeafNode(this_CONSTANT_2, grammarAccess.getPropertyBooleanAccess().getCONSTANTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:3821:3: ( (lv_visibility_3_0= ruleVisibility ) )?
            int alt104=2;
            int LA104_0 = input.LA(1);

            if ( ((LA104_0>=68 && LA104_0<=69)||LA104_0==162) ) {
                alt104=1;
            }
            switch (alt104) {
                case 1 :
                    // InternalSM2.g:3822:4: (lv_visibility_3_0= ruleVisibility )
                    {
                    // InternalSM2.g:3822:4: (lv_visibility_3_0= ruleVisibility )
                    // InternalSM2.g:3823:5: lv_visibility_3_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyBooleanAccess().getVisibilityVisibilityEnumRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_63);
                    lv_visibility_3_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyBooleanRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_3_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:3840:3: ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )?
            int alt105=3;
            int LA105_0 = input.LA(1);

            if ( (LA105_0==110) ) {
                alt105=1;
            }
            else if ( (LA105_0==111) ) {
                alt105=2;
            }
            switch (alt105) {
                case 1 :
                    // InternalSM2.g:3841:4: ( (lv_storageData_4_0= 'memory' ) )
                    {
                    // InternalSM2.g:3841:4: ( (lv_storageData_4_0= 'memory' ) )
                    // InternalSM2.g:3842:5: (lv_storageData_4_0= 'memory' )
                    {
                    // InternalSM2.g:3842:5: (lv_storageData_4_0= 'memory' )
                    // InternalSM2.g:3843:6: lv_storageData_4_0= 'memory'
                    {
                    lv_storageData_4_0=(Token)match(input,110,FOLLOW_17); 

                    						newLeafNode(lv_storageData_4_0, grammarAccess.getPropertyBooleanAccess().getStorageDataMemoryKeyword_4_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyBooleanRule());
                    						}
                    						setWithLastConsumed(current, "storageData", lv_storageData_4_0, "memory");
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3856:4: otherlv_5= 'storage'
                    {
                    otherlv_5=(Token)match(input,111,FOLLOW_17); 

                    				newLeafNode(otherlv_5, grammarAccess.getPropertyBooleanAccess().getStorageKeyword_4_1());
                    			

                    }
                    break;

            }

            // InternalSM2.g:3861:3: ( (lv_name_6_0= RULE_ID ) )
            // InternalSM2.g:3862:4: (lv_name_6_0= RULE_ID )
            {
            // InternalSM2.g:3862:4: (lv_name_6_0= RULE_ID )
            // InternalSM2.g:3863:5: lv_name_6_0= RULE_ID
            {
            lv_name_6_0=(Token)match(input,RULE_ID,FOLLOW_54); 

            					newLeafNode(lv_name_6_0, grammarAccess.getPropertyBooleanAccess().getNameIDTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyBooleanRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_6_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:3879:3: (otherlv_7= '=' ( (lv_inicialization_8_0= RULE_BOOLVALUE ) ) )?
            int alt106=2;
            int LA106_0 = input.LA(1);

            if ( (LA106_0==81) ) {
                alt106=1;
            }
            switch (alt106) {
                case 1 :
                    // InternalSM2.g:3880:4: otherlv_7= '=' ( (lv_inicialization_8_0= RULE_BOOLVALUE ) )
                    {
                    otherlv_7=(Token)match(input,81,FOLLOW_73); 

                    				newLeafNode(otherlv_7, grammarAccess.getPropertyBooleanAccess().getEqualsSignKeyword_6_0());
                    			
                    // InternalSM2.g:3884:4: ( (lv_inicialization_8_0= RULE_BOOLVALUE ) )
                    // InternalSM2.g:3885:5: (lv_inicialization_8_0= RULE_BOOLVALUE )
                    {
                    // InternalSM2.g:3885:5: (lv_inicialization_8_0= RULE_BOOLVALUE )
                    // InternalSM2.g:3886:6: lv_inicialization_8_0= RULE_BOOLVALUE
                    {
                    lv_inicialization_8_0=(Token)match(input,RULE_BOOLVALUE,FOLLOW_39); 

                    						newLeafNode(lv_inicialization_8_0, grammarAccess.getPropertyBooleanAccess().getInicializationBOOLVALUETerminalRuleCall_6_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyBooleanRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"inicialization",
                    							lv_inicialization_8_0,
                    							"org.xtext.SM2.BOOLVALUE");
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			newLeafNode(this_SEMICOLON_9, grammarAccess.getPropertyBooleanAccess().getSEMICOLONTerminalRuleCall_7());
            		
            // InternalSM2.g:3907:3: (this_EOLINE_10= RULE_EOLINE )?
            int alt107=2;
            int LA107_0 = input.LA(1);

            if ( (LA107_0==RULE_EOLINE) ) {
                alt107=1;
            }
            switch (alt107) {
                case 1 :
                    // InternalSM2.g:3908:4: this_EOLINE_10= RULE_EOLINE
                    {
                    this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_10, grammarAccess.getPropertyBooleanAccess().getEOLINETerminalRuleCall_8());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyBoolean"


    // $ANTLR start "entryRulePropertyAddress"
    // InternalSM2.g:3917:1: entryRulePropertyAddress returns [EObject current=null] : iv_rulePropertyAddress= rulePropertyAddress EOF ;
    public final EObject entryRulePropertyAddress() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyAddress = null;


        try {
            // InternalSM2.g:3917:56: (iv_rulePropertyAddress= rulePropertyAddress EOF )
            // InternalSM2.g:3918:2: iv_rulePropertyAddress= rulePropertyAddress EOF
            {
             newCompositeNode(grammarAccess.getPropertyAddressRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyAddress=rulePropertyAddress();

            state._fsp--;

             current =iv_rulePropertyAddress; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyAddress"


    // $ANTLR start "rulePropertyAddress"
    // InternalSM2.g:3924:1: rulePropertyAddress returns [EObject current=null] : ( ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) ;
    public final EObject rulePropertyAddress() throws RecognitionException {
        EObject current = null;

        Token this_CONSTANT_2=null;
        Token lv_name_4_0=null;
        Token otherlv_5=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        AntlrDatatypeRuleToken lv_type_0_0 = null;

        Enumerator lv_visibility_3_0 = null;

        AntlrDatatypeRuleToken lv_defaultValue_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3930:2: ( ( ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) )
            // InternalSM2.g:3931:2: ( ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            {
            // InternalSM2.g:3931:2: ( ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            // InternalSM2.g:3932:3: ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )?
            {
            // InternalSM2.g:3932:3: ( (lv_type_0_0= ruleTypeAddress ) )
            // InternalSM2.g:3933:4: (lv_type_0_0= ruleTypeAddress )
            {
            // InternalSM2.g:3933:4: (lv_type_0_0= ruleTypeAddress )
            // InternalSM2.g:3934:5: lv_type_0_0= ruleTypeAddress
            {

            					newCompositeNode(grammarAccess.getPropertyAddressAccess().getTypeTypeAddressParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_65);
            lv_type_0_0=ruleTypeAddress();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_0_0,
            						"org.xtext.SM2.TypeAddress");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:3951:3: ( ruleArray )?
            int alt108=2;
            int LA108_0 = input.LA(1);

            if ( ((LA108_0>=107 && LA108_0<=108)) ) {
                alt108=1;
            }
            switch (alt108) {
                case 1 :
                    // InternalSM2.g:3952:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyAddressAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_66);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:3960:3: (this_CONSTANT_2= RULE_CONSTANT )?
            int alt109=2;
            int LA109_0 = input.LA(1);

            if ( (LA109_0==RULE_CONSTANT) ) {
                alt109=1;
            }
            switch (alt109) {
                case 1 :
                    // InternalSM2.g:3961:4: this_CONSTANT_2= RULE_CONSTANT
                    {
                    this_CONSTANT_2=(Token)match(input,RULE_CONSTANT,FOLLOW_46); 

                    				newLeafNode(this_CONSTANT_2, grammarAccess.getPropertyAddressAccess().getCONSTANTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:3966:3: ( (lv_visibility_3_0= ruleVisibility ) )?
            int alt110=2;
            int LA110_0 = input.LA(1);

            if ( ((LA110_0>=68 && LA110_0<=69)||LA110_0==162) ) {
                alt110=1;
            }
            switch (alt110) {
                case 1 :
                    // InternalSM2.g:3967:4: (lv_visibility_3_0= ruleVisibility )
                    {
                    // InternalSM2.g:3967:4: (lv_visibility_3_0= ruleVisibility )
                    // InternalSM2.g:3968:5: lv_visibility_3_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyAddressAccess().getVisibilityVisibilityEnumRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_17);
                    lv_visibility_3_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_3_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:3985:3: ( (lv_name_4_0= RULE_ID ) )
            // InternalSM2.g:3986:4: (lv_name_4_0= RULE_ID )
            {
            // InternalSM2.g:3986:4: (lv_name_4_0= RULE_ID )
            // InternalSM2.g:3987:5: lv_name_4_0= RULE_ID
            {
            lv_name_4_0=(Token)match(input,RULE_ID,FOLLOW_54); 

            					newLeafNode(lv_name_4_0, grammarAccess.getPropertyAddressAccess().getNameIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyAddressRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_4_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:4003:3: (otherlv_5= '=' ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) ) )?
            int alt111=2;
            int LA111_0 = input.LA(1);

            if ( (LA111_0==81) ) {
                alt111=1;
            }
            switch (alt111) {
                case 1 :
                    // InternalSM2.g:4004:4: otherlv_5= '=' ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) )
                    {
                    otherlv_5=(Token)match(input,81,FOLLOW_74); 

                    				newLeafNode(otherlv_5, grammarAccess.getPropertyAddressAccess().getEqualsSignKeyword_5_0());
                    			
                    // InternalSM2.g:4008:4: ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) )
                    // InternalSM2.g:4009:5: (lv_defaultValue_6_0= ruleHexadecimalExpression )
                    {
                    // InternalSM2.g:4009:5: (lv_defaultValue_6_0= ruleHexadecimalExpression )
                    // InternalSM2.g:4010:6: lv_defaultValue_6_0= ruleHexadecimalExpression
                    {

                    						newCompositeNode(grammarAccess.getPropertyAddressAccess().getDefaultValueHexadecimalExpressionParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_39);
                    lv_defaultValue_6_0=ruleHexadecimalExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                    						}
                    						set(
                    							current,
                    							"defaultValue",
                    							lv_defaultValue_6_0,
                    							"org.xtext.SM2.HexadecimalExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getPropertyAddressAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:4032:3: (this_EOLINE_8= RULE_EOLINE )?
            int alt112=2;
            int LA112_0 = input.LA(1);

            if ( (LA112_0==RULE_EOLINE) ) {
                alt112=1;
            }
            switch (alt112) {
                case 1 :
                    // InternalSM2.g:4033:4: this_EOLINE_8= RULE_EOLINE
                    {
                    this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_8, grammarAccess.getPropertyAddressAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyAddress"


    // $ANTLR start "entryRuleHexadecimalExpression"
    // InternalSM2.g:4042:1: entryRuleHexadecimalExpression returns [String current=null] : iv_ruleHexadecimalExpression= ruleHexadecimalExpression EOF ;
    public final String entryRuleHexadecimalExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleHexadecimalExpression = null;


        try {
            // InternalSM2.g:4042:61: (iv_ruleHexadecimalExpression= ruleHexadecimalExpression EOF )
            // InternalSM2.g:4043:2: iv_ruleHexadecimalExpression= ruleHexadecimalExpression EOF
            {
             newCompositeNode(grammarAccess.getHexadecimalExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleHexadecimalExpression=ruleHexadecimalExpression();

            state._fsp--;

             current =iv_ruleHexadecimalExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleHexadecimalExpression"


    // $ANTLR start "ruleHexadecimalExpression"
    // InternalSM2.g:4049:1: ruleHexadecimalExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= '0x' this_HEXEXPRESSION_1= RULE_HEXEXPRESSION ) ;
    public final AntlrDatatypeRuleToken ruleHexadecimalExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_HEXEXPRESSION_1=null;


        	enterRule();

        try {
            // InternalSM2.g:4055:2: ( (kw= '0x' this_HEXEXPRESSION_1= RULE_HEXEXPRESSION ) )
            // InternalSM2.g:4056:2: (kw= '0x' this_HEXEXPRESSION_1= RULE_HEXEXPRESSION )
            {
            // InternalSM2.g:4056:2: (kw= '0x' this_HEXEXPRESSION_1= RULE_HEXEXPRESSION )
            // InternalSM2.g:4057:3: kw= '0x' this_HEXEXPRESSION_1= RULE_HEXEXPRESSION
            {
            kw=(Token)match(input,147,FOLLOW_75); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getHexadecimalExpressionAccess().getXKeyword_0());
            		
            this_HEXEXPRESSION_1=(Token)match(input,RULE_HEXEXPRESSION,FOLLOW_2); 

            			current.merge(this_HEXEXPRESSION_1);
            		

            			newLeafNode(this_HEXEXPRESSION_1, grammarAccess.getHexadecimalExpressionAccess().getHEXEXPRESSIONTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleHexadecimalExpression"


    // $ANTLR start "entryRulePropertyBytes"
    // InternalSM2.g:4073:1: entryRulePropertyBytes returns [EObject current=null] : iv_rulePropertyBytes= rulePropertyBytes EOF ;
    public final EObject entryRulePropertyBytes() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyBytes = null;


        try {
            // InternalSM2.g:4073:54: (iv_rulePropertyBytes= rulePropertyBytes EOF )
            // InternalSM2.g:4074:2: iv_rulePropertyBytes= rulePropertyBytes EOF
            {
             newCompositeNode(grammarAccess.getPropertyBytesRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyBytes=rulePropertyBytes();

            state._fsp--;

             current =iv_rulePropertyBytes; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyBytes"


    // $ANTLR start "rulePropertyBytes"
    // InternalSM2.g:4080:1: rulePropertyBytes returns [EObject current=null] : ( ( (lv_type_0_0= ruleTypeBytes ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_defaultValueLiteral_8_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_9= RULE_SEMICOLON otherlv_10= '/r' ) ;
    public final EObject rulePropertyBytes() throws RecognitionException {
        EObject current = null;

        Token this_CONSTANT_2=null;
        Token lv_storageData_4_0=null;
        Token otherlv_5=null;
        Token lv_name_6_0=null;
        Token otherlv_7=null;
        Token this_SEMICOLON_9=null;
        Token otherlv_10=null;
        AntlrDatatypeRuleToken lv_type_0_0 = null;

        Enumerator lv_visibility_3_0 = null;

        AntlrDatatypeRuleToken lv_defaultValueLiteral_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4086:2: ( ( ( (lv_type_0_0= ruleTypeBytes ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_defaultValueLiteral_8_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_9= RULE_SEMICOLON otherlv_10= '/r' ) )
            // InternalSM2.g:4087:2: ( ( (lv_type_0_0= ruleTypeBytes ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_defaultValueLiteral_8_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_9= RULE_SEMICOLON otherlv_10= '/r' )
            {
            // InternalSM2.g:4087:2: ( ( (lv_type_0_0= ruleTypeBytes ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_defaultValueLiteral_8_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_9= RULE_SEMICOLON otherlv_10= '/r' )
            // InternalSM2.g:4088:3: ( (lv_type_0_0= ruleTypeBytes ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )? ( (lv_name_6_0= RULE_ID ) ) (otherlv_7= '=' ( (lv_defaultValueLiteral_8_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_9= RULE_SEMICOLON otherlv_10= '/r'
            {
            // InternalSM2.g:4088:3: ( (lv_type_0_0= ruleTypeBytes ) )
            // InternalSM2.g:4089:4: (lv_type_0_0= ruleTypeBytes )
            {
            // InternalSM2.g:4089:4: (lv_type_0_0= ruleTypeBytes )
            // InternalSM2.g:4090:5: lv_type_0_0= ruleTypeBytes
            {

            					newCompositeNode(grammarAccess.getPropertyBytesAccess().getTypeTypeBytesParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_69);
            lv_type_0_0=ruleTypeBytes();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_0_0,
            						"org.xtext.SM2.TypeBytes");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:4107:3: ( ruleArray )?
            int alt113=2;
            int LA113_0 = input.LA(1);

            if ( ((LA113_0>=107 && LA113_0<=108)) ) {
                alt113=1;
            }
            switch (alt113) {
                case 1 :
                    // InternalSM2.g:4108:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyBytesAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_70);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:4116:3: (this_CONSTANT_2= RULE_CONSTANT )?
            int alt114=2;
            int LA114_0 = input.LA(1);

            if ( (LA114_0==RULE_CONSTANT) ) {
                alt114=1;
            }
            switch (alt114) {
                case 1 :
                    // InternalSM2.g:4117:4: this_CONSTANT_2= RULE_CONSTANT
                    {
                    this_CONSTANT_2=(Token)match(input,RULE_CONSTANT,FOLLOW_71); 

                    				newLeafNode(this_CONSTANT_2, grammarAccess.getPropertyBytesAccess().getCONSTANTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:4122:3: ( (lv_visibility_3_0= ruleVisibility ) )?
            int alt115=2;
            int LA115_0 = input.LA(1);

            if ( ((LA115_0>=68 && LA115_0<=69)||LA115_0==162) ) {
                alt115=1;
            }
            switch (alt115) {
                case 1 :
                    // InternalSM2.g:4123:4: (lv_visibility_3_0= ruleVisibility )
                    {
                    // InternalSM2.g:4123:4: (lv_visibility_3_0= ruleVisibility )
                    // InternalSM2.g:4124:5: lv_visibility_3_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyBytesAccess().getVisibilityVisibilityEnumRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_63);
                    lv_visibility_3_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_3_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:4141:3: ( ( (lv_storageData_4_0= 'memory' ) ) | otherlv_5= 'storage' )?
            int alt116=3;
            int LA116_0 = input.LA(1);

            if ( (LA116_0==110) ) {
                alt116=1;
            }
            else if ( (LA116_0==111) ) {
                alt116=2;
            }
            switch (alt116) {
                case 1 :
                    // InternalSM2.g:4142:4: ( (lv_storageData_4_0= 'memory' ) )
                    {
                    // InternalSM2.g:4142:4: ( (lv_storageData_4_0= 'memory' ) )
                    // InternalSM2.g:4143:5: (lv_storageData_4_0= 'memory' )
                    {
                    // InternalSM2.g:4143:5: (lv_storageData_4_0= 'memory' )
                    // InternalSM2.g:4144:6: lv_storageData_4_0= 'memory'
                    {
                    lv_storageData_4_0=(Token)match(input,110,FOLLOW_17); 

                    						newLeafNode(lv_storageData_4_0, grammarAccess.getPropertyBytesAccess().getStorageDataMemoryKeyword_4_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyBytesRule());
                    						}
                    						setWithLastConsumed(current, "storageData", lv_storageData_4_0, "memory");
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4157:4: otherlv_5= 'storage'
                    {
                    otherlv_5=(Token)match(input,111,FOLLOW_17); 

                    				newLeafNode(otherlv_5, grammarAccess.getPropertyBytesAccess().getStorageKeyword_4_1());
                    			

                    }
                    break;

            }

            // InternalSM2.g:4162:3: ( (lv_name_6_0= RULE_ID ) )
            // InternalSM2.g:4163:4: (lv_name_6_0= RULE_ID )
            {
            // InternalSM2.g:4163:4: (lv_name_6_0= RULE_ID )
            // InternalSM2.g:4164:5: lv_name_6_0= RULE_ID
            {
            lv_name_6_0=(Token)match(input,RULE_ID,FOLLOW_54); 

            					newLeafNode(lv_name_6_0, grammarAccess.getPropertyBytesAccess().getNameIDTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyBytesRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_6_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:4180:3: (otherlv_7= '=' ( (lv_defaultValueLiteral_8_0= ruleSyntaxExpression ) ) )?
            int alt117=2;
            int LA117_0 = input.LA(1);

            if ( (LA117_0==81) ) {
                alt117=1;
            }
            switch (alt117) {
                case 1 :
                    // InternalSM2.g:4181:4: otherlv_7= '=' ( (lv_defaultValueLiteral_8_0= ruleSyntaxExpression ) )
                    {
                    otherlv_7=(Token)match(input,81,FOLLOW_41); 

                    				newLeafNode(otherlv_7, grammarAccess.getPropertyBytesAccess().getEqualsSignKeyword_6_0());
                    			
                    // InternalSM2.g:4185:4: ( (lv_defaultValueLiteral_8_0= ruleSyntaxExpression ) )
                    // InternalSM2.g:4186:5: (lv_defaultValueLiteral_8_0= ruleSyntaxExpression )
                    {
                    // InternalSM2.g:4186:5: (lv_defaultValueLiteral_8_0= ruleSyntaxExpression )
                    // InternalSM2.g:4187:6: lv_defaultValueLiteral_8_0= ruleSyntaxExpression
                    {

                    						newCompositeNode(grammarAccess.getPropertyBytesAccess().getDefaultValueLiteralSyntaxExpressionParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_39);
                    lv_defaultValueLiteral_8_0=ruleSyntaxExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                    						}
                    						set(
                    							current,
                    							"defaultValueLiteral",
                    							lv_defaultValueLiteral_8_0,
                    							"org.xtext.SM2.SyntaxExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_76); 

            			newLeafNode(this_SEMICOLON_9, grammarAccess.getPropertyBytesAccess().getSEMICOLONTerminalRuleCall_7());
            		
            otherlv_10=(Token)match(input,148,FOLLOW_2); 

            			newLeafNode(otherlv_10, grammarAccess.getPropertyBytesAccess().getRKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyBytes"


    // $ANTLR start "entryRulePropertyStruct"
    // InternalSM2.g:4217:1: entryRulePropertyStruct returns [EObject current=null] : iv_rulePropertyStruct= rulePropertyStruct EOF ;
    public final EObject entryRulePropertyStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyStruct = null;


        try {
            // InternalSM2.g:4217:55: (iv_rulePropertyStruct= rulePropertyStruct EOF )
            // InternalSM2.g:4218:2: iv_rulePropertyStruct= rulePropertyStruct EOF
            {
             newCompositeNode(grammarAccess.getPropertyStructRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyStruct=rulePropertyStruct();

            state._fsp--;

             current =iv_rulePropertyStruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyStruct"


    // $ANTLR start "rulePropertyStruct"
    // InternalSM2.g:4224:1: rulePropertyStruct returns [EObject current=null] : ( ( (lv_assignedStruct_0_0= ruleStruct ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_NEW ) ) ruleSyntaxExpression )? this_SEMICOLON_7= RULE_SEMICOLON otherlv_8= '/r' ) ;
    public final EObject rulePropertyStruct() throws RecognitionException {
        EObject current = null;

        Token lv_name_3_0=null;
        Token otherlv_4=null;
        Token lv_inicialization_5_0=null;
        Token this_SEMICOLON_7=null;
        Token otherlv_8=null;
        EObject lv_assignedStruct_0_0 = null;

        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4230:2: ( ( ( (lv_assignedStruct_0_0= ruleStruct ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_NEW ) ) ruleSyntaxExpression )? this_SEMICOLON_7= RULE_SEMICOLON otherlv_8= '/r' ) )
            // InternalSM2.g:4231:2: ( ( (lv_assignedStruct_0_0= ruleStruct ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_NEW ) ) ruleSyntaxExpression )? this_SEMICOLON_7= RULE_SEMICOLON otherlv_8= '/r' )
            {
            // InternalSM2.g:4231:2: ( ( (lv_assignedStruct_0_0= ruleStruct ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_NEW ) ) ruleSyntaxExpression )? this_SEMICOLON_7= RULE_SEMICOLON otherlv_8= '/r' )
            // InternalSM2.g:4232:3: ( (lv_assignedStruct_0_0= ruleStruct ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_NEW ) ) ruleSyntaxExpression )? this_SEMICOLON_7= RULE_SEMICOLON otherlv_8= '/r'
            {
            // InternalSM2.g:4232:3: ( (lv_assignedStruct_0_0= ruleStruct ) )
            // InternalSM2.g:4233:4: (lv_assignedStruct_0_0= ruleStruct )
            {
            // InternalSM2.g:4233:4: (lv_assignedStruct_0_0= ruleStruct )
            // InternalSM2.g:4234:5: lv_assignedStruct_0_0= ruleStruct
            {

            					newCompositeNode(grammarAccess.getPropertyStructAccess().getAssignedStructStructParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_77);
            lv_assignedStruct_0_0=ruleStruct();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPropertyStructRule());
            					}
            					set(
            						current,
            						"assignedStruct",
            						lv_assignedStruct_0_0,
            						"org.xtext.SM2.Struct");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:4251:3: ( ruleArray )?
            int alt118=2;
            int LA118_0 = input.LA(1);

            if ( ((LA118_0>=107 && LA118_0<=108)) ) {
                alt118=1;
            }
            switch (alt118) {
                case 1 :
                    // InternalSM2.g:4252:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyStructAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_46);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:4260:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt119=2;
            int LA119_0 = input.LA(1);

            if ( ((LA119_0>=68 && LA119_0<=69)||LA119_0==162) ) {
                alt119=1;
            }
            switch (alt119) {
                case 1 :
                    // InternalSM2.g:4261:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:4261:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:4262:5: lv_visibility_2_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyStructAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_17);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyStructRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_2_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:4279:3: ( (lv_name_3_0= RULE_ID ) )
            // InternalSM2.g:4280:4: (lv_name_3_0= RULE_ID )
            {
            // InternalSM2.g:4280:4: (lv_name_3_0= RULE_ID )
            // InternalSM2.g:4281:5: lv_name_3_0= RULE_ID
            {
            lv_name_3_0=(Token)match(input,RULE_ID,FOLLOW_54); 

            					newLeafNode(lv_name_3_0, grammarAccess.getPropertyStructAccess().getNameIDTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyStructRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_3_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:4297:3: (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_NEW ) ) ruleSyntaxExpression )?
            int alt120=2;
            int LA120_0 = input.LA(1);

            if ( (LA120_0==81) ) {
                alt120=1;
            }
            switch (alt120) {
                case 1 :
                    // InternalSM2.g:4298:4: otherlv_4= '=' ( (lv_inicialization_5_0= RULE_NEW ) ) ruleSyntaxExpression
                    {
                    otherlv_4=(Token)match(input,81,FOLLOW_78); 

                    				newLeafNode(otherlv_4, grammarAccess.getPropertyStructAccess().getEqualsSignKeyword_4_0());
                    			
                    // InternalSM2.g:4302:4: ( (lv_inicialization_5_0= RULE_NEW ) )
                    // InternalSM2.g:4303:5: (lv_inicialization_5_0= RULE_NEW )
                    {
                    // InternalSM2.g:4303:5: (lv_inicialization_5_0= RULE_NEW )
                    // InternalSM2.g:4304:6: lv_inicialization_5_0= RULE_NEW
                    {
                    lv_inicialization_5_0=(Token)match(input,RULE_NEW,FOLLOW_41); 

                    						newLeafNode(lv_inicialization_5_0, grammarAccess.getPropertyStructAccess().getInicializationNEWTerminalRuleCall_4_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyStructRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"inicialization",
                    							lv_inicialization_5_0,
                    							"org.xtext.SM2.NEW");
                    					

                    }


                    }


                    				newCompositeNode(grammarAccess.getPropertyStructAccess().getSyntaxExpressionParserRuleCall_4_2());
                    			
                    pushFollow(FOLLOW_39);
                    ruleSyntaxExpression();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_76); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getPropertyStructAccess().getSEMICOLONTerminalRuleCall_5());
            		
            otherlv_8=(Token)match(input,148,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getPropertyStructAccess().getRKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyStruct"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:4340:1: entryRuleInputParam returns [EObject current=null] : iv_ruleInputParam= ruleInputParam EOF ;
    public final EObject entryRuleInputParam() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputParam = null;


        try {
            // InternalSM2.g:4340:51: (iv_ruleInputParam= ruleInputParam EOF )
            // InternalSM2.g:4341:2: iv_ruleInputParam= ruleInputParam EOF
            {
             newCompositeNode(grammarAccess.getInputParamRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputParam=ruleInputParam();

            state._fsp--;

             current =iv_ruleInputParam; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:4347:1: ruleInputParam returns [EObject current=null] : (this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )? ) ;
    public final EObject ruleInputParam() throws RecognitionException {
        EObject current = null;

        Token this_ID_1=null;
        Token this_COMMA_2=null;
        EObject this_SingularType_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4353:2: ( (this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )? ) )
            // InternalSM2.g:4354:2: (this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )? )
            {
            // InternalSM2.g:4354:2: (this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )? )
            // InternalSM2.g:4355:3: this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )?
            {

            			newCompositeNode(grammarAccess.getInputParamAccess().getSingularTypeParserRuleCall_0());
            		
            pushFollow(FOLLOW_17);
            this_SingularType_0=ruleSingularType();

            state._fsp--;


            			current = this_SingularType_0;
            			afterParserOrEnumRuleCall();
            		
            this_ID_1=(Token)match(input,RULE_ID,FOLLOW_79); 

            			newLeafNode(this_ID_1, grammarAccess.getInputParamAccess().getIDTerminalRuleCall_1());
            		
            // InternalSM2.g:4367:3: (this_COMMA_2= RULE_COMMA )?
            int alt121=2;
            int LA121_0 = input.LA(1);

            if ( (LA121_0==RULE_COMMA) ) {
                alt121=1;
            }
            switch (alt121) {
                case 1 :
                    // InternalSM2.g:4368:4: this_COMMA_2= RULE_COMMA
                    {
                    this_COMMA_2=(Token)match(input,RULE_COMMA,FOLLOW_2); 

                    				newLeafNode(this_COMMA_2, grammarAccess.getInputParamAccess().getCOMMATerminalRuleCall_2());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestrictionClause"
    // InternalSM2.g:4377:1: entryRuleRestrictionClause returns [EObject current=null] : iv_ruleRestrictionClause= ruleRestrictionClause EOF ;
    public final EObject entryRuleRestrictionClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionClause = null;


        try {
            // InternalSM2.g:4377:58: (iv_ruleRestrictionClause= ruleRestrictionClause EOF )
            // InternalSM2.g:4378:2: iv_ruleRestrictionClause= ruleRestrictionClause EOF
            {
             newCompositeNode(grammarAccess.getRestrictionClauseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionClause=ruleRestrictionClause();

            state._fsp--;

             current =iv_ruleRestrictionClause; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionClause"


    // $ANTLR start "ruleRestrictionClause"
    // InternalSM2.g:4384:1: ruleRestrictionClause returns [EObject current=null] : (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas ) ;
    public final EObject ruleRestrictionClause() throws RecognitionException {
        EObject current = null;

        EObject this_Restriction_0 = null;

        EObject this_RestrictionGas_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:4390:2: ( (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas ) )
            // InternalSM2.g:4391:2: (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas )
            {
            // InternalSM2.g:4391:2: (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas )
            int alt122=2;
            alt122 = dfa122.predict(input);
            switch (alt122) {
                case 1 :
                    // InternalSM2.g:4392:3: this_Restriction_0= ruleRestriction
                    {

                    			newCompositeNode(grammarAccess.getRestrictionClauseAccess().getRestrictionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Restriction_0=ruleRestriction();

                    state._fsp--;


                    			current = this_Restriction_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4401:3: this_RestrictionGas_1= ruleRestrictionGas
                    {

                    			newCompositeNode(grammarAccess.getRestrictionClauseAccess().getRestrictionGasParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_RestrictionGas_1=ruleRestrictionGas();

                    state._fsp--;


                    			current = this_RestrictionGas_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionClause"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:4413:1: entryRuleRestriction returns [EObject current=null] : iv_ruleRestriction= ruleRestriction EOF ;
    public final EObject entryRuleRestriction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestriction = null;


        try {
            // InternalSM2.g:4413:52: (iv_ruleRestriction= ruleRestriction EOF )
            // InternalSM2.g:4414:2: iv_ruleRestriction= ruleRestriction EOF
            {
             newCompositeNode(grammarAccess.getRestrictionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestriction=ruleRestriction();

            state._fsp--;

             current =iv_ruleRestriction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:4420:1: ruleRestriction returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) ;
    public final EObject ruleRestriction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        AntlrDatatypeRuleToken lv_expr_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4426:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) )
            // InternalSM2.g:4427:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            {
            // InternalSM2.g:4427:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            // InternalSM2.g:4428:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,149,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getRestrictionAccess().getRequireKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_41); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:4436:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:4437:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:4437:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2.g:4438:5: lv_expr_2_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_80);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_2_0,
            						"org.xtext.SM2.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:4455:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:4456:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:4456:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:4457:5: lv_operator_3_0= ruleComparationOperator
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_41);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"operator",
            						lv_operator_3_0,
            						"org.xtext.SM2.ComparationOperator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:4474:3: ( (lv_expr_4_0= ruleSyntaxExpression ) )
            // InternalSM2.g:4475:4: (lv_expr_4_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:4475:4: (lv_expr_4_0= ruleSyntaxExpression )
            // InternalSM2.g:4476:5: lv_expr_4_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_10);
            lv_expr_4_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_4_0,
            						"org.xtext.SM2.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_39); 

            			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
            		
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6());
            		
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_7, grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:4509:1: entryRuleRestrictionGas returns [EObject current=null] : iv_ruleRestrictionGas= ruleRestrictionGas EOF ;
    public final EObject entryRuleRestrictionGas() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionGas = null;


        try {
            // InternalSM2.g:4509:55: (iv_ruleRestrictionGas= ruleRestrictionGas EOF )
            // InternalSM2.g:4510:2: iv_ruleRestrictionGas= ruleRestrictionGas EOF
            {
             newCompositeNode(grammarAccess.getRestrictionGasRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionGas=ruleRestrictionGas();

            state._fsp--;

             current =iv_ruleRestrictionGas; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:4516:1: ruleRestrictionGas returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) ;
    public final EObject ruleRestrictionGas() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_amount_4_0=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        AntlrDatatypeRuleToken lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        Enumerator lv_typeCoin_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4522:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) )
            // InternalSM2.g:4523:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            {
            // InternalSM2.g:4523:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            // InternalSM2.g:4524:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,149,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getRestrictionGasAccess().getRequireKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_41); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:4532:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:4533:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:4533:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2.g:4534:5: lv_expr_2_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_80);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_2_0,
            						"org.xtext.SM2.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:4551:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:4552:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:4552:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:4553:5: lv_operator_3_0= ruleComparationOperator
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_59);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"operator",
            						lv_operator_3_0,
            						"org.xtext.SM2.ComparationOperator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:4570:3: ( (lv_amount_4_0= RULE_INT ) )
            // InternalSM2.g:4571:4: (lv_amount_4_0= RULE_INT )
            {
            // InternalSM2.g:4571:4: (lv_amount_4_0= RULE_INT )
            // InternalSM2.g:4572:5: lv_amount_4_0= RULE_INT
            {
            lv_amount_4_0=(Token)match(input,RULE_INT,FOLLOW_81); 

            					newLeafNode(lv_amount_4_0, grammarAccess.getRestrictionGasAccess().getAmountINTTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRestrictionGasRule());
            					}
            					setWithLastConsumed(
            						current,
            						"amount",
            						lv_amount_4_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalSM2.g:4588:3: ( (lv_typeCoin_5_0= ruleCoin ) )
            // InternalSM2.g:4589:4: (lv_typeCoin_5_0= ruleCoin )
            {
            // InternalSM2.g:4589:4: (lv_typeCoin_5_0= ruleCoin )
            // InternalSM2.g:4590:5: lv_typeCoin_5_0= ruleCoin
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0());
            				
            pushFollow(FOLLOW_10);
            lv_typeCoin_5_0=ruleCoin();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"typeCoin",
            						lv_typeCoin_5_0,
            						"org.xtext.SM2.Coin");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_39); 

            			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
            		
            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7());
            		
            this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_8, grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2.g:4623:1: entryRuleClause returns [EObject current=null] : iv_ruleClause= ruleClause EOF ;
    public final EObject entryRuleClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClause = null;


        try {
            // InternalSM2.g:4623:47: (iv_ruleClause= ruleClause EOF )
            // InternalSM2.g:4624:2: iv_ruleClause= ruleClause EOF
            {
             newCompositeNode(grammarAccess.getClauseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleClause=ruleClause();

            state._fsp--;

             current =iv_ruleClause; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2.g:4630:1: ruleClause returns [EObject current=null] : (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ( (lv_visibilityAccess_5_0= ruleVisibility ) ) ( ( (lv_predefinedModifier_6_0= ruleInputModifier ) ) | ( (otherlv_7= RULE_ID ) ) )? this_OPENKEY_8= RULE_OPENKEY this_EOLINE_9= RULE_EOLINE ( (lv_restriction_10_0= ruleRestrictionClause ) )? ( (lv_expression_11_0= ruleExpression ) )? (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE ) ;
    public final EObject ruleClause() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token otherlv_7=null;
        Token this_OPENKEY_8=null;
        Token this_EOLINE_9=null;
        Token this_EOLINE_12=null;
        Token this_CLOSEKEY_13=null;
        Token this_EOLINE_14=null;
        EObject lv_inputParams_3_0 = null;

        Enumerator lv_visibilityAccess_5_0 = null;

        Enumerator lv_predefinedModifier_6_0 = null;

        EObject lv_restriction_10_0 = null;

        AntlrDatatypeRuleToken lv_expression_11_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4636:2: ( (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ( (lv_visibilityAccess_5_0= ruleVisibility ) ) ( ( (lv_predefinedModifier_6_0= ruleInputModifier ) ) | ( (otherlv_7= RULE_ID ) ) )? this_OPENKEY_8= RULE_OPENKEY this_EOLINE_9= RULE_EOLINE ( (lv_restriction_10_0= ruleRestrictionClause ) )? ( (lv_expression_11_0= ruleExpression ) )? (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE ) )
            // InternalSM2.g:4637:2: (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ( (lv_visibilityAccess_5_0= ruleVisibility ) ) ( ( (lv_predefinedModifier_6_0= ruleInputModifier ) ) | ( (otherlv_7= RULE_ID ) ) )? this_OPENKEY_8= RULE_OPENKEY this_EOLINE_9= RULE_EOLINE ( (lv_restriction_10_0= ruleRestrictionClause ) )? ( (lv_expression_11_0= ruleExpression ) )? (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE )
            {
            // InternalSM2.g:4637:2: (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ( (lv_visibilityAccess_5_0= ruleVisibility ) ) ( ( (lv_predefinedModifier_6_0= ruleInputModifier ) ) | ( (otherlv_7= RULE_ID ) ) )? this_OPENKEY_8= RULE_OPENKEY this_EOLINE_9= RULE_EOLINE ( (lv_restriction_10_0= ruleRestrictionClause ) )? ( (lv_expression_11_0= ruleExpression ) )? (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE )
            // InternalSM2.g:4638:3: otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ( (lv_visibilityAccess_5_0= ruleVisibility ) ) ( ( (lv_predefinedModifier_6_0= ruleInputModifier ) ) | ( (otherlv_7= RULE_ID ) ) )? this_OPENKEY_8= RULE_OPENKEY this_EOLINE_9= RULE_EOLINE ( (lv_restriction_10_0= ruleRestrictionClause ) )? ( (lv_expression_11_0= ruleExpression ) )? (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,150,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getClauseAccess().getFunctionKeyword_0());
            		
            // InternalSM2.g:4642:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSM2.g:4643:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSM2.g:4643:4: (lv_name_1_0= RULE_ID )
            // InternalSM2.g:4644:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_8); 

            					newLeafNode(lv_name_1_0, grammarAccess.getClauseAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getClauseRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_38); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		
            // InternalSM2.g:4664:3: ( (lv_inputParams_3_0= ruleInputParam ) )
            // InternalSM2.g:4665:4: (lv_inputParams_3_0= ruleInputParam )
            {
            // InternalSM2.g:4665:4: (lv_inputParams_3_0= ruleInputParam )
            // InternalSM2.g:4666:5: lv_inputParams_3_0= ruleInputParam
            {

            					newCompositeNode(grammarAccess.getClauseAccess().getInputParamsInputParamParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_10);
            lv_inputParams_3_0=ruleInputParam();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getClauseRule());
            					}
            					add(
            						current,
            						"inputParams",
            						lv_inputParams_3_0,
            						"org.xtext.SM2.InputParam");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_82); 

            			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
            		
            // InternalSM2.g:4687:3: ( (lv_visibilityAccess_5_0= ruleVisibility ) )
            // InternalSM2.g:4688:4: (lv_visibilityAccess_5_0= ruleVisibility )
            {
            // InternalSM2.g:4688:4: (lv_visibilityAccess_5_0= ruleVisibility )
            // InternalSM2.g:4689:5: lv_visibilityAccess_5_0= ruleVisibility
            {

            					newCompositeNode(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_5_0());
            				
            pushFollow(FOLLOW_83);
            lv_visibilityAccess_5_0=ruleVisibility();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getClauseRule());
            					}
            					set(
            						current,
            						"visibilityAccess",
            						lv_visibilityAccess_5_0,
            						"org.xtext.SM2.Visibility");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:4706:3: ( ( (lv_predefinedModifier_6_0= ruleInputModifier ) ) | ( (otherlv_7= RULE_ID ) ) )?
            int alt123=3;
            int LA123_0 = input.LA(1);

            if ( ((LA123_0>=159 && LA123_0<=161)) ) {
                alt123=1;
            }
            else if ( (LA123_0==RULE_ID) ) {
                alt123=2;
            }
            switch (alt123) {
                case 1 :
                    // InternalSM2.g:4707:4: ( (lv_predefinedModifier_6_0= ruleInputModifier ) )
                    {
                    // InternalSM2.g:4707:4: ( (lv_predefinedModifier_6_0= ruleInputModifier ) )
                    // InternalSM2.g:4708:5: (lv_predefinedModifier_6_0= ruleInputModifier )
                    {
                    // InternalSM2.g:4708:5: (lv_predefinedModifier_6_0= ruleInputModifier )
                    // InternalSM2.g:4709:6: lv_predefinedModifier_6_0= ruleInputModifier
                    {

                    						newCompositeNode(grammarAccess.getClauseAccess().getPredefinedModifierInputModifierEnumRuleCall_6_0_0());
                    					
                    pushFollow(FOLLOW_19);
                    lv_predefinedModifier_6_0=ruleInputModifier();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getClauseRule());
                    						}
                    						set(
                    							current,
                    							"predefinedModifier",
                    							lv_predefinedModifier_6_0,
                    							"org.xtext.SM2.InputModifier");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4727:4: ( (otherlv_7= RULE_ID ) )
                    {
                    // InternalSM2.g:4727:4: ( (otherlv_7= RULE_ID ) )
                    // InternalSM2.g:4728:5: (otherlv_7= RULE_ID )
                    {
                    // InternalSM2.g:4728:5: (otherlv_7= RULE_ID )
                    // InternalSM2.g:4729:6: otherlv_7= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getClauseRule());
                    						}
                    					
                    otherlv_7=(Token)match(input,RULE_ID,FOLLOW_19); 

                    						newLeafNode(otherlv_7, grammarAccess.getClauseAccess().getPersonalizedModifierModifierCrossReference_6_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            this_OPENKEY_8=(Token)match(input,RULE_OPENKEY,FOLLOW_12); 

            			newLeafNode(this_OPENKEY_8, grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_7());
            		
            this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_84); 

            			newLeafNode(this_EOLINE_9, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_8());
            		
            // InternalSM2.g:4749:3: ( (lv_restriction_10_0= ruleRestrictionClause ) )?
            int alt124=2;
            int LA124_0 = input.LA(1);

            if ( (LA124_0==149) ) {
                alt124=1;
            }
            switch (alt124) {
                case 1 :
                    // InternalSM2.g:4750:4: (lv_restriction_10_0= ruleRestrictionClause )
                    {
                    // InternalSM2.g:4750:4: (lv_restriction_10_0= ruleRestrictionClause )
                    // InternalSM2.g:4751:5: lv_restriction_10_0= ruleRestrictionClause
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getRestrictionRestrictionClauseParserRuleCall_9_0());
                    				
                    pushFollow(FOLLOW_85);
                    lv_restriction_10_0=ruleRestrictionClause();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"restriction",
                    						lv_restriction_10_0,
                    						"org.xtext.SM2.RestrictionClause");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:4768:3: ( (lv_expression_11_0= ruleExpression ) )?
            int alt125=2;
            int LA125_0 = input.LA(1);

            if ( (LA125_0==RULE_OPENPARENTHESIS||LA125_0==RULE_STRING||LA125_0==RULE_NEW||(LA125_0>=RULE_DELETE && LA125_0<=RULE_RETURNS)||LA125_0==158) ) {
                alt125=1;
            }
            switch (alt125) {
                case 1 :
                    // InternalSM2.g:4769:4: (lv_expression_11_0= ruleExpression )
                    {
                    // InternalSM2.g:4769:4: (lv_expression_11_0= ruleExpression )
                    // InternalSM2.g:4770:5: lv_expression_11_0= ruleExpression
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_10_0());
                    				
                    pushFollow(FOLLOW_56);
                    lv_expression_11_0=ruleExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"expression",
                    						lv_expression_11_0,
                    						"org.xtext.SM2.Expression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:4787:3: (this_EOLINE_12= RULE_EOLINE )?
            int alt126=2;
            int LA126_0 = input.LA(1);

            if ( (LA126_0==RULE_EOLINE) ) {
                alt126=1;
            }
            switch (alt126) {
                case 1 :
                    // InternalSM2.g:4788:4: this_EOLINE_12= RULE_EOLINE
                    {
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_34); 

                    				newLeafNode(this_EOLINE_12, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_11());
                    			

                    }
                    break;

            }

            this_CLOSEKEY_13=(Token)match(input,RULE_CLOSEKEY,FOLLOW_12); 

            			newLeafNode(this_CLOSEKEY_13, grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_12());
            		
            this_EOLINE_14=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_14, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRuleSelfdestruct"
    // InternalSM2.g:4805:1: entryRuleSelfdestruct returns [EObject current=null] : iv_ruleSelfdestruct= ruleSelfdestruct EOF ;
    public final EObject entryRuleSelfdestruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSelfdestruct = null;


        try {
            // InternalSM2.g:4805:53: (iv_ruleSelfdestruct= ruleSelfdestruct EOF )
            // InternalSM2.g:4806:2: iv_ruleSelfdestruct= ruleSelfdestruct EOF
            {
             newCompositeNode(grammarAccess.getSelfdestructRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSelfdestruct=ruleSelfdestruct();

            state._fsp--;

             current =iv_ruleSelfdestruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSelfdestruct"


    // $ANTLR start "ruleSelfdestruct"
    // InternalSM2.g:4812:1: ruleSelfdestruct returns [EObject current=null] : (otherlv_0= 'selfdestruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) ;
    public final EObject ruleSelfdestruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;


        	enterRule();

        try {
            // InternalSM2.g:4818:2: ( (otherlv_0= 'selfdestruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:4819:2: (otherlv_0= 'selfdestruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:4819:2: (otherlv_0= 'selfdestruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:4820:3: otherlv_0= 'selfdestruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,151,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getSelfdestructAccess().getSelfdestructKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_41); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getSelfdestructAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		

            			newCompositeNode(grammarAccess.getSelfdestructAccess().getSyntaxExpressionParserRuleCall_2());
            		
            pushFollow(FOLLOW_10);
            ruleSyntaxExpression();

            state._fsp--;


            			afterParserOrEnumRuleCall();
            		
            this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_39); 

            			newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getSelfdestructAccess().getCLOSEPARENTHESISTerminalRuleCall_3());
            		
            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_40); 

            			newLeafNode(this_SEMICOLON_4, grammarAccess.getSelfdestructAccess().getSEMICOLONTerminalRuleCall_4());
            		
            // InternalSM2.g:4843:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt127=2;
            int LA127_0 = input.LA(1);

            if ( (LA127_0==RULE_EOLINE) ) {
                alt127=1;
            }
            switch (alt127) {
                case 1 :
                    // InternalSM2.g:4844:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_5, grammarAccess.getSelfdestructAccess().getEOLINETerminalRuleCall_5());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSelfdestruct"


    // $ANTLR start "entryRuleCryptographycFunctions"
    // InternalSM2.g:4853:1: entryRuleCryptographycFunctions returns [EObject current=null] : iv_ruleCryptographycFunctions= ruleCryptographycFunctions EOF ;
    public final EObject entryRuleCryptographycFunctions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCryptographycFunctions = null;


        try {
            // InternalSM2.g:4853:63: (iv_ruleCryptographycFunctions= ruleCryptographycFunctions EOF )
            // InternalSM2.g:4854:2: iv_ruleCryptographycFunctions= ruleCryptographycFunctions EOF
            {
             newCompositeNode(grammarAccess.getCryptographycFunctionsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCryptographycFunctions=ruleCryptographycFunctions();

            state._fsp--;

             current =iv_ruleCryptographycFunctions; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCryptographycFunctions"


    // $ANTLR start "ruleCryptographycFunctions"
    // InternalSM2.g:4860:1: ruleCryptographycFunctions returns [EObject current=null] : ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? ) ) ;
    public final EObject ruleCryptographycFunctions() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_STRING_2=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token this_SEMICOLON_4=null;
        Token otherlv_5=null;
        Token this_OPENPARENTHESIS_6=null;
        Token this_STRING_7=null;
        Token this_CLOSEPARENTHESIS_8=null;
        Token this_SEMICOLON_9=null;
        Token otherlv_10=null;
        Token this_OPENPARENTHESIS_11=null;
        Token this_STRING_12=null;
        Token this_CLOSEPARENTHESIS_13=null;
        Token this_SEMICOLON_14=null;


        	enterRule();

        try {
            // InternalSM2.g:4866:2: ( ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? ) ) )
            // InternalSM2.g:4867:2: ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? ) )
            {
            // InternalSM2.g:4867:2: ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? ) )
            int alt131=3;
            switch ( input.LA(1) ) {
            case 152:
                {
                alt131=1;
                }
                break;
            case 153:
                {
                alt131=2;
                }
                break;
            case 154:
                {
                alt131=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 131, 0, input);

                throw nvae;
            }

            switch (alt131) {
                case 1 :
                    // InternalSM2.g:4868:3: (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:4868:3: (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? )
                    // InternalSM2.g:4869:4: otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )?
                    {
                    otherlv_0=(Token)match(input,152,FOLLOW_8); 

                    				newLeafNode(otherlv_0, grammarAccess.getCryptographycFunctionsAccess().getKeccack256Keyword_0_0());
                    			
                    this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_41); 

                    				newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_0_1());
                    			
                    this_STRING_2=(Token)match(input,RULE_STRING,FOLLOW_10); 

                    				newLeafNode(this_STRING_2, grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_0_2());
                    			
                    this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                    				newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_0_3());
                    			
                    // InternalSM2.g:4885:4: (this_SEMICOLON_4= RULE_SEMICOLON )?
                    int alt128=2;
                    int LA128_0 = input.LA(1);

                    if ( (LA128_0==RULE_SEMICOLON) ) {
                        alt128=1;
                    }
                    switch (alt128) {
                        case 1 :
                            // InternalSM2.g:4886:5: this_SEMICOLON_4= RULE_SEMICOLON
                            {
                            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_4, grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_0_4());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4893:3: (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:4893:3: (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? )
                    // InternalSM2.g:4894:4: otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )?
                    {
                    otherlv_5=(Token)match(input,153,FOLLOW_8); 

                    				newLeafNode(otherlv_5, grammarAccess.getCryptographycFunctionsAccess().getSha256Keyword_1_0());
                    			
                    this_OPENPARENTHESIS_6=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_41); 

                    				newLeafNode(this_OPENPARENTHESIS_6, grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_1_1());
                    			
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_10); 

                    				newLeafNode(this_STRING_7, grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_1_2());
                    			
                    this_CLOSEPARENTHESIS_8=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                    				newLeafNode(this_CLOSEPARENTHESIS_8, grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3());
                    			
                    // InternalSM2.g:4910:4: (this_SEMICOLON_9= RULE_SEMICOLON )?
                    int alt129=2;
                    int LA129_0 = input.LA(1);

                    if ( (LA129_0==RULE_SEMICOLON) ) {
                        alt129=1;
                    }
                    switch (alt129) {
                        case 1 :
                            // InternalSM2.g:4911:5: this_SEMICOLON_9= RULE_SEMICOLON
                            {
                            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_9, grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_1_4());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:4918:3: (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:4918:3: (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? )
                    // InternalSM2.g:4919:4: otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )?
                    {
                    otherlv_10=(Token)match(input,154,FOLLOW_8); 

                    				newLeafNode(otherlv_10, grammarAccess.getCryptographycFunctionsAccess().getSha3Keyword_2_0());
                    			
                    this_OPENPARENTHESIS_11=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_41); 

                    				newLeafNode(this_OPENPARENTHESIS_11, grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_2_1());
                    			
                    this_STRING_12=(Token)match(input,RULE_STRING,FOLLOW_10); 

                    				newLeafNode(this_STRING_12, grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_2_2());
                    			
                    this_CLOSEPARENTHESIS_13=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                    				newLeafNode(this_CLOSEPARENTHESIS_13, grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_2_3());
                    			
                    // InternalSM2.g:4935:4: (this_SEMICOLON_14= RULE_SEMICOLON )?
                    int alt130=2;
                    int LA130_0 = input.LA(1);

                    if ( (LA130_0==RULE_SEMICOLON) ) {
                        alt130=1;
                    }
                    switch (alt130) {
                        case 1 :
                            // InternalSM2.g:4936:5: this_SEMICOLON_14= RULE_SEMICOLON
                            {
                            this_SEMICOLON_14=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_14, grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_2_4());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCryptographycFunctions"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:4946:1: entryRuleComment returns [EObject current=null] : iv_ruleComment= ruleComment EOF ;
    public final EObject entryRuleComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleComment = null;


        try {
            // InternalSM2.g:4946:48: (iv_ruleComment= ruleComment EOF )
            // InternalSM2.g:4947:2: iv_ruleComment= ruleComment EOF
            {
             newCompositeNode(grammarAccess.getCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleComment=ruleComment();

            state._fsp--;

             current =iv_ruleComment; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:4953:1: ruleComment returns [EObject current=null] : ( ruleShortComment | this_LongComment_1= ruleLongComment ) ;
    public final EObject ruleComment() throws RecognitionException {
        EObject current = null;

        EObject this_LongComment_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:4959:2: ( ( ruleShortComment | this_LongComment_1= ruleLongComment ) )
            // InternalSM2.g:4960:2: ( ruleShortComment | this_LongComment_1= ruleLongComment )
            {
            // InternalSM2.g:4960:2: ( ruleShortComment | this_LongComment_1= ruleLongComment )
            int alt132=2;
            int LA132_0 = input.LA(1);

            if ( (LA132_0==155) ) {
                alt132=1;
            }
            else if ( (LA132_0==156) ) {
                alt132=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 132, 0, input);

                throw nvae;
            }
            switch (alt132) {
                case 1 :
                    // InternalSM2.g:4961:3: ruleShortComment
                    {

                    			newCompositeNode(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    ruleShortComment();

                    state._fsp--;


                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4969:3: this_LongComment_1= ruleLongComment
                    {

                    			newCompositeNode(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_LongComment_1=ruleLongComment();

                    state._fsp--;


                    			current = this_LongComment_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:4981:1: entryRuleShortComment returns [String current=null] : iv_ruleShortComment= ruleShortComment EOF ;
    public final String entryRuleShortComment() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleShortComment = null;


        try {
            // InternalSM2.g:4981:52: (iv_ruleShortComment= ruleShortComment EOF )
            // InternalSM2.g:4982:2: iv_ruleShortComment= ruleShortComment EOF
            {
             newCompositeNode(grammarAccess.getShortCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleShortComment=ruleShortComment();

            state._fsp--;

             current =iv_ruleShortComment.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:4988:1: ruleShortComment returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE ) ;
    public final AntlrDatatypeRuleToken ruleShortComment() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_STRING_1=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:4994:2: ( (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE ) )
            // InternalSM2.g:4995:2: (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE )
            {
            // InternalSM2.g:4995:2: (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE )
            // InternalSM2.g:4996:3: kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE
            {
            kw=(Token)match(input,155,FOLLOW_41); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0());
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_12); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getShortCommentAccess().getSTRINGTerminalRuleCall_1());
            		
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			current.merge(this_EOLINE_2);
            		

            			newLeafNode(this_EOLINE_2, grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:5019:1: entryRuleLongComment returns [EObject current=null] : iv_ruleLongComment= ruleLongComment EOF ;
    public final EObject entryRuleLongComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLongComment = null;


        try {
            // InternalSM2.g:5019:52: (iv_ruleLongComment= ruleLongComment EOF )
            // InternalSM2.g:5020:2: iv_ruleLongComment= ruleLongComment EOF
            {
             newCompositeNode(grammarAccess.getLongCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLongComment=ruleLongComment();

            state._fsp--;

             current =iv_ruleLongComment; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:5026:1: ruleLongComment returns [EObject current=null] : (otherlv_0= '/*' ( (lv_params_1_0= RULE_PARAMSLONGCOMENT ) ) ( (lv_title_2_0= RULE_TITLELONGCOMENT ) ) ( (lv_dev_3_0= RULE_DEVLONGCOMENT ) ) ( (lv_return_4_0= RULE_RETURNSLONGCOMENT ) ) otherlv_5= '*/' this_EOLINE_6= RULE_EOLINE ) ;
    public final EObject ruleLongComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_params_1_0=null;
        Token lv_title_2_0=null;
        Token lv_dev_3_0=null;
        Token lv_return_4_0=null;
        Token otherlv_5=null;
        Token this_EOLINE_6=null;


        	enterRule();

        try {
            // InternalSM2.g:5032:2: ( (otherlv_0= '/*' ( (lv_params_1_0= RULE_PARAMSLONGCOMENT ) ) ( (lv_title_2_0= RULE_TITLELONGCOMENT ) ) ( (lv_dev_3_0= RULE_DEVLONGCOMENT ) ) ( (lv_return_4_0= RULE_RETURNSLONGCOMENT ) ) otherlv_5= '*/' this_EOLINE_6= RULE_EOLINE ) )
            // InternalSM2.g:5033:2: (otherlv_0= '/*' ( (lv_params_1_0= RULE_PARAMSLONGCOMENT ) ) ( (lv_title_2_0= RULE_TITLELONGCOMENT ) ) ( (lv_dev_3_0= RULE_DEVLONGCOMENT ) ) ( (lv_return_4_0= RULE_RETURNSLONGCOMENT ) ) otherlv_5= '*/' this_EOLINE_6= RULE_EOLINE )
            {
            // InternalSM2.g:5033:2: (otherlv_0= '/*' ( (lv_params_1_0= RULE_PARAMSLONGCOMENT ) ) ( (lv_title_2_0= RULE_TITLELONGCOMENT ) ) ( (lv_dev_3_0= RULE_DEVLONGCOMENT ) ) ( (lv_return_4_0= RULE_RETURNSLONGCOMENT ) ) otherlv_5= '*/' this_EOLINE_6= RULE_EOLINE )
            // InternalSM2.g:5034:3: otherlv_0= '/*' ( (lv_params_1_0= RULE_PARAMSLONGCOMENT ) ) ( (lv_title_2_0= RULE_TITLELONGCOMENT ) ) ( (lv_dev_3_0= RULE_DEVLONGCOMENT ) ) ( (lv_return_4_0= RULE_RETURNSLONGCOMENT ) ) otherlv_5= '*/' this_EOLINE_6= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,156,FOLLOW_86); 

            			newLeafNode(otherlv_0, grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0());
            		
            // InternalSM2.g:5038:3: ( (lv_params_1_0= RULE_PARAMSLONGCOMENT ) )
            // InternalSM2.g:5039:4: (lv_params_1_0= RULE_PARAMSLONGCOMENT )
            {
            // InternalSM2.g:5039:4: (lv_params_1_0= RULE_PARAMSLONGCOMENT )
            // InternalSM2.g:5040:5: lv_params_1_0= RULE_PARAMSLONGCOMENT
            {
            lv_params_1_0=(Token)match(input,RULE_PARAMSLONGCOMENT,FOLLOW_87); 

            					newLeafNode(lv_params_1_0, grammarAccess.getLongCommentAccess().getParamsPARAMSLONGCOMENTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getLongCommentRule());
            					}
            					setWithLastConsumed(
            						current,
            						"params",
            						lv_params_1_0,
            						"org.xtext.SM2.PARAMSLONGCOMENT");
            				

            }


            }

            // InternalSM2.g:5056:3: ( (lv_title_2_0= RULE_TITLELONGCOMENT ) )
            // InternalSM2.g:5057:4: (lv_title_2_0= RULE_TITLELONGCOMENT )
            {
            // InternalSM2.g:5057:4: (lv_title_2_0= RULE_TITLELONGCOMENT )
            // InternalSM2.g:5058:5: lv_title_2_0= RULE_TITLELONGCOMENT
            {
            lv_title_2_0=(Token)match(input,RULE_TITLELONGCOMENT,FOLLOW_88); 

            					newLeafNode(lv_title_2_0, grammarAccess.getLongCommentAccess().getTitleTITLELONGCOMENTTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getLongCommentRule());
            					}
            					setWithLastConsumed(
            						current,
            						"title",
            						lv_title_2_0,
            						"org.xtext.SM2.TITLELONGCOMENT");
            				

            }


            }

            // InternalSM2.g:5074:3: ( (lv_dev_3_0= RULE_DEVLONGCOMENT ) )
            // InternalSM2.g:5075:4: (lv_dev_3_0= RULE_DEVLONGCOMENT )
            {
            // InternalSM2.g:5075:4: (lv_dev_3_0= RULE_DEVLONGCOMENT )
            // InternalSM2.g:5076:5: lv_dev_3_0= RULE_DEVLONGCOMENT
            {
            lv_dev_3_0=(Token)match(input,RULE_DEVLONGCOMENT,FOLLOW_89); 

            					newLeafNode(lv_dev_3_0, grammarAccess.getLongCommentAccess().getDevDEVLONGCOMENTTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getLongCommentRule());
            					}
            					setWithLastConsumed(
            						current,
            						"dev",
            						lv_dev_3_0,
            						"org.xtext.SM2.DEVLONGCOMENT");
            				

            }


            }

            // InternalSM2.g:5092:3: ( (lv_return_4_0= RULE_RETURNSLONGCOMENT ) )
            // InternalSM2.g:5093:4: (lv_return_4_0= RULE_RETURNSLONGCOMENT )
            {
            // InternalSM2.g:5093:4: (lv_return_4_0= RULE_RETURNSLONGCOMENT )
            // InternalSM2.g:5094:5: lv_return_4_0= RULE_RETURNSLONGCOMENT
            {
            lv_return_4_0=(Token)match(input,RULE_RETURNSLONGCOMENT,FOLLOW_90); 

            					newLeafNode(lv_return_4_0, grammarAccess.getLongCommentAccess().getReturnRETURNSLONGCOMENTTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getLongCommentRule());
            					}
            					setWithLastConsumed(
            						current,
            						"return",
            						lv_return_4_0,
            						"org.xtext.SM2.RETURNSLONGCOMENT");
            				

            }


            }

            otherlv_5=(Token)match(input,157,FOLLOW_12); 

            			newLeafNode(otherlv_5, grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_5());
            		
            this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_6, grammarAccess.getLongCommentAccess().getEOLINETerminalRuleCall_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:5122:1: entryRuleExpression returns [String current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final String entryRuleExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleExpression = null;


        try {
            // InternalSM2.g:5122:50: (iv_ruleExpression= ruleExpression EOF )
            // InternalSM2.g:5123:2: iv_ruleExpression= ruleExpression EOF
            {
             newCompositeNode(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;

             current =iv_ruleExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:5129:1: ruleExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression | this_CreateObjectExpression_2= ruleCreateObjectExpression | this_TupleExpression_3= ruleTupleExpression | this_DeleteExpression_4= ruleDeleteExpression | this_EmitEventExpression_5= ruleEmitEventExpression | this_ReturnExpression_6= ruleReturnExpression ) ;
    public final AntlrDatatypeRuleToken ruleExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        AntlrDatatypeRuleToken this_NegationExpression_0 = null;

        AntlrDatatypeRuleToken this_SyntaxExpression_1 = null;

        AntlrDatatypeRuleToken this_CreateObjectExpression_2 = null;

        AntlrDatatypeRuleToken this_TupleExpression_3 = null;

        AntlrDatatypeRuleToken this_DeleteExpression_4 = null;

        AntlrDatatypeRuleToken this_EmitEventExpression_5 = null;

        AntlrDatatypeRuleToken this_ReturnExpression_6 = null;



        	enterRule();

        try {
            // InternalSM2.g:5135:2: ( (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression | this_CreateObjectExpression_2= ruleCreateObjectExpression | this_TupleExpression_3= ruleTupleExpression | this_DeleteExpression_4= ruleDeleteExpression | this_EmitEventExpression_5= ruleEmitEventExpression | this_ReturnExpression_6= ruleReturnExpression ) )
            // InternalSM2.g:5136:2: (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression | this_CreateObjectExpression_2= ruleCreateObjectExpression | this_TupleExpression_3= ruleTupleExpression | this_DeleteExpression_4= ruleDeleteExpression | this_EmitEventExpression_5= ruleEmitEventExpression | this_ReturnExpression_6= ruleReturnExpression )
            {
            // InternalSM2.g:5136:2: (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression | this_CreateObjectExpression_2= ruleCreateObjectExpression | this_TupleExpression_3= ruleTupleExpression | this_DeleteExpression_4= ruleDeleteExpression | this_EmitEventExpression_5= ruleEmitEventExpression | this_ReturnExpression_6= ruleReturnExpression )
            int alt133=7;
            switch ( input.LA(1) ) {
            case 158:
                {
                alt133=1;
                }
                break;
            case RULE_STRING:
                {
                alt133=2;
                }
                break;
            case RULE_NEW:
                {
                alt133=3;
                }
                break;
            case RULE_OPENPARENTHESIS:
                {
                alt133=4;
                }
                break;
            case RULE_DELETE:
                {
                alt133=5;
                }
                break;
            case RULE_EMIT:
                {
                alt133=6;
                }
                break;
            case RULE_RETURNS:
                {
                alt133=7;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 133, 0, input);

                throw nvae;
            }

            switch (alt133) {
                case 1 :
                    // InternalSM2.g:5137:3: this_NegationExpression_0= ruleNegationExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getNegationExpressionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_NegationExpression_0=ruleNegationExpression();

                    state._fsp--;


                    			current.merge(this_NegationExpression_0);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:5148:3: this_SyntaxExpression_1= ruleSyntaxExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_SyntaxExpression_1=ruleSyntaxExpression();

                    state._fsp--;


                    			current.merge(this_SyntaxExpression_1);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:5159:3: this_CreateObjectExpression_2= ruleCreateObjectExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getCreateObjectExpressionParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_CreateObjectExpression_2=ruleCreateObjectExpression();

                    state._fsp--;


                    			current.merge(this_CreateObjectExpression_2);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:5170:3: this_TupleExpression_3= ruleTupleExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getTupleExpressionParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_TupleExpression_3=ruleTupleExpression();

                    state._fsp--;


                    			current.merge(this_TupleExpression_3);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:5181:3: this_DeleteExpression_4= ruleDeleteExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getDeleteExpressionParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_DeleteExpression_4=ruleDeleteExpression();

                    state._fsp--;


                    			current.merge(this_DeleteExpression_4);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalSM2.g:5192:3: this_EmitEventExpression_5= ruleEmitEventExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getEmitEventExpressionParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_EmitEventExpression_5=ruleEmitEventExpression();

                    state._fsp--;


                    			current.merge(this_EmitEventExpression_5);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 7 :
                    // InternalSM2.g:5203:3: this_ReturnExpression_6= ruleReturnExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getReturnExpressionParserRuleCall_6());
                    		
                    pushFollow(FOLLOW_2);
                    this_ReturnExpression_6=ruleReturnExpression();

                    state._fsp--;


                    			current.merge(this_ReturnExpression_6);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleLogicalUnaryOperator"
    // InternalSM2.g:5217:1: entryRuleLogicalUnaryOperator returns [String current=null] : iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF ;
    public final String entryRuleLogicalUnaryOperator() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleLogicalUnaryOperator = null;


        try {
            // InternalSM2.g:5217:60: (iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF )
            // InternalSM2.g:5218:2: iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF
            {
             newCompositeNode(grammarAccess.getLogicalUnaryOperatorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLogicalUnaryOperator=ruleLogicalUnaryOperator();

            state._fsp--;

             current =iv_ruleLogicalUnaryOperator.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLogicalUnaryOperator"


    // $ANTLR start "ruleLogicalUnaryOperator"
    // InternalSM2.g:5224:1: ruleLogicalUnaryOperator returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '!' ;
    public final AntlrDatatypeRuleToken ruleLogicalUnaryOperator() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSM2.g:5230:2: (kw= '!' )
            // InternalSM2.g:5231:2: kw= '!'
            {
            kw=(Token)match(input,158,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getLogicalUnaryOperatorAccess().getExclamationMarkKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalUnaryOperator"


    // $ANTLR start "entryRuleNegationExpression"
    // InternalSM2.g:5239:1: entryRuleNegationExpression returns [String current=null] : iv_ruleNegationExpression= ruleNegationExpression EOF ;
    public final String entryRuleNegationExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleNegationExpression = null;


        try {
            // InternalSM2.g:5239:58: (iv_ruleNegationExpression= ruleNegationExpression EOF )
            // InternalSM2.g:5240:2: iv_ruleNegationExpression= ruleNegationExpression EOF
            {
             newCompositeNode(grammarAccess.getNegationExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNegationExpression=ruleNegationExpression();

            state._fsp--;

             current =iv_ruleNegationExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNegationExpression"


    // $ANTLR start "ruleNegationExpression"
    // InternalSM2.g:5246:1: ruleNegationExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING ) ;
    public final AntlrDatatypeRuleToken ruleNegationExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_1=null;
        AntlrDatatypeRuleToken this_LogicalUnaryOperator_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:5252:2: ( (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING ) )
            // InternalSM2.g:5253:2: (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING )
            {
            // InternalSM2.g:5253:2: (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING )
            // InternalSM2.g:5254:3: this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING
            {

            			newCompositeNode(grammarAccess.getNegationExpressionAccess().getLogicalUnaryOperatorParserRuleCall_0());
            		
            pushFollow(FOLLOW_41);
            this_LogicalUnaryOperator_0=ruleLogicalUnaryOperator();

            state._fsp--;


            			current.merge(this_LogicalUnaryOperator_0);
            		

            			afterParserOrEnumRuleCall();
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_2); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getNegationExpressionAccess().getSTRINGTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNegationExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:5275:1: entryRuleSyntaxExpression returns [String current=null] : iv_ruleSyntaxExpression= ruleSyntaxExpression EOF ;
    public final String entryRuleSyntaxExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleSyntaxExpression = null;


        try {
            // InternalSM2.g:5275:56: (iv_ruleSyntaxExpression= ruleSyntaxExpression EOF )
            // InternalSM2.g:5276:2: iv_ruleSyntaxExpression= ruleSyntaxExpression EOF
            {
             newCompositeNode(grammarAccess.getSyntaxExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSyntaxExpression=ruleSyntaxExpression();

            state._fsp--;

             current =iv_ruleSyntaxExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:5282:1: ruleSyntaxExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? ) ;
    public final AntlrDatatypeRuleToken ruleSyntaxExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_SEMICOLON_1=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:5288:2: ( (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? ) )
            // InternalSM2.g:5289:2: (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? )
            {
            // InternalSM2.g:5289:2: (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? )
            // InternalSM2.g:5290:3: this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )?
            {
            this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

            			current.merge(this_STRING_0);
            		

            			newLeafNode(this_STRING_0, grammarAccess.getSyntaxExpressionAccess().getSTRINGTerminalRuleCall_0());
            		
            // InternalSM2.g:5297:3: (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )?
            int alt134=2;
            int LA134_0 = input.LA(1);

            if ( (LA134_0==RULE_SEMICOLON) ) {
                int LA134_1 = input.LA(2);

                if ( (LA134_1==RULE_EOLINE) ) {
                    int LA134_3 = input.LA(3);

                    if ( (LA134_3==EOF||(LA134_3>=RULE_OPENPARENTHESIS && LA134_3<=RULE_EOLINE)||LA134_3==RULE_CLOSEKEY||LA134_3==RULE_STRING||LA134_3==RULE_COMMA||LA134_3==RULE_NEW||(LA134_3>=RULE_DELETE && LA134_3<=RULE_RETURNS)||(LA134_3>=65 && LA134_3<=66)||(LA134_3>=107 && LA134_3<=108)||LA134_3==158||(LA134_3>=169 && LA134_3<=172)) ) {
                        alt134=1;
                    }
                }
            }
            switch (alt134) {
                case 1 :
                    // InternalSM2.g:5298:4: this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE
                    {
                    this_SEMICOLON_1=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

                    				current.merge(this_SEMICOLON_1);
                    			

                    				newLeafNode(this_SEMICOLON_1, grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_0());
                    			
                    this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				current.merge(this_EOLINE_2);
                    			

                    				newLeafNode(this_EOLINE_2, grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleCreateObjectExpression"
    // InternalSM2.g:5317:1: entryRuleCreateObjectExpression returns [String current=null] : iv_ruleCreateObjectExpression= ruleCreateObjectExpression EOF ;
    public final String entryRuleCreateObjectExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleCreateObjectExpression = null;


        try {
            // InternalSM2.g:5317:62: (iv_ruleCreateObjectExpression= ruleCreateObjectExpression EOF )
            // InternalSM2.g:5318:2: iv_ruleCreateObjectExpression= ruleCreateObjectExpression EOF
            {
             newCompositeNode(grammarAccess.getCreateObjectExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCreateObjectExpression=ruleCreateObjectExpression();

            state._fsp--;

             current =iv_ruleCreateObjectExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCreateObjectExpression"


    // $ANTLR start "ruleCreateObjectExpression"
    // InternalSM2.g:5324:1: ruleCreateObjectExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_NEW_0= RULE_NEW ( (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) ) ) ;
    public final AntlrDatatypeRuleToken ruleCreateObjectExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_NEW_0=null;
        Token this_ID_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENPARENTHESIS_7=null;
        Token this_CLOSEPARENTHESIS_9=null;
        AntlrDatatypeRuleToken this_Expression_3 = null;

        AntlrDatatypeRuleToken this_SyntaxExpression_5 = null;

        AntlrDatatypeRuleToken this_Array_6 = null;

        AntlrDatatypeRuleToken this_Expression_8 = null;



        	enterRule();

        try {
            // InternalSM2.g:5330:2: ( (this_NEW_0= RULE_NEW ( (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) ) ) )
            // InternalSM2.g:5331:2: (this_NEW_0= RULE_NEW ( (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) ) )
            {
            // InternalSM2.g:5331:2: (this_NEW_0= RULE_NEW ( (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) ) )
            // InternalSM2.g:5332:3: this_NEW_0= RULE_NEW ( (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) )
            {
            this_NEW_0=(Token)match(input,RULE_NEW,FOLLOW_91); 

            			current.merge(this_NEW_0);
            		

            			newLeafNode(this_NEW_0, grammarAccess.getCreateObjectExpressionAccess().getNEWTerminalRuleCall_0());
            		
            // InternalSM2.g:5339:3: ( (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) )
            int alt138=2;
            int LA138_0 = input.LA(1);

            if ( (LA138_0==RULE_ID) ) {
                alt138=1;
            }
            else if ( (LA138_0==RULE_STRING) ) {
                alt138=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 138, 0, input);

                throw nvae;
            }
            switch (alt138) {
                case 1 :
                    // InternalSM2.g:5340:4: (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:5340:4: (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:5341:5: this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_8); 

                    					current.merge(this_ID_1);
                    				

                    					newLeafNode(this_ID_1, grammarAccess.getCreateObjectExpressionAccess().getIDTerminalRuleCall_1_0_0());
                    				
                    this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_92); 

                    					current.merge(this_OPENPARENTHESIS_2);
                    				

                    					newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getCreateObjectExpressionAccess().getOPENPARENTHESISTerminalRuleCall_1_0_1());
                    				
                    // InternalSM2.g:5355:5: (this_Expression_3= ruleExpression )?
                    int alt135=2;
                    int LA135_0 = input.LA(1);

                    if ( (LA135_0==RULE_OPENPARENTHESIS||LA135_0==RULE_STRING||LA135_0==RULE_NEW||(LA135_0>=RULE_DELETE && LA135_0<=RULE_RETURNS)||LA135_0==158) ) {
                        alt135=1;
                    }
                    switch (alt135) {
                        case 1 :
                            // InternalSM2.g:5356:6: this_Expression_3= ruleExpression
                            {

                            						newCompositeNode(grammarAccess.getCreateObjectExpressionAccess().getExpressionParserRuleCall_1_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            this_Expression_3=ruleExpression();

                            state._fsp--;


                            						current.merge(this_Expression_3);
                            					

                            						afterParserOrEnumRuleCall();
                            					

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                    					current.merge(this_CLOSEPARENTHESIS_4);
                    				

                    					newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getCreateObjectExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_3());
                    				

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5376:4: ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:5376:4: ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:5377:5: (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS
                    {
                    // InternalSM2.g:5377:5: (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? )
                    // InternalSM2.g:5378:6: this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )?
                    {

                    						newCompositeNode(grammarAccess.getCreateObjectExpressionAccess().getSyntaxExpressionParserRuleCall_1_1_0_0());
                    					
                    pushFollow(FOLLOW_93);
                    this_SyntaxExpression_5=ruleSyntaxExpression();

                    state._fsp--;


                    						current.merge(this_SyntaxExpression_5);
                    					

                    						afterParserOrEnumRuleCall();
                    					
                    // InternalSM2.g:5388:6: (this_Array_6= ruleArray )?
                    int alt136=2;
                    int LA136_0 = input.LA(1);

                    if ( ((LA136_0>=107 && LA136_0<=108)) ) {
                        alt136=1;
                    }
                    switch (alt136) {
                        case 1 :
                            // InternalSM2.g:5389:7: this_Array_6= ruleArray
                            {

                            							newCompositeNode(grammarAccess.getCreateObjectExpressionAccess().getArrayParserRuleCall_1_1_0_1());
                            						
                            pushFollow(FOLLOW_8);
                            this_Array_6=ruleArray();

                            state._fsp--;


                            							current.merge(this_Array_6);
                            						

                            							afterParserOrEnumRuleCall();
                            						

                            }
                            break;

                    }


                    }

                    this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_92); 

                    					current.merge(this_OPENPARENTHESIS_7);
                    				

                    					newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getCreateObjectExpressionAccess().getOPENPARENTHESISTerminalRuleCall_1_1_1());
                    				
                    // InternalSM2.g:5408:5: (this_Expression_8= ruleExpression )?
                    int alt137=2;
                    int LA137_0 = input.LA(1);

                    if ( (LA137_0==RULE_OPENPARENTHESIS||LA137_0==RULE_STRING||LA137_0==RULE_NEW||(LA137_0>=RULE_DELETE && LA137_0<=RULE_RETURNS)||LA137_0==158) ) {
                        alt137=1;
                    }
                    switch (alt137) {
                        case 1 :
                            // InternalSM2.g:5409:6: this_Expression_8= ruleExpression
                            {

                            						newCompositeNode(grammarAccess.getCreateObjectExpressionAccess().getExpressionParserRuleCall_1_1_2());
                            					
                            pushFollow(FOLLOW_10);
                            this_Expression_8=ruleExpression();

                            state._fsp--;


                            						current.merge(this_Expression_8);
                            					

                            						afterParserOrEnumRuleCall();
                            					

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_9=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                    					current.merge(this_CLOSEPARENTHESIS_9);
                    				

                    					newLeafNode(this_CLOSEPARENTHESIS_9, grammarAccess.getCreateObjectExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_3());
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCreateObjectExpression"


    // $ANTLR start "entryRuleDeleteExpression"
    // InternalSM2.g:5433:1: entryRuleDeleteExpression returns [String current=null] : iv_ruleDeleteExpression= ruleDeleteExpression EOF ;
    public final String entryRuleDeleteExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleDeleteExpression = null;


        try {
            // InternalSM2.g:5433:56: (iv_ruleDeleteExpression= ruleDeleteExpression EOF )
            // InternalSM2.g:5434:2: iv_ruleDeleteExpression= ruleDeleteExpression EOF
            {
             newCompositeNode(grammarAccess.getDeleteExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDeleteExpression=ruleDeleteExpression();

            state._fsp--;

             current =iv_ruleDeleteExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDeleteExpression"


    // $ANTLR start "ruleDeleteExpression"
    // InternalSM2.g:5440:1: ruleDeleteExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_DELETE_0= RULE_DELETE this_SyntaxExpression_1= ruleSyntaxExpression ) ;
    public final AntlrDatatypeRuleToken ruleDeleteExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_DELETE_0=null;
        AntlrDatatypeRuleToken this_SyntaxExpression_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:5446:2: ( (this_DELETE_0= RULE_DELETE this_SyntaxExpression_1= ruleSyntaxExpression ) )
            // InternalSM2.g:5447:2: (this_DELETE_0= RULE_DELETE this_SyntaxExpression_1= ruleSyntaxExpression )
            {
            // InternalSM2.g:5447:2: (this_DELETE_0= RULE_DELETE this_SyntaxExpression_1= ruleSyntaxExpression )
            // InternalSM2.g:5448:3: this_DELETE_0= RULE_DELETE this_SyntaxExpression_1= ruleSyntaxExpression
            {
            this_DELETE_0=(Token)match(input,RULE_DELETE,FOLLOW_41); 

            			current.merge(this_DELETE_0);
            		

            			newLeafNode(this_DELETE_0, grammarAccess.getDeleteExpressionAccess().getDELETETerminalRuleCall_0());
            		

            			newCompositeNode(grammarAccess.getDeleteExpressionAccess().getSyntaxExpressionParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_SyntaxExpression_1=ruleSyntaxExpression();

            state._fsp--;


            			current.merge(this_SyntaxExpression_1);
            		

            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDeleteExpression"


    // $ANTLR start "entryRuleTupleExpression"
    // InternalSM2.g:5469:1: entryRuleTupleExpression returns [String current=null] : iv_ruleTupleExpression= ruleTupleExpression EOF ;
    public final String entryRuleTupleExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTupleExpression = null;


        try {
            // InternalSM2.g:5469:55: (iv_ruleTupleExpression= ruleTupleExpression EOF )
            // InternalSM2.g:5470:2: iv_ruleTupleExpression= ruleTupleExpression EOF
            {
             newCompositeNode(grammarAccess.getTupleExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTupleExpression=ruleTupleExpression();

            state._fsp--;

             current =iv_ruleTupleExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTupleExpression"


    // $ANTLR start "ruleTupleExpression"
    // InternalSM2.g:5476:1: ruleTupleExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS (this_Expression_1= ruleExpression (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS ) ;
    public final AntlrDatatypeRuleToken ruleTupleExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_OPENPARENTHESIS_0=null;
        Token this_COMMA_2=null;
        Token this_CLOSEPARENTHESIS_3=null;
        AntlrDatatypeRuleToken this_Expression_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:5482:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS (this_Expression_1= ruleExpression (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:5483:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS (this_Expression_1= ruleExpression (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:5483:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS (this_Expression_1= ruleExpression (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:5484:3: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS (this_Expression_1= ruleExpression (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS
            {
            this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

            			current.merge(this_OPENPARENTHESIS_0);
            		

            			newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getTupleExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0());
            		
            // InternalSM2.g:5491:3: (this_Expression_1= ruleExpression (this_COMMA_2= RULE_COMMA )? )+
            int cnt140=0;
            loop140:
            do {
                int alt140=2;
                int LA140_0 = input.LA(1);

                if ( (LA140_0==RULE_OPENPARENTHESIS||LA140_0==RULE_STRING||LA140_0==RULE_NEW||(LA140_0>=RULE_DELETE && LA140_0<=RULE_RETURNS)||LA140_0==158) ) {
                    alt140=1;
                }


                switch (alt140) {
            	case 1 :
            	    // InternalSM2.g:5492:4: this_Expression_1= ruleExpression (this_COMMA_2= RULE_COMMA )?
            	    {

            	    				newCompositeNode(grammarAccess.getTupleExpressionAccess().getExpressionParserRuleCall_1_0());
            	    			
            	    pushFollow(FOLLOW_94);
            	    this_Expression_1=ruleExpression();

            	    state._fsp--;


            	    				current.merge(this_Expression_1);
            	    			

            	    				afterParserOrEnumRuleCall();
            	    			
            	    // InternalSM2.g:5502:4: (this_COMMA_2= RULE_COMMA )?
            	    int alt139=2;
            	    int LA139_0 = input.LA(1);

            	    if ( (LA139_0==RULE_COMMA) ) {
            	        alt139=1;
            	    }
            	    switch (alt139) {
            	        case 1 :
            	            // InternalSM2.g:5503:5: this_COMMA_2= RULE_COMMA
            	            {
            	            this_COMMA_2=(Token)match(input,RULE_COMMA,FOLLOW_92); 

            	            					current.merge(this_COMMA_2);
            	            				

            	            					newLeafNode(this_COMMA_2, grammarAccess.getTupleExpressionAccess().getCOMMATerminalRuleCall_1_1());
            	            				

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt140 >= 1 ) break loop140;
                        EarlyExitException eee =
                            new EarlyExitException(140, input);
                        throw eee;
                }
                cnt140++;
            } while (true);

            this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

            			current.merge(this_CLOSEPARENTHESIS_3);
            		

            			newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getTupleExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTupleExpression"


    // $ANTLR start "entryRuleEmitEventExpression"
    // InternalSM2.g:5523:1: entryRuleEmitEventExpression returns [String current=null] : iv_ruleEmitEventExpression= ruleEmitEventExpression EOF ;
    public final String entryRuleEmitEventExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEmitEventExpression = null;


        try {
            // InternalSM2.g:5523:59: (iv_ruleEmitEventExpression= ruleEmitEventExpression EOF )
            // InternalSM2.g:5524:2: iv_ruleEmitEventExpression= ruleEmitEventExpression EOF
            {
             newCompositeNode(grammarAccess.getEmitEventExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEmitEventExpression=ruleEmitEventExpression();

            state._fsp--;

             current =iv_ruleEmitEventExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEmitEventExpression"


    // $ANTLR start "ruleEmitEventExpression"
    // InternalSM2.g:5530:1: ruleEmitEventExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_EMIT_0= RULE_EMIT this_SyntaxExpression_1= ruleSyntaxExpression ) ;
    public final AntlrDatatypeRuleToken ruleEmitEventExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_EMIT_0=null;
        AntlrDatatypeRuleToken this_SyntaxExpression_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:5536:2: ( (this_EMIT_0= RULE_EMIT this_SyntaxExpression_1= ruleSyntaxExpression ) )
            // InternalSM2.g:5537:2: (this_EMIT_0= RULE_EMIT this_SyntaxExpression_1= ruleSyntaxExpression )
            {
            // InternalSM2.g:5537:2: (this_EMIT_0= RULE_EMIT this_SyntaxExpression_1= ruleSyntaxExpression )
            // InternalSM2.g:5538:3: this_EMIT_0= RULE_EMIT this_SyntaxExpression_1= ruleSyntaxExpression
            {
            this_EMIT_0=(Token)match(input,RULE_EMIT,FOLLOW_41); 

            			current.merge(this_EMIT_0);
            		

            			newLeafNode(this_EMIT_0, grammarAccess.getEmitEventExpressionAccess().getEMITTerminalRuleCall_0());
            		

            			newCompositeNode(grammarAccess.getEmitEventExpressionAccess().getSyntaxExpressionParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_SyntaxExpression_1=ruleSyntaxExpression();

            state._fsp--;


            			current.merge(this_SyntaxExpression_1);
            		

            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEmitEventExpression"


    // $ANTLR start "entryRuleReturnExpression"
    // InternalSM2.g:5559:1: entryRuleReturnExpression returns [String current=null] : iv_ruleReturnExpression= ruleReturnExpression EOF ;
    public final String entryRuleReturnExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleReturnExpression = null;


        try {
            // InternalSM2.g:5559:56: (iv_ruleReturnExpression= ruleReturnExpression EOF )
            // InternalSM2.g:5560:2: iv_ruleReturnExpression= ruleReturnExpression EOF
            {
             newCompositeNode(grammarAccess.getReturnExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleReturnExpression=ruleReturnExpression();

            state._fsp--;

             current =iv_ruleReturnExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleReturnExpression"


    // $ANTLR start "ruleReturnExpression"
    // InternalSM2.g:5566:1: ruleReturnExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_RETURNS_0= RULE_RETURNS this_SyntaxExpression_1= ruleSyntaxExpression ) ;
    public final AntlrDatatypeRuleToken ruleReturnExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_RETURNS_0=null;
        AntlrDatatypeRuleToken this_SyntaxExpression_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:5572:2: ( (this_RETURNS_0= RULE_RETURNS this_SyntaxExpression_1= ruleSyntaxExpression ) )
            // InternalSM2.g:5573:2: (this_RETURNS_0= RULE_RETURNS this_SyntaxExpression_1= ruleSyntaxExpression )
            {
            // InternalSM2.g:5573:2: (this_RETURNS_0= RULE_RETURNS this_SyntaxExpression_1= ruleSyntaxExpression )
            // InternalSM2.g:5574:3: this_RETURNS_0= RULE_RETURNS this_SyntaxExpression_1= ruleSyntaxExpression
            {
            this_RETURNS_0=(Token)match(input,RULE_RETURNS,FOLLOW_41); 

            			current.merge(this_RETURNS_0);
            		

            			newLeafNode(this_RETURNS_0, grammarAccess.getReturnExpressionAccess().getRETURNSTerminalRuleCall_0());
            		

            			newCompositeNode(grammarAccess.getReturnExpressionAccess().getSyntaxExpressionParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_SyntaxExpression_1=ruleSyntaxExpression();

            state._fsp--;


            			current.merge(this_SyntaxExpression_1);
            		

            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleReturnExpression"


    // $ANTLR start "ruleInputModifier"
    // InternalSM2.g:5595:1: ruleInputModifier returns [Enumerator current=null] : ( (enumLiteral_0= 'view' ) | (enumLiteral_1= 'pure' ) | (enumLiteral_2= 'payable' ) ) ;
    public final Enumerator ruleInputModifier() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalSM2.g:5601:2: ( ( (enumLiteral_0= 'view' ) | (enumLiteral_1= 'pure' ) | (enumLiteral_2= 'payable' ) ) )
            // InternalSM2.g:5602:2: ( (enumLiteral_0= 'view' ) | (enumLiteral_1= 'pure' ) | (enumLiteral_2= 'payable' ) )
            {
            // InternalSM2.g:5602:2: ( (enumLiteral_0= 'view' ) | (enumLiteral_1= 'pure' ) | (enumLiteral_2= 'payable' ) )
            int alt141=3;
            switch ( input.LA(1) ) {
            case 159:
                {
                alt141=1;
                }
                break;
            case 160:
                {
                alt141=2;
                }
                break;
            case 161:
                {
                alt141=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 141, 0, input);

                throw nvae;
            }

            switch (alt141) {
                case 1 :
                    // InternalSM2.g:5603:3: (enumLiteral_0= 'view' )
                    {
                    // InternalSM2.g:5603:3: (enumLiteral_0= 'view' )
                    // InternalSM2.g:5604:4: enumLiteral_0= 'view'
                    {
                    enumLiteral_0=(Token)match(input,159,FOLLOW_2); 

                    				current = grammarAccess.getInputModifierAccess().getVIEWEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getInputModifierAccess().getVIEWEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5611:3: (enumLiteral_1= 'pure' )
                    {
                    // InternalSM2.g:5611:3: (enumLiteral_1= 'pure' )
                    // InternalSM2.g:5612:4: enumLiteral_1= 'pure'
                    {
                    enumLiteral_1=(Token)match(input,160,FOLLOW_2); 

                    				current = grammarAccess.getInputModifierAccess().getPUREEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getInputModifierAccess().getPUREEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5619:3: (enumLiteral_2= 'payable' )
                    {
                    // InternalSM2.g:5619:3: (enumLiteral_2= 'payable' )
                    // InternalSM2.g:5620:4: enumLiteral_2= 'payable'
                    {
                    enumLiteral_2=(Token)match(input,161,FOLLOW_2); 

                    				current = grammarAccess.getInputModifierAccess().getPAYABLEEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getInputModifierAccess().getPAYABLEEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputModifier"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:5630:1: ruleVisibility returns [Enumerator current=null] : ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) ) ;
    public final Enumerator ruleVisibility() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalSM2.g:5636:2: ( ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) ) )
            // InternalSM2.g:5637:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) )
            {
            // InternalSM2.g:5637:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) )
            int alt142=3;
            switch ( input.LA(1) ) {
            case 68:
                {
                alt142=1;
                }
                break;
            case 162:
                {
                alt142=2;
                }
                break;
            case 69:
                {
                alt142=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 142, 0, input);

                throw nvae;
            }

            switch (alt142) {
                case 1 :
                    // InternalSM2.g:5638:3: (enumLiteral_0= 'public' )
                    {
                    // InternalSM2.g:5638:3: (enumLiteral_0= 'public' )
                    // InternalSM2.g:5639:4: enumLiteral_0= 'public'
                    {
                    enumLiteral_0=(Token)match(input,68,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5646:3: (enumLiteral_1= 'private' )
                    {
                    // InternalSM2.g:5646:3: (enumLiteral_1= 'private' )
                    // InternalSM2.g:5647:4: enumLiteral_1= 'private'
                    {
                    enumLiteral_1=(Token)match(input,162,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5654:3: (enumLiteral_2= 'internal' )
                    {
                    // InternalSM2.g:5654:3: (enumLiteral_2= 'internal' )
                    // InternalSM2.g:5655:4: enumLiteral_2= 'internal'
                    {
                    enumLiteral_2=(Token)match(input,69,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:5665:1: ruleCoin returns [Enumerator current=null] : ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) ;
    public final Enumerator ruleCoin() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:5671:2: ( ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) )
            // InternalSM2.g:5672:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            {
            // InternalSM2.g:5672:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            int alt143=6;
            switch ( input.LA(1) ) {
            case 163:
                {
                alt143=1;
                }
                break;
            case 164:
                {
                alt143=2;
                }
                break;
            case 165:
                {
                alt143=3;
                }
                break;
            case 166:
                {
                alt143=4;
                }
                break;
            case 167:
                {
                alt143=5;
                }
                break;
            case 168:
                {
                alt143=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 143, 0, input);

                throw nvae;
            }

            switch (alt143) {
                case 1 :
                    // InternalSM2.g:5673:3: (enumLiteral_0= 'ether' )
                    {
                    // InternalSM2.g:5673:3: (enumLiteral_0= 'ether' )
                    // InternalSM2.g:5674:4: enumLiteral_0= 'ether'
                    {
                    enumLiteral_0=(Token)match(input,163,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5681:3: (enumLiteral_1= 'wei' )
                    {
                    // InternalSM2.g:5681:3: (enumLiteral_1= 'wei' )
                    // InternalSM2.g:5682:4: enumLiteral_1= 'wei'
                    {
                    enumLiteral_1=(Token)match(input,164,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5689:3: (enumLiteral_2= 'gwei' )
                    {
                    // InternalSM2.g:5689:3: (enumLiteral_2= 'gwei' )
                    // InternalSM2.g:5690:4: enumLiteral_2= 'gwei'
                    {
                    enumLiteral_2=(Token)match(input,165,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:5697:3: (enumLiteral_3= 'pwei' )
                    {
                    // InternalSM2.g:5697:3: (enumLiteral_3= 'pwei' )
                    // InternalSM2.g:5698:4: enumLiteral_3= 'pwei'
                    {
                    enumLiteral_3=(Token)match(input,166,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:5705:3: (enumLiteral_4= 'finney' )
                    {
                    // InternalSM2.g:5705:3: (enumLiteral_4= 'finney' )
                    // InternalSM2.g:5706:4: enumLiteral_4= 'finney'
                    {
                    enumLiteral_4=(Token)match(input,167,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:5713:3: (enumLiteral_5= 'szabo' )
                    {
                    // InternalSM2.g:5713:3: (enumLiteral_5= 'szabo' )
                    // InternalSM2.g:5714:4: enumLiteral_5= 'szabo'
                    {
                    enumLiteral_5=(Token)match(input,168,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:5724:1: ruleComparationOperator returns [Enumerator current=null] : ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) ;
    public final Enumerator ruleComparationOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:5730:2: ( ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) )
            // InternalSM2.g:5731:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            {
            // InternalSM2.g:5731:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            int alt144=6;
            switch ( input.LA(1) ) {
            case 65:
                {
                alt144=1;
                }
                break;
            case 169:
                {
                alt144=2;
                }
                break;
            case 66:
                {
                alt144=3;
                }
                break;
            case 170:
                {
                alt144=4;
                }
                break;
            case 171:
                {
                alt144=5;
                }
                break;
            case 172:
                {
                alt144=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 144, 0, input);

                throw nvae;
            }

            switch (alt144) {
                case 1 :
                    // InternalSM2.g:5732:3: (enumLiteral_0= '>' )
                    {
                    // InternalSM2.g:5732:3: (enumLiteral_0= '>' )
                    // InternalSM2.g:5733:4: enumLiteral_0= '>'
                    {
                    enumLiteral_0=(Token)match(input,65,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5740:3: (enumLiteral_1= '<' )
                    {
                    // InternalSM2.g:5740:3: (enumLiteral_1= '<' )
                    // InternalSM2.g:5741:4: enumLiteral_1= '<'
                    {
                    enumLiteral_1=(Token)match(input,169,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5748:3: (enumLiteral_2= '>=' )
                    {
                    // InternalSM2.g:5748:3: (enumLiteral_2= '>=' )
                    // InternalSM2.g:5749:4: enumLiteral_2= '>='
                    {
                    enumLiteral_2=(Token)match(input,66,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:5756:3: (enumLiteral_3= '<=' )
                    {
                    // InternalSM2.g:5756:3: (enumLiteral_3= '<=' )
                    // InternalSM2.g:5757:4: enumLiteral_3= '<='
                    {
                    enumLiteral_3=(Token)match(input,170,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:5764:3: (enumLiteral_4= '==' )
                    {
                    // InternalSM2.g:5764:3: (enumLiteral_4= '==' )
                    // InternalSM2.g:5765:4: enumLiteral_4= '=='
                    {
                    enumLiteral_4=(Token)match(input,171,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:5772:3: (enumLiteral_5= '!=' )
                    {
                    // InternalSM2.g:5772:3: (enumLiteral_5= '!=' )
                    // InternalSM2.g:5773:4: enumLiteral_5= '!='
                    {
                    enumLiteral_5=(Token)match(input,172,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:5783:1: ruleLogicalPairOperator returns [Enumerator current=null] : ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) ;
    public final Enumerator ruleLogicalPairOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSM2.g:5789:2: ( ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) )
            // InternalSM2.g:5790:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            {
            // InternalSM2.g:5790:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            int alt145=2;
            int LA145_0 = input.LA(1);

            if ( (LA145_0==173) ) {
                alt145=1;
            }
            else if ( (LA145_0==174) ) {
                alt145=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 145, 0, input);

                throw nvae;
            }
            switch (alt145) {
                case 1 :
                    // InternalSM2.g:5791:3: (enumLiteral_0= '&&' )
                    {
                    // InternalSM2.g:5791:3: (enumLiteral_0= '&&' )
                    // InternalSM2.g:5792:4: enumLiteral_0= '&&'
                    {
                    enumLiteral_0=(Token)match(input,173,FOLLOW_2); 

                    				current = grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5799:3: (enumLiteral_1= '||' )
                    {
                    // InternalSM2.g:5799:3: (enumLiteral_1= '||' )
                    // InternalSM2.g:5800:4: enumLiteral_1= '||'
                    {
                    enumLiteral_1=(Token)match(input,174,FOLLOW_2); 

                    				current = grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:5810:1: ruleArithmeticalOperator returns [Enumerator current=null] : ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) ;
    public final Enumerator ruleArithmeticalOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;


        	enterRule();

        try {
            // InternalSM2.g:5816:2: ( ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) )
            // InternalSM2.g:5817:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            {
            // InternalSM2.g:5817:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            int alt146=5;
            switch ( input.LA(1) ) {
            case 175:
                {
                alt146=1;
                }
                break;
            case 176:
                {
                alt146=2;
                }
                break;
            case 177:
                {
                alt146=3;
                }
                break;
            case 178:
                {
                alt146=4;
                }
                break;
            case 179:
                {
                alt146=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 146, 0, input);

                throw nvae;
            }

            switch (alt146) {
                case 1 :
                    // InternalSM2.g:5818:3: (enumLiteral_0= '+' )
                    {
                    // InternalSM2.g:5818:3: (enumLiteral_0= '+' )
                    // InternalSM2.g:5819:4: enumLiteral_0= '+'
                    {
                    enumLiteral_0=(Token)match(input,175,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5826:3: (enumLiteral_1= '-' )
                    {
                    // InternalSM2.g:5826:3: (enumLiteral_1= '-' )
                    // InternalSM2.g:5827:4: enumLiteral_1= '-'
                    {
                    enumLiteral_1=(Token)match(input,176,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5834:3: (enumLiteral_2= '*' )
                    {
                    // InternalSM2.g:5834:3: (enumLiteral_2= '*' )
                    // InternalSM2.g:5835:4: enumLiteral_2= '*'
                    {
                    enumLiteral_2=(Token)match(input,177,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:5842:3: (enumLiteral_3= '/' )
                    {
                    // InternalSM2.g:5842:3: (enumLiteral_3= '/' )
                    // InternalSM2.g:5843:4: enumLiteral_3= '/'
                    {
                    enumLiteral_3=(Token)match(input,178,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:5850:3: (enumLiteral_4= '%' )
                    {
                    // InternalSM2.g:5850:3: (enumLiteral_4= '%' )
                    // InternalSM2.g:5851:4: enumLiteral_4= '%'
                    {
                    enumLiteral_4=(Token)match(input,179,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmeticalOperator"


    // $ANTLR start "ruleBasicType"
    // InternalSM2.g:5861:1: ruleBasicType returns [Enumerator current=null] : ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint2' ) | (enumLiteral_3= 'uint4' ) | (enumLiteral_4= 'uint8' ) | (enumLiteral_5= 'uint16' ) | (enumLiteral_6= 'uint24' ) | (enumLiteral_7= 'uint32' ) | (enumLiteral_8= 'uint64' ) | (enumLiteral_9= 'uint128' ) | (enumLiteral_10= 'uint160' ) | (enumLiteral_11= 'uint256' ) | (enumLiteral_12= 'string' ) | (enumLiteral_13= 'address' ) | (enumLiteral_14= 'address payable' ) | (enumLiteral_15= 'double' ) | (enumLiteral_16= 'bool' ) | (enumLiteral_17= 'byte' ) | (enumLiteral_18= 'bytes2' ) | (enumLiteral_19= 'bytes3' ) | (enumLiteral_20= 'bytes4' ) | (enumLiteral_21= 'bytes5' ) | (enumLiteral_22= 'bytes6' ) | (enumLiteral_23= 'bytes7' ) | (enumLiteral_24= 'bytes8' ) | (enumLiteral_25= 'bytes16' ) | (enumLiteral_26= 'bytes32' ) ) ;
    public final Enumerator ruleBasicType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;
        Token enumLiteral_8=null;
        Token enumLiteral_9=null;
        Token enumLiteral_10=null;
        Token enumLiteral_11=null;
        Token enumLiteral_12=null;
        Token enumLiteral_13=null;
        Token enumLiteral_14=null;
        Token enumLiteral_15=null;
        Token enumLiteral_16=null;
        Token enumLiteral_17=null;
        Token enumLiteral_18=null;
        Token enumLiteral_19=null;
        Token enumLiteral_20=null;
        Token enumLiteral_21=null;
        Token enumLiteral_22=null;
        Token enumLiteral_23=null;
        Token enumLiteral_24=null;
        Token enumLiteral_25=null;
        Token enumLiteral_26=null;


        	enterRule();

        try {
            // InternalSM2.g:5867:2: ( ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint2' ) | (enumLiteral_3= 'uint4' ) | (enumLiteral_4= 'uint8' ) | (enumLiteral_5= 'uint16' ) | (enumLiteral_6= 'uint24' ) | (enumLiteral_7= 'uint32' ) | (enumLiteral_8= 'uint64' ) | (enumLiteral_9= 'uint128' ) | (enumLiteral_10= 'uint160' ) | (enumLiteral_11= 'uint256' ) | (enumLiteral_12= 'string' ) | (enumLiteral_13= 'address' ) | (enumLiteral_14= 'address payable' ) | (enumLiteral_15= 'double' ) | (enumLiteral_16= 'bool' ) | (enumLiteral_17= 'byte' ) | (enumLiteral_18= 'bytes2' ) | (enumLiteral_19= 'bytes3' ) | (enumLiteral_20= 'bytes4' ) | (enumLiteral_21= 'bytes5' ) | (enumLiteral_22= 'bytes6' ) | (enumLiteral_23= 'bytes7' ) | (enumLiteral_24= 'bytes8' ) | (enumLiteral_25= 'bytes16' ) | (enumLiteral_26= 'bytes32' ) ) )
            // InternalSM2.g:5868:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint2' ) | (enumLiteral_3= 'uint4' ) | (enumLiteral_4= 'uint8' ) | (enumLiteral_5= 'uint16' ) | (enumLiteral_6= 'uint24' ) | (enumLiteral_7= 'uint32' ) | (enumLiteral_8= 'uint64' ) | (enumLiteral_9= 'uint128' ) | (enumLiteral_10= 'uint160' ) | (enumLiteral_11= 'uint256' ) | (enumLiteral_12= 'string' ) | (enumLiteral_13= 'address' ) | (enumLiteral_14= 'address payable' ) | (enumLiteral_15= 'double' ) | (enumLiteral_16= 'bool' ) | (enumLiteral_17= 'byte' ) | (enumLiteral_18= 'bytes2' ) | (enumLiteral_19= 'bytes3' ) | (enumLiteral_20= 'bytes4' ) | (enumLiteral_21= 'bytes5' ) | (enumLiteral_22= 'bytes6' ) | (enumLiteral_23= 'bytes7' ) | (enumLiteral_24= 'bytes8' ) | (enumLiteral_25= 'bytes16' ) | (enumLiteral_26= 'bytes32' ) )
            {
            // InternalSM2.g:5868:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint2' ) | (enumLiteral_3= 'uint4' ) | (enumLiteral_4= 'uint8' ) | (enumLiteral_5= 'uint16' ) | (enumLiteral_6= 'uint24' ) | (enumLiteral_7= 'uint32' ) | (enumLiteral_8= 'uint64' ) | (enumLiteral_9= 'uint128' ) | (enumLiteral_10= 'uint160' ) | (enumLiteral_11= 'uint256' ) | (enumLiteral_12= 'string' ) | (enumLiteral_13= 'address' ) | (enumLiteral_14= 'address payable' ) | (enumLiteral_15= 'double' ) | (enumLiteral_16= 'bool' ) | (enumLiteral_17= 'byte' ) | (enumLiteral_18= 'bytes2' ) | (enumLiteral_19= 'bytes3' ) | (enumLiteral_20= 'bytes4' ) | (enumLiteral_21= 'bytes5' ) | (enumLiteral_22= 'bytes6' ) | (enumLiteral_23= 'bytes7' ) | (enumLiteral_24= 'bytes8' ) | (enumLiteral_25= 'bytes16' ) | (enumLiteral_26= 'bytes32' ) )
            int alt147=27;
            switch ( input.LA(1) ) {
            case 83:
                {
                alt147=1;
                }
                break;
            case 84:
                {
                alt147=2;
                }
                break;
            case 130:
                {
                alt147=3;
                }
                break;
            case 131:
                {
                alt147=4;
                }
                break;
            case 85:
                {
                alt147=5;
                }
                break;
            case 132:
                {
                alt147=6;
                }
                break;
            case 133:
                {
                alt147=7;
                }
                break;
            case 134:
                {
                alt147=8;
                }
                break;
            case 138:
                {
                alt147=9;
                }
                break;
            case 143:
                {
                alt147=10;
                }
                break;
            case 144:
                {
                alt147=11;
                }
                break;
            case 145:
                {
                alt147=12;
                }
                break;
            case 80:
                {
                alt147=13;
                }
                break;
            case 78:
                {
                alt147=14;
                }
                break;
            case 86:
                {
                alt147=15;
                }
                break;
            case 87:
                {
                alt147=16;
                }
                break;
            case 88:
                {
                alt147=17;
                }
                break;
            case 180:
                {
                alt147=18;
                }
                break;
            case 90:
                {
                alt147=19;
                }
                break;
            case 91:
                {
                alt147=20;
                }
                break;
            case 92:
                {
                alt147=21;
                }
                break;
            case 93:
                {
                alt147=22;
                }
                break;
            case 94:
                {
                alt147=23;
                }
                break;
            case 95:
                {
                alt147=24;
                }
                break;
            case 96:
                {
                alt147=25;
                }
                break;
            case 100:
                {
                alt147=26;
                }
                break;
            case 106:
                {
                alt147=27;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 147, 0, input);

                throw nvae;
            }

            switch (alt147) {
                case 1 :
                    // InternalSM2.g:5869:3: (enumLiteral_0= 'int' )
                    {
                    // InternalSM2.g:5869:3: (enumLiteral_0= 'int' )
                    // InternalSM2.g:5870:4: enumLiteral_0= 'int'
                    {
                    enumLiteral_0=(Token)match(input,83,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getINTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getBasicTypeAccess().getINTEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5877:3: (enumLiteral_1= 'uint' )
                    {
                    // InternalSM2.g:5877:3: (enumLiteral_1= 'uint' )
                    // InternalSM2.g:5878:4: enumLiteral_1= 'uint'
                    {
                    enumLiteral_1=(Token)match(input,84,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getUINTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getBasicTypeAccess().getUINTEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5885:3: (enumLiteral_2= 'uint2' )
                    {
                    // InternalSM2.g:5885:3: (enumLiteral_2= 'uint2' )
                    // InternalSM2.g:5886:4: enumLiteral_2= 'uint2'
                    {
                    enumLiteral_2=(Token)match(input,130,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getUINT2EnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getBasicTypeAccess().getUINT2EnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:5893:3: (enumLiteral_3= 'uint4' )
                    {
                    // InternalSM2.g:5893:3: (enumLiteral_3= 'uint4' )
                    // InternalSM2.g:5894:4: enumLiteral_3= 'uint4'
                    {
                    enumLiteral_3=(Token)match(input,131,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getUINT4EnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getBasicTypeAccess().getUINT4EnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:5901:3: (enumLiteral_4= 'uint8' )
                    {
                    // InternalSM2.g:5901:3: (enumLiteral_4= 'uint8' )
                    // InternalSM2.g:5902:4: enumLiteral_4= 'uint8'
                    {
                    enumLiteral_4=(Token)match(input,85,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getUINT8EnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getBasicTypeAccess().getUINT8EnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:5909:3: (enumLiteral_5= 'uint16' )
                    {
                    // InternalSM2.g:5909:3: (enumLiteral_5= 'uint16' )
                    // InternalSM2.g:5910:4: enumLiteral_5= 'uint16'
                    {
                    enumLiteral_5=(Token)match(input,132,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getUINT16EnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getBasicTypeAccess().getUINT16EnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:5917:3: (enumLiteral_6= 'uint24' )
                    {
                    // InternalSM2.g:5917:3: (enumLiteral_6= 'uint24' )
                    // InternalSM2.g:5918:4: enumLiteral_6= 'uint24'
                    {
                    enumLiteral_6=(Token)match(input,133,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getUINT24EnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_6, grammarAccess.getBasicTypeAccess().getUINT24EnumLiteralDeclaration_6());
                    			

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:5925:3: (enumLiteral_7= 'uint32' )
                    {
                    // InternalSM2.g:5925:3: (enumLiteral_7= 'uint32' )
                    // InternalSM2.g:5926:4: enumLiteral_7= 'uint32'
                    {
                    enumLiteral_7=(Token)match(input,134,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getUINT32EnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_7, grammarAccess.getBasicTypeAccess().getUINT32EnumLiteralDeclaration_7());
                    			

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:5933:3: (enumLiteral_8= 'uint64' )
                    {
                    // InternalSM2.g:5933:3: (enumLiteral_8= 'uint64' )
                    // InternalSM2.g:5934:4: enumLiteral_8= 'uint64'
                    {
                    enumLiteral_8=(Token)match(input,138,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getUINT64EnumLiteralDeclaration_8().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_8, grammarAccess.getBasicTypeAccess().getUINT64EnumLiteralDeclaration_8());
                    			

                    }


                    }
                    break;
                case 10 :
                    // InternalSM2.g:5941:3: (enumLiteral_9= 'uint128' )
                    {
                    // InternalSM2.g:5941:3: (enumLiteral_9= 'uint128' )
                    // InternalSM2.g:5942:4: enumLiteral_9= 'uint128'
                    {
                    enumLiteral_9=(Token)match(input,143,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getUINT128EnumLiteralDeclaration_9().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_9, grammarAccess.getBasicTypeAccess().getUINT128EnumLiteralDeclaration_9());
                    			

                    }


                    }
                    break;
                case 11 :
                    // InternalSM2.g:5949:3: (enumLiteral_10= 'uint160' )
                    {
                    // InternalSM2.g:5949:3: (enumLiteral_10= 'uint160' )
                    // InternalSM2.g:5950:4: enumLiteral_10= 'uint160'
                    {
                    enumLiteral_10=(Token)match(input,144,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getUINT160EnumLiteralDeclaration_10().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_10, grammarAccess.getBasicTypeAccess().getUINT160EnumLiteralDeclaration_10());
                    			

                    }


                    }
                    break;
                case 12 :
                    // InternalSM2.g:5957:3: (enumLiteral_11= 'uint256' )
                    {
                    // InternalSM2.g:5957:3: (enumLiteral_11= 'uint256' )
                    // InternalSM2.g:5958:4: enumLiteral_11= 'uint256'
                    {
                    enumLiteral_11=(Token)match(input,145,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getUINT256EnumLiteralDeclaration_11().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_11, grammarAccess.getBasicTypeAccess().getUINT256EnumLiteralDeclaration_11());
                    			

                    }


                    }
                    break;
                case 13 :
                    // InternalSM2.g:5965:3: (enumLiteral_12= 'string' )
                    {
                    // InternalSM2.g:5965:3: (enumLiteral_12= 'string' )
                    // InternalSM2.g:5966:4: enumLiteral_12= 'string'
                    {
                    enumLiteral_12=(Token)match(input,80,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getSTRINGEnumLiteralDeclaration_12().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_12, grammarAccess.getBasicTypeAccess().getSTRINGEnumLiteralDeclaration_12());
                    			

                    }


                    }
                    break;
                case 14 :
                    // InternalSM2.g:5973:3: (enumLiteral_13= 'address' )
                    {
                    // InternalSM2.g:5973:3: (enumLiteral_13= 'address' )
                    // InternalSM2.g:5974:4: enumLiteral_13= 'address'
                    {
                    enumLiteral_13=(Token)match(input,78,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getADDRESSEnumLiteralDeclaration_13().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_13, grammarAccess.getBasicTypeAccess().getADDRESSEnumLiteralDeclaration_13());
                    			

                    }


                    }
                    break;
                case 15 :
                    // InternalSM2.g:5981:3: (enumLiteral_14= 'address payable' )
                    {
                    // InternalSM2.g:5981:3: (enumLiteral_14= 'address payable' )
                    // InternalSM2.g:5982:4: enumLiteral_14= 'address payable'
                    {
                    enumLiteral_14=(Token)match(input,86,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_14().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_14, grammarAccess.getBasicTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_14());
                    			

                    }


                    }
                    break;
                case 16 :
                    // InternalSM2.g:5989:3: (enumLiteral_15= 'double' )
                    {
                    // InternalSM2.g:5989:3: (enumLiteral_15= 'double' )
                    // InternalSM2.g:5990:4: enumLiteral_15= 'double'
                    {
                    enumLiteral_15=(Token)match(input,87,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getDOUBLEEnumLiteralDeclaration_15().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_15, grammarAccess.getBasicTypeAccess().getDOUBLEEnumLiteralDeclaration_15());
                    			

                    }


                    }
                    break;
                case 17 :
                    // InternalSM2.g:5997:3: (enumLiteral_16= 'bool' )
                    {
                    // InternalSM2.g:5997:3: (enumLiteral_16= 'bool' )
                    // InternalSM2.g:5998:4: enumLiteral_16= 'bool'
                    {
                    enumLiteral_16=(Token)match(input,88,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getBOOLEANEnumLiteralDeclaration_16().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_16, grammarAccess.getBasicTypeAccess().getBOOLEANEnumLiteralDeclaration_16());
                    			

                    }


                    }
                    break;
                case 18 :
                    // InternalSM2.g:6005:3: (enumLiteral_17= 'byte' )
                    {
                    // InternalSM2.g:6005:3: (enumLiteral_17= 'byte' )
                    // InternalSM2.g:6006:4: enumLiteral_17= 'byte'
                    {
                    enumLiteral_17=(Token)match(input,180,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getBYTEEnumLiteralDeclaration_17().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_17, grammarAccess.getBasicTypeAccess().getBYTEEnumLiteralDeclaration_17());
                    			

                    }


                    }
                    break;
                case 19 :
                    // InternalSM2.g:6013:3: (enumLiteral_18= 'bytes2' )
                    {
                    // InternalSM2.g:6013:3: (enumLiteral_18= 'bytes2' )
                    // InternalSM2.g:6014:4: enumLiteral_18= 'bytes2'
                    {
                    enumLiteral_18=(Token)match(input,90,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getBYTE2EnumLiteralDeclaration_18().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_18, grammarAccess.getBasicTypeAccess().getBYTE2EnumLiteralDeclaration_18());
                    			

                    }


                    }
                    break;
                case 20 :
                    // InternalSM2.g:6021:3: (enumLiteral_19= 'bytes3' )
                    {
                    // InternalSM2.g:6021:3: (enumLiteral_19= 'bytes3' )
                    // InternalSM2.g:6022:4: enumLiteral_19= 'bytes3'
                    {
                    enumLiteral_19=(Token)match(input,91,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getBYTE3EnumLiteralDeclaration_19().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_19, grammarAccess.getBasicTypeAccess().getBYTE3EnumLiteralDeclaration_19());
                    			

                    }


                    }
                    break;
                case 21 :
                    // InternalSM2.g:6029:3: (enumLiteral_20= 'bytes4' )
                    {
                    // InternalSM2.g:6029:3: (enumLiteral_20= 'bytes4' )
                    // InternalSM2.g:6030:4: enumLiteral_20= 'bytes4'
                    {
                    enumLiteral_20=(Token)match(input,92,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getBYTE4EnumLiteralDeclaration_20().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_20, grammarAccess.getBasicTypeAccess().getBYTE4EnumLiteralDeclaration_20());
                    			

                    }


                    }
                    break;
                case 22 :
                    // InternalSM2.g:6037:3: (enumLiteral_21= 'bytes5' )
                    {
                    // InternalSM2.g:6037:3: (enumLiteral_21= 'bytes5' )
                    // InternalSM2.g:6038:4: enumLiteral_21= 'bytes5'
                    {
                    enumLiteral_21=(Token)match(input,93,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getBYTE5EnumLiteralDeclaration_21().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_21, grammarAccess.getBasicTypeAccess().getBYTE5EnumLiteralDeclaration_21());
                    			

                    }


                    }
                    break;
                case 23 :
                    // InternalSM2.g:6045:3: (enumLiteral_22= 'bytes6' )
                    {
                    // InternalSM2.g:6045:3: (enumLiteral_22= 'bytes6' )
                    // InternalSM2.g:6046:4: enumLiteral_22= 'bytes6'
                    {
                    enumLiteral_22=(Token)match(input,94,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getBYTE6EnumLiteralDeclaration_22().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_22, grammarAccess.getBasicTypeAccess().getBYTE6EnumLiteralDeclaration_22());
                    			

                    }


                    }
                    break;
                case 24 :
                    // InternalSM2.g:6053:3: (enumLiteral_23= 'bytes7' )
                    {
                    // InternalSM2.g:6053:3: (enumLiteral_23= 'bytes7' )
                    // InternalSM2.g:6054:4: enumLiteral_23= 'bytes7'
                    {
                    enumLiteral_23=(Token)match(input,95,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getBYTE7EnumLiteralDeclaration_23().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_23, grammarAccess.getBasicTypeAccess().getBYTE7EnumLiteralDeclaration_23());
                    			

                    }


                    }
                    break;
                case 25 :
                    // InternalSM2.g:6061:3: (enumLiteral_24= 'bytes8' )
                    {
                    // InternalSM2.g:6061:3: (enumLiteral_24= 'bytes8' )
                    // InternalSM2.g:6062:4: enumLiteral_24= 'bytes8'
                    {
                    enumLiteral_24=(Token)match(input,96,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getBYTE8EnumLiteralDeclaration_24().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_24, grammarAccess.getBasicTypeAccess().getBYTE8EnumLiteralDeclaration_24());
                    			

                    }


                    }
                    break;
                case 26 :
                    // InternalSM2.g:6069:3: (enumLiteral_25= 'bytes16' )
                    {
                    // InternalSM2.g:6069:3: (enumLiteral_25= 'bytes16' )
                    // InternalSM2.g:6070:4: enumLiteral_25= 'bytes16'
                    {
                    enumLiteral_25=(Token)match(input,100,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getBYTE16EnumLiteralDeclaration_25().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_25, grammarAccess.getBasicTypeAccess().getBYTE16EnumLiteralDeclaration_25());
                    			

                    }


                    }
                    break;
                case 27 :
                    // InternalSM2.g:6077:3: (enumLiteral_26= 'bytes32' )
                    {
                    // InternalSM2.g:6077:3: (enumLiteral_26= 'bytes32' )
                    // InternalSM2.g:6078:4: enumLiteral_26= 'bytes32'
                    {
                    enumLiteral_26=(Token)match(input,106,FOLLOW_2); 

                    				current = grammarAccess.getBasicTypeAccess().getBYTE32EnumLiteralDeclaration_26().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_26, grammarAccess.getBasicTypeAccess().getBYTE32EnumLiteralDeclaration_26());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBasicType"

    // Delegated rules


    protected DFA46 dfa46 = new DFA46(this);
    protected DFA122 dfa122 = new DFA122(this);
    static final String dfa_1s = "\41\uffff";
    static final String dfa_2s = "\1\115\1\11\1\12\1\10\1\115\1\uffff\1\11\2\7\2\10\1\13\1\17\1\120\1\7\1\17\1\10\1\7\1\120\1\17\1\7\1\17\1\10\1\7\1\120\1\17\1\7\1\20\1\10\1\7\1\13\2\uffff";
    static final String dfa_3s = "\1\115\1\11\1\12\2\u0092\1\uffff\1\u00a2\1\121\1\7\3\120\1\17\1\120\1\121\1\17\1\120\1\7\1\120\1\17\1\121\1\17\1\120\1\7\1\120\1\17\1\121\1\20\1\120\1\7\1\120\2\uffff";
    static final String dfa_4s = "\5\uffff\1\1\31\uffff\1\2\1\3";
    static final String dfa_5s = "\41\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\4\104\uffff\1\5\1\6\1\uffff\1\5\2\uffff\4\5\1\uffff\23\5\6\uffff\42\5",
            "\1\5\1\6\1\uffff\1\5\2\uffff\4\5\1\uffff\23\5\6\uffff\42\5",
            "",
            "\1\7\11\uffff\1\5\60\uffff\2\5\11\uffff\1\10\33\uffff\2\5\65\uffff\1\5",
            "\1\11\111\uffff\1\5",
            "\1\12",
            "\1\13\2\uffff\1\5\104\uffff\1\14",
            "\1\15\107\uffff\1\14",
            "\1\5\104\uffff\1\14",
            "\1\16",
            "\1\14",
            "\1\20\111\uffff\1\17",
            "\1\21",
            "\1\22\107\uffff\1\23",
            "\1\20",
            "\1\23",
            "\1\24",
            "\1\26\111\uffff\1\25",
            "\1\27",
            "\1\30\107\uffff\1\31",
            "\1\26",
            "\1\31",
            "\1\32",
            "\1\34\111\uffff\1\33",
            "\1\35",
            "\1\36\2\uffff\1\37\104\uffff\1\40",
            "\1\34",
            "\1\37\104\uffff\1\40",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA46 extends DFA {

        public DFA46(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 46;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "1816:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )";
        }
    }
    static final String dfa_7s = "\16\uffff";
    static final String dfa_8s = "\1\u0095\1\5\1\17\1\7\1\10\6\17\1\101\2\uffff";
    static final String dfa_9s = "\1\u0095\1\5\1\17\1\u00ac\1\10\6\22\1\u00ac\2\uffff";
    static final String dfa_10s = "\14\uffff\1\1\1\2";
    static final String dfa_11s = "\16\uffff}>";
    static final String[] dfa_12s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\4\71\uffff\1\5\1\7\146\uffff\1\6\1\10\1\11\1\12",
            "\1\13",
            "\1\14\2\uffff\1\15",
            "\1\14\2\uffff\1\15",
            "\1\14\2\uffff\1\15",
            "\1\14\2\uffff\1\15",
            "\1\14\2\uffff\1\15",
            "\1\14\2\uffff\1\15",
            "\1\5\1\7\146\uffff\1\6\1\10\1\11\1\12",
            "",
            ""
    };

    static final short[] dfa_7 = DFA.unpackEncodedString(dfa_7s);
    static final char[] dfa_8 = DFA.unpackEncodedStringToUnsignedChars(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final short[] dfa_10 = DFA.unpackEncodedString(dfa_10s);
    static final short[] dfa_11 = DFA.unpackEncodedString(dfa_11s);
    static final short[][] dfa_12 = unpackEncodedStringArray(dfa_12s);

    class DFA122 extends DFA {

        public DFA122(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 122;
            this.eot = dfa_7;
            this.eof = dfa_7;
            this.min = dfa_8;
            this.max = dfa_9;
            this.accept = dfa_10;
            this.special = dfa_11;
            this.transition = dfa_12;
        }
        public String getDescription() {
            return "4391:2: (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000100L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x1000000000000000L,0xFFFE07FFFF796040L,0x000000000007FFFFL});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000018000000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x00007C0000000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000070808020L,0x0000000000000000L,0x0000000040000000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0040800000000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x003F000000000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0300000000000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0800000000000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x2000000000000400L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000000100L,0x0000000000000008L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000000A00L,0xFFFE07FFFF7D6A00L,0x000000001847FFFFL});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000000A00L,0xFFFE07FFFF7D6A00L,0x000000000047FFFFL});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000000800L,0x0000000000000200L,0x0000000000400000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000000800L,0x0000000000000000L,0x0000000000400000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x8000000000000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000007L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000000280L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000000040L,0x0000000001F94000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000030L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000000000200L,0xFFFE07FFFF7D6800L,0x000000000007FFFFL});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000000040L,0x00000411FDF94000L,0x001000000003847CL});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000000000000000L,0x0000180001F94080L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000000000000L,0x0000000001F94080L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000000000L,0x0000000001F94000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000000000000102L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000000008100L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000000000000100L,0x0000000000000400L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000000000000200L,0x0000000000000030L,0x0000000400000000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000000000000100L,0xFFFE07FFFF796000L,0x000000000007FFFFL});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000000000L,0xFFFE07FFFF796000L,0x000000000007FFFFL});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000000100L,0x0000000000004000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0000000000000200L,0x0000000000008000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0000000000000100L,0x0000000000010000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0000000000000080L,0x0000000000020000L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0000000000000900L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0000000000020800L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0000000000000002L,0x0000180000000000L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0000000000000000L,0x0000200000000000L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x0000000000080200L,0x0000D80000000000L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x0000000000080200L,0x0000C00000000000L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x0000000000000200L,0x0000C00000000000L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0000000000080200L,0x0000180000000030L,0x0000000400000000L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0000000000080200L,0x0000000000000030L,0x0000000400000000L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x0000000000040080L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x0000000000080200L,0x0000D80000000030L,0x0000000400000000L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x0000000000080200L,0x0000C00000000030L,0x0000000400000000L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x0000000000000200L,0x0000C00000000030L,0x0000000400000000L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_73 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_74 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_75 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_76 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000100000L});
    public static final BitSet FOLLOW_77 = new BitSet(new long[]{0x0000000000000200L,0x0000180000000030L,0x0000000400000000L});
    public static final BitSet FOLLOW_78 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_79 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_80 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000006L,0x00001E0000000000L});
    public static final BitSet FOLLOW_81 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x000001F800000000L});
    public static final BitSet FOLLOW_82 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000030L,0x0000000400000000L});
    public static final BitSet FOLLOW_83 = new BitSet(new long[]{0x0000000000000600L,0x0000000000000000L,0x0000000380000000L});
    public static final BitSet FOLLOW_84 = new BitSet(new long[]{0x0000000070808920L,0x0000000000000000L,0x0000000040200000L});
    public static final BitSet FOLLOW_85 = new BitSet(new long[]{0x0000000070808920L,0x0000000000000000L,0x0000000040000000L});
    public static final BitSet FOLLOW_86 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_87 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_88 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_89 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_90 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_91 = new BitSet(new long[]{0x0000000000008200L});
    public static final BitSet FOLLOW_92 = new BitSet(new long[]{0x0000000070808060L,0x0000000000000000L,0x0000000040000000L});
    public static final BitSet FOLLOW_93 = new BitSet(new long[]{0x0000000000000020L,0x0000180000000000L});
    public static final BitSet FOLLOW_94 = new BitSet(new long[]{0x0000000070828060L,0x0000000000000000L,0x0000000040000000L});

}