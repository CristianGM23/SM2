package org.xtext.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_DOT", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_ID", "RULE_OPENKEY", "RULE_CLOSEKEY", "RULE_NUMVERSION1", "RULE_NUMVERSION2", "RULE_NUMVERSION3", "RULE_STRING", "RULE_COMMA", "RULE_INT", "RULE_BOOLVALUE", "RULE_IF", "RULE_ELSE", "RULE_RETURN", "RULE_RETURNS", "RULE_EMIT", "RULE_BREAK", "RULE_CONTINUE", "RULE_NEW", "RULE_DELETE", "RULE_PARAMSLONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_NOTICELONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_EMAIL", "RULE_CONSTANT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'msg'", "'data'", "'value'", "'gas'", "'sender'", "'sig'", "'tx'", "'gasprice'", "'origin'", "'contract'", "'is'", "'pragma'", "'solidity'", "'^'", "'>'", "'>='", "'constructor'", "'public'", "'internal'", "'import'", "'modifier'", "'_;'", "'int'", "'uint'", "'uint8'", "'string'", "'address'", "'address payable'", "'double'", "'bool'", "'mapping'", "'=>'", "'struct'", "'enum'", "'='", "'require'", "'function'", "'selfdesctruct'", "'keccack256'", "'sha256'", "'sha3'", "'//'", "'/*'", "'*/'", "'!'", "'private'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'<'", "'<='", "'=='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'", "'%'"
    };
    public static final int T__50=50;
    public static final int RULE_RETURNS=22;
    public static final int RULE_OPENPARENTHESIS=5;
    public static final int RULE_EOLINE=8;
    public static final int T__59=59;
    public static final int RULE_EMIT=23;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_PARAMSLONGCOMENT=28;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=9;
    public static final int RULE_RETURN=21;
    public static final int RULE_INT=17;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=35;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int RULE_DELETE=27;
    public static final int RULE_TITLELONGCOMENT=32;
    public static final int RULE_NOTICELONGCOMENT=30;
    public static final int RULE_EMAIL=33;
    public static final int RULE_CONSTANT=34;
    public static final int RULE_OPENKEY=10;
    public static final int T__39=39;
    public static final int RULE_CLOSEPARENTHESIS=6;
    public static final int RULE_IF=19;
    public static final int RULE_DOT=4;
    public static final int RULE_CONTINUE=25;
    public static final int RULE_DEVLONGCOMENT=29;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__91=91;
    public static final int T__100=100;
    public static final int T__92=92;
    public static final int T__93=93;
    public static final int T__94=94;
    public static final int T__101=101;
    public static final int RULE_NEW=26;
    public static final int T__90=90;
    public static final int T__99=99;
    public static final int RULE_CLOSEKEY=11;
    public static final int T__95=95;
    public static final int T__96=96;
    public static final int T__97=97;
    public static final int T__98=98;
    public static final int RULE_COMMA=16;
    public static final int RULE_RETURNSLONGCOMENT=31;
    public static final int RULE_SEMICOLON=7;
    public static final int RULE_NUMVERSION3=14;
    public static final int RULE_NUMVERSION2=13;
    public static final int RULE_ELSE=20;
    public static final int RULE_NUMVERSION1=12;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int RULE_BOOLVALUE=18;
    public static final int T__72=72;
    public static final int RULE_STRING=15;
    public static final int RULE_SL_COMMENT=36;
    public static final int RULE_BREAK=24;
    public static final int T__77=77;
    public static final int T__78=78;
    public static final int T__79=79;
    public static final int T__73=73;
    public static final int EOF=-1;
    public static final int T__74=74;
    public static final int T__75=75;
    public static final int T__76=76;
    public static final int T__80=80;
    public static final int T__81=81;
    public static final int T__82=82;
    public static final int T__83=83;
    public static final int RULE_WS=37;
    public static final int RULE_ANY_OTHER=38;
    public static final int T__88=88;
    public static final int T__89=89;
    public static final int T__84=84;
    public static final int T__85=85;
    public static final int T__86=86;
    public static final int T__87=87;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }



     	private SM2GrammarAccess grammarAccess;

        public InternalSM2Parser(TokenStream input, SM2GrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "File";
       	}

       	@Override
       	protected SM2GrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleFile"
    // InternalSM2.g:65:1: entryRuleFile returns [EObject current=null] : iv_ruleFile= ruleFile EOF ;
    public final EObject entryRuleFile() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFile = null;


        try {
            // InternalSM2.g:65:45: (iv_ruleFile= ruleFile EOF )
            // InternalSM2.g:66:2: iv_ruleFile= ruleFile EOF
            {
             newCompositeNode(grammarAccess.getFileRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFile=ruleFile();

            state._fsp--;

             current =iv_ruleFile; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFile"


    // $ANTLR start "ruleFile"
    // InternalSM2.g:72:1: ruleFile returns [EObject current=null] : ( ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_attributes_2_0= ruleAttributes ) )* ( (lv_contract_3_0= ruleContract ) ) ( (lv_comments_4_0= ruleComment ) )* ) ;
    public final EObject ruleFile() throws RecognitionException {
        EObject current = null;

        EObject lv_version_0_0 = null;

        EObject lv_attributes_2_0 = null;

        EObject lv_contract_3_0 = null;

        AntlrDatatypeRuleToken lv_comments_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:78:2: ( ( ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_attributes_2_0= ruleAttributes ) )* ( (lv_contract_3_0= ruleContract ) ) ( (lv_comments_4_0= ruleComment ) )* ) )
            // InternalSM2.g:79:2: ( ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_attributes_2_0= ruleAttributes ) )* ( (lv_contract_3_0= ruleContract ) ) ( (lv_comments_4_0= ruleComment ) )* )
            {
            // InternalSM2.g:79:2: ( ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_attributes_2_0= ruleAttributes ) )* ( (lv_contract_3_0= ruleContract ) ) ( (lv_comments_4_0= ruleComment ) )* )
            // InternalSM2.g:80:3: ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_attributes_2_0= ruleAttributes ) )* ( (lv_contract_3_0= ruleContract ) ) ( (lv_comments_4_0= ruleComment ) )*
            {
            // InternalSM2.g:80:3: ( (lv_version_0_0= ruleVersion ) )
            // InternalSM2.g:81:4: (lv_version_0_0= ruleVersion )
            {
            // InternalSM2.g:81:4: (lv_version_0_0= ruleVersion )
            // InternalSM2.g:82:5: lv_version_0_0= ruleVersion
            {

            					newCompositeNode(grammarAccess.getFileAccess().getVersionVersionParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_3);
            lv_version_0_0=ruleVersion();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFileRule());
            					}
            					set(
            						current,
            						"version",
            						lv_version_0_0,
            						"org.xtext.SM2.Version");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            			newCompositeNode(grammarAccess.getFileAccess().getImportParserRuleCall_1());
            		
            pushFollow(FOLLOW_4);
            ruleImport();

            state._fsp--;


            			afterParserOrEnumRuleCall();
            		
            // InternalSM2.g:106:3: ( (lv_attributes_2_0= ruleAttributes ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==RULE_ID||LA1_0==69||(LA1_0>=71 && LA1_0<=72)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalSM2.g:107:4: (lv_attributes_2_0= ruleAttributes )
            	    {
            	    // InternalSM2.g:107:4: (lv_attributes_2_0= ruleAttributes )
            	    // InternalSM2.g:108:5: lv_attributes_2_0= ruleAttributes
            	    {

            	    					newCompositeNode(grammarAccess.getFileAccess().getAttributesAttributesParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_4);
            	    lv_attributes_2_0=ruleAttributes();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFileRule());
            	    					}
            	    					add(
            	    						current,
            	    						"attributes",
            	    						lv_attributes_2_0,
            	    						"org.xtext.SM2.Attributes");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            // InternalSM2.g:125:3: ( (lv_contract_3_0= ruleContract ) )
            // InternalSM2.g:126:4: (lv_contract_3_0= ruleContract )
            {
            // InternalSM2.g:126:4: (lv_contract_3_0= ruleContract )
            // InternalSM2.g:127:5: lv_contract_3_0= ruleContract
            {

            					newCompositeNode(grammarAccess.getFileAccess().getContractContractParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_5);
            lv_contract_3_0=ruleContract();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFileRule());
            					}
            					set(
            						current,
            						"contract",
            						lv_contract_3_0,
            						"org.xtext.SM2.Contract");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:144:3: ( (lv_comments_4_0= ruleComment ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>=80 && LA2_0<=81)) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSM2.g:145:4: (lv_comments_4_0= ruleComment )
            	    {
            	    // InternalSM2.g:145:4: (lv_comments_4_0= ruleComment )
            	    // InternalSM2.g:146:5: lv_comments_4_0= ruleComment
            	    {

            	    					newCompositeNode(grammarAccess.getFileAccess().getCommentsCommentParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_5);
            	    lv_comments_4_0=ruleComment();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFileRule());
            	    					}
            	    					add(
            	    						current,
            	    						"comments",
            	    						lv_comments_4_0,
            	    						"org.xtext.SM2.Comment");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFile"


    // $ANTLR start "entryRuleMSGVariables"
    // InternalSM2.g:167:1: entryRuleMSGVariables returns [EObject current=null] : iv_ruleMSGVariables= ruleMSGVariables EOF ;
    public final EObject entryRuleMSGVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMSGVariables = null;


        try {
            // InternalSM2.g:167:53: (iv_ruleMSGVariables= ruleMSGVariables EOF )
            // InternalSM2.g:168:2: iv_ruleMSGVariables= ruleMSGVariables EOF
            {
             newCompositeNode(grammarAccess.getMSGVariablesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMSGVariables=ruleMSGVariables();

            state._fsp--;

             current =iv_ruleMSGVariables; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMSGVariables"


    // $ANTLR start "ruleMSGVariables"
    // InternalSM2.g:174:1: ruleMSGVariables returns [EObject current=null] : (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation ) ;
    public final EObject ruleMSGVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_MSGOperation_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:180:2: ( (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation ) )
            // InternalSM2.g:181:2: (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation )
            {
            // InternalSM2.g:181:2: (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation )
            // InternalSM2.g:182:3: otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation
            {
            otherlv_0=(Token)match(input,39,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getMSGVariablesAccess().getMsgKeyword_0());
            		

            			newCompositeNode(grammarAccess.getMSGVariablesAccess().getMSGOperationParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_MSGOperation_1=ruleMSGOperation();

            state._fsp--;


            			current = this_MSGOperation_1;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMSGVariables"


    // $ANTLR start "entryRuleMSGOperation"
    // InternalSM2.g:198:1: entryRuleMSGOperation returns [EObject current=null] : iv_ruleMSGOperation= ruleMSGOperation EOF ;
    public final EObject entryRuleMSGOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMSGOperation = null;


        try {
            // InternalSM2.g:198:53: (iv_ruleMSGOperation= ruleMSGOperation EOF )
            // InternalSM2.g:199:2: iv_ruleMSGOperation= ruleMSGOperation EOF
            {
             newCompositeNode(grammarAccess.getMSGOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMSGOperation=ruleMSGOperation();

            state._fsp--;

             current =iv_ruleMSGOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMSGOperation"


    // $ANTLR start "ruleMSGOperation"
    // InternalSM2.g:205:1: ruleMSGOperation returns [EObject current=null] : (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? ) ;
    public final EObject ruleMSGOperation() throws RecognitionException {
        EObject current = null;

        Token this_DOT_0=null;
        Token otherlv_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token this_OPENPARENTHESIS_7=null;
        Token this_CLOSEPARENTHESIS_9=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token this_OPENPARENTHESIS_12=null;
        Token this_CLOSEPARENTHESIS_14=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token this_OPENPARENTHESIS_17=null;
        Token this_CLOSEPARENTHESIS_19=null;
        Token otherlv_20=null;
        Token otherlv_21=null;
        Token this_OPENPARENTHESIS_22=null;
        Token this_CLOSEPARENTHESIS_24=null;
        Token otherlv_25=null;
        Token this_SEMICOLON_26=null;
        Token this_EOLINE_27=null;


        	enterRule();

        try {
            // InternalSM2.g:211:2: ( (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? ) )
            // InternalSM2.g:212:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? )
            {
            // InternalSM2.g:212:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? )
            // InternalSM2.g:213:3: this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )?
            {
            this_DOT_0=(Token)match(input,RULE_DOT,FOLLOW_7); 

            			newLeafNode(this_DOT_0, grammarAccess.getMSGOperationAccess().getDOTTerminalRuleCall_0());
            		
            // InternalSM2.g:217:3: ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) )
            int alt8=5;
            switch ( input.LA(1) ) {
            case 40:
                {
                alt8=1;
                }
                break;
            case 41:
                {
                alt8=2;
                }
                break;
            case 42:
                {
                alt8=3;
                }
                break;
            case 43:
                {
                alt8=4;
                }
                break;
            case 44:
                {
                alt8=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // InternalSM2.g:218:4: ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' )
                    {
                    // InternalSM2.g:218:4: ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' )
                    int alt3=2;
                    int LA3_0 = input.LA(1);

                    if ( (LA3_0==40) ) {
                        int LA3_1 = input.LA(2);

                        if ( (LA3_1==RULE_OPENPARENTHESIS) ) {
                            alt3=1;
                        }
                        else if ( (LA3_1==EOF||LA3_1==RULE_SEMICOLON) ) {
                            alt3=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 3, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 3, 0, input);

                        throw nvae;
                    }
                    switch (alt3) {
                        case 1 :
                            // InternalSM2.g:219:5: (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:219:5: (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:220:6: otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_1=(Token)match(input,40,FOLLOW_8); 

                            						newLeafNode(otherlv_1, grammarAccess.getMSGOperationAccess().getDataKeyword_1_0_0_0());
                            					
                            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_0_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_0_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:241:5: otherlv_5= 'data'
                            {
                            otherlv_5=(Token)match(input,40,FOLLOW_11); 

                            					newLeafNode(otherlv_5, grammarAccess.getMSGOperationAccess().getDataKeyword_1_0_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:247:4: ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' )
                    {
                    // InternalSM2.g:247:4: ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' )
                    int alt4=2;
                    int LA4_0 = input.LA(1);

                    if ( (LA4_0==41) ) {
                        int LA4_1 = input.LA(2);

                        if ( (LA4_1==RULE_OPENPARENTHESIS) ) {
                            alt4=1;
                        }
                        else if ( (LA4_1==EOF||LA4_1==RULE_SEMICOLON) ) {
                            alt4=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 4, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 0, input);

                        throw nvae;
                    }
                    switch (alt4) {
                        case 1 :
                            // InternalSM2.g:248:5: (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:248:5: (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:249:6: otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_6=(Token)match(input,41,FOLLOW_8); 

                            						newLeafNode(otherlv_6, grammarAccess.getMSGOperationAccess().getValueKeyword_1_1_0_0());
                            					
                            this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_1_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_9=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_9, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:270:5: otherlv_10= 'value'
                            {
                            otherlv_10=(Token)match(input,41,FOLLOW_11); 

                            					newLeafNode(otherlv_10, grammarAccess.getMSGOperationAccess().getValueKeyword_1_1_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:276:4: ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' )
                    {
                    // InternalSM2.g:276:4: ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' )
                    int alt5=2;
                    int LA5_0 = input.LA(1);

                    if ( (LA5_0==42) ) {
                        int LA5_1 = input.LA(2);

                        if ( (LA5_1==EOF||LA5_1==RULE_SEMICOLON) ) {
                            alt5=2;
                        }
                        else if ( (LA5_1==RULE_OPENPARENTHESIS) ) {
                            alt5=1;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 5, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 5, 0, input);

                        throw nvae;
                    }
                    switch (alt5) {
                        case 1 :
                            // InternalSM2.g:277:5: (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:277:5: (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:278:6: otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_11=(Token)match(input,42,FOLLOW_8); 

                            						newLeafNode(otherlv_11, grammarAccess.getMSGOperationAccess().getGasKeyword_1_2_0_0());
                            					
                            this_OPENPARENTHESIS_12=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_12, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_2_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_2_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_14=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_14, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_2_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:299:5: otherlv_15= 'gas'
                            {
                            otherlv_15=(Token)match(input,42,FOLLOW_11); 

                            					newLeafNode(otherlv_15, grammarAccess.getMSGOperationAccess().getGasKeyword_1_2_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:305:4: ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' )
                    {
                    // InternalSM2.g:305:4: ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' )
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( (LA6_0==43) ) {
                        int LA6_1 = input.LA(2);

                        if ( (LA6_1==RULE_OPENPARENTHESIS) ) {
                            alt6=1;
                        }
                        else if ( (LA6_1==EOF||LA6_1==RULE_SEMICOLON) ) {
                            alt6=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 6, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 6, 0, input);

                        throw nvae;
                    }
                    switch (alt6) {
                        case 1 :
                            // InternalSM2.g:306:5: (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:306:5: (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:307:6: otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_16=(Token)match(input,43,FOLLOW_8); 

                            						newLeafNode(otherlv_16, grammarAccess.getMSGOperationAccess().getSenderKeyword_1_3_0_0());
                            					
                            this_OPENPARENTHESIS_17=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_17, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_3_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_3_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_19=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_19, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:328:5: otherlv_20= 'sender'
                            {
                            otherlv_20=(Token)match(input,43,FOLLOW_11); 

                            					newLeafNode(otherlv_20, grammarAccess.getMSGOperationAccess().getSenderKeyword_1_3_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:334:4: ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' )
                    {
                    // InternalSM2.g:334:4: ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' )
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==44) ) {
                        int LA7_1 = input.LA(2);

                        if ( (LA7_1==RULE_OPENPARENTHESIS) ) {
                            alt7=1;
                        }
                        else if ( (LA7_1==EOF||LA7_1==RULE_SEMICOLON) ) {
                            alt7=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 7, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 7, 0, input);

                        throw nvae;
                    }
                    switch (alt7) {
                        case 1 :
                            // InternalSM2.g:335:5: (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:335:5: (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:336:6: otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_21=(Token)match(input,44,FOLLOW_8); 

                            						newLeafNode(otherlv_21, grammarAccess.getMSGOperationAccess().getSigKeyword_1_4_0_0());
                            					
                            this_OPENPARENTHESIS_22=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_22, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_4_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_4_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_24=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_24, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_4_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:357:5: otherlv_25= 'sig'
                            {
                            otherlv_25=(Token)match(input,44,FOLLOW_11); 

                            					newLeafNode(otherlv_25, grammarAccess.getMSGOperationAccess().getSigKeyword_1_4_1());
                            				

                            }
                            break;

                    }


                    }
                    break;

            }

            // InternalSM2.g:363:3: (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==RULE_SEMICOLON) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalSM2.g:364:4: this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE
                    {
                    this_SEMICOLON_26=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

                    				newLeafNode(this_SEMICOLON_26, grammarAccess.getMSGOperationAccess().getSEMICOLONTerminalRuleCall_2_0());
                    			
                    this_EOLINE_27=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_27, grammarAccess.getMSGOperationAccess().getEOLINETerminalRuleCall_2_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMSGOperation"


    // $ANTLR start "entryRuleTxVariables"
    // InternalSM2.g:377:1: entryRuleTxVariables returns [EObject current=null] : iv_ruleTxVariables= ruleTxVariables EOF ;
    public final EObject entryRuleTxVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTxVariables = null;


        try {
            // InternalSM2.g:377:52: (iv_ruleTxVariables= ruleTxVariables EOF )
            // InternalSM2.g:378:2: iv_ruleTxVariables= ruleTxVariables EOF
            {
             newCompositeNode(grammarAccess.getTxVariablesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTxVariables=ruleTxVariables();

            state._fsp--;

             current =iv_ruleTxVariables; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTxVariables"


    // $ANTLR start "ruleTxVariables"
    // InternalSM2.g:384:1: ruleTxVariables returns [EObject current=null] : (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation ) ;
    public final EObject ruleTxVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_TxOperation_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:390:2: ( (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation ) )
            // InternalSM2.g:391:2: (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation )
            {
            // InternalSM2.g:391:2: (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation )
            // InternalSM2.g:392:3: otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation
            {
            otherlv_0=(Token)match(input,45,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getTxVariablesAccess().getTxKeyword_0());
            		

            			newCompositeNode(grammarAccess.getTxVariablesAccess().getTxOperationParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_TxOperation_1=ruleTxOperation();

            state._fsp--;


            			current = this_TxOperation_1;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTxVariables"


    // $ANTLR start "entryRuleTxOperation"
    // InternalSM2.g:408:1: entryRuleTxOperation returns [EObject current=null] : iv_ruleTxOperation= ruleTxOperation EOF ;
    public final EObject entryRuleTxOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTxOperation = null;


        try {
            // InternalSM2.g:408:52: (iv_ruleTxOperation= ruleTxOperation EOF )
            // InternalSM2.g:409:2: iv_ruleTxOperation= ruleTxOperation EOF
            {
             newCompositeNode(grammarAccess.getTxOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTxOperation=ruleTxOperation();

            state._fsp--;

             current =iv_ruleTxOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTxOperation"


    // $ANTLR start "ruleTxOperation"
    // InternalSM2.g:415:1: ruleTxOperation returns [EObject current=null] : (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? ) ;
    public final EObject ruleTxOperation() throws RecognitionException {
        EObject current = null;

        Token this_DOT_0=null;
        Token otherlv_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token this_OPENPARENTHESIS_7=null;
        Token this_CLOSEPARENTHESIS_9=null;
        Token otherlv_10=null;
        Token this_SEMICOLON_11=null;
        Token this_EOLINE_12=null;


        	enterRule();

        try {
            // InternalSM2.g:421:2: ( (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? ) )
            // InternalSM2.g:422:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? )
            {
            // InternalSM2.g:422:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? )
            // InternalSM2.g:423:3: this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )?
            {
            this_DOT_0=(Token)match(input,RULE_DOT,FOLLOW_13); 

            			newLeafNode(this_DOT_0, grammarAccess.getTxOperationAccess().getDOTTerminalRuleCall_0());
            		
            // InternalSM2.g:427:3: ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' )
            int alt11=3;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==46) ) {
                alt11=1;
            }
            else if ( (LA11_0==47) ) {
                int LA11_2 = input.LA(2);

                if ( (LA11_2==EOF||LA11_2==RULE_SEMICOLON) ) {
                    alt11=3;
                }
                else if ( (LA11_2==RULE_OPENPARENTHESIS) ) {
                    alt11=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 11, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalSM2.g:428:4: ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' )
                    {
                    // InternalSM2.g:428:4: ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' )
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==46) ) {
                        int LA10_1 = input.LA(2);

                        if ( (LA10_1==RULE_OPENPARENTHESIS) ) {
                            alt10=1;
                        }
                        else if ( (LA10_1==EOF||LA10_1==RULE_SEMICOLON) ) {
                            alt10=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 10, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 10, 0, input);

                        throw nvae;
                    }
                    switch (alt10) {
                        case 1 :
                            // InternalSM2.g:429:5: (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:429:5: (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:430:6: otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_1=(Token)match(input,46,FOLLOW_8); 

                            						newLeafNode(otherlv_1, grammarAccess.getTxOperationAccess().getGaspriceKeyword_1_0_0_0());
                            					
                            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getTxOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_0_0_1());
                            					

                            						newCompositeNode(grammarAccess.getTxOperationAccess().getExpressionParserRuleCall_1_0_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getTxOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:451:5: otherlv_5= 'gasprice'
                            {
                            otherlv_5=(Token)match(input,46,FOLLOW_11); 

                            					newLeafNode(otherlv_5, grammarAccess.getTxOperationAccess().getGaspriceKeyword_1_0_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:457:4: ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:457:4: ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:458:5: (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS
                    {
                    // InternalSM2.g:458:5: (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression )
                    // InternalSM2.g:459:6: otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression
                    {
                    otherlv_6=(Token)match(input,47,FOLLOW_8); 

                    						newLeafNode(otherlv_6, grammarAccess.getTxOperationAccess().getOriginKeyword_1_1_0_0());
                    					
                    this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                    						newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getTxOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1_0_1());
                    					

                    						newCompositeNode(grammarAccess.getTxOperationAccess().getExpressionParserRuleCall_1_1_0_2());
                    					
                    pushFollow(FOLLOW_10);
                    ruleExpression();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }

                    this_CLOSEPARENTHESIS_9=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                    					newLeafNode(this_CLOSEPARENTHESIS_9, grammarAccess.getTxOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_1());
                    				

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:481:4: otherlv_10= 'origin'
                    {
                    otherlv_10=(Token)match(input,47,FOLLOW_11); 

                    				newLeafNode(otherlv_10, grammarAccess.getTxOperationAccess().getOriginKeyword_1_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:486:3: (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==RULE_SEMICOLON) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalSM2.g:487:4: this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE
                    {
                    this_SEMICOLON_11=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

                    				newLeafNode(this_SEMICOLON_11, grammarAccess.getTxOperationAccess().getSEMICOLONTerminalRuleCall_2_0());
                    			
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_12, grammarAccess.getTxOperationAccess().getEOLINETerminalRuleCall_2_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTxOperation"


    // $ANTLR start "entryRuleContract"
    // InternalSM2.g:500:1: entryRuleContract returns [EObject current=null] : iv_ruleContract= ruleContract EOF ;
    public final EObject entryRuleContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleContract = null;


        try {
            // InternalSM2.g:500:49: (iv_ruleContract= ruleContract EOF )
            // InternalSM2.g:501:2: iv_ruleContract= ruleContract EOF
            {
             newCompositeNode(grammarAccess.getContractRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleContract=ruleContract();

            state._fsp--;

             current =iv_ruleContract; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleContract"


    // $ANTLR start "ruleContract"
    // InternalSM2.g:507:1: ruleContract returns [EObject current=null] : (otherlv_0= 'contract' ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY ) ;
    public final EObject ruleContract() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameContract_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token this_OPENKEY_4=null;
        Token this_EOLINE_5=null;
        Token this_CLOSEKEY_11=null;
        EObject lv_constructor_6_0 = null;

        AntlrDatatypeRuleToken lv_comments_7_0 = null;

        EObject lv_attributes_8_0 = null;

        EObject lv_modifier_9_0 = null;

        EObject lv_clauses_10_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:513:2: ( (otherlv_0= 'contract' ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY ) )
            // InternalSM2.g:514:2: (otherlv_0= 'contract' ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY )
            {
            // InternalSM2.g:514:2: (otherlv_0= 'contract' ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY )
            // InternalSM2.g:515:3: otherlv_0= 'contract' ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,48,FOLLOW_14); 

            			newLeafNode(otherlv_0, grammarAccess.getContractAccess().getContractKeyword_0());
            		
            // InternalSM2.g:519:3: ( (lv_nameContract_1_0= RULE_ID ) )
            // InternalSM2.g:520:4: (lv_nameContract_1_0= RULE_ID )
            {
            // InternalSM2.g:520:4: (lv_nameContract_1_0= RULE_ID )
            // InternalSM2.g:521:5: lv_nameContract_1_0= RULE_ID
            {
            lv_nameContract_1_0=(Token)match(input,RULE_ID,FOLLOW_15); 

            					newLeafNode(lv_nameContract_1_0, grammarAccess.getContractAccess().getNameContractIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getContractRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameContract",
            						lv_nameContract_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:537:3: (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==49) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalSM2.g:538:4: otherlv_2= 'is' ( (otherlv_3= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,49,FOLLOW_14); 

                    				newLeafNode(otherlv_2, grammarAccess.getContractAccess().getIsKeyword_2_0());
                    			
                    // InternalSM2.g:542:4: ( (otherlv_3= RULE_ID ) )
                    // InternalSM2.g:543:5: (otherlv_3= RULE_ID )
                    {
                    // InternalSM2.g:543:5: (otherlv_3= RULE_ID )
                    // InternalSM2.g:544:6: otherlv_3= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getContractRule());
                    						}
                    					
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_16); 

                    						newLeafNode(otherlv_3, grammarAccess.getContractAccess().getNameContractFatherContractCrossReference_2_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            this_OPENKEY_4=(Token)match(input,RULE_OPENKEY,FOLLOW_17); 

            			newLeafNode(this_OPENKEY_4, grammarAccess.getContractAccess().getOPENKEYTerminalRuleCall_3());
            		
            // InternalSM2.g:560:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==RULE_EOLINE) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalSM2.g:561:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_17); 

                    				newLeafNode(this_EOLINE_5, grammarAccess.getContractAccess().getEOLINETerminalRuleCall_4());
                    			

                    }
                    break;

            }

            // InternalSM2.g:566:3: ( (lv_constructor_6_0= ruleConstructor ) )
            // InternalSM2.g:567:4: (lv_constructor_6_0= ruleConstructor )
            {
            // InternalSM2.g:567:4: (lv_constructor_6_0= ruleConstructor )
            // InternalSM2.g:568:5: lv_constructor_6_0= ruleConstructor
            {

            					newCompositeNode(grammarAccess.getContractAccess().getConstructorConstructorParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_18);
            lv_constructor_6_0=ruleConstructor();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getContractRule());
            					}
            					add(
            						current,
            						"constructor",
            						lv_constructor_6_0,
            						"org.xtext.SM2.Constructor");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:585:3: ( (lv_comments_7_0= ruleComment ) )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( ((LA15_0>=80 && LA15_0<=81)) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalSM2.g:586:4: (lv_comments_7_0= ruleComment )
            	    {
            	    // InternalSM2.g:586:4: (lv_comments_7_0= ruleComment )
            	    // InternalSM2.g:587:5: lv_comments_7_0= ruleComment
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getCommentsCommentParserRuleCall_6_0());
            	    				
            	    pushFollow(FOLLOW_18);
            	    lv_comments_7_0=ruleComment();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"comments",
            	    						lv_comments_7_0,
            	    						"org.xtext.SM2.Comment");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

            // InternalSM2.g:604:3: ( (lv_attributes_8_0= ruleAttributes ) )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( (LA16_0==RULE_ID||LA16_0==69||(LA16_0>=71 && LA16_0<=72)) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // InternalSM2.g:605:4: (lv_attributes_8_0= ruleAttributes )
            	    {
            	    // InternalSM2.g:605:4: (lv_attributes_8_0= ruleAttributes )
            	    // InternalSM2.g:606:5: lv_attributes_8_0= ruleAttributes
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getAttributesAttributesParserRuleCall_7_0());
            	    				
            	    pushFollow(FOLLOW_19);
            	    lv_attributes_8_0=ruleAttributes();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"attributes",
            	    						lv_attributes_8_0,
            	    						"org.xtext.SM2.Attributes");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);

            // InternalSM2.g:623:3: ( (lv_modifier_9_0= ruleModifier ) )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( (LA17_0==59) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalSM2.g:624:4: (lv_modifier_9_0= ruleModifier )
            	    {
            	    // InternalSM2.g:624:4: (lv_modifier_9_0= ruleModifier )
            	    // InternalSM2.g:625:5: lv_modifier_9_0= ruleModifier
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getModifierModifierParserRuleCall_8_0());
            	    				
            	    pushFollow(FOLLOW_20);
            	    lv_modifier_9_0=ruleModifier();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"modifier",
            	    						lv_modifier_9_0,
            	    						"org.xtext.SM2.Modifier");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

            // InternalSM2.g:642:3: ( (lv_clauses_10_0= ruleClause ) )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==75) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalSM2.g:643:4: (lv_clauses_10_0= ruleClause )
            	    {
            	    // InternalSM2.g:643:4: (lv_clauses_10_0= ruleClause )
            	    // InternalSM2.g:644:5: lv_clauses_10_0= ruleClause
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getClausesClauseParserRuleCall_9_0());
            	    				
            	    pushFollow(FOLLOW_21);
            	    lv_clauses_10_0=ruleClause();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"clauses",
            	    						lv_clauses_10_0,
            	    						"org.xtext.SM2.Clause");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); 

            			newLeafNode(this_CLOSEKEY_11, grammarAccess.getContractAccess().getCLOSEKEYTerminalRuleCall_10());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:669:1: entryRuleVersion returns [EObject current=null] : iv_ruleVersion= ruleVersion EOF ;
    public final EObject entryRuleVersion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVersion = null;


        try {
            // InternalSM2.g:669:48: (iv_ruleVersion= ruleVersion EOF )
            // InternalSM2.g:670:2: iv_ruleVersion= ruleVersion EOF
            {
             newCompositeNode(grammarAccess.getVersionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVersion=ruleVersion();

            state._fsp--;

             current =iv_ruleVersion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:676:1: ruleVersion returns [EObject current=null] : (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) ( (otherlv_8= RULE_ID ) )? ) ;
    public final EObject ruleVersion() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_symbol_2_1=null;
        Token lv_symbol_2_2=null;
        Token lv_symbol_2_3=null;
        Token lv_numberVersion_3_0=null;
        Token this_DOT_4=null;
        Token lv_numberVersion2_5_0=null;
        Token this_DOT_6=null;
        Token lv_numberVersion3_7_0=null;
        Token otherlv_8=null;


        	enterRule();

        try {
            // InternalSM2.g:682:2: ( (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) ( (otherlv_8= RULE_ID ) )? ) )
            // InternalSM2.g:683:2: (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) ( (otherlv_8= RULE_ID ) )? )
            {
            // InternalSM2.g:683:2: (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) ( (otherlv_8= RULE_ID ) )? )
            // InternalSM2.g:684:3: otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) ( (otherlv_8= RULE_ID ) )?
            {
            otherlv_0=(Token)match(input,50,FOLLOW_22); 

            			newLeafNode(otherlv_0, grammarAccess.getVersionAccess().getPragmaKeyword_0());
            		
            otherlv_1=(Token)match(input,51,FOLLOW_23); 

            			newLeafNode(otherlv_1, grammarAccess.getVersionAccess().getSolidityKeyword_1());
            		
            // InternalSM2.g:692:3: ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) )
            // InternalSM2.g:693:4: ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) )
            {
            // InternalSM2.g:693:4: ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) )
            // InternalSM2.g:694:5: (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' )
            {
            // InternalSM2.g:694:5: (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' )
            int alt19=3;
            switch ( input.LA(1) ) {
            case 52:
                {
                alt19=1;
                }
                break;
            case 53:
                {
                alt19=2;
                }
                break;
            case 54:
                {
                alt19=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }

            switch (alt19) {
                case 1 :
                    // InternalSM2.g:695:6: lv_symbol_2_1= '^'
                    {
                    lv_symbol_2_1=(Token)match(input,52,FOLLOW_24); 

                    						newLeafNode(lv_symbol_2_1, grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_2_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_2_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:706:6: lv_symbol_2_2= '>'
                    {
                    lv_symbol_2_2=(Token)match(input,53,FOLLOW_24); 

                    						newLeafNode(lv_symbol_2_2, grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_2_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_2_2, null);
                    					

                    }
                    break;
                case 3 :
                    // InternalSM2.g:717:6: lv_symbol_2_3= '>='
                    {
                    lv_symbol_2_3=(Token)match(input,54,FOLLOW_24); 

                    						newLeafNode(lv_symbol_2_3, grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_2_0_2());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_2_3, null);
                    					

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:730:3: ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) )
            // InternalSM2.g:731:4: (lv_numberVersion_3_0= RULE_NUMVERSION1 )
            {
            // InternalSM2.g:731:4: (lv_numberVersion_3_0= RULE_NUMVERSION1 )
            // InternalSM2.g:732:5: lv_numberVersion_3_0= RULE_NUMVERSION1
            {
            lv_numberVersion_3_0=(Token)match(input,RULE_NUMVERSION1,FOLLOW_6); 

            					newLeafNode(lv_numberVersion_3_0, grammarAccess.getVersionAccess().getNumberVersionNUMVERSION1TerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVersionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"numberVersion",
            						lv_numberVersion_3_0,
            						"org.xtext.SM2.NUMVERSION1");
            				

            }


            }

            this_DOT_4=(Token)match(input,RULE_DOT,FOLLOW_25); 

            			newLeafNode(this_DOT_4, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_4());
            		
            // InternalSM2.g:752:3: ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) )
            // InternalSM2.g:753:4: (lv_numberVersion2_5_0= RULE_NUMVERSION2 )
            {
            // InternalSM2.g:753:4: (lv_numberVersion2_5_0= RULE_NUMVERSION2 )
            // InternalSM2.g:754:5: lv_numberVersion2_5_0= RULE_NUMVERSION2
            {
            lv_numberVersion2_5_0=(Token)match(input,RULE_NUMVERSION2,FOLLOW_6); 

            					newLeafNode(lv_numberVersion2_5_0, grammarAccess.getVersionAccess().getNumberVersion2NUMVERSION2TerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVersionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"numberVersion2",
            						lv_numberVersion2_5_0,
            						"org.xtext.SM2.NUMVERSION2");
            				

            }


            }

            this_DOT_6=(Token)match(input,RULE_DOT,FOLLOW_26); 

            			newLeafNode(this_DOT_6, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_6());
            		
            // InternalSM2.g:774:3: ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) )
            // InternalSM2.g:775:4: (lv_numberVersion3_7_0= RULE_NUMVERSION3 )
            {
            // InternalSM2.g:775:4: (lv_numberVersion3_7_0= RULE_NUMVERSION3 )
            // InternalSM2.g:776:5: lv_numberVersion3_7_0= RULE_NUMVERSION3
            {
            lv_numberVersion3_7_0=(Token)match(input,RULE_NUMVERSION3,FOLLOW_27); 

            					newLeafNode(lv_numberVersion3_7_0, grammarAccess.getVersionAccess().getNumberVersion3NUMVERSION3TerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVersionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"numberVersion3",
            						lv_numberVersion3_7_0,
            						"org.xtext.SM2.NUMVERSION3");
            				

            }


            }

            // InternalSM2.g:792:3: ( (otherlv_8= RULE_ID ) )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==RULE_ID) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalSM2.g:793:4: (otherlv_8= RULE_ID )
                    {
                    // InternalSM2.g:793:4: (otherlv_8= RULE_ID )
                    // InternalSM2.g:794:5: otherlv_8= RULE_ID
                    {

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getVersionRule());
                    					}
                    				
                    otherlv_8=(Token)match(input,RULE_ID,FOLLOW_2); 

                    					newLeafNode(otherlv_8, grammarAccess.getVersionAccess().getOptionalversionVersionCrossReference_8_0());
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleConstructor"
    // InternalSM2.g:809:1: entryRuleConstructor returns [EObject current=null] : iv_ruleConstructor= ruleConstructor EOF ;
    public final EObject entryRuleConstructor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConstructor = null;


        try {
            // InternalSM2.g:809:52: (iv_ruleConstructor= ruleConstructor EOF )
            // InternalSM2.g:810:2: iv_ruleConstructor= ruleConstructor EOF
            {
             newCompositeNode(grammarAccess.getConstructorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConstructor=ruleConstructor();

            state._fsp--;

             current =iv_ruleConstructor; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConstructor"


    // $ANTLR start "ruleConstructor"
    // InternalSM2.g:816:1: ruleConstructor returns [EObject current=null] : (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY ) ;
    public final EObject ruleConstructor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_type_3_1=null;
        Token lv_type_3_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_CLOSEKEY_7=null;
        EObject lv_inputParams_2_0 = null;

        EObject lv_Attributes_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:822:2: ( (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY ) )
            // InternalSM2.g:823:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY )
            {
            // InternalSM2.g:823:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY )
            // InternalSM2.g:824:3: otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,55,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getConstructorAccess().getConstructorKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_28); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConstructorAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:832:3: ( (lv_inputParams_2_0= ruleInputParam ) )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( ((LA21_0>=61 && LA21_0<=68)) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalSM2.g:833:4: (lv_inputParams_2_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:833:4: (lv_inputParams_2_0= ruleInputParam )
            	    // InternalSM2.g:834:5: lv_inputParams_2_0= ruleInputParam
            	    {

            	    					newCompositeNode(grammarAccess.getConstructorAccess().getInputParamsInputParamParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_28);
            	    lv_inputParams_2_0=ruleInputParam();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConstructorRule());
            	    					}
            	    					add(
            	    						current,
            	    						"inputParams",
            	    						lv_inputParams_2_0,
            	    						"org.xtext.SM2.InputParam");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

            // InternalSM2.g:851:3: ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) )
            // InternalSM2.g:852:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            {
            // InternalSM2.g:852:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            // InternalSM2.g:853:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            {
            // InternalSM2.g:853:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==56) ) {
                alt22=1;
            }
            else if ( (LA22_0==57) ) {
                alt22=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }
            switch (alt22) {
                case 1 :
                    // InternalSM2.g:854:6: lv_type_3_1= 'public'
                    {
                    lv_type_3_1=(Token)match(input,56,FOLLOW_10); 

                    						newLeafNode(lv_type_3_1, grammarAccess.getConstructorAccess().getTypePublicKeyword_3_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getConstructorRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_3_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:865:6: lv_type_3_2= 'internal'
                    {
                    lv_type_3_2=(Token)match(input,57,FOLLOW_10); 

                    						newLeafNode(lv_type_3_2, grammarAccess.getConstructorAccess().getTypeInternalKeyword_3_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getConstructorRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_3_2, null);
                    					

                    }
                    break;

            }


            }


            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_16); 

            			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getConstructorAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
            		
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_29); 

            			newLeafNode(this_OPENKEY_5, grammarAccess.getConstructorAccess().getOPENKEYTerminalRuleCall_5());
            		
            // InternalSM2.g:886:3: ( (lv_Attributes_6_0= ruleAttributes ) )
            // InternalSM2.g:887:4: (lv_Attributes_6_0= ruleAttributes )
            {
            // InternalSM2.g:887:4: (lv_Attributes_6_0= ruleAttributes )
            // InternalSM2.g:888:5: lv_Attributes_6_0= ruleAttributes
            {

            					newCompositeNode(grammarAccess.getConstructorAccess().getAttributesAttributesParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_30);
            lv_Attributes_6_0=ruleAttributes();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getConstructorRule());
            					}
            					add(
            						current,
            						"Attributes",
            						lv_Attributes_6_0,
            						"org.xtext.SM2.Attributes");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); 

            			newLeafNode(this_CLOSEKEY_7, grammarAccess.getConstructorAccess().getCLOSEKEYTerminalRuleCall_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConstructor"


    // $ANTLR start "entryRuleImport"
    // InternalSM2.g:913:1: entryRuleImport returns [String current=null] : iv_ruleImport= ruleImport EOF ;
    public final String entryRuleImport() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleImport = null;


        try {
            // InternalSM2.g:913:46: (iv_ruleImport= ruleImport EOF )
            // InternalSM2.g:914:2: iv_ruleImport= ruleImport EOF
            {
             newCompositeNode(grammarAccess.getImportRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleImport=ruleImport();

            state._fsp--;

             current =iv_ruleImport.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2.g:920:1: ruleImport returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? ) ;
    public final AntlrDatatypeRuleToken ruleImport() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_STRING_1=null;
        Token this_SEMICOLON_2=null;
        Token this_EOLINE_3=null;


        	enterRule();

        try {
            // InternalSM2.g:926:2: ( (kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? ) )
            // InternalSM2.g:927:2: (kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? )
            {
            // InternalSM2.g:927:2: (kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? )
            // InternalSM2.g:928:3: kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )?
            {
            kw=(Token)match(input,58,FOLLOW_31); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getImportAccess().getImportKeyword_0());
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_32); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getImportAccess().getSTRINGTerminalRuleCall_1());
            		
            this_SEMICOLON_2=(Token)match(input,RULE_SEMICOLON,FOLLOW_33); 

            			current.merge(this_SEMICOLON_2);
            		

            			newLeafNode(this_SEMICOLON_2, grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_2());
            		
            // InternalSM2.g:947:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==RULE_EOLINE) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalSM2.g:948:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				current.merge(this_EOLINE_3);
                    			

                    				newLeafNode(this_EOLINE_3, grammarAccess.getImportAccess().getEOLINETerminalRuleCall_3());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:960:1: entryRuleAttributes returns [EObject current=null] : iv_ruleAttributes= ruleAttributes EOF ;
    public final EObject entryRuleAttributes() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttributes = null;


        try {
            // InternalSM2.g:960:51: (iv_ruleAttributes= ruleAttributes EOF )
            // InternalSM2.g:961:2: iv_ruleAttributes= ruleAttributes EOF
            {
             newCompositeNode(grammarAccess.getAttributesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAttributes=ruleAttributes();

            state._fsp--;

             current =iv_ruleAttributes; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:967:1: ruleAttributes returns [EObject current=null] : this_DataType_0= ruleDataType ;
    public final EObject ruleAttributes() throws RecognitionException {
        EObject current = null;

        EObject this_DataType_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:973:2: (this_DataType_0= ruleDataType )
            // InternalSM2.g:974:2: this_DataType_0= ruleDataType
            {

            		newCompositeNode(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall());
            	
            pushFollow(FOLLOW_2);
            this_DataType_0=ruleDataType();

            state._fsp--;


            		current = this_DataType_0;
            		afterParserOrEnumRuleCall();
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:985:1: entryRuleModifier returns [EObject current=null] : iv_ruleModifier= ruleModifier EOF ;
    public final EObject entryRuleModifier() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModifier = null;


        try {
            // InternalSM2.g:985:49: (iv_ruleModifier= ruleModifier EOF )
            // InternalSM2.g:986:2: iv_ruleModifier= ruleModifier EOF
            {
             newCompositeNode(grammarAccess.getModifierRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModifier=ruleModifier();

            state._fsp--;

             current =iv_ruleModifier; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:992:1: ruleModifier returns [EObject current=null] : (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? ) ;
    public final EObject ruleModifier() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameModifier_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_EOLINE_6=null;
        Token lv_expr_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Token otherlv_10=null;
        Token this_CLOSEKEY_11=null;
        Token this_EOLINE_12=null;
        EObject lv_inputParams_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:998:2: ( (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? ) )
            // InternalSM2.g:999:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? )
            {
            // InternalSM2.g:999:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? )
            // InternalSM2.g:1000:3: otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,59,FOLLOW_14); 

            			newLeafNode(otherlv_0, grammarAccess.getModifierAccess().getModifierKeyword_0());
            		
            // InternalSM2.g:1004:3: ( (lv_nameModifier_1_0= RULE_ID ) )
            // InternalSM2.g:1005:4: (lv_nameModifier_1_0= RULE_ID )
            {
            // InternalSM2.g:1005:4: (lv_nameModifier_1_0= RULE_ID )
            // InternalSM2.g:1006:5: lv_nameModifier_1_0= RULE_ID
            {
            lv_nameModifier_1_0=(Token)match(input,RULE_ID,FOLLOW_8); 

            					newLeafNode(lv_nameModifier_1_0, grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getModifierRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameModifier",
            						lv_nameModifier_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_34); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		
            // InternalSM2.g:1026:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( ((LA24_0>=61 && LA24_0<=68)) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalSM2.g:1027:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1027:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:1028:5: lv_inputParams_3_0= ruleInputParam
            	    {

            	    					newCompositeNode(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_34);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModifierRule());
            	    					}
            	    					add(
            	    						current,
            	    						"inputParams",
            	    						lv_inputParams_3_0,
            	    						"org.xtext.SM2.InputParam");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_16); 

            			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
            		
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_35); 

            			newLeafNode(this_OPENKEY_5, grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5());
            		
            // InternalSM2.g:1053:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==RULE_EOLINE) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalSM2.g:1054:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_31); 

                    				newLeafNode(this_EOLINE_6, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }

            // InternalSM2.g:1059:3: ( (lv_expr_7_0= RULE_STRING ) )
            // InternalSM2.g:1060:4: (lv_expr_7_0= RULE_STRING )
            {
            // InternalSM2.g:1060:4: (lv_expr_7_0= RULE_STRING )
            // InternalSM2.g:1061:5: lv_expr_7_0= RULE_STRING
            {
            lv_expr_7_0=(Token)match(input,RULE_STRING,FOLLOW_32); 

            					newLeafNode(lv_expr_7_0, grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getModifierRule());
            					}
            					setWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_36); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8());
            		
            // InternalSM2.g:1081:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==RULE_EOLINE) ) {
                alt26=1;
            }
            switch (alt26) {
                case 1 :
                    // InternalSM2.g:1082:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_37); 

                    				newLeafNode(this_EOLINE_9, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9());
                    			

                    }
                    break;

            }

            otherlv_10=(Token)match(input,60,FOLLOW_30); 

            			newLeafNode(otherlv_10, grammarAccess.getModifierAccess().get_Keyword_10());
            		
            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_33); 

            			newLeafNode(this_CLOSEKEY_11, grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11());
            		
            // InternalSM2.g:1095:3: (this_EOLINE_12= RULE_EOLINE )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==RULE_EOLINE) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalSM2.g:1096:4: this_EOLINE_12= RULE_EOLINE
                    {
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_12, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:1105:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalSM2.g:1105:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalSM2.g:1106:2: iv_ruleDataType= ruleDataType EOF
            {
             newCompositeNode(grammarAccess.getDataTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;

             current =iv_ruleDataType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:1112:1: ruleDataType returns [EObject current=null] : (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        Token this_ID_2=null;
        EObject this_CompositeType_0 = null;

        EObject this_Enum_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1118:2: ( (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID ) )
            // InternalSM2.g:1119:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID )
            {
            // InternalSM2.g:1119:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID )
            int alt28=3;
            switch ( input.LA(1) ) {
            case 69:
            case 71:
                {
                alt28=1;
                }
                break;
            case 72:
                {
                alt28=2;
                }
                break;
            case RULE_ID:
                {
                alt28=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 28, 0, input);

                throw nvae;
            }

            switch (alt28) {
                case 1 :
                    // InternalSM2.g:1120:3: this_CompositeType_0= ruleCompositeType
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_CompositeType_0=ruleCompositeType();

                    state._fsp--;


                    			current = this_CompositeType_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1129:3: this_Enum_1= ruleEnum
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Enum_1=ruleEnum();

                    state._fsp--;


                    			current = this_Enum_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1138:3: this_ID_2= RULE_ID
                    {
                    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			newLeafNode(this_ID_2, grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2.g:1146:1: entryRuleCompositeType returns [EObject current=null] : iv_ruleCompositeType= ruleCompositeType EOF ;
    public final EObject entryRuleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompositeType = null;


        try {
            // InternalSM2.g:1146:54: (iv_ruleCompositeType= ruleCompositeType EOF )
            // InternalSM2.g:1147:2: iv_ruleCompositeType= ruleCompositeType EOF
            {
             newCompositeNode(grammarAccess.getCompositeTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCompositeType=ruleCompositeType();

            state._fsp--;

             current =iv_ruleCompositeType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2.g:1153:1: ruleCompositeType returns [EObject current=null] : (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) ;
    public final EObject ruleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject this_Mapping_0 = null;

        EObject this_Struct_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1159:2: ( (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) )
            // InternalSM2.g:1160:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            {
            // InternalSM2.g:1160:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==69) ) {
                alt29=1;
            }
            else if ( (LA29_0==71) ) {
                alt29=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 29, 0, input);

                throw nvae;
            }
            switch (alt29) {
                case 1 :
                    // InternalSM2.g:1161:3: this_Mapping_0= ruleMapping
                    {

                    			newCompositeNode(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Mapping_0=ruleMapping();

                    state._fsp--;


                    			current = this_Mapping_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1170:3: this_Struct_1= ruleStruct
                    {

                    			newCompositeNode(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Struct_1=ruleStruct();

                    state._fsp--;


                    			current = this_Struct_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleSingularType"
    // InternalSM2.g:1182:1: entryRuleSingularType returns [EObject current=null] : iv_ruleSingularType= ruleSingularType EOF ;
    public final EObject entryRuleSingularType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSingularType = null;


        try {
            // InternalSM2.g:1182:53: (iv_ruleSingularType= ruleSingularType EOF )
            // InternalSM2.g:1183:2: iv_ruleSingularType= ruleSingularType EOF
            {
             newCompositeNode(grammarAccess.getSingularTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSingularType=ruleSingularType();

            state._fsp--;

             current =iv_ruleSingularType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSingularType"


    // $ANTLR start "ruleSingularType"
    // InternalSM2.g:1189:1: ruleSingularType returns [EObject current=null] : ( ( (lv_INT_0_0= 'int' ) ) | ( (lv_UINT_1_0= 'uint' ) ) | ( (lv_UINT8_2_0= 'uint8' ) ) | ( (lv_STRING_3_0= 'string' ) ) | ( (lv_ADDRESS_4_0= 'address' ) ) | ( (lv_ADDRESSPAYABLE_5_0= 'address payable' ) ) | ( (lv_DOUBLE_6_0= 'double' ) ) | ( (lv_BOOLEAN_7_0= 'bool' ) ) ) ;
    public final EObject ruleSingularType() throws RecognitionException {
        EObject current = null;

        Token lv_INT_0_0=null;
        Token lv_UINT_1_0=null;
        Token lv_UINT8_2_0=null;
        Token lv_STRING_3_0=null;
        Token lv_ADDRESS_4_0=null;
        Token lv_ADDRESSPAYABLE_5_0=null;
        Token lv_DOUBLE_6_0=null;
        Token lv_BOOLEAN_7_0=null;


        	enterRule();

        try {
            // InternalSM2.g:1195:2: ( ( ( (lv_INT_0_0= 'int' ) ) | ( (lv_UINT_1_0= 'uint' ) ) | ( (lv_UINT8_2_0= 'uint8' ) ) | ( (lv_STRING_3_0= 'string' ) ) | ( (lv_ADDRESS_4_0= 'address' ) ) | ( (lv_ADDRESSPAYABLE_5_0= 'address payable' ) ) | ( (lv_DOUBLE_6_0= 'double' ) ) | ( (lv_BOOLEAN_7_0= 'bool' ) ) ) )
            // InternalSM2.g:1196:2: ( ( (lv_INT_0_0= 'int' ) ) | ( (lv_UINT_1_0= 'uint' ) ) | ( (lv_UINT8_2_0= 'uint8' ) ) | ( (lv_STRING_3_0= 'string' ) ) | ( (lv_ADDRESS_4_0= 'address' ) ) | ( (lv_ADDRESSPAYABLE_5_0= 'address payable' ) ) | ( (lv_DOUBLE_6_0= 'double' ) ) | ( (lv_BOOLEAN_7_0= 'bool' ) ) )
            {
            // InternalSM2.g:1196:2: ( ( (lv_INT_0_0= 'int' ) ) | ( (lv_UINT_1_0= 'uint' ) ) | ( (lv_UINT8_2_0= 'uint8' ) ) | ( (lv_STRING_3_0= 'string' ) ) | ( (lv_ADDRESS_4_0= 'address' ) ) | ( (lv_ADDRESSPAYABLE_5_0= 'address payable' ) ) | ( (lv_DOUBLE_6_0= 'double' ) ) | ( (lv_BOOLEAN_7_0= 'bool' ) ) )
            int alt30=8;
            switch ( input.LA(1) ) {
            case 61:
                {
                alt30=1;
                }
                break;
            case 62:
                {
                alt30=2;
                }
                break;
            case 63:
                {
                alt30=3;
                }
                break;
            case 64:
                {
                alt30=4;
                }
                break;
            case 65:
                {
                alt30=5;
                }
                break;
            case 66:
                {
                alt30=6;
                }
                break;
            case 67:
                {
                alt30=7;
                }
                break;
            case 68:
                {
                alt30=8;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 30, 0, input);

                throw nvae;
            }

            switch (alt30) {
                case 1 :
                    // InternalSM2.g:1197:3: ( (lv_INT_0_0= 'int' ) )
                    {
                    // InternalSM2.g:1197:3: ( (lv_INT_0_0= 'int' ) )
                    // InternalSM2.g:1198:4: (lv_INT_0_0= 'int' )
                    {
                    // InternalSM2.g:1198:4: (lv_INT_0_0= 'int' )
                    // InternalSM2.g:1199:5: lv_INT_0_0= 'int'
                    {
                    lv_INT_0_0=(Token)match(input,61,FOLLOW_2); 

                    					newLeafNode(lv_INT_0_0, grammarAccess.getSingularTypeAccess().getINTIntKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getSingularTypeRule());
                    					}
                    					setWithLastConsumed(current, "INT", lv_INT_0_0, "int");
                    				

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1212:3: ( (lv_UINT_1_0= 'uint' ) )
                    {
                    // InternalSM2.g:1212:3: ( (lv_UINT_1_0= 'uint' ) )
                    // InternalSM2.g:1213:4: (lv_UINT_1_0= 'uint' )
                    {
                    // InternalSM2.g:1213:4: (lv_UINT_1_0= 'uint' )
                    // InternalSM2.g:1214:5: lv_UINT_1_0= 'uint'
                    {
                    lv_UINT_1_0=(Token)match(input,62,FOLLOW_2); 

                    					newLeafNode(lv_UINT_1_0, grammarAccess.getSingularTypeAccess().getUINTUintKeyword_1_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getSingularTypeRule());
                    					}
                    					setWithLastConsumed(current, "UINT", lv_UINT_1_0, "uint");
                    				

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1227:3: ( (lv_UINT8_2_0= 'uint8' ) )
                    {
                    // InternalSM2.g:1227:3: ( (lv_UINT8_2_0= 'uint8' ) )
                    // InternalSM2.g:1228:4: (lv_UINT8_2_0= 'uint8' )
                    {
                    // InternalSM2.g:1228:4: (lv_UINT8_2_0= 'uint8' )
                    // InternalSM2.g:1229:5: lv_UINT8_2_0= 'uint8'
                    {
                    lv_UINT8_2_0=(Token)match(input,63,FOLLOW_2); 

                    					newLeafNode(lv_UINT8_2_0, grammarAccess.getSingularTypeAccess().getUINT8Uint8Keyword_2_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getSingularTypeRule());
                    					}
                    					setWithLastConsumed(current, "UINT8", lv_UINT8_2_0, "uint8");
                    				

                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1242:3: ( (lv_STRING_3_0= 'string' ) )
                    {
                    // InternalSM2.g:1242:3: ( (lv_STRING_3_0= 'string' ) )
                    // InternalSM2.g:1243:4: (lv_STRING_3_0= 'string' )
                    {
                    // InternalSM2.g:1243:4: (lv_STRING_3_0= 'string' )
                    // InternalSM2.g:1244:5: lv_STRING_3_0= 'string'
                    {
                    lv_STRING_3_0=(Token)match(input,64,FOLLOW_2); 

                    					newLeafNode(lv_STRING_3_0, grammarAccess.getSingularTypeAccess().getSTRINGStringKeyword_3_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getSingularTypeRule());
                    					}
                    					setWithLastConsumed(current, "STRING", lv_STRING_3_0, "string");
                    				

                    }


                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1257:3: ( (lv_ADDRESS_4_0= 'address' ) )
                    {
                    // InternalSM2.g:1257:3: ( (lv_ADDRESS_4_0= 'address' ) )
                    // InternalSM2.g:1258:4: (lv_ADDRESS_4_0= 'address' )
                    {
                    // InternalSM2.g:1258:4: (lv_ADDRESS_4_0= 'address' )
                    // InternalSM2.g:1259:5: lv_ADDRESS_4_0= 'address'
                    {
                    lv_ADDRESS_4_0=(Token)match(input,65,FOLLOW_2); 

                    					newLeafNode(lv_ADDRESS_4_0, grammarAccess.getSingularTypeAccess().getADDRESSAddressKeyword_4_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getSingularTypeRule());
                    					}
                    					setWithLastConsumed(current, "ADDRESS", lv_ADDRESS_4_0, "address");
                    				

                    }


                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1272:3: ( (lv_ADDRESSPAYABLE_5_0= 'address payable' ) )
                    {
                    // InternalSM2.g:1272:3: ( (lv_ADDRESSPAYABLE_5_0= 'address payable' ) )
                    // InternalSM2.g:1273:4: (lv_ADDRESSPAYABLE_5_0= 'address payable' )
                    {
                    // InternalSM2.g:1273:4: (lv_ADDRESSPAYABLE_5_0= 'address payable' )
                    // InternalSM2.g:1274:5: lv_ADDRESSPAYABLE_5_0= 'address payable'
                    {
                    lv_ADDRESSPAYABLE_5_0=(Token)match(input,66,FOLLOW_2); 

                    					newLeafNode(lv_ADDRESSPAYABLE_5_0, grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEAddressPayableKeyword_5_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getSingularTypeRule());
                    					}
                    					setWithLastConsumed(current, "ADDRESSPAYABLE", lv_ADDRESSPAYABLE_5_0, "address payable");
                    				

                    }


                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:1287:3: ( (lv_DOUBLE_6_0= 'double' ) )
                    {
                    // InternalSM2.g:1287:3: ( (lv_DOUBLE_6_0= 'double' ) )
                    // InternalSM2.g:1288:4: (lv_DOUBLE_6_0= 'double' )
                    {
                    // InternalSM2.g:1288:4: (lv_DOUBLE_6_0= 'double' )
                    // InternalSM2.g:1289:5: lv_DOUBLE_6_0= 'double'
                    {
                    lv_DOUBLE_6_0=(Token)match(input,67,FOLLOW_2); 

                    					newLeafNode(lv_DOUBLE_6_0, grammarAccess.getSingularTypeAccess().getDOUBLEDoubleKeyword_6_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getSingularTypeRule());
                    					}
                    					setWithLastConsumed(current, "DOUBLE", lv_DOUBLE_6_0, "double");
                    				

                    }


                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:1302:3: ( (lv_BOOLEAN_7_0= 'bool' ) )
                    {
                    // InternalSM2.g:1302:3: ( (lv_BOOLEAN_7_0= 'bool' ) )
                    // InternalSM2.g:1303:4: (lv_BOOLEAN_7_0= 'bool' )
                    {
                    // InternalSM2.g:1303:4: (lv_BOOLEAN_7_0= 'bool' )
                    // InternalSM2.g:1304:5: lv_BOOLEAN_7_0= 'bool'
                    {
                    lv_BOOLEAN_7_0=(Token)match(input,68,FOLLOW_2); 

                    					newLeafNode(lv_BOOLEAN_7_0, grammarAccess.getSingularTypeAccess().getBOOLEANBoolKeyword_7_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getSingularTypeRule());
                    					}
                    					setWithLastConsumed(current, "BOOLEAN", lv_BOOLEAN_7_0, "bool");
                    				

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:1320:1: entryRuleMapping returns [EObject current=null] : iv_ruleMapping= ruleMapping EOF ;
    public final EObject entryRuleMapping() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMapping = null;


        try {
            // InternalSM2.g:1320:48: (iv_ruleMapping= ruleMapping EOF )
            // InternalSM2.g:1321:2: iv_ruleMapping= ruleMapping EOF
            {
             newCompositeNode(grammarAccess.getMappingRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMapping=ruleMapping();

            state._fsp--;

             current =iv_ruleMapping; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:1327:1: ruleMapping returns [EObject current=null] : (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON ) ;
    public final EObject ruleMapping() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_3=null;
        Token lv_expr_4_0=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token lv_nameMapping_7_0=null;
        Token this_SEMICOLON_8=null;
        EObject lv_type_2_0 = null;

        Enumerator lv_visibility_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1333:2: ( (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON ) )
            // InternalSM2.g:1334:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON )
            {
            // InternalSM2.g:1334:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON )
            // InternalSM2.g:1335:3: otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON
            {
            otherlv_0=(Token)match(input,69,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getMappingAccess().getMappingKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_38); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:1343:3: ( (lv_type_2_0= ruleSingularType ) )
            // InternalSM2.g:1344:4: (lv_type_2_0= ruleSingularType )
            {
            // InternalSM2.g:1344:4: (lv_type_2_0= ruleSingularType )
            // InternalSM2.g:1345:5: lv_type_2_0= ruleSingularType
            {

            					newCompositeNode(grammarAccess.getMappingAccess().getTypeSingularTypeParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_39);
            lv_type_2_0=ruleSingularType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMappingRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_2_0,
            						"org.xtext.SM2.SingularType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,70,FOLLOW_31); 

            			newLeafNode(otherlv_3, grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3());
            		
            // InternalSM2.g:1366:3: ( (lv_expr_4_0= RULE_STRING ) )
            // InternalSM2.g:1367:4: (lv_expr_4_0= RULE_STRING )
            {
            // InternalSM2.g:1367:4: (lv_expr_4_0= RULE_STRING )
            // InternalSM2.g:1368:5: lv_expr_4_0= RULE_STRING
            {
            lv_expr_4_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_expr_4_0, grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMappingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_4_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_40); 

            			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
            		
            // InternalSM2.g:1388:3: ( (lv_visibility_6_0= ruleVisibility ) )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( ((LA31_0>=56 && LA31_0<=57)||LA31_0==84) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalSM2.g:1389:4: (lv_visibility_6_0= ruleVisibility )
                    {
                    // InternalSM2.g:1389:4: (lv_visibility_6_0= ruleVisibility )
                    // InternalSM2.g:1390:5: lv_visibility_6_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0());
                    				
                    pushFollow(FOLLOW_14);
                    lv_visibility_6_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getMappingRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_6_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:1407:3: ( (lv_nameMapping_7_0= RULE_ID ) )
            // InternalSM2.g:1408:4: (lv_nameMapping_7_0= RULE_ID )
            {
            // InternalSM2.g:1408:4: (lv_nameMapping_7_0= RULE_ID )
            // InternalSM2.g:1409:5: lv_nameMapping_7_0= RULE_ID
            {
            lv_nameMapping_7_0=(Token)match(input,RULE_ID,FOLLOW_32); 

            					newLeafNode(lv_nameMapping_7_0, grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMappingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameMapping",
            						lv_nameMapping_7_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:1433:1: entryRuleStruct returns [EObject current=null] : iv_ruleStruct= ruleStruct EOF ;
    public final EObject entryRuleStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStruct = null;


        try {
            // InternalSM2.g:1433:47: (iv_ruleStruct= ruleStruct EOF )
            // InternalSM2.g:1434:2: iv_ruleStruct= ruleStruct EOF
            {
             newCompositeNode(grammarAccess.getStructRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStruct=ruleStruct();

            state._fsp--;

             current =iv_ruleStruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:1440:1: ruleStruct returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject ruleStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_CLOSEKEY_5=null;
        Token this_EOLINE_6=null;
        EObject lv_properties_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1446:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1447:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1447:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1448:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,71,FOLLOW_14); 

            			newLeafNode(otherlv_0, grammarAccess.getStructAccess().getStructKeyword_0());
            		
            // InternalSM2.g:1452:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1453:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1453:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1454:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_16); 

            					newLeafNode(lv_nameStruct_1_0, grammarAccess.getStructAccess().getNameStructIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getStructRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameStruct",
            						lv_nameStruct_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_41); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getStructAccess().getOPENKEYTerminalRuleCall_2());
            		
            // InternalSM2.g:1474:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==RULE_EOLINE) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalSM2.g:1475:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_41); 

                    				newLeafNode(this_EOLINE_3, grammarAccess.getStructAccess().getEOLINETerminalRuleCall_3());
                    			

                    }
                    break;

            }

            // InternalSM2.g:1480:3: ( (lv_properties_4_0= ruleProperty ) )
            // InternalSM2.g:1481:4: (lv_properties_4_0= ruleProperty )
            {
            // InternalSM2.g:1481:4: (lv_properties_4_0= ruleProperty )
            // InternalSM2.g:1482:5: lv_properties_4_0= ruleProperty
            {

            					newCompositeNode(grammarAccess.getStructAccess().getPropertiesPropertyParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_30);
            lv_properties_4_0=ruleProperty();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getStructRule());
            					}
            					add(
            						current,
            						"properties",
            						lv_properties_4_0,
            						"org.xtext.SM2.Property");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_33); 

            			newLeafNode(this_CLOSEKEY_5, grammarAccess.getStructAccess().getCLOSEKEYTerminalRuleCall_5());
            		
            // InternalSM2.g:1503:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==RULE_EOLINE) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // InternalSM2.g:1504:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_6, grammarAccess.getStructAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:1513:1: entryRuleEnum returns [EObject current=null] : iv_ruleEnum= ruleEnum EOF ;
    public final EObject entryRuleEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnum = null;


        try {
            // InternalSM2.g:1513:45: (iv_ruleEnum= ruleEnum EOF )
            // InternalSM2.g:1514:2: iv_ruleEnum= ruleEnum EOF
            {
             newCompositeNode(grammarAccess.getEnumRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEnum=ruleEnum();

            state._fsp--;

             current =iv_ruleEnum; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:1520:1: ruleEnum returns [EObject current=null] : (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_ID_1=null;
        Token this_OPENKEY_2=null;
        Token this_STRING_3=null;
        Token this_COMMA_4=null;
        Token this_CLOSEKEY_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;


        	enterRule();

        try {
            // InternalSM2.g:1526:2: ( (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:1527:2: (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:1527:2: (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:1528:3: otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,72,FOLLOW_14); 

            			newLeafNode(otherlv_0, grammarAccess.getEnumAccess().getEnumKeyword_0());
            		
            this_ID_1=(Token)match(input,RULE_ID,FOLLOW_16); 

            			newLeafNode(this_ID_1, grammarAccess.getEnumAccess().getIDTerminalRuleCall_1());
            		
            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_31); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2());
            		
            this_STRING_3=(Token)match(input,RULE_STRING,FOLLOW_42); 

            			newLeafNode(this_STRING_3, grammarAccess.getEnumAccess().getSTRINGTerminalRuleCall_3());
            		
            // InternalSM2.g:1544:3: (this_COMMA_4= RULE_COMMA )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==RULE_COMMA) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalSM2.g:1545:4: this_COMMA_4= RULE_COMMA
                    {
                    this_COMMA_4=(Token)match(input,RULE_COMMA,FOLLOW_30); 

                    				newLeafNode(this_COMMA_4, grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_4());
                    			

                    }
                    break;

            }

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_32); 

            			newLeafNode(this_CLOSEKEY_5, grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_5());
            		
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_33); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:1558:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==RULE_EOLINE) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalSM2.g:1559:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:1568:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // InternalSM2.g:1568:49: (iv_ruleProperty= ruleProperty EOF )
            // InternalSM2.g:1569:2: iv_ruleProperty= ruleProperty EOF
            {
             newCompositeNode(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleProperty=ruleProperty();

            state._fsp--;

             current =iv_ruleProperty; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:1575:1: ruleProperty returns [EObject current=null] : ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        Token lv_nameProperty_2_0=null;
        Token otherlv_3=null;
        Token lv_inicialization_4_0=null;
        Token this_INT_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        EObject lv_type_0_0 = null;

        Enumerator lv_visibility_1_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1581:2: ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:1582:2: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:1582:2: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:1583:3: ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:1583:3: ( (lv_type_0_0= ruleSingularType ) )
            // InternalSM2.g:1584:4: (lv_type_0_0= ruleSingularType )
            {
            // InternalSM2.g:1584:4: (lv_type_0_0= ruleSingularType )
            // InternalSM2.g:1585:5: lv_type_0_0= ruleSingularType
            {

            					newCompositeNode(grammarAccess.getPropertyAccess().getTypeSingularTypeParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_40);
            lv_type_0_0=ruleSingularType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPropertyRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_0_0,
            						"org.xtext.SM2.SingularType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:1602:3: ( (lv_visibility_1_0= ruleVisibility ) )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( ((LA36_0>=56 && LA36_0<=57)||LA36_0==84) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalSM2.g:1603:4: (lv_visibility_1_0= ruleVisibility )
                    {
                    // InternalSM2.g:1603:4: (lv_visibility_1_0= ruleVisibility )
                    // InternalSM2.g:1604:5: lv_visibility_1_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_14);
                    lv_visibility_1_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_1_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:1621:3: ( (lv_nameProperty_2_0= RULE_ID ) )
            // InternalSM2.g:1622:4: (lv_nameProperty_2_0= RULE_ID )
            {
            // InternalSM2.g:1622:4: (lv_nameProperty_2_0= RULE_ID )
            // InternalSM2.g:1623:5: lv_nameProperty_2_0= RULE_ID
            {
            lv_nameProperty_2_0=(Token)match(input,RULE_ID,FOLLOW_43); 

            					newLeafNode(lv_nameProperty_2_0, grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameProperty",
            						lv_nameProperty_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_3=(Token)match(input,73,FOLLOW_44); 

            			newLeafNode(otherlv_3, grammarAccess.getPropertyAccess().getEqualsSignKeyword_3());
            		
            // InternalSM2.g:1643:3: ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )?
            int alt37=3;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==RULE_STRING) ) {
                alt37=1;
            }
            else if ( (LA37_0==RULE_INT) ) {
                alt37=2;
            }
            switch (alt37) {
                case 1 :
                    // InternalSM2.g:1644:4: ( (lv_inicialization_4_0= RULE_STRING ) )
                    {
                    // InternalSM2.g:1644:4: ( (lv_inicialization_4_0= RULE_STRING ) )
                    // InternalSM2.g:1645:5: (lv_inicialization_4_0= RULE_STRING )
                    {
                    // InternalSM2.g:1645:5: (lv_inicialization_4_0= RULE_STRING )
                    // InternalSM2.g:1646:6: lv_inicialization_4_0= RULE_STRING
                    {
                    lv_inicialization_4_0=(Token)match(input,RULE_STRING,FOLLOW_32); 

                    						newLeafNode(lv_inicialization_4_0, grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"inicialization",
                    							lv_inicialization_4_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1663:4: this_INT_5= RULE_INT
                    {
                    this_INT_5=(Token)match(input,RULE_INT,FOLLOW_32); 

                    				newLeafNode(this_INT_5, grammarAccess.getPropertyAccess().getINTTerminalRuleCall_4_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_33); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_5());
            		
            // InternalSM2.g:1672:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==RULE_EOLINE) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:1673:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:1682:1: entryRuleInputParam returns [EObject current=null] : iv_ruleInputParam= ruleInputParam EOF ;
    public final EObject entryRuleInputParam() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputParam = null;


        try {
            // InternalSM2.g:1682:51: (iv_ruleInputParam= ruleInputParam EOF )
            // InternalSM2.g:1683:2: iv_ruleInputParam= ruleInputParam EOF
            {
             newCompositeNode(grammarAccess.getInputParamRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputParam=ruleInputParam();

            state._fsp--;

             current =iv_ruleInputParam; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:1689:1: ruleInputParam returns [EObject current=null] : (this_SingularType_0= ruleSingularType ( (lv_nameParam_1_0= RULE_ID ) ) (this_COMMA_2= RULE_COMMA )? ) ;
    public final EObject ruleInputParam() throws RecognitionException {
        EObject current = null;

        Token lv_nameParam_1_0=null;
        Token this_COMMA_2=null;
        EObject this_SingularType_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1695:2: ( (this_SingularType_0= ruleSingularType ( (lv_nameParam_1_0= RULE_ID ) ) (this_COMMA_2= RULE_COMMA )? ) )
            // InternalSM2.g:1696:2: (this_SingularType_0= ruleSingularType ( (lv_nameParam_1_0= RULE_ID ) ) (this_COMMA_2= RULE_COMMA )? )
            {
            // InternalSM2.g:1696:2: (this_SingularType_0= ruleSingularType ( (lv_nameParam_1_0= RULE_ID ) ) (this_COMMA_2= RULE_COMMA )? )
            // InternalSM2.g:1697:3: this_SingularType_0= ruleSingularType ( (lv_nameParam_1_0= RULE_ID ) ) (this_COMMA_2= RULE_COMMA )?
            {

            			newCompositeNode(grammarAccess.getInputParamAccess().getSingularTypeParserRuleCall_0());
            		
            pushFollow(FOLLOW_14);
            this_SingularType_0=ruleSingularType();

            state._fsp--;


            			current = this_SingularType_0;
            			afterParserOrEnumRuleCall();
            		
            // InternalSM2.g:1705:3: ( (lv_nameParam_1_0= RULE_ID ) )
            // InternalSM2.g:1706:4: (lv_nameParam_1_0= RULE_ID )
            {
            // InternalSM2.g:1706:4: (lv_nameParam_1_0= RULE_ID )
            // InternalSM2.g:1707:5: lv_nameParam_1_0= RULE_ID
            {
            lv_nameParam_1_0=(Token)match(input,RULE_ID,FOLLOW_45); 

            					newLeafNode(lv_nameParam_1_0, grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInputParamRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameParam",
            						lv_nameParam_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:1723:3: (this_COMMA_2= RULE_COMMA )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==RULE_COMMA) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalSM2.g:1724:4: this_COMMA_2= RULE_COMMA
                    {
                    this_COMMA_2=(Token)match(input,RULE_COMMA,FOLLOW_2); 

                    				newLeafNode(this_COMMA_2, grammarAccess.getInputParamAccess().getCOMMATerminalRuleCall_2());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestrictionClause"
    // InternalSM2.g:1733:1: entryRuleRestrictionClause returns [EObject current=null] : iv_ruleRestrictionClause= ruleRestrictionClause EOF ;
    public final EObject entryRuleRestrictionClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionClause = null;


        try {
            // InternalSM2.g:1733:58: (iv_ruleRestrictionClause= ruleRestrictionClause EOF )
            // InternalSM2.g:1734:2: iv_ruleRestrictionClause= ruleRestrictionClause EOF
            {
             newCompositeNode(grammarAccess.getRestrictionClauseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionClause=ruleRestrictionClause();

            state._fsp--;

             current =iv_ruleRestrictionClause; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionClause"


    // $ANTLR start "ruleRestrictionClause"
    // InternalSM2.g:1740:1: ruleRestrictionClause returns [EObject current=null] : (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas ) ;
    public final EObject ruleRestrictionClause() throws RecognitionException {
        EObject current = null;

        EObject this_Restriction_0 = null;

        EObject this_RestrictionGas_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1746:2: ( (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas ) )
            // InternalSM2.g:1747:2: (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas )
            {
            // InternalSM2.g:1747:2: (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas )
            int alt40=2;
            alt40 = dfa40.predict(input);
            switch (alt40) {
                case 1 :
                    // InternalSM2.g:1748:3: this_Restriction_0= ruleRestriction
                    {

                    			newCompositeNode(grammarAccess.getRestrictionClauseAccess().getRestrictionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Restriction_0=ruleRestriction();

                    state._fsp--;


                    			current = this_Restriction_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1757:3: this_RestrictionGas_1= ruleRestrictionGas
                    {

                    			newCompositeNode(grammarAccess.getRestrictionClauseAccess().getRestrictionGasParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_RestrictionGas_1=ruleRestrictionGas();

                    state._fsp--;


                    			current = this_RestrictionGas_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionClause"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:1769:1: entryRuleRestriction returns [EObject current=null] : iv_ruleRestriction= ruleRestriction EOF ;
    public final EObject entryRuleRestriction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestriction = null;


        try {
            // InternalSM2.g:1769:52: (iv_ruleRestriction= ruleRestriction EOF )
            // InternalSM2.g:1770:2: iv_ruleRestriction= ruleRestriction EOF
            {
             newCompositeNode(grammarAccess.getRestrictionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestriction=ruleRestriction();

            state._fsp--;

             current =iv_ruleRestriction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:1776:1: ruleRestriction returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) ;
    public final EObject ruleRestriction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        AntlrDatatypeRuleToken lv_expr_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1782:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) )
            // InternalSM2.g:1783:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            {
            // InternalSM2.g:1783:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            // InternalSM2.g:1784:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,74,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getRestrictionAccess().getRequireKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:1792:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:1793:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:1793:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2.g:1794:5: lv_expr_2_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_46);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_2_0,
            						"org.xtext.SM2.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:1811:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:1812:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:1812:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:1813:5: lv_operator_3_0= ruleComparationOperator
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_9);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"operator",
            						lv_operator_3_0,
            						"org.xtext.SM2.ComparationOperator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:1830:3: ( (lv_expr_4_0= ruleSyntaxExpression ) )
            // InternalSM2.g:1831:4: (lv_expr_4_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:1831:4: (lv_expr_4_0= ruleSyntaxExpression )
            // InternalSM2.g:1832:5: lv_expr_4_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_10);
            lv_expr_4_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_4_0,
            						"org.xtext.SM2.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_32); 

            			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
            		
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6());
            		
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_7, grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:1865:1: entryRuleRestrictionGas returns [EObject current=null] : iv_ruleRestrictionGas= ruleRestrictionGas EOF ;
    public final EObject entryRuleRestrictionGas() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionGas = null;


        try {
            // InternalSM2.g:1865:55: (iv_ruleRestrictionGas= ruleRestrictionGas EOF )
            // InternalSM2.g:1866:2: iv_ruleRestrictionGas= ruleRestrictionGas EOF
            {
             newCompositeNode(grammarAccess.getRestrictionGasRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionGas=ruleRestrictionGas();

            state._fsp--;

             current =iv_ruleRestrictionGas; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:1872:1: ruleRestrictionGas returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) ;
    public final EObject ruleRestrictionGas() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_amount_4_0=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        AntlrDatatypeRuleToken lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        Enumerator lv_typeCoin_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1878:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) )
            // InternalSM2.g:1879:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            {
            // InternalSM2.g:1879:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            // InternalSM2.g:1880:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,74,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getRestrictionGasAccess().getRequireKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:1888:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:1889:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:1889:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2.g:1890:5: lv_expr_2_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_46);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_2_0,
            						"org.xtext.SM2.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:1907:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:1908:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:1908:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:1909:5: lv_operator_3_0= ruleComparationOperator
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_47);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"operator",
            						lv_operator_3_0,
            						"org.xtext.SM2.ComparationOperator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:1926:3: ( (lv_amount_4_0= RULE_INT ) )
            // InternalSM2.g:1927:4: (lv_amount_4_0= RULE_INT )
            {
            // InternalSM2.g:1927:4: (lv_amount_4_0= RULE_INT )
            // InternalSM2.g:1928:5: lv_amount_4_0= RULE_INT
            {
            lv_amount_4_0=(Token)match(input,RULE_INT,FOLLOW_48); 

            					newLeafNode(lv_amount_4_0, grammarAccess.getRestrictionGasAccess().getAmountINTTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRestrictionGasRule());
            					}
            					setWithLastConsumed(
            						current,
            						"amount",
            						lv_amount_4_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalSM2.g:1944:3: ( (lv_typeCoin_5_0= ruleCoin ) )
            // InternalSM2.g:1945:4: (lv_typeCoin_5_0= ruleCoin )
            {
            // InternalSM2.g:1945:4: (lv_typeCoin_5_0= ruleCoin )
            // InternalSM2.g:1946:5: lv_typeCoin_5_0= ruleCoin
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0());
            				
            pushFollow(FOLLOW_10);
            lv_typeCoin_5_0=ruleCoin();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"typeCoin",
            						lv_typeCoin_5_0,
            						"org.xtext.SM2.Coin");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_32); 

            			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
            		
            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7());
            		
            this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_8, grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2.g:1979:1: entryRuleClause returns [EObject current=null] : iv_ruleClause= ruleClause EOF ;
    public final EObject entryRuleClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClause = null;


        try {
            // InternalSM2.g:1979:47: (iv_ruleClause= ruleClause EOF )
            // InternalSM2.g:1980:2: iv_ruleClause= ruleClause EOF
            {
             newCompositeNode(grammarAccess.getClauseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleClause=ruleClause();

            state._fsp--;

             current =iv_ruleClause; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2.g:1986:1: ruleClause returns [EObject current=null] : (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restriction_8_0= ruleRestrictionClause ) )? ( (lv_expression_9_0= ruleExpression ) )? (this_EOLINE_10= RULE_EOLINE )? this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE ) ;
    public final EObject ruleClause() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameFunction_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_OPENKEY_6=null;
        Token this_EOLINE_7=null;
        Token this_EOLINE_10=null;
        Token this_CLOSEKEY_11=null;
        Token this_EOLINE_12=null;
        EObject lv_inputParams_3_0 = null;

        Enumerator lv_visibilityAccess_4_0 = null;

        EObject lv_restriction_8_0 = null;

        AntlrDatatypeRuleToken lv_expression_9_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1992:2: ( (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restriction_8_0= ruleRestrictionClause ) )? ( (lv_expression_9_0= ruleExpression ) )? (this_EOLINE_10= RULE_EOLINE )? this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE ) )
            // InternalSM2.g:1993:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restriction_8_0= ruleRestrictionClause ) )? ( (lv_expression_9_0= ruleExpression ) )? (this_EOLINE_10= RULE_EOLINE )? this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE )
            {
            // InternalSM2.g:1993:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restriction_8_0= ruleRestrictionClause ) )? ( (lv_expression_9_0= ruleExpression ) )? (this_EOLINE_10= RULE_EOLINE )? this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE )
            // InternalSM2.g:1994:3: otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restriction_8_0= ruleRestrictionClause ) )? ( (lv_expression_9_0= ruleExpression ) )? (this_EOLINE_10= RULE_EOLINE )? this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,75,FOLLOW_14); 

            			newLeafNode(otherlv_0, grammarAccess.getClauseAccess().getFunctionKeyword_0());
            		
            // InternalSM2.g:1998:3: ( (lv_nameFunction_1_0= RULE_ID ) )
            // InternalSM2.g:1999:4: (lv_nameFunction_1_0= RULE_ID )
            {
            // InternalSM2.g:1999:4: (lv_nameFunction_1_0= RULE_ID )
            // InternalSM2.g:2000:5: lv_nameFunction_1_0= RULE_ID
            {
            lv_nameFunction_1_0=(Token)match(input,RULE_ID,FOLLOW_8); 

            					newLeafNode(lv_nameFunction_1_0, grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getClauseRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameFunction",
            						lv_nameFunction_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_38); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		
            // InternalSM2.g:2020:3: ( (lv_inputParams_3_0= ruleInputParam ) )
            // InternalSM2.g:2021:4: (lv_inputParams_3_0= ruleInputParam )
            {
            // InternalSM2.g:2021:4: (lv_inputParams_3_0= ruleInputParam )
            // InternalSM2.g:2022:5: lv_inputParams_3_0= ruleInputParam
            {

            					newCompositeNode(grammarAccess.getClauseAccess().getInputParamsInputParamParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_49);
            lv_inputParams_3_0=ruleInputParam();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getClauseRule());
            					}
            					add(
            						current,
            						"inputParams",
            						lv_inputParams_3_0,
            						"org.xtext.SM2.InputParam");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:2039:3: ( (lv_visibilityAccess_4_0= ruleVisibility ) )
            // InternalSM2.g:2040:4: (lv_visibilityAccess_4_0= ruleVisibility )
            {
            // InternalSM2.g:2040:4: (lv_visibilityAccess_4_0= ruleVisibility )
            // InternalSM2.g:2041:5: lv_visibilityAccess_4_0= ruleVisibility
            {

            					newCompositeNode(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0());
            				
            pushFollow(FOLLOW_10);
            lv_visibilityAccess_4_0=ruleVisibility();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getClauseRule());
            					}
            					set(
            						current,
            						"visibilityAccess",
            						lv_visibilityAccess_4_0,
            						"org.xtext.SM2.Visibility");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_16); 

            			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
            		
            this_OPENKEY_6=(Token)match(input,RULE_OPENKEY,FOLLOW_12); 

            			newLeafNode(this_OPENKEY_6, grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_6());
            		
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_50); 

            			newLeafNode(this_EOLINE_7, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_7());
            		
            // InternalSM2.g:2070:3: ( (lv_restriction_8_0= ruleRestrictionClause ) )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==74) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalSM2.g:2071:4: (lv_restriction_8_0= ruleRestrictionClause )
                    {
                    // InternalSM2.g:2071:4: (lv_restriction_8_0= ruleRestrictionClause )
                    // InternalSM2.g:2072:5: lv_restriction_8_0= ruleRestrictionClause
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getRestrictionRestrictionClauseParserRuleCall_8_0());
                    				
                    pushFollow(FOLLOW_51);
                    lv_restriction_8_0=ruleRestrictionClause();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"restriction",
                    						lv_restriction_8_0,
                    						"org.xtext.SM2.RestrictionClause");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:2089:3: ( (lv_expression_9_0= ruleExpression ) )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==RULE_STRING||LA42_0==83) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalSM2.g:2090:4: (lv_expression_9_0= ruleExpression )
                    {
                    // InternalSM2.g:2090:4: (lv_expression_9_0= ruleExpression )
                    // InternalSM2.g:2091:5: lv_expression_9_0= ruleExpression
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_9_0());
                    				
                    pushFollow(FOLLOW_52);
                    lv_expression_9_0=ruleExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"expression",
                    						lv_expression_9_0,
                    						"org.xtext.SM2.Expression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:2108:3: (this_EOLINE_10= RULE_EOLINE )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==RULE_EOLINE) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalSM2.g:2109:4: this_EOLINE_10= RULE_EOLINE
                    {
                    this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_30); 

                    				newLeafNode(this_EOLINE_10, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_10());
                    			

                    }
                    break;

            }

            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_12); 

            			newLeafNode(this_CLOSEKEY_11, grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_11());
            		
            this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_12, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRuleSelfdestruct"
    // InternalSM2.g:2126:1: entryRuleSelfdestruct returns [EObject current=null] : iv_ruleSelfdestruct= ruleSelfdestruct EOF ;
    public final EObject entryRuleSelfdestruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSelfdestruct = null;


        try {
            // InternalSM2.g:2126:53: (iv_ruleSelfdestruct= ruleSelfdestruct EOF )
            // InternalSM2.g:2127:2: iv_ruleSelfdestruct= ruleSelfdestruct EOF
            {
             newCompositeNode(grammarAccess.getSelfdestructRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSelfdestruct=ruleSelfdestruct();

            state._fsp--;

             current =iv_ruleSelfdestruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSelfdestruct"


    // $ANTLR start "ruleSelfdestruct"
    // InternalSM2.g:2133:1: ruleSelfdestruct returns [EObject current=null] : (otherlv_0= 'selfdesctruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) ;
    public final EObject ruleSelfdestruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;


        	enterRule();

        try {
            // InternalSM2.g:2139:2: ( (otherlv_0= 'selfdesctruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:2140:2: (otherlv_0= 'selfdesctruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:2140:2: (otherlv_0= 'selfdesctruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:2141:3: otherlv_0= 'selfdesctruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,76,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getSelfdestructAccess().getSelfdesctructKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getSelfdestructAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		

            			newCompositeNode(grammarAccess.getSelfdestructAccess().getSyntaxExpressionParserRuleCall_2());
            		
            pushFollow(FOLLOW_10);
            ruleSyntaxExpression();

            state._fsp--;


            			afterParserOrEnumRuleCall();
            		
            this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_32); 

            			newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getSelfdestructAccess().getCLOSEPARENTHESISTerminalRuleCall_3());
            		
            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_33); 

            			newLeafNode(this_SEMICOLON_4, grammarAccess.getSelfdestructAccess().getSEMICOLONTerminalRuleCall_4());
            		
            // InternalSM2.g:2164:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==RULE_EOLINE) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:2165:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_5, grammarAccess.getSelfdestructAccess().getEOLINETerminalRuleCall_5());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSelfdestruct"


    // $ANTLR start "entryRuleCryptographycFunctions"
    // InternalSM2.g:2174:1: entryRuleCryptographycFunctions returns [EObject current=null] : iv_ruleCryptographycFunctions= ruleCryptographycFunctions EOF ;
    public final EObject entryRuleCryptographycFunctions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCryptographycFunctions = null;


        try {
            // InternalSM2.g:2174:63: (iv_ruleCryptographycFunctions= ruleCryptographycFunctions EOF )
            // InternalSM2.g:2175:2: iv_ruleCryptographycFunctions= ruleCryptographycFunctions EOF
            {
             newCompositeNode(grammarAccess.getCryptographycFunctionsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCryptographycFunctions=ruleCryptographycFunctions();

            state._fsp--;

             current =iv_ruleCryptographycFunctions; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCryptographycFunctions"


    // $ANTLR start "ruleCryptographycFunctions"
    // InternalSM2.g:2181:1: ruleCryptographycFunctions returns [EObject current=null] : ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? ) ) ;
    public final EObject ruleCryptographycFunctions() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_STRING_2=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token this_SEMICOLON_4=null;
        Token otherlv_5=null;
        Token this_OPENPARENTHESIS_6=null;
        Token this_STRING_7=null;
        Token this_CLOSEPARENTHESIS_8=null;
        Token this_SEMICOLON_9=null;
        Token otherlv_10=null;
        Token this_OPENPARENTHESIS_11=null;
        Token this_STRING_12=null;
        Token this_CLOSEPARENTHESIS_13=null;
        Token this_SEMICOLON_14=null;


        	enterRule();

        try {
            // InternalSM2.g:2187:2: ( ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? ) ) )
            // InternalSM2.g:2188:2: ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? ) )
            {
            // InternalSM2.g:2188:2: ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? ) )
            int alt48=3;
            switch ( input.LA(1) ) {
            case 77:
                {
                alt48=1;
                }
                break;
            case 78:
                {
                alt48=2;
                }
                break;
            case 79:
                {
                alt48=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 48, 0, input);

                throw nvae;
            }

            switch (alt48) {
                case 1 :
                    // InternalSM2.g:2189:3: (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:2189:3: (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? )
                    // InternalSM2.g:2190:4: otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )?
                    {
                    otherlv_0=(Token)match(input,77,FOLLOW_8); 

                    				newLeafNode(otherlv_0, grammarAccess.getCryptographycFunctionsAccess().getKeccack256Keyword_0_0());
                    			
                    this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_31); 

                    				newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_0_1());
                    			
                    this_STRING_2=(Token)match(input,RULE_STRING,FOLLOW_10); 

                    				newLeafNode(this_STRING_2, grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_0_2());
                    			
                    this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                    				newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_0_3());
                    			
                    // InternalSM2.g:2206:4: (this_SEMICOLON_4= RULE_SEMICOLON )?
                    int alt45=2;
                    int LA45_0 = input.LA(1);

                    if ( (LA45_0==RULE_SEMICOLON) ) {
                        alt45=1;
                    }
                    switch (alt45) {
                        case 1 :
                            // InternalSM2.g:2207:5: this_SEMICOLON_4= RULE_SEMICOLON
                            {
                            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_4, grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_0_4());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2214:3: (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:2214:3: (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? )
                    // InternalSM2.g:2215:4: otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )?
                    {
                    otherlv_5=(Token)match(input,78,FOLLOW_8); 

                    				newLeafNode(otherlv_5, grammarAccess.getCryptographycFunctionsAccess().getSha256Keyword_1_0());
                    			
                    this_OPENPARENTHESIS_6=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_31); 

                    				newLeafNode(this_OPENPARENTHESIS_6, grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_1_1());
                    			
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_10); 

                    				newLeafNode(this_STRING_7, grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_1_2());
                    			
                    this_CLOSEPARENTHESIS_8=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                    				newLeafNode(this_CLOSEPARENTHESIS_8, grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3());
                    			
                    // InternalSM2.g:2231:4: (this_SEMICOLON_9= RULE_SEMICOLON )?
                    int alt46=2;
                    int LA46_0 = input.LA(1);

                    if ( (LA46_0==RULE_SEMICOLON) ) {
                        alt46=1;
                    }
                    switch (alt46) {
                        case 1 :
                            // InternalSM2.g:2232:5: this_SEMICOLON_9= RULE_SEMICOLON
                            {
                            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_9, grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_1_4());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2239:3: (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:2239:3: (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? )
                    // InternalSM2.g:2240:4: otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )?
                    {
                    otherlv_10=(Token)match(input,79,FOLLOW_8); 

                    				newLeafNode(otherlv_10, grammarAccess.getCryptographycFunctionsAccess().getSha3Keyword_2_0());
                    			
                    this_OPENPARENTHESIS_11=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_31); 

                    				newLeafNode(this_OPENPARENTHESIS_11, grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_2_1());
                    			
                    this_STRING_12=(Token)match(input,RULE_STRING,FOLLOW_10); 

                    				newLeafNode(this_STRING_12, grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_2_2());
                    			
                    this_CLOSEPARENTHESIS_13=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                    				newLeafNode(this_CLOSEPARENTHESIS_13, grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_2_3());
                    			
                    // InternalSM2.g:2256:4: (this_SEMICOLON_14= RULE_SEMICOLON )?
                    int alt47=2;
                    int LA47_0 = input.LA(1);

                    if ( (LA47_0==RULE_SEMICOLON) ) {
                        alt47=1;
                    }
                    switch (alt47) {
                        case 1 :
                            // InternalSM2.g:2257:5: this_SEMICOLON_14= RULE_SEMICOLON
                            {
                            this_SEMICOLON_14=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_14, grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_2_4());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCryptographycFunctions"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:2267:1: entryRuleSyntaxExpression returns [String current=null] : iv_ruleSyntaxExpression= ruleSyntaxExpression EOF ;
    public final String entryRuleSyntaxExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleSyntaxExpression = null;


        try {
            // InternalSM2.g:2267:56: (iv_ruleSyntaxExpression= ruleSyntaxExpression EOF )
            // InternalSM2.g:2268:2: iv_ruleSyntaxExpression= ruleSyntaxExpression EOF
            {
             newCompositeNode(grammarAccess.getSyntaxExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSyntaxExpression=ruleSyntaxExpression();

            state._fsp--;

             current =iv_ruleSyntaxExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:2274:1: ruleSyntaxExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? ) ;
    public final AntlrDatatypeRuleToken ruleSyntaxExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_SEMICOLON_1=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:2280:2: ( (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? ) )
            // InternalSM2.g:2281:2: (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? )
            {
            // InternalSM2.g:2281:2: (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? )
            // InternalSM2.g:2282:3: this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )?
            {
            this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

            			current.merge(this_STRING_0);
            		

            			newLeafNode(this_STRING_0, grammarAccess.getSyntaxExpressionAccess().getSTRINGTerminalRuleCall_0());
            		
            // InternalSM2.g:2289:3: (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==RULE_SEMICOLON) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // InternalSM2.g:2290:4: this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE
                    {
                    this_SEMICOLON_1=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

                    				current.merge(this_SEMICOLON_1);
                    			

                    				newLeafNode(this_SEMICOLON_1, grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_0());
                    			
                    this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				current.merge(this_EOLINE_2);
                    			

                    				newLeafNode(this_EOLINE_2, grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:2309:1: entryRuleComment returns [String current=null] : iv_ruleComment= ruleComment EOF ;
    public final String entryRuleComment() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleComment = null;


        try {
            // InternalSM2.g:2309:47: (iv_ruleComment= ruleComment EOF )
            // InternalSM2.g:2310:2: iv_ruleComment= ruleComment EOF
            {
             newCompositeNode(grammarAccess.getCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleComment=ruleComment();

            state._fsp--;

             current =iv_ruleComment.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:2316:1: ruleComment returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) ;
    public final AntlrDatatypeRuleToken ruleComment() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        AntlrDatatypeRuleToken this_ShortComment_0 = null;

        AntlrDatatypeRuleToken this_LongComment_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:2322:2: ( (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) )
            // InternalSM2.g:2323:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            {
            // InternalSM2.g:2323:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==80) ) {
                alt50=1;
            }
            else if ( (LA50_0==81) ) {
                alt50=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 50, 0, input);

                throw nvae;
            }
            switch (alt50) {
                case 1 :
                    // InternalSM2.g:2324:3: this_ShortComment_0= ruleShortComment
                    {

                    			newCompositeNode(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_ShortComment_0=ruleShortComment();

                    state._fsp--;


                    			current.merge(this_ShortComment_0);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2335:3: this_LongComment_1= ruleLongComment
                    {

                    			newCompositeNode(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_LongComment_1=ruleLongComment();

                    state._fsp--;


                    			current.merge(this_LongComment_1);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:2349:1: entryRuleShortComment returns [String current=null] : iv_ruleShortComment= ruleShortComment EOF ;
    public final String entryRuleShortComment() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleShortComment = null;


        try {
            // InternalSM2.g:2349:52: (iv_ruleShortComment= ruleShortComment EOF )
            // InternalSM2.g:2350:2: iv_ruleShortComment= ruleShortComment EOF
            {
             newCompositeNode(grammarAccess.getShortCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleShortComment=ruleShortComment();

            state._fsp--;

             current =iv_ruleShortComment.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:2356:1: ruleShortComment returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE ) ;
    public final AntlrDatatypeRuleToken ruleShortComment() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_STRING_1=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:2362:2: ( (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE ) )
            // InternalSM2.g:2363:2: (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE )
            {
            // InternalSM2.g:2363:2: (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE )
            // InternalSM2.g:2364:3: kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE
            {
            kw=(Token)match(input,80,FOLLOW_31); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0());
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_12); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getShortCommentAccess().getSTRINGTerminalRuleCall_1());
            		
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			current.merge(this_EOLINE_2);
            		

            			newLeafNode(this_EOLINE_2, grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:2387:1: entryRuleLongComment returns [String current=null] : iv_ruleLongComment= ruleLongComment EOF ;
    public final String entryRuleLongComment() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleLongComment = null;


        try {
            // InternalSM2.g:2387:51: (iv_ruleLongComment= ruleLongComment EOF )
            // InternalSM2.g:2388:2: iv_ruleLongComment= ruleLongComment EOF
            {
             newCompositeNode(grammarAccess.getLongCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLongComment=ruleLongComment();

            state._fsp--;

             current =iv_ruleLongComment.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:2394:1: ruleLongComment returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= '/*' this_STRING_1= RULE_STRING kw= '*/' ) ;
    public final AntlrDatatypeRuleToken ruleLongComment() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_STRING_1=null;


        	enterRule();

        try {
            // InternalSM2.g:2400:2: ( (kw= '/*' this_STRING_1= RULE_STRING kw= '*/' ) )
            // InternalSM2.g:2401:2: (kw= '/*' this_STRING_1= RULE_STRING kw= '*/' )
            {
            // InternalSM2.g:2401:2: (kw= '/*' this_STRING_1= RULE_STRING kw= '*/' )
            // InternalSM2.g:2402:3: kw= '/*' this_STRING_1= RULE_STRING kw= '*/'
            {
            kw=(Token)match(input,81,FOLLOW_31); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0());
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_53); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getLongCommentAccess().getSTRINGTerminalRuleCall_1());
            		
            kw=(Token)match(input,82,FOLLOW_2); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:2423:1: entryRuleExpression returns [String current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final String entryRuleExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleExpression = null;


        try {
            // InternalSM2.g:2423:50: (iv_ruleExpression= ruleExpression EOF )
            // InternalSM2.g:2424:2: iv_ruleExpression= ruleExpression EOF
            {
             newCompositeNode(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;

             current =iv_ruleExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:2430:1: ruleExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression ) ;
    public final AntlrDatatypeRuleToken ruleExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        AntlrDatatypeRuleToken this_NegationExpression_0 = null;

        AntlrDatatypeRuleToken this_SyntaxExpression_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:2436:2: ( (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression ) )
            // InternalSM2.g:2437:2: (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression )
            {
            // InternalSM2.g:2437:2: (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression )
            int alt51=2;
            int LA51_0 = input.LA(1);

            if ( (LA51_0==83) ) {
                alt51=1;
            }
            else if ( (LA51_0==RULE_STRING) ) {
                alt51=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 51, 0, input);

                throw nvae;
            }
            switch (alt51) {
                case 1 :
                    // InternalSM2.g:2438:3: this_NegationExpression_0= ruleNegationExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getNegationExpressionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_NegationExpression_0=ruleNegationExpression();

                    state._fsp--;


                    			current.merge(this_NegationExpression_0);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2449:3: this_SyntaxExpression_1= ruleSyntaxExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_SyntaxExpression_1=ruleSyntaxExpression();

                    state._fsp--;


                    			current.merge(this_SyntaxExpression_1);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleLogicalUnaryOperator"
    // InternalSM2.g:2463:1: entryRuleLogicalUnaryOperator returns [String current=null] : iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF ;
    public final String entryRuleLogicalUnaryOperator() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleLogicalUnaryOperator = null;


        try {
            // InternalSM2.g:2463:60: (iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF )
            // InternalSM2.g:2464:2: iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF
            {
             newCompositeNode(grammarAccess.getLogicalUnaryOperatorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLogicalUnaryOperator=ruleLogicalUnaryOperator();

            state._fsp--;

             current =iv_ruleLogicalUnaryOperator.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLogicalUnaryOperator"


    // $ANTLR start "ruleLogicalUnaryOperator"
    // InternalSM2.g:2470:1: ruleLogicalUnaryOperator returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '!' ;
    public final AntlrDatatypeRuleToken ruleLogicalUnaryOperator() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSM2.g:2476:2: (kw= '!' )
            // InternalSM2.g:2477:2: kw= '!'
            {
            kw=(Token)match(input,83,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getLogicalUnaryOperatorAccess().getExclamationMarkKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalUnaryOperator"


    // $ANTLR start "entryRuleNegationExpression"
    // InternalSM2.g:2485:1: entryRuleNegationExpression returns [String current=null] : iv_ruleNegationExpression= ruleNegationExpression EOF ;
    public final String entryRuleNegationExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleNegationExpression = null;


        try {
            // InternalSM2.g:2485:58: (iv_ruleNegationExpression= ruleNegationExpression EOF )
            // InternalSM2.g:2486:2: iv_ruleNegationExpression= ruleNegationExpression EOF
            {
             newCompositeNode(grammarAccess.getNegationExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNegationExpression=ruleNegationExpression();

            state._fsp--;

             current =iv_ruleNegationExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNegationExpression"


    // $ANTLR start "ruleNegationExpression"
    // InternalSM2.g:2492:1: ruleNegationExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING ) ;
    public final AntlrDatatypeRuleToken ruleNegationExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_1=null;
        AntlrDatatypeRuleToken this_LogicalUnaryOperator_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2498:2: ( (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING ) )
            // InternalSM2.g:2499:2: (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING )
            {
            // InternalSM2.g:2499:2: (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING )
            // InternalSM2.g:2500:3: this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING
            {

            			newCompositeNode(grammarAccess.getNegationExpressionAccess().getLogicalUnaryOperatorParserRuleCall_0());
            		
            pushFollow(FOLLOW_31);
            this_LogicalUnaryOperator_0=ruleLogicalUnaryOperator();

            state._fsp--;


            			current.merge(this_LogicalUnaryOperator_0);
            		

            			afterParserOrEnumRuleCall();
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_2); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getNegationExpressionAccess().getSTRINGTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNegationExpression"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:2521:1: ruleVisibility returns [Enumerator current=null] : ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) ) ;
    public final Enumerator ruleVisibility() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalSM2.g:2527:2: ( ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) ) )
            // InternalSM2.g:2528:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) )
            {
            // InternalSM2.g:2528:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) )
            int alt52=3;
            switch ( input.LA(1) ) {
            case 56:
                {
                alt52=1;
                }
                break;
            case 84:
                {
                alt52=2;
                }
                break;
            case 57:
                {
                alt52=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 52, 0, input);

                throw nvae;
            }

            switch (alt52) {
                case 1 :
                    // InternalSM2.g:2529:3: (enumLiteral_0= 'public' )
                    {
                    // InternalSM2.g:2529:3: (enumLiteral_0= 'public' )
                    // InternalSM2.g:2530:4: enumLiteral_0= 'public'
                    {
                    enumLiteral_0=(Token)match(input,56,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2537:3: (enumLiteral_1= 'private' )
                    {
                    // InternalSM2.g:2537:3: (enumLiteral_1= 'private' )
                    // InternalSM2.g:2538:4: enumLiteral_1= 'private'
                    {
                    enumLiteral_1=(Token)match(input,84,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2545:3: (enumLiteral_2= 'internal' )
                    {
                    // InternalSM2.g:2545:3: (enumLiteral_2= 'internal' )
                    // InternalSM2.g:2546:4: enumLiteral_2= 'internal'
                    {
                    enumLiteral_2=(Token)match(input,57,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:2556:1: ruleCoin returns [Enumerator current=null] : ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) ;
    public final Enumerator ruleCoin() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:2562:2: ( ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) )
            // InternalSM2.g:2563:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            {
            // InternalSM2.g:2563:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            int alt53=6;
            switch ( input.LA(1) ) {
            case 85:
                {
                alt53=1;
                }
                break;
            case 86:
                {
                alt53=2;
                }
                break;
            case 87:
                {
                alt53=3;
                }
                break;
            case 88:
                {
                alt53=4;
                }
                break;
            case 89:
                {
                alt53=5;
                }
                break;
            case 90:
                {
                alt53=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 53, 0, input);

                throw nvae;
            }

            switch (alt53) {
                case 1 :
                    // InternalSM2.g:2564:3: (enumLiteral_0= 'ether' )
                    {
                    // InternalSM2.g:2564:3: (enumLiteral_0= 'ether' )
                    // InternalSM2.g:2565:4: enumLiteral_0= 'ether'
                    {
                    enumLiteral_0=(Token)match(input,85,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2572:3: (enumLiteral_1= 'wei' )
                    {
                    // InternalSM2.g:2572:3: (enumLiteral_1= 'wei' )
                    // InternalSM2.g:2573:4: enumLiteral_1= 'wei'
                    {
                    enumLiteral_1=(Token)match(input,86,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2580:3: (enumLiteral_2= 'gwei' )
                    {
                    // InternalSM2.g:2580:3: (enumLiteral_2= 'gwei' )
                    // InternalSM2.g:2581:4: enumLiteral_2= 'gwei'
                    {
                    enumLiteral_2=(Token)match(input,87,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:2588:3: (enumLiteral_3= 'pwei' )
                    {
                    // InternalSM2.g:2588:3: (enumLiteral_3= 'pwei' )
                    // InternalSM2.g:2589:4: enumLiteral_3= 'pwei'
                    {
                    enumLiteral_3=(Token)match(input,88,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:2596:3: (enumLiteral_4= 'finney' )
                    {
                    // InternalSM2.g:2596:3: (enumLiteral_4= 'finney' )
                    // InternalSM2.g:2597:4: enumLiteral_4= 'finney'
                    {
                    enumLiteral_4=(Token)match(input,89,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:2604:3: (enumLiteral_5= 'szabo' )
                    {
                    // InternalSM2.g:2604:3: (enumLiteral_5= 'szabo' )
                    // InternalSM2.g:2605:4: enumLiteral_5= 'szabo'
                    {
                    enumLiteral_5=(Token)match(input,90,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:2615:1: ruleComparationOperator returns [Enumerator current=null] : ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) ;
    public final Enumerator ruleComparationOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:2621:2: ( ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) )
            // InternalSM2.g:2622:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            {
            // InternalSM2.g:2622:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            int alt54=6;
            switch ( input.LA(1) ) {
            case 53:
                {
                alt54=1;
                }
                break;
            case 91:
                {
                alt54=2;
                }
                break;
            case 54:
                {
                alt54=3;
                }
                break;
            case 92:
                {
                alt54=4;
                }
                break;
            case 93:
                {
                alt54=5;
                }
                break;
            case 94:
                {
                alt54=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 54, 0, input);

                throw nvae;
            }

            switch (alt54) {
                case 1 :
                    // InternalSM2.g:2623:3: (enumLiteral_0= '>' )
                    {
                    // InternalSM2.g:2623:3: (enumLiteral_0= '>' )
                    // InternalSM2.g:2624:4: enumLiteral_0= '>'
                    {
                    enumLiteral_0=(Token)match(input,53,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2631:3: (enumLiteral_1= '<' )
                    {
                    // InternalSM2.g:2631:3: (enumLiteral_1= '<' )
                    // InternalSM2.g:2632:4: enumLiteral_1= '<'
                    {
                    enumLiteral_1=(Token)match(input,91,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2639:3: (enumLiteral_2= '>=' )
                    {
                    // InternalSM2.g:2639:3: (enumLiteral_2= '>=' )
                    // InternalSM2.g:2640:4: enumLiteral_2= '>='
                    {
                    enumLiteral_2=(Token)match(input,54,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:2647:3: (enumLiteral_3= '<=' )
                    {
                    // InternalSM2.g:2647:3: (enumLiteral_3= '<=' )
                    // InternalSM2.g:2648:4: enumLiteral_3= '<='
                    {
                    enumLiteral_3=(Token)match(input,92,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:2655:3: (enumLiteral_4= '==' )
                    {
                    // InternalSM2.g:2655:3: (enumLiteral_4= '==' )
                    // InternalSM2.g:2656:4: enumLiteral_4= '=='
                    {
                    enumLiteral_4=(Token)match(input,93,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:2663:3: (enumLiteral_5= '!=' )
                    {
                    // InternalSM2.g:2663:3: (enumLiteral_5= '!=' )
                    // InternalSM2.g:2664:4: enumLiteral_5= '!='
                    {
                    enumLiteral_5=(Token)match(input,94,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:2674:1: ruleLogicalPairOperator returns [Enumerator current=null] : ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) ;
    public final Enumerator ruleLogicalPairOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSM2.g:2680:2: ( ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) )
            // InternalSM2.g:2681:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            {
            // InternalSM2.g:2681:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==95) ) {
                alt55=1;
            }
            else if ( (LA55_0==96) ) {
                alt55=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 55, 0, input);

                throw nvae;
            }
            switch (alt55) {
                case 1 :
                    // InternalSM2.g:2682:3: (enumLiteral_0= '&&' )
                    {
                    // InternalSM2.g:2682:3: (enumLiteral_0= '&&' )
                    // InternalSM2.g:2683:4: enumLiteral_0= '&&'
                    {
                    enumLiteral_0=(Token)match(input,95,FOLLOW_2); 

                    				current = grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2690:3: (enumLiteral_1= '||' )
                    {
                    // InternalSM2.g:2690:3: (enumLiteral_1= '||' )
                    // InternalSM2.g:2691:4: enumLiteral_1= '||'
                    {
                    enumLiteral_1=(Token)match(input,96,FOLLOW_2); 

                    				current = grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:2701:1: ruleArithmeticalOperator returns [Enumerator current=null] : ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) ;
    public final Enumerator ruleArithmeticalOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;


        	enterRule();

        try {
            // InternalSM2.g:2707:2: ( ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) )
            // InternalSM2.g:2708:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            {
            // InternalSM2.g:2708:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            int alt56=5;
            switch ( input.LA(1) ) {
            case 97:
                {
                alt56=1;
                }
                break;
            case 98:
                {
                alt56=2;
                }
                break;
            case 99:
                {
                alt56=3;
                }
                break;
            case 100:
                {
                alt56=4;
                }
                break;
            case 101:
                {
                alt56=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 56, 0, input);

                throw nvae;
            }

            switch (alt56) {
                case 1 :
                    // InternalSM2.g:2709:3: (enumLiteral_0= '+' )
                    {
                    // InternalSM2.g:2709:3: (enumLiteral_0= '+' )
                    // InternalSM2.g:2710:4: enumLiteral_0= '+'
                    {
                    enumLiteral_0=(Token)match(input,97,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2717:3: (enumLiteral_1= '-' )
                    {
                    // InternalSM2.g:2717:3: (enumLiteral_1= '-' )
                    // InternalSM2.g:2718:4: enumLiteral_1= '-'
                    {
                    enumLiteral_1=(Token)match(input,98,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2725:3: (enumLiteral_2= '*' )
                    {
                    // InternalSM2.g:2725:3: (enumLiteral_2= '*' )
                    // InternalSM2.g:2726:4: enumLiteral_2= '*'
                    {
                    enumLiteral_2=(Token)match(input,99,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:2733:3: (enumLiteral_3= '/' )
                    {
                    // InternalSM2.g:2733:3: (enumLiteral_3= '/' )
                    // InternalSM2.g:2734:4: enumLiteral_3= '/'
                    {
                    enumLiteral_3=(Token)match(input,100,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:2741:3: (enumLiteral_4= '%' )
                    {
                    // InternalSM2.g:2741:3: (enumLiteral_4= '%' )
                    // InternalSM2.g:2742:4: enumLiteral_4= '%'
                    {
                    enumLiteral_4=(Token)match(input,101,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmeticalOperator"

    // Delegated rules


    protected DFA40 dfa40 = new DFA40(this);
    static final String dfa_1s = "\16\uffff";
    static final String dfa_2s = "\1\112\1\5\1\17\1\7\1\10\6\17\1\65\2\uffff";
    static final String dfa_3s = "\1\112\1\5\1\17\1\136\1\10\6\21\1\136\2\uffff";
    static final String dfa_4s = "\14\uffff\1\1\1\2";
    static final String dfa_5s = "\16\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\4\55\uffff\1\5\1\7\44\uffff\1\6\1\10\1\11\1\12",
            "\1\13",
            "\1\14\1\uffff\1\15",
            "\1\14\1\uffff\1\15",
            "\1\14\1\uffff\1\15",
            "\1\14\1\uffff\1\15",
            "\1\14\1\uffff\1\15",
            "\1\14\1\uffff\1\15",
            "\1\5\1\7\44\uffff\1\6\1\10\1\11\1\12",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA40 extends DFA {

        public DFA40(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 40;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "1747:2: (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0400000000000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0001000000000200L,0x00000000000001A0L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000002L,0x0000000000030000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x00001F0000000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000008000L,0x0000000000080000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000C00000000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0002000000000400L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0080000000000100L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0800000000000A00L,0x00000000000309A0L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0800000000000A00L,0x00000000000009A0L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0800000000000800L,0x0000000000000800L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000000800L,0x0000000000000800L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0070000000000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000000000202L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0xE300000000000000L,0x000000000000001FL});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000000200L,0x00000000000001A0L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000000000102L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0xE000000000000040L,0x000000000000001FL});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000008100L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x1000000000000100L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x1000000000000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0xE000000000000000L,0x000000000000001FL});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0300000000000200L,0x0000000000100000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0xE000000000000100L,0x000000000000001FL});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000000010800L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000000000028080L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0060000000000000L,0x0000000078000000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000000000L,0x0000000007E00000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0300000000000000L,0x0000000000100000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000000008900L,0x0000000000080400L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0000000000008900L,0x0000000000080000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0000000000000900L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0000000000000000L,0x0000000000040000L});

}