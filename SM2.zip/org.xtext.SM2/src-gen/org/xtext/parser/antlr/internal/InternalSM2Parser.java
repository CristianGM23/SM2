package org.xtext.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_CLOSEKEY", "RULE_SINGLENUMBER", "RULE_DOT", "RULE_INTEGER", "RULE_ID", "RULE_OPENKEY", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_STRING", "RULE_EMAIL", "RULE_FLOAT", "RULE_COMMA", "RULE_BOOLVALUE", "RULE_IF", "RULE_BREAK", "RULE_ELSE", "RULE_PARAMSLONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_NOTICELONGCOMENT", "RULE_RETURN", "RULE_RETURNS", "RULE_CONTINUE", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'pragma'", "'solidity'", "'^ '", "'> '", "'>='", "'import'", "'as'", "'interface'", "'contract'", "'is'", "'msg'", "'data'", "'value'", "'gas'", "'sender'", "'sig'", "'block'", "'difficulty'", "'number'", "'timestamp'", "'coinbase'", "'gaslimit'", "'blockhash'", "'now'", "'thx'", "'gasprice'", "'origin'", "'constructor'", "'public'", "'internal'", "'event'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'address'", "'='", "'string'", "'float'", "'amountAccount'", "'enum'", "'[]'", "'['", "']'", "'int'", "'uint'", "'uint2'", "'uint4'", "'uint8'", "'uint16'", "'uint32'", "'uint64'", "'uint256'", "'bool'", "'address payable'", "'bytes'", "'bytes2'", "'bytes3'", "'bytes4'", "'bytes5'", "'bytes6'", "'bytes7'", "'bytes8'", "'bytes16'", "'bytes32'", "'memory'", "'local'", "'require'", "'payable'", "'function'", "'kill'", "'msg.sender'", "'=='", "'selfdestruct'", "'while'", "'for'", "'//'", "'/*'", "'*/'", "'!'", "'++'", "'--'", "'private'", "'external'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'>'", "'<'", "'<='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'", "'%'", "'uint128'", "'double'", "'byte'", "'seconds'", "'minutes'", "'hours'", "'days'", "'weeks'", "'years'"
    };
    public static final int T__144=144;
    public static final int T__143=143;
    public static final int T__50=50;
    public static final int T__145=145;
    public static final int T__140=140;
    public static final int T__142=142;
    public static final int T__141=141;
    public static final int RULE_RETURNS=28;
    public static final int RULE_OPENPARENTHESIS=12;
    public static final int RULE_EOLINE=5;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__137=137;
    public static final int T__52=52;
    public static final int T__136=136;
    public static final int T__53=53;
    public static final int T__139=139;
    public static final int T__54=54;
    public static final int T__138=138;
    public static final int T__133=133;
    public static final int T__132=132;
    public static final int RULE_PARAMSLONGCOMENT=22;
    public static final int T__60=60;
    public static final int T__135=135;
    public static final int T__61=61;
    public static final int T__134=134;
    public static final int RULE_ID=10;
    public static final int RULE_RETURN=27;
    public static final int T__131=131;
    public static final int T__130=130;
    public static final int RULE_INT=30;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=31;
    public static final int T__67=67;
    public static final int T__129=129;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__126=126;
    public static final int T__63=63;
    public static final int T__125=125;
    public static final int T__64=64;
    public static final int T__128=128;
    public static final int T__65=65;
    public static final int T__127=127;
    public static final int RULE_TITLELONGCOMENT=25;
    public static final int RULE_EMAIL=15;
    public static final int RULE_NOTICELONGCOMENT=26;
    public static final int T__37=37;
    public static final int RULE_OPENKEY=11;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int RULE_CLOSEPARENTHESIS=13;
    public static final int T__35=35;
    public static final int RULE_IF=19;
    public static final int T__36=36;
    public static final int RULE_DOT=8;
    public static final int RULE_CONTINUE=29;
    public static final int RULE_DEVLONGCOMENT=23;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int RULE_FLOAT=16;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__91=91;
    public static final int T__100=100;
    public static final int T__92=92;
    public static final int T__93=93;
    public static final int T__102=102;
    public static final int T__94=94;
    public static final int T__101=101;
    public static final int T__90=90;
    public static final int RULE_SINGLENUMBER=7;
    public static final int T__99=99;
    public static final int RULE_CLOSEKEY=6;
    public static final int T__95=95;
    public static final int T__96=96;
    public static final int T__97=97;
    public static final int T__98=98;
    public static final int RULE_COMMA=17;
    public static final int RULE_RETURNSLONGCOMENT=24;
    public static final int RULE_SEMICOLON=4;
    public static final int RULE_ELSE=21;
    public static final int T__122=122;
    public static final int T__70=70;
    public static final int T__121=121;
    public static final int T__71=71;
    public static final int T__124=124;
    public static final int RULE_BOOLVALUE=18;
    public static final int T__72=72;
    public static final int T__123=123;
    public static final int T__120=120;
    public static final int RULE_STRING=14;
    public static final int RULE_SL_COMMENT=32;
    public static final int RULE_BREAK=20;
    public static final int T__77=77;
    public static final int T__119=119;
    public static final int T__78=78;
    public static final int T__118=118;
    public static final int T__79=79;
    public static final int T__73=73;
    public static final int T__115=115;
    public static final int EOF=-1;
    public static final int T__74=74;
    public static final int T__114=114;
    public static final int T__75=75;
    public static final int T__117=117;
    public static final int T__76=76;
    public static final int T__116=116;
    public static final int T__80=80;
    public static final int T__111=111;
    public static final int T__81=81;
    public static final int T__110=110;
    public static final int T__82=82;
    public static final int T__113=113;
    public static final int T__83=83;
    public static final int T__112=112;
    public static final int RULE_WS=33;
    public static final int RULE_ANY_OTHER=34;
    public static final int T__88=88;
    public static final int T__108=108;
    public static final int T__89=89;
    public static final int T__107=107;
    public static final int T__109=109;
    public static final int T__84=84;
    public static final int T__104=104;
    public static final int T__85=85;
    public static final int T__103=103;
    public static final int RULE_INTEGER=9;
    public static final int T__86=86;
    public static final int T__106=106;
    public static final int T__87=87;
    public static final int T__105=105;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }



     	private SM2GrammarAccess grammarAccess;

        public InternalSM2Parser(TokenStream input, SM2GrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "SmartContract";
       	}

       	@Override
       	protected SM2GrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleSmartContract"
    // InternalSM2.g:65:1: entryRuleSmartContract returns [EObject current=null] : iv_ruleSmartContract= ruleSmartContract EOF ;
    public final EObject entryRuleSmartContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSmartContract = null;


        try {
            // InternalSM2.g:65:54: (iv_ruleSmartContract= ruleSmartContract EOF )
            // InternalSM2.g:66:2: iv_ruleSmartContract= ruleSmartContract EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSmartContractRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSmartContract=ruleSmartContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSmartContract; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSmartContract"


    // $ANTLR start "ruleSmartContract"
    // InternalSM2.g:72:1: ruleSmartContract returns [EObject current=null] : (otherlv_0= 'pragma' otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY ) ;
    public final EObject ruleSmartContract() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token this_SEMICOLON_3=null;
        Token this_EOLINE_4=null;
        Token this_CLOSEKEY_8=null;
        EObject lv_VersionCompiler_2_0 = null;

        EObject lv_imports_5_0 = null;

        EObject lv_interfaces_6_0 = null;

        EObject lv_contracts_7_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:78:2: ( (otherlv_0= 'pragma' otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY ) )
            // InternalSM2.g:79:2: (otherlv_0= 'pragma' otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY )
            {
            // InternalSM2.g:79:2: (otherlv_0= 'pragma' otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY )
            // InternalSM2.g:80:3: otherlv_0= 'pragma' otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,35,FOLLOW_3); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getSmartContractAccess().getPragmaKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,36,FOLLOW_4); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getSmartContractAccess().getSolidityKeyword_1());
              		
            }
            // InternalSM2.g:88:3: ( (lv_VersionCompiler_2_0= ruleVersion ) )
            // InternalSM2.g:89:4: (lv_VersionCompiler_2_0= ruleVersion )
            {
            // InternalSM2.g:89:4: (lv_VersionCompiler_2_0= ruleVersion )
            // InternalSM2.g:90:5: lv_VersionCompiler_2_0= ruleVersion
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_5);
            lv_VersionCompiler_2_0=ruleVersion();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getSmartContractRule());
              					}
              					set(
              						current,
              						"VersionCompiler",
              						lv_VersionCompiler_2_0,
              						"org.xtext.SM2.Version");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_SEMICOLON_3=(Token)match(input,RULE_SEMICOLON,FOLLOW_6); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_3, grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:111:3: (this_EOLINE_4= RULE_EOLINE )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_EOLINE) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalSM2.g:112:4: this_EOLINE_4= RULE_EOLINE
                    {
                    this_EOLINE_4=(Token)match(input,RULE_EOLINE,FOLLOW_6); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_4, grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:117:3: ( (lv_imports_5_0= ruleLibrary ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==40) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSM2.g:118:4: (lv_imports_5_0= ruleLibrary )
            	    {
            	    // InternalSM2.g:118:4: (lv_imports_5_0= ruleLibrary )
            	    // InternalSM2.g:119:5: lv_imports_5_0= ruleLibrary
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getImportsLibraryParserRuleCall_5_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_6);
            	    lv_imports_5_0=ruleLibrary();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"imports",
            	      						lv_imports_5_0,
            	      						"org.xtext.SM2.Library");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalSM2.g:136:3: ( (lv_interfaces_6_0= ruleInterface ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==42) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalSM2.g:137:4: (lv_interfaces_6_0= ruleInterface )
            	    {
            	    // InternalSM2.g:137:4: (lv_interfaces_6_0= ruleInterface )
            	    // InternalSM2.g:138:5: lv_interfaces_6_0= ruleInterface
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getInterfacesInterfaceParserRuleCall_6_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_6);
            	    lv_interfaces_6_0=ruleInterface();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"interfaces",
            	      						lv_interfaces_6_0,
            	      						"org.xtext.SM2.Interface");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            // InternalSM2.g:155:3: ( (lv_contracts_7_0= ruleContract ) )
            // InternalSM2.g:156:4: (lv_contracts_7_0= ruleContract )
            {
            // InternalSM2.g:156:4: (lv_contracts_7_0= ruleContract )
            // InternalSM2.g:157:5: lv_contracts_7_0= ruleContract
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getSmartContractAccess().getContractsContractParserRuleCall_7_0());
              				
            }
            pushFollow(FOLLOW_7);
            lv_contracts_7_0=ruleContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getSmartContractRule());
              					}
              					add(
              						current,
              						"contracts",
              						lv_contracts_7_0,
              						"org.xtext.SM2.Contract");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEKEY_8=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_8, grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSmartContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:182:1: entryRuleVersion returns [EObject current=null] : iv_ruleVersion= ruleVersion EOF ;
    public final EObject entryRuleVersion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVersion = null;


        try {
            // InternalSM2.g:182:48: (iv_ruleVersion= ruleVersion EOF )
            // InternalSM2.g:183:2: iv_ruleVersion= ruleVersion EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getVersionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleVersion=ruleVersion();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleVersion; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:189:1: ruleVersion returns [EObject current=null] : ( () ( ( (lv_operator_1_1= '^ ' | lv_operator_1_2= '> ' | lv_operator_1_3= '>=' ) ) ) ( (lv_numberversion1_2_0= RULE_SINGLENUMBER ) ) this_DOT_3= RULE_DOT ( (lv_numberversion2_4_0= RULE_SINGLENUMBER ) ) this_DOT_5= RULE_DOT ( (lv_numberversion3_6_0= RULE_INTEGER ) ) ( (otherlv_7= RULE_ID ) )? ) ;
    public final EObject ruleVersion() throws RecognitionException {
        EObject current = null;

        Token lv_operator_1_1=null;
        Token lv_operator_1_2=null;
        Token lv_operator_1_3=null;
        Token lv_numberversion1_2_0=null;
        Token this_DOT_3=null;
        Token lv_numberversion2_4_0=null;
        Token this_DOT_5=null;
        Token lv_numberversion3_6_0=null;
        Token otherlv_7=null;


        	enterRule();

        try {
            // InternalSM2.g:195:2: ( ( () ( ( (lv_operator_1_1= '^ ' | lv_operator_1_2= '> ' | lv_operator_1_3= '>=' ) ) ) ( (lv_numberversion1_2_0= RULE_SINGLENUMBER ) ) this_DOT_3= RULE_DOT ( (lv_numberversion2_4_0= RULE_SINGLENUMBER ) ) this_DOT_5= RULE_DOT ( (lv_numberversion3_6_0= RULE_INTEGER ) ) ( (otherlv_7= RULE_ID ) )? ) )
            // InternalSM2.g:196:2: ( () ( ( (lv_operator_1_1= '^ ' | lv_operator_1_2= '> ' | lv_operator_1_3= '>=' ) ) ) ( (lv_numberversion1_2_0= RULE_SINGLENUMBER ) ) this_DOT_3= RULE_DOT ( (lv_numberversion2_4_0= RULE_SINGLENUMBER ) ) this_DOT_5= RULE_DOT ( (lv_numberversion3_6_0= RULE_INTEGER ) ) ( (otherlv_7= RULE_ID ) )? )
            {
            // InternalSM2.g:196:2: ( () ( ( (lv_operator_1_1= '^ ' | lv_operator_1_2= '> ' | lv_operator_1_3= '>=' ) ) ) ( (lv_numberversion1_2_0= RULE_SINGLENUMBER ) ) this_DOT_3= RULE_DOT ( (lv_numberversion2_4_0= RULE_SINGLENUMBER ) ) this_DOT_5= RULE_DOT ( (lv_numberversion3_6_0= RULE_INTEGER ) ) ( (otherlv_7= RULE_ID ) )? )
            // InternalSM2.g:197:3: () ( ( (lv_operator_1_1= '^ ' | lv_operator_1_2= '> ' | lv_operator_1_3= '>=' ) ) ) ( (lv_numberversion1_2_0= RULE_SINGLENUMBER ) ) this_DOT_3= RULE_DOT ( (lv_numberversion2_4_0= RULE_SINGLENUMBER ) ) this_DOT_5= RULE_DOT ( (lv_numberversion3_6_0= RULE_INTEGER ) ) ( (otherlv_7= RULE_ID ) )?
            {
            // InternalSM2.g:197:3: ()
            // InternalSM2.g:198:4: 
            {
            if ( state.backtracking==0 ) {

              				current = forceCreateModelElement(
              					grammarAccess.getVersionAccess().getVersionAction_0(),
              					current);
              			
            }

            }

            // InternalSM2.g:204:3: ( ( (lv_operator_1_1= '^ ' | lv_operator_1_2= '> ' | lv_operator_1_3= '>=' ) ) )
            // InternalSM2.g:205:4: ( (lv_operator_1_1= '^ ' | lv_operator_1_2= '> ' | lv_operator_1_3= '>=' ) )
            {
            // InternalSM2.g:205:4: ( (lv_operator_1_1= '^ ' | lv_operator_1_2= '> ' | lv_operator_1_3= '>=' ) )
            // InternalSM2.g:206:5: (lv_operator_1_1= '^ ' | lv_operator_1_2= '> ' | lv_operator_1_3= '>=' )
            {
            // InternalSM2.g:206:5: (lv_operator_1_1= '^ ' | lv_operator_1_2= '> ' | lv_operator_1_3= '>=' )
            int alt4=3;
            switch ( input.LA(1) ) {
            case 37:
                {
                alt4=1;
                }
                break;
            case 38:
                {
                alt4=2;
                }
                break;
            case 39:
                {
                alt4=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // InternalSM2.g:207:6: lv_operator_1_1= '^ '
                    {
                    lv_operator_1_1=(Token)match(input,37,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_operator_1_1, grammarAccess.getVersionAccess().getOperatorCircumflexAccentSpaceKeyword_1_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(current, "operator", lv_operator_1_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:218:6: lv_operator_1_2= '> '
                    {
                    lv_operator_1_2=(Token)match(input,38,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_operator_1_2, grammarAccess.getVersionAccess().getOperatorGreaterThanSignSpaceKeyword_1_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(current, "operator", lv_operator_1_2, null);
                      					
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:229:6: lv_operator_1_3= '>='
                    {
                    lv_operator_1_3=(Token)match(input,39,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_operator_1_3, grammarAccess.getVersionAccess().getOperatorGreaterThanSignEqualsSignKeyword_1_0_2());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(current, "operator", lv_operator_1_3, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:242:3: ( (lv_numberversion1_2_0= RULE_SINGLENUMBER ) )
            // InternalSM2.g:243:4: (lv_numberversion1_2_0= RULE_SINGLENUMBER )
            {
            // InternalSM2.g:243:4: (lv_numberversion1_2_0= RULE_SINGLENUMBER )
            // InternalSM2.g:244:5: lv_numberversion1_2_0= RULE_SINGLENUMBER
            {
            lv_numberversion1_2_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_numberversion1_2_0, grammarAccess.getVersionAccess().getNumberversion1SINGLENUMBERTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getVersionRule());
              					}
              					setWithLastConsumed(
              						current,
              						"numberversion1",
              						lv_numberversion1_2_0,
              						"org.xtext.SM2.SINGLENUMBER");
              				
            }

            }


            }

            this_DOT_3=(Token)match(input,RULE_DOT,FOLLOW_8); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_DOT_3, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:264:3: ( (lv_numberversion2_4_0= RULE_SINGLENUMBER ) )
            // InternalSM2.g:265:4: (lv_numberversion2_4_0= RULE_SINGLENUMBER )
            {
            // InternalSM2.g:265:4: (lv_numberversion2_4_0= RULE_SINGLENUMBER )
            // InternalSM2.g:266:5: lv_numberversion2_4_0= RULE_SINGLENUMBER
            {
            lv_numberversion2_4_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_numberversion2_4_0, grammarAccess.getVersionAccess().getNumberversion2SINGLENUMBERTerminalRuleCall_4_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getVersionRule());
              					}
              					setWithLastConsumed(
              						current,
              						"numberversion2",
              						lv_numberversion2_4_0,
              						"org.xtext.SM2.SINGLENUMBER");
              				
            }

            }


            }

            this_DOT_5=(Token)match(input,RULE_DOT,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_DOT_5, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:286:3: ( (lv_numberversion3_6_0= RULE_INTEGER ) )
            // InternalSM2.g:287:4: (lv_numberversion3_6_0= RULE_INTEGER )
            {
            // InternalSM2.g:287:4: (lv_numberversion3_6_0= RULE_INTEGER )
            // InternalSM2.g:288:5: lv_numberversion3_6_0= RULE_INTEGER
            {
            lv_numberversion3_6_0=(Token)match(input,RULE_INTEGER,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_numberversion3_6_0, grammarAccess.getVersionAccess().getNumberversion3INTEGERTerminalRuleCall_6_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getVersionRule());
              					}
              					setWithLastConsumed(
              						current,
              						"numberversion3",
              						lv_numberversion3_6_0,
              						"org.xtext.SM2.INTEGER");
              				
            }

            }


            }

            // InternalSM2.g:304:3: ( (otherlv_7= RULE_ID ) )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==RULE_ID) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalSM2.g:305:4: (otherlv_7= RULE_ID )
                    {
                    // InternalSM2.g:305:4: (otherlv_7= RULE_ID )
                    // InternalSM2.g:306:5: otherlv_7= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getVersionRule());
                      					}
                      				
                    }
                    otherlv_7=(Token)match(input,RULE_ID,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_7, grammarAccess.getVersionAccess().getOptionalversionVersionCrossReference_7_0());
                      				
                    }

                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleLibrary"
    // InternalSM2.g:321:1: entryRuleLibrary returns [EObject current=null] : iv_ruleLibrary= ruleLibrary EOF ;
    public final EObject entryRuleLibrary() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLibrary = null;


        try {
            // InternalSM2.g:321:48: (iv_ruleLibrary= ruleLibrary EOF )
            // InternalSM2.g:322:2: iv_ruleLibrary= ruleLibrary EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLibraryRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLibrary=ruleLibrary();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLibrary; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLibrary"


    // $ANTLR start "ruleLibrary"
    // InternalSM2.g:328:1: ruleLibrary returns [EObject current=null] : (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) ;
    public final EObject ruleLibrary() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameLibrary_1_0=null;
        Token otherlv_2=null;
        Token lv_alias_3_0=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;


        	enterRule();

        try {
            // InternalSM2.g:334:2: ( (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:335:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:335:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:336:3: otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,40,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getLibraryAccess().getImportKeyword_0());
              		
            }
            // InternalSM2.g:340:3: ( (lv_nameLibrary_1_0= RULE_ID ) )
            // InternalSM2.g:341:4: (lv_nameLibrary_1_0= RULE_ID )
            {
            // InternalSM2.g:341:4: (lv_nameLibrary_1_0= RULE_ID )
            // InternalSM2.g:342:5: lv_nameLibrary_1_0= RULE_ID
            {
            lv_nameLibrary_1_0=(Token)match(input,RULE_ID,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameLibrary_1_0, grammarAccess.getLibraryAccess().getNameLibraryIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getLibraryRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameLibrary",
              						lv_nameLibrary_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:358:3: (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==41) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalSM2.g:359:4: otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,41,FOLLOW_12); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getLibraryAccess().getAsKeyword_2_0());
                      			
                    }
                    // InternalSM2.g:363:4: ( (lv_alias_3_0= RULE_ID ) )
                    // InternalSM2.g:364:5: (lv_alias_3_0= RULE_ID )
                    {
                    // InternalSM2.g:364:5: (lv_alias_3_0= RULE_ID )
                    // InternalSM2.g:365:6: lv_alias_3_0= RULE_ID
                    {
                    lv_alias_3_0=(Token)match(input,RULE_ID,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_alias_3_0, grammarAccess.getLibraryAccess().getAliasIDTerminalRuleCall_2_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLibraryRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"alias",
                      							lv_alias_3_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_4, grammarAccess.getLibraryAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:386:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==RULE_EOLINE) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalSM2.g:387:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_5, grammarAccess.getLibraryAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLibrary"


    // $ANTLR start "entryRuleInterface"
    // InternalSM2.g:396:1: entryRuleInterface returns [EObject current=null] : iv_ruleInterface= ruleInterface EOF ;
    public final EObject entryRuleInterface() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInterface = null;


        try {
            // InternalSM2.g:396:50: (iv_ruleInterface= ruleInterface EOF )
            // InternalSM2.g:397:2: iv_ruleInterface= ruleInterface EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getInterfaceRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleInterface=ruleInterface();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleInterface; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInterface"


    // $ANTLR start "ruleInterface"
    // InternalSM2.g:403:1: ruleInterface returns [EObject current=null] : (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) )* this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE ) ;
    public final EObject ruleInterface() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameInterface_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;
        Token this_CLOSEKEY_7=null;
        Token this_EOLINE_8=null;


        	enterRule();

        try {
            // InternalSM2.g:409:2: ( (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) )* this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE ) )
            // InternalSM2.g:410:2: (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) )* this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE )
            {
            // InternalSM2.g:410:2: (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) )* this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE )
            // InternalSM2.g:411:3: otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) )* this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,42,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getInterfaceAccess().getInterfaceKeyword_0());
              		
            }
            // InternalSM2.g:415:3: ( (lv_nameInterface_1_0= RULE_ID ) )
            // InternalSM2.g:416:4: (lv_nameInterface_1_0= RULE_ID )
            {
            // InternalSM2.g:416:4: (lv_nameInterface_1_0= RULE_ID )
            // InternalSM2.g:417:5: lv_nameInterface_1_0= RULE_ID
            {
            lv_nameInterface_1_0=(Token)match(input,RULE_ID,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameInterface_1_0, grammarAccess.getInterfaceAccess().getNameInterfaceIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getInterfaceRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameInterface",
              						lv_nameInterface_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getInterfaceAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_17); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_3, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_3());
              		
            }
            // InternalSM2.g:441:3: ( (otherlv_4= RULE_ID ) )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==RULE_ID) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalSM2.g:442:4: (otherlv_4= RULE_ID )
            	    {
            	    // InternalSM2.g:442:4: (otherlv_4= RULE_ID )
            	    // InternalSM2.g:443:5: otherlv_4= RULE_ID
            	    {
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElement(grammarAccess.getInterfaceRule());
            	      					}
            	      				
            	    }
            	    otherlv_4=(Token)match(input,RULE_ID,FOLLOW_17); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_4, grammarAccess.getInterfaceAccess().getFunctionsHeadClauseCrossReference_4_0());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_5, grammarAccess.getInterfaceAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_6, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_6());
              		
            }
            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_7, grammarAccess.getInterfaceAccess().getCLOSEKEYTerminalRuleCall_7());
              		
            }
            this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_8, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInterface"


    // $ANTLR start "entryRuleContract"
    // InternalSM2.g:474:1: entryRuleContract returns [EObject current=null] : iv_ruleContract= ruleContract EOF ;
    public final EObject entryRuleContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleContract = null;


        try {
            // InternalSM2.g:474:49: (iv_ruleContract= ruleContract EOF )
            // InternalSM2.g:475:2: iv_ruleContract= ruleContract EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getContractRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleContract=ruleContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleContract; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleContract"


    // $ANTLR start "ruleContract"
    // InternalSM2.g:481:1: ruleContract returns [EObject current=null] : ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* ) ;
    public final EObject ruleContract() throws RecognitionException {
        EObject current = null;

        Token lv_contract_0_0=null;
        Token lv_nameContract_1_0=null;
        Token otherlv_2=null;
        Token lv_nameContractFather_3_0=null;
        Token this_OPENKEY_4=null;
        Token this_EOLINE_5=null;
        EObject lv_attributes_6_0 = null;

        EObject lv_constructor_7_0 = null;

        EObject lv_events_8_0 = null;

        EObject lv_modifier_9_0 = null;

        EObject lv_functions_10_0 = null;

        EObject lv_comments_11_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:487:2: ( ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* ) )
            // InternalSM2.g:488:2: ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* )
            {
            // InternalSM2.g:488:2: ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* )
            // InternalSM2.g:489:3: ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )*
            {
            // InternalSM2.g:489:3: ( (lv_contract_0_0= 'contract' ) )
            // InternalSM2.g:490:4: (lv_contract_0_0= 'contract' )
            {
            // InternalSM2.g:490:4: (lv_contract_0_0= 'contract' )
            // InternalSM2.g:491:5: lv_contract_0_0= 'contract'
            {
            lv_contract_0_0=(Token)match(input,43,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_contract_0_0, grammarAccess.getContractAccess().getContractContractKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getContractRule());
              					}
              					setWithLastConsumed(current, "contract", lv_contract_0_0, "contract");
              				
            }

            }


            }

            // InternalSM2.g:503:3: ( (lv_nameContract_1_0= RULE_ID ) )
            // InternalSM2.g:504:4: (lv_nameContract_1_0= RULE_ID )
            {
            // InternalSM2.g:504:4: (lv_nameContract_1_0= RULE_ID )
            // InternalSM2.g:505:5: lv_nameContract_1_0= RULE_ID
            {
            lv_nameContract_1_0=(Token)match(input,RULE_ID,FOLLOW_18); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameContract_1_0, grammarAccess.getContractAccess().getNameContractIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getContractRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameContract",
              						lv_nameContract_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:521:3: (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==44) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalSM2.g:522:4: otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,44,FOLLOW_12); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getContractAccess().getIsKeyword_2_0());
                      			
                    }
                    // InternalSM2.g:526:4: ( (lv_nameContractFather_3_0= RULE_ID ) )
                    // InternalSM2.g:527:5: (lv_nameContractFather_3_0= RULE_ID )
                    {
                    // InternalSM2.g:527:5: (lv_nameContractFather_3_0= RULE_ID )
                    // InternalSM2.g:528:6: lv_nameContractFather_3_0= RULE_ID
                    {
                    lv_nameContractFather_3_0=(Token)match(input,RULE_ID,FOLLOW_15); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_nameContractFather_3_0, grammarAccess.getContractAccess().getNameContractFatherIDTerminalRuleCall_2_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getContractRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"nameContractFather",
                      							lv_nameContractFather_3_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_OPENKEY_4=(Token)match(input,RULE_OPENKEY,FOLLOW_19); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_4, grammarAccess.getContractAccess().getOPENKEYTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:549:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==RULE_EOLINE) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalSM2.g:550:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_20); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_5, grammarAccess.getContractAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:555:3: ( (lv_attributes_6_0= ruleAttributes ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==RULE_ID) ) {
                    int LA11_2 = input.LA(2);

                    if ( ((LA11_2>=RULE_INTEGER && LA11_2<=RULE_ID)||(LA11_2>=63 && LA11_2<=64)||(LA11_2>=77 && LA11_2<=78)||(LA11_2>=118 && LA11_2<=119)) ) {
                        alt11=1;
                    }


                }
                else if ( (LA11_0==68||(LA11_0>=70 && LA11_0<=71)||(LA11_0>=73 && LA11_0<=74)||LA11_0==76||(LA11_0>=80 && LA11_0<=100)) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalSM2.g:556:4: (lv_attributes_6_0= ruleAttributes )
            	    {
            	    // InternalSM2.g:556:4: (lv_attributes_6_0= ruleAttributes )
            	    // InternalSM2.g:557:5: lv_attributes_6_0= ruleAttributes
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getAttributesAttributesParserRuleCall_5_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_20);
            	    lv_attributes_6_0=ruleAttributes();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"attributes",
            	      						lv_attributes_6_0,
            	      						"org.xtext.SM2.Attributes");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

            // InternalSM2.g:574:3: ( (lv_constructor_7_0= ruleConstructor ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==62) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalSM2.g:575:4: (lv_constructor_7_0= ruleConstructor )
                    {
                    // InternalSM2.g:575:4: (lv_constructor_7_0= ruleConstructor )
                    // InternalSM2.g:576:5: lv_constructor_7_0= ruleConstructor
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getContractAccess().getConstructorConstructorParserRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_21);
                    lv_constructor_7_0=ruleConstructor();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getContractRule());
                      					}
                      					set(
                      						current,
                      						"constructor",
                      						lv_constructor_7_0,
                      						"org.xtext.SM2.Constructor");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:593:3: ( (lv_events_8_0= ruleEvent ) )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==65) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalSM2.g:594:4: (lv_events_8_0= ruleEvent )
            	    {
            	    // InternalSM2.g:594:4: (lv_events_8_0= ruleEvent )
            	    // InternalSM2.g:595:5: lv_events_8_0= ruleEvent
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getEventsEventParserRuleCall_7_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_21);
            	    lv_events_8_0=ruleEvent();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"events",
            	      						lv_events_8_0,
            	      						"org.xtext.SM2.Event");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

            // InternalSM2.g:612:3: ( (lv_modifier_9_0= ruleModifier ) )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==66) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // InternalSM2.g:613:4: (lv_modifier_9_0= ruleModifier )
            	    {
            	    // InternalSM2.g:613:4: (lv_modifier_9_0= ruleModifier )
            	    // InternalSM2.g:614:5: lv_modifier_9_0= ruleModifier
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getModifierModifierParserRuleCall_8_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_22);
            	    lv_modifier_9_0=ruleModifier();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"modifier",
            	      						lv_modifier_9_0,
            	      						"org.xtext.SM2.Modifier");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);

            // InternalSM2.g:631:3: ( (lv_functions_10_0= ruleFunction ) )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==RULE_ID||LA15_0==105) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalSM2.g:632:4: (lv_functions_10_0= ruleFunction )
            	    {
            	    // InternalSM2.g:632:4: (lv_functions_10_0= ruleFunction )
            	    // InternalSM2.g:633:5: lv_functions_10_0= ruleFunction
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getFunctionsFunctionParserRuleCall_9_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_23);
            	    lv_functions_10_0=ruleFunction();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"functions",
            	      						lv_functions_10_0,
            	      						"org.xtext.SM2.Function");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

            // InternalSM2.g:650:3: ( (lv_comments_11_0= ruleComment ) )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( ((LA16_0>=112 && LA16_0<=113)) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // InternalSM2.g:651:4: (lv_comments_11_0= ruleComment )
            	    {
            	    // InternalSM2.g:651:4: (lv_comments_11_0= ruleComment )
            	    // InternalSM2.g:652:5: lv_comments_11_0= ruleComment
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getCommentsCommentParserRuleCall_10_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_24);
            	    lv_comments_11_0=ruleComment();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"comments",
            	      						lv_comments_11_0,
            	      						"org.xtext.SM2.Comment");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleContract"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:673:1: entryRuleAttributes returns [EObject current=null] : iv_ruleAttributes= ruleAttributes EOF ;
    public final EObject entryRuleAttributes() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttributes = null;


        try {
            // InternalSM2.g:673:51: (iv_ruleAttributes= ruleAttributes EOF )
            // InternalSM2.g:674:2: iv_ruleAttributes= ruleAttributes EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getAttributesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleAttributes=ruleAttributes();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleAttributes; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:680:1: ruleAttributes returns [EObject current=null] : (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) ;
    public final EObject ruleAttributes() throws RecognitionException {
        EObject current = null;

        EObject this_Property_0 = null;

        EObject this_DataType_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:686:2: ( (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) )
            // InternalSM2.g:687:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            {
            // InternalSM2.g:687:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==RULE_ID||LA17_0==71||(LA17_0>=73 && LA17_0<=74)||(LA17_0>=80 && LA17_0<=100)) ) {
                alt17=1;
            }
            else if ( (LA17_0==68||LA17_0==70||LA17_0==76) ) {
                alt17=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }
            switch (alt17) {
                case 1 :
                    // InternalSM2.g:688:3: this_Property_0= ruleProperty
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Property_0=ruleProperty();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Property_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:697:3: this_DataType_1= ruleDataType
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_DataType_1=ruleDataType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_DataType_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleVariables"
    // InternalSM2.g:709:1: entryRuleVariables returns [EObject current=null] : iv_ruleVariables= ruleVariables EOF ;
    public final EObject entryRuleVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariables = null;


        try {
            // InternalSM2.g:709:50: (iv_ruleVariables= ruleVariables EOF )
            // InternalSM2.g:710:2: iv_ruleVariables= ruleVariables EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getVariablesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleVariables=ruleVariables();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleVariables; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariables"


    // $ANTLR start "ruleVariables"
    // InternalSM2.g:716:1: ruleVariables returns [EObject current=null] : (this_MSGVariables_0= ruleMSGVariables | this_BlockVariables_1= ruleBlockVariables | this_Thx_2= ruleThx ) ;
    public final EObject ruleVariables() throws RecognitionException {
        EObject current = null;

        EObject this_MSGVariables_0 = null;

        EObject this_BlockVariables_1 = null;

        EObject this_Thx_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:722:2: ( (this_MSGVariables_0= ruleMSGVariables | this_BlockVariables_1= ruleBlockVariables | this_Thx_2= ruleThx ) )
            // InternalSM2.g:723:2: (this_MSGVariables_0= ruleMSGVariables | this_BlockVariables_1= ruleBlockVariables | this_Thx_2= ruleThx )
            {
            // InternalSM2.g:723:2: (this_MSGVariables_0= ruleMSGVariables | this_BlockVariables_1= ruleBlockVariables | this_Thx_2= ruleThx )
            int alt18=3;
            switch ( input.LA(1) ) {
            case 45:
                {
                alt18=1;
                }
                break;
            case 51:
            case 58:
                {
                alt18=2;
                }
                break;
            case 59:
                {
                alt18=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }

            switch (alt18) {
                case 1 :
                    // InternalSM2.g:724:3: this_MSGVariables_0= ruleMSGVariables
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getVariablesAccess().getMSGVariablesParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_MSGVariables_0=ruleMSGVariables();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_MSGVariables_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:733:3: this_BlockVariables_1= ruleBlockVariables
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getVariablesAccess().getBlockVariablesParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_BlockVariables_1=ruleBlockVariables();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_BlockVariables_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:742:3: this_Thx_2= ruleThx
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getVariablesAccess().getThxParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Thx_2=ruleThx();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Thx_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariables"


    // $ANTLR start "entryRuleMSGVariables"
    // InternalSM2.g:754:1: entryRuleMSGVariables returns [EObject current=null] : iv_ruleMSGVariables= ruleMSGVariables EOF ;
    public final EObject entryRuleMSGVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMSGVariables = null;


        try {
            // InternalSM2.g:754:53: (iv_ruleMSGVariables= ruleMSGVariables EOF )
            // InternalSM2.g:755:2: iv_ruleMSGVariables= ruleMSGVariables EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMSGVariablesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleMSGVariables=ruleMSGVariables();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleMSGVariables; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMSGVariables"


    // $ANTLR start "ruleMSGVariables"
    // InternalSM2.g:761:1: ruleMSGVariables returns [EObject current=null] : (otherlv_0= 'msg' this_DOT_1= RULE_DOT ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) ) (this_SEMICOLON_27= RULE_SEMICOLON )? ) ;
    public final EObject ruleMSGVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_DOT_1=null;
        Token otherlv_2=null;
        Token this_OPENPARENTHESIS_3=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token otherlv_7=null;
        Token this_OPENPARENTHESIS_8=null;
        Token this_CLOSEPARENTHESIS_11=null;
        Token otherlv_12=null;
        Token this_OPENPARENTHESIS_13=null;
        Token this_CLOSEPARENTHESIS_16=null;
        Token otherlv_17=null;
        Token this_OPENPARENTHESIS_18=null;
        Token this_CLOSEPARENTHESIS_21=null;
        Token otherlv_22=null;
        Token this_OPENPARENTHESIS_23=null;
        Token this_CLOSEPARENTHESIS_26=null;
        Token this_SEMICOLON_27=null;
        EObject this_PropertyBytes_4 = null;

        EObject this_SyntaxExpression_5 = null;

        EObject this_PropertyInteger_9 = null;

        EObject this_SyntaxExpression_10 = null;

        EObject this_PropertyInteger_14 = null;

        EObject this_SyntaxExpression_15 = null;

        EObject this_PropertyAddress_19 = null;

        EObject this_SyntaxExpression_20 = null;

        EObject this_PropertyBytes_24 = null;

        EObject this_SyntaxExpression_25 = null;



        	enterRule();

        try {
            // InternalSM2.g:767:2: ( (otherlv_0= 'msg' this_DOT_1= RULE_DOT ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) ) (this_SEMICOLON_27= RULE_SEMICOLON )? ) )
            // InternalSM2.g:768:2: (otherlv_0= 'msg' this_DOT_1= RULE_DOT ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) ) (this_SEMICOLON_27= RULE_SEMICOLON )? )
            {
            // InternalSM2.g:768:2: (otherlv_0= 'msg' this_DOT_1= RULE_DOT ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) ) (this_SEMICOLON_27= RULE_SEMICOLON )? )
            // InternalSM2.g:769:3: otherlv_0= 'msg' this_DOT_1= RULE_DOT ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) ) (this_SEMICOLON_27= RULE_SEMICOLON )?
            {
            otherlv_0=(Token)match(input,45,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getMSGVariablesAccess().getMsgKeyword_0());
              		
            }
            this_DOT_1=(Token)match(input,RULE_DOT,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_DOT_1, grammarAccess.getMSGVariablesAccess().getDOTTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:777:3: ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) )
            int alt24=5;
            switch ( input.LA(1) ) {
            case 46:
                {
                alt24=1;
                }
                break;
            case 47:
                {
                alt24=2;
                }
                break;
            case 48:
                {
                alt24=3;
                }
                break;
            case 49:
                {
                alt24=4;
                }
                break;
            case 50:
                {
                alt24=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }

            switch (alt24) {
                case 1 :
                    // InternalSM2.g:778:4: (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:778:4: (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:779:5: otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS
                    {
                    otherlv_2=(Token)match(input,46,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_2, grammarAccess.getMSGVariablesAccess().getDataKeyword_2_0_0());
                      				
                    }
                    this_OPENPARENTHESIS_3=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_3, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_0_1());
                      				
                    }
                    // InternalSM2.g:787:5: (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression )
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( ((LA19_0>=91 && LA19_0<=100)) ) {
                        alt19=1;
                    }
                    else if ( (LA19_0==RULE_INTEGER||LA19_0==RULE_STRING||LA19_0==RULE_FLOAT) ) {
                        alt19=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 19, 0, input);

                        throw nvae;
                    }
                    switch (alt19) {
                        case 1 :
                            // InternalSM2.g:788:6: this_PropertyBytes_4= rulePropertyBytes
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyBytesParserRuleCall_2_0_2_0());
                              					
                            }
                            pushFollow(FOLLOW_28);
                            this_PropertyBytes_4=rulePropertyBytes();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_PropertyBytes_4;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:797:6: this_SyntaxExpression_5= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_0_2_1());
                              					
                            }
                            pushFollow(FOLLOW_28);
                            this_SyntaxExpression_5=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_5;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_0_3());
                      				
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:812:4: (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:812:4: (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:813:5: otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS
                    {
                    otherlv_7=(Token)match(input,47,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_7, grammarAccess.getMSGVariablesAccess().getValueKeyword_2_1_0());
                      				
                    }
                    this_OPENPARENTHESIS_8=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_30); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_8, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_1_1());
                      				
                    }
                    // InternalSM2.g:821:5: (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression )
                    int alt20=2;
                    int LA20_0 = input.LA(1);

                    if ( ((LA20_0>=80 && LA20_0<=88)) ) {
                        alt20=1;
                    }
                    else if ( (LA20_0==RULE_INTEGER||LA20_0==RULE_STRING||LA20_0==RULE_FLOAT) ) {
                        alt20=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 20, 0, input);

                        throw nvae;
                    }
                    switch (alt20) {
                        case 1 :
                            // InternalSM2.g:822:6: this_PropertyInteger_9= rulePropertyInteger
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyIntegerParserRuleCall_2_1_2_0());
                              					
                            }
                            pushFollow(FOLLOW_28);
                            this_PropertyInteger_9=rulePropertyInteger();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_PropertyInteger_9;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:831:6: this_SyntaxExpression_10= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_1_2_1());
                              					
                            }
                            pushFollow(FOLLOW_28);
                            this_SyntaxExpression_10=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_10;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_11=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_11, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_1_3());
                      				
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:846:4: (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:846:4: (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:847:5: otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS
                    {
                    otherlv_12=(Token)match(input,48,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_12, grammarAccess.getMSGVariablesAccess().getGasKeyword_2_2_0());
                      				
                    }
                    this_OPENPARENTHESIS_13=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_30); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_13, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_2_1());
                      				
                    }
                    // InternalSM2.g:855:5: (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression )
                    int alt21=2;
                    int LA21_0 = input.LA(1);

                    if ( ((LA21_0>=80 && LA21_0<=88)) ) {
                        alt21=1;
                    }
                    else if ( (LA21_0==RULE_INTEGER||LA21_0==RULE_STRING||LA21_0==RULE_FLOAT) ) {
                        alt21=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 21, 0, input);

                        throw nvae;
                    }
                    switch (alt21) {
                        case 1 :
                            // InternalSM2.g:856:6: this_PropertyInteger_14= rulePropertyInteger
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyIntegerParserRuleCall_2_2_2_0());
                              					
                            }
                            pushFollow(FOLLOW_28);
                            this_PropertyInteger_14=rulePropertyInteger();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_PropertyInteger_14;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:865:6: this_SyntaxExpression_15= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_2_2_1());
                              					
                            }
                            pushFollow(FOLLOW_28);
                            this_SyntaxExpression_15=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_15;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_16=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_16, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_2_3());
                      				
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:880:4: (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:880:4: (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:881:5: otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS
                    {
                    otherlv_17=(Token)match(input,49,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_17, grammarAccess.getMSGVariablesAccess().getSenderKeyword_2_3_0());
                      				
                    }
                    this_OPENPARENTHESIS_18=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_31); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_18, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_3_1());
                      				
                    }
                    // InternalSM2.g:889:5: (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression )
                    int alt22=2;
                    int LA22_0 = input.LA(1);

                    if ( (LA22_0==71||LA22_0==90) ) {
                        alt22=1;
                    }
                    else if ( (LA22_0==RULE_INTEGER||LA22_0==RULE_STRING||LA22_0==RULE_FLOAT) ) {
                        alt22=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 22, 0, input);

                        throw nvae;
                    }
                    switch (alt22) {
                        case 1 :
                            // InternalSM2.g:890:6: this_PropertyAddress_19= rulePropertyAddress
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyAddressParserRuleCall_2_3_2_0());
                              					
                            }
                            pushFollow(FOLLOW_28);
                            this_PropertyAddress_19=rulePropertyAddress();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_PropertyAddress_19;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:899:6: this_SyntaxExpression_20= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_3_2_1());
                              					
                            }
                            pushFollow(FOLLOW_28);
                            this_SyntaxExpression_20=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_20;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_21=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_21, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_3_3());
                      				
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:914:4: (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:914:4: (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:915:5: otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS
                    {
                    otherlv_22=(Token)match(input,50,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_22, grammarAccess.getMSGVariablesAccess().getSigKeyword_2_4_0());
                      				
                    }
                    this_OPENPARENTHESIS_23=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_23, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_4_1());
                      				
                    }
                    // InternalSM2.g:923:5: (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression )
                    int alt23=2;
                    int LA23_0 = input.LA(1);

                    if ( ((LA23_0>=91 && LA23_0<=100)) ) {
                        alt23=1;
                    }
                    else if ( (LA23_0==RULE_INTEGER||LA23_0==RULE_STRING||LA23_0==RULE_FLOAT) ) {
                        alt23=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 23, 0, input);

                        throw nvae;
                    }
                    switch (alt23) {
                        case 1 :
                            // InternalSM2.g:924:6: this_PropertyBytes_24= rulePropertyBytes
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyBytesParserRuleCall_2_4_2_0());
                              					
                            }
                            pushFollow(FOLLOW_28);
                            this_PropertyBytes_24=rulePropertyBytes();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_PropertyBytes_24;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:933:6: this_SyntaxExpression_25= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_4_2_1());
                              					
                            }
                            pushFollow(FOLLOW_28);
                            this_SyntaxExpression_25=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_25;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_26=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_26, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_4_3());
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:948:3: (this_SEMICOLON_27= RULE_SEMICOLON )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==RULE_SEMICOLON) ) {
                int LA25_1 = input.LA(2);

                if ( (LA25_1==EOF||LA25_1==RULE_SEMICOLON||LA25_1==RULE_CLOSEKEY||(LA25_1>=RULE_INTEGER && LA25_1<=RULE_ID)||(LA25_1>=RULE_OPENPARENTHESIS && LA25_1<=RULE_STRING)||LA25_1==RULE_FLOAT||LA25_1==RULE_BREAK||LA25_1==45||LA25_1==51||(LA25_1>=58 && LA25_1<=59)||LA25_1==115) ) {
                    alt25=1;
                }
                else if ( (LA25_1==RULE_EOLINE) ) {
                    int LA25_4 = input.LA(3);

                    if ( ((LA25_4>=RULE_EOLINE && LA25_4<=RULE_CLOSEKEY)||LA25_4==RULE_BREAK) ) {
                        alt25=1;
                    }
                }
            }
            switch (alt25) {
                case 1 :
                    // InternalSM2.g:949:4: this_SEMICOLON_27= RULE_SEMICOLON
                    {
                    this_SEMICOLON_27=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_27, grammarAccess.getMSGVariablesAccess().getSEMICOLONTerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMSGVariables"


    // $ANTLR start "entryRuleBlockVariables"
    // InternalSM2.g:958:1: entryRuleBlockVariables returns [EObject current=null] : iv_ruleBlockVariables= ruleBlockVariables EOF ;
    public final EObject entryRuleBlockVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBlockVariables = null;


        try {
            // InternalSM2.g:958:55: (iv_ruleBlockVariables= ruleBlockVariables EOF )
            // InternalSM2.g:959:2: iv_ruleBlockVariables= ruleBlockVariables EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getBlockVariablesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleBlockVariables=ruleBlockVariables();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleBlockVariables; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBlockVariables"


    // $ANTLR start "ruleBlockVariables"
    // InternalSM2.g:965:1: ruleBlockVariables returns [EObject current=null] : ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS (this_SEMICOLON_37= RULE_SEMICOLON )? ) ) ;
    public final EObject ruleBlockVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_DOT_1=null;
        Token otherlv_2=null;
        Token this_OPENPARENTHESIS_3=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token otherlv_7=null;
        Token this_OPENPARENTHESIS_8=null;
        Token this_CLOSEPARENTHESIS_11=null;
        Token otherlv_12=null;
        Token this_OPENPARENTHESIS_13=null;
        Token this_CLOSEPARENTHESIS_16=null;
        Token otherlv_17=null;
        Token this_OPENPARENTHESIS_18=null;
        Token this_CLOSEPARENTHESIS_21=null;
        Token otherlv_22=null;
        Token this_OPENPARENTHESIS_23=null;
        Token this_CLOSEPARENTHESIS_26=null;
        Token otherlv_27=null;
        Token this_OPENPARENTHESIS_28=null;
        Token this_CLOSEPARENTHESIS_31=null;
        Token otherlv_32=null;
        Token this_OPENPARENTHESIS_33=null;
        Token this_CLOSEPARENTHESIS_36=null;
        Token this_SEMICOLON_37=null;
        EObject this_PropertyInteger_4 = null;

        EObject this_SyntaxExpression_5 = null;

        EObject this_PropertyInteger_9 = null;

        EObject this_SyntaxExpression_10 = null;

        EObject this_PropertyInteger_14 = null;

        EObject this_SyntaxExpression_15 = null;

        EObject this_PropertyAddress_19 = null;

        EObject this_SyntaxExpression_20 = null;

        EObject this_PropertyInteger_24 = null;

        EObject this_SyntaxExpression_25 = null;

        EObject this_PropertyInteger_29 = null;

        EObject this_SyntaxExpression_30 = null;

        EObject this_PropertyInteger_34 = null;

        EObject this_SyntaxExpression_35 = null;



        	enterRule();

        try {
            // InternalSM2.g:971:2: ( ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS (this_SEMICOLON_37= RULE_SEMICOLON )? ) ) )
            // InternalSM2.g:972:2: ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS (this_SEMICOLON_37= RULE_SEMICOLON )? ) )
            {
            // InternalSM2.g:972:2: ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS (this_SEMICOLON_37= RULE_SEMICOLON )? ) )
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==51) ) {
                alt35=1;
            }
            else if ( (LA35_0==58) ) {
                alt35=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 35, 0, input);

                throw nvae;
            }
            switch (alt35) {
                case 1 :
                    // InternalSM2.g:973:3: (otherlv_0= 'block' this_DOT_1= RULE_DOT ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) ) )
                    {
                    // InternalSM2.g:973:3: (otherlv_0= 'block' this_DOT_1= RULE_DOT ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) ) )
                    // InternalSM2.g:974:4: otherlv_0= 'block' this_DOT_1= RULE_DOT ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) )
                    {
                    otherlv_0=(Token)match(input,51,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_0, grammarAccess.getBlockVariablesAccess().getBlockKeyword_0_0());
                      			
                    }
                    this_DOT_1=(Token)match(input,RULE_DOT,FOLLOW_32); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_1, grammarAccess.getBlockVariablesAccess().getDOTTerminalRuleCall_0_1());
                      			
                    }
                    // InternalSM2.g:982:4: ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) )
                    int alt32=6;
                    switch ( input.LA(1) ) {
                    case 52:
                        {
                        alt32=1;
                        }
                        break;
                    case 53:
                        {
                        alt32=2;
                        }
                        break;
                    case 54:
                        {
                        alt32=3;
                        }
                        break;
                    case 55:
                        {
                        alt32=4;
                        }
                        break;
                    case 56:
                        {
                        alt32=5;
                        }
                        break;
                    case 57:
                        {
                        alt32=6;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 32, 0, input);

                        throw nvae;
                    }

                    switch (alt32) {
                        case 1 :
                            // InternalSM2.g:983:5: (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:983:5: (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:984:6: otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_2=(Token)match(input,52,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_2, grammarAccess.getBlockVariablesAccess().getDifficultyKeyword_0_2_0_0());
                              					
                            }
                            this_OPENPARENTHESIS_3=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_30); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_3, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_0_1());
                              					
                            }
                            // InternalSM2.g:992:6: (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression )
                            int alt26=2;
                            int LA26_0 = input.LA(1);

                            if ( ((LA26_0>=80 && LA26_0<=88)) ) {
                                alt26=1;
                            }
                            else if ( (LA26_0==RULE_INTEGER||LA26_0==RULE_STRING||LA26_0==RULE_FLOAT) ) {
                                alt26=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 26, 0, input);

                                throw nvae;
                            }
                            switch (alt26) {
                                case 1 :
                                    // InternalSM2.g:993:7: this_PropertyInteger_4= rulePropertyInteger
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_0_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_28);
                                    this_PropertyInteger_4=rulePropertyInteger();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyInteger_4;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1002:7: this_SyntaxExpression_5= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_0_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_28);
                                    this_SyntaxExpression_5=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_5;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_0_3());
                              					
                            }

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:1017:5: (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:1017:5: (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:1018:6: otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_7=(Token)match(input,53,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_7, grammarAccess.getBlockVariablesAccess().getNumberKeyword_0_2_1_0());
                              					
                            }
                            this_OPENPARENTHESIS_8=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_30); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_8, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_1_1());
                              					
                            }
                            // InternalSM2.g:1026:6: (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression )
                            int alt27=2;
                            int LA27_0 = input.LA(1);

                            if ( ((LA27_0>=80 && LA27_0<=88)) ) {
                                alt27=1;
                            }
                            else if ( (LA27_0==RULE_INTEGER||LA27_0==RULE_STRING||LA27_0==RULE_FLOAT) ) {
                                alt27=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 27, 0, input);

                                throw nvae;
                            }
                            switch (alt27) {
                                case 1 :
                                    // InternalSM2.g:1027:7: this_PropertyInteger_9= rulePropertyInteger
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_1_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_28);
                                    this_PropertyInteger_9=rulePropertyInteger();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyInteger_9;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1036:7: this_SyntaxExpression_10= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_1_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_28);
                                    this_SyntaxExpression_10=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_10;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_11=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_11, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_1_3());
                              					
                            }

                            }


                            }
                            break;
                        case 3 :
                            // InternalSM2.g:1051:5: (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:1051:5: (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:1052:6: otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_12=(Token)match(input,54,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_12, grammarAccess.getBlockVariablesAccess().getTimestampKeyword_0_2_2_0());
                              					
                            }
                            this_OPENPARENTHESIS_13=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_30); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_13, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_2_1());
                              					
                            }
                            // InternalSM2.g:1060:6: (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression )
                            int alt28=2;
                            int LA28_0 = input.LA(1);

                            if ( ((LA28_0>=80 && LA28_0<=88)) ) {
                                alt28=1;
                            }
                            else if ( (LA28_0==RULE_INTEGER||LA28_0==RULE_STRING||LA28_0==RULE_FLOAT) ) {
                                alt28=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 28, 0, input);

                                throw nvae;
                            }
                            switch (alt28) {
                                case 1 :
                                    // InternalSM2.g:1061:7: this_PropertyInteger_14= rulePropertyInteger
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_2_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_28);
                                    this_PropertyInteger_14=rulePropertyInteger();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyInteger_14;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1070:7: this_SyntaxExpression_15= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_2_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_28);
                                    this_SyntaxExpression_15=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_15;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_16=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_16, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_2_3());
                              					
                            }

                            }


                            }
                            break;
                        case 4 :
                            // InternalSM2.g:1085:5: (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:1085:5: (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:1086:6: otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_17=(Token)match(input,55,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_17, grammarAccess.getBlockVariablesAccess().getCoinbaseKeyword_0_2_3_0());
                              					
                            }
                            this_OPENPARENTHESIS_18=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_31); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_18, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_3_1());
                              					
                            }
                            // InternalSM2.g:1094:6: (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression )
                            int alt29=2;
                            int LA29_0 = input.LA(1);

                            if ( (LA29_0==71||LA29_0==90) ) {
                                alt29=1;
                            }
                            else if ( (LA29_0==RULE_INTEGER||LA29_0==RULE_STRING||LA29_0==RULE_FLOAT) ) {
                                alt29=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 29, 0, input);

                                throw nvae;
                            }
                            switch (alt29) {
                                case 1 :
                                    // InternalSM2.g:1095:7: this_PropertyAddress_19= rulePropertyAddress
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyAddressParserRuleCall_0_2_3_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_28);
                                    this_PropertyAddress_19=rulePropertyAddress();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyAddress_19;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1104:7: this_SyntaxExpression_20= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_3_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_28);
                                    this_SyntaxExpression_20=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_20;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_21=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_21, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_3_3());
                              					
                            }

                            }


                            }
                            break;
                        case 5 :
                            // InternalSM2.g:1119:5: (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:1119:5: (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:1120:6: otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_22=(Token)match(input,56,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_22, grammarAccess.getBlockVariablesAccess().getGaslimitKeyword_0_2_4_0());
                              					
                            }
                            this_OPENPARENTHESIS_23=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_30); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_23, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_4_1());
                              					
                            }
                            // InternalSM2.g:1128:6: (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression )
                            int alt30=2;
                            int LA30_0 = input.LA(1);

                            if ( ((LA30_0>=80 && LA30_0<=88)) ) {
                                alt30=1;
                            }
                            else if ( (LA30_0==RULE_INTEGER||LA30_0==RULE_STRING||LA30_0==RULE_FLOAT) ) {
                                alt30=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 30, 0, input);

                                throw nvae;
                            }
                            switch (alt30) {
                                case 1 :
                                    // InternalSM2.g:1129:7: this_PropertyInteger_24= rulePropertyInteger
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_4_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_28);
                                    this_PropertyInteger_24=rulePropertyInteger();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyInteger_24;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1138:7: this_SyntaxExpression_25= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_4_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_28);
                                    this_SyntaxExpression_25=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_25;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_26=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_26, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_4_3());
                              					
                            }

                            }


                            }
                            break;
                        case 6 :
                            // InternalSM2.g:1153:5: (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:1153:5: (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:1154:6: otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_27=(Token)match(input,57,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_27, grammarAccess.getBlockVariablesAccess().getBlockhashKeyword_0_2_5_0());
                              					
                            }
                            this_OPENPARENTHESIS_28=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_30); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_28, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_5_1());
                              					
                            }
                            // InternalSM2.g:1162:6: (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression )
                            int alt31=2;
                            int LA31_0 = input.LA(1);

                            if ( ((LA31_0>=80 && LA31_0<=88)) ) {
                                alt31=1;
                            }
                            else if ( (LA31_0==RULE_INTEGER||LA31_0==RULE_STRING||LA31_0==RULE_FLOAT) ) {
                                alt31=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 31, 0, input);

                                throw nvae;
                            }
                            switch (alt31) {
                                case 1 :
                                    // InternalSM2.g:1163:7: this_PropertyInteger_29= rulePropertyInteger
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_5_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_28);
                                    this_PropertyInteger_29=rulePropertyInteger();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyInteger_29;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1172:7: this_SyntaxExpression_30= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_5_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_28);
                                    this_SyntaxExpression_30=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_30;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_31=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_31, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_5_3());
                              					
                            }

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1189:3: (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS (this_SEMICOLON_37= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:1189:3: (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS (this_SEMICOLON_37= RULE_SEMICOLON )? )
                    // InternalSM2.g:1190:4: otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS (this_SEMICOLON_37= RULE_SEMICOLON )?
                    {
                    otherlv_32=(Token)match(input,58,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_32, grammarAccess.getBlockVariablesAccess().getNowKeyword_1_0());
                      			
                    }
                    this_OPENPARENTHESIS_33=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_30); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_OPENPARENTHESIS_33, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_1_1());
                      			
                    }
                    // InternalSM2.g:1198:4: (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression )
                    int alt33=2;
                    int LA33_0 = input.LA(1);

                    if ( ((LA33_0>=80 && LA33_0<=88)) ) {
                        alt33=1;
                    }
                    else if ( (LA33_0==RULE_INTEGER||LA33_0==RULE_STRING||LA33_0==RULE_FLOAT) ) {
                        alt33=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 33, 0, input);

                        throw nvae;
                    }
                    switch (alt33) {
                        case 1 :
                            // InternalSM2.g:1199:5: this_PropertyInteger_34= rulePropertyInteger
                            {
                            if ( state.backtracking==0 ) {

                              					newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_1_2_0());
                              				
                            }
                            pushFollow(FOLLOW_28);
                            this_PropertyInteger_34=rulePropertyInteger();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					current = this_PropertyInteger_34;
                              					afterParserOrEnumRuleCall();
                              				
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:1208:5: this_SyntaxExpression_35= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              					newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_1_2_1());
                              				
                            }
                            pushFollow(FOLLOW_28);
                            this_SyntaxExpression_35=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					current = this_SyntaxExpression_35;
                              					afterParserOrEnumRuleCall();
                              				
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_36=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_CLOSEPARENTHESIS_36, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3());
                      			
                    }
                    // InternalSM2.g:1221:4: (this_SEMICOLON_37= RULE_SEMICOLON )?
                    int alt34=2;
                    int LA34_0 = input.LA(1);

                    if ( (LA34_0==RULE_SEMICOLON) ) {
                        int LA34_1 = input.LA(2);

                        if ( (LA34_1==EOF||LA34_1==RULE_SEMICOLON||LA34_1==RULE_CLOSEKEY||(LA34_1>=RULE_INTEGER && LA34_1<=RULE_ID)||(LA34_1>=RULE_OPENPARENTHESIS && LA34_1<=RULE_STRING)||LA34_1==RULE_FLOAT||LA34_1==RULE_BREAK||LA34_1==45||LA34_1==51||(LA34_1>=58 && LA34_1<=59)||LA34_1==115) ) {
                            alt34=1;
                        }
                        else if ( (LA34_1==RULE_EOLINE) ) {
                            int LA34_4 = input.LA(3);

                            if ( ((LA34_4>=RULE_EOLINE && LA34_4<=RULE_CLOSEKEY)||LA34_4==RULE_BREAK) ) {
                                alt34=1;
                            }
                        }
                    }
                    switch (alt34) {
                        case 1 :
                            // InternalSM2.g:1222:5: this_SEMICOLON_37= RULE_SEMICOLON
                            {
                            this_SEMICOLON_37=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_37, grammarAccess.getBlockVariablesAccess().getSEMICOLONTerminalRuleCall_1_4());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBlockVariables"


    // $ANTLR start "entryRuleThx"
    // InternalSM2.g:1232:1: entryRuleThx returns [EObject current=null] : iv_ruleThx= ruleThx EOF ;
    public final EObject entryRuleThx() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleThx = null;


        try {
            // InternalSM2.g:1232:44: (iv_ruleThx= ruleThx EOF )
            // InternalSM2.g:1233:2: iv_ruleThx= ruleThx EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getThxRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleThx=ruleThx();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleThx; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleThx"


    // $ANTLR start "ruleThx"
    // InternalSM2.g:1239:1: ruleThx returns [EObject current=null] : (otherlv_0= 'thx' this_DOT_1= RULE_DOT ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) ;
    public final EObject ruleThx() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_DOT_1=null;
        Token otherlv_2=null;
        Token this_OPENPARENTHESIS_3=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token otherlv_7=null;
        Token this_OPENPARENTHESIS_8=null;
        Token this_CLOSEPARENTHESIS_11=null;
        EObject this_PropertyAddress_4 = null;

        EObject this_SyntaxExpression_5 = null;

        EObject this_PropertyInteger_9 = null;

        EObject this_SyntaxExpression_10 = null;



        	enterRule();

        try {
            // InternalSM2.g:1245:2: ( (otherlv_0= 'thx' this_DOT_1= RULE_DOT ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:1246:2: (otherlv_0= 'thx' this_DOT_1= RULE_DOT ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:1246:2: (otherlv_0= 'thx' this_DOT_1= RULE_DOT ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:1247:3: otherlv_0= 'thx' this_DOT_1= RULE_DOT ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS
            {
            otherlv_0=(Token)match(input,59,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getThxAccess().getThxKeyword_0());
              		
            }
            this_DOT_1=(Token)match(input,RULE_DOT,FOLLOW_33); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_DOT_1, grammarAccess.getThxAccess().getDOTTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1255:3: ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) ) )
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==60) ) {
                alt38=1;
            }
            else if ( (LA38_0==61) ) {
                alt38=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 38, 0, input);

                throw nvae;
            }
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:1256:4: (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:1256:4: (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:1257:5: otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS
                    {
                    otherlv_2=(Token)match(input,60,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_2, grammarAccess.getThxAccess().getGaspriceKeyword_2_0_0());
                      				
                    }
                    this_OPENPARENTHESIS_3=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_31); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_3, grammarAccess.getThxAccess().getOPENPARENTHESISTerminalRuleCall_2_0_1());
                      				
                    }
                    // InternalSM2.g:1265:5: (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression )
                    int alt36=2;
                    int LA36_0 = input.LA(1);

                    if ( (LA36_0==71||LA36_0==90) ) {
                        alt36=1;
                    }
                    else if ( (LA36_0==RULE_INTEGER||LA36_0==RULE_STRING||LA36_0==RULE_FLOAT) ) {
                        alt36=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 36, 0, input);

                        throw nvae;
                    }
                    switch (alt36) {
                        case 1 :
                            // InternalSM2.g:1266:6: this_PropertyAddress_4= rulePropertyAddress
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getThxAccess().getPropertyAddressParserRuleCall_2_0_2_0());
                              					
                            }
                            pushFollow(FOLLOW_28);
                            this_PropertyAddress_4=rulePropertyAddress();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_PropertyAddress_4;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:1275:6: this_SyntaxExpression_5= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getThxAccess().getSyntaxExpressionParserRuleCall_2_0_2_1());
                              					
                            }
                            pushFollow(FOLLOW_28);
                            this_SyntaxExpression_5=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_5;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getThxAccess().getCLOSEPARENTHESISTerminalRuleCall_2_0_3());
                      				
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1290:4: (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) )
                    {
                    // InternalSM2.g:1290:4: (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) )
                    // InternalSM2.g:1291:5: otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression )
                    {
                    otherlv_7=(Token)match(input,61,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_7, grammarAccess.getThxAccess().getOriginKeyword_2_1_0());
                      				
                    }
                    this_OPENPARENTHESIS_8=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_30); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_8, grammarAccess.getThxAccess().getOPENPARENTHESISTerminalRuleCall_2_1_1());
                      				
                    }
                    // InternalSM2.g:1299:5: (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression )
                    int alt37=2;
                    int LA37_0 = input.LA(1);

                    if ( ((LA37_0>=80 && LA37_0<=88)) ) {
                        alt37=1;
                    }
                    else if ( (LA37_0==RULE_INTEGER||LA37_0==RULE_STRING||LA37_0==RULE_FLOAT) ) {
                        alt37=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 37, 0, input);

                        throw nvae;
                    }
                    switch (alt37) {
                        case 1 :
                            // InternalSM2.g:1300:6: this_PropertyInteger_9= rulePropertyInteger
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getThxAccess().getPropertyIntegerParserRuleCall_2_1_2_0());
                              					
                            }
                            pushFollow(FOLLOW_28);
                            this_PropertyInteger_9=rulePropertyInteger();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_PropertyInteger_9;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:1309:6: this_SyntaxExpression_10= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getThxAccess().getSyntaxExpressionParserRuleCall_2_1_2_1());
                              					
                            }
                            pushFollow(FOLLOW_28);
                            this_SyntaxExpression_10=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_10;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_11=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_11, grammarAccess.getThxAccess().getCLOSEPARENTHESISTerminalRuleCall_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleThx"


    // $ANTLR start "entryRuleConstructor"
    // InternalSM2.g:1328:1: entryRuleConstructor returns [EObject current=null] : iv_ruleConstructor= ruleConstructor EOF ;
    public final EObject entryRuleConstructor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConstructor = null;


        try {
            // InternalSM2.g:1328:52: (iv_ruleConstructor= ruleConstructor EOF )
            // InternalSM2.g:1329:2: iv_ruleConstructor= ruleConstructor EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConstructorRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleConstructor=ruleConstructor();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleConstructor; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConstructor"


    // $ANTLR start "ruleConstructor"
    // InternalSM2.g:1335:1: ruleConstructor returns [EObject current=null] : (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY ) ;
    public final EObject ruleConstructor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_2=null;
        Token lv_type_3_1=null;
        Token lv_type_3_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token otherlv_6=null;
        Token this_CLOSEKEY_7=null;


        	enterRule();

        try {
            // InternalSM2.g:1341:2: ( (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY ) )
            // InternalSM2.g:1342:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY )
            {
            // InternalSM2.g:1342:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY )
            // InternalSM2.g:1343:3: otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,62,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getConstructorAccess().getConstructorKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConstructorAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1351:3: ( (otherlv_2= RULE_ID ) )
            // InternalSM2.g:1352:4: (otherlv_2= RULE_ID )
            {
            // InternalSM2.g:1352:4: (otherlv_2= RULE_ID )
            // InternalSM2.g:1353:5: otherlv_2= RULE_ID
            {
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getConstructorRule());
              					}
              				
            }
            otherlv_2=(Token)match(input,RULE_ID,FOLLOW_34); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(otherlv_2, grammarAccess.getConstructorAccess().getInputParamsInputParamCrossReference_2_0());
              				
            }

            }


            }

            // InternalSM2.g:1364:3: ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) )
            // InternalSM2.g:1365:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            {
            // InternalSM2.g:1365:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            // InternalSM2.g:1366:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            {
            // InternalSM2.g:1366:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==63) ) {
                alt39=1;
            }
            else if ( (LA39_0==64) ) {
                alt39=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 39, 0, input);

                throw nvae;
            }
            switch (alt39) {
                case 1 :
                    // InternalSM2.g:1367:6: lv_type_3_1= 'public'
                    {
                    lv_type_3_1=(Token)match(input,63,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_3_1, grammarAccess.getConstructorAccess().getTypePublicKeyword_3_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getConstructorRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_3_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1378:6: lv_type_3_2= 'internal'
                    {
                    lv_type_3_2=(Token)match(input,64,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_3_2, grammarAccess.getConstructorAccess().getTypeInternalKeyword_3_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getConstructorRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_3_2, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getConstructorAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_35); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getConstructorAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1399:3: ( (otherlv_6= RULE_ID ) )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==RULE_ID) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalSM2.g:1400:4: (otherlv_6= RULE_ID )
                    {
                    // InternalSM2.g:1400:4: (otherlv_6= RULE_ID )
                    // InternalSM2.g:1401:5: otherlv_6= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getConstructorRule());
                      					}
                      				
                    }
                    otherlv_6=(Token)match(input,RULE_ID,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_6, grammarAccess.getConstructorAccess().getAttributesAttributesCrossReference_6_0());
                      				
                    }

                    }


                    }
                    break;

            }

            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_7, grammarAccess.getConstructorAccess().getCLOSEKEYTerminalRuleCall_7());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConstructor"


    // $ANTLR start "entryRuleEvent"
    // InternalSM2.g:1420:1: entryRuleEvent returns [EObject current=null] : iv_ruleEvent= ruleEvent EOF ;
    public final EObject entryRuleEvent() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvent = null;


        try {
            // InternalSM2.g:1420:46: (iv_ruleEvent= ruleEvent EOF )
            // InternalSM2.g:1421:2: iv_ruleEvent= ruleEvent EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getEventRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleEvent=ruleEvent();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleEvent; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalSM2.g:1427:1: ruleEvent returns [EObject current=null] : (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject ruleEvent() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEvent_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;
        EObject lv_inputParams_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1433:2: ( (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1434:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1434:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1435:3: otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,65,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getEventAccess().getEventKeyword_0());
              		
            }
            // InternalSM2.g:1439:3: ( (lv_nameEvent_1_0= RULE_ID ) )
            // InternalSM2.g:1440:4: (lv_nameEvent_1_0= RULE_ID )
            {
            // InternalSM2.g:1440:4: (lv_nameEvent_1_0= RULE_ID )
            // InternalSM2.g:1441:5: lv_nameEvent_1_0= RULE_ID
            {
            lv_nameEvent_1_0=(Token)match(input,RULE_ID,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameEvent_1_0, grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEventRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameEvent",
              						lv_nameEvent_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_36); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1461:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop41:
            do {
                int alt41=2;
                int LA41_0 = input.LA(1);

                if ( (LA41_0==71||LA41_0==73||(LA41_0>=80 && LA41_0<=90)||(LA41_0>=92 && LA41_0<=98)||LA41_0==100||(LA41_0>=137 && LA41_0<=139)) ) {
                    alt41=1;
                }


                switch (alt41) {
            	case 1 :
            	    // InternalSM2.g:1462:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1462:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:1463:5: lv_inputParams_3_0= ruleInputParam
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_36);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getEventRule());
            	      					}
            	      					add(
            	      						current,
            	      						"inputParams",
            	      						lv_inputParams_3_0,
            	      						"org.xtext.SM2.InputParam");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop41;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_5, grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1488:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==RULE_EOLINE) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalSM2.g:1489:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:1498:1: entryRuleModifier returns [EObject current=null] : iv_ruleModifier= ruleModifier EOF ;
    public final EObject entryRuleModifier() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModifier = null;


        try {
            // InternalSM2.g:1498:49: (iv_ruleModifier= ruleModifier EOF )
            // InternalSM2.g:1499:2: iv_ruleModifier= ruleModifier EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getModifierRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleModifier=ruleModifier();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleModifier; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:1505:1: ruleModifier returns [EObject current=null] : (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? ) ;
    public final EObject ruleModifier() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameModifier_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_EOLINE_6=null;
        Token this_SEMICOLON_9=null;
        Token this_EOLINE_10=null;
        Token otherlv_11=null;
        Token this_CLOSEKEY_12=null;
        Token this_EOLINE_13=null;
        EObject lv_inputParams_3_0 = null;

        EObject lv_conditions_7_0 = null;

        EObject lv_expr_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1511:2: ( (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? ) )
            // InternalSM2.g:1512:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? )
            {
            // InternalSM2.g:1512:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? )
            // InternalSM2.g:1513:3: otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,66,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getModifierAccess().getModifierKeyword_0());
              		
            }
            // InternalSM2.g:1517:3: ( (lv_nameModifier_1_0= RULE_ID ) )
            // InternalSM2.g:1518:4: (lv_nameModifier_1_0= RULE_ID )
            {
            // InternalSM2.g:1518:4: (lv_nameModifier_1_0= RULE_ID )
            // InternalSM2.g:1519:5: lv_nameModifier_1_0= RULE_ID
            {
            lv_nameModifier_1_0=(Token)match(input,RULE_ID,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameModifier_1_0, grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getModifierRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameModifier",
              						lv_nameModifier_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_36); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1539:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop43:
            do {
                int alt43=2;
                int LA43_0 = input.LA(1);

                if ( (LA43_0==71||LA43_0==73||(LA43_0>=80 && LA43_0<=90)||(LA43_0>=92 && LA43_0<=98)||LA43_0==100||(LA43_0>=137 && LA43_0<=139)) ) {
                    alt43=1;
                }


                switch (alt43) {
            	case 1 :
            	    // InternalSM2.g:1540:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1540:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:1541:5: lv_inputParams_3_0= ruleInputParam
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_36);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getModifierRule());
            	      					}
            	      					add(
            	      						current,
            	      						"inputParams",
            	      						lv_inputParams_3_0,
            	      						"org.xtext.SM2.InputParam");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop43;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_37); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1566:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==RULE_EOLINE) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:1567:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_37); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:1572:3: ( (lv_conditions_7_0= ruleConditional ) )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==RULE_IF) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalSM2.g:1573:4: (lv_conditions_7_0= ruleConditional )
                    {
                    // InternalSM2.g:1573:4: (lv_conditions_7_0= ruleConditional )
                    // InternalSM2.g:1574:5: lv_conditions_7_0= ruleConditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getModifierAccess().getConditionsConditionalParserRuleCall_7_0());
                      				
                    }
                    pushFollow(FOLLOW_37);
                    lv_conditions_7_0=ruleConditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getModifierRule());
                      					}
                      					add(
                      						current,
                      						"conditions",
                      						lv_conditions_7_0,
                      						"org.xtext.SM2.Conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1591:3: ( (lv_expr_8_0= ruleExpression ) )
            // InternalSM2.g:1592:4: (lv_expr_8_0= ruleExpression )
            {
            // InternalSM2.g:1592:4: (lv_expr_8_0= ruleExpression )
            // InternalSM2.g:1593:5: lv_expr_8_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getModifierAccess().getExprExpressionParserRuleCall_8_0());
              				
            }
            pushFollow(FOLLOW_5);
            lv_expr_8_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getModifierRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_8_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_38); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_9, grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_9());
              		
            }
            // InternalSM2.g:1614:3: (this_EOLINE_10= RULE_EOLINE )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==RULE_EOLINE) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:1615:4: this_EOLINE_10= RULE_EOLINE
                    {
                    this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_39); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_10, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_10());
                      			
                    }

                    }
                    break;

            }

            otherlv_11=(Token)match(input,67,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_11, grammarAccess.getModifierAccess().get_Keyword_11());
              		
            }
            this_CLOSEKEY_12=(Token)match(input,RULE_CLOSEKEY,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_12, grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_12());
              		
            }
            // InternalSM2.g:1628:3: (this_EOLINE_13= RULE_EOLINE )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==RULE_EOLINE) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalSM2.g:1629:4: this_EOLINE_13= RULE_EOLINE
                    {
                    this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_13, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_13());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:1638:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalSM2.g:1638:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalSM2.g:1639:2: iv_ruleDataType= ruleDataType EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getDataTypeRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleDataType; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:1645:1: ruleDataType returns [EObject current=null] : (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        EObject this_Mapping_0 = null;

        EObject this_Enum_1 = null;

        EObject this_Struct_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:1651:2: ( (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct ) )
            // InternalSM2.g:1652:2: (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct )
            {
            // InternalSM2.g:1652:2: (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct )
            int alt48=3;
            switch ( input.LA(1) ) {
            case 68:
                {
                alt48=1;
                }
                break;
            case 76:
                {
                alt48=2;
                }
                break;
            case 70:
                {
                alt48=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 48, 0, input);

                throw nvae;
            }

            switch (alt48) {
                case 1 :
                    // InternalSM2.g:1653:3: this_Mapping_0= ruleMapping
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getMappingParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Mapping_0=ruleMapping();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Mapping_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1662:3: this_Enum_1= ruleEnum
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Enum_1=ruleEnum();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Enum_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1671:3: this_Struct_2= ruleStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getStructParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Struct_2=ruleStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Struct_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:1683:1: entryRuleMapping returns [EObject current=null] : iv_ruleMapping= ruleMapping EOF ;
    public final EObject entryRuleMapping() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMapping = null;


        try {
            // InternalSM2.g:1683:48: (iv_ruleMapping= ruleMapping EOF )
            // InternalSM2.g:1684:2: iv_ruleMapping= ruleMapping EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMappingRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleMapping=ruleMapping();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleMapping; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:1690:1: ruleMapping returns [EObject current=null] : (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON ) ;
    public final EObject ruleMapping() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token lv_nameMapping_8_0=null;
        Token this_SEMICOLON_9=null;
        Enumerator lv_key_2_0 = null;

        Enumerator lv_valueBasicType_5_0 = null;

        Enumerator lv_visibility_7_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1696:2: ( (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON ) )
            // InternalSM2.g:1697:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON )
            {
            // InternalSM2.g:1697:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON )
            // InternalSM2.g:1698:3: otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON
            {
            otherlv_0=(Token)match(input,68,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getMappingAccess().getMappingKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_40); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1706:3: ( (lv_key_2_0= ruleBasicType ) )
            // InternalSM2.g:1707:4: (lv_key_2_0= ruleBasicType )
            {
            // InternalSM2.g:1707:4: (lv_key_2_0= ruleBasicType )
            // InternalSM2.g:1708:5: lv_key_2_0= ruleBasicType
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getMappingAccess().getKeyBasicTypeEnumRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_41);
            lv_key_2_0=ruleBasicType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getMappingRule());
              					}
              					set(
              						current,
              						"key",
              						lv_key_2_0,
              						"org.xtext.SM2.BasicType");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,69,FOLLOW_42); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3());
              		
            }
            // InternalSM2.g:1729:3: ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) )
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==RULE_ID) ) {
                alt49=1;
            }
            else if ( (LA49_0==71||LA49_0==73||(LA49_0>=80 && LA49_0<=90)||(LA49_0>=92 && LA49_0<=98)||LA49_0==100||(LA49_0>=137 && LA49_0<=139)) ) {
                alt49=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 49, 0, input);

                throw nvae;
            }
            switch (alt49) {
                case 1 :
                    // InternalSM2.g:1730:4: ( (otherlv_4= RULE_ID ) )
                    {
                    // InternalSM2.g:1730:4: ( (otherlv_4= RULE_ID ) )
                    // InternalSM2.g:1731:5: (otherlv_4= RULE_ID )
                    {
                    // InternalSM2.g:1731:5: (otherlv_4= RULE_ID )
                    // InternalSM2.g:1732:6: otherlv_4= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getMappingRule());
                      						}
                      					
                    }
                    otherlv_4=(Token)match(input,RULE_ID,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(otherlv_4, grammarAccess.getMappingAccess().getValueStructCrossReference_4_0_0());
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1744:4: ( (lv_valueBasicType_5_0= ruleBasicType ) )
                    {
                    // InternalSM2.g:1744:4: ( (lv_valueBasicType_5_0= ruleBasicType ) )
                    // InternalSM2.g:1745:5: (lv_valueBasicType_5_0= ruleBasicType )
                    {
                    // InternalSM2.g:1745:5: (lv_valueBasicType_5_0= ruleBasicType )
                    // InternalSM2.g:1746:6: lv_valueBasicType_5_0= ruleBasicType
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getMappingAccess().getValueBasicTypeBasicTypeEnumRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_28);
                    lv_valueBasicType_5_0=ruleBasicType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getMappingRule());
                      						}
                      						set(
                      							current,
                      							"valueBasicType",
                      							lv_valueBasicType_5_0,
                      							"org.xtext.SM2.BasicType");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_43); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1768:3: ( (lv_visibility_7_0= ruleVisibility ) )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( ((LA50_0>=63 && LA50_0<=64)||(LA50_0>=118 && LA50_0<=119)) ) {
                alt50=1;
            }
            switch (alt50) {
                case 1 :
                    // InternalSM2.g:1769:4: (lv_visibility_7_0= ruleVisibility )
                    {
                    // InternalSM2.g:1769:4: (lv_visibility_7_0= ruleVisibility )
                    // InternalSM2.g:1770:5: lv_visibility_7_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_12);
                    lv_visibility_7_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getMappingRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_7_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1787:3: ( (lv_nameMapping_8_0= RULE_ID ) )
            // InternalSM2.g:1788:4: (lv_nameMapping_8_0= RULE_ID )
            {
            // InternalSM2.g:1788:4: (lv_nameMapping_8_0= RULE_ID )
            // InternalSM2.g:1789:5: lv_nameMapping_8_0= RULE_ID
            {
            lv_nameMapping_8_0=(Token)match(input,RULE_ID,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameMapping_8_0, grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getMappingRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameMapping",
              						lv_nameMapping_8_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_9, grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:1813:1: entryRuleStruct returns [EObject current=null] : iv_ruleStruct= ruleStruct EOF ;
    public final EObject entryRuleStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStruct = null;


        try {
            // InternalSM2.g:1813:47: (iv_ruleStruct= ruleStruct EOF )
            // InternalSM2.g:1814:2: iv_ruleStruct= ruleStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleStruct=ruleStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:1820:1: ruleStruct returns [EObject current=null] : (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany ) ;
    public final EObject ruleStruct() throws RecognitionException {
        EObject current = null;

        EObject this_PersonalizedStruct_0 = null;

        EObject this_User_1 = null;

        EObject this_Company_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:1826:2: ( (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany ) )
            // InternalSM2.g:1827:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )
            {
            // InternalSM2.g:1827:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )
            int alt51=3;
            alt51 = dfa51.predict(input);
            switch (alt51) {
                case 1 :
                    // InternalSM2.g:1828:3: this_PersonalizedStruct_0= rulePersonalizedStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructAccess().getPersonalizedStructParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PersonalizedStruct_0=rulePersonalizedStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PersonalizedStruct_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1837:3: this_User_1= ruleUser
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructAccess().getUserParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_User_1=ruleUser();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_User_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1846:3: this_Company_2= ruleCompany
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructAccess().getCompanyParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Company_2=ruleCompany();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Company_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRulePersonalizedStruct"
    // InternalSM2.g:1858:1: entryRulePersonalizedStruct returns [EObject current=null] : iv_rulePersonalizedStruct= rulePersonalizedStruct EOF ;
    public final EObject entryRulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonalizedStruct = null;


        try {
            // InternalSM2.g:1858:59: (iv_rulePersonalizedStruct= rulePersonalizedStruct EOF )
            // InternalSM2.g:1859:2: iv_rulePersonalizedStruct= rulePersonalizedStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPersonalizedStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePersonalizedStruct=rulePersonalizedStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePersonalizedStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonalizedStruct"


    // $ANTLR start "rulePersonalizedStruct"
    // InternalSM2.g:1865:1: rulePersonalizedStruct returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject rulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_CLOSEKEY_5=null;
        Token this_EOLINE_6=null;
        EObject lv_properties_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1871:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1872:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1872:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1873:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,70,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getPersonalizedStructAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:1877:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1878:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1878:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1879:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getPersonalizedStructAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPersonalizedStructRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_44); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1899:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==RULE_EOLINE) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalSM2.g:1900:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_45); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:1905:3: ( (lv_properties_4_0= ruleProperty ) )+
            int cnt53=0;
            loop53:
            do {
                int alt53=2;
                int LA53_0 = input.LA(1);

                if ( (LA53_0==RULE_ID||LA53_0==71||(LA53_0>=73 && LA53_0<=74)||(LA53_0>=80 && LA53_0<=100)) ) {
                    alt53=1;
                }


                switch (alt53) {
            	case 1 :
            	    // InternalSM2.g:1906:4: (lv_properties_4_0= ruleProperty )
            	    {
            	    // InternalSM2.g:1906:4: (lv_properties_4_0= ruleProperty )
            	    // InternalSM2.g:1907:5: lv_properties_4_0= ruleProperty
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_46);
            	    lv_properties_4_0=ruleProperty();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getPersonalizedStructRule());
            	      					}
            	      					add(
            	      						current,
            	      						"properties",
            	      						lv_properties_4_0,
            	      						"org.xtext.SM2.Property");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt53 >= 1 ) break loop53;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(53, input);
                        throw eee;
                }
                cnt53++;
            } while (true);

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_5, grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1928:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==RULE_EOLINE) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalSM2.g:1929:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonalizedStruct"


    // $ANTLR start "entryRuleUser"
    // InternalSM2.g:1938:1: entryRuleUser returns [EObject current=null] : iv_ruleUser= ruleUser EOF ;
    public final EObject entryRuleUser() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUser = null;


        try {
            // InternalSM2.g:1938:45: (iv_ruleUser= ruleUser EOF )
            // InternalSM2.g:1939:2: iv_ruleUser= ruleUser EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getUserRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleUser=ruleUser();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleUser; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUser"


    // $ANTLR start "ruleUser"
    // InternalSM2.g:1945:1: ruleUser returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) ;
    public final EObject ruleUser() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_0=null;
        Token otherlv_6=null;
        Token this_STRING_7=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Token otherlv_10=null;
        Token lv_nameUser_11_0=null;
        Token otherlv_12=null;
        Token this_STRING_13=null;
        Token this_SEMICOLON_14=null;
        Token this_EOLINE_15=null;
        Token otherlv_16=null;
        Token lv_surname_17_0=null;
        Token otherlv_18=null;
        Token this_STRING_19=null;
        Token this_SEMICOLON_20=null;
        Token this_EOLINE_21=null;
        Token otherlv_22=null;
        Token lv_email_23_0=null;
        Token otherlv_24=null;
        Token this_EMAIL_25=null;
        Token this_SEMICOLON_26=null;
        Token this_EOLINE_27=null;
        Token otherlv_28=null;
        Token otherlv_29=null;
        Token otherlv_30=null;
        Token lv_amount_31_0=null;
        Token this_FLOAT_32=null;
        Token this_SEMICOLON_33=null;
        Token this_EOLINE_34=null;
        Token this_CLOSEKEY_35=null;
        Token this_EOLINE_36=null;


        	enterRule();

        try {
            // InternalSM2.g:1951:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) )
            // InternalSM2.g:1952:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            {
            // InternalSM2.g:1952:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            // InternalSM2.g:1953:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,70,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getUserAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:1957:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1958:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1958:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1959:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1979:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==RULE_EOLINE) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // InternalSM2.g:1980:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_48); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            otherlv_4=(Token)match(input,71,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getUserAccess().getAddressKeyword_4());
              		
            }
            // InternalSM2.g:1989:3: ( (lv_idAdress_5_0= RULE_ID ) )
            // InternalSM2.g:1990:4: (lv_idAdress_5_0= RULE_ID )
            {
            // InternalSM2.g:1990:4: (lv_idAdress_5_0= RULE_ID )
            // InternalSM2.g:1991:5: lv_idAdress_5_0= RULE_ID
            {
            lv_idAdress_5_0=(Token)match(input,RULE_ID,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_idAdress_5_0, grammarAccess.getUserAccess().getIdAdressIDTerminalRuleCall_5_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"idAdress",
              						lv_idAdress_5_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:2007:3: (otherlv_6= '=' this_STRING_7= RULE_STRING )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==72) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalSM2.g:2008:4: otherlv_6= '=' this_STRING_7= RULE_STRING
                    {
                    otherlv_6=(Token)match(input,72,FOLLOW_50); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_6, grammarAccess.getUserAccess().getEqualsSignKeyword_6_0());
                      			
                    }
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_7, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_6_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            // InternalSM2.g:2021:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==RULE_EOLINE) ) {
                alt57=1;
            }
            switch (alt57) {
                case 1 :
                    // InternalSM2.g:2022:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_52); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_8());
                      			
                    }

                    }
                    break;

            }

            otherlv_10=(Token)match(input,73,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_10, grammarAccess.getUserAccess().getStringKeyword_9());
              		
            }
            // InternalSM2.g:2031:3: ( (lv_nameUser_11_0= RULE_STRING ) )
            // InternalSM2.g:2032:4: (lv_nameUser_11_0= RULE_STRING )
            {
            // InternalSM2.g:2032:4: (lv_nameUser_11_0= RULE_STRING )
            // InternalSM2.g:2033:5: lv_nameUser_11_0= RULE_STRING
            {
            lv_nameUser_11_0=(Token)match(input,RULE_STRING,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameUser_11_0, grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_10_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameUser",
              						lv_nameUser_11_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2049:3: (otherlv_12= '=' this_STRING_13= RULE_STRING )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==72) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // InternalSM2.g:2050:4: otherlv_12= '=' this_STRING_13= RULE_STRING
                    {
                    otherlv_12=(Token)match(input,72,FOLLOW_50); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_12, grammarAccess.getUserAccess().getEqualsSignKeyword_11_0());
                      			
                    }
                    this_STRING_13=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_13, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_11_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_14=(Token)match(input,RULE_SEMICOLON,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_14, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_12());
              		
            }
            // InternalSM2.g:2063:3: (this_EOLINE_15= RULE_EOLINE )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==RULE_EOLINE) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // InternalSM2.g:2064:4: this_EOLINE_15= RULE_EOLINE
                    {
                    this_EOLINE_15=(Token)match(input,RULE_EOLINE,FOLLOW_52); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_15, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_13());
                      			
                    }

                    }
                    break;

            }

            otherlv_16=(Token)match(input,73,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_16, grammarAccess.getUserAccess().getStringKeyword_14());
              		
            }
            // InternalSM2.g:2073:3: ( (lv_surname_17_0= RULE_STRING ) )
            // InternalSM2.g:2074:4: (lv_surname_17_0= RULE_STRING )
            {
            // InternalSM2.g:2074:4: (lv_surname_17_0= RULE_STRING )
            // InternalSM2.g:2075:5: lv_surname_17_0= RULE_STRING
            {
            lv_surname_17_0=(Token)match(input,RULE_STRING,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_surname_17_0, grammarAccess.getUserAccess().getSurnameSTRINGTerminalRuleCall_15_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"surname",
              						lv_surname_17_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2091:3: (otherlv_18= '=' this_STRING_19= RULE_STRING )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==72) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // InternalSM2.g:2092:4: otherlv_18= '=' this_STRING_19= RULE_STRING
                    {
                    otherlv_18=(Token)match(input,72,FOLLOW_50); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_18, grammarAccess.getUserAccess().getEqualsSignKeyword_16_0());
                      			
                    }
                    this_STRING_19=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_19, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_16_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_20=(Token)match(input,RULE_SEMICOLON,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_20, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_17());
              		
            }
            // InternalSM2.g:2105:3: (this_EOLINE_21= RULE_EOLINE )?
            int alt61=2;
            int LA61_0 = input.LA(1);

            if ( (LA61_0==RULE_EOLINE) ) {
                alt61=1;
            }
            switch (alt61) {
                case 1 :
                    // InternalSM2.g:2106:4: this_EOLINE_21= RULE_EOLINE
                    {
                    this_EOLINE_21=(Token)match(input,RULE_EOLINE,FOLLOW_52); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_21, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_18());
                      			
                    }

                    }
                    break;

            }

            otherlv_22=(Token)match(input,73,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_22, grammarAccess.getUserAccess().getStringKeyword_19());
              		
            }
            // InternalSM2.g:2115:3: ( (lv_email_23_0= RULE_STRING ) )
            // InternalSM2.g:2116:4: (lv_email_23_0= RULE_STRING )
            {
            // InternalSM2.g:2116:4: (lv_email_23_0= RULE_STRING )
            // InternalSM2.g:2117:5: lv_email_23_0= RULE_STRING
            {
            lv_email_23_0=(Token)match(input,RULE_STRING,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_email_23_0, grammarAccess.getUserAccess().getEmailSTRINGTerminalRuleCall_20_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"email",
              						lv_email_23_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2133:3: (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )?
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==72) ) {
                alt62=1;
            }
            switch (alt62) {
                case 1 :
                    // InternalSM2.g:2134:4: otherlv_24= '=' this_EMAIL_25= RULE_EMAIL
                    {
                    otherlv_24=(Token)match(input,72,FOLLOW_53); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_24, grammarAccess.getUserAccess().getEqualsSignKeyword_21_0());
                      			
                    }
                    this_EMAIL_25=(Token)match(input,RULE_EMAIL,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EMAIL_25, grammarAccess.getUserAccess().getEMAILTerminalRuleCall_21_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_26=(Token)match(input,RULE_SEMICOLON,FOLLOW_54); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_26, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_22());
              		
            }
            // InternalSM2.g:2147:3: (this_EOLINE_27= RULE_EOLINE )?
            int alt63=2;
            int LA63_0 = input.LA(1);

            if ( (LA63_0==RULE_EOLINE) ) {
                alt63=1;
            }
            switch (alt63) {
                case 1 :
                    // InternalSM2.g:2148:4: this_EOLINE_27= RULE_EOLINE
                    {
                    this_EOLINE_27=(Token)match(input,RULE_EOLINE,FOLLOW_55); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_27, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_23());
                      			
                    }

                    }
                    break;

            }

            otherlv_28=(Token)match(input,74,FOLLOW_56); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_28, grammarAccess.getUserAccess().getFloatKeyword_24());
              		
            }
            otherlv_29=(Token)match(input,75,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_29, grammarAccess.getUserAccess().getAmountAccountKeyword_25());
              		
            }
            // InternalSM2.g:2161:3: (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )?
            int alt65=2;
            int LA65_0 = input.LA(1);

            if ( (LA65_0==72) ) {
                alt65=1;
            }
            switch (alt65) {
                case 1 :
                    // InternalSM2.g:2162:4: otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT )
                    {
                    otherlv_30=(Token)match(input,72,FOLLOW_57); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_30, grammarAccess.getUserAccess().getEqualsSignKeyword_26_0());
                      			
                    }
                    // InternalSM2.g:2166:4: ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT )
                    int alt64=2;
                    int LA64_0 = input.LA(1);

                    if ( (LA64_0==RULE_INTEGER) ) {
                        alt64=1;
                    }
                    else if ( (LA64_0==RULE_FLOAT) ) {
                        alt64=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 64, 0, input);

                        throw nvae;
                    }
                    switch (alt64) {
                        case 1 :
                            // InternalSM2.g:2167:5: ( (lv_amount_31_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:2167:5: ( (lv_amount_31_0= RULE_INTEGER ) )
                            // InternalSM2.g:2168:6: (lv_amount_31_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:2168:6: (lv_amount_31_0= RULE_INTEGER )
                            // InternalSM2.g:2169:7: lv_amount_31_0= RULE_INTEGER
                            {
                            lv_amount_31_0=(Token)match(input,RULE_INTEGER,FOLLOW_5); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_amount_31_0, grammarAccess.getUserAccess().getAmountINTEGERTerminalRuleCall_26_1_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getUserRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"amount",
                              								lv_amount_31_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:2186:5: this_FLOAT_32= RULE_FLOAT
                            {
                            this_FLOAT_32=(Token)match(input,RULE_FLOAT,FOLLOW_5); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_32, grammarAccess.getUserAccess().getFLOATTerminalRuleCall_26_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }
                    break;

            }

            this_SEMICOLON_33=(Token)match(input,RULE_SEMICOLON,FOLLOW_58); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_33, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_27());
              		
            }
            // InternalSM2.g:2196:3: (this_EOLINE_34= RULE_EOLINE )?
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==RULE_EOLINE) ) {
                alt66=1;
            }
            switch (alt66) {
                case 1 :
                    // InternalSM2.g:2197:4: this_EOLINE_34= RULE_EOLINE
                    {
                    this_EOLINE_34=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_34, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_28());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_35=(Token)match(input,RULE_CLOSEKEY,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_35, grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_29());
              		
            }
            // InternalSM2.g:2206:3: (this_EOLINE_36= RULE_EOLINE )?
            int alt67=2;
            int LA67_0 = input.LA(1);

            if ( (LA67_0==RULE_EOLINE) ) {
                alt67=1;
            }
            switch (alt67) {
                case 1 :
                    // InternalSM2.g:2207:4: this_EOLINE_36= RULE_EOLINE
                    {
                    this_EOLINE_36=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_36, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_30());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUser"


    // $ANTLR start "entryRuleCompany"
    // InternalSM2.g:2216:1: entryRuleCompany returns [EObject current=null] : iv_ruleCompany= ruleCompany EOF ;
    public final EObject entryRuleCompany() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompany = null;


        try {
            // InternalSM2.g:2216:48: (iv_ruleCompany= ruleCompany EOF )
            // InternalSM2.g:2217:2: iv_ruleCompany= ruleCompany EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCompanyRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleCompany=ruleCompany();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleCompany; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompany"


    // $ANTLR start "ruleCompany"
    // InternalSM2.g:2223:1: ruleCompany returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) ;
    public final EObject ruleCompany() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_0=null;
        Token otherlv_6=null;
        Token this_STRING_7=null;
        Token this_SEMICOLON_8=null;
        Token otherlv_9=null;
        Token lv_nameCompany_10_0=null;
        Token otherlv_11=null;
        Token this_STRING_12=null;
        Token this_SEMICOLON_13=null;
        Token otherlv_14=null;
        Token lv_city_15_0=null;
        Token otherlv_16=null;
        Token this_STRING_17=null;
        Token this_SEMICOLON_18=null;
        Token otherlv_19=null;
        Token lv_email_20_0=null;
        Token otherlv_21=null;
        Token this_EMAIL_22=null;
        Token this_SEMICOLON_23=null;
        Token otherlv_24=null;
        Token lv_telf_25_0=null;
        Token otherlv_26=null;
        Token this_STRING_27=null;
        Token this_SEMICOLON_28=null;
        Token otherlv_29=null;
        Token otherlv_30=null;
        Token otherlv_31=null;
        Token lv_amount_32_0=null;
        Token this_FLOAT_33=null;
        Token this_SEMICOLON_34=null;
        Token this_CLOSEKEY_35=null;
        Token this_EOLINE_36=null;


        	enterRule();

        try {
            // InternalSM2.g:2229:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) )
            // InternalSM2.g:2230:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            {
            // InternalSM2.g:2230:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            // InternalSM2.g:2231:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,70,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getCompanyAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:2235:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:2236:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:2236:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:2237:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getCompanyAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getCompanyAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2257:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==RULE_EOLINE) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // InternalSM2.g:2258:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_48); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            otherlv_4=(Token)match(input,71,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getCompanyAccess().getAddressKeyword_4());
              		
            }
            // InternalSM2.g:2267:3: ( (lv_idAdress_5_0= RULE_ID ) )
            // InternalSM2.g:2268:4: (lv_idAdress_5_0= RULE_ID )
            {
            // InternalSM2.g:2268:4: (lv_idAdress_5_0= RULE_ID )
            // InternalSM2.g:2269:5: lv_idAdress_5_0= RULE_ID
            {
            lv_idAdress_5_0=(Token)match(input,RULE_ID,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_idAdress_5_0, grammarAccess.getCompanyAccess().getIdAdressIDTerminalRuleCall_5_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"idAdress",
              						lv_idAdress_5_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:2285:3: (otherlv_6= '=' this_STRING_7= RULE_STRING )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==72) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // InternalSM2.g:2286:4: otherlv_6= '=' this_STRING_7= RULE_STRING
                    {
                    otherlv_6=(Token)match(input,72,FOLLOW_50); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_6, grammarAccess.getCompanyAccess().getEqualsSignKeyword_6_0());
                      			
                    }
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_7, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_6_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_52); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            otherlv_9=(Token)match(input,73,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_9, grammarAccess.getCompanyAccess().getStringKeyword_8());
              		
            }
            // InternalSM2.g:2303:3: ( (lv_nameCompany_10_0= RULE_STRING ) )
            // InternalSM2.g:2304:4: (lv_nameCompany_10_0= RULE_STRING )
            {
            // InternalSM2.g:2304:4: (lv_nameCompany_10_0= RULE_STRING )
            // InternalSM2.g:2305:5: lv_nameCompany_10_0= RULE_STRING
            {
            lv_nameCompany_10_0=(Token)match(input,RULE_STRING,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameCompany_10_0, grammarAccess.getCompanyAccess().getNameCompanySTRINGTerminalRuleCall_9_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameCompany",
              						lv_nameCompany_10_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2321:3: (otherlv_11= '=' this_STRING_12= RULE_STRING )?
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( (LA70_0==72) ) {
                alt70=1;
            }
            switch (alt70) {
                case 1 :
                    // InternalSM2.g:2322:4: otherlv_11= '=' this_STRING_12= RULE_STRING
                    {
                    otherlv_11=(Token)match(input,72,FOLLOW_50); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_11, grammarAccess.getCompanyAccess().getEqualsSignKeyword_10_0());
                      			
                    }
                    this_STRING_12=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_12, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_10_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_13=(Token)match(input,RULE_SEMICOLON,FOLLOW_52); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_13, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_11());
              		
            }
            otherlv_14=(Token)match(input,73,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_14, grammarAccess.getCompanyAccess().getStringKeyword_12());
              		
            }
            // InternalSM2.g:2339:3: ( (lv_city_15_0= RULE_STRING ) )
            // InternalSM2.g:2340:4: (lv_city_15_0= RULE_STRING )
            {
            // InternalSM2.g:2340:4: (lv_city_15_0= RULE_STRING )
            // InternalSM2.g:2341:5: lv_city_15_0= RULE_STRING
            {
            lv_city_15_0=(Token)match(input,RULE_STRING,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_city_15_0, grammarAccess.getCompanyAccess().getCitySTRINGTerminalRuleCall_13_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"city",
              						lv_city_15_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2357:3: (otherlv_16= '=' this_STRING_17= RULE_STRING )?
            int alt71=2;
            int LA71_0 = input.LA(1);

            if ( (LA71_0==72) ) {
                alt71=1;
            }
            switch (alt71) {
                case 1 :
                    // InternalSM2.g:2358:4: otherlv_16= '=' this_STRING_17= RULE_STRING
                    {
                    otherlv_16=(Token)match(input,72,FOLLOW_50); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_16, grammarAccess.getCompanyAccess().getEqualsSignKeyword_14_0());
                      			
                    }
                    this_STRING_17=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_17, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_14_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_18=(Token)match(input,RULE_SEMICOLON,FOLLOW_52); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_18, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_15());
              		
            }
            otherlv_19=(Token)match(input,73,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_19, grammarAccess.getCompanyAccess().getStringKeyword_16());
              		
            }
            // InternalSM2.g:2375:3: ( (lv_email_20_0= RULE_STRING ) )
            // InternalSM2.g:2376:4: (lv_email_20_0= RULE_STRING )
            {
            // InternalSM2.g:2376:4: (lv_email_20_0= RULE_STRING )
            // InternalSM2.g:2377:5: lv_email_20_0= RULE_STRING
            {
            lv_email_20_0=(Token)match(input,RULE_STRING,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_email_20_0, grammarAccess.getCompanyAccess().getEmailSTRINGTerminalRuleCall_17_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"email",
              						lv_email_20_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2393:3: (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )?
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==72) ) {
                alt72=1;
            }
            switch (alt72) {
                case 1 :
                    // InternalSM2.g:2394:4: otherlv_21= '=' this_EMAIL_22= RULE_EMAIL
                    {
                    otherlv_21=(Token)match(input,72,FOLLOW_53); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_21, grammarAccess.getCompanyAccess().getEqualsSignKeyword_18_0());
                      			
                    }
                    this_EMAIL_22=(Token)match(input,RULE_EMAIL,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EMAIL_22, grammarAccess.getCompanyAccess().getEMAILTerminalRuleCall_18_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_23=(Token)match(input,RULE_SEMICOLON,FOLLOW_52); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_23, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_19());
              		
            }
            otherlv_24=(Token)match(input,73,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_24, grammarAccess.getCompanyAccess().getStringKeyword_20());
              		
            }
            // InternalSM2.g:2411:3: ( (lv_telf_25_0= RULE_STRING ) )
            // InternalSM2.g:2412:4: (lv_telf_25_0= RULE_STRING )
            {
            // InternalSM2.g:2412:4: (lv_telf_25_0= RULE_STRING )
            // InternalSM2.g:2413:5: lv_telf_25_0= RULE_STRING
            {
            lv_telf_25_0=(Token)match(input,RULE_STRING,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_telf_25_0, grammarAccess.getCompanyAccess().getTelfSTRINGTerminalRuleCall_21_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"telf",
              						lv_telf_25_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2429:3: (otherlv_26= '=' this_STRING_27= RULE_STRING )?
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==72) ) {
                alt73=1;
            }
            switch (alt73) {
                case 1 :
                    // InternalSM2.g:2430:4: otherlv_26= '=' this_STRING_27= RULE_STRING
                    {
                    otherlv_26=(Token)match(input,72,FOLLOW_50); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_26, grammarAccess.getCompanyAccess().getEqualsSignKeyword_22_0());
                      			
                    }
                    this_STRING_27=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_27, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_22_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_28=(Token)match(input,RULE_SEMICOLON,FOLLOW_55); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_28, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_23());
              		
            }
            otherlv_29=(Token)match(input,74,FOLLOW_56); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_29, grammarAccess.getCompanyAccess().getFloatKeyword_24());
              		
            }
            otherlv_30=(Token)match(input,75,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_30, grammarAccess.getCompanyAccess().getAmountAccountKeyword_25());
              		
            }
            // InternalSM2.g:2451:3: (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )?
            int alt75=2;
            int LA75_0 = input.LA(1);

            if ( (LA75_0==72) ) {
                alt75=1;
            }
            switch (alt75) {
                case 1 :
                    // InternalSM2.g:2452:4: otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT )
                    {
                    otherlv_31=(Token)match(input,72,FOLLOW_57); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_31, grammarAccess.getCompanyAccess().getEqualsSignKeyword_26_0());
                      			
                    }
                    // InternalSM2.g:2456:4: ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT )
                    int alt74=2;
                    int LA74_0 = input.LA(1);

                    if ( (LA74_0==RULE_INTEGER) ) {
                        alt74=1;
                    }
                    else if ( (LA74_0==RULE_FLOAT) ) {
                        alt74=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 74, 0, input);

                        throw nvae;
                    }
                    switch (alt74) {
                        case 1 :
                            // InternalSM2.g:2457:5: ( (lv_amount_32_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:2457:5: ( (lv_amount_32_0= RULE_INTEGER ) )
                            // InternalSM2.g:2458:6: (lv_amount_32_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:2458:6: (lv_amount_32_0= RULE_INTEGER )
                            // InternalSM2.g:2459:7: lv_amount_32_0= RULE_INTEGER
                            {
                            lv_amount_32_0=(Token)match(input,RULE_INTEGER,FOLLOW_5); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_amount_32_0, grammarAccess.getCompanyAccess().getAmountINTEGERTerminalRuleCall_26_1_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getCompanyRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"amount",
                              								lv_amount_32_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:2476:5: this_FLOAT_33= RULE_FLOAT
                            {
                            this_FLOAT_33=(Token)match(input,RULE_FLOAT,FOLLOW_5); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_33, grammarAccess.getCompanyAccess().getFLOATTerminalRuleCall_26_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }
                    break;

            }

            this_SEMICOLON_34=(Token)match(input,RULE_SEMICOLON,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_34, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_27());
              		
            }
            this_CLOSEKEY_35=(Token)match(input,RULE_CLOSEKEY,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_35, grammarAccess.getCompanyAccess().getCLOSEKEYTerminalRuleCall_28());
              		
            }
            // InternalSM2.g:2490:3: (this_EOLINE_36= RULE_EOLINE )?
            int alt76=2;
            int LA76_0 = input.LA(1);

            if ( (LA76_0==RULE_EOLINE) ) {
                alt76=1;
            }
            switch (alt76) {
                case 1 :
                    // InternalSM2.g:2491:4: this_EOLINE_36= RULE_EOLINE
                    {
                    this_EOLINE_36=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_36, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_29());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompany"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:2500:1: entryRuleEnum returns [EObject current=null] : iv_ruleEnum= ruleEnum EOF ;
    public final EObject entryRuleEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnum = null;


        try {
            // InternalSM2.g:2500:45: (iv_ruleEnum= ruleEnum EOF )
            // InternalSM2.g:2501:2: iv_ruleEnum= ruleEnum EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getEnumRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleEnum=ruleEnum();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleEnum; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:2507:1: ruleEnum returns [EObject current=null] : (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEnum_1_0=null;
        Token this_OPENKEY_2=null;
        Token lv_literal_3_0=null;
        Token this_COMMA_4=null;
        Token this_CLOSEKEY_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;


        	enterRule();

        try {
            // InternalSM2.g:2513:2: ( (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2514:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2514:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2515:3: otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,76,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getEnumAccess().getEnumKeyword_0());
              		
            }
            // InternalSM2.g:2519:3: ( (lv_nameEnum_1_0= RULE_ID ) )
            // InternalSM2.g:2520:4: (lv_nameEnum_1_0= RULE_ID )
            {
            // InternalSM2.g:2520:4: (lv_nameEnum_1_0= RULE_ID )
            // InternalSM2.g:2521:5: lv_nameEnum_1_0= RULE_ID
            {
            lv_nameEnum_1_0=(Token)match(input,RULE_ID,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameEnum_1_0, grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEnumRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameEnum",
              						lv_nameEnum_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2541:3: ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+
            int cnt78=0;
            loop78:
            do {
                int alt78=2;
                int LA78_0 = input.LA(1);

                if ( (LA78_0==RULE_STRING) ) {
                    alt78=1;
                }


                switch (alt78) {
            	case 1 :
            	    // InternalSM2.g:2542:4: ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )?
            	    {
            	    // InternalSM2.g:2542:4: ( (lv_literal_3_0= RULE_STRING ) )
            	    // InternalSM2.g:2543:5: (lv_literal_3_0= RULE_STRING )
            	    {
            	    // InternalSM2.g:2543:5: (lv_literal_3_0= RULE_STRING )
            	    // InternalSM2.g:2544:6: lv_literal_3_0= RULE_STRING
            	    {
            	    lv_literal_3_0=(Token)match(input,RULE_STRING,FOLLOW_59); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      						newLeafNode(lv_literal_3_0, grammarAccess.getEnumAccess().getLiteralSTRINGTerminalRuleCall_3_0_0());
            	      					
            	    }
            	    if ( state.backtracking==0 ) {

            	      						if (current==null) {
            	      							current = createModelElement(grammarAccess.getEnumRule());
            	      						}
            	      						setWithLastConsumed(
            	      							current,
            	      							"literal",
            	      							lv_literal_3_0,
            	      							"org.eclipse.xtext.common.Terminals.STRING");
            	      					
            	    }

            	    }


            	    }

            	    // InternalSM2.g:2560:4: (this_COMMA_4= RULE_COMMA )?
            	    int alt77=2;
            	    int LA77_0 = input.LA(1);

            	    if ( (LA77_0==RULE_COMMA) ) {
            	        alt77=1;
            	    }
            	    switch (alt77) {
            	        case 1 :
            	            // InternalSM2.g:2561:5: this_COMMA_4= RULE_COMMA
            	            {
            	            this_COMMA_4=(Token)match(input,RULE_COMMA,FOLLOW_60); if (state.failed) return current;
            	            if ( state.backtracking==0 ) {

            	              					newLeafNode(this_COMMA_4, grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_3_1());
            	              				
            	            }

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt78 >= 1 ) break loop78;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(78, input);
                        throw eee;
                }
                cnt78++;
            } while (true);

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_5, grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_4());
              		
            }
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:2575:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt79=2;
            int LA79_0 = input.LA(1);

            if ( (LA79_0==RULE_EOLINE) ) {
                alt79=1;
            }
            switch (alt79) {
                case 1 :
                    // InternalSM2.g:2576:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleArray"
    // InternalSM2.g:2585:1: entryRuleArray returns [String current=null] : iv_ruleArray= ruleArray EOF ;
    public final String entryRuleArray() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleArray = null;


        try {
            // InternalSM2.g:2585:45: (iv_ruleArray= ruleArray EOF )
            // InternalSM2.g:2586:2: iv_ruleArray= ruleArray EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArrayRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArray=ruleArray();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArray.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArray"


    // $ANTLR start "ruleArray"
    // InternalSM2.g:2592:1: ruleArray returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )* ) ;
    public final AntlrDatatypeRuleToken ruleArray() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_SINGLENUMBER_2=null;
        Token this_INTEGER_3=null;
        Token this_SINGLENUMBER_7=null;
        Token this_INTEGER_8=null;


        	enterRule();

        try {
            // InternalSM2.g:2598:2: ( ( (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )* ) )
            // InternalSM2.g:2599:2: ( (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )* )
            {
            // InternalSM2.g:2599:2: ( (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )* )
            // InternalSM2.g:2600:3: (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )*
            {
            // InternalSM2.g:2600:3: (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) )
            int alt80=3;
            switch ( input.LA(1) ) {
            case 77:
                {
                alt80=1;
                }
                break;
            case 78:
                {
                alt80=2;
                }
                break;
            case RULE_INTEGER:
                {
                alt80=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 80, 0, input);

                throw nvae;
            }

            switch (alt80) {
                case 1 :
                    // InternalSM2.g:2601:4: kw= '[]'
                    {
                    kw=(Token)match(input,77,FOLLOW_61); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current.merge(kw);
                      				newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_0_0());
                      			
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2607:4: (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER )
                    {
                    // InternalSM2.g:2607:4: (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER )
                    // InternalSM2.g:2608:5: kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER
                    {
                    kw=(Token)match(input,78,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					current.merge(kw);
                      					newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_0_1_0());
                      				
                    }
                    this_SINGLENUMBER_2=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_61); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					current.merge(this_SINGLENUMBER_2);
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_SINGLENUMBER_2, grammarAccess.getArrayAccess().getSINGLENUMBERTerminalRuleCall_0_1_1());
                      				
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2622:4: (this_INTEGER_3= RULE_INTEGER kw= ']' )
                    {
                    // InternalSM2.g:2622:4: (this_INTEGER_3= RULE_INTEGER kw= ']' )
                    // InternalSM2.g:2623:5: this_INTEGER_3= RULE_INTEGER kw= ']'
                    {
                    this_INTEGER_3=(Token)match(input,RULE_INTEGER,FOLLOW_62); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					current.merge(this_INTEGER_3);
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_INTEGER_3, grammarAccess.getArrayAccess().getINTEGERTerminalRuleCall_0_2_0());
                      				
                    }
                    kw=(Token)match(input,79,FOLLOW_61); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					current.merge(kw);
                      					newLeafNode(kw, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_0_2_1());
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2637:3: (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )*
            loop81:
            do {
                int alt81=4;
                switch ( input.LA(1) ) {
                case 77:
                    {
                    alt81=1;
                    }
                    break;
                case 78:
                    {
                    alt81=2;
                    }
                    break;
                case RULE_INTEGER:
                    {
                    alt81=3;
                    }
                    break;

                }

                switch (alt81) {
            	case 1 :
            	    // InternalSM2.g:2638:4: kw= '[]'
            	    {
            	    kw=(Token)match(input,77,FOLLOW_61); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      				current.merge(kw);
            	      				newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_1_0());
            	      			
            	    }

            	    }
            	    break;
            	case 2 :
            	    // InternalSM2.g:2644:4: (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER )
            	    {
            	    // InternalSM2.g:2644:4: (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER )
            	    // InternalSM2.g:2645:5: kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER
            	    {
            	    kw=(Token)match(input,78,FOLLOW_8); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					current.merge(kw);
            	      					newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_1_1_0());
            	      				
            	    }
            	    this_SINGLENUMBER_7=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_61); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					current.merge(this_SINGLENUMBER_7);
            	      				
            	    }
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(this_SINGLENUMBER_7, grammarAccess.getArrayAccess().getSINGLENUMBERTerminalRuleCall_1_1_1());
            	      				
            	    }

            	    }


            	    }
            	    break;
            	case 3 :
            	    // InternalSM2.g:2659:4: (this_INTEGER_8= RULE_INTEGER kw= ']' )
            	    {
            	    // InternalSM2.g:2659:4: (this_INTEGER_8= RULE_INTEGER kw= ']' )
            	    // InternalSM2.g:2660:5: this_INTEGER_8= RULE_INTEGER kw= ']'
            	    {
            	    this_INTEGER_8=(Token)match(input,RULE_INTEGER,FOLLOW_62); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					current.merge(this_INTEGER_8);
            	      				
            	    }
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(this_INTEGER_8, grammarAccess.getArrayAccess().getINTEGERTerminalRuleCall_1_2_0());
            	      				
            	    }
            	    kw=(Token)match(input,79,FOLLOW_61); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					current.merge(kw);
            	      					newLeafNode(kw, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_1_2_1());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop81;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArray"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:2678:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // InternalSM2.g:2678:49: (iv_ruleProperty= ruleProperty EOF )
            // InternalSM2.g:2679:2: iv_ruleProperty= ruleProperty EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleProperty=ruleProperty();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleProperty; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:2685:1: ruleProperty returns [EObject current=null] : (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        EObject this_PropertyString_0 = null;

        EObject this_PropertyInteger_1 = null;

        EObject this_PropertyFloat_2 = null;

        EObject this_PropertyAddress_3 = null;

        EObject this_PropertyBoolean_4 = null;

        EObject this_PropertyBytes_5 = null;

        EObject this_PropertyStruct_6 = null;



        	enterRule();

        try {
            // InternalSM2.g:2691:2: ( (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct ) )
            // InternalSM2.g:2692:2: (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct )
            {
            // InternalSM2.g:2692:2: (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct )
            int alt82=7;
            switch ( input.LA(1) ) {
            case 73:
                {
                alt82=1;
                }
                break;
            case 80:
            case 81:
            case 82:
            case 83:
            case 84:
            case 85:
            case 86:
            case 87:
            case 88:
                {
                alt82=2;
                }
                break;
            case 74:
                {
                alt82=3;
                }
                break;
            case 71:
            case 90:
                {
                alt82=4;
                }
                break;
            case 89:
                {
                alt82=5;
                }
                break;
            case 91:
            case 92:
            case 93:
            case 94:
            case 95:
            case 96:
            case 97:
            case 98:
            case 99:
            case 100:
                {
                alt82=6;
                }
                break;
            case RULE_ID:
                {
                alt82=7;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 82, 0, input);

                throw nvae;
            }

            switch (alt82) {
                case 1 :
                    // InternalSM2.g:2693:3: this_PropertyString_0= rulePropertyString
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyStringParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyString_0=rulePropertyString();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyString_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2702:3: this_PropertyInteger_1= rulePropertyInteger
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyIntegerParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyInteger_1=rulePropertyInteger();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyInteger_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2711:3: this_PropertyFloat_2= rulePropertyFloat
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyFloatParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyFloat_2=rulePropertyFloat();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyFloat_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:2720:3: this_PropertyAddress_3= rulePropertyAddress
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyAddressParserRuleCall_3());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyAddress_3=rulePropertyAddress();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyAddress_3;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:2729:3: this_PropertyBoolean_4= rulePropertyBoolean
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyBooleanParserRuleCall_4());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyBoolean_4=rulePropertyBoolean();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyBoolean_4;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 6 :
                    // InternalSM2.g:2738:3: this_PropertyBytes_5= rulePropertyBytes
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyBytesParserRuleCall_5());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyBytes_5=rulePropertyBytes();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyBytes_5;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 7 :
                    // InternalSM2.g:2747:3: this_PropertyStruct_6= rulePropertyStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyStructParserRuleCall_6());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyStruct_6=rulePropertyStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyStruct_6;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRulePropertyString"
    // InternalSM2.g:2759:1: entryRulePropertyString returns [EObject current=null] : iv_rulePropertyString= rulePropertyString EOF ;
    public final EObject entryRulePropertyString() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyString = null;


        try {
            // InternalSM2.g:2759:55: (iv_rulePropertyString= rulePropertyString EOF )
            // InternalSM2.g:2760:2: iv_rulePropertyString= rulePropertyString EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyStringRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyString=rulePropertyString();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyString; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyString"


    // $ANTLR start "rulePropertyString"
    // InternalSM2.g:2766:1: rulePropertyString returns [EObject current=null] : ( ( (lv_type_0_0= 'string' ) ) (otherlv_1= '=' ( (lv_inicialization_2_0= RULE_STRING ) ) )? this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ) ;
    public final EObject rulePropertyString() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token otherlv_1=null;
        Token lv_inicialization_2_0=null;
        Token this_SEMICOLON_3=null;
        Token this_EOLINE_4=null;


        	enterRule();

        try {
            // InternalSM2.g:2772:2: ( ( ( (lv_type_0_0= 'string' ) ) (otherlv_1= '=' ( (lv_inicialization_2_0= RULE_STRING ) ) )? this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ) )
            // InternalSM2.g:2773:2: ( ( (lv_type_0_0= 'string' ) ) (otherlv_1= '=' ( (lv_inicialization_2_0= RULE_STRING ) ) )? this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? )
            {
            // InternalSM2.g:2773:2: ( ( (lv_type_0_0= 'string' ) ) (otherlv_1= '=' ( (lv_inicialization_2_0= RULE_STRING ) ) )? this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? )
            // InternalSM2.g:2774:3: ( (lv_type_0_0= 'string' ) ) (otherlv_1= '=' ( (lv_inicialization_2_0= RULE_STRING ) ) )? this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )?
            {
            // InternalSM2.g:2774:3: ( (lv_type_0_0= 'string' ) )
            // InternalSM2.g:2775:4: (lv_type_0_0= 'string' )
            {
            // InternalSM2.g:2775:4: (lv_type_0_0= 'string' )
            // InternalSM2.g:2776:5: lv_type_0_0= 'string'
            {
            lv_type_0_0=(Token)match(input,73,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_type_0_0, grammarAccess.getPropertyStringAccess().getTypeStringKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyStringRule());
              					}
              					setWithLastConsumed(current, "type", lv_type_0_0, "string");
              				
            }

            }


            }

            // InternalSM2.g:2788:3: (otherlv_1= '=' ( (lv_inicialization_2_0= RULE_STRING ) ) )?
            int alt83=2;
            int LA83_0 = input.LA(1);

            if ( (LA83_0==72) ) {
                alt83=1;
            }
            switch (alt83) {
                case 1 :
                    // InternalSM2.g:2789:4: otherlv_1= '=' ( (lv_inicialization_2_0= RULE_STRING ) )
                    {
                    otherlv_1=(Token)match(input,72,FOLLOW_50); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_1, grammarAccess.getPropertyStringAccess().getEqualsSignKeyword_1_0());
                      			
                    }
                    // InternalSM2.g:2793:4: ( (lv_inicialization_2_0= RULE_STRING ) )
                    // InternalSM2.g:2794:5: (lv_inicialization_2_0= RULE_STRING )
                    {
                    // InternalSM2.g:2794:5: (lv_inicialization_2_0= RULE_STRING )
                    // InternalSM2.g:2795:6: lv_inicialization_2_0= RULE_STRING
                    {
                    lv_inicialization_2_0=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_inicialization_2_0, grammarAccess.getPropertyStringAccess().getInicializationSTRINGTerminalRuleCall_1_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyStringRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"inicialization",
                      							lv_inicialization_2_0,
                      							"org.eclipse.xtext.common.Terminals.STRING");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_3=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_3, grammarAccess.getPropertyStringAccess().getSEMICOLONTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2816:3: (this_EOLINE_4= RULE_EOLINE )?
            int alt84=2;
            int LA84_0 = input.LA(1);

            if ( (LA84_0==RULE_EOLINE) ) {
                alt84=1;
            }
            switch (alt84) {
                case 1 :
                    // InternalSM2.g:2817:4: this_EOLINE_4= RULE_EOLINE
                    {
                    this_EOLINE_4=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_4, grammarAccess.getPropertyStringAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyString"


    // $ANTLR start "entryRulePropertyInteger"
    // InternalSM2.g:2826:1: entryRulePropertyInteger returns [EObject current=null] : iv_rulePropertyInteger= rulePropertyInteger EOF ;
    public final EObject entryRulePropertyInteger() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyInteger = null;


        try {
            // InternalSM2.g:2826:56: (iv_rulePropertyInteger= rulePropertyInteger EOF )
            // InternalSM2.g:2827:2: iv_rulePropertyInteger= rulePropertyInteger EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyIntegerRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyInteger=rulePropertyInteger();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyInteger; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyInteger"


    // $ANTLR start "rulePropertyInteger"
    // InternalSM2.g:2833:1: rulePropertyInteger returns [EObject current=null] : ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint64' | lv_type_0_9= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyInteger() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_1=null;
        Token lv_type_0_2=null;
        Token lv_type_0_3=null;
        Token lv_type_0_4=null;
        Token lv_type_0_5=null;
        Token lv_type_0_6=null;
        Token lv_type_0_7=null;
        Token lv_type_0_8=null;
        Token lv_type_0_9=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token lv_inicialization_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2839:2: ( ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint64' | lv_type_0_9= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2840:2: ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint64' | lv_type_0_9= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2840:2: ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint64' | lv_type_0_9= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2841:3: ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint64' | lv_type_0_9= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:2841:3: ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint64' | lv_type_0_9= 'uint256' ) ) )
            // InternalSM2.g:2842:4: ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint64' | lv_type_0_9= 'uint256' ) )
            {
            // InternalSM2.g:2842:4: ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint64' | lv_type_0_9= 'uint256' ) )
            // InternalSM2.g:2843:5: (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint64' | lv_type_0_9= 'uint256' )
            {
            // InternalSM2.g:2843:5: (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint32' | lv_type_0_8= 'uint64' | lv_type_0_9= 'uint256' )
            int alt85=9;
            switch ( input.LA(1) ) {
            case 80:
                {
                alt85=1;
                }
                break;
            case 81:
                {
                alt85=2;
                }
                break;
            case 82:
                {
                alt85=3;
                }
                break;
            case 83:
                {
                alt85=4;
                }
                break;
            case 84:
                {
                alt85=5;
                }
                break;
            case 85:
                {
                alt85=6;
                }
                break;
            case 86:
                {
                alt85=7;
                }
                break;
            case 87:
                {
                alt85=8;
                }
                break;
            case 88:
                {
                alt85=9;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 85, 0, input);

                throw nvae;
            }

            switch (alt85) {
                case 1 :
                    // InternalSM2.g:2844:6: lv_type_0_1= 'int'
                    {
                    lv_type_0_1=(Token)match(input,80,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_1, grammarAccess.getPropertyIntegerAccess().getTypeIntKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2855:6: lv_type_0_2= 'uint'
                    {
                    lv_type_0_2=(Token)match(input,81,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_2, grammarAccess.getPropertyIntegerAccess().getTypeUintKeyword_0_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_2, null);
                      					
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2866:6: lv_type_0_3= 'uint2'
                    {
                    lv_type_0_3=(Token)match(input,82,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_3, grammarAccess.getPropertyIntegerAccess().getTypeUint2Keyword_0_0_2());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_3, null);
                      					
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:2877:6: lv_type_0_4= 'uint4'
                    {
                    lv_type_0_4=(Token)match(input,83,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_4, grammarAccess.getPropertyIntegerAccess().getTypeUint4Keyword_0_0_3());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_4, null);
                      					
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:2888:6: lv_type_0_5= 'uint8'
                    {
                    lv_type_0_5=(Token)match(input,84,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_5, grammarAccess.getPropertyIntegerAccess().getTypeUint8Keyword_0_0_4());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_5, null);
                      					
                    }

                    }
                    break;
                case 6 :
                    // InternalSM2.g:2899:6: lv_type_0_6= 'uint16'
                    {
                    lv_type_0_6=(Token)match(input,85,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_6, grammarAccess.getPropertyIntegerAccess().getTypeUint16Keyword_0_0_5());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_6, null);
                      					
                    }

                    }
                    break;
                case 7 :
                    // InternalSM2.g:2910:6: lv_type_0_7= 'uint32'
                    {
                    lv_type_0_7=(Token)match(input,86,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_7, grammarAccess.getPropertyIntegerAccess().getTypeUint32Keyword_0_0_6());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_7, null);
                      					
                    }

                    }
                    break;
                case 8 :
                    // InternalSM2.g:2921:6: lv_type_0_8= 'uint64'
                    {
                    lv_type_0_8=(Token)match(input,87,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_8, grammarAccess.getPropertyIntegerAccess().getTypeUint64Keyword_0_0_7());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_8, null);
                      					
                    }

                    }
                    break;
                case 9 :
                    // InternalSM2.g:2932:6: lv_type_0_9= 'uint256'
                    {
                    lv_type_0_9=(Token)match(input,88,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_9, grammarAccess.getPropertyIntegerAccess().getTypeUint256Keyword_0_0_8());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_9, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:2945:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt86=2;
            int LA86_0 = input.LA(1);

            if ( (LA86_0==RULE_INTEGER||(LA86_0>=77 && LA86_0<=78)) ) {
                alt86=1;
            }
            switch (alt86) {
                case 1 :
                    // InternalSM2.g:2946:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:2946:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:2947:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyIntegerAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_43);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyIntegerRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2964:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt87=2;
            int LA87_0 = input.LA(1);

            if ( ((LA87_0>=63 && LA87_0<=64)||(LA87_0>=118 && LA87_0<=119)) ) {
                alt87=1;
            }
            switch (alt87) {
                case 1 :
                    // InternalSM2.g:2965:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:2965:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:2966:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyIntegerAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_12);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyIntegerRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2983:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:2984:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:2984:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:2985:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_64); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyIntegerAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyIntegerRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            otherlv_4=(Token)match(input,72,FOLLOW_65); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getPropertyIntegerAccess().getEqualsSignKeyword_4());
              		
            }
            // InternalSM2.g:3005:3: ( (lv_inicialization_5_0= RULE_INTEGER ) )?
            int alt88=2;
            int LA88_0 = input.LA(1);

            if ( (LA88_0==RULE_INTEGER) ) {
                alt88=1;
            }
            switch (alt88) {
                case 1 :
                    // InternalSM2.g:3006:4: (lv_inicialization_5_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:3006:4: (lv_inicialization_5_0= RULE_INTEGER )
                    // InternalSM2.g:3007:5: lv_inicialization_5_0= RULE_INTEGER
                    {
                    lv_inicialization_5_0=(Token)match(input,RULE_INTEGER,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_inicialization_5_0, grammarAccess.getPropertyIntegerAccess().getInicializationINTEGERTerminalRuleCall_5_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"inicialization",
                      						lv_inicialization_5_0,
                      						"org.xtext.SM2.INTEGER");
                      				
                    }

                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyIntegerAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:3027:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt89=2;
            int LA89_0 = input.LA(1);

            if ( (LA89_0==RULE_EOLINE) ) {
                alt89=1;
            }
            switch (alt89) {
                case 1 :
                    // InternalSM2.g:3028:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyIntegerAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyInteger"


    // $ANTLR start "entryRulePropertyFloat"
    // InternalSM2.g:3037:1: entryRulePropertyFloat returns [EObject current=null] : iv_rulePropertyFloat= rulePropertyFloat EOF ;
    public final EObject entryRulePropertyFloat() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyFloat = null;


        try {
            // InternalSM2.g:3037:54: (iv_rulePropertyFloat= rulePropertyFloat EOF )
            // InternalSM2.g:3038:2: iv_rulePropertyFloat= rulePropertyFloat EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyFloatRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyFloat=rulePropertyFloat();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyFloat; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyFloat"


    // $ANTLR start "rulePropertyFloat"
    // InternalSM2.g:3044:1: rulePropertyFloat returns [EObject current=null] : ( ( (lv_type_0_0= 'float' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyFloat() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token lv_inicialization_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3050:2: ( ( ( (lv_type_0_0= 'float' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:3051:2: ( ( (lv_type_0_0= 'float' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:3051:2: ( ( (lv_type_0_0= 'float' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:3052:3: ( (lv_type_0_0= 'float' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:3052:3: ( (lv_type_0_0= 'float' ) )
            // InternalSM2.g:3053:4: (lv_type_0_0= 'float' )
            {
            // InternalSM2.g:3053:4: (lv_type_0_0= 'float' )
            // InternalSM2.g:3054:5: lv_type_0_0= 'float'
            {
            lv_type_0_0=(Token)match(input,74,FOLLOW_63); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_type_0_0, grammarAccess.getPropertyFloatAccess().getTypeFloatKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyFloatRule());
              					}
              					setWithLastConsumed(current, "type", lv_type_0_0, "float");
              				
            }

            }


            }

            // InternalSM2.g:3066:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt90=2;
            int LA90_0 = input.LA(1);

            if ( (LA90_0==RULE_INTEGER||(LA90_0>=77 && LA90_0<=78)) ) {
                alt90=1;
            }
            switch (alt90) {
                case 1 :
                    // InternalSM2.g:3067:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3067:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3068:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyFloatAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_43);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyFloatRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3085:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt91=2;
            int LA91_0 = input.LA(1);

            if ( ((LA91_0>=63 && LA91_0<=64)||(LA91_0>=118 && LA91_0<=119)) ) {
                alt91=1;
            }
            switch (alt91) {
                case 1 :
                    // InternalSM2.g:3086:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3086:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3087:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyFloatAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_12);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyFloatRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3104:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:3105:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:3105:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:3106:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyFloatAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyFloatRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3122:3: (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) ) )?
            int alt92=2;
            int LA92_0 = input.LA(1);

            if ( (LA92_0==72) ) {
                alt92=1;
            }
            switch (alt92) {
                case 1 :
                    // InternalSM2.g:3123:4: otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) )
                    {
                    otherlv_4=(Token)match(input,72,FOLLOW_66); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyFloatAccess().getEqualsSignKeyword_4_0());
                      			
                    }
                    // InternalSM2.g:3127:4: ( (lv_inicialization_5_0= RULE_FLOAT ) )
                    // InternalSM2.g:3128:5: (lv_inicialization_5_0= RULE_FLOAT )
                    {
                    // InternalSM2.g:3128:5: (lv_inicialization_5_0= RULE_FLOAT )
                    // InternalSM2.g:3129:6: lv_inicialization_5_0= RULE_FLOAT
                    {
                    lv_inicialization_5_0=(Token)match(input,RULE_FLOAT,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_inicialization_5_0, grammarAccess.getPropertyFloatAccess().getInicializationFLOATTerminalRuleCall_4_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyFloatRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"inicialization",
                      							lv_inicialization_5_0,
                      							"org.xtext.SM2.FLOAT");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyFloatAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:3150:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt93=2;
            int LA93_0 = input.LA(1);

            if ( (LA93_0==RULE_EOLINE) ) {
                alt93=1;
            }
            switch (alt93) {
                case 1 :
                    // InternalSM2.g:3151:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyFloatAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyFloat"


    // $ANTLR start "entryRulePropertyBoolean"
    // InternalSM2.g:3160:1: entryRulePropertyBoolean returns [EObject current=null] : iv_rulePropertyBoolean= rulePropertyBoolean EOF ;
    public final EObject entryRulePropertyBoolean() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyBoolean = null;


        try {
            // InternalSM2.g:3160:56: (iv_rulePropertyBoolean= rulePropertyBoolean EOF )
            // InternalSM2.g:3161:2: iv_rulePropertyBoolean= rulePropertyBoolean EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyBooleanRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyBoolean=rulePropertyBoolean();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyBoolean; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyBoolean"


    // $ANTLR start "rulePropertyBoolean"
    // InternalSM2.g:3167:1: rulePropertyBoolean returns [EObject current=null] : ( ( (lv_type_0_0= 'bool' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyBoolean() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token lv_inicialization_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3173:2: ( ( ( (lv_type_0_0= 'bool' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:3174:2: ( ( (lv_type_0_0= 'bool' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:3174:2: ( ( (lv_type_0_0= 'bool' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:3175:3: ( (lv_type_0_0= 'bool' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:3175:3: ( (lv_type_0_0= 'bool' ) )
            // InternalSM2.g:3176:4: (lv_type_0_0= 'bool' )
            {
            // InternalSM2.g:3176:4: (lv_type_0_0= 'bool' )
            // InternalSM2.g:3177:5: lv_type_0_0= 'bool'
            {
            lv_type_0_0=(Token)match(input,89,FOLLOW_63); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_type_0_0, grammarAccess.getPropertyBooleanAccess().getTypeBoolKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyBooleanRule());
              					}
              					setWithLastConsumed(current, "type", lv_type_0_0, "bool");
              				
            }

            }


            }

            // InternalSM2.g:3189:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt94=2;
            int LA94_0 = input.LA(1);

            if ( (LA94_0==RULE_INTEGER||(LA94_0>=77 && LA94_0<=78)) ) {
                alt94=1;
            }
            switch (alt94) {
                case 1 :
                    // InternalSM2.g:3190:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3190:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3191:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBooleanAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_43);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBooleanRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3208:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt95=2;
            int LA95_0 = input.LA(1);

            if ( ((LA95_0>=63 && LA95_0<=64)||(LA95_0>=118 && LA95_0<=119)) ) {
                alt95=1;
            }
            switch (alt95) {
                case 1 :
                    // InternalSM2.g:3209:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3209:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3210:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBooleanAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_12);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBooleanRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3227:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:3228:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:3228:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:3229:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyBooleanAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyBooleanRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3245:3: (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) ) )?
            int alt96=2;
            int LA96_0 = input.LA(1);

            if ( (LA96_0==72) ) {
                alt96=1;
            }
            switch (alt96) {
                case 1 :
                    // InternalSM2.g:3246:4: otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) )
                    {
                    otherlv_4=(Token)match(input,72,FOLLOW_67); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyBooleanAccess().getEqualsSignKeyword_4_0());
                      			
                    }
                    // InternalSM2.g:3250:4: ( (lv_inicialization_5_0= RULE_BOOLVALUE ) )
                    // InternalSM2.g:3251:5: (lv_inicialization_5_0= RULE_BOOLVALUE )
                    {
                    // InternalSM2.g:3251:5: (lv_inicialization_5_0= RULE_BOOLVALUE )
                    // InternalSM2.g:3252:6: lv_inicialization_5_0= RULE_BOOLVALUE
                    {
                    lv_inicialization_5_0=(Token)match(input,RULE_BOOLVALUE,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_inicialization_5_0, grammarAccess.getPropertyBooleanAccess().getInicializationBOOLVALUETerminalRuleCall_4_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBooleanRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"inicialization",
                      							lv_inicialization_5_0,
                      							"org.xtext.SM2.BOOLVALUE");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyBooleanAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:3273:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt97=2;
            int LA97_0 = input.LA(1);

            if ( (LA97_0==RULE_EOLINE) ) {
                alt97=1;
            }
            switch (alt97) {
                case 1 :
                    // InternalSM2.g:3274:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyBooleanAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyBoolean"


    // $ANTLR start "entryRulePropertyAddress"
    // InternalSM2.g:3283:1: entryRulePropertyAddress returns [EObject current=null] : iv_rulePropertyAddress= rulePropertyAddress EOF ;
    public final EObject entryRulePropertyAddress() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyAddress = null;


        try {
            // InternalSM2.g:3283:56: (iv_rulePropertyAddress= rulePropertyAddress EOF )
            // InternalSM2.g:3284:2: iv_rulePropertyAddress= rulePropertyAddress EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyAddressRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyAddress=rulePropertyAddress();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyAddress; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyAddress"


    // $ANTLR start "rulePropertyAddress"
    // InternalSM2.g:3290:1: rulePropertyAddress returns [EObject current=null] : ( ( ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyAddress() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_1=null;
        Token lv_type_0_2=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;

        EObject lv_inicialization_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3296:2: ( ( ( ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:3297:2: ( ( ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:3297:2: ( ( ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:3298:3: ( ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:3298:3: ( ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) ) )
            // InternalSM2.g:3299:4: ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) )
            {
            // InternalSM2.g:3299:4: ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) )
            // InternalSM2.g:3300:5: (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' )
            {
            // InternalSM2.g:3300:5: (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' )
            int alt98=2;
            int LA98_0 = input.LA(1);

            if ( (LA98_0==71) ) {
                alt98=1;
            }
            else if ( (LA98_0==90) ) {
                alt98=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 98, 0, input);

                throw nvae;
            }
            switch (alt98) {
                case 1 :
                    // InternalSM2.g:3301:6: lv_type_0_1= 'address'
                    {
                    lv_type_0_1=(Token)match(input,71,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_1, grammarAccess.getPropertyAddressAccess().getTypeAddressKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyAddressRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3312:6: lv_type_0_2= 'address payable'
                    {
                    lv_type_0_2=(Token)match(input,90,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_2, grammarAccess.getPropertyAddressAccess().getTypeAddressPayableKeyword_0_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyAddressRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_2, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:3325:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt99=2;
            int LA99_0 = input.LA(1);

            if ( (LA99_0==RULE_INTEGER||(LA99_0>=77 && LA99_0<=78)) ) {
                alt99=1;
            }
            switch (alt99) {
                case 1 :
                    // InternalSM2.g:3326:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3326:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3327:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyAddressAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_43);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3344:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt100=2;
            int LA100_0 = input.LA(1);

            if ( ((LA100_0>=63 && LA100_0<=64)||(LA100_0>=118 && LA100_0<=119)) ) {
                alt100=1;
            }
            switch (alt100) {
                case 1 :
                    // InternalSM2.g:3345:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3345:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3346:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyAddressAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_12);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3363:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:3364:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:3364:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:3365:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyAddressAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyAddressRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3381:3: (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )?
            int alt101=2;
            int LA101_0 = input.LA(1);

            if ( (LA101_0==72) ) {
                alt101=1;
            }
            switch (alt101) {
                case 1 :
                    // InternalSM2.g:3382:4: otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    {
                    otherlv_4=(Token)match(input,72,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyAddressAccess().getEqualsSignKeyword_4_0());
                      			
                    }
                    // InternalSM2.g:3386:4: ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    // InternalSM2.g:3387:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    {
                    // InternalSM2.g:3387:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    // InternalSM2.g:3388:6: lv_inicialization_5_0= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getPropertyAddressAccess().getInicializationSyntaxExpressionParserRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_5);
                    lv_inicialization_5_0=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                      						}
                      						set(
                      							current,
                      							"inicialization",
                      							lv_inicialization_5_0,
                      							"org.xtext.SM2.SyntaxExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyAddressAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:3410:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt102=2;
            int LA102_0 = input.LA(1);

            if ( (LA102_0==RULE_EOLINE) ) {
                alt102=1;
            }
            switch (alt102) {
                case 1 :
                    // InternalSM2.g:3411:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyAddressAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyAddress"


    // $ANTLR start "entryRulePropertyBytes"
    // InternalSM2.g:3420:1: entryRulePropertyBytes returns [EObject current=null] : iv_rulePropertyBytes= rulePropertyBytes EOF ;
    public final EObject entryRulePropertyBytes() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyBytes = null;


        try {
            // InternalSM2.g:3420:54: (iv_rulePropertyBytes= rulePropertyBytes EOF )
            // InternalSM2.g:3421:2: iv_rulePropertyBytes= rulePropertyBytes EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyBytesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyBytes=rulePropertyBytes();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyBytes; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyBytes"


    // $ANTLR start "rulePropertyBytes"
    // InternalSM2.g:3427:1: rulePropertyBytes returns [EObject current=null] : ( ( ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyBytes() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_1=null;
        Token lv_type_0_2=null;
        Token lv_type_0_3=null;
        Token lv_type_0_4=null;
        Token lv_type_0_5=null;
        Token lv_type_0_6=null;
        Token lv_type_0_7=null;
        Token lv_type_0_8=null;
        Token lv_type_0_9=null;
        Token lv_type_0_10=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;

        EObject lv_inicialization_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3433:2: ( ( ( ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:3434:2: ( ( ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:3434:2: ( ( ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:3435:3: ( ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:3435:3: ( ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) ) )
            // InternalSM2.g:3436:4: ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) )
            {
            // InternalSM2.g:3436:4: ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) )
            // InternalSM2.g:3437:5: (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' )
            {
            // InternalSM2.g:3437:5: (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' )
            int alt103=10;
            switch ( input.LA(1) ) {
            case 91:
                {
                alt103=1;
                }
                break;
            case 92:
                {
                alt103=2;
                }
                break;
            case 93:
                {
                alt103=3;
                }
                break;
            case 94:
                {
                alt103=4;
                }
                break;
            case 95:
                {
                alt103=5;
                }
                break;
            case 96:
                {
                alt103=6;
                }
                break;
            case 97:
                {
                alt103=7;
                }
                break;
            case 98:
                {
                alt103=8;
                }
                break;
            case 99:
                {
                alt103=9;
                }
                break;
            case 100:
                {
                alt103=10;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 103, 0, input);

                throw nvae;
            }

            switch (alt103) {
                case 1 :
                    // InternalSM2.g:3438:6: lv_type_0_1= 'bytes'
                    {
                    lv_type_0_1=(Token)match(input,91,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_1, grammarAccess.getPropertyBytesAccess().getTypeBytesKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3449:6: lv_type_0_2= 'bytes2'
                    {
                    lv_type_0_2=(Token)match(input,92,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_2, grammarAccess.getPropertyBytesAccess().getTypeBytes2Keyword_0_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_2, null);
                      					
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:3460:6: lv_type_0_3= 'bytes3'
                    {
                    lv_type_0_3=(Token)match(input,93,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_3, grammarAccess.getPropertyBytesAccess().getTypeBytes3Keyword_0_0_2());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_3, null);
                      					
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:3471:6: lv_type_0_4= 'bytes4'
                    {
                    lv_type_0_4=(Token)match(input,94,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_4, grammarAccess.getPropertyBytesAccess().getTypeBytes4Keyword_0_0_3());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_4, null);
                      					
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:3482:6: lv_type_0_5= 'bytes5'
                    {
                    lv_type_0_5=(Token)match(input,95,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_5, grammarAccess.getPropertyBytesAccess().getTypeBytes5Keyword_0_0_4());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_5, null);
                      					
                    }

                    }
                    break;
                case 6 :
                    // InternalSM2.g:3493:6: lv_type_0_6= 'bytes6'
                    {
                    lv_type_0_6=(Token)match(input,96,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_6, grammarAccess.getPropertyBytesAccess().getTypeBytes6Keyword_0_0_5());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_6, null);
                      					
                    }

                    }
                    break;
                case 7 :
                    // InternalSM2.g:3504:6: lv_type_0_7= 'bytes7'
                    {
                    lv_type_0_7=(Token)match(input,97,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_7, grammarAccess.getPropertyBytesAccess().getTypeBytes7Keyword_0_0_6());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_7, null);
                      					
                    }

                    }
                    break;
                case 8 :
                    // InternalSM2.g:3515:6: lv_type_0_8= 'bytes8'
                    {
                    lv_type_0_8=(Token)match(input,98,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_8, grammarAccess.getPropertyBytesAccess().getTypeBytes8Keyword_0_0_7());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_8, null);
                      					
                    }

                    }
                    break;
                case 9 :
                    // InternalSM2.g:3526:6: lv_type_0_9= 'bytes16'
                    {
                    lv_type_0_9=(Token)match(input,99,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_9, grammarAccess.getPropertyBytesAccess().getTypeBytes16Keyword_0_0_8());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_9, null);
                      					
                    }

                    }
                    break;
                case 10 :
                    // InternalSM2.g:3537:6: lv_type_0_10= 'bytes32'
                    {
                    lv_type_0_10=(Token)match(input,100,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_10, grammarAccess.getPropertyBytesAccess().getTypeBytes32Keyword_0_0_9());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_10, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:3550:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt104=2;
            int LA104_0 = input.LA(1);

            if ( (LA104_0==RULE_INTEGER||(LA104_0>=77 && LA104_0<=78)) ) {
                alt104=1;
            }
            switch (alt104) {
                case 1 :
                    // InternalSM2.g:3551:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3551:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3552:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBytesAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_43);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3569:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt105=2;
            int LA105_0 = input.LA(1);

            if ( ((LA105_0>=63 && LA105_0<=64)||(LA105_0>=118 && LA105_0<=119)) ) {
                alt105=1;
            }
            switch (alt105) {
                case 1 :
                    // InternalSM2.g:3570:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3570:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3571:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBytesAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_12);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3588:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:3589:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:3589:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:3590:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyBytesAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyBytesRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3606:3: (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )?
            int alt106=2;
            int LA106_0 = input.LA(1);

            if ( (LA106_0==72) ) {
                alt106=1;
            }
            switch (alt106) {
                case 1 :
                    // InternalSM2.g:3607:4: otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    {
                    otherlv_4=(Token)match(input,72,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyBytesAccess().getEqualsSignKeyword_4_0());
                      			
                    }
                    // InternalSM2.g:3611:4: ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    // InternalSM2.g:3612:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    {
                    // InternalSM2.g:3612:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    // InternalSM2.g:3613:6: lv_inicialization_5_0= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getPropertyBytesAccess().getInicializationSyntaxExpressionParserRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_5);
                    lv_inicialization_5_0=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                      						}
                      						set(
                      							current,
                      							"inicialization",
                      							lv_inicialization_5_0,
                      							"org.xtext.SM2.SyntaxExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyBytesAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:3635:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt107=2;
            int LA107_0 = input.LA(1);

            if ( (LA107_0==RULE_EOLINE) ) {
                alt107=1;
            }
            switch (alt107) {
                case 1 :
                    // InternalSM2.g:3636:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyBytesAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyBytes"


    // $ANTLR start "entryRulePropertyStruct"
    // InternalSM2.g:3645:1: entryRulePropertyStruct returns [EObject current=null] : iv_rulePropertyStruct= rulePropertyStruct EOF ;
    public final EObject entryRulePropertyStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyStruct = null;


        try {
            // InternalSM2.g:3645:55: (iv_rulePropertyStruct= rulePropertyStruct EOF )
            // InternalSM2.g:3646:2: iv_rulePropertyStruct= rulePropertyStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyStruct=rulePropertyStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyStruct"


    // $ANTLR start "rulePropertyStruct"
    // InternalSM2.g:3652:1: rulePropertyStruct returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;

        EObject lv_inicialization_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3658:2: ( ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:3659:2: ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:3659:2: ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:3660:3: ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:3660:3: ( (otherlv_0= RULE_ID ) )
            // InternalSM2.g:3661:4: (otherlv_0= RULE_ID )
            {
            // InternalSM2.g:3661:4: (otherlv_0= RULE_ID )
            // InternalSM2.g:3662:5: otherlv_0= RULE_ID
            {
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyStructRule());
              					}
              				
            }
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_63); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(otherlv_0, grammarAccess.getPropertyStructAccess().getAssignedStructStructCrossReference_0_0());
              				
            }

            }


            }

            // InternalSM2.g:3673:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt108=2;
            int LA108_0 = input.LA(1);

            if ( (LA108_0==RULE_INTEGER||(LA108_0>=77 && LA108_0<=78)) ) {
                alt108=1;
            }
            switch (alt108) {
                case 1 :
                    // InternalSM2.g:3674:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3674:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3675:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyStructAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_43);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyStructRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3692:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt109=2;
            int LA109_0 = input.LA(1);

            if ( ((LA109_0>=63 && LA109_0<=64)||(LA109_0>=118 && LA109_0<=119)) ) {
                alt109=1;
            }
            switch (alt109) {
                case 1 :
                    // InternalSM2.g:3693:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3693:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3694:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyStructAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_12);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyStructRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3711:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:3712:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:3712:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:3713:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyStructAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyStructRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3729:3: (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )?
            int alt110=2;
            int LA110_0 = input.LA(1);

            if ( (LA110_0==72) ) {
                alt110=1;
            }
            switch (alt110) {
                case 1 :
                    // InternalSM2.g:3730:4: otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    {
                    otherlv_4=(Token)match(input,72,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyStructAccess().getEqualsSignKeyword_4_0());
                      			
                    }
                    // InternalSM2.g:3734:4: ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    // InternalSM2.g:3735:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    {
                    // InternalSM2.g:3735:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    // InternalSM2.g:3736:6: lv_inicialization_5_0= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getPropertyStructAccess().getInicializationSyntaxExpressionParserRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_5);
                    lv_inicialization_5_0=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getPropertyStructRule());
                      						}
                      						set(
                      							current,
                      							"inicialization",
                      							lv_inicialization_5_0,
                      							"org.xtext.SM2.SyntaxExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyStructAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:3758:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt111=2;
            int LA111_0 = input.LA(1);

            if ( (LA111_0==RULE_EOLINE) ) {
                alt111=1;
            }
            switch (alt111) {
                case 1 :
                    // InternalSM2.g:3759:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyStructAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyStruct"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:3768:1: entryRuleInputParam returns [EObject current=null] : iv_ruleInputParam= ruleInputParam EOF ;
    public final EObject entryRuleInputParam() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputParam = null;


        try {
            // InternalSM2.g:3768:51: (iv_ruleInputParam= ruleInputParam EOF )
            // InternalSM2.g:3769:2: iv_ruleInputParam= ruleInputParam EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getInputParamRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleInputParam=ruleInputParam();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleInputParam; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:3775:1: ruleInputParam returns [EObject current=null] : ( ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )? ) ;
    public final EObject ruleInputParam() throws RecognitionException {
        EObject current = null;

        Token lv_storage_2_0=null;
        Token otherlv_3=null;
        Token lv_nameParam_4_0=null;
        Token this_COMMA_5=null;
        Enumerator lv_type_0_0 = null;

        AntlrDatatypeRuleToken lv_isArray_1_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3781:2: ( ( ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )? ) )
            // InternalSM2.g:3782:2: ( ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )? )
            {
            // InternalSM2.g:3782:2: ( ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )? )
            // InternalSM2.g:3783:3: ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )?
            {
            // InternalSM2.g:3783:3: ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) )
            // InternalSM2.g:3784:4: ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) )
            {
            // InternalSM2.g:3784:4: ( (lv_type_0_0= ruleBasicType ) )
            // InternalSM2.g:3785:5: (lv_type_0_0= ruleBasicType )
            {
            // InternalSM2.g:3785:5: (lv_type_0_0= ruleBasicType )
            // InternalSM2.g:3786:6: lv_type_0_0= ruleBasicType
            {
            if ( state.backtracking==0 ) {

              						newCompositeNode(grammarAccess.getInputParamAccess().getTypeBasicTypeEnumRuleCall_0_0_0());
              					
            }
            pushFollow(FOLLOW_68);
            lv_type_0_0=ruleBasicType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElementForParent(grammarAccess.getInputParamRule());
              						}
              						set(
              							current,
              							"type",
              							lv_type_0_0,
              							"org.xtext.SM2.BasicType");
              						afterParserOrEnumRuleCall();
              					
            }

            }


            }

            // InternalSM2.g:3803:4: ( (lv_isArray_1_0= ruleArray ) )?
            int alt112=2;
            int LA112_0 = input.LA(1);

            if ( (LA112_0==RULE_INTEGER||(LA112_0>=77 && LA112_0<=78)) ) {
                alt112=1;
            }
            switch (alt112) {
                case 1 :
                    // InternalSM2.g:3804:5: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3804:5: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3805:6: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getInputParamAccess().getIsArrayArrayParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_69);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getInputParamRule());
                      						}
                      						set(
                      							current,
                      							"isArray",
                      							lv_isArray_1_0,
                      							"org.xtext.SM2.Array");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3822:4: ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )?
            int alt113=3;
            int LA113_0 = input.LA(1);

            if ( (LA113_0==101) ) {
                alt113=1;
            }
            else if ( (LA113_0==102) ) {
                alt113=2;
            }
            switch (alt113) {
                case 1 :
                    // InternalSM2.g:3823:5: ( (lv_storage_2_0= 'memory' ) )
                    {
                    // InternalSM2.g:3823:5: ( (lv_storage_2_0= 'memory' ) )
                    // InternalSM2.g:3824:6: (lv_storage_2_0= 'memory' )
                    {
                    // InternalSM2.g:3824:6: (lv_storage_2_0= 'memory' )
                    // InternalSM2.g:3825:7: lv_storage_2_0= 'memory'
                    {
                    lv_storage_2_0=(Token)match(input,101,FOLLOW_12); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_storage_2_0, grammarAccess.getInputParamAccess().getStorageMemoryKeyword_0_2_0_0());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getInputParamRule());
                      							}
                      							setWithLastConsumed(current, "storage", lv_storage_2_0, "memory");
                      						
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3838:5: otherlv_3= 'local'
                    {
                    otherlv_3=(Token)match(input,102,FOLLOW_12); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_3, grammarAccess.getInputParamAccess().getLocalKeyword_0_2_1());
                      				
                    }

                    }
                    break;

            }

            // InternalSM2.g:3843:4: ( (lv_nameParam_4_0= RULE_ID ) )
            // InternalSM2.g:3844:5: (lv_nameParam_4_0= RULE_ID )
            {
            // InternalSM2.g:3844:5: (lv_nameParam_4_0= RULE_ID )
            // InternalSM2.g:3845:6: lv_nameParam_4_0= RULE_ID
            {
            lv_nameParam_4_0=(Token)match(input,RULE_ID,FOLLOW_70); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						newLeafNode(lv_nameParam_4_0, grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_3_0());
              					
            }
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElement(grammarAccess.getInputParamRule());
              						}
              						setWithLastConsumed(
              							current,
              							"nameParam",
              							lv_nameParam_4_0,
              							"org.eclipse.xtext.common.Terminals.ID");
              					
            }

            }


            }


            }

            // InternalSM2.g:3862:3: (this_COMMA_5= RULE_COMMA )?
            int alt114=2;
            int LA114_0 = input.LA(1);

            if ( (LA114_0==RULE_COMMA) ) {
                alt114=1;
            }
            switch (alt114) {
                case 1 :
                    // InternalSM2.g:3863:4: this_COMMA_5= RULE_COMMA
                    {
                    this_COMMA_5=(Token)match(input,RULE_COMMA,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_COMMA_5, grammarAccess.getInputParamAccess().getCOMMATerminalRuleCall_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:3872:1: entryRuleRestriction returns [EObject current=null] : iv_ruleRestriction= ruleRestriction EOF ;
    public final EObject entryRuleRestriction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestriction = null;


        try {
            // InternalSM2.g:3872:52: (iv_ruleRestriction= ruleRestriction EOF )
            // InternalSM2.g:3873:2: iv_ruleRestriction= ruleRestriction EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRestrictionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRestriction=ruleRestriction();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRestriction; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:3879:1: ruleRestriction returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) ;
    public final EObject ruleRestriction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        EObject lv_expr1_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        EObject lv_expr2_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3885:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) )
            // InternalSM2.g:3886:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            {
            // InternalSM2.g:3886:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            // InternalSM2.g:3887:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,103,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getRestrictionAccess().getRequireKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:3895:3: ( (lv_expr1_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:3896:4: (lv_expr1_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:3896:4: (lv_expr1_2_0= ruleSyntaxExpression )
            // InternalSM2.g:3897:5: lv_expr1_2_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr1SyntaxExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_71);
            lv_expr1_2_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"expr1",
              						lv_expr1_2_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3914:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:3915:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:3915:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:3916:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_27);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3933:3: ( (lv_expr2_4_0= ruleSyntaxExpression ) )
            // InternalSM2.g:3934:4: (lv_expr2_4_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:3934:4: (lv_expr2_4_0= ruleSyntaxExpression )
            // InternalSM2.g:3935:5: lv_expr2_4_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr2SyntaxExpressionParserRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_28);
            lv_expr2_4_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"expr2",
              						lv_expr2_4_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_7, grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:3968:1: entryRuleRestrictionGas returns [EObject current=null] : iv_ruleRestrictionGas= ruleRestrictionGas EOF ;
    public final EObject entryRuleRestrictionGas() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionGas = null;


        try {
            // InternalSM2.g:3968:55: (iv_ruleRestrictionGas= ruleRestrictionGas EOF )
            // InternalSM2.g:3969:2: iv_ruleRestrictionGas= ruleRestrictionGas EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRestrictionGasRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionGas=ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRestrictionGas; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:3975:1: ruleRestrictionGas returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE ) ;
    public final EObject ruleRestrictionGas() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_amount_4_0=null;
        Token this_FLOAT_5=null;
        Token this_CLOSEPARENTHESIS_7=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        EObject lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        Enumerator lv_typeCoin_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3981:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE ) )
            // InternalSM2.g:3982:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )
            {
            // InternalSM2.g:3982:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )
            // InternalSM2.g:3983:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,103,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getRestrictionGasAccess().getRequireKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:3991:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:3992:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:3992:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2.g:3993:5: lv_expr_2_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_71);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_2_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4010:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:4011:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:4011:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:4012:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_57);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4029:3: ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT )
            int alt115=2;
            int LA115_0 = input.LA(1);

            if ( (LA115_0==RULE_INTEGER) ) {
                alt115=1;
            }
            else if ( (LA115_0==RULE_FLOAT) ) {
                alt115=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 115, 0, input);

                throw nvae;
            }
            switch (alt115) {
                case 1 :
                    // InternalSM2.g:4030:4: ( (lv_amount_4_0= RULE_INTEGER ) )
                    {
                    // InternalSM2.g:4030:4: ( (lv_amount_4_0= RULE_INTEGER ) )
                    // InternalSM2.g:4031:5: (lv_amount_4_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:4031:5: (lv_amount_4_0= RULE_INTEGER )
                    // InternalSM2.g:4032:6: lv_amount_4_0= RULE_INTEGER
                    {
                    lv_amount_4_0=(Token)match(input,RULE_INTEGER,FOLLOW_72); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_amount_4_0, grammarAccess.getRestrictionGasAccess().getAmountINTEGERTerminalRuleCall_4_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getRestrictionGasRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"amount",
                      							lv_amount_4_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4049:4: this_FLOAT_5= RULE_FLOAT
                    {
                    this_FLOAT_5=(Token)match(input,RULE_FLOAT,FOLLOW_72); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_FLOAT_5, grammarAccess.getRestrictionGasAccess().getFLOATTerminalRuleCall_4_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:4054:3: ( (lv_typeCoin_6_0= ruleCoin ) )
            // InternalSM2.g:4055:4: (lv_typeCoin_6_0= ruleCoin )
            {
            // InternalSM2.g:4055:4: (lv_typeCoin_6_0= ruleCoin )
            // InternalSM2.g:4056:5: lv_typeCoin_6_0= ruleCoin
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0());
              				
            }
            pushFollow(FOLLOW_28);
            lv_typeCoin_6_0=ruleCoin();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"typeCoin",
              						lv_typeCoin_6_0,
              						"org.xtext.SM2.Coin");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_7=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_7, grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }
            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_9, grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleFunction"
    // InternalSM2.g:4089:1: entryRuleFunction returns [EObject current=null] : iv_ruleFunction= ruleFunction EOF ;
    public final EObject entryRuleFunction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFunction = null;


        try {
            // InternalSM2.g:4089:49: (iv_ruleFunction= ruleFunction EOF )
            // InternalSM2.g:4090:2: iv_ruleFunction= ruleFunction EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getFunctionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleFunction=ruleFunction();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleFunction; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFunction"


    // $ANTLR start "ruleFunction"
    // InternalSM2.g:4096:1: ruleFunction returns [EObject current=null] : (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions ) ;
    public final EObject ruleFunction() throws RecognitionException {
        EObject current = null;

        EObject this_PredefinedFunctions_0 = null;

        EObject this_PersonalizedFunctions_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:4102:2: ( (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions ) )
            // InternalSM2.g:4103:2: (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions )
            {
            // InternalSM2.g:4103:2: (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions )
            int alt116=2;
            int LA116_0 = input.LA(1);

            if ( (LA116_0==105) ) {
                alt116=1;
            }
            else if ( (LA116_0==RULE_ID) ) {
                alt116=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 116, 0, input);

                throw nvae;
            }
            switch (alt116) {
                case 1 :
                    // InternalSM2.g:4104:3: this_PredefinedFunctions_0= rulePredefinedFunctions
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getFunctionAccess().getPredefinedFunctionsParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PredefinedFunctions_0=rulePredefinedFunctions();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PredefinedFunctions_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4113:3: this_PersonalizedFunctions_1= rulePersonalizedFunctions
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getFunctionAccess().getPersonalizedFunctionsParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PersonalizedFunctions_1=rulePersonalizedFunctions();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PersonalizedFunctions_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFunction"


    // $ANTLR start "entryRulePredefinedFunctions"
    // InternalSM2.g:4125:1: entryRulePredefinedFunctions returns [EObject current=null] : iv_rulePredefinedFunctions= rulePredefinedFunctions EOF ;
    public final EObject entryRulePredefinedFunctions() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePredefinedFunctions = null;


        try {
            // InternalSM2.g:4125:60: (iv_rulePredefinedFunctions= rulePredefinedFunctions EOF )
            // InternalSM2.g:4126:2: iv_rulePredefinedFunctions= rulePredefinedFunctions EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPredefinedFunctionsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePredefinedFunctions=rulePredefinedFunctions();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePredefinedFunctions; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePredefinedFunctions"


    // $ANTLR start "rulePredefinedFunctions"
    // InternalSM2.g:4132:1: rulePredefinedFunctions returns [EObject current=null] : this_Kill_0= ruleKill ;
    public final EObject rulePredefinedFunctions() throws RecognitionException {
        EObject current = null;

        EObject this_Kill_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4138:2: (this_Kill_0= ruleKill )
            // InternalSM2.g:4139:2: this_Kill_0= ruleKill
            {
            if ( state.backtracking==0 ) {

              		newCompositeNode(grammarAccess.getPredefinedFunctionsAccess().getKillParserRuleCall());
              	
            }
            pushFollow(FOLLOW_2);
            this_Kill_0=ruleKill();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current = this_Kill_0;
              		afterParserOrEnumRuleCall();
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePredefinedFunctions"


    // $ANTLR start "entryRulePersonalizedFunctions"
    // InternalSM2.g:4150:1: entryRulePersonalizedFunctions returns [EObject current=null] : iv_rulePersonalizedFunctions= rulePersonalizedFunctions EOF ;
    public final EObject entryRulePersonalizedFunctions() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonalizedFunctions = null;


        try {
            // InternalSM2.g:4150:62: (iv_rulePersonalizedFunctions= rulePersonalizedFunctions EOF )
            // InternalSM2.g:4151:2: iv_rulePersonalizedFunctions= rulePersonalizedFunctions EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPersonalizedFunctionsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePersonalizedFunctions=rulePersonalizedFunctions();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePersonalizedFunctions; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonalizedFunctions"


    // $ANTLR start "rulePersonalizedFunctions"
    // InternalSM2.g:4157:1: rulePersonalizedFunctions returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE ) ;
    public final EObject rulePersonalizedFunctions() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_ispayable_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_EOLINE_9=null;
        Token this_CLOSEKEY_10=null;
        Token this_EOLINE_11=null;
        EObject lv_restriction_4_0 = null;

        EObject lv_restrictionGas_5_0 = null;

        EObject lv_localAttributes_6_0 = null;

        EObject lv_conditions_7_0 = null;

        EObject lv_expression_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4163:2: ( ( ( (otherlv_0= RULE_ID ) ) ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE ) )
            // InternalSM2.g:4164:2: ( ( (otherlv_0= RULE_ID ) ) ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE )
            {
            // InternalSM2.g:4164:2: ( ( (otherlv_0= RULE_ID ) ) ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE )
            // InternalSM2.g:4165:3: ( (otherlv_0= RULE_ID ) ) ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE
            {
            // InternalSM2.g:4165:3: ( (otherlv_0= RULE_ID ) )
            // InternalSM2.g:4166:4: (otherlv_0= RULE_ID )
            {
            // InternalSM2.g:4166:4: (otherlv_0= RULE_ID )
            // InternalSM2.g:4167:5: otherlv_0= RULE_ID
            {
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPersonalizedFunctionsRule());
              					}
              				
            }
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_73); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(otherlv_0, grammarAccess.getPersonalizedFunctionsAccess().getHeadHeadClauseCrossReference_0_0());
              				
            }

            }


            }

            // InternalSM2.g:4178:3: ( (lv_ispayable_1_0= 'payable' ) )?
            int alt117=2;
            int LA117_0 = input.LA(1);

            if ( (LA117_0==104) ) {
                alt117=1;
            }
            switch (alt117) {
                case 1 :
                    // InternalSM2.g:4179:4: (lv_ispayable_1_0= 'payable' )
                    {
                    // InternalSM2.g:4179:4: (lv_ispayable_1_0= 'payable' )
                    // InternalSM2.g:4180:5: lv_ispayable_1_0= 'payable'
                    {
                    lv_ispayable_1_0=(Token)match(input,104,FOLLOW_15); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_ispayable_1_0, grammarAccess.getPersonalizedFunctionsAccess().getIspayablePayableKeyword_1_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					setWithLastConsumed(current, "ispayable", lv_ispayable_1_0, "payable");
                      				
                    }

                    }


                    }
                    break;

            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getPersonalizedFunctionsAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_74); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_3, grammarAccess.getPersonalizedFunctionsAccess().getEOLINETerminalRuleCall_3());
              		
            }
            // InternalSM2.g:4200:3: ( (lv_restriction_4_0= ruleRestriction ) )?
            int alt118=2;
            alt118 = dfa118.predict(input);
            switch (alt118) {
                case 1 :
                    // InternalSM2.g:4201:4: (lv_restriction_4_0= ruleRestriction )
                    {
                    // InternalSM2.g:4201:4: (lv_restriction_4_0= ruleRestriction )
                    // InternalSM2.g:4202:5: lv_restriction_4_0= ruleRestriction
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getRestrictionRestrictionParserRuleCall_4_0());
                      				
                    }
                    pushFollow(FOLLOW_74);
                    lv_restriction_4_0=ruleRestriction();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"restriction",
                      						lv_restriction_4_0,
                      						"org.xtext.SM2.Restriction");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:4219:3: ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )?
            int alt119=2;
            int LA119_0 = input.LA(1);

            if ( (LA119_0==103) ) {
                alt119=1;
            }
            switch (alt119) {
                case 1 :
                    // InternalSM2.g:4220:4: (lv_restrictionGas_5_0= ruleRestrictionGas )
                    {
                    // InternalSM2.g:4220:4: (lv_restrictionGas_5_0= ruleRestrictionGas )
                    // InternalSM2.g:4221:5: lv_restrictionGas_5_0= ruleRestrictionGas
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getRestrictionGasRestrictionGasParserRuleCall_5_0());
                      				
                    }
                    pushFollow(FOLLOW_75);
                    lv_restrictionGas_5_0=ruleRestrictionGas();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"restrictionGas",
                      						lv_restrictionGas_5_0,
                      						"org.xtext.SM2.RestrictionGas");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:4238:3: ( (lv_localAttributes_6_0= ruleAttributes ) )?
            int alt120=2;
            int LA120_0 = input.LA(1);

            if ( (LA120_0==68||(LA120_0>=70 && LA120_0<=71)||(LA120_0>=73 && LA120_0<=74)||LA120_0==76||(LA120_0>=80 && LA120_0<=100)) ) {
                alt120=1;
            }
            else if ( (LA120_0==RULE_ID) ) {
                int LA120_2 = input.LA(2);

                if ( ((LA120_2>=RULE_INTEGER && LA120_2<=RULE_ID)||(LA120_2>=63 && LA120_2<=64)||(LA120_2>=77 && LA120_2<=78)||(LA120_2>=118 && LA120_2<=119)) ) {
                    alt120=1;
                }
            }
            switch (alt120) {
                case 1 :
                    // InternalSM2.g:4239:4: (lv_localAttributes_6_0= ruleAttributes )
                    {
                    // InternalSM2.g:4239:4: (lv_localAttributes_6_0= ruleAttributes )
                    // InternalSM2.g:4240:5: lv_localAttributes_6_0= ruleAttributes
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getLocalAttributesAttributesParserRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_37);
                    lv_localAttributes_6_0=ruleAttributes();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"localAttributes",
                      						lv_localAttributes_6_0,
                      						"org.xtext.SM2.Attributes");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:4257:3: ( (lv_conditions_7_0= ruleConditional ) )?
            int alt121=2;
            int LA121_0 = input.LA(1);

            if ( (LA121_0==RULE_IF) ) {
                alt121=1;
            }
            switch (alt121) {
                case 1 :
                    // InternalSM2.g:4258:4: (lv_conditions_7_0= ruleConditional )
                    {
                    // InternalSM2.g:4258:4: (lv_conditions_7_0= ruleConditional )
                    // InternalSM2.g:4259:5: lv_conditions_7_0= ruleConditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getConditionsConditionalParserRuleCall_7_0());
                      				
                    }
                    pushFollow(FOLLOW_37);
                    lv_conditions_7_0=ruleConditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"conditions",
                      						lv_conditions_7_0,
                      						"org.xtext.SM2.Conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:4276:3: ( (lv_expression_8_0= ruleExpression ) )+
            int cnt122=0;
            loop122:
            do {
                int alt122=2;
                int LA122_0 = input.LA(1);

                if ( ((LA122_0>=RULE_INTEGER && LA122_0<=RULE_ID)||LA122_0==RULE_OPENPARENTHESIS||LA122_0==RULE_STRING||LA122_0==RULE_FLOAT||LA122_0==45||LA122_0==51||(LA122_0>=58 && LA122_0<=59)||LA122_0==115) ) {
                    alt122=1;
                }


                switch (alt122) {
            	case 1 :
            	    // InternalSM2.g:4277:4: (lv_expression_8_0= ruleExpression )
            	    {
            	    // InternalSM2.g:4277:4: (lv_expression_8_0= ruleExpression )
            	    // InternalSM2.g:4278:5: lv_expression_8_0= ruleExpression
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getExpressionExpressionParserRuleCall_8_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_76);
            	    lv_expression_8_0=ruleExpression();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
            	      					}
            	      					add(
            	      						current,
            	      						"expression",
            	      						lv_expression_8_0,
            	      						"org.xtext.SM2.Expression");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt122 >= 1 ) break loop122;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(122, input);
                        throw eee;
                }
                cnt122++;
            } while (true);

            // InternalSM2.g:4295:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt123=2;
            int LA123_0 = input.LA(1);

            if ( (LA123_0==RULE_EOLINE) ) {
                alt123=1;
            }
            switch (alt123) {
                case 1 :
                    // InternalSM2.g:4296:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getPersonalizedFunctionsAccess().getEOLINETerminalRuleCall_9());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_10=(Token)match(input,RULE_CLOSEKEY,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_10, grammarAccess.getPersonalizedFunctionsAccess().getCLOSEKEYTerminalRuleCall_10());
              		
            }
            this_EOLINE_11=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_11, grammarAccess.getPersonalizedFunctionsAccess().getEOLINETerminalRuleCall_11());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonalizedFunctions"


    // $ANTLR start "entryRuleKill"
    // InternalSM2.g:4313:1: entryRuleKill returns [EObject current=null] : iv_ruleKill= ruleKill EOF ;
    public final EObject entryRuleKill() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleKill = null;


        try {
            // InternalSM2.g:4313:45: (iv_ruleKill= ruleKill EOF )
            // InternalSM2.g:4314:2: iv_ruleKill= ruleKill EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getKillRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleKill=ruleKill();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleKill; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleKill"


    // $ANTLR start "ruleKill"
    // InternalSM2.g:4320:1: ruleKill returns [EObject current=null] : (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY ) ;
    public final EObject ruleKill() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token otherlv_3=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_IF_6=null;
        Token this_OPENPARENTHESIS_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token this_CLOSEPARENTHESIS_12=null;
        Token otherlv_13=null;
        Token this_OPENPARENTHESIS_14=null;
        Token this_CLOSEPARENTHESIS_16=null;
        Token this_SEMICOLON_17=null;
        Token this_EOLINE_18=null;
        Token this_CLOSEKEY_19=null;
        EObject lv_addressValueCondition_10_0 = null;

        EObject this_InputParam_11 = null;

        EObject lv_addressValue_15_1 = null;

        EObject lv_addressValue_15_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:4326:2: ( (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY ) )
            // InternalSM2.g:4327:2: (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY )
            {
            // InternalSM2.g:4327:2: (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY )
            // InternalSM2.g:4328:3: otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,105,FOLLOW_77); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getKillAccess().getFunctionKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,106,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getKillAccess().getKillKeyword_1());
              		
            }
            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_78); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getKillAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:4340:3: ( (otherlv_3= RULE_ID ) )?
            int alt124=2;
            int LA124_0 = input.LA(1);

            if ( (LA124_0==RULE_ID) ) {
                alt124=1;
            }
            switch (alt124) {
                case 1 :
                    // InternalSM2.g:4341:4: (otherlv_3= RULE_ID )
                    {
                    // InternalSM2.g:4341:4: (otherlv_3= RULE_ID )
                    // InternalSM2.g:4342:5: otherlv_3= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getKillRule());
                      					}
                      				
                    }
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_3, grammarAccess.getKillAccess().getInputParamInputParamCrossReference_3_0());
                      				
                    }

                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getKillAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_79); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getKillAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            this_IF_6=(Token)match(input,RULE_IF,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_IF_6, grammarAccess.getKillAccess().getIFTerminalRuleCall_6());
              		
            }
            this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_80); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getKillAccess().getOPENPARENTHESISTerminalRuleCall_7());
              		
            }
            otherlv_8=(Token)match(input,107,FOLLOW_81); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_8, grammarAccess.getKillAccess().getMsgSenderKeyword_8());
              		
            }
            otherlv_9=(Token)match(input,108,FOLLOW_82); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_9, grammarAccess.getKillAccess().getEqualsSignEqualsSignKeyword_9());
              		
            }
            // InternalSM2.g:4377:3: ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam )
            int alt125=2;
            int LA125_0 = input.LA(1);

            if ( ((LA125_0>=RULE_INTEGER && LA125_0<=RULE_ID)||LA125_0==RULE_OPENPARENTHESIS||LA125_0==RULE_STRING||LA125_0==RULE_FLOAT||LA125_0==45||LA125_0==51||(LA125_0>=58 && LA125_0<=59)||LA125_0==115) ) {
                alt125=1;
            }
            else if ( (LA125_0==71||LA125_0==73||(LA125_0>=80 && LA125_0<=90)||(LA125_0>=92 && LA125_0<=98)||LA125_0==100||(LA125_0>=137 && LA125_0<=139)) ) {
                alt125=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 125, 0, input);

                throw nvae;
            }
            switch (alt125) {
                case 1 :
                    // InternalSM2.g:4378:4: ( (lv_addressValueCondition_10_0= ruleExpression ) )
                    {
                    // InternalSM2.g:4378:4: ( (lv_addressValueCondition_10_0= ruleExpression ) )
                    // InternalSM2.g:4379:5: (lv_addressValueCondition_10_0= ruleExpression )
                    {
                    // InternalSM2.g:4379:5: (lv_addressValueCondition_10_0= ruleExpression )
                    // InternalSM2.g:4380:6: lv_addressValueCondition_10_0= ruleExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getKillAccess().getAddressValueConditionExpressionParserRuleCall_10_0_0());
                      					
                    }
                    pushFollow(FOLLOW_28);
                    lv_addressValueCondition_10_0=ruleExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getKillRule());
                      						}
                      						set(
                      							current,
                      							"addressValueCondition",
                      							lv_addressValueCondition_10_0,
                      							"org.xtext.SM2.Expression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4398:4: this_InputParam_11= ruleInputParam
                    {
                    if ( state.backtracking==0 ) {

                      				newCompositeNode(grammarAccess.getKillAccess().getInputParamParserRuleCall_10_1());
                      			
                    }
                    pushFollow(FOLLOW_28);
                    this_InputParam_11=ruleInputParam();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = this_InputParam_11;
                      				afterParserOrEnumRuleCall();
                      			
                    }

                    }
                    break;

            }

            this_CLOSEPARENTHESIS_12=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_83); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_12, grammarAccess.getKillAccess().getCLOSEPARENTHESISTerminalRuleCall_11());
              		
            }
            otherlv_13=(Token)match(input,109,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_13, grammarAccess.getKillAccess().getSelfdestructKeyword_12());
              		
            }
            this_OPENPARENTHESIS_14=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_82); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_14, grammarAccess.getKillAccess().getOPENPARENTHESISTerminalRuleCall_13());
              		
            }
            // InternalSM2.g:4419:3: ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) )
            // InternalSM2.g:4420:4: ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) )
            {
            // InternalSM2.g:4420:4: ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) )
            // InternalSM2.g:4421:5: (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam )
            {
            // InternalSM2.g:4421:5: (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam )
            int alt126=2;
            int LA126_0 = input.LA(1);

            if ( ((LA126_0>=RULE_INTEGER && LA126_0<=RULE_ID)||LA126_0==RULE_OPENPARENTHESIS||LA126_0==RULE_STRING||LA126_0==RULE_FLOAT||LA126_0==45||LA126_0==51||(LA126_0>=58 && LA126_0<=59)||LA126_0==115) ) {
                alt126=1;
            }
            else if ( (LA126_0==71||LA126_0==73||(LA126_0>=80 && LA126_0<=90)||(LA126_0>=92 && LA126_0<=98)||LA126_0==100||(LA126_0>=137 && LA126_0<=139)) ) {
                alt126=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 126, 0, input);

                throw nvae;
            }
            switch (alt126) {
                case 1 :
                    // InternalSM2.g:4422:6: lv_addressValue_15_1= ruleExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getKillAccess().getAddressValueExpressionParserRuleCall_14_0_0());
                      					
                    }
                    pushFollow(FOLLOW_28);
                    lv_addressValue_15_1=ruleExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getKillRule());
                      						}
                      						set(
                      							current,
                      							"addressValue",
                      							lv_addressValue_15_1,
                      							"org.xtext.SM2.Expression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4438:6: lv_addressValue_15_2= ruleInputParam
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getKillAccess().getAddressValueInputParamParserRuleCall_14_0_1());
                      					
                    }
                    pushFollow(FOLLOW_28);
                    lv_addressValue_15_2=ruleInputParam();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getKillRule());
                      						}
                      						set(
                      							current,
                      							"addressValue",
                      							lv_addressValue_15_2,
                      							"org.xtext.SM2.InputParam");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }
                    break;

            }


            }


            }

            this_CLOSEPARENTHESIS_16=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_16, grammarAccess.getKillAccess().getCLOSEPARENTHESISTerminalRuleCall_15());
              		
            }
            this_SEMICOLON_17=(Token)match(input,RULE_SEMICOLON,FOLLOW_58); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_17, grammarAccess.getKillAccess().getSEMICOLONTerminalRuleCall_16());
              		
            }
            // InternalSM2.g:4464:3: (this_EOLINE_18= RULE_EOLINE )?
            int alt127=2;
            int LA127_0 = input.LA(1);

            if ( (LA127_0==RULE_EOLINE) ) {
                alt127=1;
            }
            switch (alt127) {
                case 1 :
                    // InternalSM2.g:4465:4: this_EOLINE_18= RULE_EOLINE
                    {
                    this_EOLINE_18=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_18, grammarAccess.getKillAccess().getEOLINETerminalRuleCall_17());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_19=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_19, grammarAccess.getKillAccess().getCLOSEKEYTerminalRuleCall_18());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleKill"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:4478:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // InternalSM2.g:4478:51: (iv_ruleExpression= ruleExpression EOF )
            // InternalSM2.g:4479:2: iv_ruleExpression= ruleExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:4485:1: ruleExpression returns [EObject current=null] : (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables | this_LogicalExpression_5= ruleLogicalExpression ) ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_ArithmethicalExpression_0 = null;

        EObject this_ArithmethicalLogicalExpression_1 = null;

        EObject this_SyntaxExpression_2 = null;

        EObject this_TimeExpression_3 = null;

        EObject this_Variables_4 = null;

        EObject this_LogicalExpression_5 = null;



        	enterRule();

        try {
            // InternalSM2.g:4491:2: ( (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables | this_LogicalExpression_5= ruleLogicalExpression ) )
            // InternalSM2.g:4492:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables | this_LogicalExpression_5= ruleLogicalExpression )
            {
            // InternalSM2.g:4492:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables | this_LogicalExpression_5= ruleLogicalExpression )
            int alt128=6;
            alt128 = dfa128.predict(input);
            switch (alt128) {
                case 1 :
                    // InternalSM2.g:4493:3: this_ArithmethicalExpression_0= ruleArithmethicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalExpression_0=ruleArithmethicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ArithmethicalExpression_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4502:3: this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalLogicalExpressionParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalLogicalExpression_1=ruleArithmethicalLogicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ArithmethicalLogicalExpression_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:4511:3: this_SyntaxExpression_2= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_SyntaxExpression_2=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_SyntaxExpression_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:4520:3: this_TimeExpression_3= ruleTimeExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getTimeExpressionParserRuleCall_3());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_TimeExpression_3=ruleTimeExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_TimeExpression_3;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:4529:3: this_Variables_4= ruleVariables
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getVariablesParserRuleCall_4());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Variables_4=ruleVariables();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Variables_4;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 6 :
                    // InternalSM2.g:4538:3: this_LogicalExpression_5= ruleLogicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getLogicalExpressionParserRuleCall_5());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_LogicalExpression_5=ruleLogicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_LogicalExpression_5;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleLogicalExpression"
    // InternalSM2.g:4550:1: entryRuleLogicalExpression returns [EObject current=null] : iv_ruleLogicalExpression= ruleLogicalExpression EOF ;
    public final EObject entryRuleLogicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLogicalExpression = null;


        try {
            // InternalSM2.g:4550:58: (iv_ruleLogicalExpression= ruleLogicalExpression EOF )
            // InternalSM2.g:4551:2: iv_ruleLogicalExpression= ruleLogicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLogicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLogicalExpression=ruleLogicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLogicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLogicalExpression"


    // $ANTLR start "ruleLogicalExpression"
    // InternalSM2.g:4557:1: ruleLogicalExpression returns [EObject current=null] : ( ( (lv_operator_0_0= ruleLogicalUnaryOperator ) ) ( ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) ) ) ) ;
    public final EObject ruleLogicalExpression() throws RecognitionException {
        EObject current = null;

        EObject lv_operator_0_0 = null;

        EObject lv_expr1_1_1 = null;

        EObject lv_expr1_1_2 = null;

        EObject lv_expr1_1_3 = null;



        	enterRule();

        try {
            // InternalSM2.g:4563:2: ( ( ( (lv_operator_0_0= ruleLogicalUnaryOperator ) ) ( ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) ) ) ) )
            // InternalSM2.g:4564:2: ( ( (lv_operator_0_0= ruleLogicalUnaryOperator ) ) ( ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) ) ) )
            {
            // InternalSM2.g:4564:2: ( ( (lv_operator_0_0= ruleLogicalUnaryOperator ) ) ( ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) ) ) )
            // InternalSM2.g:4565:3: ( (lv_operator_0_0= ruleLogicalUnaryOperator ) ) ( ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) ) )
            {
            // InternalSM2.g:4565:3: ( (lv_operator_0_0= ruleLogicalUnaryOperator ) )
            // InternalSM2.g:4566:4: (lv_operator_0_0= ruleLogicalUnaryOperator )
            {
            // InternalSM2.g:4566:4: (lv_operator_0_0= ruleLogicalUnaryOperator )
            // InternalSM2.g:4567:5: lv_operator_0_0= ruleLogicalUnaryOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getLogicalExpressionAccess().getOperatorLogicalUnaryOperatorParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_84);
            lv_operator_0_0=ruleLogicalUnaryOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getLogicalExpressionRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_0_0,
              						"org.xtext.SM2.LogicalUnaryOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4584:3: ( ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) ) )
            // InternalSM2.g:4585:4: ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) )
            {
            // InternalSM2.g:4585:4: ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) )
            // InternalSM2.g:4586:5: (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression )
            {
            // InternalSM2.g:4586:5: (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression )
            int alt129=3;
            alt129 = dfa129.predict(input);
            switch (alt129) {
                case 1 :
                    // InternalSM2.g:4587:6: lv_expr1_1_1= ruleArithmethicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getLogicalExpressionAccess().getExpr1ArithmethicalExpressionParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_expr1_1_1=ruleArithmethicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getLogicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"expr1",
                      							lv_expr1_1_1,
                      							"org.xtext.SM2.ArithmethicalExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4603:6: lv_expr1_1_2= ruleArithmethicalLogicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getLogicalExpressionAccess().getExpr1ArithmethicalLogicalExpressionParserRuleCall_1_0_1());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_expr1_1_2=ruleArithmethicalLogicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getLogicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"expr1",
                      							lv_expr1_1_2,
                      							"org.xtext.SM2.ArithmethicalLogicalExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:4619:6: lv_expr1_1_3= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getLogicalExpressionAccess().getExpr1SyntaxExpressionParserRuleCall_1_0_2());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_expr1_1_3=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getLogicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"expr1",
                      							lv_expr1_1_3,
                      							"org.xtext.SM2.SyntaxExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }
                    break;

            }


            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalExpression"


    // $ANTLR start "entryRuleArithmethicalExpression"
    // InternalSM2.g:4641:1: entryRuleArithmethicalExpression returns [EObject current=null] : iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF ;
    public final EObject entryRuleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalExpression = null;


        try {
            // InternalSM2.g:4641:64: (iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF )
            // InternalSM2.g:4642:2: iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmethicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalExpression=ruleArithmethicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArithmethicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalExpression"


    // $ANTLR start "ruleArithmethicalExpression"
    // InternalSM2.g:4648:1: ruleArithmethicalExpression returns [EObject current=null] : ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_9_0= RULE_INTEGER ) ) | this_FLOAT_10= RULE_FLOAT | this_ID_11= RULE_ID ) ( (lv_operator_12_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_13_0= RULE_INTEGER ) ) | this_FLOAT_14= RULE_FLOAT | this_ID_15= RULE_ID ) (this_SEMICOLON_16= RULE_SEMICOLON this_EOLINE_17= RULE_EOLINE )? ) ) ;
    public final EObject ruleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token lv_op1_1_0=null;
        Token this_FLOAT_2=null;
        Token this_ID_3=null;
        Token lv_op2_5_0=null;
        Token this_FLOAT_6=null;
        Token this_ID_7=null;
        Token this_CLOSEPARENTHESIS_8=null;
        Token lv_op1_9_0=null;
        Token this_FLOAT_10=null;
        Token this_ID_11=null;
        Token lv_op2_13_0=null;
        Token this_FLOAT_14=null;
        Token this_ID_15=null;
        Token this_SEMICOLON_16=null;
        Token this_EOLINE_17=null;
        Enumerator lv_operator_4_0 = null;

        Enumerator lv_operator_12_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4654:2: ( ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_9_0= RULE_INTEGER ) ) | this_FLOAT_10= RULE_FLOAT | this_ID_11= RULE_ID ) ( (lv_operator_12_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_13_0= RULE_INTEGER ) ) | this_FLOAT_14= RULE_FLOAT | this_ID_15= RULE_ID ) (this_SEMICOLON_16= RULE_SEMICOLON this_EOLINE_17= RULE_EOLINE )? ) ) )
            // InternalSM2.g:4655:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_9_0= RULE_INTEGER ) ) | this_FLOAT_10= RULE_FLOAT | this_ID_11= RULE_ID ) ( (lv_operator_12_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_13_0= RULE_INTEGER ) ) | this_FLOAT_14= RULE_FLOAT | this_ID_15= RULE_ID ) (this_SEMICOLON_16= RULE_SEMICOLON this_EOLINE_17= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:4655:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_9_0= RULE_INTEGER ) ) | this_FLOAT_10= RULE_FLOAT | this_ID_11= RULE_ID ) ( (lv_operator_12_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_13_0= RULE_INTEGER ) ) | this_FLOAT_14= RULE_FLOAT | this_ID_15= RULE_ID ) (this_SEMICOLON_16= RULE_SEMICOLON this_EOLINE_17= RULE_EOLINE )? ) )
            int alt135=2;
            int LA135_0 = input.LA(1);

            if ( (LA135_0==RULE_OPENPARENTHESIS) ) {
                alt135=1;
            }
            else if ( ((LA135_0>=RULE_INTEGER && LA135_0<=RULE_ID)||LA135_0==RULE_FLOAT) ) {
                alt135=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 135, 0, input);

                throw nvae;
            }
            switch (alt135) {
                case 1 :
                    // InternalSM2.g:4656:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:4656:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:4657:4: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS
                    {
                    this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_85); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0());
                      			
                    }
                    // InternalSM2.g:4661:4: ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID )
                    int alt130=3;
                    switch ( input.LA(1) ) {
                    case RULE_INTEGER:
                        {
                        alt130=1;
                        }
                        break;
                    case RULE_FLOAT:
                        {
                        alt130=2;
                        }
                        break;
                    case RULE_ID:
                        {
                        alt130=3;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 130, 0, input);

                        throw nvae;
                    }

                    switch (alt130) {
                        case 1 :
                            // InternalSM2.g:4662:5: ( (lv_op1_1_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4662:5: ( (lv_op1_1_0= RULE_INTEGER ) )
                            // InternalSM2.g:4663:6: (lv_op1_1_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4663:6: (lv_op1_1_0= RULE_INTEGER )
                            // InternalSM2.g:4664:7: lv_op1_1_0= RULE_INTEGER
                            {
                            lv_op1_1_0=(Token)match(input,RULE_INTEGER,FOLLOW_86); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op1_1_0, grammarAccess.getArithmethicalExpressionAccess().getOp1INTEGERTerminalRuleCall_0_1_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op1",
                              								lv_op1_1_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4681:5: this_FLOAT_2= RULE_FLOAT
                            {
                            this_FLOAT_2=(Token)match(input,RULE_FLOAT,FOLLOW_86); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_2, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_0_1_1());
                              				
                            }

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:4686:5: this_ID_3= RULE_ID
                            {
                            this_ID_3=(Token)match(input,RULE_ID,FOLLOW_86); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_ID_3, grammarAccess.getArithmethicalExpressionAccess().getIDTerminalRuleCall_0_1_2());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:4691:4: ( (lv_operator_4_0= ruleArithmeticalOperator ) )
                    // InternalSM2.g:4692:5: (lv_operator_4_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2.g:4692:5: (lv_operator_4_0= ruleArithmeticalOperator )
                    // InternalSM2.g:4693:6: lv_operator_4_0= ruleArithmeticalOperator
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0());
                      					
                    }
                    pushFollow(FOLLOW_85);
                    lv_operator_4_0=ruleArithmeticalOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"operator",
                      							lv_operator_4_0,
                      							"org.xtext.SM2.ArithmeticalOperator");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:4710:4: ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID )
                    int alt131=3;
                    switch ( input.LA(1) ) {
                    case RULE_INTEGER:
                        {
                        alt131=1;
                        }
                        break;
                    case RULE_FLOAT:
                        {
                        alt131=2;
                        }
                        break;
                    case RULE_ID:
                        {
                        alt131=3;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 131, 0, input);

                        throw nvae;
                    }

                    switch (alt131) {
                        case 1 :
                            // InternalSM2.g:4711:5: ( (lv_op2_5_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4711:5: ( (lv_op2_5_0= RULE_INTEGER ) )
                            // InternalSM2.g:4712:6: (lv_op2_5_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4712:6: (lv_op2_5_0= RULE_INTEGER )
                            // InternalSM2.g:4713:7: lv_op2_5_0= RULE_INTEGER
                            {
                            lv_op2_5_0=(Token)match(input,RULE_INTEGER,FOLLOW_28); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op2_5_0, grammarAccess.getArithmethicalExpressionAccess().getOp2INTEGERTerminalRuleCall_0_3_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op2",
                              								lv_op2_5_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4730:5: this_FLOAT_6= RULE_FLOAT
                            {
                            this_FLOAT_6=(Token)match(input,RULE_FLOAT,FOLLOW_28); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_6, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_0_3_1());
                              				
                            }

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:4735:5: this_ID_7= RULE_ID
                            {
                            this_ID_7=(Token)match(input,RULE_ID,FOLLOW_28); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_ID_7, grammarAccess.getArithmethicalExpressionAccess().getIDTerminalRuleCall_0_3_2());
                              				
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_8=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_CLOSEPARENTHESIS_8, grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4746:3: ( ( ( (lv_op1_9_0= RULE_INTEGER ) ) | this_FLOAT_10= RULE_FLOAT | this_ID_11= RULE_ID ) ( (lv_operator_12_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_13_0= RULE_INTEGER ) ) | this_FLOAT_14= RULE_FLOAT | this_ID_15= RULE_ID ) (this_SEMICOLON_16= RULE_SEMICOLON this_EOLINE_17= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:4746:3: ( ( ( (lv_op1_9_0= RULE_INTEGER ) ) | this_FLOAT_10= RULE_FLOAT | this_ID_11= RULE_ID ) ( (lv_operator_12_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_13_0= RULE_INTEGER ) ) | this_FLOAT_14= RULE_FLOAT | this_ID_15= RULE_ID ) (this_SEMICOLON_16= RULE_SEMICOLON this_EOLINE_17= RULE_EOLINE )? )
                    // InternalSM2.g:4747:4: ( ( (lv_op1_9_0= RULE_INTEGER ) ) | this_FLOAT_10= RULE_FLOAT | this_ID_11= RULE_ID ) ( (lv_operator_12_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_13_0= RULE_INTEGER ) ) | this_FLOAT_14= RULE_FLOAT | this_ID_15= RULE_ID ) (this_SEMICOLON_16= RULE_SEMICOLON this_EOLINE_17= RULE_EOLINE )?
                    {
                    // InternalSM2.g:4747:4: ( ( (lv_op1_9_0= RULE_INTEGER ) ) | this_FLOAT_10= RULE_FLOAT | this_ID_11= RULE_ID )
                    int alt132=3;
                    switch ( input.LA(1) ) {
                    case RULE_INTEGER:
                        {
                        alt132=1;
                        }
                        break;
                    case RULE_FLOAT:
                        {
                        alt132=2;
                        }
                        break;
                    case RULE_ID:
                        {
                        alt132=3;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 132, 0, input);

                        throw nvae;
                    }

                    switch (alt132) {
                        case 1 :
                            // InternalSM2.g:4748:5: ( (lv_op1_9_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4748:5: ( (lv_op1_9_0= RULE_INTEGER ) )
                            // InternalSM2.g:4749:6: (lv_op1_9_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4749:6: (lv_op1_9_0= RULE_INTEGER )
                            // InternalSM2.g:4750:7: lv_op1_9_0= RULE_INTEGER
                            {
                            lv_op1_9_0=(Token)match(input,RULE_INTEGER,FOLLOW_86); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op1_9_0, grammarAccess.getArithmethicalExpressionAccess().getOp1INTEGERTerminalRuleCall_1_0_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op1",
                              								lv_op1_9_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4767:5: this_FLOAT_10= RULE_FLOAT
                            {
                            this_FLOAT_10=(Token)match(input,RULE_FLOAT,FOLLOW_86); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_10, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_1_0_1());
                              				
                            }

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:4772:5: this_ID_11= RULE_ID
                            {
                            this_ID_11=(Token)match(input,RULE_ID,FOLLOW_86); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_ID_11, grammarAccess.getArithmethicalExpressionAccess().getIDTerminalRuleCall_1_0_2());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:4777:4: ( (lv_operator_12_0= ruleArithmeticalOperator ) )
                    // InternalSM2.g:4778:5: (lv_operator_12_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2.g:4778:5: (lv_operator_12_0= ruleArithmeticalOperator )
                    // InternalSM2.g:4779:6: lv_operator_12_0= ruleArithmeticalOperator
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_85);
                    lv_operator_12_0=ruleArithmeticalOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"operator",
                      							lv_operator_12_0,
                      							"org.xtext.SM2.ArithmeticalOperator");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:4796:4: ( ( (lv_op2_13_0= RULE_INTEGER ) ) | this_FLOAT_14= RULE_FLOAT | this_ID_15= RULE_ID )
                    int alt133=3;
                    switch ( input.LA(1) ) {
                    case RULE_INTEGER:
                        {
                        alt133=1;
                        }
                        break;
                    case RULE_FLOAT:
                        {
                        alt133=2;
                        }
                        break;
                    case RULE_ID:
                        {
                        alt133=3;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 133, 0, input);

                        throw nvae;
                    }

                    switch (alt133) {
                        case 1 :
                            // InternalSM2.g:4797:5: ( (lv_op2_13_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4797:5: ( (lv_op2_13_0= RULE_INTEGER ) )
                            // InternalSM2.g:4798:6: (lv_op2_13_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4798:6: (lv_op2_13_0= RULE_INTEGER )
                            // InternalSM2.g:4799:7: lv_op2_13_0= RULE_INTEGER
                            {
                            lv_op2_13_0=(Token)match(input,RULE_INTEGER,FOLLOW_29); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op2_13_0, grammarAccess.getArithmethicalExpressionAccess().getOp2INTEGERTerminalRuleCall_1_2_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op2",
                              								lv_op2_13_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4816:5: this_FLOAT_14= RULE_FLOAT
                            {
                            this_FLOAT_14=(Token)match(input,RULE_FLOAT,FOLLOW_29); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_14, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_1_2_1());
                              				
                            }

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:4821:5: this_ID_15= RULE_ID
                            {
                            this_ID_15=(Token)match(input,RULE_ID,FOLLOW_29); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_ID_15, grammarAccess.getArithmethicalExpressionAccess().getIDTerminalRuleCall_1_2_2());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:4826:4: (this_SEMICOLON_16= RULE_SEMICOLON this_EOLINE_17= RULE_EOLINE )?
                    int alt134=2;
                    int LA134_0 = input.LA(1);

                    if ( (LA134_0==RULE_SEMICOLON) ) {
                        int LA134_1 = input.LA(2);

                        if ( (LA134_1==RULE_EOLINE) ) {
                            int LA134_3 = input.LA(3);

                            if ( (LA134_3==EOF||(LA134_3>=RULE_SEMICOLON && LA134_3<=RULE_CLOSEKEY)||(LA134_3>=RULE_INTEGER && LA134_3<=RULE_ID)||(LA134_3>=RULE_OPENPARENTHESIS && LA134_3<=RULE_STRING)||LA134_3==RULE_FLOAT||LA134_3==RULE_BREAK||LA134_3==45||LA134_3==51||(LA134_3>=58 && LA134_3<=59)||LA134_3==115) ) {
                                alt134=1;
                            }
                        }
                    }
                    switch (alt134) {
                        case 1 :
                            // InternalSM2.g:4827:5: this_SEMICOLON_16= RULE_SEMICOLON this_EOLINE_17= RULE_EOLINE
                            {
                            this_SEMICOLON_16=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_16, grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0());
                              				
                            }
                            this_EOLINE_17=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_17, grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalExpression"


    // $ANTLR start "entryRuleArithmethicalLogicalExpression"
    // InternalSM2.g:4841:1: entryRuleArithmethicalLogicalExpression returns [EObject current=null] : iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF ;
    public final EObject entryRuleArithmethicalLogicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalLogicalExpression = null;


        try {
            // InternalSM2.g:4841:71: (iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF )
            // InternalSM2.g:4842:2: iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalLogicalExpression=ruleArithmethicalLogicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArithmethicalLogicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalLogicalExpression"


    // $ANTLR start "ruleArithmethicalLogicalExpression"
    // InternalSM2.g:4848:1: ruleArithmethicalLogicalExpression returns [EObject current=null] : (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator1_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) ( (lv_operator2_8_0= ruleComparationOperator ) ) ( (lv_expr_9_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? ) ;
    public final EObject ruleArithmethicalLogicalExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token lv_op1_1_0=null;
        Token this_FLOAT_2=null;
        Token this_ID_3=null;
        Token lv_op2_5_0=null;
        Token this_FLOAT_6=null;
        Token this_ID_7=null;
        Token this_CLOSEPARENTHESIS_10=null;
        Token this_SEMICOLON_11=null;
        Token this_EOLINE_12=null;
        Enumerator lv_operator1_4_0 = null;

        Enumerator lv_operator2_8_0 = null;

        EObject lv_expr_9_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4854:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator1_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) ( (lv_operator2_8_0= ruleComparationOperator ) ) ( (lv_expr_9_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? ) )
            // InternalSM2.g:4855:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator1_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) ( (lv_operator2_8_0= ruleComparationOperator ) ) ( (lv_expr_9_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? )
            {
            // InternalSM2.g:4855:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator1_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) ( (lv_operator2_8_0= ruleComparationOperator ) ) ( (lv_expr_9_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? )
            // InternalSM2.g:4856:3: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator1_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) ( (lv_operator2_8_0= ruleComparationOperator ) ) ( (lv_expr_9_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )?
            {
            this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_85); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0());
              		
            }
            // InternalSM2.g:4860:3: ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID )
            int alt136=3;
            switch ( input.LA(1) ) {
            case RULE_INTEGER:
                {
                alt136=1;
                }
                break;
            case RULE_FLOAT:
                {
                alt136=2;
                }
                break;
            case RULE_ID:
                {
                alt136=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 136, 0, input);

                throw nvae;
            }

            switch (alt136) {
                case 1 :
                    // InternalSM2.g:4861:4: ( (lv_op1_1_0= RULE_INTEGER ) )
                    {
                    // InternalSM2.g:4861:4: ( (lv_op1_1_0= RULE_INTEGER ) )
                    // InternalSM2.g:4862:5: (lv_op1_1_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:4862:5: (lv_op1_1_0= RULE_INTEGER )
                    // InternalSM2.g:4863:6: lv_op1_1_0= RULE_INTEGER
                    {
                    lv_op1_1_0=(Token)match(input,RULE_INTEGER,FOLLOW_86); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op1_1_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOp1INTEGERTerminalRuleCall_1_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalLogicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op1",
                      							lv_op1_1_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4880:4: this_FLOAT_2= RULE_FLOAT
                    {
                    this_FLOAT_2=(Token)match(input,RULE_FLOAT,FOLLOW_86); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_FLOAT_2, grammarAccess.getArithmethicalLogicalExpressionAccess().getFLOATTerminalRuleCall_1_1());
                      			
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:4885:4: this_ID_3= RULE_ID
                    {
                    this_ID_3=(Token)match(input,RULE_ID,FOLLOW_86); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_ID_3, grammarAccess.getArithmethicalLogicalExpressionAccess().getIDTerminalRuleCall_1_2());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:4890:3: ( (lv_operator1_4_0= ruleArithmeticalOperator ) )
            // InternalSM2.g:4891:4: (lv_operator1_4_0= ruleArithmeticalOperator )
            {
            // InternalSM2.g:4891:4: (lv_operator1_4_0= ruleArithmeticalOperator )
            // InternalSM2.g:4892:5: lv_operator1_4_0= ruleArithmeticalOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator1ArithmeticalOperatorEnumRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_85);
            lv_operator1_4_0=ruleArithmeticalOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"operator1",
              						lv_operator1_4_0,
              						"org.xtext.SM2.ArithmeticalOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4909:3: ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID )
            int alt137=3;
            switch ( input.LA(1) ) {
            case RULE_INTEGER:
                {
                alt137=1;
                }
                break;
            case RULE_FLOAT:
                {
                alt137=2;
                }
                break;
            case RULE_ID:
                {
                alt137=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 137, 0, input);

                throw nvae;
            }

            switch (alt137) {
                case 1 :
                    // InternalSM2.g:4910:4: ( (lv_op2_5_0= RULE_INTEGER ) )
                    {
                    // InternalSM2.g:4910:4: ( (lv_op2_5_0= RULE_INTEGER ) )
                    // InternalSM2.g:4911:5: (lv_op2_5_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:4911:5: (lv_op2_5_0= RULE_INTEGER )
                    // InternalSM2.g:4912:6: lv_op2_5_0= RULE_INTEGER
                    {
                    lv_op2_5_0=(Token)match(input,RULE_INTEGER,FOLLOW_71); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op2_5_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOp2INTEGERTerminalRuleCall_3_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalLogicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op2",
                      							lv_op2_5_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4929:4: this_FLOAT_6= RULE_FLOAT
                    {
                    this_FLOAT_6=(Token)match(input,RULE_FLOAT,FOLLOW_71); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_FLOAT_6, grammarAccess.getArithmethicalLogicalExpressionAccess().getFLOATTerminalRuleCall_3_1());
                      			
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:4934:4: this_ID_7= RULE_ID
                    {
                    this_ID_7=(Token)match(input,RULE_ID,FOLLOW_71); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_ID_7, grammarAccess.getArithmethicalLogicalExpressionAccess().getIDTerminalRuleCall_3_2());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:4939:3: ( (lv_operator2_8_0= ruleComparationOperator ) )
            // InternalSM2.g:4940:4: (lv_operator2_8_0= ruleComparationOperator )
            {
            // InternalSM2.g:4940:4: (lv_operator2_8_0= ruleComparationOperator )
            // InternalSM2.g:4941:5: lv_operator2_8_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator2ComparationOperatorEnumRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_87);
            lv_operator2_8_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"operator2",
              						lv_operator2_8_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4958:3: ( (lv_expr_9_0= ruleArithmethicalExpression ) )
            // InternalSM2.g:4959:4: (lv_expr_9_0= ruleArithmethicalExpression )
            {
            // InternalSM2.g:4959:4: (lv_expr_9_0= ruleArithmethicalExpression )
            // InternalSM2.g:4960:5: lv_expr_9_0= ruleArithmethicalExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getExprArithmethicalExpressionParserRuleCall_5_0());
              				
            }
            pushFollow(FOLLOW_28);
            lv_expr_9_0=ruleArithmethicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_9_0,
              						"org.xtext.SM2.ArithmethicalExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_10=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_29); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_10, grammarAccess.getArithmethicalLogicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:4981:3: (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )?
            int alt138=2;
            int LA138_0 = input.LA(1);

            if ( (LA138_0==RULE_SEMICOLON) ) {
                int LA138_1 = input.LA(2);

                if ( (LA138_1==RULE_EOLINE) ) {
                    int LA138_3 = input.LA(3);

                    if ( (LA138_3==EOF||(LA138_3>=RULE_SEMICOLON && LA138_3<=RULE_CLOSEKEY)||(LA138_3>=RULE_INTEGER && LA138_3<=RULE_ID)||(LA138_3>=RULE_OPENPARENTHESIS && LA138_3<=RULE_STRING)||LA138_3==RULE_FLOAT||LA138_3==RULE_BREAK||LA138_3==45||LA138_3==51||(LA138_3>=58 && LA138_3<=59)||LA138_3==115) ) {
                        alt138=1;
                    }
                }
            }
            switch (alt138) {
                case 1 :
                    // InternalSM2.g:4982:4: this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE
                    {
                    this_SEMICOLON_11=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_11, grammarAccess.getArithmethicalLogicalExpressionAccess().getSEMICOLONTerminalRuleCall_7_0());
                      			
                    }
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_12, grammarAccess.getArithmethicalLogicalExpressionAccess().getEOLINETerminalRuleCall_7_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalLogicalExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:4995:1: entryRuleSyntaxExpression returns [EObject current=null] : iv_ruleSyntaxExpression= ruleSyntaxExpression EOF ;
    public final EObject entryRuleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSyntaxExpression = null;


        try {
            // InternalSM2.g:4995:57: (iv_ruleSyntaxExpression= ruleSyntaxExpression EOF )
            // InternalSM2.g:4996:2: iv_ruleSyntaxExpression= ruleSyntaxExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSyntaxExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSyntaxExpression=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSyntaxExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:5002:1: ruleSyntaxExpression returns [EObject current=null] : ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) ) ;
    public final EObject ruleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        Token lv_expr_0_0=null;
        Token this_INTEGER_1=null;
        Token this_FLOAT_2=null;
        Token this_SEMICOLON_3=null;
        Token this_EOLINE_4=null;


        	enterRule();

        try {
            // InternalSM2.g:5008:2: ( ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) ) )
            // InternalSM2.g:5009:2: ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:5009:2: ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) )
            int alt141=2;
            int LA141_0 = input.LA(1);

            if ( (LA141_0==RULE_STRING) ) {
                alt141=1;
            }
            else if ( (LA141_0==RULE_INTEGER||LA141_0==RULE_FLOAT) ) {
                alt141=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 141, 0, input);

                throw nvae;
            }
            switch (alt141) {
                case 1 :
                    // InternalSM2.g:5010:3: ( (lv_expr_0_0= RULE_STRING ) )
                    {
                    // InternalSM2.g:5010:3: ( (lv_expr_0_0= RULE_STRING ) )
                    // InternalSM2.g:5011:4: (lv_expr_0_0= RULE_STRING )
                    {
                    // InternalSM2.g:5011:4: (lv_expr_0_0= RULE_STRING )
                    // InternalSM2.g:5012:5: lv_expr_0_0= RULE_STRING
                    {
                    lv_expr_0_0=(Token)match(input,RULE_STRING,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_expr_0_0, grammarAccess.getSyntaxExpressionAccess().getExprSTRINGTerminalRuleCall_0_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getSyntaxExpressionRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"expr",
                      						lv_expr_0_0,
                      						"org.eclipse.xtext.common.Terminals.STRING");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5029:3: ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:5029:3: ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? )
                    // InternalSM2.g:5030:4: (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )?
                    {
                    // InternalSM2.g:5030:4: (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT )
                    int alt139=2;
                    int LA139_0 = input.LA(1);

                    if ( (LA139_0==RULE_INTEGER) ) {
                        alt139=1;
                    }
                    else if ( (LA139_0==RULE_FLOAT) ) {
                        alt139=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 139, 0, input);

                        throw nvae;
                    }
                    switch (alt139) {
                        case 1 :
                            // InternalSM2.g:5031:5: this_INTEGER_1= RULE_INTEGER
                            {
                            this_INTEGER_1=(Token)match(input,RULE_INTEGER,FOLLOW_29); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_INTEGER_1, grammarAccess.getSyntaxExpressionAccess().getINTEGERTerminalRuleCall_1_0_0());
                              				
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:5036:5: this_FLOAT_2= RULE_FLOAT
                            {
                            this_FLOAT_2=(Token)match(input,RULE_FLOAT,FOLLOW_29); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_2, grammarAccess.getSyntaxExpressionAccess().getFLOATTerminalRuleCall_1_0_1());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:5041:4: (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )?
                    int alt140=2;
                    int LA140_0 = input.LA(1);

                    if ( (LA140_0==RULE_SEMICOLON) ) {
                        int LA140_1 = input.LA(2);

                        if ( (LA140_1==RULE_EOLINE) ) {
                            alt140=1;
                        }
                    }
                    switch (alt140) {
                        case 1 :
                            // InternalSM2.g:5042:5: this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE
                            {
                            this_SEMICOLON_3=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_3, grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0());
                              				
                            }
                            this_EOLINE_4=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_4, grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleWhileLoop"
    // InternalSM2.g:5056:1: entryRuleWhileLoop returns [EObject current=null] : iv_ruleWhileLoop= ruleWhileLoop EOF ;
    public final EObject entryRuleWhileLoop() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleWhileLoop = null;


        try {
            // InternalSM2.g:5056:50: (iv_ruleWhileLoop= ruleWhileLoop EOF )
            // InternalSM2.g:5057:2: iv_ruleWhileLoop= ruleWhileLoop EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getWhileLoopRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleWhileLoop=ruleWhileLoop();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleWhileLoop; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleWhileLoop"


    // $ANTLR start "ruleWhileLoop"
    // InternalSM2.g:5063:1: ruleWhileLoop returns [EObject current=null] : (otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= RULE_ID ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restrictionGas_8_0= ruleRestrictionGas ) ) ( (lv_loops_9_0= ruleLoops ) )? this_EOLINE_10= RULE_EOLINE ( (lv_conditions_11_0= ruleConditional ) )? this_EOLINE_12= RULE_EOLINE ( (lv_expressions_13_0= ruleExpression ) ) (this_EOLINE_14= RULE_EOLINE )? (this_BREAK_15= RULE_BREAK this_SEMICOLON_16= RULE_SEMICOLON )? (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY (this_EOLINE_19= RULE_EOLINE )? ) ;
    public final EObject ruleWhileLoop() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_expr1_2_0=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_OPENKEY_6=null;
        Token this_EOLINE_7=null;
        Token this_EOLINE_10=null;
        Token this_EOLINE_12=null;
        Token this_EOLINE_14=null;
        Token this_BREAK_15=null;
        Token this_SEMICOLON_16=null;
        Token this_EOLINE_17=null;
        Token this_CLOSEKEY_18=null;
        Token this_EOLINE_19=null;
        Enumerator lv_operator_3_0 = null;

        EObject lv_expr2_4_0 = null;

        EObject lv_restrictionGas_8_0 = null;

        EObject lv_loops_9_0 = null;

        EObject lv_conditions_11_0 = null;

        EObject lv_expressions_13_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:5069:2: ( (otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= RULE_ID ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restrictionGas_8_0= ruleRestrictionGas ) ) ( (lv_loops_9_0= ruleLoops ) )? this_EOLINE_10= RULE_EOLINE ( (lv_conditions_11_0= ruleConditional ) )? this_EOLINE_12= RULE_EOLINE ( (lv_expressions_13_0= ruleExpression ) ) (this_EOLINE_14= RULE_EOLINE )? (this_BREAK_15= RULE_BREAK this_SEMICOLON_16= RULE_SEMICOLON )? (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY (this_EOLINE_19= RULE_EOLINE )? ) )
            // InternalSM2.g:5070:2: (otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= RULE_ID ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restrictionGas_8_0= ruleRestrictionGas ) ) ( (lv_loops_9_0= ruleLoops ) )? this_EOLINE_10= RULE_EOLINE ( (lv_conditions_11_0= ruleConditional ) )? this_EOLINE_12= RULE_EOLINE ( (lv_expressions_13_0= ruleExpression ) ) (this_EOLINE_14= RULE_EOLINE )? (this_BREAK_15= RULE_BREAK this_SEMICOLON_16= RULE_SEMICOLON )? (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY (this_EOLINE_19= RULE_EOLINE )? )
            {
            // InternalSM2.g:5070:2: (otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= RULE_ID ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restrictionGas_8_0= ruleRestrictionGas ) ) ( (lv_loops_9_0= ruleLoops ) )? this_EOLINE_10= RULE_EOLINE ( (lv_conditions_11_0= ruleConditional ) )? this_EOLINE_12= RULE_EOLINE ( (lv_expressions_13_0= ruleExpression ) ) (this_EOLINE_14= RULE_EOLINE )? (this_BREAK_15= RULE_BREAK this_SEMICOLON_16= RULE_SEMICOLON )? (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY (this_EOLINE_19= RULE_EOLINE )? )
            // InternalSM2.g:5071:3: otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= RULE_ID ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restrictionGas_8_0= ruleRestrictionGas ) ) ( (lv_loops_9_0= ruleLoops ) )? this_EOLINE_10= RULE_EOLINE ( (lv_conditions_11_0= ruleConditional ) )? this_EOLINE_12= RULE_EOLINE ( (lv_expressions_13_0= ruleExpression ) ) (this_EOLINE_14= RULE_EOLINE )? (this_BREAK_15= RULE_BREAK this_SEMICOLON_16= RULE_SEMICOLON )? (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY (this_EOLINE_19= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,110,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getWhileLoopAccess().getWhileKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getWhileLoopAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:5079:3: ( (lv_expr1_2_0= RULE_ID ) )
            // InternalSM2.g:5080:4: (lv_expr1_2_0= RULE_ID )
            {
            // InternalSM2.g:5080:4: (lv_expr1_2_0= RULE_ID )
            // InternalSM2.g:5081:5: lv_expr1_2_0= RULE_ID
            {
            lv_expr1_2_0=(Token)match(input,RULE_ID,FOLLOW_71); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr1_2_0, grammarAccess.getWhileLoopAccess().getExpr1IDTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getWhileLoopRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr1",
              						lv_expr1_2_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:5097:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:5098:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:5098:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:5099:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getWhileLoopAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_37);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:5116:3: ( (lv_expr2_4_0= ruleExpression ) )
            // InternalSM2.g:5117:4: (lv_expr2_4_0= ruleExpression )
            {
            // InternalSM2.g:5117:4: (lv_expr2_4_0= ruleExpression )
            // InternalSM2.g:5118:5: lv_expr2_4_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getWhileLoopAccess().getExpr2ExpressionParserRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_28);
            lv_expr2_4_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
              					}
              					set(
              						current,
              						"expr2",
              						lv_expr2_4_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getWhileLoopAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            this_OPENKEY_6=(Token)match(input,RULE_OPENKEY,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_6, grammarAccess.getWhileLoopAccess().getOPENKEYTerminalRuleCall_6());
              		
            }
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_88); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_7, grammarAccess.getWhileLoopAccess().getEOLINETerminalRuleCall_7());
              		
            }
            // InternalSM2.g:5147:3: ( (lv_restrictionGas_8_0= ruleRestrictionGas ) )
            // InternalSM2.g:5148:4: (lv_restrictionGas_8_0= ruleRestrictionGas )
            {
            // InternalSM2.g:5148:4: (lv_restrictionGas_8_0= ruleRestrictionGas )
            // InternalSM2.g:5149:5: lv_restrictionGas_8_0= ruleRestrictionGas
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getWhileLoopAccess().getRestrictionGasRestrictionGasParserRuleCall_8_0());
              				
            }
            pushFollow(FOLLOW_89);
            lv_restrictionGas_8_0=ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
              					}
              					set(
              						current,
              						"restrictionGas",
              						lv_restrictionGas_8_0,
              						"org.xtext.SM2.RestrictionGas");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:5166:3: ( (lv_loops_9_0= ruleLoops ) )?
            int alt142=2;
            int LA142_0 = input.LA(1);

            if ( ((LA142_0>=110 && LA142_0<=111)) ) {
                alt142=1;
            }
            switch (alt142) {
                case 1 :
                    // InternalSM2.g:5167:4: (lv_loops_9_0= ruleLoops )
                    {
                    // InternalSM2.g:5167:4: (lv_loops_9_0= ruleLoops )
                    // InternalSM2.g:5168:5: lv_loops_9_0= ruleLoops
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getWhileLoopAccess().getLoopsLoopsParserRuleCall_9_0());
                      				
                    }
                    pushFollow(FOLLOW_16);
                    lv_loops_9_0=ruleLoops();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
                      					}
                      					add(
                      						current,
                      						"loops",
                      						lv_loops_9_0,
                      						"org.xtext.SM2.Loops");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_90); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_10, grammarAccess.getWhileLoopAccess().getEOLINETerminalRuleCall_10());
              		
            }
            // InternalSM2.g:5189:3: ( (lv_conditions_11_0= ruleConditional ) )?
            int alt143=2;
            int LA143_0 = input.LA(1);

            if ( (LA143_0==RULE_IF) ) {
                alt143=1;
            }
            switch (alt143) {
                case 1 :
                    // InternalSM2.g:5190:4: (lv_conditions_11_0= ruleConditional )
                    {
                    // InternalSM2.g:5190:4: (lv_conditions_11_0= ruleConditional )
                    // InternalSM2.g:5191:5: lv_conditions_11_0= ruleConditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getWhileLoopAccess().getConditionsConditionalParserRuleCall_11_0());
                      				
                    }
                    pushFollow(FOLLOW_16);
                    lv_conditions_11_0=ruleConditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
                      					}
                      					add(
                      						current,
                      						"conditions",
                      						lv_conditions_11_0,
                      						"org.xtext.SM2.Conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_37); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_12, grammarAccess.getWhileLoopAccess().getEOLINETerminalRuleCall_12());
              		
            }
            // InternalSM2.g:5212:3: ( (lv_expressions_13_0= ruleExpression ) )
            // InternalSM2.g:5213:4: (lv_expressions_13_0= ruleExpression )
            {
            // InternalSM2.g:5213:4: (lv_expressions_13_0= ruleExpression )
            // InternalSM2.g:5214:5: lv_expressions_13_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getWhileLoopAccess().getExpressionsExpressionParserRuleCall_13_0());
              				
            }
            pushFollow(FOLLOW_91);
            lv_expressions_13_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
              					}
              					add(
              						current,
              						"expressions",
              						lv_expressions_13_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:5231:3: (this_EOLINE_14= RULE_EOLINE )?
            int alt144=2;
            int LA144_0 = input.LA(1);

            if ( (LA144_0==RULE_EOLINE) ) {
                alt144=1;
            }
            switch (alt144) {
                case 1 :
                    // InternalSM2.g:5232:4: this_EOLINE_14= RULE_EOLINE
                    {
                    this_EOLINE_14=(Token)match(input,RULE_EOLINE,FOLLOW_91); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_14, grammarAccess.getWhileLoopAccess().getEOLINETerminalRuleCall_14());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:5237:3: (this_BREAK_15= RULE_BREAK this_SEMICOLON_16= RULE_SEMICOLON )?
            int alt145=2;
            int LA145_0 = input.LA(1);

            if ( (LA145_0==RULE_BREAK) ) {
                alt145=1;
            }
            switch (alt145) {
                case 1 :
                    // InternalSM2.g:5238:4: this_BREAK_15= RULE_BREAK this_SEMICOLON_16= RULE_SEMICOLON
                    {
                    this_BREAK_15=(Token)match(input,RULE_BREAK,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_BREAK_15, grammarAccess.getWhileLoopAccess().getBREAKTerminalRuleCall_15_0());
                      			
                    }
                    this_SEMICOLON_16=(Token)match(input,RULE_SEMICOLON,FOLLOW_58); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_16, grammarAccess.getWhileLoopAccess().getSEMICOLONTerminalRuleCall_15_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:5247:3: (this_EOLINE_17= RULE_EOLINE )?
            int alt146=2;
            int LA146_0 = input.LA(1);

            if ( (LA146_0==RULE_EOLINE) ) {
                alt146=1;
            }
            switch (alt146) {
                case 1 :
                    // InternalSM2.g:5248:4: this_EOLINE_17= RULE_EOLINE
                    {
                    this_EOLINE_17=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_17, grammarAccess.getWhileLoopAccess().getEOLINETerminalRuleCall_16());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_18=(Token)match(input,RULE_CLOSEKEY,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_18, grammarAccess.getWhileLoopAccess().getCLOSEKEYTerminalRuleCall_17());
              		
            }
            // InternalSM2.g:5257:3: (this_EOLINE_19= RULE_EOLINE )?
            int alt147=2;
            int LA147_0 = input.LA(1);

            if ( (LA147_0==RULE_EOLINE) ) {
                int LA147_1 = input.LA(2);

                if ( (LA147_1==EOF) ) {
                    alt147=1;
                }
                else if ( (LA147_1==RULE_EOLINE) ) {
                    int LA147_4 = input.LA(3);

                    if ( (LA147_4==RULE_EOLINE||LA147_4==RULE_IF) ) {
                        alt147=1;
                    }
                }
            }
            switch (alt147) {
                case 1 :
                    // InternalSM2.g:5258:4: this_EOLINE_19= RULE_EOLINE
                    {
                    this_EOLINE_19=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_19, grammarAccess.getWhileLoopAccess().getEOLINETerminalRuleCall_18());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleWhileLoop"


    // $ANTLR start "entryRuleForLoop"
    // InternalSM2.g:5267:1: entryRuleForLoop returns [EObject current=null] : iv_ruleForLoop= ruleForLoop EOF ;
    public final EObject entryRuleForLoop() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleForLoop = null;


        try {
            // InternalSM2.g:5267:48: (iv_ruleForLoop= ruleForLoop EOF )
            // InternalSM2.g:5268:2: iv_ruleForLoop= ruleForLoop EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getForLoopRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleForLoop=ruleForLoop();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleForLoop; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleForLoop"


    // $ANTLR start "ruleForLoop"
    // InternalSM2.g:5274:1: ruleForLoop returns [EObject current=null] : (otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INTEGER ) ) ) this_SEMICOLON_6= RULE_SEMICOLON this_ArithmethicalLogicalExpression_7= ruleArithmethicalLogicalExpression this_SEMICOLON_8= RULE_SEMICOLON ( (lv_nameCounterIteration_9_0= RULE_ID ) ) ( (lv_operator_10_0= ruleLoopOperator ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS this_OPENKEY_12= RULE_OPENKEY this_EOLINE_13= RULE_EOLINE ( (lv_restrictionGas_14_0= ruleRestrictionGas ) ) ( (lv_loops_15_0= ruleLoops ) )? this_EOLINE_16= RULE_EOLINE ( (lv_conditions_17_0= ruleConditional ) )? this_EOLINE_18= RULE_EOLINE ( (lv_expressions_19_0= ruleExpression ) ) (this_EOLINE_20= RULE_EOLINE )? (this_BREAK_21= RULE_BREAK this_SEMICOLON_22= RULE_SEMICOLON )? (this_EOLINE_23= RULE_EOLINE )? this_CLOSEKEY_24= RULE_CLOSEKEY (this_EOLINE_25= RULE_EOLINE )? ) ;
    public final EObject ruleForLoop() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_typeCounter_2_1=null;
        Token lv_typeCounter_2_2=null;
        Token lv_nameCounter_3_0=null;
        Token otherlv_4=null;
        Token lv_value_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_SEMICOLON_8=null;
        Token lv_nameCounterIteration_9_0=null;
        Token this_CLOSEPARENTHESIS_11=null;
        Token this_OPENKEY_12=null;
        Token this_EOLINE_13=null;
        Token this_EOLINE_16=null;
        Token this_EOLINE_18=null;
        Token this_EOLINE_20=null;
        Token this_BREAK_21=null;
        Token this_SEMICOLON_22=null;
        Token this_EOLINE_23=null;
        Token this_CLOSEKEY_24=null;
        Token this_EOLINE_25=null;
        EObject this_ArithmethicalLogicalExpression_7 = null;

        EObject lv_operator_10_0 = null;

        EObject lv_restrictionGas_14_0 = null;

        EObject lv_loops_15_0 = null;

        EObject lv_conditions_17_0 = null;

        EObject lv_expressions_19_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:5280:2: ( (otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INTEGER ) ) ) this_SEMICOLON_6= RULE_SEMICOLON this_ArithmethicalLogicalExpression_7= ruleArithmethicalLogicalExpression this_SEMICOLON_8= RULE_SEMICOLON ( (lv_nameCounterIteration_9_0= RULE_ID ) ) ( (lv_operator_10_0= ruleLoopOperator ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS this_OPENKEY_12= RULE_OPENKEY this_EOLINE_13= RULE_EOLINE ( (lv_restrictionGas_14_0= ruleRestrictionGas ) ) ( (lv_loops_15_0= ruleLoops ) )? this_EOLINE_16= RULE_EOLINE ( (lv_conditions_17_0= ruleConditional ) )? this_EOLINE_18= RULE_EOLINE ( (lv_expressions_19_0= ruleExpression ) ) (this_EOLINE_20= RULE_EOLINE )? (this_BREAK_21= RULE_BREAK this_SEMICOLON_22= RULE_SEMICOLON )? (this_EOLINE_23= RULE_EOLINE )? this_CLOSEKEY_24= RULE_CLOSEKEY (this_EOLINE_25= RULE_EOLINE )? ) )
            // InternalSM2.g:5281:2: (otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INTEGER ) ) ) this_SEMICOLON_6= RULE_SEMICOLON this_ArithmethicalLogicalExpression_7= ruleArithmethicalLogicalExpression this_SEMICOLON_8= RULE_SEMICOLON ( (lv_nameCounterIteration_9_0= RULE_ID ) ) ( (lv_operator_10_0= ruleLoopOperator ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS this_OPENKEY_12= RULE_OPENKEY this_EOLINE_13= RULE_EOLINE ( (lv_restrictionGas_14_0= ruleRestrictionGas ) ) ( (lv_loops_15_0= ruleLoops ) )? this_EOLINE_16= RULE_EOLINE ( (lv_conditions_17_0= ruleConditional ) )? this_EOLINE_18= RULE_EOLINE ( (lv_expressions_19_0= ruleExpression ) ) (this_EOLINE_20= RULE_EOLINE )? (this_BREAK_21= RULE_BREAK this_SEMICOLON_22= RULE_SEMICOLON )? (this_EOLINE_23= RULE_EOLINE )? this_CLOSEKEY_24= RULE_CLOSEKEY (this_EOLINE_25= RULE_EOLINE )? )
            {
            // InternalSM2.g:5281:2: (otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INTEGER ) ) ) this_SEMICOLON_6= RULE_SEMICOLON this_ArithmethicalLogicalExpression_7= ruleArithmethicalLogicalExpression this_SEMICOLON_8= RULE_SEMICOLON ( (lv_nameCounterIteration_9_0= RULE_ID ) ) ( (lv_operator_10_0= ruleLoopOperator ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS this_OPENKEY_12= RULE_OPENKEY this_EOLINE_13= RULE_EOLINE ( (lv_restrictionGas_14_0= ruleRestrictionGas ) ) ( (lv_loops_15_0= ruleLoops ) )? this_EOLINE_16= RULE_EOLINE ( (lv_conditions_17_0= ruleConditional ) )? this_EOLINE_18= RULE_EOLINE ( (lv_expressions_19_0= ruleExpression ) ) (this_EOLINE_20= RULE_EOLINE )? (this_BREAK_21= RULE_BREAK this_SEMICOLON_22= RULE_SEMICOLON )? (this_EOLINE_23= RULE_EOLINE )? this_CLOSEKEY_24= RULE_CLOSEKEY (this_EOLINE_25= RULE_EOLINE )? )
            // InternalSM2.g:5282:3: otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INTEGER ) ) ) this_SEMICOLON_6= RULE_SEMICOLON this_ArithmethicalLogicalExpression_7= ruleArithmethicalLogicalExpression this_SEMICOLON_8= RULE_SEMICOLON ( (lv_nameCounterIteration_9_0= RULE_ID ) ) ( (lv_operator_10_0= ruleLoopOperator ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS this_OPENKEY_12= RULE_OPENKEY this_EOLINE_13= RULE_EOLINE ( (lv_restrictionGas_14_0= ruleRestrictionGas ) ) ( (lv_loops_15_0= ruleLoops ) )? this_EOLINE_16= RULE_EOLINE ( (lv_conditions_17_0= ruleConditional ) )? this_EOLINE_18= RULE_EOLINE ( (lv_expressions_19_0= ruleExpression ) ) (this_EOLINE_20= RULE_EOLINE )? (this_BREAK_21= RULE_BREAK this_SEMICOLON_22= RULE_SEMICOLON )? (this_EOLINE_23= RULE_EOLINE )? this_CLOSEKEY_24= RULE_CLOSEKEY (this_EOLINE_25= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,111,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getForLoopAccess().getForKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_92); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getForLoopAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:5290:3: ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INTEGER ) ) )
            // InternalSM2.g:5291:4: ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INTEGER ) )
            {
            // InternalSM2.g:5291:4: ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) )
            // InternalSM2.g:5292:5: ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) )
            {
            // InternalSM2.g:5292:5: ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) )
            // InternalSM2.g:5293:6: (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' )
            {
            // InternalSM2.g:5293:6: (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' )
            int alt148=2;
            int LA148_0 = input.LA(1);

            if ( (LA148_0==81) ) {
                alt148=1;
            }
            else if ( (LA148_0==80) ) {
                alt148=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 148, 0, input);

                throw nvae;
            }
            switch (alt148) {
                case 1 :
                    // InternalSM2.g:5294:7: lv_typeCounter_2_1= 'uint'
                    {
                    lv_typeCounter_2_1=(Token)match(input,81,FOLLOW_12); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_typeCounter_2_1, grammarAccess.getForLoopAccess().getTypeCounterUintKeyword_2_0_0_0());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getForLoopRule());
                      							}
                      							setWithLastConsumed(current, "typeCounter", lv_typeCounter_2_1, null);
                      						
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:5305:7: lv_typeCounter_2_2= 'int'
                    {
                    lv_typeCounter_2_2=(Token)match(input,80,FOLLOW_12); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_typeCounter_2_2, grammarAccess.getForLoopAccess().getTypeCounterIntKeyword_2_0_0_1());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getForLoopRule());
                      							}
                      							setWithLastConsumed(current, "typeCounter", lv_typeCounter_2_2, null);
                      						
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:5318:4: ( (lv_nameCounter_3_0= RULE_ID ) )
            // InternalSM2.g:5319:5: (lv_nameCounter_3_0= RULE_ID )
            {
            // InternalSM2.g:5319:5: (lv_nameCounter_3_0= RULE_ID )
            // InternalSM2.g:5320:6: lv_nameCounter_3_0= RULE_ID
            {
            lv_nameCounter_3_0=(Token)match(input,RULE_ID,FOLLOW_64); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						newLeafNode(lv_nameCounter_3_0, grammarAccess.getForLoopAccess().getNameCounterIDTerminalRuleCall_2_1_0());
              					
            }
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElement(grammarAccess.getForLoopRule());
              						}
              						setWithLastConsumed(
              							current,
              							"nameCounter",
              							lv_nameCounter_3_0,
              							"org.eclipse.xtext.common.Terminals.ID");
              					
            }

            }


            }

            otherlv_4=(Token)match(input,72,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_4, grammarAccess.getForLoopAccess().getEqualsSignKeyword_2_2());
              			
            }
            // InternalSM2.g:5340:4: ( (lv_value_5_0= RULE_INTEGER ) )
            // InternalSM2.g:5341:5: (lv_value_5_0= RULE_INTEGER )
            {
            // InternalSM2.g:5341:5: (lv_value_5_0= RULE_INTEGER )
            // InternalSM2.g:5342:6: lv_value_5_0= RULE_INTEGER
            {
            lv_value_5_0=(Token)match(input,RULE_INTEGER,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						newLeafNode(lv_value_5_0, grammarAccess.getForLoopAccess().getValueINTEGERTerminalRuleCall_2_3_0());
              					
            }
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElement(grammarAccess.getForLoopRule());
              						}
              						setWithLastConsumed(
              							current,
              							"value",
              							lv_value_5_0,
              							"org.xtext.SM2.INTEGER");
              					
            }

            }


            }


            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getForLoopAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            if ( state.backtracking==0 ) {

              			newCompositeNode(grammarAccess.getForLoopAccess().getArithmethicalLogicalExpressionParserRuleCall_4());
              		
            }
            pushFollow(FOLLOW_5);
            this_ArithmethicalLogicalExpression_7=ruleArithmethicalLogicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			current = this_ArithmethicalLogicalExpression_7;
              			afterParserOrEnumRuleCall();
              		
            }
            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getForLoopAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:5375:3: ( (lv_nameCounterIteration_9_0= RULE_ID ) )
            // InternalSM2.g:5376:4: (lv_nameCounterIteration_9_0= RULE_ID )
            {
            // InternalSM2.g:5376:4: (lv_nameCounterIteration_9_0= RULE_ID )
            // InternalSM2.g:5377:5: lv_nameCounterIteration_9_0= RULE_ID
            {
            lv_nameCounterIteration_9_0=(Token)match(input,RULE_ID,FOLLOW_93); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameCounterIteration_9_0, grammarAccess.getForLoopAccess().getNameCounterIterationIDTerminalRuleCall_6_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getForLoopRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameCounterIteration",
              						lv_nameCounterIteration_9_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:5393:3: ( (lv_operator_10_0= ruleLoopOperator ) )
            // InternalSM2.g:5394:4: (lv_operator_10_0= ruleLoopOperator )
            {
            // InternalSM2.g:5394:4: (lv_operator_10_0= ruleLoopOperator )
            // InternalSM2.g:5395:5: lv_operator_10_0= ruleLoopOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getForLoopAccess().getOperatorLoopOperatorParserRuleCall_7_0());
              				
            }
            pushFollow(FOLLOW_28);
            lv_operator_10_0=ruleLoopOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getForLoopRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_10_0,
              						"org.xtext.SM2.LoopOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_11=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_11, grammarAccess.getForLoopAccess().getCLOSEPARENTHESISTerminalRuleCall_8());
              		
            }
            this_OPENKEY_12=(Token)match(input,RULE_OPENKEY,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_12, grammarAccess.getForLoopAccess().getOPENKEYTerminalRuleCall_9());
              		
            }
            this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_88); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_13, grammarAccess.getForLoopAccess().getEOLINETerminalRuleCall_10());
              		
            }
            // InternalSM2.g:5424:3: ( (lv_restrictionGas_14_0= ruleRestrictionGas ) )
            // InternalSM2.g:5425:4: (lv_restrictionGas_14_0= ruleRestrictionGas )
            {
            // InternalSM2.g:5425:4: (lv_restrictionGas_14_0= ruleRestrictionGas )
            // InternalSM2.g:5426:5: lv_restrictionGas_14_0= ruleRestrictionGas
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getForLoopAccess().getRestrictionGasRestrictionGasParserRuleCall_11_0());
              				
            }
            pushFollow(FOLLOW_89);
            lv_restrictionGas_14_0=ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getForLoopRule());
              					}
              					set(
              						current,
              						"restrictionGas",
              						lv_restrictionGas_14_0,
              						"org.xtext.SM2.RestrictionGas");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:5443:3: ( (lv_loops_15_0= ruleLoops ) )?
            int alt149=2;
            int LA149_0 = input.LA(1);

            if ( ((LA149_0>=110 && LA149_0<=111)) ) {
                alt149=1;
            }
            switch (alt149) {
                case 1 :
                    // InternalSM2.g:5444:4: (lv_loops_15_0= ruleLoops )
                    {
                    // InternalSM2.g:5444:4: (lv_loops_15_0= ruleLoops )
                    // InternalSM2.g:5445:5: lv_loops_15_0= ruleLoops
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getForLoopAccess().getLoopsLoopsParserRuleCall_12_0());
                      				
                    }
                    pushFollow(FOLLOW_16);
                    lv_loops_15_0=ruleLoops();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getForLoopRule());
                      					}
                      					add(
                      						current,
                      						"loops",
                      						lv_loops_15_0,
                      						"org.xtext.SM2.Loops");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            this_EOLINE_16=(Token)match(input,RULE_EOLINE,FOLLOW_90); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_16, grammarAccess.getForLoopAccess().getEOLINETerminalRuleCall_13());
              		
            }
            // InternalSM2.g:5466:3: ( (lv_conditions_17_0= ruleConditional ) )?
            int alt150=2;
            int LA150_0 = input.LA(1);

            if ( (LA150_0==RULE_IF) ) {
                alt150=1;
            }
            switch (alt150) {
                case 1 :
                    // InternalSM2.g:5467:4: (lv_conditions_17_0= ruleConditional )
                    {
                    // InternalSM2.g:5467:4: (lv_conditions_17_0= ruleConditional )
                    // InternalSM2.g:5468:5: lv_conditions_17_0= ruleConditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getForLoopAccess().getConditionsConditionalParserRuleCall_14_0());
                      				
                    }
                    pushFollow(FOLLOW_16);
                    lv_conditions_17_0=ruleConditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getForLoopRule());
                      					}
                      					add(
                      						current,
                      						"conditions",
                      						lv_conditions_17_0,
                      						"org.xtext.SM2.Conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            this_EOLINE_18=(Token)match(input,RULE_EOLINE,FOLLOW_37); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_18, grammarAccess.getForLoopAccess().getEOLINETerminalRuleCall_15());
              		
            }
            // InternalSM2.g:5489:3: ( (lv_expressions_19_0= ruleExpression ) )
            // InternalSM2.g:5490:4: (lv_expressions_19_0= ruleExpression )
            {
            // InternalSM2.g:5490:4: (lv_expressions_19_0= ruleExpression )
            // InternalSM2.g:5491:5: lv_expressions_19_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getForLoopAccess().getExpressionsExpressionParserRuleCall_16_0());
              				
            }
            pushFollow(FOLLOW_91);
            lv_expressions_19_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getForLoopRule());
              					}
              					add(
              						current,
              						"expressions",
              						lv_expressions_19_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:5508:3: (this_EOLINE_20= RULE_EOLINE )?
            int alt151=2;
            int LA151_0 = input.LA(1);

            if ( (LA151_0==RULE_EOLINE) ) {
                alt151=1;
            }
            switch (alt151) {
                case 1 :
                    // InternalSM2.g:5509:4: this_EOLINE_20= RULE_EOLINE
                    {
                    this_EOLINE_20=(Token)match(input,RULE_EOLINE,FOLLOW_91); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_20, grammarAccess.getForLoopAccess().getEOLINETerminalRuleCall_17());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:5514:3: (this_BREAK_21= RULE_BREAK this_SEMICOLON_22= RULE_SEMICOLON )?
            int alt152=2;
            int LA152_0 = input.LA(1);

            if ( (LA152_0==RULE_BREAK) ) {
                alt152=1;
            }
            switch (alt152) {
                case 1 :
                    // InternalSM2.g:5515:4: this_BREAK_21= RULE_BREAK this_SEMICOLON_22= RULE_SEMICOLON
                    {
                    this_BREAK_21=(Token)match(input,RULE_BREAK,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_BREAK_21, grammarAccess.getForLoopAccess().getBREAKTerminalRuleCall_18_0());
                      			
                    }
                    this_SEMICOLON_22=(Token)match(input,RULE_SEMICOLON,FOLLOW_58); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_22, grammarAccess.getForLoopAccess().getSEMICOLONTerminalRuleCall_18_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:5524:3: (this_EOLINE_23= RULE_EOLINE )?
            int alt153=2;
            int LA153_0 = input.LA(1);

            if ( (LA153_0==RULE_EOLINE) ) {
                alt153=1;
            }
            switch (alt153) {
                case 1 :
                    // InternalSM2.g:5525:4: this_EOLINE_23= RULE_EOLINE
                    {
                    this_EOLINE_23=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_23, grammarAccess.getForLoopAccess().getEOLINETerminalRuleCall_19());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_24=(Token)match(input,RULE_CLOSEKEY,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_24, grammarAccess.getForLoopAccess().getCLOSEKEYTerminalRuleCall_20());
              		
            }
            // InternalSM2.g:5534:3: (this_EOLINE_25= RULE_EOLINE )?
            int alt154=2;
            int LA154_0 = input.LA(1);

            if ( (LA154_0==RULE_EOLINE) ) {
                int LA154_1 = input.LA(2);

                if ( (LA154_1==RULE_EOLINE) ) {
                    int LA154_3 = input.LA(3);

                    if ( (LA154_3==RULE_EOLINE||LA154_3==RULE_IF) ) {
                        alt154=1;
                    }
                }
                else if ( (LA154_1==EOF) ) {
                    alt154=1;
                }
            }
            switch (alt154) {
                case 1 :
                    // InternalSM2.g:5535:4: this_EOLINE_25= RULE_EOLINE
                    {
                    this_EOLINE_25=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_25, grammarAccess.getForLoopAccess().getEOLINETerminalRuleCall_21());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleForLoop"


    // $ANTLR start "entryRuleLoops"
    // InternalSM2.g:5544:1: entryRuleLoops returns [EObject current=null] : iv_ruleLoops= ruleLoops EOF ;
    public final EObject entryRuleLoops() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLoops = null;


        try {
            // InternalSM2.g:5544:46: (iv_ruleLoops= ruleLoops EOF )
            // InternalSM2.g:5545:2: iv_ruleLoops= ruleLoops EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLoopsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLoops=ruleLoops();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLoops; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLoops"


    // $ANTLR start "ruleLoops"
    // InternalSM2.g:5551:1: ruleLoops returns [EObject current=null] : (this_WhileLoop_0= ruleWhileLoop | this_ForLoop_1= ruleForLoop ) ;
    public final EObject ruleLoops() throws RecognitionException {
        EObject current = null;

        EObject this_WhileLoop_0 = null;

        EObject this_ForLoop_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:5557:2: ( (this_WhileLoop_0= ruleWhileLoop | this_ForLoop_1= ruleForLoop ) )
            // InternalSM2.g:5558:2: (this_WhileLoop_0= ruleWhileLoop | this_ForLoop_1= ruleForLoop )
            {
            // InternalSM2.g:5558:2: (this_WhileLoop_0= ruleWhileLoop | this_ForLoop_1= ruleForLoop )
            int alt155=2;
            int LA155_0 = input.LA(1);

            if ( (LA155_0==110) ) {
                alt155=1;
            }
            else if ( (LA155_0==111) ) {
                alt155=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 155, 0, input);

                throw nvae;
            }
            switch (alt155) {
                case 1 :
                    // InternalSM2.g:5559:3: this_WhileLoop_0= ruleWhileLoop
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getLoopsAccess().getWhileLoopParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_WhileLoop_0=ruleWhileLoop();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_WhileLoop_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:5568:3: this_ForLoop_1= ruleForLoop
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getLoopsAccess().getForLoopParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ForLoop_1=ruleForLoop();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ForLoop_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLoops"


    // $ANTLR start "entryRuleTimeExpression"
    // InternalSM2.g:5580:1: entryRuleTimeExpression returns [EObject current=null] : iv_ruleTimeExpression= ruleTimeExpression EOF ;
    public final EObject entryRuleTimeExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTimeExpression = null;


        try {
            // InternalSM2.g:5580:55: (iv_ruleTimeExpression= ruleTimeExpression EOF )
            // InternalSM2.g:5581:2: iv_ruleTimeExpression= ruleTimeExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getTimeExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleTimeExpression=ruleTimeExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleTimeExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTimeExpression"


    // $ANTLR start "ruleTimeExpression"
    // InternalSM2.g:5587:1: ruleTimeExpression returns [EObject current=null] : ( ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) ;
    public final EObject ruleTimeExpression() throws RecognitionException {
        EObject current = null;

        Token lv_time_0_0=null;
        Token this_SEMICOLON_2=null;
        Token this_EOLINE_3=null;
        Enumerator lv_unit_1_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:5593:2: ( ( ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) )
            // InternalSM2.g:5594:2: ( ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
            {
            // InternalSM2.g:5594:2: ( ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
            // InternalSM2.g:5595:3: ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
            {
            // InternalSM2.g:5595:3: ( (lv_time_0_0= RULE_INTEGER ) )
            // InternalSM2.g:5596:4: (lv_time_0_0= RULE_INTEGER )
            {
            // InternalSM2.g:5596:4: (lv_time_0_0= RULE_INTEGER )
            // InternalSM2.g:5597:5: lv_time_0_0= RULE_INTEGER
            {
            lv_time_0_0=(Token)match(input,RULE_INTEGER,FOLLOW_94); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_time_0_0, grammarAccess.getTimeExpressionAccess().getTimeINTEGERTerminalRuleCall_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getTimeExpressionRule());
              					}
              					setWithLastConsumed(
              						current,
              						"time",
              						lv_time_0_0,
              						"org.xtext.SM2.INTEGER");
              				
            }

            }


            }

            // InternalSM2.g:5613:3: ( (lv_unit_1_0= ruleTimeUnit ) )
            // InternalSM2.g:5614:4: (lv_unit_1_0= ruleTimeUnit )
            {
            // InternalSM2.g:5614:4: (lv_unit_1_0= ruleTimeUnit )
            // InternalSM2.g:5615:5: lv_unit_1_0= ruleTimeUnit
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getTimeExpressionAccess().getUnitTimeUnitEnumRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_29);
            lv_unit_1_0=ruleTimeUnit();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getTimeExpressionRule());
              					}
              					set(
              						current,
              						"unit",
              						lv_unit_1_0,
              						"org.xtext.SM2.TimeUnit");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:5632:3: (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
            int alt156=2;
            int LA156_0 = input.LA(1);

            if ( (LA156_0==RULE_SEMICOLON) ) {
                int LA156_1 = input.LA(2);

                if ( (LA156_1==RULE_EOLINE) ) {
                    int LA156_3 = input.LA(3);

                    if ( (LA156_3==EOF||(LA156_3>=RULE_SEMICOLON && LA156_3<=RULE_CLOSEKEY)||(LA156_3>=RULE_INTEGER && LA156_3<=RULE_ID)||(LA156_3>=RULE_OPENPARENTHESIS && LA156_3<=RULE_STRING)||LA156_3==RULE_FLOAT||LA156_3==RULE_BREAK||LA156_3==45||LA156_3==51||(LA156_3>=58 && LA156_3<=59)||LA156_3==115) ) {
                        alt156=1;
                    }
                }
            }
            switch (alt156) {
                case 1 :
                    // InternalSM2.g:5633:4: this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE
                    {
                    this_SEMICOLON_2=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_2, grammarAccess.getTimeExpressionAccess().getSEMICOLONTerminalRuleCall_2_0());
                      			
                    }
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getTimeExpressionAccess().getEOLINETerminalRuleCall_2_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeExpression"


    // $ANTLR start "entryRuleConditional"
    // InternalSM2.g:5646:1: entryRuleConditional returns [EObject current=null] : iv_ruleConditional= ruleConditional EOF ;
    public final EObject entryRuleConditional() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConditional = null;


        try {
            // InternalSM2.g:5646:52: (iv_ruleConditional= ruleConditional EOF )
            // InternalSM2.g:5647:2: iv_ruleConditional= ruleConditional EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConditionalRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleConditional=ruleConditional();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleConditional; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConditional"


    // $ANTLR start "ruleConditional"
    // InternalSM2.g:5653:1: ruleConditional returns [EObject current=null] : (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) ) ;
    public final EObject ruleConditional() throws RecognitionException {
        EObject current = null;

        Token this_IF_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_CLOSEKEY_7=null;
        Token this_ELSE_8=null;
        EObject this_LogicalUnaryOperator_2 = null;

        EObject lv_expression_3_0 = null;

        EObject lv_expressions_6_0 = null;

        EObject lv_needOtherCondition_9_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:5659:2: ( (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) ) )
            // InternalSM2.g:5660:2: (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) )
            {
            // InternalSM2.g:5660:2: (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) )
            // InternalSM2.g:5661:3: this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) )
            {
            this_IF_0=(Token)match(input,RULE_IF,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_IF_0, grammarAccess.getConditionalAccess().getIFTerminalRuleCall_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_37); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConditionalAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:5669:3: (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )?
            int alt157=2;
            alt157 = dfa157.predict(input);
            switch (alt157) {
                case 1 :
                    // InternalSM2.g:5670:4: this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator
                    {
                    if ( state.backtracking==0 ) {

                      				newCompositeNode(grammarAccess.getConditionalAccess().getLogicalUnaryOperatorParserRuleCall_2());
                      			
                    }
                    pushFollow(FOLLOW_37);
                    this_LogicalUnaryOperator_2=ruleLogicalUnaryOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = this_LogicalUnaryOperator_2;
                      				afterParserOrEnumRuleCall();
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:5679:3: ( (lv_expression_3_0= ruleExpression ) )
            // InternalSM2.g:5680:4: (lv_expression_3_0= ruleExpression )
            {
            // InternalSM2.g:5680:4: (lv_expression_3_0= ruleExpression )
            // InternalSM2.g:5681:5: lv_expression_3_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getConditionalAccess().getExpressionExpressionParserRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_28);
            lv_expression_3_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getConditionalRule());
              					}
              					set(
              						current,
              						"expression",
              						lv_expression_3_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getConditionalAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_76); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getConditionalAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:5706:3: ( (lv_expressions_6_0= ruleExpression ) )*
            loop158:
            do {
                int alt158=2;
                int LA158_0 = input.LA(1);

                if ( ((LA158_0>=RULE_INTEGER && LA158_0<=RULE_ID)||LA158_0==RULE_OPENPARENTHESIS||LA158_0==RULE_STRING||LA158_0==RULE_FLOAT||LA158_0==45||LA158_0==51||(LA158_0>=58 && LA158_0<=59)||LA158_0==115) ) {
                    alt158=1;
                }


                switch (alt158) {
            	case 1 :
            	    // InternalSM2.g:5707:4: (lv_expressions_6_0= ruleExpression )
            	    {
            	    // InternalSM2.g:5707:4: (lv_expressions_6_0= ruleExpression )
            	    // InternalSM2.g:5708:5: lv_expressions_6_0= ruleExpression
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getConditionalAccess().getExpressionsExpressionParserRuleCall_6_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_76);
            	    lv_expressions_6_0=ruleExpression();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getConditionalRule());
            	      					}
            	      					add(
            	      						current,
            	      						"expressions",
            	      						lv_expressions_6_0,
            	      						"org.xtext.SM2.Expression");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop158;
                }
            } while (true);

            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_95); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_7, grammarAccess.getConditionalAccess().getCLOSEKEYTerminalRuleCall_7());
              		
            }
            // InternalSM2.g:5729:3: (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) )
            // InternalSM2.g:5730:4: this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) )
            {
            this_ELSE_8=(Token)match(input,RULE_ELSE,FOLLOW_79); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(this_ELSE_8, grammarAccess.getConditionalAccess().getELSETerminalRuleCall_8_0());
              			
            }
            // InternalSM2.g:5734:4: ( (lv_needOtherCondition_9_0= ruleConditional ) )
            // InternalSM2.g:5735:5: (lv_needOtherCondition_9_0= ruleConditional )
            {
            // InternalSM2.g:5735:5: (lv_needOtherCondition_9_0= ruleConditional )
            // InternalSM2.g:5736:6: lv_needOtherCondition_9_0= ruleConditional
            {
            if ( state.backtracking==0 ) {

              						newCompositeNode(grammarAccess.getConditionalAccess().getNeedOtherConditionConditionalParserRuleCall_8_1_0());
              					
            }
            pushFollow(FOLLOW_2);
            lv_needOtherCondition_9_0=ruleConditional();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElementForParent(grammarAccess.getConditionalRule());
              						}
              						set(
              							current,
              							"needOtherCondition",
              							lv_needOtherCondition_9_0,
              							"org.xtext.SM2.Conditional");
              						afterParserOrEnumRuleCall();
              					
            }

            }


            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConditional"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:5758:1: entryRuleComment returns [EObject current=null] : iv_ruleComment= ruleComment EOF ;
    public final EObject entryRuleComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleComment = null;


        try {
            // InternalSM2.g:5758:48: (iv_ruleComment= ruleComment EOF )
            // InternalSM2.g:5759:2: iv_ruleComment= ruleComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleComment=ruleComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:5765:1: ruleComment returns [EObject current=null] : (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) ;
    public final EObject ruleComment() throws RecognitionException {
        EObject current = null;

        EObject this_ShortComment_0 = null;

        EObject this_LongComment_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:5771:2: ( (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) )
            // InternalSM2.g:5772:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            {
            // InternalSM2.g:5772:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            int alt159=2;
            int LA159_0 = input.LA(1);

            if ( (LA159_0==112) ) {
                alt159=1;
            }
            else if ( (LA159_0==113) ) {
                alt159=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 159, 0, input);

                throw nvae;
            }
            switch (alt159) {
                case 1 :
                    // InternalSM2.g:5773:3: this_ShortComment_0= ruleShortComment
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ShortComment_0=ruleShortComment();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ShortComment_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:5782:3: this_LongComment_1= ruleLongComment
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_LongComment_1=ruleLongComment();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_LongComment_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:5794:1: entryRuleShortComment returns [EObject current=null] : iv_ruleShortComment= ruleShortComment EOF ;
    public final EObject entryRuleShortComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleShortComment = null;


        try {
            // InternalSM2.g:5794:53: (iv_ruleShortComment= ruleShortComment EOF )
            // InternalSM2.g:5795:2: iv_ruleShortComment= ruleShortComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getShortCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleShortComment=ruleShortComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleShortComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:5801:1: ruleShortComment returns [EObject current=null] : (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) ) ;
    public final EObject ruleShortComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expr_1_0=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:5807:2: ( (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) ) )
            // InternalSM2.g:5808:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) )
            {
            // InternalSM2.g:5808:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) )
            // InternalSM2.g:5809:3: otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE )
            {
            otherlv_0=(Token)match(input,112,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0());
              		
            }
            // InternalSM2.g:5813:3: ( (lv_expr_1_0= RULE_STRING ) )
            // InternalSM2.g:5814:4: (lv_expr_1_0= RULE_STRING )
            {
            // InternalSM2.g:5814:4: (lv_expr_1_0= RULE_STRING )
            // InternalSM2.g:5815:5: lv_expr_1_0= RULE_STRING
            {
            lv_expr_1_0=(Token)match(input,RULE_STRING,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr_1_0, grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getShortCommentRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr",
              						lv_expr_1_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:5831:3: ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE )
            // InternalSM2.g:5832:4: ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE
            {
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(this_EOLINE_2, grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:5842:1: entryRuleLongComment returns [EObject current=null] : iv_ruleLongComment= ruleLongComment EOF ;
    public final EObject entryRuleLongComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLongComment = null;


        try {
            // InternalSM2.g:5842:52: (iv_ruleLongComment= ruleLongComment EOF )
            // InternalSM2.g:5843:2: iv_ruleLongComment= ruleLongComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLongCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLongComment=ruleLongComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLongComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:5849:1: ruleLongComment returns [EObject current=null] : (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) ) ;
    public final EObject ruleLongComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expression_1_1=null;
        Token lv_expression_1_2=null;
        Token lv_expression_1_3=null;
        Token lv_expression_1_4=null;
        Token lv_expression_1_5=null;
        Token lv_expression_1_6=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSM2.g:5855:2: ( (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) ) )
            // InternalSM2.g:5856:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) )
            {
            // InternalSM2.g:5856:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) )
            // InternalSM2.g:5857:3: otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' )
            {
            otherlv_0=(Token)match(input,113,FOLLOW_96); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0());
              		
            }
            // InternalSM2.g:5861:3: ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )?
            int alt161=2;
            int LA161_0 = input.LA(1);

            if ( (LA161_0==RULE_STRING||(LA161_0>=RULE_PARAMSLONGCOMENT && LA161_0<=RULE_NOTICELONGCOMENT)) ) {
                alt161=1;
            }
            switch (alt161) {
                case 1 :
                    // InternalSM2.g:5862:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
                    {
                    // InternalSM2.g:5862:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
                    // InternalSM2.g:5863:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
                    {
                    // InternalSM2.g:5863:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
                    int alt160=6;
                    switch ( input.LA(1) ) {
                    case RULE_STRING:
                        {
                        alt160=1;
                        }
                        break;
                    case RULE_PARAMSLONGCOMENT:
                        {
                        alt160=2;
                        }
                        break;
                    case RULE_DEVLONGCOMENT:
                        {
                        alt160=3;
                        }
                        break;
                    case RULE_RETURNSLONGCOMENT:
                        {
                        alt160=4;
                        }
                        break;
                    case RULE_TITLELONGCOMENT:
                        {
                        alt160=5;
                        }
                        break;
                    case RULE_NOTICELONGCOMENT:
                        {
                        alt160=6;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 160, 0, input);

                        throw nvae;
                    }

                    switch (alt160) {
                        case 1 :
                            // InternalSM2.g:5864:6: lv_expression_1_1= RULE_STRING
                            {
                            lv_expression_1_1=(Token)match(input,RULE_STRING,FOLLOW_97); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_1, grammarAccess.getLongCommentAccess().getExpressionSTRINGTerminalRuleCall_1_0_0());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_1,
                              							"org.eclipse.xtext.common.Terminals.STRING");
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:5879:6: lv_expression_1_2= RULE_PARAMSLONGCOMENT
                            {
                            lv_expression_1_2=(Token)match(input,RULE_PARAMSLONGCOMENT,FOLLOW_97); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_2, grammarAccess.getLongCommentAccess().getExpressionPARAMSLONGCOMENTTerminalRuleCall_1_0_1());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_2,
                              							"org.xtext.SM2.PARAMSLONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:5894:6: lv_expression_1_3= RULE_DEVLONGCOMENT
                            {
                            lv_expression_1_3=(Token)match(input,RULE_DEVLONGCOMENT,FOLLOW_97); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_3, grammarAccess.getLongCommentAccess().getExpressionDEVLONGCOMENTTerminalRuleCall_1_0_2());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_3,
                              							"org.xtext.SM2.DEVLONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 4 :
                            // InternalSM2.g:5909:6: lv_expression_1_4= RULE_RETURNSLONGCOMENT
                            {
                            lv_expression_1_4=(Token)match(input,RULE_RETURNSLONGCOMENT,FOLLOW_97); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_4, grammarAccess.getLongCommentAccess().getExpressionRETURNSLONGCOMENTTerminalRuleCall_1_0_3());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_4,
                              							"org.xtext.SM2.RETURNSLONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 5 :
                            // InternalSM2.g:5924:6: lv_expression_1_5= RULE_TITLELONGCOMENT
                            {
                            lv_expression_1_5=(Token)match(input,RULE_TITLELONGCOMENT,FOLLOW_97); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_5, grammarAccess.getLongCommentAccess().getExpressionTITLELONGCOMENTTerminalRuleCall_1_0_4());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_5,
                              							"org.xtext.SM2.TITLELONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 6 :
                            // InternalSM2.g:5939:6: lv_expression_1_6= RULE_NOTICELONGCOMENT
                            {
                            lv_expression_1_6=(Token)match(input,RULE_NOTICELONGCOMENT,FOLLOW_97); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_6, grammarAccess.getLongCommentAccess().getExpressionNOTICELONGCOMENTTerminalRuleCall_1_0_5());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_6,
                              							"org.xtext.SM2.NOTICELONGCOMENT");
                              					
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }

            // InternalSM2.g:5956:3: ( ( '*/' )=>otherlv_2= '*/' )
            // InternalSM2.g:5957:4: ( '*/' )=>otherlv_2= '*/'
            {
            otherlv_2=(Token)match(input,114,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_2, grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "entryRuleLogicalUnaryOperator"
    // InternalSM2.g:5967:1: entryRuleLogicalUnaryOperator returns [EObject current=null] : iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF ;
    public final EObject entryRuleLogicalUnaryOperator() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLogicalUnaryOperator = null;


        try {
            // InternalSM2.g:5967:61: (iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF )
            // InternalSM2.g:5968:2: iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLogicalUnaryOperatorRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLogicalUnaryOperator=ruleLogicalUnaryOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLogicalUnaryOperator; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLogicalUnaryOperator"


    // $ANTLR start "ruleLogicalUnaryOperator"
    // InternalSM2.g:5974:1: ruleLogicalUnaryOperator returns [EObject current=null] : ( (lv_operator_0_0= '!' ) ) ;
    public final EObject ruleLogicalUnaryOperator() throws RecognitionException {
        EObject current = null;

        Token lv_operator_0_0=null;


        	enterRule();

        try {
            // InternalSM2.g:5980:2: ( ( (lv_operator_0_0= '!' ) ) )
            // InternalSM2.g:5981:2: ( (lv_operator_0_0= '!' ) )
            {
            // InternalSM2.g:5981:2: ( (lv_operator_0_0= '!' ) )
            // InternalSM2.g:5982:3: (lv_operator_0_0= '!' )
            {
            // InternalSM2.g:5982:3: (lv_operator_0_0= '!' )
            // InternalSM2.g:5983:4: lv_operator_0_0= '!'
            {
            lv_operator_0_0=(Token)match(input,115,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(lv_operator_0_0, grammarAccess.getLogicalUnaryOperatorAccess().getOperatorExclamationMarkKeyword_0());
              			
            }
            if ( state.backtracking==0 ) {

              				if (current==null) {
              					current = createModelElement(grammarAccess.getLogicalUnaryOperatorRule());
              				}
              				setWithLastConsumed(current, "operator", lv_operator_0_0, "!");
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalUnaryOperator"


    // $ANTLR start "entryRuleLoopOperator"
    // InternalSM2.g:5998:1: entryRuleLoopOperator returns [EObject current=null] : iv_ruleLoopOperator= ruleLoopOperator EOF ;
    public final EObject entryRuleLoopOperator() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLoopOperator = null;


        try {
            // InternalSM2.g:5998:53: (iv_ruleLoopOperator= ruleLoopOperator EOF )
            // InternalSM2.g:5999:2: iv_ruleLoopOperator= ruleLoopOperator EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLoopOperatorRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLoopOperator=ruleLoopOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLoopOperator; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLoopOperator"


    // $ANTLR start "ruleLoopOperator"
    // InternalSM2.g:6005:1: ruleLoopOperator returns [EObject current=null] : ( ( (lv_operator_0_1= '++' | lv_operator_0_2= '--' ) ) ) ;
    public final EObject ruleLoopOperator() throws RecognitionException {
        EObject current = null;

        Token lv_operator_0_1=null;
        Token lv_operator_0_2=null;


        	enterRule();

        try {
            // InternalSM2.g:6011:2: ( ( ( (lv_operator_0_1= '++' | lv_operator_0_2= '--' ) ) ) )
            // InternalSM2.g:6012:2: ( ( (lv_operator_0_1= '++' | lv_operator_0_2= '--' ) ) )
            {
            // InternalSM2.g:6012:2: ( ( (lv_operator_0_1= '++' | lv_operator_0_2= '--' ) ) )
            // InternalSM2.g:6013:3: ( (lv_operator_0_1= '++' | lv_operator_0_2= '--' ) )
            {
            // InternalSM2.g:6013:3: ( (lv_operator_0_1= '++' | lv_operator_0_2= '--' ) )
            // InternalSM2.g:6014:4: (lv_operator_0_1= '++' | lv_operator_0_2= '--' )
            {
            // InternalSM2.g:6014:4: (lv_operator_0_1= '++' | lv_operator_0_2= '--' )
            int alt162=2;
            int LA162_0 = input.LA(1);

            if ( (LA162_0==116) ) {
                alt162=1;
            }
            else if ( (LA162_0==117) ) {
                alt162=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 162, 0, input);

                throw nvae;
            }
            switch (alt162) {
                case 1 :
                    // InternalSM2.g:6015:5: lv_operator_0_1= '++'
                    {
                    lv_operator_0_1=(Token)match(input,116,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_operator_0_1, grammarAccess.getLoopOperatorAccess().getOperatorPlusSignPlusSignKeyword_0_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getLoopOperatorRule());
                      					}
                      					setWithLastConsumed(current, "operator", lv_operator_0_1, null);
                      				
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:6026:5: lv_operator_0_2= '--'
                    {
                    lv_operator_0_2=(Token)match(input,117,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_operator_0_2, grammarAccess.getLoopOperatorAccess().getOperatorHyphenMinusHyphenMinusKeyword_0_1());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getLoopOperatorRule());
                      					}
                      					setWithLastConsumed(current, "operator", lv_operator_0_2, null);
                      				
                    }

                    }
                    break;

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLoopOperator"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:6042:1: ruleVisibility returns [Enumerator current=null] : ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) ;
    public final Enumerator ruleVisibility() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalSM2.g:6048:2: ( ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) )
            // InternalSM2.g:6049:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            {
            // InternalSM2.g:6049:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            int alt163=4;
            switch ( input.LA(1) ) {
            case 63:
                {
                alt163=1;
                }
                break;
            case 118:
                {
                alt163=2;
                }
                break;
            case 64:
                {
                alt163=3;
                }
                break;
            case 119:
                {
                alt163=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 163, 0, input);

                throw nvae;
            }

            switch (alt163) {
                case 1 :
                    // InternalSM2.g:6050:3: (enumLiteral_0= 'public' )
                    {
                    // InternalSM2.g:6050:3: (enumLiteral_0= 'public' )
                    // InternalSM2.g:6051:4: enumLiteral_0= 'public'
                    {
                    enumLiteral_0=(Token)match(input,63,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6058:3: (enumLiteral_1= 'private' )
                    {
                    // InternalSM2.g:6058:3: (enumLiteral_1= 'private' )
                    // InternalSM2.g:6059:4: enumLiteral_1= 'private'
                    {
                    enumLiteral_1=(Token)match(input,118,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:6066:3: (enumLiteral_2= 'internal' )
                    {
                    // InternalSM2.g:6066:3: (enumLiteral_2= 'internal' )
                    // InternalSM2.g:6067:4: enumLiteral_2= 'internal'
                    {
                    enumLiteral_2=(Token)match(input,64,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:6074:3: (enumLiteral_3= 'external' )
                    {
                    // InternalSM2.g:6074:3: (enumLiteral_3= 'external' )
                    // InternalSM2.g:6075:4: enumLiteral_3= 'external'
                    {
                    enumLiteral_3=(Token)match(input,119,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:6085:1: ruleCoin returns [Enumerator current=null] : ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) ;
    public final Enumerator ruleCoin() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:6091:2: ( ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) )
            // InternalSM2.g:6092:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            {
            // InternalSM2.g:6092:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            int alt164=6;
            switch ( input.LA(1) ) {
            case 120:
                {
                alt164=1;
                }
                break;
            case 121:
                {
                alt164=2;
                }
                break;
            case 122:
                {
                alt164=3;
                }
                break;
            case 123:
                {
                alt164=4;
                }
                break;
            case 124:
                {
                alt164=5;
                }
                break;
            case 125:
                {
                alt164=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 164, 0, input);

                throw nvae;
            }

            switch (alt164) {
                case 1 :
                    // InternalSM2.g:6093:3: (enumLiteral_0= 'ether' )
                    {
                    // InternalSM2.g:6093:3: (enumLiteral_0= 'ether' )
                    // InternalSM2.g:6094:4: enumLiteral_0= 'ether'
                    {
                    enumLiteral_0=(Token)match(input,120,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6101:3: (enumLiteral_1= 'wei' )
                    {
                    // InternalSM2.g:6101:3: (enumLiteral_1= 'wei' )
                    // InternalSM2.g:6102:4: enumLiteral_1= 'wei'
                    {
                    enumLiteral_1=(Token)match(input,121,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:6109:3: (enumLiteral_2= 'gwei' )
                    {
                    // InternalSM2.g:6109:3: (enumLiteral_2= 'gwei' )
                    // InternalSM2.g:6110:4: enumLiteral_2= 'gwei'
                    {
                    enumLiteral_2=(Token)match(input,122,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:6117:3: (enumLiteral_3= 'pwei' )
                    {
                    // InternalSM2.g:6117:3: (enumLiteral_3= 'pwei' )
                    // InternalSM2.g:6118:4: enumLiteral_3= 'pwei'
                    {
                    enumLiteral_3=(Token)match(input,123,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:6125:3: (enumLiteral_4= 'finney' )
                    {
                    // InternalSM2.g:6125:3: (enumLiteral_4= 'finney' )
                    // InternalSM2.g:6126:4: enumLiteral_4= 'finney'
                    {
                    enumLiteral_4=(Token)match(input,124,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:6133:3: (enumLiteral_5= 'szabo' )
                    {
                    // InternalSM2.g:6133:3: (enumLiteral_5= 'szabo' )
                    // InternalSM2.g:6134:4: enumLiteral_5= 'szabo'
                    {
                    enumLiteral_5=(Token)match(input,125,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:6144:1: ruleComparationOperator returns [Enumerator current=null] : ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) ;
    public final Enumerator ruleComparationOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:6150:2: ( ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) )
            // InternalSM2.g:6151:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            {
            // InternalSM2.g:6151:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            int alt165=6;
            switch ( input.LA(1) ) {
            case 126:
                {
                alt165=1;
                }
                break;
            case 127:
                {
                alt165=2;
                }
                break;
            case 39:
                {
                alt165=3;
                }
                break;
            case 128:
                {
                alt165=4;
                }
                break;
            case 108:
                {
                alt165=5;
                }
                break;
            case 129:
                {
                alt165=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 165, 0, input);

                throw nvae;
            }

            switch (alt165) {
                case 1 :
                    // InternalSM2.g:6152:3: (enumLiteral_0= '>' )
                    {
                    // InternalSM2.g:6152:3: (enumLiteral_0= '>' )
                    // InternalSM2.g:6153:4: enumLiteral_0= '>'
                    {
                    enumLiteral_0=(Token)match(input,126,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6160:3: (enumLiteral_1= '<' )
                    {
                    // InternalSM2.g:6160:3: (enumLiteral_1= '<' )
                    // InternalSM2.g:6161:4: enumLiteral_1= '<'
                    {
                    enumLiteral_1=(Token)match(input,127,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:6168:3: (enumLiteral_2= '>=' )
                    {
                    // InternalSM2.g:6168:3: (enumLiteral_2= '>=' )
                    // InternalSM2.g:6169:4: enumLiteral_2= '>='
                    {
                    enumLiteral_2=(Token)match(input,39,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:6176:3: (enumLiteral_3= '<=' )
                    {
                    // InternalSM2.g:6176:3: (enumLiteral_3= '<=' )
                    // InternalSM2.g:6177:4: enumLiteral_3= '<='
                    {
                    enumLiteral_3=(Token)match(input,128,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:6184:3: (enumLiteral_4= '==' )
                    {
                    // InternalSM2.g:6184:3: (enumLiteral_4= '==' )
                    // InternalSM2.g:6185:4: enumLiteral_4= '=='
                    {
                    enumLiteral_4=(Token)match(input,108,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:6192:3: (enumLiteral_5= '!=' )
                    {
                    // InternalSM2.g:6192:3: (enumLiteral_5= '!=' )
                    // InternalSM2.g:6193:4: enumLiteral_5= '!='
                    {
                    enumLiteral_5=(Token)match(input,129,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:6203:1: ruleLogicalPairOperator returns [Enumerator current=null] : ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) ;
    public final Enumerator ruleLogicalPairOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSM2.g:6209:2: ( ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) )
            // InternalSM2.g:6210:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            {
            // InternalSM2.g:6210:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            int alt166=2;
            int LA166_0 = input.LA(1);

            if ( (LA166_0==130) ) {
                alt166=1;
            }
            else if ( (LA166_0==131) ) {
                alt166=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 166, 0, input);

                throw nvae;
            }
            switch (alt166) {
                case 1 :
                    // InternalSM2.g:6211:3: (enumLiteral_0= '&&' )
                    {
                    // InternalSM2.g:6211:3: (enumLiteral_0= '&&' )
                    // InternalSM2.g:6212:4: enumLiteral_0= '&&'
                    {
                    enumLiteral_0=(Token)match(input,130,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6219:3: (enumLiteral_1= '||' )
                    {
                    // InternalSM2.g:6219:3: (enumLiteral_1= '||' )
                    // InternalSM2.g:6220:4: enumLiteral_1= '||'
                    {
                    enumLiteral_1=(Token)match(input,131,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:6230:1: ruleArithmeticalOperator returns [Enumerator current=null] : ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) ;
    public final Enumerator ruleArithmeticalOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;


        	enterRule();

        try {
            // InternalSM2.g:6236:2: ( ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) )
            // InternalSM2.g:6237:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            {
            // InternalSM2.g:6237:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            int alt167=5;
            switch ( input.LA(1) ) {
            case 132:
                {
                alt167=1;
                }
                break;
            case 133:
                {
                alt167=2;
                }
                break;
            case 134:
                {
                alt167=3;
                }
                break;
            case 135:
                {
                alt167=4;
                }
                break;
            case 136:
                {
                alt167=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 167, 0, input);

                throw nvae;
            }

            switch (alt167) {
                case 1 :
                    // InternalSM2.g:6238:3: (enumLiteral_0= '+' )
                    {
                    // InternalSM2.g:6238:3: (enumLiteral_0= '+' )
                    // InternalSM2.g:6239:4: enumLiteral_0= '+'
                    {
                    enumLiteral_0=(Token)match(input,132,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6246:3: (enumLiteral_1= '-' )
                    {
                    // InternalSM2.g:6246:3: (enumLiteral_1= '-' )
                    // InternalSM2.g:6247:4: enumLiteral_1= '-'
                    {
                    enumLiteral_1=(Token)match(input,133,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:6254:3: (enumLiteral_2= '*' )
                    {
                    // InternalSM2.g:6254:3: (enumLiteral_2= '*' )
                    // InternalSM2.g:6255:4: enumLiteral_2= '*'
                    {
                    enumLiteral_2=(Token)match(input,134,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:6262:3: (enumLiteral_3= '/' )
                    {
                    // InternalSM2.g:6262:3: (enumLiteral_3= '/' )
                    // InternalSM2.g:6263:4: enumLiteral_3= '/'
                    {
                    enumLiteral_3=(Token)match(input,135,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:6270:3: (enumLiteral_4= '%' )
                    {
                    // InternalSM2.g:6270:3: (enumLiteral_4= '%' )
                    // InternalSM2.g:6271:4: enumLiteral_4= '%'
                    {
                    enumLiteral_4=(Token)match(input,136,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmeticalOperator"


    // $ANTLR start "ruleBasicType"
    // InternalSM2.g:6281:1: ruleBasicType returns [Enumerator current=null] : ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint2' ) | (enumLiteral_3= 'uint4' ) | (enumLiteral_4= 'uint8' ) | (enumLiteral_5= 'uint16' ) | (enumLiteral_6= 'uint32' ) | (enumLiteral_7= 'uint64' ) | (enumLiteral_8= 'uint128' ) | (enumLiteral_9= 'uint256' ) | (enumLiteral_10= 'string' ) | (enumLiteral_11= 'address' ) | (enumLiteral_12= 'address payable' ) | (enumLiteral_13= 'double' ) | (enumLiteral_14= 'bool' ) | (enumLiteral_15= 'byte' ) | (enumLiteral_16= 'bytes2' ) | (enumLiteral_17= 'bytes3' ) | (enumLiteral_18= 'bytes4' ) | (enumLiteral_19= 'bytes5' ) | (enumLiteral_20= 'bytes6' ) | (enumLiteral_21= 'bytes7' ) | (enumLiteral_22= 'bytes8' ) | (enumLiteral_23= 'bytes32' ) ) ;
    public final Enumerator ruleBasicType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;
        Token enumLiteral_8=null;
        Token enumLiteral_9=null;
        Token enumLiteral_10=null;
        Token enumLiteral_11=null;
        Token enumLiteral_12=null;
        Token enumLiteral_13=null;
        Token enumLiteral_14=null;
        Token enumLiteral_15=null;
        Token enumLiteral_16=null;
        Token enumLiteral_17=null;
        Token enumLiteral_18=null;
        Token enumLiteral_19=null;
        Token enumLiteral_20=null;
        Token enumLiteral_21=null;
        Token enumLiteral_22=null;
        Token enumLiteral_23=null;


        	enterRule();

        try {
            // InternalSM2.g:6287:2: ( ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint2' ) | (enumLiteral_3= 'uint4' ) | (enumLiteral_4= 'uint8' ) | (enumLiteral_5= 'uint16' ) | (enumLiteral_6= 'uint32' ) | (enumLiteral_7= 'uint64' ) | (enumLiteral_8= 'uint128' ) | (enumLiteral_9= 'uint256' ) | (enumLiteral_10= 'string' ) | (enumLiteral_11= 'address' ) | (enumLiteral_12= 'address payable' ) | (enumLiteral_13= 'double' ) | (enumLiteral_14= 'bool' ) | (enumLiteral_15= 'byte' ) | (enumLiteral_16= 'bytes2' ) | (enumLiteral_17= 'bytes3' ) | (enumLiteral_18= 'bytes4' ) | (enumLiteral_19= 'bytes5' ) | (enumLiteral_20= 'bytes6' ) | (enumLiteral_21= 'bytes7' ) | (enumLiteral_22= 'bytes8' ) | (enumLiteral_23= 'bytes32' ) ) )
            // InternalSM2.g:6288:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint2' ) | (enumLiteral_3= 'uint4' ) | (enumLiteral_4= 'uint8' ) | (enumLiteral_5= 'uint16' ) | (enumLiteral_6= 'uint32' ) | (enumLiteral_7= 'uint64' ) | (enumLiteral_8= 'uint128' ) | (enumLiteral_9= 'uint256' ) | (enumLiteral_10= 'string' ) | (enumLiteral_11= 'address' ) | (enumLiteral_12= 'address payable' ) | (enumLiteral_13= 'double' ) | (enumLiteral_14= 'bool' ) | (enumLiteral_15= 'byte' ) | (enumLiteral_16= 'bytes2' ) | (enumLiteral_17= 'bytes3' ) | (enumLiteral_18= 'bytes4' ) | (enumLiteral_19= 'bytes5' ) | (enumLiteral_20= 'bytes6' ) | (enumLiteral_21= 'bytes7' ) | (enumLiteral_22= 'bytes8' ) | (enumLiteral_23= 'bytes32' ) )
            {
            // InternalSM2.g:6288:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint2' ) | (enumLiteral_3= 'uint4' ) | (enumLiteral_4= 'uint8' ) | (enumLiteral_5= 'uint16' ) | (enumLiteral_6= 'uint32' ) | (enumLiteral_7= 'uint64' ) | (enumLiteral_8= 'uint128' ) | (enumLiteral_9= 'uint256' ) | (enumLiteral_10= 'string' ) | (enumLiteral_11= 'address' ) | (enumLiteral_12= 'address payable' ) | (enumLiteral_13= 'double' ) | (enumLiteral_14= 'bool' ) | (enumLiteral_15= 'byte' ) | (enumLiteral_16= 'bytes2' ) | (enumLiteral_17= 'bytes3' ) | (enumLiteral_18= 'bytes4' ) | (enumLiteral_19= 'bytes5' ) | (enumLiteral_20= 'bytes6' ) | (enumLiteral_21= 'bytes7' ) | (enumLiteral_22= 'bytes8' ) | (enumLiteral_23= 'bytes32' ) )
            int alt168=24;
            switch ( input.LA(1) ) {
            case 80:
                {
                alt168=1;
                }
                break;
            case 81:
                {
                alt168=2;
                }
                break;
            case 82:
                {
                alt168=3;
                }
                break;
            case 83:
                {
                alt168=4;
                }
                break;
            case 84:
                {
                alt168=5;
                }
                break;
            case 85:
                {
                alt168=6;
                }
                break;
            case 86:
                {
                alt168=7;
                }
                break;
            case 87:
                {
                alt168=8;
                }
                break;
            case 137:
                {
                alt168=9;
                }
                break;
            case 88:
                {
                alt168=10;
                }
                break;
            case 73:
                {
                alt168=11;
                }
                break;
            case 71:
                {
                alt168=12;
                }
                break;
            case 90:
                {
                alt168=13;
                }
                break;
            case 138:
                {
                alt168=14;
                }
                break;
            case 89:
                {
                alt168=15;
                }
                break;
            case 139:
                {
                alt168=16;
                }
                break;
            case 92:
                {
                alt168=17;
                }
                break;
            case 93:
                {
                alt168=18;
                }
                break;
            case 94:
                {
                alt168=19;
                }
                break;
            case 95:
                {
                alt168=20;
                }
                break;
            case 96:
                {
                alt168=21;
                }
                break;
            case 97:
                {
                alt168=22;
                }
                break;
            case 98:
                {
                alt168=23;
                }
                break;
            case 100:
                {
                alt168=24;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 168, 0, input);

                throw nvae;
            }

            switch (alt168) {
                case 1 :
                    // InternalSM2.g:6289:3: (enumLiteral_0= 'int' )
                    {
                    // InternalSM2.g:6289:3: (enumLiteral_0= 'int' )
                    // InternalSM2.g:6290:4: enumLiteral_0= 'int'
                    {
                    enumLiteral_0=(Token)match(input,80,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getINTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getBasicTypeAccess().getINTEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6297:3: (enumLiteral_1= 'uint' )
                    {
                    // InternalSM2.g:6297:3: (enumLiteral_1= 'uint' )
                    // InternalSM2.g:6298:4: enumLiteral_1= 'uint'
                    {
                    enumLiteral_1=(Token)match(input,81,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getBasicTypeAccess().getUINTEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:6305:3: (enumLiteral_2= 'uint2' )
                    {
                    // InternalSM2.g:6305:3: (enumLiteral_2= 'uint2' )
                    // InternalSM2.g:6306:4: enumLiteral_2= 'uint2'
                    {
                    enumLiteral_2=(Token)match(input,82,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT2EnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getBasicTypeAccess().getUINT2EnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:6313:3: (enumLiteral_3= 'uint4' )
                    {
                    // InternalSM2.g:6313:3: (enumLiteral_3= 'uint4' )
                    // InternalSM2.g:6314:4: enumLiteral_3= 'uint4'
                    {
                    enumLiteral_3=(Token)match(input,83,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT4EnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getBasicTypeAccess().getUINT4EnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:6321:3: (enumLiteral_4= 'uint8' )
                    {
                    // InternalSM2.g:6321:3: (enumLiteral_4= 'uint8' )
                    // InternalSM2.g:6322:4: enumLiteral_4= 'uint8'
                    {
                    enumLiteral_4=(Token)match(input,84,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT8EnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getBasicTypeAccess().getUINT8EnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:6329:3: (enumLiteral_5= 'uint16' )
                    {
                    // InternalSM2.g:6329:3: (enumLiteral_5= 'uint16' )
                    // InternalSM2.g:6330:4: enumLiteral_5= 'uint16'
                    {
                    enumLiteral_5=(Token)match(input,85,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT16EnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getBasicTypeAccess().getUINT16EnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:6337:3: (enumLiteral_6= 'uint32' )
                    {
                    // InternalSM2.g:6337:3: (enumLiteral_6= 'uint32' )
                    // InternalSM2.g:6338:4: enumLiteral_6= 'uint32'
                    {
                    enumLiteral_6=(Token)match(input,86,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT32EnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_6, grammarAccess.getBasicTypeAccess().getUINT32EnumLiteralDeclaration_6());
                      			
                    }

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:6345:3: (enumLiteral_7= 'uint64' )
                    {
                    // InternalSM2.g:6345:3: (enumLiteral_7= 'uint64' )
                    // InternalSM2.g:6346:4: enumLiteral_7= 'uint64'
                    {
                    enumLiteral_7=(Token)match(input,87,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT64EnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_7, grammarAccess.getBasicTypeAccess().getUINT64EnumLiteralDeclaration_7());
                      			
                    }

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:6353:3: (enumLiteral_8= 'uint128' )
                    {
                    // InternalSM2.g:6353:3: (enumLiteral_8= 'uint128' )
                    // InternalSM2.g:6354:4: enumLiteral_8= 'uint128'
                    {
                    enumLiteral_8=(Token)match(input,137,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT128EnumLiteralDeclaration_8().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_8, grammarAccess.getBasicTypeAccess().getUINT128EnumLiteralDeclaration_8());
                      			
                    }

                    }


                    }
                    break;
                case 10 :
                    // InternalSM2.g:6361:3: (enumLiteral_9= 'uint256' )
                    {
                    // InternalSM2.g:6361:3: (enumLiteral_9= 'uint256' )
                    // InternalSM2.g:6362:4: enumLiteral_9= 'uint256'
                    {
                    enumLiteral_9=(Token)match(input,88,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT256EnumLiteralDeclaration_9().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_9, grammarAccess.getBasicTypeAccess().getUINT256EnumLiteralDeclaration_9());
                      			
                    }

                    }


                    }
                    break;
                case 11 :
                    // InternalSM2.g:6369:3: (enumLiteral_10= 'string' )
                    {
                    // InternalSM2.g:6369:3: (enumLiteral_10= 'string' )
                    // InternalSM2.g:6370:4: enumLiteral_10= 'string'
                    {
                    enumLiteral_10=(Token)match(input,73,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getSTRINGEnumLiteralDeclaration_10().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_10, grammarAccess.getBasicTypeAccess().getSTRINGEnumLiteralDeclaration_10());
                      			
                    }

                    }


                    }
                    break;
                case 12 :
                    // InternalSM2.g:6377:3: (enumLiteral_11= 'address' )
                    {
                    // InternalSM2.g:6377:3: (enumLiteral_11= 'address' )
                    // InternalSM2.g:6378:4: enumLiteral_11= 'address'
                    {
                    enumLiteral_11=(Token)match(input,71,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getADDRESSEnumLiteralDeclaration_11().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_11, grammarAccess.getBasicTypeAccess().getADDRESSEnumLiteralDeclaration_11());
                      			
                    }

                    }


                    }
                    break;
                case 13 :
                    // InternalSM2.g:6385:3: (enumLiteral_12= 'address payable' )
                    {
                    // InternalSM2.g:6385:3: (enumLiteral_12= 'address payable' )
                    // InternalSM2.g:6386:4: enumLiteral_12= 'address payable'
                    {
                    enumLiteral_12=(Token)match(input,90,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_12().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_12, grammarAccess.getBasicTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_12());
                      			
                    }

                    }


                    }
                    break;
                case 14 :
                    // InternalSM2.g:6393:3: (enumLiteral_13= 'double' )
                    {
                    // InternalSM2.g:6393:3: (enumLiteral_13= 'double' )
                    // InternalSM2.g:6394:4: enumLiteral_13= 'double'
                    {
                    enumLiteral_13=(Token)match(input,138,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getDOUBLEEnumLiteralDeclaration_13().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_13, grammarAccess.getBasicTypeAccess().getDOUBLEEnumLiteralDeclaration_13());
                      			
                    }

                    }


                    }
                    break;
                case 15 :
                    // InternalSM2.g:6401:3: (enumLiteral_14= 'bool' )
                    {
                    // InternalSM2.g:6401:3: (enumLiteral_14= 'bool' )
                    // InternalSM2.g:6402:4: enumLiteral_14= 'bool'
                    {
                    enumLiteral_14=(Token)match(input,89,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBOOLEANEnumLiteralDeclaration_14().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_14, grammarAccess.getBasicTypeAccess().getBOOLEANEnumLiteralDeclaration_14());
                      			
                    }

                    }


                    }
                    break;
                case 16 :
                    // InternalSM2.g:6409:3: (enumLiteral_15= 'byte' )
                    {
                    // InternalSM2.g:6409:3: (enumLiteral_15= 'byte' )
                    // InternalSM2.g:6410:4: enumLiteral_15= 'byte'
                    {
                    enumLiteral_15=(Token)match(input,139,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTEEnumLiteralDeclaration_15().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_15, grammarAccess.getBasicTypeAccess().getBYTEEnumLiteralDeclaration_15());
                      			
                    }

                    }


                    }
                    break;
                case 17 :
                    // InternalSM2.g:6417:3: (enumLiteral_16= 'bytes2' )
                    {
                    // InternalSM2.g:6417:3: (enumLiteral_16= 'bytes2' )
                    // InternalSM2.g:6418:4: enumLiteral_16= 'bytes2'
                    {
                    enumLiteral_16=(Token)match(input,92,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE2EnumLiteralDeclaration_16().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_16, grammarAccess.getBasicTypeAccess().getBYTE2EnumLiteralDeclaration_16());
                      			
                    }

                    }


                    }
                    break;
                case 18 :
                    // InternalSM2.g:6425:3: (enumLiteral_17= 'bytes3' )
                    {
                    // InternalSM2.g:6425:3: (enumLiteral_17= 'bytes3' )
                    // InternalSM2.g:6426:4: enumLiteral_17= 'bytes3'
                    {
                    enumLiteral_17=(Token)match(input,93,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE3EnumLiteralDeclaration_17().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_17, grammarAccess.getBasicTypeAccess().getBYTE3EnumLiteralDeclaration_17());
                      			
                    }

                    }


                    }
                    break;
                case 19 :
                    // InternalSM2.g:6433:3: (enumLiteral_18= 'bytes4' )
                    {
                    // InternalSM2.g:6433:3: (enumLiteral_18= 'bytes4' )
                    // InternalSM2.g:6434:4: enumLiteral_18= 'bytes4'
                    {
                    enumLiteral_18=(Token)match(input,94,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE4EnumLiteralDeclaration_18().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_18, grammarAccess.getBasicTypeAccess().getBYTE4EnumLiteralDeclaration_18());
                      			
                    }

                    }


                    }
                    break;
                case 20 :
                    // InternalSM2.g:6441:3: (enumLiteral_19= 'bytes5' )
                    {
                    // InternalSM2.g:6441:3: (enumLiteral_19= 'bytes5' )
                    // InternalSM2.g:6442:4: enumLiteral_19= 'bytes5'
                    {
                    enumLiteral_19=(Token)match(input,95,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE5EnumLiteralDeclaration_19().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_19, grammarAccess.getBasicTypeAccess().getBYTE5EnumLiteralDeclaration_19());
                      			
                    }

                    }


                    }
                    break;
                case 21 :
                    // InternalSM2.g:6449:3: (enumLiteral_20= 'bytes6' )
                    {
                    // InternalSM2.g:6449:3: (enumLiteral_20= 'bytes6' )
                    // InternalSM2.g:6450:4: enumLiteral_20= 'bytes6'
                    {
                    enumLiteral_20=(Token)match(input,96,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE6EnumLiteralDeclaration_20().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_20, grammarAccess.getBasicTypeAccess().getBYTE6EnumLiteralDeclaration_20());
                      			
                    }

                    }


                    }
                    break;
                case 22 :
                    // InternalSM2.g:6457:3: (enumLiteral_21= 'bytes7' )
                    {
                    // InternalSM2.g:6457:3: (enumLiteral_21= 'bytes7' )
                    // InternalSM2.g:6458:4: enumLiteral_21= 'bytes7'
                    {
                    enumLiteral_21=(Token)match(input,97,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE7EnumLiteralDeclaration_21().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_21, grammarAccess.getBasicTypeAccess().getBYTE7EnumLiteralDeclaration_21());
                      			
                    }

                    }


                    }
                    break;
                case 23 :
                    // InternalSM2.g:6465:3: (enumLiteral_22= 'bytes8' )
                    {
                    // InternalSM2.g:6465:3: (enumLiteral_22= 'bytes8' )
                    // InternalSM2.g:6466:4: enumLiteral_22= 'bytes8'
                    {
                    enumLiteral_22=(Token)match(input,98,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE8EnumLiteralDeclaration_22().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_22, grammarAccess.getBasicTypeAccess().getBYTE8EnumLiteralDeclaration_22());
                      			
                    }

                    }


                    }
                    break;
                case 24 :
                    // InternalSM2.g:6473:3: (enumLiteral_23= 'bytes32' )
                    {
                    // InternalSM2.g:6473:3: (enumLiteral_23= 'bytes32' )
                    // InternalSM2.g:6474:4: enumLiteral_23= 'bytes32'
                    {
                    enumLiteral_23=(Token)match(input,100,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE32EnumLiteralDeclaration_23().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_23, grammarAccess.getBasicTypeAccess().getBYTE32EnumLiteralDeclaration_23());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBasicType"


    // $ANTLR start "ruleTimeUnit"
    // InternalSM2.g:6484:1: ruleTimeUnit returns [Enumerator current=null] : ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) ) ;
    public final Enumerator ruleTimeUnit() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:6490:2: ( ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) ) )
            // InternalSM2.g:6491:2: ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) )
            {
            // InternalSM2.g:6491:2: ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) )
            int alt169=6;
            switch ( input.LA(1) ) {
            case 140:
                {
                alt169=1;
                }
                break;
            case 141:
                {
                alt169=2;
                }
                break;
            case 142:
                {
                alt169=3;
                }
                break;
            case 143:
                {
                alt169=4;
                }
                break;
            case 144:
                {
                alt169=5;
                }
                break;
            case 145:
                {
                alt169=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 169, 0, input);

                throw nvae;
            }

            switch (alt169) {
                case 1 :
                    // InternalSM2.g:6492:3: (enumLiteral_0= 'seconds' )
                    {
                    // InternalSM2.g:6492:3: (enumLiteral_0= 'seconds' )
                    // InternalSM2.g:6493:4: enumLiteral_0= 'seconds'
                    {
                    enumLiteral_0=(Token)match(input,140,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getSECONDSEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getTimeUnitAccess().getSECONDSEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6500:3: (enumLiteral_1= 'minutes' )
                    {
                    // InternalSM2.g:6500:3: (enumLiteral_1= 'minutes' )
                    // InternalSM2.g:6501:4: enumLiteral_1= 'minutes'
                    {
                    enumLiteral_1=(Token)match(input,141,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getMINUTESEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getTimeUnitAccess().getMINUTESEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:6508:3: (enumLiteral_2= 'hours' )
                    {
                    // InternalSM2.g:6508:3: (enumLiteral_2= 'hours' )
                    // InternalSM2.g:6509:4: enumLiteral_2= 'hours'
                    {
                    enumLiteral_2=(Token)match(input,142,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getHOURSEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getTimeUnitAccess().getHOURSEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:6516:3: (enumLiteral_3= 'days' )
                    {
                    // InternalSM2.g:6516:3: (enumLiteral_3= 'days' )
                    // InternalSM2.g:6517:4: enumLiteral_3= 'days'
                    {
                    enumLiteral_3=(Token)match(input,143,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getDAYSEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getTimeUnitAccess().getDAYSEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:6524:3: (enumLiteral_4= 'weeks' )
                    {
                    // InternalSM2.g:6524:3: (enumLiteral_4= 'weeks' )
                    // InternalSM2.g:6525:4: enumLiteral_4= 'weeks'
                    {
                    enumLiteral_4=(Token)match(input,144,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getWEEKSEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getTimeUnitAccess().getWEEKSEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:6532:3: (enumLiteral_5= 'years' )
                    {
                    // InternalSM2.g:6532:3: (enumLiteral_5= 'years' )
                    // InternalSM2.g:6533:4: enumLiteral_5= 'years'
                    {
                    enumLiteral_5=(Token)match(input,145,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getYEARSEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getTimeUnitAccess().getYEARSEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeUnit"

    // $ANTLR start synpred2_InternalSM2
    public final void synpred2_InternalSM2_fragment() throws RecognitionException {   
        // InternalSM2.g:5957:4: ( '*/' )
        // InternalSM2.g:5957:5: '*/'
        {
        match(input,114,FOLLOW_2); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred2_InternalSM2

    // Delegated rules

    public final boolean synpred2_InternalSM2() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred2_InternalSM2_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA51 dfa51 = new DFA51(this);
    protected DFA118 dfa118 = new DFA118(this);
    protected DFA128 dfa128 = new DFA128(this);
    protected DFA129 dfa129 = new DFA129(this);
    protected DFA157 dfa157 = new DFA157(this);
    static final String dfa_1s = "\36\uffff";
    static final String dfa_2s = "\1\106\1\12\1\13\1\5\1\12\1\11\1\uffff\1\4\1\11\1\5\1\4\1\6\3\4\1\uffff\1\16\1\5\1\4\1\16\1\4\1\16\1\5\1\4\1\16\1\4\1\17\1\5\1\4\1\uffff";
    static final String dfa_3s = "\1\106\1\12\1\13\2\144\1\167\1\uffff\1\110\1\20\1\144\1\4\1\144\3\110\1\uffff\1\16\1\111\1\4\1\16\1\110\1\16\1\111\1\4\1\16\1\110\1\17\1\112\1\4\1\uffff";
    static final String dfa_4s = "\6\uffff\1\1\10\uffff\1\2\15\uffff\1\3";
    static final String dfa_5s = "\36\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\4\4\uffff\1\6\74\uffff\1\5\1\uffff\2\6\5\uffff\25\6",
            "\1\6\74\uffff\1\5\1\uffff\2\6\5\uffff\25\6",
            "\1\6\1\7\64\uffff\2\6\14\uffff\2\6\47\uffff\2\6",
            "",
            "\1\11\103\uffff\1\10",
            "\1\6\4\uffff\1\12\1\uffff\1\6",
            "\1\13\1\6\3\uffff\1\6\74\uffff\1\6\1\uffff\1\14\1\6\5\uffff\25\6",
            "\1\11",
            "\1\6\3\uffff\1\6\74\uffff\1\6\1\uffff\1\15\1\6\5\uffff\25\6",
            "\1\6\11\uffff\1\16\71\uffff\1\6",
            "\1\6\11\uffff\1\17\71\uffff\1\6",
            "\1\21\103\uffff\1\20",
            "",
            "\1\22",
            "\1\17\103\uffff\1\23",
            "\1\21",
            "\1\24",
            "\1\26\103\uffff\1\25",
            "\1\27",
            "\1\17\103\uffff\1\30",
            "\1\26",
            "\1\31",
            "\1\33\103\uffff\1\32",
            "\1\34",
            "\1\17\103\uffff\1\35\1\17",
            "\1\33",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA51 extends DFA {

        public DFA51(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 51;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "1827:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )";
        }
    }
    static final String dfa_7s = "\22\uffff";
    static final String dfa_8s = "\1\11\1\14\1\uffff\1\11\1\47\2\4\6\11\1\5\1\uffff\2\4\1\47";
    static final String dfa_9s = "\1\163\1\14\1\uffff\1\20\3\u0081\6\20\1\5\1\uffff\2\175\1\u0081";
    static final String dfa_10s = "\2\uffff\1\2\13\uffff\1\1\3\uffff";
    static final String dfa_11s = "\22\uffff}>";
    static final String[] dfa_12s = {
            "\2\2\1\uffff\1\2\1\uffff\1\2\1\uffff\1\2\2\uffff\1\2\31\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\1\uffff\2\2\1\uffff\2\2\1\uffff\1\2\3\uffff\25\2\2\uffff\1\1\13\uffff\1\2",
            "\1\3",
            "",
            "\1\5\4\uffff\1\4\1\uffff\1\6",
            "\1\11\104\uffff\1\13\21\uffff\1\7\1\10\1\12\1\14",
            "\1\15\42\uffff\1\11\104\uffff\1\13\21\uffff\1\7\1\10\1\12\1\14",
            "\1\15\42\uffff\1\11\104\uffff\1\13\21\uffff\1\7\1\10\1\12\1\14",
            "\1\17\4\uffff\1\16\1\uffff\1\20",
            "\1\17\4\uffff\1\16\1\uffff\1\20",
            "\1\17\4\uffff\1\16\1\uffff\1\20",
            "\1\17\4\uffff\1\16\1\uffff\1\20",
            "\1\17\4\uffff\1\16\1\uffff\1\20",
            "\1\17\4\uffff\1\16\1\uffff\1\20",
            "\1\21",
            "",
            "\1\16\10\uffff\1\16\152\uffff\6\2",
            "\1\16\10\uffff\1\16\152\uffff\6\2",
            "\1\11\104\uffff\1\13\21\uffff\1\7\1\10\1\12\1\14"
    };

    static final short[] dfa_7 = DFA.unpackEncodedString(dfa_7s);
    static final char[] dfa_8 = DFA.unpackEncodedStringToUnsignedChars(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final short[] dfa_10 = DFA.unpackEncodedString(dfa_10s);
    static final short[] dfa_11 = DFA.unpackEncodedString(dfa_11s);
    static final short[][] dfa_12 = unpackEncodedStringArray(dfa_12s);

    class DFA118 extends DFA {

        public DFA118(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 118;
            this.eot = dfa_7;
            this.eof = dfa_7;
            this.min = dfa_8;
            this.max = dfa_9;
            this.accept = dfa_10;
            this.special = dfa_11;
            this.transition = dfa_12;
        }
        public String getDescription() {
            return "4200:3: ( (lv_restriction_4_0= ruleRestriction ) )?";
        }
    }
    static final String dfa_13s = "\25\uffff";
    static final String dfa_14s = "\2\uffff\2\5\21\uffff";
    static final String dfa_15s = "\2\11\2\4\4\uffff\3\u0084\1\uffff\5\11\3\15\1\uffff";
    static final String dfa_16s = "\1\163\1\20\1\u0091\1\u0088\4\uffff\3\u0088\1\uffff\5\20\3\u0081\1\uffff";
    static final String dfa_17s = "\4\uffff\1\1\1\3\1\5\1\6\3\uffff\1\4\10\uffff\1\2";
    static final String dfa_18s = "\25\uffff}>";
    static final String[] dfa_19s = {
            "\1\2\1\4\1\uffff\1\1\1\uffff\1\5\1\uffff\1\3\34\uffff\1\6\5\uffff\1\6\6\uffff\2\6\67\uffff\1\7",
            "\1\10\1\12\5\uffff\1\11",
            "\3\5\2\uffff\2\5\1\uffff\3\5\1\uffff\1\5\3\uffff\1\5\30\uffff\1\5\5\uffff\1\5\6\uffff\2\5\67\uffff\1\5\20\uffff\5\4\3\uffff\6\13",
            "\3\5\2\uffff\2\5\1\uffff\3\5\1\uffff\1\5\3\uffff\1\5\30\uffff\1\5\5\uffff\1\5\6\uffff\2\5\67\uffff\1\5\20\uffff\5\4",
            "",
            "",
            "",
            "",
            "\1\14\1\15\1\16\1\17\1\20",
            "\1\14\1\15\1\16\1\17\1\20",
            "\1\14\1\15\1\16\1\17\1\20",
            "",
            "\1\21\1\23\5\uffff\1\22",
            "\1\21\1\23\5\uffff\1\22",
            "\1\21\1\23\5\uffff\1\22",
            "\1\21\1\23\5\uffff\1\22",
            "\1\21\1\23\5\uffff\1\22",
            "\1\4\31\uffff\1\24\104\uffff\1\24\21\uffff\4\24",
            "\1\4\31\uffff\1\24\104\uffff\1\24\21\uffff\4\24",
            "\1\4\31\uffff\1\24\104\uffff\1\24\21\uffff\4\24",
            ""
    };

    static final short[] dfa_13 = DFA.unpackEncodedString(dfa_13s);
    static final short[] dfa_14 = DFA.unpackEncodedString(dfa_14s);
    static final char[] dfa_15 = DFA.unpackEncodedStringToUnsignedChars(dfa_15s);
    static final char[] dfa_16 = DFA.unpackEncodedStringToUnsignedChars(dfa_16s);
    static final short[] dfa_17 = DFA.unpackEncodedString(dfa_17s);
    static final short[] dfa_18 = DFA.unpackEncodedString(dfa_18s);
    static final short[][] dfa_19 = unpackEncodedStringArray(dfa_19s);

    class DFA128 extends DFA {

        public DFA128(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 128;
            this.eot = dfa_13;
            this.eof = dfa_14;
            this.min = dfa_15;
            this.max = dfa_16;
            this.accept = dfa_17;
            this.special = dfa_18;
            this.transition = dfa_19;
        }
        public String getDescription() {
            return "4492:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables | this_LogicalExpression_5= ruleLogicalExpression )";
        }
    }
    static final String dfa_20s = "\2\uffff\2\5\16\uffff";
    static final String dfa_21s = "\2\11\2\4\2\uffff\3\u0084\5\11\3\15\1\uffff";
    static final String dfa_22s = "\2\20\2\u0088\2\uffff\3\u0088\5\20\3\u0081\1\uffff";
    static final String dfa_23s = "\4\uffff\1\1\1\3\13\uffff\1\2";
    static final String[] dfa_24s = {
            "\1\2\1\4\1\uffff\1\1\1\uffff\1\5\1\uffff\1\3",
            "\1\6\1\10\5\uffff\1\7",
            "\3\5\2\uffff\2\5\1\uffff\3\5\1\uffff\1\5\3\uffff\1\5\30\uffff\1\5\5\uffff\1\5\6\uffff\2\5\67\uffff\1\5\20\uffff\5\4",
            "\3\5\2\uffff\2\5\1\uffff\3\5\1\uffff\1\5\3\uffff\1\5\30\uffff\1\5\5\uffff\1\5\6\uffff\2\5\67\uffff\1\5\20\uffff\5\4",
            "",
            "",
            "\1\11\1\12\1\13\1\14\1\15",
            "\1\11\1\12\1\13\1\14\1\15",
            "\1\11\1\12\1\13\1\14\1\15",
            "\1\16\1\20\5\uffff\1\17",
            "\1\16\1\20\5\uffff\1\17",
            "\1\16\1\20\5\uffff\1\17",
            "\1\16\1\20\5\uffff\1\17",
            "\1\16\1\20\5\uffff\1\17",
            "\1\4\31\uffff\1\21\104\uffff\1\21\21\uffff\4\21",
            "\1\4\31\uffff\1\21\104\uffff\1\21\21\uffff\4\21",
            "\1\4\31\uffff\1\21\104\uffff\1\21\21\uffff\4\21",
            ""
    };
    static final short[] dfa_20 = DFA.unpackEncodedString(dfa_20s);
    static final char[] dfa_21 = DFA.unpackEncodedStringToUnsignedChars(dfa_21s);
    static final char[] dfa_22 = DFA.unpackEncodedStringToUnsignedChars(dfa_22s);
    static final short[] dfa_23 = DFA.unpackEncodedString(dfa_23s);
    static final short[][] dfa_24 = unpackEncodedStringArray(dfa_24s);

    class DFA129 extends DFA {

        public DFA129(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 129;
            this.eot = dfa_7;
            this.eof = dfa_20;
            this.min = dfa_21;
            this.max = dfa_22;
            this.accept = dfa_23;
            this.special = dfa_11;
            this.transition = dfa_24;
        }
        public String getDescription() {
            return "4586:5: (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression )";
        }
    }
    static final String dfa_25s = "\75\uffff";
    static final String dfa_26s = "\2\11\1\uffff\1\11\2\uffff\1\u0084\1\uffff\3\u0084\12\11\3\uffff\3\15\6\11\1\uffff\1\11\6\u0084\12\11\3\4\3\15\1\5\1\uffff\2\15";
    static final String dfa_27s = "\2\163\1\uffff\1\20\2\uffff\1\u0088\1\uffff\3\u0088\12\20\3\uffff\3\u0081\6\20\1\uffff\1\20\6\u0088\12\20\6\15\1\5\1\uffff\2\15";
    static final String dfa_28s = "\2\uffff\1\2\1\uffff\2\1\1\uffff\1\1\15\uffff\3\1\11\uffff\1\1\30\uffff\1\1\2\uffff";
    static final String dfa_29s = "\75\uffff}>";
    static final String[] dfa_30s = {
            "\2\2\1\uffff\1\2\1\uffff\1\2\1\uffff\1\2\34\uffff\1\2\5\uffff\1\2\6\uffff\2\2\67\uffff\1\1",
            "\1\4\1\6\1\uffff\1\3\1\uffff\1\7\1\uffff\1\5\34\uffff\1\7\5\uffff\1\7\6\uffff\2\7\67\uffff\1\7",
            "",
            "\1\10\1\12\5\uffff\1\11",
            "",
            "",
            "\1\13\1\14\1\15\1\16\1\17",
            "",
            "\1\20\1\21\1\22\1\23\1\24",
            "\1\20\1\21\1\22\1\23\1\24",
            "\1\20\1\21\1\22\1\23\1\24",
            "\1\25\1\27\5\uffff\1\26",
            "\1\25\1\27\5\uffff\1\26",
            "\1\25\1\27\5\uffff\1\26",
            "\1\25\1\27\5\uffff\1\26",
            "\1\25\1\27\5\uffff\1\26",
            "\1\30\1\32\5\uffff\1\31",
            "\1\30\1\32\5\uffff\1\31",
            "\1\30\1\32\5\uffff\1\31",
            "\1\30\1\32\5\uffff\1\31",
            "\1\30\1\32\5\uffff\1\31",
            "",
            "",
            "",
            "\1\41\31\uffff\1\35\104\uffff\1\37\21\uffff\1\33\1\34\1\36\1\40",
            "\1\41\31\uffff\1\35\104\uffff\1\37\21\uffff\1\33\1\34\1\36\1\40",
            "\1\41\31\uffff\1\35\104\uffff\1\37\21\uffff\1\33\1\34\1\36\1\40",
            "\1\43\1\45\1\uffff\1\42\3\uffff\1\44",
            "\1\43\1\45\1\uffff\1\42\3\uffff\1\44",
            "\1\43\1\45\1\uffff\1\42\3\uffff\1\44",
            "\1\43\1\45\1\uffff\1\42\3\uffff\1\44",
            "\1\43\1\45\1\uffff\1\42\3\uffff\1\44",
            "\1\43\1\45\1\uffff\1\42\3\uffff\1\44",
            "",
            "\1\46\1\50\5\uffff\1\47",
            "\1\51\1\52\1\53\1\54\1\55",
            "\1\51\1\52\1\53\1\54\1\55",
            "\1\51\1\52\1\53\1\54\1\55",
            "\1\56\1\57\1\60\1\61\1\62",
            "\1\56\1\57\1\60\1\61\1\62",
            "\1\56\1\57\1\60\1\61\1\62",
            "\1\63\1\65\5\uffff\1\64",
            "\1\63\1\65\5\uffff\1\64",
            "\1\63\1\65\5\uffff\1\64",
            "\1\63\1\65\5\uffff\1\64",
            "\1\63\1\65\5\uffff\1\64",
            "\1\66\1\70\5\uffff\1\67",
            "\1\66\1\70\5\uffff\1\67",
            "\1\66\1\70\5\uffff\1\67",
            "\1\66\1\70\5\uffff\1\67",
            "\1\66\1\70\5\uffff\1\67",
            "\1\71\10\uffff\1\72",
            "\1\71\10\uffff\1\72",
            "\1\71\10\uffff\1\72",
            "\1\73",
            "\1\73",
            "\1\73",
            "\1\74",
            "",
            "\1\72",
            "\1\72"
    };

    static final short[] dfa_25 = DFA.unpackEncodedString(dfa_25s);
    static final char[] dfa_26 = DFA.unpackEncodedStringToUnsignedChars(dfa_26s);
    static final char[] dfa_27 = DFA.unpackEncodedStringToUnsignedChars(dfa_27s);
    static final short[] dfa_28 = DFA.unpackEncodedString(dfa_28s);
    static final short[] dfa_29 = DFA.unpackEncodedString(dfa_29s);
    static final short[][] dfa_30 = unpackEncodedStringArray(dfa_30s);

    class DFA157 extends DFA {

        public DFA157(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 157;
            this.eot = dfa_25;
            this.eof = dfa_25;
            this.min = dfa_26;
            this.max = dfa_27;
            this.accept = dfa_28;
            this.special = dfa_29;
            this.transition = dfa_30;
        }
        public String getDescription() {
            return "5669:3: (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )?";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x000000E000000000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x00000D0000000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000020000000010L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000410L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000100000000800L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x4000000000000422L,0x0003021FFFFF16D6L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x4000000000000402L,0x0003021FFFFF16D6L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000000402L,0x0003020000000006L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000000402L,0x0003020000000004L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000000402L,0x0003020000000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000000002L,0x0003000000000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0007C00000000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000000014200L,0x0000001FF8000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000014200L,0x0000001FF9FF0000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000014200L,0x0000001FFC000080L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x03F0000000000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x3000000000000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x8000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000000440L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000000000002000L,0x00000017F7FF0280L,0x0000000000000E00L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0C08200000095620L,0x0008001FF8000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000000020L,0x0000000000000008L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000000000000000L,0x00000017F7FF0280L,0x0000000000000E00L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000000000400L,0x00000017F7FF0280L,0x0000000000000E00L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x8000000000000400L,0x00C0000000000001L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000000000000420L,0x0000001FFFFF0680L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000000400L,0x0000001FFFFF0680L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000000000000440L,0x0000001FFFFF0680L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000000000000020L,0x0000000000000080L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000000010L,0x0000000000000100L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0000000000000020L,0x0000000000000200L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0000000000000020L,0x0000000000000400L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0000000000010200L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0000000000000060L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0000000000024040L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0000000000004040L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x0000000000000202L,0x0000000000006000L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x8000000000000600L,0x00C0000000006001L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000100L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0000000000000210L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x0000000000000600L,0x0000006000006000L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x0000000000000400L,0x0000006000000000L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x0000008000000000L,0xC000100000000000L,0x0000000000000003L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0x0000000000000000L,0x3F00000000000000L});
    public static final BitSet FOLLOW_73 = new BitSet(new long[]{0x0000000000000800L,0x0000010000000000L});
    public static final BitSet FOLLOW_74 = new BitSet(new long[]{0x0C08200000095620L,0x0008009FFFFF16D0L});
    public static final BitSet FOLLOW_75 = new BitSet(new long[]{0x0C08200000095620L,0x0008001FFFFF16D0L});
    public static final BitSet FOLLOW_76 = new BitSet(new long[]{0x0C08200000095660L,0x0008001FF8000000L});
    public static final BitSet FOLLOW_77 = new BitSet(new long[]{0x0000000000000000L,0x0000040000000000L});
    public static final BitSet FOLLOW_78 = new BitSet(new long[]{0x0000000000002400L});
    public static final BitSet FOLLOW_79 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_80 = new BitSet(new long[]{0x0000000000000000L,0x0000080000000000L});
    public static final BitSet FOLLOW_81 = new BitSet(new long[]{0x0000000000000000L,0x0000100000000000L});
    public static final BitSet FOLLOW_82 = new BitSet(new long[]{0x0C08200000095620L,0x0008001FFFFF0280L,0x0000000000000E00L});
    public static final BitSet FOLLOW_83 = new BitSet(new long[]{0x0000000000000000L,0x0000200000000000L});
    public static final BitSet FOLLOW_84 = new BitSet(new long[]{0x0000000000015600L,0x0000001FF8000000L});
    public static final BitSet FOLLOW_85 = new BitSet(new long[]{0x0000000000010600L});
    public static final BitSet FOLLOW_86 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x00000000000001F0L});
    public static final BitSet FOLLOW_87 = new BitSet(new long[]{0x0000000000011600L});
    public static final BitSet FOLLOW_88 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
    public static final BitSet FOLLOW_89 = new BitSet(new long[]{0x0000000000000020L,0x0000C00000000000L});
    public static final BitSet FOLLOW_90 = new BitSet(new long[]{0x0000000000080020L});
    public static final BitSet FOLLOW_91 = new BitSet(new long[]{0x0000000000100060L});
    public static final BitSet FOLLOW_92 = new BitSet(new long[]{0x0000000000000000L,0x0000000000030000L});
    public static final BitSet FOLLOW_93 = new BitSet(new long[]{0x0000000000000000L,0x0030000000000000L});
    public static final BitSet FOLLOW_94 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x000000000003F000L});
    public static final BitSet FOLLOW_95 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_96 = new BitSet(new long[]{0x0000000007C04000L,0x0004000000000000L});
    public static final BitSet FOLLOW_97 = new BitSet(new long[]{0x0000000000000000L,0x0004000000000000L});

}