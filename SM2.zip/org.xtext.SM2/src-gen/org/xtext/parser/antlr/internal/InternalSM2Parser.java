package org.xtext.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_CLOSEKEY", "RULE_INTEGER", "RULE_DOT", "RULE_ID", "RULE_OPENKEY", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_STRING", "RULE_EMAIL", "RULE_FLOAT", "RULE_COMMA", "RULE_SINGLENUMBER", "RULE_BOOLVALUE", "RULE_IF", "RULE_ELSE", "RULE_PARAMSLONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_NOTICELONGCOMENT", "RULE_RETURNS", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'pragma'", "'solidity'", "'^'", "'>'", "'>='", "'import'", "'as'", "'interface'", "'contract'", "'is'", "'msg'", "'data'", "'value'", "'gas'", "'sender'", "'sig'", "'block'", "'difficulty'", "'number'", "'timestamp'", "'coinbase'", "'gaslimit'", "'blockhash'", "'now'", "'thx'", "'gasprice'", "'origin'", "'constructor'", "'public'", "'internal'", "'event'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'address'", "'='", "'string'", "'float'", "'amountAccount'", "'enum'", "'[]'", "'['", "']'", "'int'", "'uint'", "'uint8'", "'uint32'", "'uint64'", "'uint256'", "'bool'", "'address payable'", "'bytes'", "'bytes4'", "'bytes8'", "'bytes16'", "'bytes32'", "'memory'", "'local'", "'require'", "'payable'", "'function'", "'kill'", "'msg.sender'", "'=='", "'selfdestruct'", "'//'", "'/*'", "'*/'", "'!'", "'private'", "'external'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'<'", "'<='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'", "'%'", "'double'", "'byte'", "'seconds'", "'minutes'", "'hours'", "'days'", "'weeks'", "'years'"
    };
    public static final int T__50=50;
    public static final int RULE_RETURNS=26;
    public static final int RULE_OPENPARENTHESIS=11;
    public static final int RULE_EOLINE=5;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_PARAMSLONGCOMENT=21;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=9;
    public static final int RULE_INT=27;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=28;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__126=126;
    public static final int T__63=63;
    public static final int T__125=125;
    public static final int T__64=64;
    public static final int T__128=128;
    public static final int T__65=65;
    public static final int T__127=127;
    public static final int RULE_TITLELONGCOMENT=24;
    public static final int RULE_EMAIL=14;
    public static final int RULE_NOTICELONGCOMENT=25;
    public static final int T__37=37;
    public static final int RULE_OPENKEY=10;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int RULE_CLOSEPARENTHESIS=12;
    public static final int T__35=35;
    public static final int RULE_IF=19;
    public static final int T__36=36;
    public static final int RULE_DOT=8;
    public static final int T__32=32;
    public static final int RULE_DEVLONGCOMENT=22;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int RULE_FLOAT=15;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__91=91;
    public static final int T__100=100;
    public static final int T__92=92;
    public static final int T__93=93;
    public static final int T__102=102;
    public static final int T__94=94;
    public static final int T__101=101;
    public static final int T__90=90;
    public static final int RULE_SINGLENUMBER=17;
    public static final int T__99=99;
    public static final int RULE_CLOSEKEY=6;
    public static final int T__95=95;
    public static final int T__96=96;
    public static final int T__97=97;
    public static final int T__98=98;
    public static final int RULE_COMMA=16;
    public static final int RULE_RETURNSLONGCOMENT=23;
    public static final int RULE_SEMICOLON=4;
    public static final int RULE_ELSE=20;
    public static final int T__122=122;
    public static final int T__70=70;
    public static final int T__121=121;
    public static final int T__71=71;
    public static final int T__124=124;
    public static final int RULE_BOOLVALUE=18;
    public static final int T__72=72;
    public static final int T__123=123;
    public static final int T__120=120;
    public static final int RULE_STRING=13;
    public static final int RULE_SL_COMMENT=29;
    public static final int T__77=77;
    public static final int T__119=119;
    public static final int T__78=78;
    public static final int T__118=118;
    public static final int T__79=79;
    public static final int T__73=73;
    public static final int T__115=115;
    public static final int EOF=-1;
    public static final int T__74=74;
    public static final int T__114=114;
    public static final int T__75=75;
    public static final int T__117=117;
    public static final int T__76=76;
    public static final int T__116=116;
    public static final int T__80=80;
    public static final int T__111=111;
    public static final int T__81=81;
    public static final int T__110=110;
    public static final int T__82=82;
    public static final int T__113=113;
    public static final int T__83=83;
    public static final int T__112=112;
    public static final int RULE_WS=30;
    public static final int RULE_ANY_OTHER=31;
    public static final int T__88=88;
    public static final int T__108=108;
    public static final int T__89=89;
    public static final int T__107=107;
    public static final int T__109=109;
    public static final int T__84=84;
    public static final int T__104=104;
    public static final int T__85=85;
    public static final int T__103=103;
    public static final int RULE_INTEGER=7;
    public static final int T__86=86;
    public static final int T__106=106;
    public static final int T__87=87;
    public static final int T__105=105;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }



     	private SM2GrammarAccess grammarAccess;

        public InternalSM2Parser(TokenStream input, SM2GrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "SmartContract";
       	}

       	@Override
       	protected SM2GrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleSmartContract"
    // InternalSM2.g:65:1: entryRuleSmartContract returns [EObject current=null] : iv_ruleSmartContract= ruleSmartContract EOF ;
    public final EObject entryRuleSmartContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSmartContract = null;


        try {
            // InternalSM2.g:65:54: (iv_ruleSmartContract= ruleSmartContract EOF )
            // InternalSM2.g:66:2: iv_ruleSmartContract= ruleSmartContract EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSmartContractRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSmartContract=ruleSmartContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSmartContract; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSmartContract"


    // $ANTLR start "ruleSmartContract"
    // InternalSM2.g:72:1: ruleSmartContract returns [EObject current=null] : (otherlv_0= 'pragma' otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY ) ;
    public final EObject ruleSmartContract() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token this_SEMICOLON_3=null;
        Token this_EOLINE_4=null;
        Token this_CLOSEKEY_8=null;
        EObject lv_VersionCompiler_2_0 = null;

        EObject lv_imports_5_0 = null;

        EObject lv_interfaces_6_0 = null;

        EObject lv_contracts_7_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:78:2: ( (otherlv_0= 'pragma' otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY ) )
            // InternalSM2.g:79:2: (otherlv_0= 'pragma' otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY )
            {
            // InternalSM2.g:79:2: (otherlv_0= 'pragma' otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY )
            // InternalSM2.g:80:3: otherlv_0= 'pragma' otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,32,FOLLOW_3); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getSmartContractAccess().getPragmaKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,33,FOLLOW_4); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getSmartContractAccess().getSolidityKeyword_1());
              		
            }
            // InternalSM2.g:88:3: ( (lv_VersionCompiler_2_0= ruleVersion ) )
            // InternalSM2.g:89:4: (lv_VersionCompiler_2_0= ruleVersion )
            {
            // InternalSM2.g:89:4: (lv_VersionCompiler_2_0= ruleVersion )
            // InternalSM2.g:90:5: lv_VersionCompiler_2_0= ruleVersion
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_5);
            lv_VersionCompiler_2_0=ruleVersion();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getSmartContractRule());
              					}
              					set(
              						current,
              						"VersionCompiler",
              						lv_VersionCompiler_2_0,
              						"org.xtext.SM2.Version");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_SEMICOLON_3=(Token)match(input,RULE_SEMICOLON,FOLLOW_6); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_3, grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:111:3: (this_EOLINE_4= RULE_EOLINE )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_EOLINE) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalSM2.g:112:4: this_EOLINE_4= RULE_EOLINE
                    {
                    this_EOLINE_4=(Token)match(input,RULE_EOLINE,FOLLOW_6); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_4, grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:117:3: ( (lv_imports_5_0= ruleLibrary ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==37) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSM2.g:118:4: (lv_imports_5_0= ruleLibrary )
            	    {
            	    // InternalSM2.g:118:4: (lv_imports_5_0= ruleLibrary )
            	    // InternalSM2.g:119:5: lv_imports_5_0= ruleLibrary
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getImportsLibraryParserRuleCall_5_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_6);
            	    lv_imports_5_0=ruleLibrary();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"imports",
            	      						lv_imports_5_0,
            	      						"org.xtext.SM2.Library");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalSM2.g:136:3: ( (lv_interfaces_6_0= ruleInterface ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==39) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalSM2.g:137:4: (lv_interfaces_6_0= ruleInterface )
            	    {
            	    // InternalSM2.g:137:4: (lv_interfaces_6_0= ruleInterface )
            	    // InternalSM2.g:138:5: lv_interfaces_6_0= ruleInterface
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getInterfacesInterfaceParserRuleCall_6_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_6);
            	    lv_interfaces_6_0=ruleInterface();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"interfaces",
            	      						lv_interfaces_6_0,
            	      						"org.xtext.SM2.Interface");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            // InternalSM2.g:155:3: ( (lv_contracts_7_0= ruleContract ) )
            // InternalSM2.g:156:4: (lv_contracts_7_0= ruleContract )
            {
            // InternalSM2.g:156:4: (lv_contracts_7_0= ruleContract )
            // InternalSM2.g:157:5: lv_contracts_7_0= ruleContract
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getSmartContractAccess().getContractsContractParserRuleCall_7_0());
              				
            }
            pushFollow(FOLLOW_7);
            lv_contracts_7_0=ruleContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getSmartContractRule());
              					}
              					add(
              						current,
              						"contracts",
              						lv_contracts_7_0,
              						"org.xtext.SM2.Contract");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEKEY_8=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_8, grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSmartContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:182:1: entryRuleVersion returns [EObject current=null] : iv_ruleVersion= ruleVersion EOF ;
    public final EObject entryRuleVersion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVersion = null;


        try {
            // InternalSM2.g:182:48: (iv_ruleVersion= ruleVersion EOF )
            // InternalSM2.g:183:2: iv_ruleVersion= ruleVersion EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getVersionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleVersion=ruleVersion();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleVersion; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:189:1: ruleVersion returns [EObject current=null] : ( () (otherlv_1= '^' | otherlv_2= '>' | otherlv_3= '>=' ) this_INTEGER_4= RULE_INTEGER this_DOT_5= RULE_DOT this_INTEGER_6= RULE_INTEGER this_DOT_7= RULE_DOT this_INTEGER_8= RULE_INTEGER ( (otherlv_9= RULE_ID ) )? ) ;
    public final EObject ruleVersion() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token this_INTEGER_4=null;
        Token this_DOT_5=null;
        Token this_INTEGER_6=null;
        Token this_DOT_7=null;
        Token this_INTEGER_8=null;
        Token otherlv_9=null;


        	enterRule();

        try {
            // InternalSM2.g:195:2: ( ( () (otherlv_1= '^' | otherlv_2= '>' | otherlv_3= '>=' ) this_INTEGER_4= RULE_INTEGER this_DOT_5= RULE_DOT this_INTEGER_6= RULE_INTEGER this_DOT_7= RULE_DOT this_INTEGER_8= RULE_INTEGER ( (otherlv_9= RULE_ID ) )? ) )
            // InternalSM2.g:196:2: ( () (otherlv_1= '^' | otherlv_2= '>' | otherlv_3= '>=' ) this_INTEGER_4= RULE_INTEGER this_DOT_5= RULE_DOT this_INTEGER_6= RULE_INTEGER this_DOT_7= RULE_DOT this_INTEGER_8= RULE_INTEGER ( (otherlv_9= RULE_ID ) )? )
            {
            // InternalSM2.g:196:2: ( () (otherlv_1= '^' | otherlv_2= '>' | otherlv_3= '>=' ) this_INTEGER_4= RULE_INTEGER this_DOT_5= RULE_DOT this_INTEGER_6= RULE_INTEGER this_DOT_7= RULE_DOT this_INTEGER_8= RULE_INTEGER ( (otherlv_9= RULE_ID ) )? )
            // InternalSM2.g:197:3: () (otherlv_1= '^' | otherlv_2= '>' | otherlv_3= '>=' ) this_INTEGER_4= RULE_INTEGER this_DOT_5= RULE_DOT this_INTEGER_6= RULE_INTEGER this_DOT_7= RULE_DOT this_INTEGER_8= RULE_INTEGER ( (otherlv_9= RULE_ID ) )?
            {
            // InternalSM2.g:197:3: ()
            // InternalSM2.g:198:4: 
            {
            if ( state.backtracking==0 ) {

              				current = forceCreateModelElement(
              					grammarAccess.getVersionAccess().getVersionAction_0(),
              					current);
              			
            }

            }

            // InternalSM2.g:204:3: (otherlv_1= '^' | otherlv_2= '>' | otherlv_3= '>=' )
            int alt4=3;
            switch ( input.LA(1) ) {
            case 34:
                {
                alt4=1;
                }
                break;
            case 35:
                {
                alt4=2;
                }
                break;
            case 36:
                {
                alt4=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // InternalSM2.g:205:4: otherlv_1= '^'
                    {
                    otherlv_1=(Token)match(input,34,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_1, grammarAccess.getVersionAccess().getCircumflexAccentKeyword_1_0());
                      			
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:210:4: otherlv_2= '>'
                    {
                    otherlv_2=(Token)match(input,35,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getVersionAccess().getGreaterThanSignKeyword_1_1());
                      			
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:215:4: otherlv_3= '>='
                    {
                    otherlv_3=(Token)match(input,36,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_3, grammarAccess.getVersionAccess().getGreaterThanSignEqualsSignKeyword_1_2());
                      			
                    }

                    }
                    break;

            }

            this_INTEGER_4=(Token)match(input,RULE_INTEGER,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_INTEGER_4, grammarAccess.getVersionAccess().getINTEGERTerminalRuleCall_2());
              		
            }
            this_DOT_5=(Token)match(input,RULE_DOT,FOLLOW_8); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_DOT_5, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_3());
              		
            }
            this_INTEGER_6=(Token)match(input,RULE_INTEGER,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_INTEGER_6, grammarAccess.getVersionAccess().getINTEGERTerminalRuleCall_4());
              		
            }
            this_DOT_7=(Token)match(input,RULE_DOT,FOLLOW_8); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_DOT_7, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_5());
              		
            }
            this_INTEGER_8=(Token)match(input,RULE_INTEGER,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_INTEGER_8, grammarAccess.getVersionAccess().getINTEGERTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:240:3: ( (otherlv_9= RULE_ID ) )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==RULE_ID) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalSM2.g:241:4: (otherlv_9= RULE_ID )
                    {
                    // InternalSM2.g:241:4: (otherlv_9= RULE_ID )
                    // InternalSM2.g:242:5: otherlv_9= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getVersionRule());
                      					}
                      				
                    }
                    otherlv_9=(Token)match(input,RULE_ID,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_9, grammarAccess.getVersionAccess().getOptionalversionVersionCrossReference_7_0());
                      				
                    }

                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleLibrary"
    // InternalSM2.g:257:1: entryRuleLibrary returns [EObject current=null] : iv_ruleLibrary= ruleLibrary EOF ;
    public final EObject entryRuleLibrary() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLibrary = null;


        try {
            // InternalSM2.g:257:48: (iv_ruleLibrary= ruleLibrary EOF )
            // InternalSM2.g:258:2: iv_ruleLibrary= ruleLibrary EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLibraryRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLibrary=ruleLibrary();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLibrary; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLibrary"


    // $ANTLR start "ruleLibrary"
    // InternalSM2.g:264:1: ruleLibrary returns [EObject current=null] : (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) ;
    public final EObject ruleLibrary() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameLibrary_1_0=null;
        Token otherlv_2=null;
        Token lv_alias_3_0=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;


        	enterRule();

        try {
            // InternalSM2.g:270:2: ( (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:271:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:271:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:272:3: otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,37,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getLibraryAccess().getImportKeyword_0());
              		
            }
            // InternalSM2.g:276:3: ( (lv_nameLibrary_1_0= RULE_ID ) )
            // InternalSM2.g:277:4: (lv_nameLibrary_1_0= RULE_ID )
            {
            // InternalSM2.g:277:4: (lv_nameLibrary_1_0= RULE_ID )
            // InternalSM2.g:278:5: lv_nameLibrary_1_0= RULE_ID
            {
            lv_nameLibrary_1_0=(Token)match(input,RULE_ID,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameLibrary_1_0, grammarAccess.getLibraryAccess().getNameLibraryIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getLibraryRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameLibrary",
              						lv_nameLibrary_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:294:3: (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==38) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalSM2.g:295:4: otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,38,FOLLOW_11); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getLibraryAccess().getAsKeyword_2_0());
                      			
                    }
                    // InternalSM2.g:299:4: ( (lv_alias_3_0= RULE_ID ) )
                    // InternalSM2.g:300:5: (lv_alias_3_0= RULE_ID )
                    {
                    // InternalSM2.g:300:5: (lv_alias_3_0= RULE_ID )
                    // InternalSM2.g:301:6: lv_alias_3_0= RULE_ID
                    {
                    lv_alias_3_0=(Token)match(input,RULE_ID,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_alias_3_0, grammarAccess.getLibraryAccess().getAliasIDTerminalRuleCall_2_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLibraryRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"alias",
                      							lv_alias_3_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_4, grammarAccess.getLibraryAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:322:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==RULE_EOLINE) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalSM2.g:323:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_5, grammarAccess.getLibraryAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLibrary"


    // $ANTLR start "entryRuleInterface"
    // InternalSM2.g:332:1: entryRuleInterface returns [EObject current=null] : iv_ruleInterface= ruleInterface EOF ;
    public final EObject entryRuleInterface() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInterface = null;


        try {
            // InternalSM2.g:332:50: (iv_ruleInterface= ruleInterface EOF )
            // InternalSM2.g:333:2: iv_ruleInterface= ruleInterface EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getInterfaceRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleInterface=ruleInterface();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleInterface; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInterface"


    // $ANTLR start "ruleInterface"
    // InternalSM2.g:339:1: ruleInterface returns [EObject current=null] : (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) )* this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE ) ;
    public final EObject ruleInterface() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameInterface_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;
        Token this_CLOSEKEY_7=null;
        Token this_EOLINE_8=null;


        	enterRule();

        try {
            // InternalSM2.g:345:2: ( (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) )* this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE ) )
            // InternalSM2.g:346:2: (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) )* this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE )
            {
            // InternalSM2.g:346:2: (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) )* this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE )
            // InternalSM2.g:347:3: otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) )* this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,39,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getInterfaceAccess().getInterfaceKeyword_0());
              		
            }
            // InternalSM2.g:351:3: ( (lv_nameInterface_1_0= RULE_ID ) )
            // InternalSM2.g:352:4: (lv_nameInterface_1_0= RULE_ID )
            {
            // InternalSM2.g:352:4: (lv_nameInterface_1_0= RULE_ID )
            // InternalSM2.g:353:5: lv_nameInterface_1_0= RULE_ID
            {
            lv_nameInterface_1_0=(Token)match(input,RULE_ID,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameInterface_1_0, grammarAccess.getInterfaceAccess().getNameInterfaceIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getInterfaceRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameInterface",
              						lv_nameInterface_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getInterfaceAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_3, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_3());
              		
            }
            // InternalSM2.g:377:3: ( (otherlv_4= RULE_ID ) )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==RULE_ID) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalSM2.g:378:4: (otherlv_4= RULE_ID )
            	    {
            	    // InternalSM2.g:378:4: (otherlv_4= RULE_ID )
            	    // InternalSM2.g:379:5: otherlv_4= RULE_ID
            	    {
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElement(grammarAccess.getInterfaceRule());
            	      					}
            	      				
            	    }
            	    otherlv_4=(Token)match(input,RULE_ID,FOLLOW_16); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_4, grammarAccess.getInterfaceAccess().getFunctionsHeadClauseCrossReference_4_0());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_5, grammarAccess.getInterfaceAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_6, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_6());
              		
            }
            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_7, grammarAccess.getInterfaceAccess().getCLOSEKEYTerminalRuleCall_7());
              		
            }
            this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_8, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInterface"


    // $ANTLR start "entryRuleContract"
    // InternalSM2.g:410:1: entryRuleContract returns [EObject current=null] : iv_ruleContract= ruleContract EOF ;
    public final EObject entryRuleContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleContract = null;


        try {
            // InternalSM2.g:410:49: (iv_ruleContract= ruleContract EOF )
            // InternalSM2.g:411:2: iv_ruleContract= ruleContract EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getContractRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleContract=ruleContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleContract; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleContract"


    // $ANTLR start "ruleContract"
    // InternalSM2.g:417:1: ruleContract returns [EObject current=null] : ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* ) ;
    public final EObject ruleContract() throws RecognitionException {
        EObject current = null;

        Token lv_contract_0_0=null;
        Token lv_nameContract_1_0=null;
        Token otherlv_2=null;
        Token lv_nameContractFather_3_0=null;
        Token this_OPENKEY_4=null;
        Token this_EOLINE_5=null;
        EObject lv_attributes_6_0 = null;

        EObject lv_constructor_7_0 = null;

        EObject lv_events_8_0 = null;

        EObject lv_modifier_9_0 = null;

        EObject lv_functions_10_0 = null;

        EObject lv_comments_11_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:423:2: ( ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* ) )
            // InternalSM2.g:424:2: ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* )
            {
            // InternalSM2.g:424:2: ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* )
            // InternalSM2.g:425:3: ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )*
            {
            // InternalSM2.g:425:3: ( (lv_contract_0_0= 'contract' ) )
            // InternalSM2.g:426:4: (lv_contract_0_0= 'contract' )
            {
            // InternalSM2.g:426:4: (lv_contract_0_0= 'contract' )
            // InternalSM2.g:427:5: lv_contract_0_0= 'contract'
            {
            lv_contract_0_0=(Token)match(input,40,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_contract_0_0, grammarAccess.getContractAccess().getContractContractKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getContractRule());
              					}
              					setWithLastConsumed(current, "contract", lv_contract_0_0, "contract");
              				
            }

            }


            }

            // InternalSM2.g:439:3: ( (lv_nameContract_1_0= RULE_ID ) )
            // InternalSM2.g:440:4: (lv_nameContract_1_0= RULE_ID )
            {
            // InternalSM2.g:440:4: (lv_nameContract_1_0= RULE_ID )
            // InternalSM2.g:441:5: lv_nameContract_1_0= RULE_ID
            {
            lv_nameContract_1_0=(Token)match(input,RULE_ID,FOLLOW_17); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameContract_1_0, grammarAccess.getContractAccess().getNameContractIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getContractRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameContract",
              						lv_nameContract_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:457:3: (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==41) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalSM2.g:458:4: otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,41,FOLLOW_11); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getContractAccess().getIsKeyword_2_0());
                      			
                    }
                    // InternalSM2.g:462:4: ( (lv_nameContractFather_3_0= RULE_ID ) )
                    // InternalSM2.g:463:5: (lv_nameContractFather_3_0= RULE_ID )
                    {
                    // InternalSM2.g:463:5: (lv_nameContractFather_3_0= RULE_ID )
                    // InternalSM2.g:464:6: lv_nameContractFather_3_0= RULE_ID
                    {
                    lv_nameContractFather_3_0=(Token)match(input,RULE_ID,FOLLOW_14); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_nameContractFather_3_0, grammarAccess.getContractAccess().getNameContractFatherIDTerminalRuleCall_2_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getContractRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"nameContractFather",
                      							lv_nameContractFather_3_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_OPENKEY_4=(Token)match(input,RULE_OPENKEY,FOLLOW_18); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_4, grammarAccess.getContractAccess().getOPENKEYTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:485:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==RULE_EOLINE) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalSM2.g:486:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_19); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_5, grammarAccess.getContractAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:491:3: ( (lv_attributes_6_0= ruleAttributes ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==RULE_ID||LA11_0==65||(LA11_0>=67 && LA11_0<=68)||(LA11_0>=70 && LA11_0<=71)||LA11_0==73||(LA11_0>=77 && LA11_0<=89)) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalSM2.g:492:4: (lv_attributes_6_0= ruleAttributes )
            	    {
            	    // InternalSM2.g:492:4: (lv_attributes_6_0= ruleAttributes )
            	    // InternalSM2.g:493:5: lv_attributes_6_0= ruleAttributes
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getAttributesAttributesParserRuleCall_5_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_19);
            	    lv_attributes_6_0=ruleAttributes();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"attributes",
            	      						lv_attributes_6_0,
            	      						"org.xtext.SM2.Attributes");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

            // InternalSM2.g:510:3: ( (lv_constructor_7_0= ruleConstructor ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==59) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalSM2.g:511:4: (lv_constructor_7_0= ruleConstructor )
                    {
                    // InternalSM2.g:511:4: (lv_constructor_7_0= ruleConstructor )
                    // InternalSM2.g:512:5: lv_constructor_7_0= ruleConstructor
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getContractAccess().getConstructorConstructorParserRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_20);
                    lv_constructor_7_0=ruleConstructor();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getContractRule());
                      					}
                      					set(
                      						current,
                      						"constructor",
                      						lv_constructor_7_0,
                      						"org.xtext.SM2.Constructor");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:529:3: ( (lv_events_8_0= ruleEvent ) )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==62) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalSM2.g:530:4: (lv_events_8_0= ruleEvent )
            	    {
            	    // InternalSM2.g:530:4: (lv_events_8_0= ruleEvent )
            	    // InternalSM2.g:531:5: lv_events_8_0= ruleEvent
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getEventsEventParserRuleCall_7_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_20);
            	    lv_events_8_0=ruleEvent();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"events",
            	      						lv_events_8_0,
            	      						"org.xtext.SM2.Event");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

            // InternalSM2.g:548:3: ( (lv_modifier_9_0= ruleModifier ) )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==63) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // InternalSM2.g:549:4: (lv_modifier_9_0= ruleModifier )
            	    {
            	    // InternalSM2.g:549:4: (lv_modifier_9_0= ruleModifier )
            	    // InternalSM2.g:550:5: lv_modifier_9_0= ruleModifier
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getModifierModifierParserRuleCall_8_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_21);
            	    lv_modifier_9_0=ruleModifier();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"modifier",
            	      						lv_modifier_9_0,
            	      						"org.xtext.SM2.Modifier");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);

            // InternalSM2.g:567:3: ( (lv_functions_10_0= ruleFunction ) )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==94) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalSM2.g:568:4: (lv_functions_10_0= ruleFunction )
            	    {
            	    // InternalSM2.g:568:4: (lv_functions_10_0= ruleFunction )
            	    // InternalSM2.g:569:5: lv_functions_10_0= ruleFunction
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getFunctionsFunctionParserRuleCall_9_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_22);
            	    lv_functions_10_0=ruleFunction();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"functions",
            	      						lv_functions_10_0,
            	      						"org.xtext.SM2.Function");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

            // InternalSM2.g:586:3: ( (lv_comments_11_0= ruleComment ) )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( ((LA16_0>=99 && LA16_0<=100)) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // InternalSM2.g:587:4: (lv_comments_11_0= ruleComment )
            	    {
            	    // InternalSM2.g:587:4: (lv_comments_11_0= ruleComment )
            	    // InternalSM2.g:588:5: lv_comments_11_0= ruleComment
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getCommentsCommentParserRuleCall_10_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_23);
            	    lv_comments_11_0=ruleComment();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"comments",
            	      						lv_comments_11_0,
            	      						"org.xtext.SM2.Comment");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleContract"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:609:1: entryRuleAttributes returns [EObject current=null] : iv_ruleAttributes= ruleAttributes EOF ;
    public final EObject entryRuleAttributes() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttributes = null;


        try {
            // InternalSM2.g:609:51: (iv_ruleAttributes= ruleAttributes EOF )
            // InternalSM2.g:610:2: iv_ruleAttributes= ruleAttributes EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getAttributesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleAttributes=ruleAttributes();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleAttributes; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:616:1: ruleAttributes returns [EObject current=null] : (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) ;
    public final EObject ruleAttributes() throws RecognitionException {
        EObject current = null;

        EObject this_Property_0 = null;

        EObject this_DataType_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:622:2: ( (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) )
            // InternalSM2.g:623:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            {
            // InternalSM2.g:623:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==RULE_ID||LA17_0==68||(LA17_0>=70 && LA17_0<=71)||(LA17_0>=77 && LA17_0<=89)) ) {
                alt17=1;
            }
            else if ( (LA17_0==65||LA17_0==67||LA17_0==73) ) {
                alt17=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }
            switch (alt17) {
                case 1 :
                    // InternalSM2.g:624:3: this_Property_0= ruleProperty
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Property_0=ruleProperty();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Property_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:633:3: this_DataType_1= ruleDataType
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_DataType_1=ruleDataType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_DataType_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleVariables"
    // InternalSM2.g:645:1: entryRuleVariables returns [EObject current=null] : iv_ruleVariables= ruleVariables EOF ;
    public final EObject entryRuleVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariables = null;


        try {
            // InternalSM2.g:645:50: (iv_ruleVariables= ruleVariables EOF )
            // InternalSM2.g:646:2: iv_ruleVariables= ruleVariables EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getVariablesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleVariables=ruleVariables();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleVariables; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariables"


    // $ANTLR start "ruleVariables"
    // InternalSM2.g:652:1: ruleVariables returns [EObject current=null] : (this_MSGVariables_0= ruleMSGVariables | this_BlockVariables_1= ruleBlockVariables | this_Thx_2= ruleThx ) ;
    public final EObject ruleVariables() throws RecognitionException {
        EObject current = null;

        EObject this_MSGVariables_0 = null;

        EObject this_BlockVariables_1 = null;

        EObject this_Thx_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:658:2: ( (this_MSGVariables_0= ruleMSGVariables | this_BlockVariables_1= ruleBlockVariables | this_Thx_2= ruleThx ) )
            // InternalSM2.g:659:2: (this_MSGVariables_0= ruleMSGVariables | this_BlockVariables_1= ruleBlockVariables | this_Thx_2= ruleThx )
            {
            // InternalSM2.g:659:2: (this_MSGVariables_0= ruleMSGVariables | this_BlockVariables_1= ruleBlockVariables | this_Thx_2= ruleThx )
            int alt18=3;
            switch ( input.LA(1) ) {
            case 42:
                {
                alt18=1;
                }
                break;
            case 48:
            case 55:
                {
                alt18=2;
                }
                break;
            case 56:
                {
                alt18=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }

            switch (alt18) {
                case 1 :
                    // InternalSM2.g:660:3: this_MSGVariables_0= ruleMSGVariables
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getVariablesAccess().getMSGVariablesParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_MSGVariables_0=ruleMSGVariables();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_MSGVariables_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:669:3: this_BlockVariables_1= ruleBlockVariables
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getVariablesAccess().getBlockVariablesParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_BlockVariables_1=ruleBlockVariables();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_BlockVariables_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:678:3: this_Thx_2= ruleThx
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getVariablesAccess().getThxParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Thx_2=ruleThx();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Thx_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariables"


    // $ANTLR start "entryRuleMSGVariables"
    // InternalSM2.g:690:1: entryRuleMSGVariables returns [EObject current=null] : iv_ruleMSGVariables= ruleMSGVariables EOF ;
    public final EObject entryRuleMSGVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMSGVariables = null;


        try {
            // InternalSM2.g:690:53: (iv_ruleMSGVariables= ruleMSGVariables EOF )
            // InternalSM2.g:691:2: iv_ruleMSGVariables= ruleMSGVariables EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMSGVariablesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleMSGVariables=ruleMSGVariables();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleMSGVariables; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMSGVariables"


    // $ANTLR start "ruleMSGVariables"
    // InternalSM2.g:697:1: ruleMSGVariables returns [EObject current=null] : (otherlv_0= 'msg' this_DOT_1= RULE_DOT ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) ) (this_SEMICOLON_27= RULE_SEMICOLON )? ) ;
    public final EObject ruleMSGVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_DOT_1=null;
        Token otherlv_2=null;
        Token this_OPENPARENTHESIS_3=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token otherlv_7=null;
        Token this_OPENPARENTHESIS_8=null;
        Token this_CLOSEPARENTHESIS_11=null;
        Token otherlv_12=null;
        Token this_OPENPARENTHESIS_13=null;
        Token this_CLOSEPARENTHESIS_16=null;
        Token otherlv_17=null;
        Token this_OPENPARENTHESIS_18=null;
        Token this_CLOSEPARENTHESIS_21=null;
        Token otherlv_22=null;
        Token this_OPENPARENTHESIS_23=null;
        Token this_CLOSEPARENTHESIS_26=null;
        Token this_SEMICOLON_27=null;
        EObject this_PropertyBytes_4 = null;

        EObject this_SyntaxExpression_5 = null;

        EObject this_PropertyInteger_9 = null;

        EObject this_SyntaxExpression_10 = null;

        EObject this_PropertyInteger_14 = null;

        EObject this_SyntaxExpression_15 = null;

        EObject this_PropertyAddress_19 = null;

        EObject this_SyntaxExpression_20 = null;

        EObject this_PropertyBytes_24 = null;

        EObject this_SyntaxExpression_25 = null;



        	enterRule();

        try {
            // InternalSM2.g:703:2: ( (otherlv_0= 'msg' this_DOT_1= RULE_DOT ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) ) (this_SEMICOLON_27= RULE_SEMICOLON )? ) )
            // InternalSM2.g:704:2: (otherlv_0= 'msg' this_DOT_1= RULE_DOT ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) ) (this_SEMICOLON_27= RULE_SEMICOLON )? )
            {
            // InternalSM2.g:704:2: (otherlv_0= 'msg' this_DOT_1= RULE_DOT ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) ) (this_SEMICOLON_27= RULE_SEMICOLON )? )
            // InternalSM2.g:705:3: otherlv_0= 'msg' this_DOT_1= RULE_DOT ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) ) (this_SEMICOLON_27= RULE_SEMICOLON )?
            {
            otherlv_0=(Token)match(input,42,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getMSGVariablesAccess().getMsgKeyword_0());
              		
            }
            this_DOT_1=(Token)match(input,RULE_DOT,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_DOT_1, grammarAccess.getMSGVariablesAccess().getDOTTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:713:3: ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) )
            int alt24=5;
            switch ( input.LA(1) ) {
            case 43:
                {
                alt24=1;
                }
                break;
            case 44:
                {
                alt24=2;
                }
                break;
            case 45:
                {
                alt24=3;
                }
                break;
            case 46:
                {
                alt24=4;
                }
                break;
            case 47:
                {
                alt24=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }

            switch (alt24) {
                case 1 :
                    // InternalSM2.g:714:4: (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:714:4: (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:715:5: otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS
                    {
                    otherlv_2=(Token)match(input,43,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_2, grammarAccess.getMSGVariablesAccess().getDataKeyword_2_0_0());
                      				
                    }
                    this_OPENPARENTHESIS_3=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_3, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_0_1());
                      				
                    }
                    // InternalSM2.g:723:5: (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression )
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( ((LA19_0>=85 && LA19_0<=89)) ) {
                        alt19=1;
                    }
                    else if ( (LA19_0==RULE_INTEGER||LA19_0==RULE_STRING||LA19_0==RULE_FLOAT) ) {
                        alt19=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 19, 0, input);

                        throw nvae;
                    }
                    switch (alt19) {
                        case 1 :
                            // InternalSM2.g:724:6: this_PropertyBytes_4= rulePropertyBytes
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyBytesParserRuleCall_2_0_2_0());
                              					
                            }
                            pushFollow(FOLLOW_27);
                            this_PropertyBytes_4=rulePropertyBytes();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_PropertyBytes_4;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:733:6: this_SyntaxExpression_5= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_0_2_1());
                              					
                            }
                            pushFollow(FOLLOW_27);
                            this_SyntaxExpression_5=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_5;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_0_3());
                      				
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:748:4: (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:748:4: (otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:749:5: otherlv_7= 'value' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS
                    {
                    otherlv_7=(Token)match(input,44,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_7, grammarAccess.getMSGVariablesAccess().getValueKeyword_2_1_0());
                      				
                    }
                    this_OPENPARENTHESIS_8=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_8, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_1_1());
                      				
                    }
                    // InternalSM2.g:757:5: (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression )
                    int alt20=2;
                    int LA20_0 = input.LA(1);

                    if ( ((LA20_0>=77 && LA20_0<=82)) ) {
                        alt20=1;
                    }
                    else if ( (LA20_0==RULE_INTEGER||LA20_0==RULE_STRING||LA20_0==RULE_FLOAT) ) {
                        alt20=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 20, 0, input);

                        throw nvae;
                    }
                    switch (alt20) {
                        case 1 :
                            // InternalSM2.g:758:6: this_PropertyInteger_9= rulePropertyInteger
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyIntegerParserRuleCall_2_1_2_0());
                              					
                            }
                            pushFollow(FOLLOW_27);
                            this_PropertyInteger_9=rulePropertyInteger();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_PropertyInteger_9;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:767:6: this_SyntaxExpression_10= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_1_2_1());
                              					
                            }
                            pushFollow(FOLLOW_27);
                            this_SyntaxExpression_10=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_10;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_11=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_11, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_1_3());
                      				
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:782:4: (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:782:4: (otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:783:5: otherlv_12= 'gas' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS
                    {
                    otherlv_12=(Token)match(input,45,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_12, grammarAccess.getMSGVariablesAccess().getGasKeyword_2_2_0());
                      				
                    }
                    this_OPENPARENTHESIS_13=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_13, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_2_1());
                      				
                    }
                    // InternalSM2.g:791:5: (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression )
                    int alt21=2;
                    int LA21_0 = input.LA(1);

                    if ( ((LA21_0>=77 && LA21_0<=82)) ) {
                        alt21=1;
                    }
                    else if ( (LA21_0==RULE_INTEGER||LA21_0==RULE_STRING||LA21_0==RULE_FLOAT) ) {
                        alt21=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 21, 0, input);

                        throw nvae;
                    }
                    switch (alt21) {
                        case 1 :
                            // InternalSM2.g:792:6: this_PropertyInteger_14= rulePropertyInteger
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyIntegerParserRuleCall_2_2_2_0());
                              					
                            }
                            pushFollow(FOLLOW_27);
                            this_PropertyInteger_14=rulePropertyInteger();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_PropertyInteger_14;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:801:6: this_SyntaxExpression_15= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_2_2_1());
                              					
                            }
                            pushFollow(FOLLOW_27);
                            this_SyntaxExpression_15=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_15;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_16=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_16, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_2_3());
                      				
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:816:4: (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:816:4: (otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:817:5: otherlv_17= 'sender' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS
                    {
                    otherlv_17=(Token)match(input,46,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_17, grammarAccess.getMSGVariablesAccess().getSenderKeyword_2_3_0());
                      				
                    }
                    this_OPENPARENTHESIS_18=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_30); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_18, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_3_1());
                      				
                    }
                    // InternalSM2.g:825:5: (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression )
                    int alt22=2;
                    int LA22_0 = input.LA(1);

                    if ( (LA22_0==68||LA22_0==84) ) {
                        alt22=1;
                    }
                    else if ( (LA22_0==RULE_INTEGER||LA22_0==RULE_STRING||LA22_0==RULE_FLOAT) ) {
                        alt22=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 22, 0, input);

                        throw nvae;
                    }
                    switch (alt22) {
                        case 1 :
                            // InternalSM2.g:826:6: this_PropertyAddress_19= rulePropertyAddress
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyAddressParserRuleCall_2_3_2_0());
                              					
                            }
                            pushFollow(FOLLOW_27);
                            this_PropertyAddress_19=rulePropertyAddress();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_PropertyAddress_19;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:835:6: this_SyntaxExpression_20= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_3_2_1());
                              					
                            }
                            pushFollow(FOLLOW_27);
                            this_SyntaxExpression_20=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_20;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_21=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_21, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_3_3());
                      				
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:850:4: (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:850:4: (otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:851:5: otherlv_22= 'sig' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS
                    {
                    otherlv_22=(Token)match(input,47,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_22, grammarAccess.getMSGVariablesAccess().getSigKeyword_2_4_0());
                      				
                    }
                    this_OPENPARENTHESIS_23=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_23, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_4_1());
                      				
                    }
                    // InternalSM2.g:859:5: (this_PropertyBytes_24= rulePropertyBytes | this_SyntaxExpression_25= ruleSyntaxExpression )
                    int alt23=2;
                    int LA23_0 = input.LA(1);

                    if ( ((LA23_0>=85 && LA23_0<=89)) ) {
                        alt23=1;
                    }
                    else if ( (LA23_0==RULE_INTEGER||LA23_0==RULE_STRING||LA23_0==RULE_FLOAT) ) {
                        alt23=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 23, 0, input);

                        throw nvae;
                    }
                    switch (alt23) {
                        case 1 :
                            // InternalSM2.g:860:6: this_PropertyBytes_24= rulePropertyBytes
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyBytesParserRuleCall_2_4_2_0());
                              					
                            }
                            pushFollow(FOLLOW_27);
                            this_PropertyBytes_24=rulePropertyBytes();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_PropertyBytes_24;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:869:6: this_SyntaxExpression_25= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_4_2_1());
                              					
                            }
                            pushFollow(FOLLOW_27);
                            this_SyntaxExpression_25=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_25;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_26=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_26, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_4_3());
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:884:3: (this_SEMICOLON_27= RULE_SEMICOLON )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==RULE_SEMICOLON) ) {
                int LA25_1 = input.LA(2);

                if ( (LA25_1==RULE_EOLINE) ) {
                    int LA25_3 = input.LA(3);

                    if ( (LA25_3==RULE_CLOSEKEY) ) {
                        alt25=1;
                    }
                }
                else if ( (LA25_1==EOF||LA25_1==RULE_SEMICOLON||(LA25_1>=RULE_CLOSEKEY && LA25_1<=RULE_INTEGER)||(LA25_1>=RULE_OPENPARENTHESIS && LA25_1<=RULE_STRING)||LA25_1==RULE_FLOAT||LA25_1==42||LA25_1==48||(LA25_1>=55 && LA25_1<=56)) ) {
                    alt25=1;
                }
            }
            switch (alt25) {
                case 1 :
                    // InternalSM2.g:885:4: this_SEMICOLON_27= RULE_SEMICOLON
                    {
                    this_SEMICOLON_27=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_27, grammarAccess.getMSGVariablesAccess().getSEMICOLONTerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMSGVariables"


    // $ANTLR start "entryRuleBlockVariables"
    // InternalSM2.g:894:1: entryRuleBlockVariables returns [EObject current=null] : iv_ruleBlockVariables= ruleBlockVariables EOF ;
    public final EObject entryRuleBlockVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBlockVariables = null;


        try {
            // InternalSM2.g:894:55: (iv_ruleBlockVariables= ruleBlockVariables EOF )
            // InternalSM2.g:895:2: iv_ruleBlockVariables= ruleBlockVariables EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getBlockVariablesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleBlockVariables=ruleBlockVariables();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleBlockVariables; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBlockVariables"


    // $ANTLR start "ruleBlockVariables"
    // InternalSM2.g:901:1: ruleBlockVariables returns [EObject current=null] : ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS (this_SEMICOLON_37= RULE_SEMICOLON )? ) ) ;
    public final EObject ruleBlockVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_DOT_1=null;
        Token otherlv_2=null;
        Token this_OPENPARENTHESIS_3=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token otherlv_7=null;
        Token this_OPENPARENTHESIS_8=null;
        Token this_CLOSEPARENTHESIS_11=null;
        Token otherlv_12=null;
        Token this_OPENPARENTHESIS_13=null;
        Token this_CLOSEPARENTHESIS_16=null;
        Token otherlv_17=null;
        Token this_OPENPARENTHESIS_18=null;
        Token this_CLOSEPARENTHESIS_21=null;
        Token otherlv_22=null;
        Token this_OPENPARENTHESIS_23=null;
        Token this_CLOSEPARENTHESIS_26=null;
        Token otherlv_27=null;
        Token this_OPENPARENTHESIS_28=null;
        Token this_CLOSEPARENTHESIS_31=null;
        Token otherlv_32=null;
        Token this_OPENPARENTHESIS_33=null;
        Token this_CLOSEPARENTHESIS_36=null;
        Token this_SEMICOLON_37=null;
        EObject this_PropertyInteger_4 = null;

        EObject this_SyntaxExpression_5 = null;

        EObject this_PropertyInteger_9 = null;

        EObject this_SyntaxExpression_10 = null;

        EObject this_PropertyInteger_14 = null;

        EObject this_SyntaxExpression_15 = null;

        EObject this_PropertyAddress_19 = null;

        EObject this_SyntaxExpression_20 = null;

        EObject this_PropertyInteger_24 = null;

        EObject this_SyntaxExpression_25 = null;

        EObject this_PropertyInteger_29 = null;

        EObject this_SyntaxExpression_30 = null;

        EObject this_PropertyInteger_34 = null;

        EObject this_SyntaxExpression_35 = null;



        	enterRule();

        try {
            // InternalSM2.g:907:2: ( ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS (this_SEMICOLON_37= RULE_SEMICOLON )? ) ) )
            // InternalSM2.g:908:2: ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS (this_SEMICOLON_37= RULE_SEMICOLON )? ) )
            {
            // InternalSM2.g:908:2: ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS (this_SEMICOLON_37= RULE_SEMICOLON )? ) )
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==48) ) {
                alt35=1;
            }
            else if ( (LA35_0==55) ) {
                alt35=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 35, 0, input);

                throw nvae;
            }
            switch (alt35) {
                case 1 :
                    // InternalSM2.g:909:3: (otherlv_0= 'block' this_DOT_1= RULE_DOT ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) ) )
                    {
                    // InternalSM2.g:909:3: (otherlv_0= 'block' this_DOT_1= RULE_DOT ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) ) )
                    // InternalSM2.g:910:4: otherlv_0= 'block' this_DOT_1= RULE_DOT ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) )
                    {
                    otherlv_0=(Token)match(input,48,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_0, grammarAccess.getBlockVariablesAccess().getBlockKeyword_0_0());
                      			
                    }
                    this_DOT_1=(Token)match(input,RULE_DOT,FOLLOW_31); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_1, grammarAccess.getBlockVariablesAccess().getDOTTerminalRuleCall_0_1());
                      			
                    }
                    // InternalSM2.g:918:4: ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) | (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS ) | (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS ) | (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS ) | (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS ) )
                    int alt32=6;
                    switch ( input.LA(1) ) {
                    case 49:
                        {
                        alt32=1;
                        }
                        break;
                    case 50:
                        {
                        alt32=2;
                        }
                        break;
                    case 51:
                        {
                        alt32=3;
                        }
                        break;
                    case 52:
                        {
                        alt32=4;
                        }
                        break;
                    case 53:
                        {
                        alt32=5;
                        }
                        break;
                    case 54:
                        {
                        alt32=6;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 32, 0, input);

                        throw nvae;
                    }

                    switch (alt32) {
                        case 1 :
                            // InternalSM2.g:919:5: (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:919:5: (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:920:6: otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_2=(Token)match(input,49,FOLLOW_25); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_2, grammarAccess.getBlockVariablesAccess().getDifficultyKeyword_0_2_0_0());
                              					
                            }
                            this_OPENPARENTHESIS_3=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_3, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_0_1());
                              					
                            }
                            // InternalSM2.g:928:6: (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression )
                            int alt26=2;
                            int LA26_0 = input.LA(1);

                            if ( ((LA26_0>=77 && LA26_0<=82)) ) {
                                alt26=1;
                            }
                            else if ( (LA26_0==RULE_INTEGER||LA26_0==RULE_STRING||LA26_0==RULE_FLOAT) ) {
                                alt26=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 26, 0, input);

                                throw nvae;
                            }
                            switch (alt26) {
                                case 1 :
                                    // InternalSM2.g:929:7: this_PropertyInteger_4= rulePropertyInteger
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_0_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_27);
                                    this_PropertyInteger_4=rulePropertyInteger();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyInteger_4;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:938:7: this_SyntaxExpression_5= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_0_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_27);
                                    this_SyntaxExpression_5=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_5;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_0_3());
                              					
                            }

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:953:5: (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:953:5: (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:954:6: otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_7=(Token)match(input,50,FOLLOW_25); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_7, grammarAccess.getBlockVariablesAccess().getNumberKeyword_0_2_1_0());
                              					
                            }
                            this_OPENPARENTHESIS_8=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_8, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_1_1());
                              					
                            }
                            // InternalSM2.g:962:6: (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression )
                            int alt27=2;
                            int LA27_0 = input.LA(1);

                            if ( ((LA27_0>=77 && LA27_0<=82)) ) {
                                alt27=1;
                            }
                            else if ( (LA27_0==RULE_INTEGER||LA27_0==RULE_STRING||LA27_0==RULE_FLOAT) ) {
                                alt27=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 27, 0, input);

                                throw nvae;
                            }
                            switch (alt27) {
                                case 1 :
                                    // InternalSM2.g:963:7: this_PropertyInteger_9= rulePropertyInteger
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_1_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_27);
                                    this_PropertyInteger_9=rulePropertyInteger();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyInteger_9;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:972:7: this_SyntaxExpression_10= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_1_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_27);
                                    this_SyntaxExpression_10=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_10;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_11=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_11, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_1_3());
                              					
                            }

                            }


                            }
                            break;
                        case 3 :
                            // InternalSM2.g:987:5: (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:987:5: (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:988:6: otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_12=(Token)match(input,51,FOLLOW_25); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_12, grammarAccess.getBlockVariablesAccess().getTimestampKeyword_0_2_2_0());
                              					
                            }
                            this_OPENPARENTHESIS_13=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_13, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_2_1());
                              					
                            }
                            // InternalSM2.g:996:6: (this_PropertyInteger_14= rulePropertyInteger | this_SyntaxExpression_15= ruleSyntaxExpression )
                            int alt28=2;
                            int LA28_0 = input.LA(1);

                            if ( ((LA28_0>=77 && LA28_0<=82)) ) {
                                alt28=1;
                            }
                            else if ( (LA28_0==RULE_INTEGER||LA28_0==RULE_STRING||LA28_0==RULE_FLOAT) ) {
                                alt28=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 28, 0, input);

                                throw nvae;
                            }
                            switch (alt28) {
                                case 1 :
                                    // InternalSM2.g:997:7: this_PropertyInteger_14= rulePropertyInteger
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_2_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_27);
                                    this_PropertyInteger_14=rulePropertyInteger();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyInteger_14;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1006:7: this_SyntaxExpression_15= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_2_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_27);
                                    this_SyntaxExpression_15=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_15;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_16=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_16, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_2_3());
                              					
                            }

                            }


                            }
                            break;
                        case 4 :
                            // InternalSM2.g:1021:5: (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:1021:5: (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:1022:6: otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_21= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_17=(Token)match(input,52,FOLLOW_25); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_17, grammarAccess.getBlockVariablesAccess().getCoinbaseKeyword_0_2_3_0());
                              					
                            }
                            this_OPENPARENTHESIS_18=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_30); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_18, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_3_1());
                              					
                            }
                            // InternalSM2.g:1030:6: (this_PropertyAddress_19= rulePropertyAddress | this_SyntaxExpression_20= ruleSyntaxExpression )
                            int alt29=2;
                            int LA29_0 = input.LA(1);

                            if ( (LA29_0==68||LA29_0==84) ) {
                                alt29=1;
                            }
                            else if ( (LA29_0==RULE_INTEGER||LA29_0==RULE_STRING||LA29_0==RULE_FLOAT) ) {
                                alt29=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 29, 0, input);

                                throw nvae;
                            }
                            switch (alt29) {
                                case 1 :
                                    // InternalSM2.g:1031:7: this_PropertyAddress_19= rulePropertyAddress
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyAddressParserRuleCall_0_2_3_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_27);
                                    this_PropertyAddress_19=rulePropertyAddress();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyAddress_19;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1040:7: this_SyntaxExpression_20= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_3_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_27);
                                    this_SyntaxExpression_20=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_20;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_21=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_21, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_3_3());
                              					
                            }

                            }


                            }
                            break;
                        case 5 :
                            // InternalSM2.g:1055:5: (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:1055:5: (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:1056:6: otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_26= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_22=(Token)match(input,53,FOLLOW_25); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_22, grammarAccess.getBlockVariablesAccess().getGaslimitKeyword_0_2_4_0());
                              					
                            }
                            this_OPENPARENTHESIS_23=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_23, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_4_1());
                              					
                            }
                            // InternalSM2.g:1064:6: (this_PropertyInteger_24= rulePropertyInteger | this_SyntaxExpression_25= ruleSyntaxExpression )
                            int alt30=2;
                            int LA30_0 = input.LA(1);

                            if ( ((LA30_0>=77 && LA30_0<=82)) ) {
                                alt30=1;
                            }
                            else if ( (LA30_0==RULE_INTEGER||LA30_0==RULE_STRING||LA30_0==RULE_FLOAT) ) {
                                alt30=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 30, 0, input);

                                throw nvae;
                            }
                            switch (alt30) {
                                case 1 :
                                    // InternalSM2.g:1065:7: this_PropertyInteger_24= rulePropertyInteger
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_4_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_27);
                                    this_PropertyInteger_24=rulePropertyInteger();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyInteger_24;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1074:7: this_SyntaxExpression_25= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_4_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_27);
                                    this_SyntaxExpression_25=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_25;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_26=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_26, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_4_3());
                              					
                            }

                            }


                            }
                            break;
                        case 6 :
                            // InternalSM2.g:1089:5: (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:1089:5: (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:1090:6: otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_31= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_27=(Token)match(input,54,FOLLOW_25); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_27, grammarAccess.getBlockVariablesAccess().getBlockhashKeyword_0_2_5_0());
                              					
                            }
                            this_OPENPARENTHESIS_28=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_28, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_5_1());
                              					
                            }
                            // InternalSM2.g:1098:6: (this_PropertyInteger_29= rulePropertyInteger | this_SyntaxExpression_30= ruleSyntaxExpression )
                            int alt31=2;
                            int LA31_0 = input.LA(1);

                            if ( ((LA31_0>=77 && LA31_0<=82)) ) {
                                alt31=1;
                            }
                            else if ( (LA31_0==RULE_INTEGER||LA31_0==RULE_STRING||LA31_0==RULE_FLOAT) ) {
                                alt31=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 31, 0, input);

                                throw nvae;
                            }
                            switch (alt31) {
                                case 1 :
                                    // InternalSM2.g:1099:7: this_PropertyInteger_29= rulePropertyInteger
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_5_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_27);
                                    this_PropertyInteger_29=rulePropertyInteger();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyInteger_29;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1108:7: this_SyntaxExpression_30= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_5_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_27);
                                    this_SyntaxExpression_30=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_30;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_31=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_31, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_5_3());
                              					
                            }

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1125:3: (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS (this_SEMICOLON_37= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:1125:3: (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS (this_SEMICOLON_37= RULE_SEMICOLON )? )
                    // InternalSM2.g:1126:4: otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS (this_SEMICOLON_37= RULE_SEMICOLON )?
                    {
                    otherlv_32=(Token)match(input,55,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_32, grammarAccess.getBlockVariablesAccess().getNowKeyword_1_0());
                      			
                    }
                    this_OPENPARENTHESIS_33=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_OPENPARENTHESIS_33, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_1_1());
                      			
                    }
                    // InternalSM2.g:1134:4: (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression )
                    int alt33=2;
                    int LA33_0 = input.LA(1);

                    if ( ((LA33_0>=77 && LA33_0<=82)) ) {
                        alt33=1;
                    }
                    else if ( (LA33_0==RULE_INTEGER||LA33_0==RULE_STRING||LA33_0==RULE_FLOAT) ) {
                        alt33=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 33, 0, input);

                        throw nvae;
                    }
                    switch (alt33) {
                        case 1 :
                            // InternalSM2.g:1135:5: this_PropertyInteger_34= rulePropertyInteger
                            {
                            if ( state.backtracking==0 ) {

                              					newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_1_2_0());
                              				
                            }
                            pushFollow(FOLLOW_27);
                            this_PropertyInteger_34=rulePropertyInteger();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					current = this_PropertyInteger_34;
                              					afterParserOrEnumRuleCall();
                              				
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:1144:5: this_SyntaxExpression_35= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              					newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_1_2_1());
                              				
                            }
                            pushFollow(FOLLOW_27);
                            this_SyntaxExpression_35=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					current = this_SyntaxExpression_35;
                              					afterParserOrEnumRuleCall();
                              				
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_36=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_CLOSEPARENTHESIS_36, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3());
                      			
                    }
                    // InternalSM2.g:1157:4: (this_SEMICOLON_37= RULE_SEMICOLON )?
                    int alt34=2;
                    int LA34_0 = input.LA(1);

                    if ( (LA34_0==RULE_SEMICOLON) ) {
                        int LA34_1 = input.LA(2);

                        if ( (LA34_1==EOF||LA34_1==RULE_SEMICOLON||(LA34_1>=RULE_CLOSEKEY && LA34_1<=RULE_INTEGER)||(LA34_1>=RULE_OPENPARENTHESIS && LA34_1<=RULE_STRING)||LA34_1==RULE_FLOAT||LA34_1==42||LA34_1==48||(LA34_1>=55 && LA34_1<=56)) ) {
                            alt34=1;
                        }
                        else if ( (LA34_1==RULE_EOLINE) ) {
                            int LA34_4 = input.LA(3);

                            if ( (LA34_4==RULE_CLOSEKEY) ) {
                                alt34=1;
                            }
                        }
                    }
                    switch (alt34) {
                        case 1 :
                            // InternalSM2.g:1158:5: this_SEMICOLON_37= RULE_SEMICOLON
                            {
                            this_SEMICOLON_37=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_37, grammarAccess.getBlockVariablesAccess().getSEMICOLONTerminalRuleCall_1_4());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBlockVariables"


    // $ANTLR start "entryRuleThx"
    // InternalSM2.g:1168:1: entryRuleThx returns [EObject current=null] : iv_ruleThx= ruleThx EOF ;
    public final EObject entryRuleThx() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleThx = null;


        try {
            // InternalSM2.g:1168:44: (iv_ruleThx= ruleThx EOF )
            // InternalSM2.g:1169:2: iv_ruleThx= ruleThx EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getThxRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleThx=ruleThx();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleThx; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleThx"


    // $ANTLR start "ruleThx"
    // InternalSM2.g:1175:1: ruleThx returns [EObject current=null] : (otherlv_0= 'thx' this_DOT_1= RULE_DOT ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) ;
    public final EObject ruleThx() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_DOT_1=null;
        Token otherlv_2=null;
        Token this_OPENPARENTHESIS_3=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token otherlv_7=null;
        Token this_OPENPARENTHESIS_8=null;
        Token this_CLOSEPARENTHESIS_11=null;
        EObject this_PropertyAddress_4 = null;

        EObject this_SyntaxExpression_5 = null;

        EObject this_PropertyInteger_9 = null;

        EObject this_SyntaxExpression_10 = null;



        	enterRule();

        try {
            // InternalSM2.g:1181:2: ( (otherlv_0= 'thx' this_DOT_1= RULE_DOT ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:1182:2: (otherlv_0= 'thx' this_DOT_1= RULE_DOT ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:1182:2: (otherlv_0= 'thx' this_DOT_1= RULE_DOT ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:1183:3: otherlv_0= 'thx' this_DOT_1= RULE_DOT ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS
            {
            otherlv_0=(Token)match(input,56,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getThxAccess().getThxKeyword_0());
              		
            }
            this_DOT_1=(Token)match(input,RULE_DOT,FOLLOW_32); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_DOT_1, grammarAccess.getThxAccess().getDOTTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1191:3: ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) ) )
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==57) ) {
                alt38=1;
            }
            else if ( (LA38_0==58) ) {
                alt38=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 38, 0, input);

                throw nvae;
            }
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:1192:4: (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:1192:4: (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:1193:5: otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS
                    {
                    otherlv_2=(Token)match(input,57,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_2, grammarAccess.getThxAccess().getGaspriceKeyword_2_0_0());
                      				
                    }
                    this_OPENPARENTHESIS_3=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_30); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_3, grammarAccess.getThxAccess().getOPENPARENTHESISTerminalRuleCall_2_0_1());
                      				
                    }
                    // InternalSM2.g:1201:5: (this_PropertyAddress_4= rulePropertyAddress | this_SyntaxExpression_5= ruleSyntaxExpression )
                    int alt36=2;
                    int LA36_0 = input.LA(1);

                    if ( (LA36_0==68||LA36_0==84) ) {
                        alt36=1;
                    }
                    else if ( (LA36_0==RULE_INTEGER||LA36_0==RULE_STRING||LA36_0==RULE_FLOAT) ) {
                        alt36=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 36, 0, input);

                        throw nvae;
                    }
                    switch (alt36) {
                        case 1 :
                            // InternalSM2.g:1202:6: this_PropertyAddress_4= rulePropertyAddress
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getThxAccess().getPropertyAddressParserRuleCall_2_0_2_0());
                              					
                            }
                            pushFollow(FOLLOW_27);
                            this_PropertyAddress_4=rulePropertyAddress();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_PropertyAddress_4;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:1211:6: this_SyntaxExpression_5= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getThxAccess().getSyntaxExpressionParserRuleCall_2_0_2_1());
                              					
                            }
                            pushFollow(FOLLOW_27);
                            this_SyntaxExpression_5=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_5;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getThxAccess().getCLOSEPARENTHESISTerminalRuleCall_2_0_3());
                      				
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1226:4: (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) )
                    {
                    // InternalSM2.g:1226:4: (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression ) )
                    // InternalSM2.g:1227:5: otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression )
                    {
                    otherlv_7=(Token)match(input,58,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_7, grammarAccess.getThxAccess().getOriginKeyword_2_1_0());
                      				
                    }
                    this_OPENPARENTHESIS_8=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_8, grammarAccess.getThxAccess().getOPENPARENTHESISTerminalRuleCall_2_1_1());
                      				
                    }
                    // InternalSM2.g:1235:5: (this_PropertyInteger_9= rulePropertyInteger | this_SyntaxExpression_10= ruleSyntaxExpression )
                    int alt37=2;
                    int LA37_0 = input.LA(1);

                    if ( ((LA37_0>=77 && LA37_0<=82)) ) {
                        alt37=1;
                    }
                    else if ( (LA37_0==RULE_INTEGER||LA37_0==RULE_STRING||LA37_0==RULE_FLOAT) ) {
                        alt37=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 37, 0, input);

                        throw nvae;
                    }
                    switch (alt37) {
                        case 1 :
                            // InternalSM2.g:1236:6: this_PropertyInteger_9= rulePropertyInteger
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getThxAccess().getPropertyIntegerParserRuleCall_2_1_2_0());
                              					
                            }
                            pushFollow(FOLLOW_27);
                            this_PropertyInteger_9=rulePropertyInteger();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_PropertyInteger_9;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:1245:6: this_SyntaxExpression_10= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getThxAccess().getSyntaxExpressionParserRuleCall_2_1_2_1());
                              					
                            }
                            pushFollow(FOLLOW_27);
                            this_SyntaxExpression_10=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_10;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_11=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_11, grammarAccess.getThxAccess().getCLOSEPARENTHESISTerminalRuleCall_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleThx"


    // $ANTLR start "entryRuleConstructor"
    // InternalSM2.g:1264:1: entryRuleConstructor returns [EObject current=null] : iv_ruleConstructor= ruleConstructor EOF ;
    public final EObject entryRuleConstructor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConstructor = null;


        try {
            // InternalSM2.g:1264:52: (iv_ruleConstructor= ruleConstructor EOF )
            // InternalSM2.g:1265:2: iv_ruleConstructor= ruleConstructor EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConstructorRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleConstructor=ruleConstructor();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleConstructor; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConstructor"


    // $ANTLR start "ruleConstructor"
    // InternalSM2.g:1271:1: ruleConstructor returns [EObject current=null] : (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY ) ;
    public final EObject ruleConstructor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_2=null;
        Token lv_type_3_1=null;
        Token lv_type_3_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token otherlv_6=null;
        Token this_CLOSEKEY_7=null;


        	enterRule();

        try {
            // InternalSM2.g:1277:2: ( (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY ) )
            // InternalSM2.g:1278:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY )
            {
            // InternalSM2.g:1278:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY )
            // InternalSM2.g:1279:3: otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,59,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getConstructorAccess().getConstructorKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConstructorAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1287:3: ( (otherlv_2= RULE_ID ) )
            // InternalSM2.g:1288:4: (otherlv_2= RULE_ID )
            {
            // InternalSM2.g:1288:4: (otherlv_2= RULE_ID )
            // InternalSM2.g:1289:5: otherlv_2= RULE_ID
            {
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getConstructorRule());
              					}
              				
            }
            otherlv_2=(Token)match(input,RULE_ID,FOLLOW_33); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(otherlv_2, grammarAccess.getConstructorAccess().getInputParamsInputParamCrossReference_2_0());
              				
            }

            }


            }

            // InternalSM2.g:1300:3: ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) )
            // InternalSM2.g:1301:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            {
            // InternalSM2.g:1301:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            // InternalSM2.g:1302:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            {
            // InternalSM2.g:1302:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==60) ) {
                alt39=1;
            }
            else if ( (LA39_0==61) ) {
                alt39=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 39, 0, input);

                throw nvae;
            }
            switch (alt39) {
                case 1 :
                    // InternalSM2.g:1303:6: lv_type_3_1= 'public'
                    {
                    lv_type_3_1=(Token)match(input,60,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_3_1, grammarAccess.getConstructorAccess().getTypePublicKeyword_3_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getConstructorRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_3_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1314:6: lv_type_3_2= 'internal'
                    {
                    lv_type_3_2=(Token)match(input,61,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_3_2, grammarAccess.getConstructorAccess().getTypeInternalKeyword_3_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getConstructorRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_3_2, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getConstructorAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_34); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getConstructorAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1335:3: ( (otherlv_6= RULE_ID ) )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==RULE_ID) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalSM2.g:1336:4: (otherlv_6= RULE_ID )
                    {
                    // InternalSM2.g:1336:4: (otherlv_6= RULE_ID )
                    // InternalSM2.g:1337:5: otherlv_6= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getConstructorRule());
                      					}
                      				
                    }
                    otherlv_6=(Token)match(input,RULE_ID,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_6, grammarAccess.getConstructorAccess().getAttributesAttributesCrossReference_6_0());
                      				
                    }

                    }


                    }
                    break;

            }

            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_7, grammarAccess.getConstructorAccess().getCLOSEKEYTerminalRuleCall_7());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConstructor"


    // $ANTLR start "entryRuleEvent"
    // InternalSM2.g:1356:1: entryRuleEvent returns [EObject current=null] : iv_ruleEvent= ruleEvent EOF ;
    public final EObject entryRuleEvent() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvent = null;


        try {
            // InternalSM2.g:1356:46: (iv_ruleEvent= ruleEvent EOF )
            // InternalSM2.g:1357:2: iv_ruleEvent= ruleEvent EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getEventRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleEvent=ruleEvent();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleEvent; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalSM2.g:1363:1: ruleEvent returns [EObject current=null] : (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject ruleEvent() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEvent_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;
        EObject lv_inputParams_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1369:2: ( (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1370:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1370:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1371:3: otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,62,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getEventAccess().getEventKeyword_0());
              		
            }
            // InternalSM2.g:1375:3: ( (lv_nameEvent_1_0= RULE_ID ) )
            // InternalSM2.g:1376:4: (lv_nameEvent_1_0= RULE_ID )
            {
            // InternalSM2.g:1376:4: (lv_nameEvent_1_0= RULE_ID )
            // InternalSM2.g:1377:5: lv_nameEvent_1_0= RULE_ID
            {
            lv_nameEvent_1_0=(Token)match(input,RULE_ID,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameEvent_1_0, grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEventRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameEvent",
              						lv_nameEvent_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_35); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1397:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop41:
            do {
                int alt41=2;
                int LA41_0 = input.LA(1);

                if ( (LA41_0==68||LA41_0==70||(LA41_0>=77 && LA41_0<=79)||(LA41_0>=82 && LA41_0<=84)||LA41_0==89||(LA41_0>=121 && LA41_0<=122)) ) {
                    alt41=1;
                }


                switch (alt41) {
            	case 1 :
            	    // InternalSM2.g:1398:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1398:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:1399:5: lv_inputParams_3_0= ruleInputParam
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_35);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getEventRule());
            	      					}
            	      					add(
            	      						current,
            	      						"inputParams",
            	      						lv_inputParams_3_0,
            	      						"org.xtext.SM2.InputParam");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop41;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_5, grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1424:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==RULE_EOLINE) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalSM2.g:1425:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:1434:1: entryRuleModifier returns [EObject current=null] : iv_ruleModifier= ruleModifier EOF ;
    public final EObject entryRuleModifier() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModifier = null;


        try {
            // InternalSM2.g:1434:49: (iv_ruleModifier= ruleModifier EOF )
            // InternalSM2.g:1435:2: iv_ruleModifier= ruleModifier EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getModifierRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleModifier=ruleModifier();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleModifier; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:1441:1: ruleModifier returns [EObject current=null] : (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? ) ;
    public final EObject ruleModifier() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameModifier_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_EOLINE_6=null;
        Token this_SEMICOLON_9=null;
        Token this_EOLINE_10=null;
        Token otherlv_11=null;
        Token this_CLOSEKEY_12=null;
        Token this_EOLINE_13=null;
        EObject lv_inputParams_3_0 = null;

        EObject lv_conditions_7_0 = null;

        EObject lv_expr_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1447:2: ( (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? ) )
            // InternalSM2.g:1448:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? )
            {
            // InternalSM2.g:1448:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? )
            // InternalSM2.g:1449:3: otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,63,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getModifierAccess().getModifierKeyword_0());
              		
            }
            // InternalSM2.g:1453:3: ( (lv_nameModifier_1_0= RULE_ID ) )
            // InternalSM2.g:1454:4: (lv_nameModifier_1_0= RULE_ID )
            {
            // InternalSM2.g:1454:4: (lv_nameModifier_1_0= RULE_ID )
            // InternalSM2.g:1455:5: lv_nameModifier_1_0= RULE_ID
            {
            lv_nameModifier_1_0=(Token)match(input,RULE_ID,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameModifier_1_0, grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getModifierRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameModifier",
              						lv_nameModifier_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_35); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1475:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop43:
            do {
                int alt43=2;
                int LA43_0 = input.LA(1);

                if ( (LA43_0==68||LA43_0==70||(LA43_0>=77 && LA43_0<=79)||(LA43_0>=82 && LA43_0<=84)||LA43_0==89||(LA43_0>=121 && LA43_0<=122)) ) {
                    alt43=1;
                }


                switch (alt43) {
            	case 1 :
            	    // InternalSM2.g:1476:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1476:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:1477:5: lv_inputParams_3_0= ruleInputParam
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_35);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getModifierRule());
            	      					}
            	      					add(
            	      						current,
            	      						"inputParams",
            	      						lv_inputParams_3_0,
            	      						"org.xtext.SM2.InputParam");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop43;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_36); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1502:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==RULE_EOLINE) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:1503:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_36); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:1508:3: ( (lv_conditions_7_0= ruleConditional ) )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==RULE_IF) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalSM2.g:1509:4: (lv_conditions_7_0= ruleConditional )
                    {
                    // InternalSM2.g:1509:4: (lv_conditions_7_0= ruleConditional )
                    // InternalSM2.g:1510:5: lv_conditions_7_0= ruleConditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getModifierAccess().getConditionsConditionalParserRuleCall_7_0());
                      				
                    }
                    pushFollow(FOLLOW_36);
                    lv_conditions_7_0=ruleConditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getModifierRule());
                      					}
                      					add(
                      						current,
                      						"conditions",
                      						lv_conditions_7_0,
                      						"org.xtext.SM2.Conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1527:3: ( (lv_expr_8_0= ruleExpression ) )
            // InternalSM2.g:1528:4: (lv_expr_8_0= ruleExpression )
            {
            // InternalSM2.g:1528:4: (lv_expr_8_0= ruleExpression )
            // InternalSM2.g:1529:5: lv_expr_8_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getModifierAccess().getExprExpressionParserRuleCall_8_0());
              				
            }
            pushFollow(FOLLOW_5);
            lv_expr_8_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getModifierRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_8_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_37); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_9, grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_9());
              		
            }
            // InternalSM2.g:1550:3: (this_EOLINE_10= RULE_EOLINE )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==RULE_EOLINE) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:1551:4: this_EOLINE_10= RULE_EOLINE
                    {
                    this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_38); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_10, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_10());
                      			
                    }

                    }
                    break;

            }

            otherlv_11=(Token)match(input,64,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_11, grammarAccess.getModifierAccess().get_Keyword_11());
              		
            }
            this_CLOSEKEY_12=(Token)match(input,RULE_CLOSEKEY,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_12, grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_12());
              		
            }
            // InternalSM2.g:1564:3: (this_EOLINE_13= RULE_EOLINE )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==RULE_EOLINE) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalSM2.g:1565:4: this_EOLINE_13= RULE_EOLINE
                    {
                    this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_13, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_13());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:1574:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalSM2.g:1574:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalSM2.g:1575:2: iv_ruleDataType= ruleDataType EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getDataTypeRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleDataType; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:1581:1: ruleDataType returns [EObject current=null] : (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        EObject this_Mapping_0 = null;

        EObject this_Enum_1 = null;

        EObject this_Struct_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:1587:2: ( (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct ) )
            // InternalSM2.g:1588:2: (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct )
            {
            // InternalSM2.g:1588:2: (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct )
            int alt48=3;
            switch ( input.LA(1) ) {
            case 65:
                {
                alt48=1;
                }
                break;
            case 73:
                {
                alt48=2;
                }
                break;
            case 67:
                {
                alt48=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 48, 0, input);

                throw nvae;
            }

            switch (alt48) {
                case 1 :
                    // InternalSM2.g:1589:3: this_Mapping_0= ruleMapping
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getMappingParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Mapping_0=ruleMapping();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Mapping_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1598:3: this_Enum_1= ruleEnum
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Enum_1=ruleEnum();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Enum_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1607:3: this_Struct_2= ruleStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getStructParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Struct_2=ruleStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Struct_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:1619:1: entryRuleMapping returns [EObject current=null] : iv_ruleMapping= ruleMapping EOF ;
    public final EObject entryRuleMapping() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMapping = null;


        try {
            // InternalSM2.g:1619:48: (iv_ruleMapping= ruleMapping EOF )
            // InternalSM2.g:1620:2: iv_ruleMapping= ruleMapping EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMappingRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleMapping=ruleMapping();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleMapping; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:1626:1: ruleMapping returns [EObject current=null] : (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON ) ;
    public final EObject ruleMapping() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token lv_nameMapping_8_0=null;
        Token this_SEMICOLON_9=null;
        Enumerator lv_key_2_0 = null;

        Enumerator lv_valueBasicType_5_0 = null;

        Enumerator lv_visibility_7_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1632:2: ( (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON ) )
            // InternalSM2.g:1633:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON )
            {
            // InternalSM2.g:1633:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON )
            // InternalSM2.g:1634:3: otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON
            {
            otherlv_0=(Token)match(input,65,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getMappingAccess().getMappingKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_39); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1642:3: ( (lv_key_2_0= ruleBasicType ) )
            // InternalSM2.g:1643:4: (lv_key_2_0= ruleBasicType )
            {
            // InternalSM2.g:1643:4: (lv_key_2_0= ruleBasicType )
            // InternalSM2.g:1644:5: lv_key_2_0= ruleBasicType
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getMappingAccess().getKeyBasicTypeEnumRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_40);
            lv_key_2_0=ruleBasicType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getMappingRule());
              					}
              					set(
              						current,
              						"key",
              						lv_key_2_0,
              						"org.xtext.SM2.BasicType");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,66,FOLLOW_41); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3());
              		
            }
            // InternalSM2.g:1665:3: ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) )
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==RULE_ID) ) {
                alt49=1;
            }
            else if ( (LA49_0==68||LA49_0==70||(LA49_0>=77 && LA49_0<=79)||(LA49_0>=82 && LA49_0<=84)||LA49_0==89||(LA49_0>=121 && LA49_0<=122)) ) {
                alt49=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 49, 0, input);

                throw nvae;
            }
            switch (alt49) {
                case 1 :
                    // InternalSM2.g:1666:4: ( (otherlv_4= RULE_ID ) )
                    {
                    // InternalSM2.g:1666:4: ( (otherlv_4= RULE_ID ) )
                    // InternalSM2.g:1667:5: (otherlv_4= RULE_ID )
                    {
                    // InternalSM2.g:1667:5: (otherlv_4= RULE_ID )
                    // InternalSM2.g:1668:6: otherlv_4= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getMappingRule());
                      						}
                      					
                    }
                    otherlv_4=(Token)match(input,RULE_ID,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(otherlv_4, grammarAccess.getMappingAccess().getValueStructCrossReference_4_0_0());
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1680:4: ( (lv_valueBasicType_5_0= ruleBasicType ) )
                    {
                    // InternalSM2.g:1680:4: ( (lv_valueBasicType_5_0= ruleBasicType ) )
                    // InternalSM2.g:1681:5: (lv_valueBasicType_5_0= ruleBasicType )
                    {
                    // InternalSM2.g:1681:5: (lv_valueBasicType_5_0= ruleBasicType )
                    // InternalSM2.g:1682:6: lv_valueBasicType_5_0= ruleBasicType
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getMappingAccess().getValueBasicTypeBasicTypeEnumRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_27);
                    lv_valueBasicType_5_0=ruleBasicType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getMappingRule());
                      						}
                      						set(
                      							current,
                      							"valueBasicType",
                      							lv_valueBasicType_5_0,
                      							"org.xtext.SM2.BasicType");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_42); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1704:3: ( (lv_visibility_7_0= ruleVisibility ) )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( ((LA50_0>=60 && LA50_0<=61)||(LA50_0>=103 && LA50_0<=104)) ) {
                alt50=1;
            }
            switch (alt50) {
                case 1 :
                    // InternalSM2.g:1705:4: (lv_visibility_7_0= ruleVisibility )
                    {
                    // InternalSM2.g:1705:4: (lv_visibility_7_0= ruleVisibility )
                    // InternalSM2.g:1706:5: lv_visibility_7_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_11);
                    lv_visibility_7_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getMappingRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_7_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1723:3: ( (lv_nameMapping_8_0= RULE_ID ) )
            // InternalSM2.g:1724:4: (lv_nameMapping_8_0= RULE_ID )
            {
            // InternalSM2.g:1724:4: (lv_nameMapping_8_0= RULE_ID )
            // InternalSM2.g:1725:5: lv_nameMapping_8_0= RULE_ID
            {
            lv_nameMapping_8_0=(Token)match(input,RULE_ID,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameMapping_8_0, grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getMappingRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameMapping",
              						lv_nameMapping_8_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_9, grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:1749:1: entryRuleStruct returns [EObject current=null] : iv_ruleStruct= ruleStruct EOF ;
    public final EObject entryRuleStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStruct = null;


        try {
            // InternalSM2.g:1749:47: (iv_ruleStruct= ruleStruct EOF )
            // InternalSM2.g:1750:2: iv_ruleStruct= ruleStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleStruct=ruleStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:1756:1: ruleStruct returns [EObject current=null] : (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany ) ;
    public final EObject ruleStruct() throws RecognitionException {
        EObject current = null;

        EObject this_PersonalizedStruct_0 = null;

        EObject this_User_1 = null;

        EObject this_Company_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:1762:2: ( (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany ) )
            // InternalSM2.g:1763:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )
            {
            // InternalSM2.g:1763:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )
            int alt51=3;
            alt51 = dfa51.predict(input);
            switch (alt51) {
                case 1 :
                    // InternalSM2.g:1764:3: this_PersonalizedStruct_0= rulePersonalizedStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructAccess().getPersonalizedStructParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PersonalizedStruct_0=rulePersonalizedStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PersonalizedStruct_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1773:3: this_User_1= ruleUser
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructAccess().getUserParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_User_1=ruleUser();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_User_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1782:3: this_Company_2= ruleCompany
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructAccess().getCompanyParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Company_2=ruleCompany();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Company_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRulePersonalizedStruct"
    // InternalSM2.g:1794:1: entryRulePersonalizedStruct returns [EObject current=null] : iv_rulePersonalizedStruct= rulePersonalizedStruct EOF ;
    public final EObject entryRulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonalizedStruct = null;


        try {
            // InternalSM2.g:1794:59: (iv_rulePersonalizedStruct= rulePersonalizedStruct EOF )
            // InternalSM2.g:1795:2: iv_rulePersonalizedStruct= rulePersonalizedStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPersonalizedStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePersonalizedStruct=rulePersonalizedStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePersonalizedStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonalizedStruct"


    // $ANTLR start "rulePersonalizedStruct"
    // InternalSM2.g:1801:1: rulePersonalizedStruct returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject rulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_CLOSEKEY_5=null;
        Token this_EOLINE_6=null;
        EObject lv_properties_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1807:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1808:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1808:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1809:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,67,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getPersonalizedStructAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:1813:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1814:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1814:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1815:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getPersonalizedStructAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPersonalizedStructRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_43); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1835:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==RULE_EOLINE) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalSM2.g:1836:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_44); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:1841:3: ( (lv_properties_4_0= ruleProperty ) )+
            int cnt53=0;
            loop53:
            do {
                int alt53=2;
                int LA53_0 = input.LA(1);

                if ( (LA53_0==RULE_ID||LA53_0==68||(LA53_0>=70 && LA53_0<=71)||(LA53_0>=77 && LA53_0<=89)) ) {
                    alt53=1;
                }


                switch (alt53) {
            	case 1 :
            	    // InternalSM2.g:1842:4: (lv_properties_4_0= ruleProperty )
            	    {
            	    // InternalSM2.g:1842:4: (lv_properties_4_0= ruleProperty )
            	    // InternalSM2.g:1843:5: lv_properties_4_0= ruleProperty
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_45);
            	    lv_properties_4_0=ruleProperty();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getPersonalizedStructRule());
            	      					}
            	      					add(
            	      						current,
            	      						"properties",
            	      						lv_properties_4_0,
            	      						"org.xtext.SM2.Property");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt53 >= 1 ) break loop53;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(53, input);
                        throw eee;
                }
                cnt53++;
            } while (true);

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_5, grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1864:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==RULE_EOLINE) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalSM2.g:1865:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonalizedStruct"


    // $ANTLR start "entryRuleUser"
    // InternalSM2.g:1874:1: entryRuleUser returns [EObject current=null] : iv_ruleUser= ruleUser EOF ;
    public final EObject entryRuleUser() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUser = null;


        try {
            // InternalSM2.g:1874:45: (iv_ruleUser= ruleUser EOF )
            // InternalSM2.g:1875:2: iv_ruleUser= ruleUser EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getUserRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleUser=ruleUser();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleUser; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUser"


    // $ANTLR start "ruleUser"
    // InternalSM2.g:1881:1: ruleUser returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) ;
    public final EObject ruleUser() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_0=null;
        Token otherlv_6=null;
        Token this_STRING_7=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Token otherlv_10=null;
        Token lv_nameUser_11_0=null;
        Token otherlv_12=null;
        Token this_STRING_13=null;
        Token this_SEMICOLON_14=null;
        Token this_EOLINE_15=null;
        Token otherlv_16=null;
        Token lv_surname_17_0=null;
        Token otherlv_18=null;
        Token this_STRING_19=null;
        Token this_SEMICOLON_20=null;
        Token this_EOLINE_21=null;
        Token otherlv_22=null;
        Token lv_email_23_0=null;
        Token otherlv_24=null;
        Token this_EMAIL_25=null;
        Token this_SEMICOLON_26=null;
        Token this_EOLINE_27=null;
        Token otherlv_28=null;
        Token otherlv_29=null;
        Token otherlv_30=null;
        Token lv_amount_31_0=null;
        Token this_FLOAT_32=null;
        Token this_SEMICOLON_33=null;
        Token this_EOLINE_34=null;
        Token this_CLOSEKEY_35=null;
        Token this_EOLINE_36=null;


        	enterRule();

        try {
            // InternalSM2.g:1887:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) )
            // InternalSM2.g:1888:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            {
            // InternalSM2.g:1888:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            // InternalSM2.g:1889:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,67,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getUserAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:1893:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1894:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1894:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1895:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_46); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1915:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==RULE_EOLINE) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // InternalSM2.g:1916:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            otherlv_4=(Token)match(input,68,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getUserAccess().getAddressKeyword_4());
              		
            }
            // InternalSM2.g:1925:3: ( (lv_idAdress_5_0= RULE_ID ) )
            // InternalSM2.g:1926:4: (lv_idAdress_5_0= RULE_ID )
            {
            // InternalSM2.g:1926:4: (lv_idAdress_5_0= RULE_ID )
            // InternalSM2.g:1927:5: lv_idAdress_5_0= RULE_ID
            {
            lv_idAdress_5_0=(Token)match(input,RULE_ID,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_idAdress_5_0, grammarAccess.getUserAccess().getIdAdressIDTerminalRuleCall_5_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"idAdress",
              						lv_idAdress_5_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:1943:3: (otherlv_6= '=' this_STRING_7= RULE_STRING )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==69) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalSM2.g:1944:4: otherlv_6= '=' this_STRING_7= RULE_STRING
                    {
                    otherlv_6=(Token)match(input,69,FOLLOW_49); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_6, grammarAccess.getUserAccess().getEqualsSignKeyword_6_0());
                      			
                    }
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_7, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_6_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            // InternalSM2.g:1957:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==RULE_EOLINE) ) {
                alt57=1;
            }
            switch (alt57) {
                case 1 :
                    // InternalSM2.g:1958:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_51); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_8());
                      			
                    }

                    }
                    break;

            }

            otherlv_10=(Token)match(input,70,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_10, grammarAccess.getUserAccess().getStringKeyword_9());
              		
            }
            // InternalSM2.g:1967:3: ( (lv_nameUser_11_0= RULE_STRING ) )
            // InternalSM2.g:1968:4: (lv_nameUser_11_0= RULE_STRING )
            {
            // InternalSM2.g:1968:4: (lv_nameUser_11_0= RULE_STRING )
            // InternalSM2.g:1969:5: lv_nameUser_11_0= RULE_STRING
            {
            lv_nameUser_11_0=(Token)match(input,RULE_STRING,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameUser_11_0, grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_10_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameUser",
              						lv_nameUser_11_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1985:3: (otherlv_12= '=' this_STRING_13= RULE_STRING )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==69) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // InternalSM2.g:1986:4: otherlv_12= '=' this_STRING_13= RULE_STRING
                    {
                    otherlv_12=(Token)match(input,69,FOLLOW_49); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_12, grammarAccess.getUserAccess().getEqualsSignKeyword_11_0());
                      			
                    }
                    this_STRING_13=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_13, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_11_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_14=(Token)match(input,RULE_SEMICOLON,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_14, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_12());
              		
            }
            // InternalSM2.g:1999:3: (this_EOLINE_15= RULE_EOLINE )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==RULE_EOLINE) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // InternalSM2.g:2000:4: this_EOLINE_15= RULE_EOLINE
                    {
                    this_EOLINE_15=(Token)match(input,RULE_EOLINE,FOLLOW_51); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_15, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_13());
                      			
                    }

                    }
                    break;

            }

            otherlv_16=(Token)match(input,70,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_16, grammarAccess.getUserAccess().getStringKeyword_14());
              		
            }
            // InternalSM2.g:2009:3: ( (lv_surname_17_0= RULE_STRING ) )
            // InternalSM2.g:2010:4: (lv_surname_17_0= RULE_STRING )
            {
            // InternalSM2.g:2010:4: (lv_surname_17_0= RULE_STRING )
            // InternalSM2.g:2011:5: lv_surname_17_0= RULE_STRING
            {
            lv_surname_17_0=(Token)match(input,RULE_STRING,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_surname_17_0, grammarAccess.getUserAccess().getSurnameSTRINGTerminalRuleCall_15_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"surname",
              						lv_surname_17_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2027:3: (otherlv_18= '=' this_STRING_19= RULE_STRING )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==69) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // InternalSM2.g:2028:4: otherlv_18= '=' this_STRING_19= RULE_STRING
                    {
                    otherlv_18=(Token)match(input,69,FOLLOW_49); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_18, grammarAccess.getUserAccess().getEqualsSignKeyword_16_0());
                      			
                    }
                    this_STRING_19=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_19, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_16_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_20=(Token)match(input,RULE_SEMICOLON,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_20, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_17());
              		
            }
            // InternalSM2.g:2041:3: (this_EOLINE_21= RULE_EOLINE )?
            int alt61=2;
            int LA61_0 = input.LA(1);

            if ( (LA61_0==RULE_EOLINE) ) {
                alt61=1;
            }
            switch (alt61) {
                case 1 :
                    // InternalSM2.g:2042:4: this_EOLINE_21= RULE_EOLINE
                    {
                    this_EOLINE_21=(Token)match(input,RULE_EOLINE,FOLLOW_51); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_21, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_18());
                      			
                    }

                    }
                    break;

            }

            otherlv_22=(Token)match(input,70,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_22, grammarAccess.getUserAccess().getStringKeyword_19());
              		
            }
            // InternalSM2.g:2051:3: ( (lv_email_23_0= RULE_STRING ) )
            // InternalSM2.g:2052:4: (lv_email_23_0= RULE_STRING )
            {
            // InternalSM2.g:2052:4: (lv_email_23_0= RULE_STRING )
            // InternalSM2.g:2053:5: lv_email_23_0= RULE_STRING
            {
            lv_email_23_0=(Token)match(input,RULE_STRING,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_email_23_0, grammarAccess.getUserAccess().getEmailSTRINGTerminalRuleCall_20_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"email",
              						lv_email_23_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2069:3: (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )?
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==69) ) {
                alt62=1;
            }
            switch (alt62) {
                case 1 :
                    // InternalSM2.g:2070:4: otherlv_24= '=' this_EMAIL_25= RULE_EMAIL
                    {
                    otherlv_24=(Token)match(input,69,FOLLOW_52); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_24, grammarAccess.getUserAccess().getEqualsSignKeyword_21_0());
                      			
                    }
                    this_EMAIL_25=(Token)match(input,RULE_EMAIL,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EMAIL_25, grammarAccess.getUserAccess().getEMAILTerminalRuleCall_21_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_26=(Token)match(input,RULE_SEMICOLON,FOLLOW_53); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_26, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_22());
              		
            }
            // InternalSM2.g:2083:3: (this_EOLINE_27= RULE_EOLINE )?
            int alt63=2;
            int LA63_0 = input.LA(1);

            if ( (LA63_0==RULE_EOLINE) ) {
                alt63=1;
            }
            switch (alt63) {
                case 1 :
                    // InternalSM2.g:2084:4: this_EOLINE_27= RULE_EOLINE
                    {
                    this_EOLINE_27=(Token)match(input,RULE_EOLINE,FOLLOW_54); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_27, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_23());
                      			
                    }

                    }
                    break;

            }

            otherlv_28=(Token)match(input,71,FOLLOW_55); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_28, grammarAccess.getUserAccess().getFloatKeyword_24());
              		
            }
            otherlv_29=(Token)match(input,72,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_29, grammarAccess.getUserAccess().getAmountAccountKeyword_25());
              		
            }
            // InternalSM2.g:2097:3: (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )?
            int alt65=2;
            int LA65_0 = input.LA(1);

            if ( (LA65_0==69) ) {
                alt65=1;
            }
            switch (alt65) {
                case 1 :
                    // InternalSM2.g:2098:4: otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT )
                    {
                    otherlv_30=(Token)match(input,69,FOLLOW_56); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_30, grammarAccess.getUserAccess().getEqualsSignKeyword_26_0());
                      			
                    }
                    // InternalSM2.g:2102:4: ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT )
                    int alt64=2;
                    int LA64_0 = input.LA(1);

                    if ( (LA64_0==RULE_INTEGER) ) {
                        alt64=1;
                    }
                    else if ( (LA64_0==RULE_FLOAT) ) {
                        alt64=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 64, 0, input);

                        throw nvae;
                    }
                    switch (alt64) {
                        case 1 :
                            // InternalSM2.g:2103:5: ( (lv_amount_31_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:2103:5: ( (lv_amount_31_0= RULE_INTEGER ) )
                            // InternalSM2.g:2104:6: (lv_amount_31_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:2104:6: (lv_amount_31_0= RULE_INTEGER )
                            // InternalSM2.g:2105:7: lv_amount_31_0= RULE_INTEGER
                            {
                            lv_amount_31_0=(Token)match(input,RULE_INTEGER,FOLLOW_5); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_amount_31_0, grammarAccess.getUserAccess().getAmountINTEGERTerminalRuleCall_26_1_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getUserRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"amount",
                              								lv_amount_31_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:2122:5: this_FLOAT_32= RULE_FLOAT
                            {
                            this_FLOAT_32=(Token)match(input,RULE_FLOAT,FOLLOW_5); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_32, grammarAccess.getUserAccess().getFLOATTerminalRuleCall_26_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }
                    break;

            }

            this_SEMICOLON_33=(Token)match(input,RULE_SEMICOLON,FOLLOW_57); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_33, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_27());
              		
            }
            // InternalSM2.g:2132:3: (this_EOLINE_34= RULE_EOLINE )?
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==RULE_EOLINE) ) {
                alt66=1;
            }
            switch (alt66) {
                case 1 :
                    // InternalSM2.g:2133:4: this_EOLINE_34= RULE_EOLINE
                    {
                    this_EOLINE_34=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_34, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_28());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_35=(Token)match(input,RULE_CLOSEKEY,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_35, grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_29());
              		
            }
            // InternalSM2.g:2142:3: (this_EOLINE_36= RULE_EOLINE )?
            int alt67=2;
            int LA67_0 = input.LA(1);

            if ( (LA67_0==RULE_EOLINE) ) {
                alt67=1;
            }
            switch (alt67) {
                case 1 :
                    // InternalSM2.g:2143:4: this_EOLINE_36= RULE_EOLINE
                    {
                    this_EOLINE_36=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_36, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_30());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUser"


    // $ANTLR start "entryRuleCompany"
    // InternalSM2.g:2152:1: entryRuleCompany returns [EObject current=null] : iv_ruleCompany= ruleCompany EOF ;
    public final EObject entryRuleCompany() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompany = null;


        try {
            // InternalSM2.g:2152:48: (iv_ruleCompany= ruleCompany EOF )
            // InternalSM2.g:2153:2: iv_ruleCompany= ruleCompany EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCompanyRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleCompany=ruleCompany();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleCompany; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompany"


    // $ANTLR start "ruleCompany"
    // InternalSM2.g:2159:1: ruleCompany returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) ;
    public final EObject ruleCompany() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_0=null;
        Token otherlv_6=null;
        Token this_STRING_7=null;
        Token this_SEMICOLON_8=null;
        Token otherlv_9=null;
        Token lv_nameCompany_10_0=null;
        Token otherlv_11=null;
        Token this_STRING_12=null;
        Token this_SEMICOLON_13=null;
        Token otherlv_14=null;
        Token lv_city_15_0=null;
        Token otherlv_16=null;
        Token this_STRING_17=null;
        Token this_SEMICOLON_18=null;
        Token otherlv_19=null;
        Token lv_email_20_0=null;
        Token otherlv_21=null;
        Token this_EMAIL_22=null;
        Token this_SEMICOLON_23=null;
        Token otherlv_24=null;
        Token lv_telf_25_0=null;
        Token otherlv_26=null;
        Token this_STRING_27=null;
        Token this_SEMICOLON_28=null;
        Token otherlv_29=null;
        Token otherlv_30=null;
        Token otherlv_31=null;
        Token lv_amount_32_0=null;
        Token this_FLOAT_33=null;
        Token this_SEMICOLON_34=null;
        Token this_CLOSEKEY_35=null;
        Token this_EOLINE_36=null;


        	enterRule();

        try {
            // InternalSM2.g:2165:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) )
            // InternalSM2.g:2166:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            {
            // InternalSM2.g:2166:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            // InternalSM2.g:2167:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,67,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getCompanyAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:2171:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:2172:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:2172:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:2173:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getCompanyAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_46); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getCompanyAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2193:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==RULE_EOLINE) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // InternalSM2.g:2194:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            otherlv_4=(Token)match(input,68,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getCompanyAccess().getAddressKeyword_4());
              		
            }
            // InternalSM2.g:2203:3: ( (lv_idAdress_5_0= RULE_ID ) )
            // InternalSM2.g:2204:4: (lv_idAdress_5_0= RULE_ID )
            {
            // InternalSM2.g:2204:4: (lv_idAdress_5_0= RULE_ID )
            // InternalSM2.g:2205:5: lv_idAdress_5_0= RULE_ID
            {
            lv_idAdress_5_0=(Token)match(input,RULE_ID,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_idAdress_5_0, grammarAccess.getCompanyAccess().getIdAdressIDTerminalRuleCall_5_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"idAdress",
              						lv_idAdress_5_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:2221:3: (otherlv_6= '=' this_STRING_7= RULE_STRING )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==69) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // InternalSM2.g:2222:4: otherlv_6= '=' this_STRING_7= RULE_STRING
                    {
                    otherlv_6=(Token)match(input,69,FOLLOW_49); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_6, grammarAccess.getCompanyAccess().getEqualsSignKeyword_6_0());
                      			
                    }
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_7, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_6_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            otherlv_9=(Token)match(input,70,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_9, grammarAccess.getCompanyAccess().getStringKeyword_8());
              		
            }
            // InternalSM2.g:2239:3: ( (lv_nameCompany_10_0= RULE_STRING ) )
            // InternalSM2.g:2240:4: (lv_nameCompany_10_0= RULE_STRING )
            {
            // InternalSM2.g:2240:4: (lv_nameCompany_10_0= RULE_STRING )
            // InternalSM2.g:2241:5: lv_nameCompany_10_0= RULE_STRING
            {
            lv_nameCompany_10_0=(Token)match(input,RULE_STRING,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameCompany_10_0, grammarAccess.getCompanyAccess().getNameCompanySTRINGTerminalRuleCall_9_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameCompany",
              						lv_nameCompany_10_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2257:3: (otherlv_11= '=' this_STRING_12= RULE_STRING )?
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( (LA70_0==69) ) {
                alt70=1;
            }
            switch (alt70) {
                case 1 :
                    // InternalSM2.g:2258:4: otherlv_11= '=' this_STRING_12= RULE_STRING
                    {
                    otherlv_11=(Token)match(input,69,FOLLOW_49); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_11, grammarAccess.getCompanyAccess().getEqualsSignKeyword_10_0());
                      			
                    }
                    this_STRING_12=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_12, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_10_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_13=(Token)match(input,RULE_SEMICOLON,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_13, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_11());
              		
            }
            otherlv_14=(Token)match(input,70,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_14, grammarAccess.getCompanyAccess().getStringKeyword_12());
              		
            }
            // InternalSM2.g:2275:3: ( (lv_city_15_0= RULE_STRING ) )
            // InternalSM2.g:2276:4: (lv_city_15_0= RULE_STRING )
            {
            // InternalSM2.g:2276:4: (lv_city_15_0= RULE_STRING )
            // InternalSM2.g:2277:5: lv_city_15_0= RULE_STRING
            {
            lv_city_15_0=(Token)match(input,RULE_STRING,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_city_15_0, grammarAccess.getCompanyAccess().getCitySTRINGTerminalRuleCall_13_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"city",
              						lv_city_15_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2293:3: (otherlv_16= '=' this_STRING_17= RULE_STRING )?
            int alt71=2;
            int LA71_0 = input.LA(1);

            if ( (LA71_0==69) ) {
                alt71=1;
            }
            switch (alt71) {
                case 1 :
                    // InternalSM2.g:2294:4: otherlv_16= '=' this_STRING_17= RULE_STRING
                    {
                    otherlv_16=(Token)match(input,69,FOLLOW_49); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_16, grammarAccess.getCompanyAccess().getEqualsSignKeyword_14_0());
                      			
                    }
                    this_STRING_17=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_17, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_14_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_18=(Token)match(input,RULE_SEMICOLON,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_18, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_15());
              		
            }
            otherlv_19=(Token)match(input,70,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_19, grammarAccess.getCompanyAccess().getStringKeyword_16());
              		
            }
            // InternalSM2.g:2311:3: ( (lv_email_20_0= RULE_STRING ) )
            // InternalSM2.g:2312:4: (lv_email_20_0= RULE_STRING )
            {
            // InternalSM2.g:2312:4: (lv_email_20_0= RULE_STRING )
            // InternalSM2.g:2313:5: lv_email_20_0= RULE_STRING
            {
            lv_email_20_0=(Token)match(input,RULE_STRING,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_email_20_0, grammarAccess.getCompanyAccess().getEmailSTRINGTerminalRuleCall_17_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"email",
              						lv_email_20_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2329:3: (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )?
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==69) ) {
                alt72=1;
            }
            switch (alt72) {
                case 1 :
                    // InternalSM2.g:2330:4: otherlv_21= '=' this_EMAIL_22= RULE_EMAIL
                    {
                    otherlv_21=(Token)match(input,69,FOLLOW_52); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_21, grammarAccess.getCompanyAccess().getEqualsSignKeyword_18_0());
                      			
                    }
                    this_EMAIL_22=(Token)match(input,RULE_EMAIL,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EMAIL_22, grammarAccess.getCompanyAccess().getEMAILTerminalRuleCall_18_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_23=(Token)match(input,RULE_SEMICOLON,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_23, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_19());
              		
            }
            otherlv_24=(Token)match(input,70,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_24, grammarAccess.getCompanyAccess().getStringKeyword_20());
              		
            }
            // InternalSM2.g:2347:3: ( (lv_telf_25_0= RULE_STRING ) )
            // InternalSM2.g:2348:4: (lv_telf_25_0= RULE_STRING )
            {
            // InternalSM2.g:2348:4: (lv_telf_25_0= RULE_STRING )
            // InternalSM2.g:2349:5: lv_telf_25_0= RULE_STRING
            {
            lv_telf_25_0=(Token)match(input,RULE_STRING,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_telf_25_0, grammarAccess.getCompanyAccess().getTelfSTRINGTerminalRuleCall_21_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"telf",
              						lv_telf_25_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2365:3: (otherlv_26= '=' this_STRING_27= RULE_STRING )?
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==69) ) {
                alt73=1;
            }
            switch (alt73) {
                case 1 :
                    // InternalSM2.g:2366:4: otherlv_26= '=' this_STRING_27= RULE_STRING
                    {
                    otherlv_26=(Token)match(input,69,FOLLOW_49); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_26, grammarAccess.getCompanyAccess().getEqualsSignKeyword_22_0());
                      			
                    }
                    this_STRING_27=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_27, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_22_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_28=(Token)match(input,RULE_SEMICOLON,FOLLOW_54); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_28, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_23());
              		
            }
            otherlv_29=(Token)match(input,71,FOLLOW_55); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_29, grammarAccess.getCompanyAccess().getFloatKeyword_24());
              		
            }
            otherlv_30=(Token)match(input,72,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_30, grammarAccess.getCompanyAccess().getAmountAccountKeyword_25());
              		
            }
            // InternalSM2.g:2387:3: (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )?
            int alt75=2;
            int LA75_0 = input.LA(1);

            if ( (LA75_0==69) ) {
                alt75=1;
            }
            switch (alt75) {
                case 1 :
                    // InternalSM2.g:2388:4: otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT )
                    {
                    otherlv_31=(Token)match(input,69,FOLLOW_56); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_31, grammarAccess.getCompanyAccess().getEqualsSignKeyword_26_0());
                      			
                    }
                    // InternalSM2.g:2392:4: ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT )
                    int alt74=2;
                    int LA74_0 = input.LA(1);

                    if ( (LA74_0==RULE_INTEGER) ) {
                        alt74=1;
                    }
                    else if ( (LA74_0==RULE_FLOAT) ) {
                        alt74=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 74, 0, input);

                        throw nvae;
                    }
                    switch (alt74) {
                        case 1 :
                            // InternalSM2.g:2393:5: ( (lv_amount_32_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:2393:5: ( (lv_amount_32_0= RULE_INTEGER ) )
                            // InternalSM2.g:2394:6: (lv_amount_32_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:2394:6: (lv_amount_32_0= RULE_INTEGER )
                            // InternalSM2.g:2395:7: lv_amount_32_0= RULE_INTEGER
                            {
                            lv_amount_32_0=(Token)match(input,RULE_INTEGER,FOLLOW_5); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_amount_32_0, grammarAccess.getCompanyAccess().getAmountINTEGERTerminalRuleCall_26_1_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getCompanyRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"amount",
                              								lv_amount_32_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:2412:5: this_FLOAT_33= RULE_FLOAT
                            {
                            this_FLOAT_33=(Token)match(input,RULE_FLOAT,FOLLOW_5); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_33, grammarAccess.getCompanyAccess().getFLOATTerminalRuleCall_26_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }
                    break;

            }

            this_SEMICOLON_34=(Token)match(input,RULE_SEMICOLON,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_34, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_27());
              		
            }
            this_CLOSEKEY_35=(Token)match(input,RULE_CLOSEKEY,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_35, grammarAccess.getCompanyAccess().getCLOSEKEYTerminalRuleCall_28());
              		
            }
            // InternalSM2.g:2426:3: (this_EOLINE_36= RULE_EOLINE )?
            int alt76=2;
            int LA76_0 = input.LA(1);

            if ( (LA76_0==RULE_EOLINE) ) {
                alt76=1;
            }
            switch (alt76) {
                case 1 :
                    // InternalSM2.g:2427:4: this_EOLINE_36= RULE_EOLINE
                    {
                    this_EOLINE_36=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_36, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_29());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompany"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:2436:1: entryRuleEnum returns [EObject current=null] : iv_ruleEnum= ruleEnum EOF ;
    public final EObject entryRuleEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnum = null;


        try {
            // InternalSM2.g:2436:45: (iv_ruleEnum= ruleEnum EOF )
            // InternalSM2.g:2437:2: iv_ruleEnum= ruleEnum EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getEnumRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleEnum=ruleEnum();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleEnum; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:2443:1: ruleEnum returns [EObject current=null] : (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEnum_1_0=null;
        Token this_OPENKEY_2=null;
        Token lv_literal_3_0=null;
        Token this_COMMA_4=null;
        Token this_CLOSEKEY_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;


        	enterRule();

        try {
            // InternalSM2.g:2449:2: ( (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2450:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2450:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2451:3: otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,73,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getEnumAccess().getEnumKeyword_0());
              		
            }
            // InternalSM2.g:2455:3: ( (lv_nameEnum_1_0= RULE_ID ) )
            // InternalSM2.g:2456:4: (lv_nameEnum_1_0= RULE_ID )
            {
            // InternalSM2.g:2456:4: (lv_nameEnum_1_0= RULE_ID )
            // InternalSM2.g:2457:5: lv_nameEnum_1_0= RULE_ID
            {
            lv_nameEnum_1_0=(Token)match(input,RULE_ID,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameEnum_1_0, grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEnumRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameEnum",
              						lv_nameEnum_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2477:3: ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+
            int cnt78=0;
            loop78:
            do {
                int alt78=2;
                int LA78_0 = input.LA(1);

                if ( (LA78_0==RULE_STRING) ) {
                    alt78=1;
                }


                switch (alt78) {
            	case 1 :
            	    // InternalSM2.g:2478:4: ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )?
            	    {
            	    // InternalSM2.g:2478:4: ( (lv_literal_3_0= RULE_STRING ) )
            	    // InternalSM2.g:2479:5: (lv_literal_3_0= RULE_STRING )
            	    {
            	    // InternalSM2.g:2479:5: (lv_literal_3_0= RULE_STRING )
            	    // InternalSM2.g:2480:6: lv_literal_3_0= RULE_STRING
            	    {
            	    lv_literal_3_0=(Token)match(input,RULE_STRING,FOLLOW_58); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      						newLeafNode(lv_literal_3_0, grammarAccess.getEnumAccess().getLiteralSTRINGTerminalRuleCall_3_0_0());
            	      					
            	    }
            	    if ( state.backtracking==0 ) {

            	      						if (current==null) {
            	      							current = createModelElement(grammarAccess.getEnumRule());
            	      						}
            	      						setWithLastConsumed(
            	      							current,
            	      							"literal",
            	      							lv_literal_3_0,
            	      							"org.eclipse.xtext.common.Terminals.STRING");
            	      					
            	    }

            	    }


            	    }

            	    // InternalSM2.g:2496:4: (this_COMMA_4= RULE_COMMA )?
            	    int alt77=2;
            	    int LA77_0 = input.LA(1);

            	    if ( (LA77_0==RULE_COMMA) ) {
            	        alt77=1;
            	    }
            	    switch (alt77) {
            	        case 1 :
            	            // InternalSM2.g:2497:5: this_COMMA_4= RULE_COMMA
            	            {
            	            this_COMMA_4=(Token)match(input,RULE_COMMA,FOLLOW_59); if (state.failed) return current;
            	            if ( state.backtracking==0 ) {

            	              					newLeafNode(this_COMMA_4, grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_3_1());
            	              				
            	            }

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt78 >= 1 ) break loop78;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(78, input);
                        throw eee;
                }
                cnt78++;
            } while (true);

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_5, grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_4());
              		
            }
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:2511:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt79=2;
            int LA79_0 = input.LA(1);

            if ( (LA79_0==RULE_EOLINE) ) {
                alt79=1;
            }
            switch (alt79) {
                case 1 :
                    // InternalSM2.g:2512:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleArray"
    // InternalSM2.g:2521:1: entryRuleArray returns [String current=null] : iv_ruleArray= ruleArray EOF ;
    public final String entryRuleArray() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleArray = null;


        try {
            // InternalSM2.g:2521:45: (iv_ruleArray= ruleArray EOF )
            // InternalSM2.g:2522:2: iv_ruleArray= ruleArray EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArrayRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArray=ruleArray();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArray.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArray"


    // $ANTLR start "ruleArray"
    // InternalSM2.g:2528:1: ruleArray returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )* ) ;
    public final AntlrDatatypeRuleToken ruleArray() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_SINGLENUMBER_2=null;
        Token this_INTEGER_3=null;
        Token this_SINGLENUMBER_7=null;
        Token this_INTEGER_8=null;


        	enterRule();

        try {
            // InternalSM2.g:2534:2: ( ( (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )* ) )
            // InternalSM2.g:2535:2: ( (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )* )
            {
            // InternalSM2.g:2535:2: ( (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )* )
            // InternalSM2.g:2536:3: (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )*
            {
            // InternalSM2.g:2536:3: (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) )
            int alt80=3;
            switch ( input.LA(1) ) {
            case 74:
                {
                alt80=1;
                }
                break;
            case 75:
                {
                alt80=2;
                }
                break;
            case RULE_INTEGER:
                {
                alt80=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 80, 0, input);

                throw nvae;
            }

            switch (alt80) {
                case 1 :
                    // InternalSM2.g:2537:4: kw= '[]'
                    {
                    kw=(Token)match(input,74,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current.merge(kw);
                      				newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_0_0());
                      			
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2543:4: (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER )
                    {
                    // InternalSM2.g:2543:4: (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER )
                    // InternalSM2.g:2544:5: kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER
                    {
                    kw=(Token)match(input,75,FOLLOW_61); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					current.merge(kw);
                      					newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_0_1_0());
                      				
                    }
                    this_SINGLENUMBER_2=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					current.merge(this_SINGLENUMBER_2);
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_SINGLENUMBER_2, grammarAccess.getArrayAccess().getSINGLENUMBERTerminalRuleCall_0_1_1());
                      				
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2558:4: (this_INTEGER_3= RULE_INTEGER kw= ']' )
                    {
                    // InternalSM2.g:2558:4: (this_INTEGER_3= RULE_INTEGER kw= ']' )
                    // InternalSM2.g:2559:5: this_INTEGER_3= RULE_INTEGER kw= ']'
                    {
                    this_INTEGER_3=(Token)match(input,RULE_INTEGER,FOLLOW_62); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					current.merge(this_INTEGER_3);
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_INTEGER_3, grammarAccess.getArrayAccess().getINTEGERTerminalRuleCall_0_2_0());
                      				
                    }
                    kw=(Token)match(input,76,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					current.merge(kw);
                      					newLeafNode(kw, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_0_2_1());
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2573:3: (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )*
            loop81:
            do {
                int alt81=4;
                switch ( input.LA(1) ) {
                case 74:
                    {
                    alt81=1;
                    }
                    break;
                case 75:
                    {
                    alt81=2;
                    }
                    break;
                case RULE_INTEGER:
                    {
                    alt81=3;
                    }
                    break;

                }

                switch (alt81) {
            	case 1 :
            	    // InternalSM2.g:2574:4: kw= '[]'
            	    {
            	    kw=(Token)match(input,74,FOLLOW_60); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      				current.merge(kw);
            	      				newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_1_0());
            	      			
            	    }

            	    }
            	    break;
            	case 2 :
            	    // InternalSM2.g:2580:4: (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER )
            	    {
            	    // InternalSM2.g:2580:4: (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER )
            	    // InternalSM2.g:2581:5: kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER
            	    {
            	    kw=(Token)match(input,75,FOLLOW_61); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					current.merge(kw);
            	      					newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_1_1_0());
            	      				
            	    }
            	    this_SINGLENUMBER_7=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_60); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					current.merge(this_SINGLENUMBER_7);
            	      				
            	    }
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(this_SINGLENUMBER_7, grammarAccess.getArrayAccess().getSINGLENUMBERTerminalRuleCall_1_1_1());
            	      				
            	    }

            	    }


            	    }
            	    break;
            	case 3 :
            	    // InternalSM2.g:2595:4: (this_INTEGER_8= RULE_INTEGER kw= ']' )
            	    {
            	    // InternalSM2.g:2595:4: (this_INTEGER_8= RULE_INTEGER kw= ']' )
            	    // InternalSM2.g:2596:5: this_INTEGER_8= RULE_INTEGER kw= ']'
            	    {
            	    this_INTEGER_8=(Token)match(input,RULE_INTEGER,FOLLOW_62); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					current.merge(this_INTEGER_8);
            	      				
            	    }
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(this_INTEGER_8, grammarAccess.getArrayAccess().getINTEGERTerminalRuleCall_1_2_0());
            	      				
            	    }
            	    kw=(Token)match(input,76,FOLLOW_60); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					current.merge(kw);
            	      					newLeafNode(kw, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_1_2_1());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop81;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArray"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:2614:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // InternalSM2.g:2614:49: (iv_ruleProperty= ruleProperty EOF )
            // InternalSM2.g:2615:2: iv_ruleProperty= ruleProperty EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleProperty=ruleProperty();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleProperty; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:2621:1: ruleProperty returns [EObject current=null] : (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        EObject this_PropertyString_0 = null;

        EObject this_PropertyInteger_1 = null;

        EObject this_PropertyFloat_2 = null;

        EObject this_PropertyAddress_3 = null;

        EObject this_PropertyBoolean_4 = null;

        EObject this_PropertyBytes_5 = null;

        EObject this_PropertyStruct_6 = null;



        	enterRule();

        try {
            // InternalSM2.g:2627:2: ( (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct ) )
            // InternalSM2.g:2628:2: (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct )
            {
            // InternalSM2.g:2628:2: (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct )
            int alt82=7;
            switch ( input.LA(1) ) {
            case 70:
                {
                alt82=1;
                }
                break;
            case 77:
            case 78:
            case 79:
            case 80:
            case 81:
            case 82:
                {
                alt82=2;
                }
                break;
            case 71:
                {
                alt82=3;
                }
                break;
            case 68:
            case 84:
                {
                alt82=4;
                }
                break;
            case 83:
                {
                alt82=5;
                }
                break;
            case 85:
            case 86:
            case 87:
            case 88:
            case 89:
                {
                alt82=6;
                }
                break;
            case RULE_ID:
                {
                alt82=7;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 82, 0, input);

                throw nvae;
            }

            switch (alt82) {
                case 1 :
                    // InternalSM2.g:2629:3: this_PropertyString_0= rulePropertyString
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyStringParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyString_0=rulePropertyString();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyString_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2638:3: this_PropertyInteger_1= rulePropertyInteger
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyIntegerParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyInteger_1=rulePropertyInteger();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyInteger_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2647:3: this_PropertyFloat_2= rulePropertyFloat
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyFloatParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyFloat_2=rulePropertyFloat();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyFloat_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:2656:3: this_PropertyAddress_3= rulePropertyAddress
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyAddressParserRuleCall_3());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyAddress_3=rulePropertyAddress();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyAddress_3;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:2665:3: this_PropertyBoolean_4= rulePropertyBoolean
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyBooleanParserRuleCall_4());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyBoolean_4=rulePropertyBoolean();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyBoolean_4;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 6 :
                    // InternalSM2.g:2674:3: this_PropertyBytes_5= rulePropertyBytes
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyBytesParserRuleCall_5());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyBytes_5=rulePropertyBytes();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyBytes_5;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 7 :
                    // InternalSM2.g:2683:3: this_PropertyStruct_6= rulePropertyStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyStructParserRuleCall_6());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyStruct_6=rulePropertyStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyStruct_6;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRulePropertyString"
    // InternalSM2.g:2695:1: entryRulePropertyString returns [EObject current=null] : iv_rulePropertyString= rulePropertyString EOF ;
    public final EObject entryRulePropertyString() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyString = null;


        try {
            // InternalSM2.g:2695:55: (iv_rulePropertyString= rulePropertyString EOF )
            // InternalSM2.g:2696:2: iv_rulePropertyString= rulePropertyString EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyStringRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyString=rulePropertyString();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyString; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyString"


    // $ANTLR start "rulePropertyString"
    // InternalSM2.g:2702:1: rulePropertyString returns [EObject current=null] : ( () otherlv_1= 'string' ( (lv_inicialization_2_0= RULE_STRING ) )? this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ) ;
    public final EObject rulePropertyString() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_inicialization_2_0=null;
        Token this_SEMICOLON_3=null;
        Token this_EOLINE_4=null;


        	enterRule();

        try {
            // InternalSM2.g:2708:2: ( ( () otherlv_1= 'string' ( (lv_inicialization_2_0= RULE_STRING ) )? this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ) )
            // InternalSM2.g:2709:2: ( () otherlv_1= 'string' ( (lv_inicialization_2_0= RULE_STRING ) )? this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? )
            {
            // InternalSM2.g:2709:2: ( () otherlv_1= 'string' ( (lv_inicialization_2_0= RULE_STRING ) )? this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? )
            // InternalSM2.g:2710:3: () otherlv_1= 'string' ( (lv_inicialization_2_0= RULE_STRING ) )? this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )?
            {
            // InternalSM2.g:2710:3: ()
            // InternalSM2.g:2711:4: 
            {
            if ( state.backtracking==0 ) {

              				current = forceCreateModelElement(
              					grammarAccess.getPropertyStringAccess().getPropertyStringAction_0(),
              					current);
              			
            }

            }

            otherlv_1=(Token)match(input,70,FOLLOW_63); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getPropertyStringAccess().getStringKeyword_1());
              		
            }
            // InternalSM2.g:2721:3: ( (lv_inicialization_2_0= RULE_STRING ) )?
            int alt83=2;
            int LA83_0 = input.LA(1);

            if ( (LA83_0==RULE_STRING) ) {
                alt83=1;
            }
            switch (alt83) {
                case 1 :
                    // InternalSM2.g:2722:4: (lv_inicialization_2_0= RULE_STRING )
                    {
                    // InternalSM2.g:2722:4: (lv_inicialization_2_0= RULE_STRING )
                    // InternalSM2.g:2723:5: lv_inicialization_2_0= RULE_STRING
                    {
                    lv_inicialization_2_0=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_inicialization_2_0, grammarAccess.getPropertyStringAccess().getInicializationSTRINGTerminalRuleCall_2_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getPropertyStringRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"inicialization",
                      						lv_inicialization_2_0,
                      						"org.eclipse.xtext.common.Terminals.STRING");
                      				
                    }

                    }


                    }
                    break;

            }

            this_SEMICOLON_3=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_3, grammarAccess.getPropertyStringAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:2743:3: (this_EOLINE_4= RULE_EOLINE )?
            int alt84=2;
            int LA84_0 = input.LA(1);

            if ( (LA84_0==RULE_EOLINE) ) {
                alt84=1;
            }
            switch (alt84) {
                case 1 :
                    // InternalSM2.g:2744:4: this_EOLINE_4= RULE_EOLINE
                    {
                    this_EOLINE_4=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_4, grammarAccess.getPropertyStringAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyString"


    // $ANTLR start "entryRulePropertyInteger"
    // InternalSM2.g:2753:1: entryRulePropertyInteger returns [EObject current=null] : iv_rulePropertyInteger= rulePropertyInteger EOF ;
    public final EObject entryRulePropertyInteger() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyInteger = null;


        try {
            // InternalSM2.g:2753:56: (iv_rulePropertyInteger= rulePropertyInteger EOF )
            // InternalSM2.g:2754:2: iv_rulePropertyInteger= rulePropertyInteger EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyIntegerRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyInteger=rulePropertyInteger();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyInteger; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyInteger"


    // $ANTLR start "rulePropertyInteger"
    // InternalSM2.g:2760:1: rulePropertyInteger returns [EObject current=null] : ( ( ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint' | lv_option_0_3= 'uint8' | lv_option_0_4= 'uint32' | lv_option_0_5= 'uint64' | lv_option_0_6= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyInteger() throws RecognitionException {
        EObject current = null;

        Token lv_option_0_1=null;
        Token lv_option_0_2=null;
        Token lv_option_0_3=null;
        Token lv_option_0_4=null;
        Token lv_option_0_5=null;
        Token lv_option_0_6=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token lv_inicialization_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2766:2: ( ( ( ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint' | lv_option_0_3= 'uint8' | lv_option_0_4= 'uint32' | lv_option_0_5= 'uint64' | lv_option_0_6= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2767:2: ( ( ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint' | lv_option_0_3= 'uint8' | lv_option_0_4= 'uint32' | lv_option_0_5= 'uint64' | lv_option_0_6= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2767:2: ( ( ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint' | lv_option_0_3= 'uint8' | lv_option_0_4= 'uint32' | lv_option_0_5= 'uint64' | lv_option_0_6= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2768:3: ( ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint' | lv_option_0_3= 'uint8' | lv_option_0_4= 'uint32' | lv_option_0_5= 'uint64' | lv_option_0_6= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:2768:3: ( ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint' | lv_option_0_3= 'uint8' | lv_option_0_4= 'uint32' | lv_option_0_5= 'uint64' | lv_option_0_6= 'uint256' ) ) )
            // InternalSM2.g:2769:4: ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint' | lv_option_0_3= 'uint8' | lv_option_0_4= 'uint32' | lv_option_0_5= 'uint64' | lv_option_0_6= 'uint256' ) )
            {
            // InternalSM2.g:2769:4: ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint' | lv_option_0_3= 'uint8' | lv_option_0_4= 'uint32' | lv_option_0_5= 'uint64' | lv_option_0_6= 'uint256' ) )
            // InternalSM2.g:2770:5: (lv_option_0_1= 'int' | lv_option_0_2= 'uint' | lv_option_0_3= 'uint8' | lv_option_0_4= 'uint32' | lv_option_0_5= 'uint64' | lv_option_0_6= 'uint256' )
            {
            // InternalSM2.g:2770:5: (lv_option_0_1= 'int' | lv_option_0_2= 'uint' | lv_option_0_3= 'uint8' | lv_option_0_4= 'uint32' | lv_option_0_5= 'uint64' | lv_option_0_6= 'uint256' )
            int alt85=6;
            switch ( input.LA(1) ) {
            case 77:
                {
                alt85=1;
                }
                break;
            case 78:
                {
                alt85=2;
                }
                break;
            case 79:
                {
                alt85=3;
                }
                break;
            case 80:
                {
                alt85=4;
                }
                break;
            case 81:
                {
                alt85=5;
                }
                break;
            case 82:
                {
                alt85=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 85, 0, input);

                throw nvae;
            }

            switch (alt85) {
                case 1 :
                    // InternalSM2.g:2771:6: lv_option_0_1= 'int'
                    {
                    lv_option_0_1=(Token)match(input,77,FOLLOW_64); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_1, grammarAccess.getPropertyIntegerAccess().getOptionIntKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2782:6: lv_option_0_2= 'uint'
                    {
                    lv_option_0_2=(Token)match(input,78,FOLLOW_64); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_2, grammarAccess.getPropertyIntegerAccess().getOptionUintKeyword_0_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_2, null);
                      					
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2793:6: lv_option_0_3= 'uint8'
                    {
                    lv_option_0_3=(Token)match(input,79,FOLLOW_64); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_3, grammarAccess.getPropertyIntegerAccess().getOptionUint8Keyword_0_0_2());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_3, null);
                      					
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:2804:6: lv_option_0_4= 'uint32'
                    {
                    lv_option_0_4=(Token)match(input,80,FOLLOW_64); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_4, grammarAccess.getPropertyIntegerAccess().getOptionUint32Keyword_0_0_3());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_4, null);
                      					
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:2815:6: lv_option_0_5= 'uint64'
                    {
                    lv_option_0_5=(Token)match(input,81,FOLLOW_64); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_5, grammarAccess.getPropertyIntegerAccess().getOptionUint64Keyword_0_0_4());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_5, null);
                      					
                    }

                    }
                    break;
                case 6 :
                    // InternalSM2.g:2826:6: lv_option_0_6= 'uint256'
                    {
                    lv_option_0_6=(Token)match(input,82,FOLLOW_64); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_6, grammarAccess.getPropertyIntegerAccess().getOptionUint256Keyword_0_0_5());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_6, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:2839:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt86=2;
            int LA86_0 = input.LA(1);

            if ( (LA86_0==RULE_INTEGER||(LA86_0>=74 && LA86_0<=75)) ) {
                alt86=1;
            }
            switch (alt86) {
                case 1 :
                    // InternalSM2.g:2840:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:2840:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:2841:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyIntegerAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_42);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyIntegerRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2858:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt87=2;
            int LA87_0 = input.LA(1);

            if ( ((LA87_0>=60 && LA87_0<=61)||(LA87_0>=103 && LA87_0<=104)) ) {
                alt87=1;
            }
            switch (alt87) {
                case 1 :
                    // InternalSM2.g:2859:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:2859:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:2860:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyIntegerAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_11);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyIntegerRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2877:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:2878:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:2878:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:2879:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_65); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyIntegerAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyIntegerRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            otherlv_4=(Token)match(input,69,FOLLOW_66); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getPropertyIntegerAccess().getEqualsSignKeyword_4());
              		
            }
            // InternalSM2.g:2899:3: ( (lv_inicialization_5_0= RULE_INTEGER ) )?
            int alt88=2;
            int LA88_0 = input.LA(1);

            if ( (LA88_0==RULE_INTEGER) ) {
                alt88=1;
            }
            switch (alt88) {
                case 1 :
                    // InternalSM2.g:2900:4: (lv_inicialization_5_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:2900:4: (lv_inicialization_5_0= RULE_INTEGER )
                    // InternalSM2.g:2901:5: lv_inicialization_5_0= RULE_INTEGER
                    {
                    lv_inicialization_5_0=(Token)match(input,RULE_INTEGER,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_inicialization_5_0, grammarAccess.getPropertyIntegerAccess().getInicializationINTEGERTerminalRuleCall_5_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"inicialization",
                      						lv_inicialization_5_0,
                      						"org.xtext.SM2.INTEGER");
                      				
                    }

                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyIntegerAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:2921:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt89=2;
            int LA89_0 = input.LA(1);

            if ( (LA89_0==RULE_EOLINE) ) {
                alt89=1;
            }
            switch (alt89) {
                case 1 :
                    // InternalSM2.g:2922:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyIntegerAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyInteger"


    // $ANTLR start "entryRulePropertyFloat"
    // InternalSM2.g:2931:1: entryRulePropertyFloat returns [EObject current=null] : iv_rulePropertyFloat= rulePropertyFloat EOF ;
    public final EObject entryRulePropertyFloat() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyFloat = null;


        try {
            // InternalSM2.g:2931:54: (iv_rulePropertyFloat= rulePropertyFloat EOF )
            // InternalSM2.g:2932:2: iv_rulePropertyFloat= rulePropertyFloat EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyFloatRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyFloat=rulePropertyFloat();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyFloat; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyFloat"


    // $ANTLR start "rulePropertyFloat"
    // InternalSM2.g:2938:1: rulePropertyFloat returns [EObject current=null] : (otherlv_0= 'float' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyFloat() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token lv_inicialization_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2944:2: ( (otherlv_0= 'float' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2945:2: (otherlv_0= 'float' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2945:2: (otherlv_0= 'float' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2946:3: otherlv_0= 'float' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,71,FOLLOW_64); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getPropertyFloatAccess().getFloatKeyword_0());
              		
            }
            // InternalSM2.g:2950:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt90=2;
            int LA90_0 = input.LA(1);

            if ( (LA90_0==RULE_INTEGER||(LA90_0>=74 && LA90_0<=75)) ) {
                alt90=1;
            }
            switch (alt90) {
                case 1 :
                    // InternalSM2.g:2951:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:2951:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:2952:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyFloatAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_42);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyFloatRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2969:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt91=2;
            int LA91_0 = input.LA(1);

            if ( ((LA91_0>=60 && LA91_0<=61)||(LA91_0>=103 && LA91_0<=104)) ) {
                alt91=1;
            }
            switch (alt91) {
                case 1 :
                    // InternalSM2.g:2970:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:2970:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:2971:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyFloatAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_11);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyFloatRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2988:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:2989:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:2989:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:2990:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyFloatAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyFloatRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3006:3: (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) ) )?
            int alt92=2;
            int LA92_0 = input.LA(1);

            if ( (LA92_0==69) ) {
                alt92=1;
            }
            switch (alt92) {
                case 1 :
                    // InternalSM2.g:3007:4: otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) )
                    {
                    otherlv_4=(Token)match(input,69,FOLLOW_67); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyFloatAccess().getEqualsSignKeyword_4_0());
                      			
                    }
                    // InternalSM2.g:3011:4: ( (lv_inicialization_5_0= RULE_FLOAT ) )
                    // InternalSM2.g:3012:5: (lv_inicialization_5_0= RULE_FLOAT )
                    {
                    // InternalSM2.g:3012:5: (lv_inicialization_5_0= RULE_FLOAT )
                    // InternalSM2.g:3013:6: lv_inicialization_5_0= RULE_FLOAT
                    {
                    lv_inicialization_5_0=(Token)match(input,RULE_FLOAT,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_inicialization_5_0, grammarAccess.getPropertyFloatAccess().getInicializationFLOATTerminalRuleCall_4_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyFloatRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"inicialization",
                      							lv_inicialization_5_0,
                      							"org.xtext.SM2.FLOAT");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyFloatAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:3034:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt93=2;
            int LA93_0 = input.LA(1);

            if ( (LA93_0==RULE_EOLINE) ) {
                alt93=1;
            }
            switch (alt93) {
                case 1 :
                    // InternalSM2.g:3035:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyFloatAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyFloat"


    // $ANTLR start "entryRulePropertyBoolean"
    // InternalSM2.g:3044:1: entryRulePropertyBoolean returns [EObject current=null] : iv_rulePropertyBoolean= rulePropertyBoolean EOF ;
    public final EObject entryRulePropertyBoolean() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyBoolean = null;


        try {
            // InternalSM2.g:3044:56: (iv_rulePropertyBoolean= rulePropertyBoolean EOF )
            // InternalSM2.g:3045:2: iv_rulePropertyBoolean= rulePropertyBoolean EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyBooleanRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyBoolean=rulePropertyBoolean();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyBoolean; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyBoolean"


    // $ANTLR start "rulePropertyBoolean"
    // InternalSM2.g:3051:1: rulePropertyBoolean returns [EObject current=null] : (otherlv_0= 'bool' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyBoolean() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token lv_inicialization_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3057:2: ( (otherlv_0= 'bool' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:3058:2: (otherlv_0= 'bool' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:3058:2: (otherlv_0= 'bool' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:3059:3: otherlv_0= 'bool' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,83,FOLLOW_64); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getPropertyBooleanAccess().getBoolKeyword_0());
              		
            }
            // InternalSM2.g:3063:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt94=2;
            int LA94_0 = input.LA(1);

            if ( (LA94_0==RULE_INTEGER||(LA94_0>=74 && LA94_0<=75)) ) {
                alt94=1;
            }
            switch (alt94) {
                case 1 :
                    // InternalSM2.g:3064:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3064:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3065:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBooleanAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_42);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBooleanRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3082:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt95=2;
            int LA95_0 = input.LA(1);

            if ( ((LA95_0>=60 && LA95_0<=61)||(LA95_0>=103 && LA95_0<=104)) ) {
                alt95=1;
            }
            switch (alt95) {
                case 1 :
                    // InternalSM2.g:3083:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3083:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3084:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBooleanAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_11);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBooleanRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3101:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:3102:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:3102:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:3103:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyBooleanAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyBooleanRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3119:3: (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) ) )?
            int alt96=2;
            int LA96_0 = input.LA(1);

            if ( (LA96_0==69) ) {
                alt96=1;
            }
            switch (alt96) {
                case 1 :
                    // InternalSM2.g:3120:4: otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) )
                    {
                    otherlv_4=(Token)match(input,69,FOLLOW_68); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyBooleanAccess().getEqualsSignKeyword_4_0());
                      			
                    }
                    // InternalSM2.g:3124:4: ( (lv_inicialization_5_0= RULE_BOOLVALUE ) )
                    // InternalSM2.g:3125:5: (lv_inicialization_5_0= RULE_BOOLVALUE )
                    {
                    // InternalSM2.g:3125:5: (lv_inicialization_5_0= RULE_BOOLVALUE )
                    // InternalSM2.g:3126:6: lv_inicialization_5_0= RULE_BOOLVALUE
                    {
                    lv_inicialization_5_0=(Token)match(input,RULE_BOOLVALUE,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_inicialization_5_0, grammarAccess.getPropertyBooleanAccess().getInicializationBOOLVALUETerminalRuleCall_4_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBooleanRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"inicialization",
                      							lv_inicialization_5_0,
                      							"org.xtext.SM2.BOOLVALUE");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyBooleanAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:3147:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt97=2;
            int LA97_0 = input.LA(1);

            if ( (LA97_0==RULE_EOLINE) ) {
                alt97=1;
            }
            switch (alt97) {
                case 1 :
                    // InternalSM2.g:3148:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyBooleanAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyBoolean"


    // $ANTLR start "entryRulePropertyAddress"
    // InternalSM2.g:3157:1: entryRulePropertyAddress returns [EObject current=null] : iv_rulePropertyAddress= rulePropertyAddress EOF ;
    public final EObject entryRulePropertyAddress() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyAddress = null;


        try {
            // InternalSM2.g:3157:56: (iv_rulePropertyAddress= rulePropertyAddress EOF )
            // InternalSM2.g:3158:2: iv_rulePropertyAddress= rulePropertyAddress EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyAddressRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyAddress=rulePropertyAddress();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyAddress; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyAddress"


    // $ANTLR start "rulePropertyAddress"
    // InternalSM2.g:3164:1: rulePropertyAddress returns [EObject current=null] : ( ( ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyAddress() throws RecognitionException {
        EObject current = null;

        Token lv_option_0_1=null;
        Token lv_option_0_2=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;

        EObject lv_inicialization_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3170:2: ( ( ( ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:3171:2: ( ( ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:3171:2: ( ( ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:3172:3: ( ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:3172:3: ( ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) ) )
            // InternalSM2.g:3173:4: ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) )
            {
            // InternalSM2.g:3173:4: ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) )
            // InternalSM2.g:3174:5: (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' )
            {
            // InternalSM2.g:3174:5: (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' )
            int alt98=2;
            int LA98_0 = input.LA(1);

            if ( (LA98_0==68) ) {
                alt98=1;
            }
            else if ( (LA98_0==84) ) {
                alt98=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 98, 0, input);

                throw nvae;
            }
            switch (alt98) {
                case 1 :
                    // InternalSM2.g:3175:6: lv_option_0_1= 'address'
                    {
                    lv_option_0_1=(Token)match(input,68,FOLLOW_64); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_1, grammarAccess.getPropertyAddressAccess().getOptionAddressKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyAddressRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3186:6: lv_option_0_2= 'address payable'
                    {
                    lv_option_0_2=(Token)match(input,84,FOLLOW_64); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_2, grammarAccess.getPropertyAddressAccess().getOptionAddressPayableKeyword_0_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyAddressRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_2, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:3199:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt99=2;
            int LA99_0 = input.LA(1);

            if ( (LA99_0==RULE_INTEGER||(LA99_0>=74 && LA99_0<=75)) ) {
                alt99=1;
            }
            switch (alt99) {
                case 1 :
                    // InternalSM2.g:3200:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3200:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3201:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyAddressAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_42);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3218:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt100=2;
            int LA100_0 = input.LA(1);

            if ( ((LA100_0>=60 && LA100_0<=61)||(LA100_0>=103 && LA100_0<=104)) ) {
                alt100=1;
            }
            switch (alt100) {
                case 1 :
                    // InternalSM2.g:3219:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3219:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3220:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyAddressAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_11);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3237:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:3238:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:3238:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:3239:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyAddressAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyAddressRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3255:3: (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )?
            int alt101=2;
            int LA101_0 = input.LA(1);

            if ( (LA101_0==69) ) {
                alt101=1;
            }
            switch (alt101) {
                case 1 :
                    // InternalSM2.g:3256:4: otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    {
                    otherlv_4=(Token)match(input,69,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyAddressAccess().getEqualsSignKeyword_4_0());
                      			
                    }
                    // InternalSM2.g:3260:4: ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    // InternalSM2.g:3261:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    {
                    // InternalSM2.g:3261:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    // InternalSM2.g:3262:6: lv_inicialization_5_0= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getPropertyAddressAccess().getInicializationSyntaxExpressionParserRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_5);
                    lv_inicialization_5_0=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                      						}
                      						set(
                      							current,
                      							"inicialization",
                      							lv_inicialization_5_0,
                      							"org.xtext.SM2.SyntaxExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyAddressAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:3284:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt102=2;
            int LA102_0 = input.LA(1);

            if ( (LA102_0==RULE_EOLINE) ) {
                alt102=1;
            }
            switch (alt102) {
                case 1 :
                    // InternalSM2.g:3285:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyAddressAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyAddress"


    // $ANTLR start "entryRulePropertyBytes"
    // InternalSM2.g:3294:1: entryRulePropertyBytes returns [EObject current=null] : iv_rulePropertyBytes= rulePropertyBytes EOF ;
    public final EObject entryRulePropertyBytes() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyBytes = null;


        try {
            // InternalSM2.g:3294:54: (iv_rulePropertyBytes= rulePropertyBytes EOF )
            // InternalSM2.g:3295:2: iv_rulePropertyBytes= rulePropertyBytes EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyBytesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyBytes=rulePropertyBytes();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyBytes; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyBytes"


    // $ANTLR start "rulePropertyBytes"
    // InternalSM2.g:3301:1: rulePropertyBytes returns [EObject current=null] : ( ( ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes4' | lv_option_0_3= 'bytes8' | lv_option_0_4= 'bytes16' | lv_option_0_5= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyBytes() throws RecognitionException {
        EObject current = null;

        Token lv_option_0_1=null;
        Token lv_option_0_2=null;
        Token lv_option_0_3=null;
        Token lv_option_0_4=null;
        Token lv_option_0_5=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;

        EObject lv_inicialization_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3307:2: ( ( ( ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes4' | lv_option_0_3= 'bytes8' | lv_option_0_4= 'bytes16' | lv_option_0_5= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:3308:2: ( ( ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes4' | lv_option_0_3= 'bytes8' | lv_option_0_4= 'bytes16' | lv_option_0_5= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:3308:2: ( ( ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes4' | lv_option_0_3= 'bytes8' | lv_option_0_4= 'bytes16' | lv_option_0_5= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:3309:3: ( ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes4' | lv_option_0_3= 'bytes8' | lv_option_0_4= 'bytes16' | lv_option_0_5= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:3309:3: ( ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes4' | lv_option_0_3= 'bytes8' | lv_option_0_4= 'bytes16' | lv_option_0_5= 'bytes32' ) ) )
            // InternalSM2.g:3310:4: ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes4' | lv_option_0_3= 'bytes8' | lv_option_0_4= 'bytes16' | lv_option_0_5= 'bytes32' ) )
            {
            // InternalSM2.g:3310:4: ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes4' | lv_option_0_3= 'bytes8' | lv_option_0_4= 'bytes16' | lv_option_0_5= 'bytes32' ) )
            // InternalSM2.g:3311:5: (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes4' | lv_option_0_3= 'bytes8' | lv_option_0_4= 'bytes16' | lv_option_0_5= 'bytes32' )
            {
            // InternalSM2.g:3311:5: (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes4' | lv_option_0_3= 'bytes8' | lv_option_0_4= 'bytes16' | lv_option_0_5= 'bytes32' )
            int alt103=5;
            switch ( input.LA(1) ) {
            case 85:
                {
                alt103=1;
                }
                break;
            case 86:
                {
                alt103=2;
                }
                break;
            case 87:
                {
                alt103=3;
                }
                break;
            case 88:
                {
                alt103=4;
                }
                break;
            case 89:
                {
                alt103=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 103, 0, input);

                throw nvae;
            }

            switch (alt103) {
                case 1 :
                    // InternalSM2.g:3312:6: lv_option_0_1= 'bytes'
                    {
                    lv_option_0_1=(Token)match(input,85,FOLLOW_64); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_1, grammarAccess.getPropertyBytesAccess().getOptionBytesKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3323:6: lv_option_0_2= 'bytes4'
                    {
                    lv_option_0_2=(Token)match(input,86,FOLLOW_64); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_2, grammarAccess.getPropertyBytesAccess().getOptionBytes4Keyword_0_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_2, null);
                      					
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:3334:6: lv_option_0_3= 'bytes8'
                    {
                    lv_option_0_3=(Token)match(input,87,FOLLOW_64); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_3, grammarAccess.getPropertyBytesAccess().getOptionBytes8Keyword_0_0_2());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_3, null);
                      					
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:3345:6: lv_option_0_4= 'bytes16'
                    {
                    lv_option_0_4=(Token)match(input,88,FOLLOW_64); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_4, grammarAccess.getPropertyBytesAccess().getOptionBytes16Keyword_0_0_3());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_4, null);
                      					
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:3356:6: lv_option_0_5= 'bytes32'
                    {
                    lv_option_0_5=(Token)match(input,89,FOLLOW_64); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_5, grammarAccess.getPropertyBytesAccess().getOptionBytes32Keyword_0_0_4());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_5, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:3369:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt104=2;
            int LA104_0 = input.LA(1);

            if ( (LA104_0==RULE_INTEGER||(LA104_0>=74 && LA104_0<=75)) ) {
                alt104=1;
            }
            switch (alt104) {
                case 1 :
                    // InternalSM2.g:3370:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3370:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3371:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBytesAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_42);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3388:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt105=2;
            int LA105_0 = input.LA(1);

            if ( ((LA105_0>=60 && LA105_0<=61)||(LA105_0>=103 && LA105_0<=104)) ) {
                alt105=1;
            }
            switch (alt105) {
                case 1 :
                    // InternalSM2.g:3389:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3389:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3390:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBytesAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_11);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3407:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:3408:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:3408:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:3409:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyBytesAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyBytesRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3425:3: (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )?
            int alt106=2;
            int LA106_0 = input.LA(1);

            if ( (LA106_0==69) ) {
                alt106=1;
            }
            switch (alt106) {
                case 1 :
                    // InternalSM2.g:3426:4: otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    {
                    otherlv_4=(Token)match(input,69,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyBytesAccess().getEqualsSignKeyword_4_0());
                      			
                    }
                    // InternalSM2.g:3430:4: ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    // InternalSM2.g:3431:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    {
                    // InternalSM2.g:3431:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    // InternalSM2.g:3432:6: lv_inicialization_5_0= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getPropertyBytesAccess().getInicializationSyntaxExpressionParserRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_5);
                    lv_inicialization_5_0=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                      						}
                      						set(
                      							current,
                      							"inicialization",
                      							lv_inicialization_5_0,
                      							"org.xtext.SM2.SyntaxExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyBytesAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:3454:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt107=2;
            int LA107_0 = input.LA(1);

            if ( (LA107_0==RULE_EOLINE) ) {
                alt107=1;
            }
            switch (alt107) {
                case 1 :
                    // InternalSM2.g:3455:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyBytesAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyBytes"


    // $ANTLR start "entryRulePropertyStruct"
    // InternalSM2.g:3464:1: entryRulePropertyStruct returns [EObject current=null] : iv_rulePropertyStruct= rulePropertyStruct EOF ;
    public final EObject entryRulePropertyStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyStruct = null;


        try {
            // InternalSM2.g:3464:55: (iv_rulePropertyStruct= rulePropertyStruct EOF )
            // InternalSM2.g:3465:2: iv_rulePropertyStruct= rulePropertyStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyStruct=rulePropertyStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyStruct"


    // $ANTLR start "rulePropertyStruct"
    // InternalSM2.g:3471:1: rulePropertyStruct returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;

        EObject lv_inicialization_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3477:2: ( ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:3478:2: ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:3478:2: ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:3479:3: ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:3479:3: ( (otherlv_0= RULE_ID ) )
            // InternalSM2.g:3480:4: (otherlv_0= RULE_ID )
            {
            // InternalSM2.g:3480:4: (otherlv_0= RULE_ID )
            // InternalSM2.g:3481:5: otherlv_0= RULE_ID
            {
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyStructRule());
              					}
              				
            }
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_64); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(otherlv_0, grammarAccess.getPropertyStructAccess().getAssignedStructStructCrossReference_0_0());
              				
            }

            }


            }

            // InternalSM2.g:3492:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt108=2;
            int LA108_0 = input.LA(1);

            if ( (LA108_0==RULE_INTEGER||(LA108_0>=74 && LA108_0<=75)) ) {
                alt108=1;
            }
            switch (alt108) {
                case 1 :
                    // InternalSM2.g:3493:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3493:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3494:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyStructAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_42);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyStructRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3511:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt109=2;
            int LA109_0 = input.LA(1);

            if ( ((LA109_0>=60 && LA109_0<=61)||(LA109_0>=103 && LA109_0<=104)) ) {
                alt109=1;
            }
            switch (alt109) {
                case 1 :
                    // InternalSM2.g:3512:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3512:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3513:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyStructAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_11);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyStructRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3530:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:3531:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:3531:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:3532:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyStructAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyStructRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3548:3: (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )?
            int alt110=2;
            int LA110_0 = input.LA(1);

            if ( (LA110_0==69) ) {
                alt110=1;
            }
            switch (alt110) {
                case 1 :
                    // InternalSM2.g:3549:4: otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    {
                    otherlv_4=(Token)match(input,69,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyStructAccess().getEqualsSignKeyword_4_0());
                      			
                    }
                    // InternalSM2.g:3553:4: ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    // InternalSM2.g:3554:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    {
                    // InternalSM2.g:3554:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    // InternalSM2.g:3555:6: lv_inicialization_5_0= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getPropertyStructAccess().getInicializationSyntaxExpressionParserRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_5);
                    lv_inicialization_5_0=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getPropertyStructRule());
                      						}
                      						set(
                      							current,
                      							"inicialization",
                      							lv_inicialization_5_0,
                      							"org.xtext.SM2.SyntaxExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyStructAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:3577:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt111=2;
            int LA111_0 = input.LA(1);

            if ( (LA111_0==RULE_EOLINE) ) {
                alt111=1;
            }
            switch (alt111) {
                case 1 :
                    // InternalSM2.g:3578:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyStructAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyStruct"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:3587:1: entryRuleInputParam returns [EObject current=null] : iv_ruleInputParam= ruleInputParam EOF ;
    public final EObject entryRuleInputParam() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputParam = null;


        try {
            // InternalSM2.g:3587:51: (iv_ruleInputParam= ruleInputParam EOF )
            // InternalSM2.g:3588:2: iv_ruleInputParam= ruleInputParam EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getInputParamRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleInputParam=ruleInputParam();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleInputParam; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:3594:1: ruleInputParam returns [EObject current=null] : ( ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )? ) ;
    public final EObject ruleInputParam() throws RecognitionException {
        EObject current = null;

        Token lv_storage_2_0=null;
        Token otherlv_3=null;
        Token lv_nameParam_4_0=null;
        Token this_COMMA_5=null;
        Enumerator lv_type_0_0 = null;

        AntlrDatatypeRuleToken lv_isArray_1_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3600:2: ( ( ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )? ) )
            // InternalSM2.g:3601:2: ( ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )? )
            {
            // InternalSM2.g:3601:2: ( ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )? )
            // InternalSM2.g:3602:3: ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )?
            {
            // InternalSM2.g:3602:3: ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) )
            // InternalSM2.g:3603:4: ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) )
            {
            // InternalSM2.g:3603:4: ( (lv_type_0_0= ruleBasicType ) )
            // InternalSM2.g:3604:5: (lv_type_0_0= ruleBasicType )
            {
            // InternalSM2.g:3604:5: (lv_type_0_0= ruleBasicType )
            // InternalSM2.g:3605:6: lv_type_0_0= ruleBasicType
            {
            if ( state.backtracking==0 ) {

              						newCompositeNode(grammarAccess.getInputParamAccess().getTypeBasicTypeEnumRuleCall_0_0_0());
              					
            }
            pushFollow(FOLLOW_69);
            lv_type_0_0=ruleBasicType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElementForParent(grammarAccess.getInputParamRule());
              						}
              						set(
              							current,
              							"type",
              							lv_type_0_0,
              							"org.xtext.SM2.BasicType");
              						afterParserOrEnumRuleCall();
              					
            }

            }


            }

            // InternalSM2.g:3622:4: ( (lv_isArray_1_0= ruleArray ) )?
            int alt112=2;
            int LA112_0 = input.LA(1);

            if ( (LA112_0==RULE_INTEGER||(LA112_0>=74 && LA112_0<=75)) ) {
                alt112=1;
            }
            switch (alt112) {
                case 1 :
                    // InternalSM2.g:3623:5: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3623:5: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3624:6: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getInputParamAccess().getIsArrayArrayParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_70);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getInputParamRule());
                      						}
                      						set(
                      							current,
                      							"isArray",
                      							lv_isArray_1_0,
                      							"org.xtext.SM2.Array");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3641:4: ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )?
            int alt113=3;
            int LA113_0 = input.LA(1);

            if ( (LA113_0==90) ) {
                alt113=1;
            }
            else if ( (LA113_0==91) ) {
                alt113=2;
            }
            switch (alt113) {
                case 1 :
                    // InternalSM2.g:3642:5: ( (lv_storage_2_0= 'memory' ) )
                    {
                    // InternalSM2.g:3642:5: ( (lv_storage_2_0= 'memory' ) )
                    // InternalSM2.g:3643:6: (lv_storage_2_0= 'memory' )
                    {
                    // InternalSM2.g:3643:6: (lv_storage_2_0= 'memory' )
                    // InternalSM2.g:3644:7: lv_storage_2_0= 'memory'
                    {
                    lv_storage_2_0=(Token)match(input,90,FOLLOW_11); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_storage_2_0, grammarAccess.getInputParamAccess().getStorageMemoryKeyword_0_2_0_0());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getInputParamRule());
                      							}
                      							setWithLastConsumed(current, "storage", lv_storage_2_0, "memory");
                      						
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3657:5: otherlv_3= 'local'
                    {
                    otherlv_3=(Token)match(input,91,FOLLOW_11); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_3, grammarAccess.getInputParamAccess().getLocalKeyword_0_2_1());
                      				
                    }

                    }
                    break;

            }

            // InternalSM2.g:3662:4: ( (lv_nameParam_4_0= RULE_ID ) )
            // InternalSM2.g:3663:5: (lv_nameParam_4_0= RULE_ID )
            {
            // InternalSM2.g:3663:5: (lv_nameParam_4_0= RULE_ID )
            // InternalSM2.g:3664:6: lv_nameParam_4_0= RULE_ID
            {
            lv_nameParam_4_0=(Token)match(input,RULE_ID,FOLLOW_71); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						newLeafNode(lv_nameParam_4_0, grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_3_0());
              					
            }
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElement(grammarAccess.getInputParamRule());
              						}
              						setWithLastConsumed(
              							current,
              							"nameParam",
              							lv_nameParam_4_0,
              							"org.eclipse.xtext.common.Terminals.ID");
              					
            }

            }


            }


            }

            // InternalSM2.g:3681:3: (this_COMMA_5= RULE_COMMA )?
            int alt114=2;
            int LA114_0 = input.LA(1);

            if ( (LA114_0==RULE_COMMA) ) {
                alt114=1;
            }
            switch (alt114) {
                case 1 :
                    // InternalSM2.g:3682:4: this_COMMA_5= RULE_COMMA
                    {
                    this_COMMA_5=(Token)match(input,RULE_COMMA,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_COMMA_5, grammarAccess.getInputParamAccess().getCOMMATerminalRuleCall_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:3691:1: entryRuleRestriction returns [EObject current=null] : iv_ruleRestriction= ruleRestriction EOF ;
    public final EObject entryRuleRestriction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestriction = null;


        try {
            // InternalSM2.g:3691:52: (iv_ruleRestriction= ruleRestriction EOF )
            // InternalSM2.g:3692:2: iv_ruleRestriction= ruleRestriction EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRestrictionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRestriction=ruleRestriction();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRestriction; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:3698:1: ruleRestriction returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) ;
    public final EObject ruleRestriction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        EObject lv_expr1_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        EObject lv_expr2_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3704:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) )
            // InternalSM2.g:3705:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            {
            // InternalSM2.g:3705:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            // InternalSM2.g:3706:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,92,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getRestrictionAccess().getRequireKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:3714:3: ( (lv_expr1_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:3715:4: (lv_expr1_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:3715:4: (lv_expr1_2_0= ruleSyntaxExpression )
            // InternalSM2.g:3716:5: lv_expr1_2_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr1SyntaxExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_72);
            lv_expr1_2_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"expr1",
              						lv_expr1_2_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3733:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:3734:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:3734:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:3735:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_26);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3752:3: ( (lv_expr2_4_0= ruleSyntaxExpression ) )
            // InternalSM2.g:3753:4: (lv_expr2_4_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:3753:4: (lv_expr2_4_0= ruleSyntaxExpression )
            // InternalSM2.g:3754:5: lv_expr2_4_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr2SyntaxExpressionParserRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_27);
            lv_expr2_4_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"expr2",
              						lv_expr2_4_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_7, grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:3787:1: entryRuleRestrictionGas returns [EObject current=null] : iv_ruleRestrictionGas= ruleRestrictionGas EOF ;
    public final EObject entryRuleRestrictionGas() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionGas = null;


        try {
            // InternalSM2.g:3787:55: (iv_ruleRestrictionGas= ruleRestrictionGas EOF )
            // InternalSM2.g:3788:2: iv_ruleRestrictionGas= ruleRestrictionGas EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRestrictionGasRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionGas=ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRestrictionGas; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:3794:1: ruleRestrictionGas returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE ) ;
    public final EObject ruleRestrictionGas() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_amount_4_0=null;
        Token this_FLOAT_5=null;
        Token this_CLOSEPARENTHESIS_7=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        EObject lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        Enumerator lv_typeCoin_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3800:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE ) )
            // InternalSM2.g:3801:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )
            {
            // InternalSM2.g:3801:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )
            // InternalSM2.g:3802:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,92,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getRestrictionGasAccess().getRequireKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:3810:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:3811:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:3811:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2.g:3812:5: lv_expr_2_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_72);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_2_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3829:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:3830:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:3830:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:3831:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_56);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3848:3: ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT )
            int alt115=2;
            int LA115_0 = input.LA(1);

            if ( (LA115_0==RULE_INTEGER) ) {
                alt115=1;
            }
            else if ( (LA115_0==RULE_FLOAT) ) {
                alt115=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 115, 0, input);

                throw nvae;
            }
            switch (alt115) {
                case 1 :
                    // InternalSM2.g:3849:4: ( (lv_amount_4_0= RULE_INTEGER ) )
                    {
                    // InternalSM2.g:3849:4: ( (lv_amount_4_0= RULE_INTEGER ) )
                    // InternalSM2.g:3850:5: (lv_amount_4_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:3850:5: (lv_amount_4_0= RULE_INTEGER )
                    // InternalSM2.g:3851:6: lv_amount_4_0= RULE_INTEGER
                    {
                    lv_amount_4_0=(Token)match(input,RULE_INTEGER,FOLLOW_73); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_amount_4_0, grammarAccess.getRestrictionGasAccess().getAmountINTEGERTerminalRuleCall_4_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getRestrictionGasRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"amount",
                      							lv_amount_4_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3868:4: this_FLOAT_5= RULE_FLOAT
                    {
                    this_FLOAT_5=(Token)match(input,RULE_FLOAT,FOLLOW_73); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_FLOAT_5, grammarAccess.getRestrictionGasAccess().getFLOATTerminalRuleCall_4_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:3873:3: ( (lv_typeCoin_6_0= ruleCoin ) )
            // InternalSM2.g:3874:4: (lv_typeCoin_6_0= ruleCoin )
            {
            // InternalSM2.g:3874:4: (lv_typeCoin_6_0= ruleCoin )
            // InternalSM2.g:3875:5: lv_typeCoin_6_0= ruleCoin
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0());
              				
            }
            pushFollow(FOLLOW_27);
            lv_typeCoin_6_0=ruleCoin();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"typeCoin",
              						lv_typeCoin_6_0,
              						"org.xtext.SM2.Coin");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_7=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_7, grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }
            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_9, grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleFunction"
    // InternalSM2.g:3908:1: entryRuleFunction returns [EObject current=null] : iv_ruleFunction= ruleFunction EOF ;
    public final EObject entryRuleFunction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFunction = null;


        try {
            // InternalSM2.g:3908:49: (iv_ruleFunction= ruleFunction EOF )
            // InternalSM2.g:3909:2: iv_ruleFunction= ruleFunction EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getFunctionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleFunction=ruleFunction();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleFunction; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFunction"


    // $ANTLR start "ruleFunction"
    // InternalSM2.g:3915:1: ruleFunction returns [EObject current=null] : (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions ) ;
    public final EObject ruleFunction() throws RecognitionException {
        EObject current = null;

        EObject this_PredefinedFunctions_0 = null;

        EObject this_PersonalizedFunctions_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:3921:2: ( (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions ) )
            // InternalSM2.g:3922:2: (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions )
            {
            // InternalSM2.g:3922:2: (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions )
            int alt116=2;
            int LA116_0 = input.LA(1);

            if ( (LA116_0==94) ) {
                int LA116_1 = input.LA(2);

                if ( (LA116_1==RULE_ID) ) {
                    alt116=2;
                }
                else if ( (LA116_1==95) ) {
                    alt116=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 116, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 116, 0, input);

                throw nvae;
            }
            switch (alt116) {
                case 1 :
                    // InternalSM2.g:3923:3: this_PredefinedFunctions_0= rulePredefinedFunctions
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getFunctionAccess().getPredefinedFunctionsParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PredefinedFunctions_0=rulePredefinedFunctions();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PredefinedFunctions_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3932:3: this_PersonalizedFunctions_1= rulePersonalizedFunctions
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getFunctionAccess().getPersonalizedFunctionsParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PersonalizedFunctions_1=rulePersonalizedFunctions();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PersonalizedFunctions_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFunction"


    // $ANTLR start "entryRulePredefinedFunctions"
    // InternalSM2.g:3944:1: entryRulePredefinedFunctions returns [EObject current=null] : iv_rulePredefinedFunctions= rulePredefinedFunctions EOF ;
    public final EObject entryRulePredefinedFunctions() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePredefinedFunctions = null;


        try {
            // InternalSM2.g:3944:60: (iv_rulePredefinedFunctions= rulePredefinedFunctions EOF )
            // InternalSM2.g:3945:2: iv_rulePredefinedFunctions= rulePredefinedFunctions EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPredefinedFunctionsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePredefinedFunctions=rulePredefinedFunctions();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePredefinedFunctions; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePredefinedFunctions"


    // $ANTLR start "rulePredefinedFunctions"
    // InternalSM2.g:3951:1: rulePredefinedFunctions returns [EObject current=null] : this_Kill_0= ruleKill ;
    public final EObject rulePredefinedFunctions() throws RecognitionException {
        EObject current = null;

        EObject this_Kill_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3957:2: (this_Kill_0= ruleKill )
            // InternalSM2.g:3958:2: this_Kill_0= ruleKill
            {
            if ( state.backtracking==0 ) {

              		newCompositeNode(grammarAccess.getPredefinedFunctionsAccess().getKillParserRuleCall());
              	
            }
            pushFollow(FOLLOW_2);
            this_Kill_0=ruleKill();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current = this_Kill_0;
              		afterParserOrEnumRuleCall();
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePredefinedFunctions"


    // $ANTLR start "entryRulePersonalizedFunctions"
    // InternalSM2.g:3969:1: entryRulePersonalizedFunctions returns [EObject current=null] : iv_rulePersonalizedFunctions= rulePersonalizedFunctions EOF ;
    public final EObject entryRulePersonalizedFunctions() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonalizedFunctions = null;


        try {
            // InternalSM2.g:3969:62: (iv_rulePersonalizedFunctions= rulePersonalizedFunctions EOF )
            // InternalSM2.g:3970:2: iv_rulePersonalizedFunctions= rulePersonalizedFunctions EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPersonalizedFunctionsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePersonalizedFunctions=rulePersonalizedFunctions();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePersonalizedFunctions; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonalizedFunctions"


    // $ANTLR start "rulePersonalizedFunctions"
    // InternalSM2.g:3976:1: rulePersonalizedFunctions returns [EObject current=null] : (this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE ) ;
    public final EObject rulePersonalizedFunctions() throws RecognitionException {
        EObject current = null;

        Token lv_ispayable_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_EOLINE_9=null;
        Token this_CLOSEKEY_10=null;
        Token this_EOLINE_11=null;
        EObject this_HeadClause_0 = null;

        EObject lv_restriction_4_0 = null;

        EObject lv_restrictionGas_5_0 = null;

        EObject lv_localAttributes_6_0 = null;

        EObject lv_conditions_7_0 = null;

        EObject lv_expression_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3982:2: ( (this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE ) )
            // InternalSM2.g:3983:2: (this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE )
            {
            // InternalSM2.g:3983:2: (this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE )
            // InternalSM2.g:3984:3: this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE
            {
            if ( state.backtracking==0 ) {

              			newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getHeadClauseParserRuleCall_0());
              		
            }
            pushFollow(FOLLOW_74);
            this_HeadClause_0=ruleHeadClause();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			current = this_HeadClause_0;
              			afterParserOrEnumRuleCall();
              		
            }
            // InternalSM2.g:3992:3: ( (lv_ispayable_1_0= 'payable' ) )?
            int alt117=2;
            int LA117_0 = input.LA(1);

            if ( (LA117_0==93) ) {
                alt117=1;
            }
            switch (alt117) {
                case 1 :
                    // InternalSM2.g:3993:4: (lv_ispayable_1_0= 'payable' )
                    {
                    // InternalSM2.g:3993:4: (lv_ispayable_1_0= 'payable' )
                    // InternalSM2.g:3994:5: lv_ispayable_1_0= 'payable'
                    {
                    lv_ispayable_1_0=(Token)match(input,93,FOLLOW_14); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_ispayable_1_0, grammarAccess.getPersonalizedFunctionsAccess().getIspayablePayableKeyword_1_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					setWithLastConsumed(current, "ispayable", lv_ispayable_1_0, "payable");
                      				
                    }

                    }


                    }
                    break;

            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getPersonalizedFunctionsAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_75); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_3, grammarAccess.getPersonalizedFunctionsAccess().getEOLINETerminalRuleCall_3());
              		
            }
            // InternalSM2.g:4014:3: ( (lv_restriction_4_0= ruleRestriction ) )?
            int alt118=2;
            alt118 = dfa118.predict(input);
            switch (alt118) {
                case 1 :
                    // InternalSM2.g:4015:4: (lv_restriction_4_0= ruleRestriction )
                    {
                    // InternalSM2.g:4015:4: (lv_restriction_4_0= ruleRestriction )
                    // InternalSM2.g:4016:5: lv_restriction_4_0= ruleRestriction
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getRestrictionRestrictionParserRuleCall_4_0());
                      				
                    }
                    pushFollow(FOLLOW_75);
                    lv_restriction_4_0=ruleRestriction();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"restriction",
                      						lv_restriction_4_0,
                      						"org.xtext.SM2.Restriction");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:4033:3: ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )?
            int alt119=2;
            int LA119_0 = input.LA(1);

            if ( (LA119_0==92) ) {
                alt119=1;
            }
            switch (alt119) {
                case 1 :
                    // InternalSM2.g:4034:4: (lv_restrictionGas_5_0= ruleRestrictionGas )
                    {
                    // InternalSM2.g:4034:4: (lv_restrictionGas_5_0= ruleRestrictionGas )
                    // InternalSM2.g:4035:5: lv_restrictionGas_5_0= ruleRestrictionGas
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getRestrictionGasRestrictionGasParserRuleCall_5_0());
                      				
                    }
                    pushFollow(FOLLOW_76);
                    lv_restrictionGas_5_0=ruleRestrictionGas();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"restrictionGas",
                      						lv_restrictionGas_5_0,
                      						"org.xtext.SM2.RestrictionGas");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:4052:3: ( (lv_localAttributes_6_0= ruleAttributes ) )?
            int alt120=2;
            int LA120_0 = input.LA(1);

            if ( (LA120_0==RULE_ID||LA120_0==65||(LA120_0>=67 && LA120_0<=68)||(LA120_0>=70 && LA120_0<=71)||LA120_0==73||(LA120_0>=77 && LA120_0<=89)) ) {
                alt120=1;
            }
            switch (alt120) {
                case 1 :
                    // InternalSM2.g:4053:4: (lv_localAttributes_6_0= ruleAttributes )
                    {
                    // InternalSM2.g:4053:4: (lv_localAttributes_6_0= ruleAttributes )
                    // InternalSM2.g:4054:5: lv_localAttributes_6_0= ruleAttributes
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getLocalAttributesAttributesParserRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_36);
                    lv_localAttributes_6_0=ruleAttributes();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"localAttributes",
                      						lv_localAttributes_6_0,
                      						"org.xtext.SM2.Attributes");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:4071:3: ( (lv_conditions_7_0= ruleConditional ) )?
            int alt121=2;
            int LA121_0 = input.LA(1);

            if ( (LA121_0==RULE_IF) ) {
                alt121=1;
            }
            switch (alt121) {
                case 1 :
                    // InternalSM2.g:4072:4: (lv_conditions_7_0= ruleConditional )
                    {
                    // InternalSM2.g:4072:4: (lv_conditions_7_0= ruleConditional )
                    // InternalSM2.g:4073:5: lv_conditions_7_0= ruleConditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getConditionsConditionalParserRuleCall_7_0());
                      				
                    }
                    pushFollow(FOLLOW_36);
                    lv_conditions_7_0=ruleConditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"conditions",
                      						lv_conditions_7_0,
                      						"org.xtext.SM2.Conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:4090:3: ( (lv_expression_8_0= ruleExpression ) )+
            int cnt122=0;
            loop122:
            do {
                int alt122=2;
                int LA122_0 = input.LA(1);

                if ( (LA122_0==RULE_INTEGER||LA122_0==RULE_OPENPARENTHESIS||LA122_0==RULE_STRING||LA122_0==RULE_FLOAT||LA122_0==42||LA122_0==48||(LA122_0>=55 && LA122_0<=56)) ) {
                    alt122=1;
                }


                switch (alt122) {
            	case 1 :
            	    // InternalSM2.g:4091:4: (lv_expression_8_0= ruleExpression )
            	    {
            	    // InternalSM2.g:4091:4: (lv_expression_8_0= ruleExpression )
            	    // InternalSM2.g:4092:5: lv_expression_8_0= ruleExpression
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getExpressionExpressionParserRuleCall_8_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_77);
            	    lv_expression_8_0=ruleExpression();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
            	      					}
            	      					add(
            	      						current,
            	      						"expression",
            	      						lv_expression_8_0,
            	      						"org.xtext.SM2.Expression");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt122 >= 1 ) break loop122;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(122, input);
                        throw eee;
                }
                cnt122++;
            } while (true);

            // InternalSM2.g:4109:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt123=2;
            int LA123_0 = input.LA(1);

            if ( (LA123_0==RULE_EOLINE) ) {
                alt123=1;
            }
            switch (alt123) {
                case 1 :
                    // InternalSM2.g:4110:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getPersonalizedFunctionsAccess().getEOLINETerminalRuleCall_9());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_10=(Token)match(input,RULE_CLOSEKEY,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_10, grammarAccess.getPersonalizedFunctionsAccess().getCLOSEKEYTerminalRuleCall_10());
              		
            }
            this_EOLINE_11=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_11, grammarAccess.getPersonalizedFunctionsAccess().getEOLINETerminalRuleCall_11());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonalizedFunctions"


    // $ANTLR start "entryRuleHeadClause"
    // InternalSM2.g:4127:1: entryRuleHeadClause returns [EObject current=null] : iv_ruleHeadClause= ruleHeadClause EOF ;
    public final EObject entryRuleHeadClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleHeadClause = null;


        try {
            // InternalSM2.g:4127:51: (iv_ruleHeadClause= ruleHeadClause EOF )
            // InternalSM2.g:4128:2: iv_ruleHeadClause= ruleHeadClause EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getHeadClauseRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleHeadClause=ruleHeadClause();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleHeadClause; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleHeadClause"


    // $ANTLR start "ruleHeadClause"
    // InternalSM2.g:4134:1: ruleHeadClause returns [EObject current=null] : (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) ;
    public final EObject ruleHeadClause() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameFunction_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Enumerator lv_visibilityAccess_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4140:2: ( (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:4141:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:4141:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:4142:3: otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS
            {
            otherlv_0=(Token)match(input,94,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getHeadClauseAccess().getFunctionKeyword_0());
              		
            }
            // InternalSM2.g:4146:3: ( (lv_nameFunction_1_0= RULE_ID ) )
            // InternalSM2.g:4147:4: (lv_nameFunction_1_0= RULE_ID )
            {
            // InternalSM2.g:4147:4: (lv_nameFunction_1_0= RULE_ID )
            // InternalSM2.g:4148:5: lv_nameFunction_1_0= RULE_ID
            {
            lv_nameFunction_1_0=(Token)match(input,RULE_ID,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameFunction_1_0, grammarAccess.getHeadClauseAccess().getNameFunctionIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getHeadClauseRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameFunction",
              						lv_nameFunction_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_42); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getHeadClauseAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:4168:3: ( (otherlv_3= RULE_ID ) )*
            loop124:
            do {
                int alt124=2;
                int LA124_0 = input.LA(1);

                if ( (LA124_0==RULE_ID) ) {
                    alt124=1;
                }


                switch (alt124) {
            	case 1 :
            	    // InternalSM2.g:4169:4: (otherlv_3= RULE_ID )
            	    {
            	    // InternalSM2.g:4169:4: (otherlv_3= RULE_ID )
            	    // InternalSM2.g:4170:5: otherlv_3= RULE_ID
            	    {
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElement(grammarAccess.getHeadClauseRule());
            	      					}
            	      				
            	    }
            	    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_42); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_3, grammarAccess.getHeadClauseAccess().getInputParamsInputParamCrossReference_3_0());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop124;
                }
            } while (true);

            // InternalSM2.g:4181:3: ( (lv_visibilityAccess_4_0= ruleVisibility ) )
            // InternalSM2.g:4182:4: (lv_visibilityAccess_4_0= ruleVisibility )
            {
            // InternalSM2.g:4182:4: (lv_visibilityAccess_4_0= ruleVisibility )
            // InternalSM2.g:4183:5: lv_visibilityAccess_4_0= ruleVisibility
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getHeadClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_78);
            lv_visibilityAccess_4_0=ruleVisibility();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getHeadClauseRule());
              					}
              					set(
              						current,
              						"visibilityAccess",
              						lv_visibilityAccess_4_0,
              						"org.xtext.SM2.Visibility");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4200:3: ( (otherlv_5= RULE_ID ) )?
            int alt125=2;
            int LA125_0 = input.LA(1);

            if ( (LA125_0==RULE_ID) ) {
                alt125=1;
            }
            switch (alt125) {
                case 1 :
                    // InternalSM2.g:4201:4: (otherlv_5= RULE_ID )
                    {
                    // InternalSM2.g:4201:4: (otherlv_5= RULE_ID )
                    // InternalSM2.g:4202:5: otherlv_5= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getHeadClauseRule());
                      					}
                      				
                    }
                    otherlv_5=(Token)match(input,RULE_ID,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_5, grammarAccess.getHeadClauseAccess().getModifierModifierCrossReference_5_0());
                      				
                    }

                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getHeadClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleHeadClause"


    // $ANTLR start "entryRuleKill"
    // InternalSM2.g:4221:1: entryRuleKill returns [EObject current=null] : iv_ruleKill= ruleKill EOF ;
    public final EObject entryRuleKill() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleKill = null;


        try {
            // InternalSM2.g:4221:45: (iv_ruleKill= ruleKill EOF )
            // InternalSM2.g:4222:2: iv_ruleKill= ruleKill EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getKillRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleKill=ruleKill();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleKill; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleKill"


    // $ANTLR start "ruleKill"
    // InternalSM2.g:4228:1: ruleKill returns [EObject current=null] : (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParam_3_0= ruleInputParam ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY ) ;
    public final EObject ruleKill() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_IF_6=null;
        Token this_OPENPARENTHESIS_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token this_CLOSEPARENTHESIS_12=null;
        Token otherlv_13=null;
        Token this_OPENPARENTHESIS_14=null;
        Token this_CLOSEPARENTHESIS_16=null;
        Token this_SEMICOLON_17=null;
        Token this_EOLINE_18=null;
        Token this_CLOSEKEY_19=null;
        EObject lv_inputParam_3_0 = null;

        EObject lv_addressValueCondition_10_0 = null;

        EObject this_InputParam_11 = null;

        EObject lv_addressValue_15_1 = null;

        EObject lv_addressValue_15_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:4234:2: ( (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParam_3_0= ruleInputParam ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY ) )
            // InternalSM2.g:4235:2: (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParam_3_0= ruleInputParam ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY )
            {
            // InternalSM2.g:4235:2: (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParam_3_0= ruleInputParam ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY )
            // InternalSM2.g:4236:3: otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParam_3_0= ruleInputParam ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,94,FOLLOW_79); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getKillAccess().getFunctionKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,95,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getKillAccess().getKillKeyword_1());
              		
            }
            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_35); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getKillAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:4248:3: ( (lv_inputParam_3_0= ruleInputParam ) )?
            int alt126=2;
            int LA126_0 = input.LA(1);

            if ( (LA126_0==68||LA126_0==70||(LA126_0>=77 && LA126_0<=79)||(LA126_0>=82 && LA126_0<=84)||LA126_0==89||(LA126_0>=121 && LA126_0<=122)) ) {
                alt126=1;
            }
            switch (alt126) {
                case 1 :
                    // InternalSM2.g:4249:4: (lv_inputParam_3_0= ruleInputParam )
                    {
                    // InternalSM2.g:4249:4: (lv_inputParam_3_0= ruleInputParam )
                    // InternalSM2.g:4250:5: lv_inputParam_3_0= ruleInputParam
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getKillAccess().getInputParamInputParamParserRuleCall_3_0());
                      				
                    }
                    pushFollow(FOLLOW_27);
                    lv_inputParam_3_0=ruleInputParam();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getKillRule());
                      					}
                      					set(
                      						current,
                      						"inputParam",
                      						lv_inputParam_3_0,
                      						"org.xtext.SM2.InputParam");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getKillAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_80); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getKillAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            this_IF_6=(Token)match(input,RULE_IF,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_IF_6, grammarAccess.getKillAccess().getIFTerminalRuleCall_6());
              		
            }
            this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_81); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getKillAccess().getOPENPARENTHESISTerminalRuleCall_7());
              		
            }
            otherlv_8=(Token)match(input,96,FOLLOW_82); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_8, grammarAccess.getKillAccess().getMsgSenderKeyword_8());
              		
            }
            otherlv_9=(Token)match(input,97,FOLLOW_83); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_9, grammarAccess.getKillAccess().getEqualsSignEqualsSignKeyword_9());
              		
            }
            // InternalSM2.g:4291:3: ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam )
            int alt127=2;
            int LA127_0 = input.LA(1);

            if ( (LA127_0==RULE_INTEGER||LA127_0==RULE_OPENPARENTHESIS||LA127_0==RULE_STRING||LA127_0==RULE_FLOAT||LA127_0==42||LA127_0==48||(LA127_0>=55 && LA127_0<=56)) ) {
                alt127=1;
            }
            else if ( (LA127_0==68||LA127_0==70||(LA127_0>=77 && LA127_0<=79)||(LA127_0>=82 && LA127_0<=84)||LA127_0==89||(LA127_0>=121 && LA127_0<=122)) ) {
                alt127=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 127, 0, input);

                throw nvae;
            }
            switch (alt127) {
                case 1 :
                    // InternalSM2.g:4292:4: ( (lv_addressValueCondition_10_0= ruleExpression ) )
                    {
                    // InternalSM2.g:4292:4: ( (lv_addressValueCondition_10_0= ruleExpression ) )
                    // InternalSM2.g:4293:5: (lv_addressValueCondition_10_0= ruleExpression )
                    {
                    // InternalSM2.g:4293:5: (lv_addressValueCondition_10_0= ruleExpression )
                    // InternalSM2.g:4294:6: lv_addressValueCondition_10_0= ruleExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getKillAccess().getAddressValueConditionExpressionParserRuleCall_10_0_0());
                      					
                    }
                    pushFollow(FOLLOW_27);
                    lv_addressValueCondition_10_0=ruleExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getKillRule());
                      						}
                      						set(
                      							current,
                      							"addressValueCondition",
                      							lv_addressValueCondition_10_0,
                      							"org.xtext.SM2.Expression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4312:4: this_InputParam_11= ruleInputParam
                    {
                    if ( state.backtracking==0 ) {

                      				newCompositeNode(grammarAccess.getKillAccess().getInputParamParserRuleCall_10_1());
                      			
                    }
                    pushFollow(FOLLOW_27);
                    this_InputParam_11=ruleInputParam();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = this_InputParam_11;
                      				afterParserOrEnumRuleCall();
                      			
                    }

                    }
                    break;

            }

            this_CLOSEPARENTHESIS_12=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_84); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_12, grammarAccess.getKillAccess().getCLOSEPARENTHESISTerminalRuleCall_11());
              		
            }
            otherlv_13=(Token)match(input,98,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_13, grammarAccess.getKillAccess().getSelfdestructKeyword_12());
              		
            }
            this_OPENPARENTHESIS_14=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_83); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_14, grammarAccess.getKillAccess().getOPENPARENTHESISTerminalRuleCall_13());
              		
            }
            // InternalSM2.g:4333:3: ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) )
            // InternalSM2.g:4334:4: ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) )
            {
            // InternalSM2.g:4334:4: ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) )
            // InternalSM2.g:4335:5: (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam )
            {
            // InternalSM2.g:4335:5: (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam )
            int alt128=2;
            int LA128_0 = input.LA(1);

            if ( (LA128_0==RULE_INTEGER||LA128_0==RULE_OPENPARENTHESIS||LA128_0==RULE_STRING||LA128_0==RULE_FLOAT||LA128_0==42||LA128_0==48||(LA128_0>=55 && LA128_0<=56)) ) {
                alt128=1;
            }
            else if ( (LA128_0==68||LA128_0==70||(LA128_0>=77 && LA128_0<=79)||(LA128_0>=82 && LA128_0<=84)||LA128_0==89||(LA128_0>=121 && LA128_0<=122)) ) {
                alt128=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 128, 0, input);

                throw nvae;
            }
            switch (alt128) {
                case 1 :
                    // InternalSM2.g:4336:6: lv_addressValue_15_1= ruleExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getKillAccess().getAddressValueExpressionParserRuleCall_14_0_0());
                      					
                    }
                    pushFollow(FOLLOW_27);
                    lv_addressValue_15_1=ruleExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getKillRule());
                      						}
                      						set(
                      							current,
                      							"addressValue",
                      							lv_addressValue_15_1,
                      							"org.xtext.SM2.Expression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4352:6: lv_addressValue_15_2= ruleInputParam
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getKillAccess().getAddressValueInputParamParserRuleCall_14_0_1());
                      					
                    }
                    pushFollow(FOLLOW_27);
                    lv_addressValue_15_2=ruleInputParam();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getKillRule());
                      						}
                      						set(
                      							current,
                      							"addressValue",
                      							lv_addressValue_15_2,
                      							"org.xtext.SM2.InputParam");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }
                    break;

            }


            }


            }

            this_CLOSEPARENTHESIS_16=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_16, grammarAccess.getKillAccess().getCLOSEPARENTHESISTerminalRuleCall_15());
              		
            }
            this_SEMICOLON_17=(Token)match(input,RULE_SEMICOLON,FOLLOW_57); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_17, grammarAccess.getKillAccess().getSEMICOLONTerminalRuleCall_16());
              		
            }
            // InternalSM2.g:4378:3: (this_EOLINE_18= RULE_EOLINE )?
            int alt129=2;
            int LA129_0 = input.LA(1);

            if ( (LA129_0==RULE_EOLINE) ) {
                alt129=1;
            }
            switch (alt129) {
                case 1 :
                    // InternalSM2.g:4379:4: this_EOLINE_18= RULE_EOLINE
                    {
                    this_EOLINE_18=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_18, grammarAccess.getKillAccess().getEOLINETerminalRuleCall_17());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_19=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_19, grammarAccess.getKillAccess().getCLOSEKEYTerminalRuleCall_18());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleKill"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:4392:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // InternalSM2.g:4392:51: (iv_ruleExpression= ruleExpression EOF )
            // InternalSM2.g:4393:2: iv_ruleExpression= ruleExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:4399:1: ruleExpression returns [EObject current=null] : (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables ) ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_ArithmethicalExpression_0 = null;

        EObject this_ArithmethicalLogicalExpression_1 = null;

        EObject this_SyntaxExpression_2 = null;

        EObject this_TimeExpression_3 = null;

        EObject this_Variables_4 = null;



        	enterRule();

        try {
            // InternalSM2.g:4405:2: ( (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables ) )
            // InternalSM2.g:4406:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables )
            {
            // InternalSM2.g:4406:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables )
            int alt130=5;
            alt130 = dfa130.predict(input);
            switch (alt130) {
                case 1 :
                    // InternalSM2.g:4407:3: this_ArithmethicalExpression_0= ruleArithmethicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalExpression_0=ruleArithmethicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ArithmethicalExpression_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4416:3: this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalLogicalExpressionParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalLogicalExpression_1=ruleArithmethicalLogicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ArithmethicalLogicalExpression_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:4425:3: this_SyntaxExpression_2= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_SyntaxExpression_2=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_SyntaxExpression_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:4434:3: this_TimeExpression_3= ruleTimeExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getTimeExpressionParserRuleCall_3());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_TimeExpression_3=ruleTimeExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_TimeExpression_3;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:4443:3: this_Variables_4= ruleVariables
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getVariablesParserRuleCall_4());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Variables_4=ruleVariables();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Variables_4;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleArithmethicalExpression"
    // InternalSM2.g:4455:1: entryRuleArithmethicalExpression returns [EObject current=null] : iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF ;
    public final EObject entryRuleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalExpression = null;


        try {
            // InternalSM2.g:4455:64: (iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF )
            // InternalSM2.g:4456:2: iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmethicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalExpression=ruleArithmethicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArithmethicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalExpression"


    // $ANTLR start "ruleArithmethicalExpression"
    // InternalSM2.g:4462:1: ruleArithmethicalExpression returns [EObject current=null] : ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT ) ( (lv_operator_9_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? ) ) ;
    public final EObject ruleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token lv_op1_1_0=null;
        Token this_FLOAT_2=null;
        Token lv_op2_4_0=null;
        Token this_FLOAT_5=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token lv_op1_7_0=null;
        Token this_FLOAT_8=null;
        Token lv_op2_10_0=null;
        Token this_FLOAT_11=null;
        Token this_SEMICOLON_12=null;
        Token this_EOLINE_13=null;
        Enumerator lv_operator_3_0 = null;

        Enumerator lv_operator_9_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4468:2: ( ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT ) ( (lv_operator_9_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? ) ) )
            // InternalSM2.g:4469:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT ) ( (lv_operator_9_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:4469:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT ) ( (lv_operator_9_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? ) )
            int alt136=2;
            int LA136_0 = input.LA(1);

            if ( (LA136_0==RULE_OPENPARENTHESIS) ) {
                alt136=1;
            }
            else if ( (LA136_0==RULE_INTEGER||LA136_0==RULE_FLOAT) ) {
                alt136=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 136, 0, input);

                throw nvae;
            }
            switch (alt136) {
                case 1 :
                    // InternalSM2.g:4470:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:4470:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:4471:4: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS
                    {
                    this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_56); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0());
                      			
                    }
                    // InternalSM2.g:4475:4: ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT )
                    int alt131=2;
                    int LA131_0 = input.LA(1);

                    if ( (LA131_0==RULE_INTEGER) ) {
                        alt131=1;
                    }
                    else if ( (LA131_0==RULE_FLOAT) ) {
                        alt131=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 131, 0, input);

                        throw nvae;
                    }
                    switch (alt131) {
                        case 1 :
                            // InternalSM2.g:4476:5: ( (lv_op1_1_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4476:5: ( (lv_op1_1_0= RULE_INTEGER ) )
                            // InternalSM2.g:4477:6: (lv_op1_1_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4477:6: (lv_op1_1_0= RULE_INTEGER )
                            // InternalSM2.g:4478:7: lv_op1_1_0= RULE_INTEGER
                            {
                            lv_op1_1_0=(Token)match(input,RULE_INTEGER,FOLLOW_85); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op1_1_0, grammarAccess.getArithmethicalExpressionAccess().getOp1INTEGERTerminalRuleCall_0_1_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op1",
                              								lv_op1_1_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4495:5: this_FLOAT_2= RULE_FLOAT
                            {
                            this_FLOAT_2=(Token)match(input,RULE_FLOAT,FOLLOW_85); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_2, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_0_1_1());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:4500:4: ( (lv_operator_3_0= ruleArithmeticalOperator ) )
                    // InternalSM2.g:4501:5: (lv_operator_3_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2.g:4501:5: (lv_operator_3_0= ruleArithmeticalOperator )
                    // InternalSM2.g:4502:6: lv_operator_3_0= ruleArithmeticalOperator
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0());
                      					
                    }
                    pushFollow(FOLLOW_56);
                    lv_operator_3_0=ruleArithmeticalOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"operator",
                      							lv_operator_3_0,
                      							"org.xtext.SM2.ArithmeticalOperator");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:4519:4: ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT )
                    int alt132=2;
                    int LA132_0 = input.LA(1);

                    if ( (LA132_0==RULE_INTEGER) ) {
                        alt132=1;
                    }
                    else if ( (LA132_0==RULE_FLOAT) ) {
                        alt132=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 132, 0, input);

                        throw nvae;
                    }
                    switch (alt132) {
                        case 1 :
                            // InternalSM2.g:4520:5: ( (lv_op2_4_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4520:5: ( (lv_op2_4_0= RULE_INTEGER ) )
                            // InternalSM2.g:4521:6: (lv_op2_4_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4521:6: (lv_op2_4_0= RULE_INTEGER )
                            // InternalSM2.g:4522:7: lv_op2_4_0= RULE_INTEGER
                            {
                            lv_op2_4_0=(Token)match(input,RULE_INTEGER,FOLLOW_27); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op2_4_0, grammarAccess.getArithmethicalExpressionAccess().getOp2INTEGERTerminalRuleCall_0_3_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op2",
                              								lv_op2_4_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4539:5: this_FLOAT_5= RULE_FLOAT
                            {
                            this_FLOAT_5=(Token)match(input,RULE_FLOAT,FOLLOW_27); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_5, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_0_3_1());
                              				
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4550:3: ( ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT ) ( (lv_operator_9_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:4550:3: ( ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT ) ( (lv_operator_9_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? )
                    // InternalSM2.g:4551:4: ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT ) ( (lv_operator_9_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )?
                    {
                    // InternalSM2.g:4551:4: ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT )
                    int alt133=2;
                    int LA133_0 = input.LA(1);

                    if ( (LA133_0==RULE_INTEGER) ) {
                        alt133=1;
                    }
                    else if ( (LA133_0==RULE_FLOAT) ) {
                        alt133=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 133, 0, input);

                        throw nvae;
                    }
                    switch (alt133) {
                        case 1 :
                            // InternalSM2.g:4552:5: ( (lv_op1_7_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4552:5: ( (lv_op1_7_0= RULE_INTEGER ) )
                            // InternalSM2.g:4553:6: (lv_op1_7_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4553:6: (lv_op1_7_0= RULE_INTEGER )
                            // InternalSM2.g:4554:7: lv_op1_7_0= RULE_INTEGER
                            {
                            lv_op1_7_0=(Token)match(input,RULE_INTEGER,FOLLOW_85); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op1_7_0, grammarAccess.getArithmethicalExpressionAccess().getOp1INTEGERTerminalRuleCall_1_0_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op1",
                              								lv_op1_7_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4571:5: this_FLOAT_8= RULE_FLOAT
                            {
                            this_FLOAT_8=(Token)match(input,RULE_FLOAT,FOLLOW_85); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_8, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_1_0_1());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:4576:4: ( (lv_operator_9_0= ruleArithmeticalOperator ) )
                    // InternalSM2.g:4577:5: (lv_operator_9_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2.g:4577:5: (lv_operator_9_0= ruleArithmeticalOperator )
                    // InternalSM2.g:4578:6: lv_operator_9_0= ruleArithmeticalOperator
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_56);
                    lv_operator_9_0=ruleArithmeticalOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"operator",
                      							lv_operator_9_0,
                      							"org.xtext.SM2.ArithmeticalOperator");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:4595:4: ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT )
                    int alt134=2;
                    int LA134_0 = input.LA(1);

                    if ( (LA134_0==RULE_INTEGER) ) {
                        alt134=1;
                    }
                    else if ( (LA134_0==RULE_FLOAT) ) {
                        alt134=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 134, 0, input);

                        throw nvae;
                    }
                    switch (alt134) {
                        case 1 :
                            // InternalSM2.g:4596:5: ( (lv_op2_10_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4596:5: ( (lv_op2_10_0= RULE_INTEGER ) )
                            // InternalSM2.g:4597:6: (lv_op2_10_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4597:6: (lv_op2_10_0= RULE_INTEGER )
                            // InternalSM2.g:4598:7: lv_op2_10_0= RULE_INTEGER
                            {
                            lv_op2_10_0=(Token)match(input,RULE_INTEGER,FOLLOW_28); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op2_10_0, grammarAccess.getArithmethicalExpressionAccess().getOp2INTEGERTerminalRuleCall_1_2_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op2",
                              								lv_op2_10_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4615:5: this_FLOAT_11= RULE_FLOAT
                            {
                            this_FLOAT_11=(Token)match(input,RULE_FLOAT,FOLLOW_28); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_11, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_1_2_1());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:4620:4: (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )?
                    int alt135=2;
                    int LA135_0 = input.LA(1);

                    if ( (LA135_0==RULE_SEMICOLON) ) {
                        int LA135_1 = input.LA(2);

                        if ( (LA135_1==RULE_EOLINE) ) {
                            int LA135_3 = input.LA(3);

                            if ( (LA135_3==EOF||(LA135_3>=RULE_SEMICOLON && LA135_3<=RULE_INTEGER)||(LA135_3>=RULE_OPENPARENTHESIS && LA135_3<=RULE_STRING)||LA135_3==RULE_FLOAT||LA135_3==42||LA135_3==48||(LA135_3>=55 && LA135_3<=56)) ) {
                                alt135=1;
                            }
                        }
                    }
                    switch (alt135) {
                        case 1 :
                            // InternalSM2.g:4621:5: this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE
                            {
                            this_SEMICOLON_12=(Token)match(input,RULE_SEMICOLON,FOLLOW_15); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_12, grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0());
                              				
                            }
                            this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_13, grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalExpression"


    // $ANTLR start "entryRuleArithmethicalLogicalExpression"
    // InternalSM2.g:4635:1: entryRuleArithmethicalLogicalExpression returns [EObject current=null] : iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF ;
    public final EObject entryRuleArithmethicalLogicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalLogicalExpression = null;


        try {
            // InternalSM2.g:4635:71: (iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF )
            // InternalSM2.g:4636:2: iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalLogicalExpression=ruleArithmethicalLogicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArithmethicalLogicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalLogicalExpression"


    // $ANTLR start "ruleArithmethicalLogicalExpression"
    // InternalSM2.g:4642:1: ruleArithmethicalLogicalExpression returns [EObject current=null] : (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator1_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_operator2_6_0= ruleComparationOperator ) ) ( (lv_expr_7_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE )? ) ;
    public final EObject ruleArithmethicalLogicalExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token lv_op1_1_0=null;
        Token this_FLOAT_2=null;
        Token lv_op2_4_0=null;
        Token this_FLOAT_5=null;
        Token this_CLOSEPARENTHESIS_8=null;
        Token this_SEMICOLON_9=null;
        Token this_EOLINE_10=null;
        Enumerator lv_operator1_3_0 = null;

        Enumerator lv_operator2_6_0 = null;

        EObject lv_expr_7_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4648:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator1_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_operator2_6_0= ruleComparationOperator ) ) ( (lv_expr_7_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE )? ) )
            // InternalSM2.g:4649:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator1_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_operator2_6_0= ruleComparationOperator ) ) ( (lv_expr_7_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE )? )
            {
            // InternalSM2.g:4649:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator1_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_operator2_6_0= ruleComparationOperator ) ) ( (lv_expr_7_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE )? )
            // InternalSM2.g:4650:3: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator1_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_operator2_6_0= ruleComparationOperator ) ) ( (lv_expr_7_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE )?
            {
            this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_56); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0());
              		
            }
            // InternalSM2.g:4654:3: ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT )
            int alt137=2;
            int LA137_0 = input.LA(1);

            if ( (LA137_0==RULE_INTEGER) ) {
                alt137=1;
            }
            else if ( (LA137_0==RULE_FLOAT) ) {
                alt137=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 137, 0, input);

                throw nvae;
            }
            switch (alt137) {
                case 1 :
                    // InternalSM2.g:4655:4: ( (lv_op1_1_0= RULE_INTEGER ) )
                    {
                    // InternalSM2.g:4655:4: ( (lv_op1_1_0= RULE_INTEGER ) )
                    // InternalSM2.g:4656:5: (lv_op1_1_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:4656:5: (lv_op1_1_0= RULE_INTEGER )
                    // InternalSM2.g:4657:6: lv_op1_1_0= RULE_INTEGER
                    {
                    lv_op1_1_0=(Token)match(input,RULE_INTEGER,FOLLOW_85); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op1_1_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOp1INTEGERTerminalRuleCall_1_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalLogicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op1",
                      							lv_op1_1_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4674:4: this_FLOAT_2= RULE_FLOAT
                    {
                    this_FLOAT_2=(Token)match(input,RULE_FLOAT,FOLLOW_85); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_FLOAT_2, grammarAccess.getArithmethicalLogicalExpressionAccess().getFLOATTerminalRuleCall_1_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:4679:3: ( (lv_operator1_3_0= ruleArithmeticalOperator ) )
            // InternalSM2.g:4680:4: (lv_operator1_3_0= ruleArithmeticalOperator )
            {
            // InternalSM2.g:4680:4: (lv_operator1_3_0= ruleArithmeticalOperator )
            // InternalSM2.g:4681:5: lv_operator1_3_0= ruleArithmeticalOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator1ArithmeticalOperatorEnumRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_56);
            lv_operator1_3_0=ruleArithmeticalOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"operator1",
              						lv_operator1_3_0,
              						"org.xtext.SM2.ArithmeticalOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4698:3: ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT )
            int alt138=2;
            int LA138_0 = input.LA(1);

            if ( (LA138_0==RULE_INTEGER) ) {
                alt138=1;
            }
            else if ( (LA138_0==RULE_FLOAT) ) {
                alt138=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 138, 0, input);

                throw nvae;
            }
            switch (alt138) {
                case 1 :
                    // InternalSM2.g:4699:4: ( (lv_op2_4_0= RULE_INTEGER ) )
                    {
                    // InternalSM2.g:4699:4: ( (lv_op2_4_0= RULE_INTEGER ) )
                    // InternalSM2.g:4700:5: (lv_op2_4_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:4700:5: (lv_op2_4_0= RULE_INTEGER )
                    // InternalSM2.g:4701:6: lv_op2_4_0= RULE_INTEGER
                    {
                    lv_op2_4_0=(Token)match(input,RULE_INTEGER,FOLLOW_72); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op2_4_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOp2INTEGERTerminalRuleCall_3_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalLogicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op2",
                      							lv_op2_4_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4718:4: this_FLOAT_5= RULE_FLOAT
                    {
                    this_FLOAT_5=(Token)match(input,RULE_FLOAT,FOLLOW_72); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_FLOAT_5, grammarAccess.getArithmethicalLogicalExpressionAccess().getFLOATTerminalRuleCall_3_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:4723:3: ( (lv_operator2_6_0= ruleComparationOperator ) )
            // InternalSM2.g:4724:4: (lv_operator2_6_0= ruleComparationOperator )
            {
            // InternalSM2.g:4724:4: (lv_operator2_6_0= ruleComparationOperator )
            // InternalSM2.g:4725:5: lv_operator2_6_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator2ComparationOperatorEnumRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_86);
            lv_operator2_6_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"operator2",
              						lv_operator2_6_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4742:3: ( (lv_expr_7_0= ruleArithmethicalExpression ) )
            // InternalSM2.g:4743:4: (lv_expr_7_0= ruleArithmethicalExpression )
            {
            // InternalSM2.g:4743:4: (lv_expr_7_0= ruleArithmethicalExpression )
            // InternalSM2.g:4744:5: lv_expr_7_0= ruleArithmethicalExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getExprArithmethicalExpressionParserRuleCall_5_0());
              				
            }
            pushFollow(FOLLOW_27);
            lv_expr_7_0=ruleArithmethicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_7_0,
              						"org.xtext.SM2.ArithmethicalExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_8=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_28); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_8, grammarAccess.getArithmethicalLogicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:4765:3: (this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE )?
            int alt139=2;
            int LA139_0 = input.LA(1);

            if ( (LA139_0==RULE_SEMICOLON) ) {
                int LA139_1 = input.LA(2);

                if ( (LA139_1==RULE_EOLINE) ) {
                    int LA139_3 = input.LA(3);

                    if ( (LA139_3==EOF||(LA139_3>=RULE_SEMICOLON && LA139_3<=RULE_INTEGER)||(LA139_3>=RULE_OPENPARENTHESIS && LA139_3<=RULE_STRING)||LA139_3==RULE_FLOAT||LA139_3==42||LA139_3==48||(LA139_3>=55 && LA139_3<=56)) ) {
                        alt139=1;
                    }
                }
            }
            switch (alt139) {
                case 1 :
                    // InternalSM2.g:4766:4: this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE
                    {
                    this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_15); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_9, grammarAccess.getArithmethicalLogicalExpressionAccess().getSEMICOLONTerminalRuleCall_7_0());
                      			
                    }
                    this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_10, grammarAccess.getArithmethicalLogicalExpressionAccess().getEOLINETerminalRuleCall_7_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalLogicalExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:4779:1: entryRuleSyntaxExpression returns [EObject current=null] : iv_ruleSyntaxExpression= ruleSyntaxExpression EOF ;
    public final EObject entryRuleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSyntaxExpression = null;


        try {
            // InternalSM2.g:4779:57: (iv_ruleSyntaxExpression= ruleSyntaxExpression EOF )
            // InternalSM2.g:4780:2: iv_ruleSyntaxExpression= ruleSyntaxExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSyntaxExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSyntaxExpression=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSyntaxExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:4786:1: ruleSyntaxExpression returns [EObject current=null] : ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) ) ;
    public final EObject ruleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        Token lv_expr_0_0=null;
        Token this_INTEGER_1=null;
        Token this_FLOAT_2=null;
        Token this_SEMICOLON_3=null;
        Token this_EOLINE_4=null;


        	enterRule();

        try {
            // InternalSM2.g:4792:2: ( ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) ) )
            // InternalSM2.g:4793:2: ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:4793:2: ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) )
            int alt142=2;
            int LA142_0 = input.LA(1);

            if ( (LA142_0==RULE_STRING) ) {
                alt142=1;
            }
            else if ( (LA142_0==RULE_INTEGER||LA142_0==RULE_FLOAT) ) {
                alt142=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 142, 0, input);

                throw nvae;
            }
            switch (alt142) {
                case 1 :
                    // InternalSM2.g:4794:3: ( (lv_expr_0_0= RULE_STRING ) )
                    {
                    // InternalSM2.g:4794:3: ( (lv_expr_0_0= RULE_STRING ) )
                    // InternalSM2.g:4795:4: (lv_expr_0_0= RULE_STRING )
                    {
                    // InternalSM2.g:4795:4: (lv_expr_0_0= RULE_STRING )
                    // InternalSM2.g:4796:5: lv_expr_0_0= RULE_STRING
                    {
                    lv_expr_0_0=(Token)match(input,RULE_STRING,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_expr_0_0, grammarAccess.getSyntaxExpressionAccess().getExprSTRINGTerminalRuleCall_0_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getSyntaxExpressionRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"expr",
                      						lv_expr_0_0,
                      						"org.eclipse.xtext.common.Terminals.STRING");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4813:3: ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:4813:3: ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? )
                    // InternalSM2.g:4814:4: (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )?
                    {
                    // InternalSM2.g:4814:4: (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT )
                    int alt140=2;
                    int LA140_0 = input.LA(1);

                    if ( (LA140_0==RULE_INTEGER) ) {
                        alt140=1;
                    }
                    else if ( (LA140_0==RULE_FLOAT) ) {
                        alt140=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 140, 0, input);

                        throw nvae;
                    }
                    switch (alt140) {
                        case 1 :
                            // InternalSM2.g:4815:5: this_INTEGER_1= RULE_INTEGER
                            {
                            this_INTEGER_1=(Token)match(input,RULE_INTEGER,FOLLOW_28); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_INTEGER_1, grammarAccess.getSyntaxExpressionAccess().getINTEGERTerminalRuleCall_1_0_0());
                              				
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4820:5: this_FLOAT_2= RULE_FLOAT
                            {
                            this_FLOAT_2=(Token)match(input,RULE_FLOAT,FOLLOW_28); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_2, grammarAccess.getSyntaxExpressionAccess().getFLOATTerminalRuleCall_1_0_1());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:4825:4: (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )?
                    int alt141=2;
                    int LA141_0 = input.LA(1);

                    if ( (LA141_0==RULE_SEMICOLON) ) {
                        int LA141_1 = input.LA(2);

                        if ( (LA141_1==RULE_EOLINE) ) {
                            alt141=1;
                        }
                    }
                    switch (alt141) {
                        case 1 :
                            // InternalSM2.g:4826:5: this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE
                            {
                            this_SEMICOLON_3=(Token)match(input,RULE_SEMICOLON,FOLLOW_15); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_3, grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0());
                              				
                            }
                            this_EOLINE_4=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_4, grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleTimeExpression"
    // InternalSM2.g:4840:1: entryRuleTimeExpression returns [EObject current=null] : iv_ruleTimeExpression= ruleTimeExpression EOF ;
    public final EObject entryRuleTimeExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTimeExpression = null;


        try {
            // InternalSM2.g:4840:55: (iv_ruleTimeExpression= ruleTimeExpression EOF )
            // InternalSM2.g:4841:2: iv_ruleTimeExpression= ruleTimeExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getTimeExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleTimeExpression=ruleTimeExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleTimeExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTimeExpression"


    // $ANTLR start "ruleTimeExpression"
    // InternalSM2.g:4847:1: ruleTimeExpression returns [EObject current=null] : ( ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) ;
    public final EObject ruleTimeExpression() throws RecognitionException {
        EObject current = null;

        Token lv_time_0_0=null;
        Token this_SEMICOLON_2=null;
        Token this_EOLINE_3=null;
        Enumerator lv_unit_1_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4853:2: ( ( ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) )
            // InternalSM2.g:4854:2: ( ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
            {
            // InternalSM2.g:4854:2: ( ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
            // InternalSM2.g:4855:3: ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
            {
            // InternalSM2.g:4855:3: ( (lv_time_0_0= RULE_INTEGER ) )
            // InternalSM2.g:4856:4: (lv_time_0_0= RULE_INTEGER )
            {
            // InternalSM2.g:4856:4: (lv_time_0_0= RULE_INTEGER )
            // InternalSM2.g:4857:5: lv_time_0_0= RULE_INTEGER
            {
            lv_time_0_0=(Token)match(input,RULE_INTEGER,FOLLOW_87); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_time_0_0, grammarAccess.getTimeExpressionAccess().getTimeINTEGERTerminalRuleCall_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getTimeExpressionRule());
              					}
              					setWithLastConsumed(
              						current,
              						"time",
              						lv_time_0_0,
              						"org.xtext.SM2.INTEGER");
              				
            }

            }


            }

            // InternalSM2.g:4873:3: ( (lv_unit_1_0= ruleTimeUnit ) )
            // InternalSM2.g:4874:4: (lv_unit_1_0= ruleTimeUnit )
            {
            // InternalSM2.g:4874:4: (lv_unit_1_0= ruleTimeUnit )
            // InternalSM2.g:4875:5: lv_unit_1_0= ruleTimeUnit
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getTimeExpressionAccess().getUnitTimeUnitEnumRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_28);
            lv_unit_1_0=ruleTimeUnit();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getTimeExpressionRule());
              					}
              					set(
              						current,
              						"unit",
              						lv_unit_1_0,
              						"org.xtext.SM2.TimeUnit");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4892:3: (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
            int alt143=2;
            int LA143_0 = input.LA(1);

            if ( (LA143_0==RULE_SEMICOLON) ) {
                int LA143_1 = input.LA(2);

                if ( (LA143_1==RULE_EOLINE) ) {
                    int LA143_3 = input.LA(3);

                    if ( (LA143_3==EOF||(LA143_3>=RULE_SEMICOLON && LA143_3<=RULE_INTEGER)||(LA143_3>=RULE_OPENPARENTHESIS && LA143_3<=RULE_STRING)||LA143_3==RULE_FLOAT||LA143_3==42||LA143_3==48||(LA143_3>=55 && LA143_3<=56)) ) {
                        alt143=1;
                    }
                }
            }
            switch (alt143) {
                case 1 :
                    // InternalSM2.g:4893:4: this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE
                    {
                    this_SEMICOLON_2=(Token)match(input,RULE_SEMICOLON,FOLLOW_15); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_2, grammarAccess.getTimeExpressionAccess().getSEMICOLONTerminalRuleCall_2_0());
                      			
                    }
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getTimeExpressionAccess().getEOLINETerminalRuleCall_2_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeExpression"


    // $ANTLR start "entryRuleConditional"
    // InternalSM2.g:4906:1: entryRuleConditional returns [EObject current=null] : iv_ruleConditional= ruleConditional EOF ;
    public final EObject entryRuleConditional() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConditional = null;


        try {
            // InternalSM2.g:4906:52: (iv_ruleConditional= ruleConditional EOF )
            // InternalSM2.g:4907:2: iv_ruleConditional= ruleConditional EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConditionalRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleConditional=ruleConditional();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleConditional; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConditional"


    // $ANTLR start "ruleConditional"
    // InternalSM2.g:4913:1: ruleConditional returns [EObject current=null] : (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) ) ;
    public final EObject ruleConditional() throws RecognitionException {
        EObject current = null;

        Token this_IF_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_CLOSEKEY_7=null;
        Token this_ELSE_8=null;
        EObject this_LogicalUnaryOperator_2 = null;

        EObject lv_expression_3_0 = null;

        EObject lv_expressions_6_0 = null;

        EObject lv_needOtherCondition_9_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4919:2: ( (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) ) )
            // InternalSM2.g:4920:2: (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) )
            {
            // InternalSM2.g:4920:2: (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) )
            // InternalSM2.g:4921:3: this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) )
            {
            this_IF_0=(Token)match(input,RULE_IF,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_IF_0, grammarAccess.getConditionalAccess().getIFTerminalRuleCall_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_88); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConditionalAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:4929:3: (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )?
            int alt144=2;
            int LA144_0 = input.LA(1);

            if ( (LA144_0==102) ) {
                alt144=1;
            }
            switch (alt144) {
                case 1 :
                    // InternalSM2.g:4930:4: this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator
                    {
                    if ( state.backtracking==0 ) {

                      				newCompositeNode(grammarAccess.getConditionalAccess().getLogicalUnaryOperatorParserRuleCall_2());
                      			
                    }
                    pushFollow(FOLLOW_36);
                    this_LogicalUnaryOperator_2=ruleLogicalUnaryOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = this_LogicalUnaryOperator_2;
                      				afterParserOrEnumRuleCall();
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:4939:3: ( (lv_expression_3_0= ruleExpression ) )
            // InternalSM2.g:4940:4: (lv_expression_3_0= ruleExpression )
            {
            // InternalSM2.g:4940:4: (lv_expression_3_0= ruleExpression )
            // InternalSM2.g:4941:5: lv_expression_3_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getConditionalAccess().getExpressionExpressionParserRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_27);
            lv_expression_3_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getConditionalRule());
              					}
              					set(
              						current,
              						"expression",
              						lv_expression_3_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getConditionalAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_77); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getConditionalAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:4966:3: ( (lv_expressions_6_0= ruleExpression ) )*
            loop145:
            do {
                int alt145=2;
                int LA145_0 = input.LA(1);

                if ( (LA145_0==RULE_INTEGER||LA145_0==RULE_OPENPARENTHESIS||LA145_0==RULE_STRING||LA145_0==RULE_FLOAT||LA145_0==42||LA145_0==48||(LA145_0>=55 && LA145_0<=56)) ) {
                    alt145=1;
                }


                switch (alt145) {
            	case 1 :
            	    // InternalSM2.g:4967:4: (lv_expressions_6_0= ruleExpression )
            	    {
            	    // InternalSM2.g:4967:4: (lv_expressions_6_0= ruleExpression )
            	    // InternalSM2.g:4968:5: lv_expressions_6_0= ruleExpression
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getConditionalAccess().getExpressionsExpressionParserRuleCall_6_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_77);
            	    lv_expressions_6_0=ruleExpression();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getConditionalRule());
            	      					}
            	      					add(
            	      						current,
            	      						"expressions",
            	      						lv_expressions_6_0,
            	      						"org.xtext.SM2.Expression");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop145;
                }
            } while (true);

            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_89); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_7, grammarAccess.getConditionalAccess().getCLOSEKEYTerminalRuleCall_7());
              		
            }
            // InternalSM2.g:4989:3: (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) )
            // InternalSM2.g:4990:4: this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) )
            {
            this_ELSE_8=(Token)match(input,RULE_ELSE,FOLLOW_80); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(this_ELSE_8, grammarAccess.getConditionalAccess().getELSETerminalRuleCall_8_0());
              			
            }
            // InternalSM2.g:4994:4: ( (lv_needOtherCondition_9_0= ruleConditional ) )
            // InternalSM2.g:4995:5: (lv_needOtherCondition_9_0= ruleConditional )
            {
            // InternalSM2.g:4995:5: (lv_needOtherCondition_9_0= ruleConditional )
            // InternalSM2.g:4996:6: lv_needOtherCondition_9_0= ruleConditional
            {
            if ( state.backtracking==0 ) {

              						newCompositeNode(grammarAccess.getConditionalAccess().getNeedOtherConditionConditionalParserRuleCall_8_1_0());
              					
            }
            pushFollow(FOLLOW_2);
            lv_needOtherCondition_9_0=ruleConditional();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElementForParent(grammarAccess.getConditionalRule());
              						}
              						set(
              							current,
              							"needOtherCondition",
              							lv_needOtherCondition_9_0,
              							"org.xtext.SM2.Conditional");
              						afterParserOrEnumRuleCall();
              					
            }

            }


            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConditional"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:5018:1: entryRuleComment returns [EObject current=null] : iv_ruleComment= ruleComment EOF ;
    public final EObject entryRuleComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleComment = null;


        try {
            // InternalSM2.g:5018:48: (iv_ruleComment= ruleComment EOF )
            // InternalSM2.g:5019:2: iv_ruleComment= ruleComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleComment=ruleComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:5025:1: ruleComment returns [EObject current=null] : (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) ;
    public final EObject ruleComment() throws RecognitionException {
        EObject current = null;

        EObject this_ShortComment_0 = null;

        EObject this_LongComment_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:5031:2: ( (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) )
            // InternalSM2.g:5032:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            {
            // InternalSM2.g:5032:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            int alt146=2;
            int LA146_0 = input.LA(1);

            if ( (LA146_0==99) ) {
                alt146=1;
            }
            else if ( (LA146_0==100) ) {
                alt146=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 146, 0, input);

                throw nvae;
            }
            switch (alt146) {
                case 1 :
                    // InternalSM2.g:5033:3: this_ShortComment_0= ruleShortComment
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ShortComment_0=ruleShortComment();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ShortComment_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:5042:3: this_LongComment_1= ruleLongComment
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_LongComment_1=ruleLongComment();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_LongComment_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:5054:1: entryRuleShortComment returns [EObject current=null] : iv_ruleShortComment= ruleShortComment EOF ;
    public final EObject entryRuleShortComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleShortComment = null;


        try {
            // InternalSM2.g:5054:53: (iv_ruleShortComment= ruleShortComment EOF )
            // InternalSM2.g:5055:2: iv_ruleShortComment= ruleShortComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getShortCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleShortComment=ruleShortComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleShortComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:5061:1: ruleShortComment returns [EObject current=null] : (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) ) ;
    public final EObject ruleShortComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expr_1_0=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:5067:2: ( (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) ) )
            // InternalSM2.g:5068:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) )
            {
            // InternalSM2.g:5068:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) )
            // InternalSM2.g:5069:3: otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE )
            {
            otherlv_0=(Token)match(input,99,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0());
              		
            }
            // InternalSM2.g:5073:3: ( (lv_expr_1_0= RULE_STRING ) )
            // InternalSM2.g:5074:4: (lv_expr_1_0= RULE_STRING )
            {
            // InternalSM2.g:5074:4: (lv_expr_1_0= RULE_STRING )
            // InternalSM2.g:5075:5: lv_expr_1_0= RULE_STRING
            {
            lv_expr_1_0=(Token)match(input,RULE_STRING,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr_1_0, grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getShortCommentRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr",
              						lv_expr_1_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:5091:3: ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE )
            // InternalSM2.g:5092:4: ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE
            {
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(this_EOLINE_2, grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:5102:1: entryRuleLongComment returns [EObject current=null] : iv_ruleLongComment= ruleLongComment EOF ;
    public final EObject entryRuleLongComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLongComment = null;


        try {
            // InternalSM2.g:5102:52: (iv_ruleLongComment= ruleLongComment EOF )
            // InternalSM2.g:5103:2: iv_ruleLongComment= ruleLongComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLongCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLongComment=ruleLongComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLongComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:5109:1: ruleLongComment returns [EObject current=null] : (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) ) ;
    public final EObject ruleLongComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expression_1_1=null;
        Token lv_expression_1_2=null;
        Token lv_expression_1_3=null;
        Token lv_expression_1_4=null;
        Token lv_expression_1_5=null;
        Token lv_expression_1_6=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSM2.g:5115:2: ( (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) ) )
            // InternalSM2.g:5116:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) )
            {
            // InternalSM2.g:5116:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) )
            // InternalSM2.g:5117:3: otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' )
            {
            otherlv_0=(Token)match(input,100,FOLLOW_90); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0());
              		
            }
            // InternalSM2.g:5121:3: ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )?
            int alt148=2;
            int LA148_0 = input.LA(1);

            if ( (LA148_0==RULE_STRING||(LA148_0>=RULE_PARAMSLONGCOMENT && LA148_0<=RULE_NOTICELONGCOMENT)) ) {
                alt148=1;
            }
            switch (alt148) {
                case 1 :
                    // InternalSM2.g:5122:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
                    {
                    // InternalSM2.g:5122:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
                    // InternalSM2.g:5123:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
                    {
                    // InternalSM2.g:5123:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
                    int alt147=6;
                    switch ( input.LA(1) ) {
                    case RULE_STRING:
                        {
                        alt147=1;
                        }
                        break;
                    case RULE_PARAMSLONGCOMENT:
                        {
                        alt147=2;
                        }
                        break;
                    case RULE_DEVLONGCOMENT:
                        {
                        alt147=3;
                        }
                        break;
                    case RULE_RETURNSLONGCOMENT:
                        {
                        alt147=4;
                        }
                        break;
                    case RULE_TITLELONGCOMENT:
                        {
                        alt147=5;
                        }
                        break;
                    case RULE_NOTICELONGCOMENT:
                        {
                        alt147=6;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 147, 0, input);

                        throw nvae;
                    }

                    switch (alt147) {
                        case 1 :
                            // InternalSM2.g:5124:6: lv_expression_1_1= RULE_STRING
                            {
                            lv_expression_1_1=(Token)match(input,RULE_STRING,FOLLOW_91); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_1, grammarAccess.getLongCommentAccess().getExpressionSTRINGTerminalRuleCall_1_0_0());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_1,
                              							"org.eclipse.xtext.common.Terminals.STRING");
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:5139:6: lv_expression_1_2= RULE_PARAMSLONGCOMENT
                            {
                            lv_expression_1_2=(Token)match(input,RULE_PARAMSLONGCOMENT,FOLLOW_91); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_2, grammarAccess.getLongCommentAccess().getExpressionPARAMSLONGCOMENTTerminalRuleCall_1_0_1());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_2,
                              							"org.xtext.SM2.PARAMSLONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:5154:6: lv_expression_1_3= RULE_DEVLONGCOMENT
                            {
                            lv_expression_1_3=(Token)match(input,RULE_DEVLONGCOMENT,FOLLOW_91); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_3, grammarAccess.getLongCommentAccess().getExpressionDEVLONGCOMENTTerminalRuleCall_1_0_2());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_3,
                              							"org.xtext.SM2.DEVLONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 4 :
                            // InternalSM2.g:5169:6: lv_expression_1_4= RULE_RETURNSLONGCOMENT
                            {
                            lv_expression_1_4=(Token)match(input,RULE_RETURNSLONGCOMENT,FOLLOW_91); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_4, grammarAccess.getLongCommentAccess().getExpressionRETURNSLONGCOMENTTerminalRuleCall_1_0_3());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_4,
                              							"org.xtext.SM2.RETURNSLONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 5 :
                            // InternalSM2.g:5184:6: lv_expression_1_5= RULE_TITLELONGCOMENT
                            {
                            lv_expression_1_5=(Token)match(input,RULE_TITLELONGCOMENT,FOLLOW_91); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_5, grammarAccess.getLongCommentAccess().getExpressionTITLELONGCOMENTTerminalRuleCall_1_0_4());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_5,
                              							"org.xtext.SM2.TITLELONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 6 :
                            // InternalSM2.g:5199:6: lv_expression_1_6= RULE_NOTICELONGCOMENT
                            {
                            lv_expression_1_6=(Token)match(input,RULE_NOTICELONGCOMENT,FOLLOW_91); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_6, grammarAccess.getLongCommentAccess().getExpressionNOTICELONGCOMENTTerminalRuleCall_1_0_5());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_6,
                              							"org.xtext.SM2.NOTICELONGCOMENT");
                              					
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }

            // InternalSM2.g:5216:3: ( ( '*/' )=>otherlv_2= '*/' )
            // InternalSM2.g:5217:4: ( '*/' )=>otherlv_2= '*/'
            {
            otherlv_2=(Token)match(input,101,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_2, grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "entryRuleLogicalUnaryOperator"
    // InternalSM2.g:5227:1: entryRuleLogicalUnaryOperator returns [EObject current=null] : iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF ;
    public final EObject entryRuleLogicalUnaryOperator() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLogicalUnaryOperator = null;


        try {
            // InternalSM2.g:5227:61: (iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF )
            // InternalSM2.g:5228:2: iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLogicalUnaryOperatorRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLogicalUnaryOperator=ruleLogicalUnaryOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLogicalUnaryOperator; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLogicalUnaryOperator"


    // $ANTLR start "ruleLogicalUnaryOperator"
    // InternalSM2.g:5234:1: ruleLogicalUnaryOperator returns [EObject current=null] : ( (lv_operator_0_0= '!' ) ) ;
    public final EObject ruleLogicalUnaryOperator() throws RecognitionException {
        EObject current = null;

        Token lv_operator_0_0=null;


        	enterRule();

        try {
            // InternalSM2.g:5240:2: ( ( (lv_operator_0_0= '!' ) ) )
            // InternalSM2.g:5241:2: ( (lv_operator_0_0= '!' ) )
            {
            // InternalSM2.g:5241:2: ( (lv_operator_0_0= '!' ) )
            // InternalSM2.g:5242:3: (lv_operator_0_0= '!' )
            {
            // InternalSM2.g:5242:3: (lv_operator_0_0= '!' )
            // InternalSM2.g:5243:4: lv_operator_0_0= '!'
            {
            lv_operator_0_0=(Token)match(input,102,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(lv_operator_0_0, grammarAccess.getLogicalUnaryOperatorAccess().getOperatorExclamationMarkKeyword_0());
              			
            }
            if ( state.backtracking==0 ) {

              				if (current==null) {
              					current = createModelElement(grammarAccess.getLogicalUnaryOperatorRule());
              				}
              				setWithLastConsumed(current, "operator", lv_operator_0_0, "!");
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalUnaryOperator"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:5258:1: ruleVisibility returns [Enumerator current=null] : ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) ;
    public final Enumerator ruleVisibility() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalSM2.g:5264:2: ( ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) )
            // InternalSM2.g:5265:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            {
            // InternalSM2.g:5265:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            int alt149=4;
            switch ( input.LA(1) ) {
            case 60:
                {
                alt149=1;
                }
                break;
            case 103:
                {
                alt149=2;
                }
                break;
            case 61:
                {
                alt149=3;
                }
                break;
            case 104:
                {
                alt149=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 149, 0, input);

                throw nvae;
            }

            switch (alt149) {
                case 1 :
                    // InternalSM2.g:5266:3: (enumLiteral_0= 'public' )
                    {
                    // InternalSM2.g:5266:3: (enumLiteral_0= 'public' )
                    // InternalSM2.g:5267:4: enumLiteral_0= 'public'
                    {
                    enumLiteral_0=(Token)match(input,60,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5274:3: (enumLiteral_1= 'private' )
                    {
                    // InternalSM2.g:5274:3: (enumLiteral_1= 'private' )
                    // InternalSM2.g:5275:4: enumLiteral_1= 'private'
                    {
                    enumLiteral_1=(Token)match(input,103,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5282:3: (enumLiteral_2= 'internal' )
                    {
                    // InternalSM2.g:5282:3: (enumLiteral_2= 'internal' )
                    // InternalSM2.g:5283:4: enumLiteral_2= 'internal'
                    {
                    enumLiteral_2=(Token)match(input,61,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:5290:3: (enumLiteral_3= 'external' )
                    {
                    // InternalSM2.g:5290:3: (enumLiteral_3= 'external' )
                    // InternalSM2.g:5291:4: enumLiteral_3= 'external'
                    {
                    enumLiteral_3=(Token)match(input,104,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:5301:1: ruleCoin returns [Enumerator current=null] : ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) ;
    public final Enumerator ruleCoin() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:5307:2: ( ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) )
            // InternalSM2.g:5308:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            {
            // InternalSM2.g:5308:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            int alt150=6;
            switch ( input.LA(1) ) {
            case 105:
                {
                alt150=1;
                }
                break;
            case 106:
                {
                alt150=2;
                }
                break;
            case 107:
                {
                alt150=3;
                }
                break;
            case 108:
                {
                alt150=4;
                }
                break;
            case 109:
                {
                alt150=5;
                }
                break;
            case 110:
                {
                alt150=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 150, 0, input);

                throw nvae;
            }

            switch (alt150) {
                case 1 :
                    // InternalSM2.g:5309:3: (enumLiteral_0= 'ether' )
                    {
                    // InternalSM2.g:5309:3: (enumLiteral_0= 'ether' )
                    // InternalSM2.g:5310:4: enumLiteral_0= 'ether'
                    {
                    enumLiteral_0=(Token)match(input,105,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5317:3: (enumLiteral_1= 'wei' )
                    {
                    // InternalSM2.g:5317:3: (enumLiteral_1= 'wei' )
                    // InternalSM2.g:5318:4: enumLiteral_1= 'wei'
                    {
                    enumLiteral_1=(Token)match(input,106,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5325:3: (enumLiteral_2= 'gwei' )
                    {
                    // InternalSM2.g:5325:3: (enumLiteral_2= 'gwei' )
                    // InternalSM2.g:5326:4: enumLiteral_2= 'gwei'
                    {
                    enumLiteral_2=(Token)match(input,107,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:5333:3: (enumLiteral_3= 'pwei' )
                    {
                    // InternalSM2.g:5333:3: (enumLiteral_3= 'pwei' )
                    // InternalSM2.g:5334:4: enumLiteral_3= 'pwei'
                    {
                    enumLiteral_3=(Token)match(input,108,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:5341:3: (enumLiteral_4= 'finney' )
                    {
                    // InternalSM2.g:5341:3: (enumLiteral_4= 'finney' )
                    // InternalSM2.g:5342:4: enumLiteral_4= 'finney'
                    {
                    enumLiteral_4=(Token)match(input,109,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:5349:3: (enumLiteral_5= 'szabo' )
                    {
                    // InternalSM2.g:5349:3: (enumLiteral_5= 'szabo' )
                    // InternalSM2.g:5350:4: enumLiteral_5= 'szabo'
                    {
                    enumLiteral_5=(Token)match(input,110,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:5360:1: ruleComparationOperator returns [Enumerator current=null] : ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) ;
    public final Enumerator ruleComparationOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:5366:2: ( ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) )
            // InternalSM2.g:5367:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            {
            // InternalSM2.g:5367:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            int alt151=6;
            switch ( input.LA(1) ) {
            case 35:
                {
                alt151=1;
                }
                break;
            case 111:
                {
                alt151=2;
                }
                break;
            case 36:
                {
                alt151=3;
                }
                break;
            case 112:
                {
                alt151=4;
                }
                break;
            case 97:
                {
                alt151=5;
                }
                break;
            case 113:
                {
                alt151=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 151, 0, input);

                throw nvae;
            }

            switch (alt151) {
                case 1 :
                    // InternalSM2.g:5368:3: (enumLiteral_0= '>' )
                    {
                    // InternalSM2.g:5368:3: (enumLiteral_0= '>' )
                    // InternalSM2.g:5369:4: enumLiteral_0= '>'
                    {
                    enumLiteral_0=(Token)match(input,35,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5376:3: (enumLiteral_1= '<' )
                    {
                    // InternalSM2.g:5376:3: (enumLiteral_1= '<' )
                    // InternalSM2.g:5377:4: enumLiteral_1= '<'
                    {
                    enumLiteral_1=(Token)match(input,111,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5384:3: (enumLiteral_2= '>=' )
                    {
                    // InternalSM2.g:5384:3: (enumLiteral_2= '>=' )
                    // InternalSM2.g:5385:4: enumLiteral_2= '>='
                    {
                    enumLiteral_2=(Token)match(input,36,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:5392:3: (enumLiteral_3= '<=' )
                    {
                    // InternalSM2.g:5392:3: (enumLiteral_3= '<=' )
                    // InternalSM2.g:5393:4: enumLiteral_3= '<='
                    {
                    enumLiteral_3=(Token)match(input,112,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:5400:3: (enumLiteral_4= '==' )
                    {
                    // InternalSM2.g:5400:3: (enumLiteral_4= '==' )
                    // InternalSM2.g:5401:4: enumLiteral_4= '=='
                    {
                    enumLiteral_4=(Token)match(input,97,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:5408:3: (enumLiteral_5= '!=' )
                    {
                    // InternalSM2.g:5408:3: (enumLiteral_5= '!=' )
                    // InternalSM2.g:5409:4: enumLiteral_5= '!='
                    {
                    enumLiteral_5=(Token)match(input,113,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:5419:1: ruleLogicalPairOperator returns [Enumerator current=null] : ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) ;
    public final Enumerator ruleLogicalPairOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSM2.g:5425:2: ( ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) )
            // InternalSM2.g:5426:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            {
            // InternalSM2.g:5426:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            int alt152=2;
            int LA152_0 = input.LA(1);

            if ( (LA152_0==114) ) {
                alt152=1;
            }
            else if ( (LA152_0==115) ) {
                alt152=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 152, 0, input);

                throw nvae;
            }
            switch (alt152) {
                case 1 :
                    // InternalSM2.g:5427:3: (enumLiteral_0= '&&' )
                    {
                    // InternalSM2.g:5427:3: (enumLiteral_0= '&&' )
                    // InternalSM2.g:5428:4: enumLiteral_0= '&&'
                    {
                    enumLiteral_0=(Token)match(input,114,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5435:3: (enumLiteral_1= '||' )
                    {
                    // InternalSM2.g:5435:3: (enumLiteral_1= '||' )
                    // InternalSM2.g:5436:4: enumLiteral_1= '||'
                    {
                    enumLiteral_1=(Token)match(input,115,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:5446:1: ruleArithmeticalOperator returns [Enumerator current=null] : ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) ;
    public final Enumerator ruleArithmeticalOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;


        	enterRule();

        try {
            // InternalSM2.g:5452:2: ( ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) )
            // InternalSM2.g:5453:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            {
            // InternalSM2.g:5453:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            int alt153=5;
            switch ( input.LA(1) ) {
            case 116:
                {
                alt153=1;
                }
                break;
            case 117:
                {
                alt153=2;
                }
                break;
            case 118:
                {
                alt153=3;
                }
                break;
            case 119:
                {
                alt153=4;
                }
                break;
            case 120:
                {
                alt153=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 153, 0, input);

                throw nvae;
            }

            switch (alt153) {
                case 1 :
                    // InternalSM2.g:5454:3: (enumLiteral_0= '+' )
                    {
                    // InternalSM2.g:5454:3: (enumLiteral_0= '+' )
                    // InternalSM2.g:5455:4: enumLiteral_0= '+'
                    {
                    enumLiteral_0=(Token)match(input,116,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5462:3: (enumLiteral_1= '-' )
                    {
                    // InternalSM2.g:5462:3: (enumLiteral_1= '-' )
                    // InternalSM2.g:5463:4: enumLiteral_1= '-'
                    {
                    enumLiteral_1=(Token)match(input,117,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5470:3: (enumLiteral_2= '*' )
                    {
                    // InternalSM2.g:5470:3: (enumLiteral_2= '*' )
                    // InternalSM2.g:5471:4: enumLiteral_2= '*'
                    {
                    enumLiteral_2=(Token)match(input,118,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:5478:3: (enumLiteral_3= '/' )
                    {
                    // InternalSM2.g:5478:3: (enumLiteral_3= '/' )
                    // InternalSM2.g:5479:4: enumLiteral_3= '/'
                    {
                    enumLiteral_3=(Token)match(input,119,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:5486:3: (enumLiteral_4= '%' )
                    {
                    // InternalSM2.g:5486:3: (enumLiteral_4= '%' )
                    // InternalSM2.g:5487:4: enumLiteral_4= '%'
                    {
                    enumLiteral_4=(Token)match(input,120,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmeticalOperator"


    // $ANTLR start "ruleBasicType"
    // InternalSM2.g:5497:1: ruleBasicType returns [Enumerator current=null] : ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) ) ;
    public final Enumerator ruleBasicType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;
        Token enumLiteral_8=null;
        Token enumLiteral_9=null;
        Token enumLiteral_10=null;


        	enterRule();

        try {
            // InternalSM2.g:5503:2: ( ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) ) )
            // InternalSM2.g:5504:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) )
            {
            // InternalSM2.g:5504:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) )
            int alt154=11;
            switch ( input.LA(1) ) {
            case 77:
                {
                alt154=1;
                }
                break;
            case 78:
                {
                alt154=2;
                }
                break;
            case 79:
                {
                alt154=3;
                }
                break;
            case 82:
                {
                alt154=4;
                }
                break;
            case 70:
                {
                alt154=5;
                }
                break;
            case 68:
                {
                alt154=6;
                }
                break;
            case 84:
                {
                alt154=7;
                }
                break;
            case 121:
                {
                alt154=8;
                }
                break;
            case 83:
                {
                alt154=9;
                }
                break;
            case 122:
                {
                alt154=10;
                }
                break;
            case 89:
                {
                alt154=11;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 154, 0, input);

                throw nvae;
            }

            switch (alt154) {
                case 1 :
                    // InternalSM2.g:5505:3: (enumLiteral_0= 'int' )
                    {
                    // InternalSM2.g:5505:3: (enumLiteral_0= 'int' )
                    // InternalSM2.g:5506:4: enumLiteral_0= 'int'
                    {
                    enumLiteral_0=(Token)match(input,77,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getINTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getBasicTypeAccess().getINTEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5513:3: (enumLiteral_1= 'uint' )
                    {
                    // InternalSM2.g:5513:3: (enumLiteral_1= 'uint' )
                    // InternalSM2.g:5514:4: enumLiteral_1= 'uint'
                    {
                    enumLiteral_1=(Token)match(input,78,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getBasicTypeAccess().getUINTEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5521:3: (enumLiteral_2= 'uint8' )
                    {
                    // InternalSM2.g:5521:3: (enumLiteral_2= 'uint8' )
                    // InternalSM2.g:5522:4: enumLiteral_2= 'uint8'
                    {
                    enumLiteral_2=(Token)match(input,79,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT8EnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getBasicTypeAccess().getUINT8EnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:5529:3: (enumLiteral_3= 'uint256' )
                    {
                    // InternalSM2.g:5529:3: (enumLiteral_3= 'uint256' )
                    // InternalSM2.g:5530:4: enumLiteral_3= 'uint256'
                    {
                    enumLiteral_3=(Token)match(input,82,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT256EnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getBasicTypeAccess().getUINT256EnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:5537:3: (enumLiteral_4= 'string' )
                    {
                    // InternalSM2.g:5537:3: (enumLiteral_4= 'string' )
                    // InternalSM2.g:5538:4: enumLiteral_4= 'string'
                    {
                    enumLiteral_4=(Token)match(input,70,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getSTRINGEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getBasicTypeAccess().getSTRINGEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:5545:3: (enumLiteral_5= 'address' )
                    {
                    // InternalSM2.g:5545:3: (enumLiteral_5= 'address' )
                    // InternalSM2.g:5546:4: enumLiteral_5= 'address'
                    {
                    enumLiteral_5=(Token)match(input,68,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getADDRESSEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getBasicTypeAccess().getADDRESSEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:5553:3: (enumLiteral_6= 'address payable' )
                    {
                    // InternalSM2.g:5553:3: (enumLiteral_6= 'address payable' )
                    // InternalSM2.g:5554:4: enumLiteral_6= 'address payable'
                    {
                    enumLiteral_6=(Token)match(input,84,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_6, grammarAccess.getBasicTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6());
                      			
                    }

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:5561:3: (enumLiteral_7= 'double' )
                    {
                    // InternalSM2.g:5561:3: (enumLiteral_7= 'double' )
                    // InternalSM2.g:5562:4: enumLiteral_7= 'double'
                    {
                    enumLiteral_7=(Token)match(input,121,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getDOUBLEEnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_7, grammarAccess.getBasicTypeAccess().getDOUBLEEnumLiteralDeclaration_7());
                      			
                    }

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:5569:3: (enumLiteral_8= 'bool' )
                    {
                    // InternalSM2.g:5569:3: (enumLiteral_8= 'bool' )
                    // InternalSM2.g:5570:4: enumLiteral_8= 'bool'
                    {
                    enumLiteral_8=(Token)match(input,83,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBOOLEANEnumLiteralDeclaration_8().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_8, grammarAccess.getBasicTypeAccess().getBOOLEANEnumLiteralDeclaration_8());
                      			
                    }

                    }


                    }
                    break;
                case 10 :
                    // InternalSM2.g:5577:3: (enumLiteral_9= 'byte' )
                    {
                    // InternalSM2.g:5577:3: (enumLiteral_9= 'byte' )
                    // InternalSM2.g:5578:4: enumLiteral_9= 'byte'
                    {
                    enumLiteral_9=(Token)match(input,122,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTEEnumLiteralDeclaration_9().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_9, grammarAccess.getBasicTypeAccess().getBYTEEnumLiteralDeclaration_9());
                      			
                    }

                    }


                    }
                    break;
                case 11 :
                    // InternalSM2.g:5585:3: (enumLiteral_10= 'bytes32' )
                    {
                    // InternalSM2.g:5585:3: (enumLiteral_10= 'bytes32' )
                    // InternalSM2.g:5586:4: enumLiteral_10= 'bytes32'
                    {
                    enumLiteral_10=(Token)match(input,89,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE32EnumLiteralDeclaration_10().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_10, grammarAccess.getBasicTypeAccess().getBYTE32EnumLiteralDeclaration_10());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBasicType"


    // $ANTLR start "ruleTimeUnit"
    // InternalSM2.g:5596:1: ruleTimeUnit returns [Enumerator current=null] : ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) ) ;
    public final Enumerator ruleTimeUnit() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:5602:2: ( ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) ) )
            // InternalSM2.g:5603:2: ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) )
            {
            // InternalSM2.g:5603:2: ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) )
            int alt155=6;
            switch ( input.LA(1) ) {
            case 123:
                {
                alt155=1;
                }
                break;
            case 124:
                {
                alt155=2;
                }
                break;
            case 125:
                {
                alt155=3;
                }
                break;
            case 126:
                {
                alt155=4;
                }
                break;
            case 127:
                {
                alt155=5;
                }
                break;
            case 128:
                {
                alt155=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 155, 0, input);

                throw nvae;
            }

            switch (alt155) {
                case 1 :
                    // InternalSM2.g:5604:3: (enumLiteral_0= 'seconds' )
                    {
                    // InternalSM2.g:5604:3: (enumLiteral_0= 'seconds' )
                    // InternalSM2.g:5605:4: enumLiteral_0= 'seconds'
                    {
                    enumLiteral_0=(Token)match(input,123,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getSECONDSEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getTimeUnitAccess().getSECONDSEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5612:3: (enumLiteral_1= 'minutes' )
                    {
                    // InternalSM2.g:5612:3: (enumLiteral_1= 'minutes' )
                    // InternalSM2.g:5613:4: enumLiteral_1= 'minutes'
                    {
                    enumLiteral_1=(Token)match(input,124,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getMINUTESEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getTimeUnitAccess().getMINUTESEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5620:3: (enumLiteral_2= 'hours' )
                    {
                    // InternalSM2.g:5620:3: (enumLiteral_2= 'hours' )
                    // InternalSM2.g:5621:4: enumLiteral_2= 'hours'
                    {
                    enumLiteral_2=(Token)match(input,125,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getHOURSEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getTimeUnitAccess().getHOURSEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:5628:3: (enumLiteral_3= 'days' )
                    {
                    // InternalSM2.g:5628:3: (enumLiteral_3= 'days' )
                    // InternalSM2.g:5629:4: enumLiteral_3= 'days'
                    {
                    enumLiteral_3=(Token)match(input,126,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getDAYSEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getTimeUnitAccess().getDAYSEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:5636:3: (enumLiteral_4= 'weeks' )
                    {
                    // InternalSM2.g:5636:3: (enumLiteral_4= 'weeks' )
                    // InternalSM2.g:5637:4: enumLiteral_4= 'weeks'
                    {
                    enumLiteral_4=(Token)match(input,127,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getWEEKSEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getTimeUnitAccess().getWEEKSEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:5644:3: (enumLiteral_5= 'years' )
                    {
                    // InternalSM2.g:5644:3: (enumLiteral_5= 'years' )
                    // InternalSM2.g:5645:4: enumLiteral_5= 'years'
                    {
                    enumLiteral_5=(Token)match(input,128,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getYEARSEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getTimeUnitAccess().getYEARSEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeUnit"

    // $ANTLR start synpred2_InternalSM2
    public final void synpred2_InternalSM2_fragment() throws RecognitionException {   
        // InternalSM2.g:5217:4: ( '*/' )
        // InternalSM2.g:5217:5: '*/'
        {
        match(input,101,FOLLOW_2); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred2_InternalSM2

    // Delegated rules

    public final boolean synpred2_InternalSM2() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred2_InternalSM2_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA51 dfa51 = new DFA51(this);
    protected DFA118 dfa118 = new DFA118(this);
    protected DFA130 dfa130 = new DFA130(this);
    static final String dfa_1s = "\65\uffff";
    static final String dfa_2s = "\1\103\1\11\1\12\1\5\1\11\1\uffff\1\7\1\4\1\7\1\5\1\4\1\6\4\4\1\5\1\15\1\5\1\uffff\1\4\1\6\3\4\1\5\1\4\1\5\2\15\1\5\1\4\1\6\4\4\1\5\1\4\1\5\1\16\1\15\1\5\1\6\1\4\1\7\3\4\2\5\1\uffff\1\7";
    static final String dfa_3s = "\1\103\1\11\1\12\2\131\1\uffff\1\150\1\105\1\17\1\131\1\4\1\131\2\15\2\105\1\131\1\15\1\131\1\uffff\1\15\1\131\1\4\1\15\1\105\1\106\1\105\1\131\2\15\1\131\1\15\1\131\1\4\1\105\1\15\1\105\1\106\1\105\1\131\1\16\1\15\2\131\1\15\1\150\1\4\2\105\1\107\1\131\1\uffff\1\150";
    static final String dfa_4s = "\5\uffff\1\1\15\uffff\1\2\37\uffff\1\3\1\uffff";
    static final String dfa_5s = "\65\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\4\3\uffff\1\5\72\uffff\1\6\1\uffff\2\5\5\uffff\15\5",
            "\1\5\72\uffff\1\6\1\uffff\2\5\5\uffff\15\5",
            "",
            "\1\5\1\uffff\1\7\62\uffff\2\5\14\uffff\2\5\33\uffff\2\5",
            "\1\11\100\uffff\1\10",
            "\1\5\5\uffff\1\12\1\uffff\1\5",
            "\1\13\1\5\2\uffff\1\5\72\uffff\1\5\1\uffff\1\14\1\5\5\uffff\15\5",
            "\1\11",
            "\1\5\2\uffff\1\5\72\uffff\1\5\1\uffff\1\15\1\5\5\uffff\15\5",
            "\1\5\10\uffff\1\16",
            "\1\5\10\uffff\1\17",
            "\1\20\100\uffff\1\21",
            "\1\22\100\uffff\1\23",
            "\1\25\1\5\2\uffff\1\5\72\uffff\1\5\1\uffff\1\24\1\5\5\uffff\15\5",
            "\1\26",
            "\1\25\1\5\2\uffff\1\5\72\uffff\1\5\1\uffff\1\27\1\5\5\uffff\15\5",
            "",
            "\1\5\10\uffff\1\30",
            "\1\5\2\uffff\1\5\72\uffff\1\5\1\uffff\1\27\1\5\5\uffff\15\5",
            "\1\31",
            "\1\5\10\uffff\1\32",
            "\1\33\100\uffff\1\34",
            "\1\23\100\uffff\1\35",
            "\1\36\100\uffff\1\23",
            "\1\40\1\5\2\uffff\1\5\72\uffff\1\5\1\uffff\1\37\1\5\5\uffff\15\5",
            "\1\41",
            "\1\42",
            "\1\40\1\5\2\uffff\1\5\72\uffff\1\5\1\uffff\1\43\1\5\5\uffff\15\5",
            "\1\5\10\uffff\1\44",
            "\1\5\2\uffff\1\5\72\uffff\1\5\1\uffff\1\43\1\5\5\uffff\15\5",
            "\1\45",
            "\1\45\100\uffff\1\34",
            "\1\5\10\uffff\1\46",
            "\1\47\100\uffff\1\50",
            "\1\23\100\uffff\1\51",
            "\1\52\100\uffff\1\23",
            "\1\53\1\5\2\uffff\1\5\72\uffff\1\5\1\uffff\1\54\1\55\5\uffff\15\5",
            "\1\56",
            "\1\57",
            "\1\53\1\5\2\uffff\1\5\72\uffff\1\5\1\uffff\1\5\1\55\5\uffff\15\5",
            "\1\5\2\uffff\1\5\72\uffff\1\5\1\uffff\1\5\1\55\5\uffff\15\5",
            "\1\5\10\uffff\1\60",
            "\1\5\1\uffff\1\5\62\uffff\2\5\12\uffff\1\23\1\uffff\2\5\33\uffff\2\5",
            "\1\61",
            "\1\61\100\uffff\1\50",
            "\1\62\100\uffff\1\63",
            "\1\23\100\uffff\1\63\1\23",
            "\2\5\2\uffff\1\5\72\uffff\1\5\1\uffff\1\5\1\64\5\uffff\15\5",
            "",
            "\1\5\1\uffff\1\5\62\uffff\2\5\12\uffff\1\63\1\uffff\2\5\33\uffff\2\5"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA51 extends DFA {

        public DFA51(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 51;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "1763:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )";
        }
    }
    static final String dfa_7s = "\22\uffff";
    static final String dfa_8s = "\1\7\1\13\1\uffff\1\7\1\43\2\4\6\7\1\5\1\uffff\2\4\1\43";
    static final String dfa_9s = "\1\134\1\13\1\uffff\1\17\3\161\6\17\1\5\1\uffff\2\156\1\161";
    static final String dfa_10s = "\2\uffff\1\2\13\uffff\1\1\3\uffff";
    static final String dfa_11s = "\22\uffff}>";
    static final String[] dfa_12s = {
            "\1\2\1\uffff\1\2\1\uffff\1\2\1\uffff\1\2\1\uffff\1\2\3\uffff\1\2\26\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\1\uffff\2\2\1\uffff\2\2\1\uffff\1\2\3\uffff\15\2\2\uffff\1\1",
            "\1\3",
            "",
            "\1\5\5\uffff\1\4\1\uffff\1\6",
            "\1\7\1\11\74\uffff\1\13\15\uffff\1\10\1\12\1\14",
            "\1\15\36\uffff\1\7\1\11\74\uffff\1\13\15\uffff\1\10\1\12\1\14",
            "\1\15\36\uffff\1\7\1\11\74\uffff\1\13\15\uffff\1\10\1\12\1\14",
            "\1\17\5\uffff\1\16\1\uffff\1\20",
            "\1\17\5\uffff\1\16\1\uffff\1\20",
            "\1\17\5\uffff\1\16\1\uffff\1\20",
            "\1\17\5\uffff\1\16\1\uffff\1\20",
            "\1\17\5\uffff\1\16\1\uffff\1\20",
            "\1\17\5\uffff\1\16\1\uffff\1\20",
            "\1\21",
            "",
            "\1\16\7\uffff\1\16\134\uffff\6\2",
            "\1\16\7\uffff\1\16\134\uffff\6\2",
            "\1\7\1\11\74\uffff\1\13\15\uffff\1\10\1\12\1\14"
    };

    static final short[] dfa_7 = DFA.unpackEncodedString(dfa_7s);
    static final char[] dfa_8 = DFA.unpackEncodedStringToUnsignedChars(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final short[] dfa_10 = DFA.unpackEncodedString(dfa_10s);
    static final short[] dfa_11 = DFA.unpackEncodedString(dfa_11s);
    static final short[][] dfa_12 = unpackEncodedStringArray(dfa_12s);

    class DFA118 extends DFA {

        public DFA118(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 118;
            this.eot = dfa_7;
            this.eof = dfa_7;
            this.min = dfa_8;
            this.max = dfa_9;
            this.accept = dfa_10;
            this.special = dfa_11;
            this.transition = dfa_12;
        }
        public String getDescription() {
            return "4014:3: ( (lv_restriction_4_0= ruleRestriction ) )?";
        }
    }
    static final String dfa_13s = "\2\uffff\2\4\16\uffff";
    static final String dfa_14s = "\2\7\2\4\2\uffff\2\164\2\uffff\5\7\2\14\1\uffff";
    static final String dfa_15s = "\1\70\1\17\1\u0080\1\170\2\uffff\2\170\2\uffff\5\17\2\161\1\uffff";
    static final String dfa_16s = "\4\uffff\1\3\1\5\2\uffff\1\4\1\1\7\uffff\1\2";
    static final String[] dfa_17s = {
            "\1\2\3\uffff\1\1\1\uffff\1\4\1\uffff\1\3\32\uffff\1\5\5\uffff\1\5\6\uffff\2\5",
            "\1\6\7\uffff\1\7",
            "\4\4\3\uffff\3\4\1\uffff\1\4\32\uffff\1\4\5\uffff\1\4\6\uffff\2\4\73\uffff\5\11\2\uffff\6\10",
            "\4\4\3\uffff\3\4\1\uffff\1\4\32\uffff\1\4\5\uffff\1\4\6\uffff\2\4\73\uffff\5\11",
            "",
            "",
            "\1\12\1\13\1\14\1\15\1\16",
            "\1\12\1\13\1\14\1\15\1\16",
            "",
            "",
            "\1\17\7\uffff\1\20",
            "\1\17\7\uffff\1\20",
            "\1\17\7\uffff\1\20",
            "\1\17\7\uffff\1\20",
            "\1\17\7\uffff\1\20",
            "\1\11\26\uffff\2\21\74\uffff\1\21\15\uffff\3\21",
            "\1\11\26\uffff\2\21\74\uffff\1\21\15\uffff\3\21",
            ""
    };
    static final short[] dfa_13 = DFA.unpackEncodedString(dfa_13s);
    static final char[] dfa_14 = DFA.unpackEncodedStringToUnsignedChars(dfa_14s);
    static final char[] dfa_15 = DFA.unpackEncodedStringToUnsignedChars(dfa_15s);
    static final short[] dfa_16 = DFA.unpackEncodedString(dfa_16s);
    static final short[][] dfa_17 = unpackEncodedStringArray(dfa_17s);

    class DFA130 extends DFA {

        public DFA130(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 130;
            this.eot = dfa_7;
            this.eof = dfa_13;
            this.min = dfa_14;
            this.max = dfa_15;
            this.accept = dfa_16;
            this.special = dfa_11;
            this.transition = dfa_17;
        }
        public String getDescription() {
            return "4406:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000001C00000000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x000001A000000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000202L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000004000000010L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000210L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000020000000400L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0xC800000000000222L,0x0000001843FFE2DAL});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0xC800000000000202L,0x0000001843FFE2DAL});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0xC000000000000002L,0x0000001840000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x8000000000000002L,0x0000001840000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000000002L,0x0000001840000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000000002L,0x0000001800000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000F80000000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x000000000000A080L,0x0000000003E00000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x000000000000A080L,0x0000000003E7E000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x000000000000A080L,0x0000000003F00010L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x007E000000000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0600000000000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x3000000000000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000000000000240L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000001000L,0x06000000021CE050L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x018104000008A8A0L,0x0000000003E00000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000000000020L,0x0000000000000001L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000000000000L,0x06000000021CE050L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000004L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000000200L,0x06000000021CE050L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x3000000000000200L,0x0000018000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000000000000220L,0x0000000003FFE0D0L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000000000000200L,0x0000000003FFE0D0L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000000240L,0x0000000003FFE0D0L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000000000000020L,0x0000000000000010L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000000010L,0x0000000000000020L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000000000020L,0x0000000000000040L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0000000000000020L,0x0000000000000080L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000100L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0000000000008080L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0000000000000060L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0000000000012040L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0000000000002040L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0000000000000082L,0x0000000000000C00L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x0000000000002010L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x3000000000000280L,0x0000018000000C00L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0000000000000090L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x0000000000000280L,0x000000000C000C00L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x0000000000000200L,0x000000000C000000L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0x0000001800000000L,0x0003800200000000L});
    public static final BitSet FOLLOW_73 = new BitSet(new long[]{0x0000000000000000L,0x00007E0000000000L});
    public static final BitSet FOLLOW_74 = new BitSet(new long[]{0x0000000000000400L,0x0000000020000000L});
    public static final BitSet FOLLOW_75 = new BitSet(new long[]{0x018104000008AAA0L,0x0000000013FFE2DAL});
    public static final BitSet FOLLOW_76 = new BitSet(new long[]{0x018104000008AAA0L,0x0000000003FFE2DAL});
    public static final BitSet FOLLOW_77 = new BitSet(new long[]{0x018104000008A8E0L,0x0000000003E00000L});
    public static final BitSet FOLLOW_78 = new BitSet(new long[]{0x0000000000001200L});
    public static final BitSet FOLLOW_79 = new BitSet(new long[]{0x0000000000000000L,0x0000000080000000L});
    public static final BitSet FOLLOW_80 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_81 = new BitSet(new long[]{0x0000000000000000L,0x0000000100000000L});
    public static final BitSet FOLLOW_82 = new BitSet(new long[]{0x0000000000000000L,0x0000000200000000L});
    public static final BitSet FOLLOW_83 = new BitSet(new long[]{0x018104000008A8A0L,0x0600000003FCE050L});
    public static final BitSet FOLLOW_84 = new BitSet(new long[]{0x0000000000000000L,0x0000000400000000L});
    public static final BitSet FOLLOW_85 = new BitSet(new long[]{0x0000000000000000L,0x01F0000000000000L});
    public static final BitSet FOLLOW_86 = new BitSet(new long[]{0x0000000000008880L});
    public static final BitSet FOLLOW_87 = new BitSet(new long[]{0x0000000000000000L,0xF800000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_88 = new BitSet(new long[]{0x018104000008A8A0L,0x0000004003E00000L});
    public static final BitSet FOLLOW_89 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_90 = new BitSet(new long[]{0x0000000003E02000L,0x0000002000000000L});
    public static final BitSet FOLLOW_91 = new BitSet(new long[]{0x0000000000000000L,0x0000002000000000L});

}