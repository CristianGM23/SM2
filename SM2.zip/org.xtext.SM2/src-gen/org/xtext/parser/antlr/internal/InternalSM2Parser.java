package org.xtext.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_CLOSEKEY", "RULE_OPENKEY", "RULE_DOT", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_STRING", "RULE_EMAIL", "RULE_INTEGER", "RULE_FLOAT", "RULE_SINGLENUMBER", "RULE_BOOLVALUE", "RULE_RETURN", "RULE_IF", "RULE_NEW", "RULE_DELETE", "RULE_COMMA", "RULE_BREAK", "RULE_ELSE", "RULE_PARAMSLONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_NOTICELONGCOMENT", "RULE_HEXADECIMAL", "RULE_RETURNS", "RULE_CONTINUE", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'pragma'", "'solidity'", "'^ '", "'> '", "'>='", "'<'", "'<= '", "'import'", "'as'", "'interface'", "'contract'", "'is'", "'msg'", "'data'", "'value'", "'gas'", "'sender'", "'sig'", "'block'", "'difficulty'", "'number'", "'timestamp'", "'coinbase'", "'gaslimit'", "'blockhash'", "'now'", "'tx'", "'gasprice'", "'origin'", "'constructor'", "'public'", "'internal'", "'event'", "'modifier'", "'_;'", "'!'", "'mapping'", "'=>'", "'struct'", "'address'", "'string'", "'='", "'float'", "'amountAccount'", "'enum'", "'[]'", "'['", "']'", "'memory'", "'storage'", "'int'", "'uint'", "'uint2'", "'uint4'", "'uint8'", "'uint16'", "'uint24'", "'uint32'", "'uint64'", "'uint128'", "'uint160'", "'uint256'", "'bool'", "'address payable'", "'bytes'", "'bytes2'", "'bytes3'", "'bytes4'", "'bytes5'", "'bytes6'", "'bytes7'", "'bytes8'", "'bytes16'", "'bytes32'", "'require'", "'function'", "'kill'", "'msg.sender'", "'=='", "'selfdestruct'", "'while'", "'for'", "'//'", "'/*'", "'*/'", "'private'", "'external'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'--'", "'++'", "'>'", "'<='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'", "'%'", "'+='", "'-='", "'*='", "'/='", "'%='", "'double'", "'byte'", "'seconds'", "'minutes'", "'hours'", "'days'", "'weeks'", "'years'"
    };
    public static final int T__144=144;
    public static final int T__143=143;
    public static final int T__146=146;
    public static final int T__50=50;
    public static final int T__145=145;
    public static final int T__140=140;
    public static final int T__142=142;
    public static final int T__141=141;
    public static final int RULE_RETURNS=31;
    public static final int RULE_OPENPARENTHESIS=10;
    public static final int RULE_EOLINE=6;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__137=137;
    public static final int T__52=52;
    public static final int T__136=136;
    public static final int T__53=53;
    public static final int T__139=139;
    public static final int T__54=54;
    public static final int T__138=138;
    public static final int T__133=133;
    public static final int T__132=132;
    public static final int RULE_PARAMSLONGCOMENT=25;
    public static final int T__60=60;
    public static final int T__135=135;
    public static final int T__61=61;
    public static final int T__134=134;
    public static final int RULE_ID=4;
    public static final int RULE_RETURN=18;
    public static final int T__131=131;
    public static final int T__130=130;
    public static final int RULE_INT=33;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=34;
    public static final int T__67=67;
    public static final int T__129=129;
    public static final int RULE_HEXADECIMAL=30;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__126=126;
    public static final int T__63=63;
    public static final int T__125=125;
    public static final int T__64=64;
    public static final int T__128=128;
    public static final int T__65=65;
    public static final int T__127=127;
    public static final int RULE_DELETE=21;
    public static final int RULE_TITLELONGCOMENT=28;
    public static final int RULE_EMAIL=13;
    public static final int RULE_NOTICELONGCOMENT=29;
    public static final int RULE_OPENKEY=8;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int RULE_CLOSEPARENTHESIS=11;
    public static final int RULE_IF=19;
    public static final int RULE_DOT=9;
    public static final int T__155=155;
    public static final int T__154=154;
    public static final int T__151=151;
    public static final int T__150=150;
    public static final int T__153=153;
    public static final int T__152=152;
    public static final int RULE_CONTINUE=32;
    public static final int RULE_DEVLONGCOMENT=26;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int RULE_FLOAT=15;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__148=148;
    public static final int T__41=41;
    public static final int T__147=147;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__149=149;
    public static final int T__91=91;
    public static final int T__100=100;
    public static final int T__92=92;
    public static final int T__93=93;
    public static final int T__102=102;
    public static final int T__94=94;
    public static final int T__101=101;
    public static final int RULE_NEW=20;
    public static final int T__90=90;
    public static final int RULE_SINGLENUMBER=16;
    public static final int T__99=99;
    public static final int RULE_CLOSEKEY=7;
    public static final int T__95=95;
    public static final int T__96=96;
    public static final int T__97=97;
    public static final int T__98=98;
    public static final int RULE_COMMA=22;
    public static final int RULE_RETURNSLONGCOMENT=27;
    public static final int RULE_SEMICOLON=5;
    public static final int RULE_ELSE=24;
    public static final int T__122=122;
    public static final int T__70=70;
    public static final int T__121=121;
    public static final int T__71=71;
    public static final int T__124=124;
    public static final int RULE_BOOLVALUE=17;
    public static final int T__72=72;
    public static final int T__123=123;
    public static final int T__120=120;
    public static final int RULE_STRING=12;
    public static final int RULE_SL_COMMENT=35;
    public static final int RULE_BREAK=23;
    public static final int T__77=77;
    public static final int T__119=119;
    public static final int T__78=78;
    public static final int T__118=118;
    public static final int T__79=79;
    public static final int T__73=73;
    public static final int T__115=115;
    public static final int EOF=-1;
    public static final int T__74=74;
    public static final int T__114=114;
    public static final int T__75=75;
    public static final int T__117=117;
    public static final int T__76=76;
    public static final int T__116=116;
    public static final int T__80=80;
    public static final int T__111=111;
    public static final int T__81=81;
    public static final int T__110=110;
    public static final int T__82=82;
    public static final int T__113=113;
    public static final int T__83=83;
    public static final int T__112=112;
    public static final int RULE_WS=36;
    public static final int RULE_ANY_OTHER=37;
    public static final int T__88=88;
    public static final int T__108=108;
    public static final int T__89=89;
    public static final int T__107=107;
    public static final int T__109=109;
    public static final int T__84=84;
    public static final int T__104=104;
    public static final int T__85=85;
    public static final int T__103=103;
    public static final int RULE_INTEGER=14;
    public static final int T__86=86;
    public static final int T__106=106;
    public static final int T__87=87;
    public static final int T__105=105;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }



     	private SM2GrammarAccess grammarAccess;

        public InternalSM2Parser(TokenStream input, SM2GrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "SmartContract";
       	}

       	@Override
       	protected SM2GrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleSmartContract"
    // InternalSM2.g:65:1: entryRuleSmartContract returns [EObject current=null] : iv_ruleSmartContract= ruleSmartContract EOF ;
    public final EObject entryRuleSmartContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSmartContract = null;


        try {
            // InternalSM2.g:65:54: (iv_ruleSmartContract= ruleSmartContract EOF )
            // InternalSM2.g:66:2: iv_ruleSmartContract= ruleSmartContract EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSmartContractRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSmartContract=ruleSmartContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSmartContract; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSmartContract"


    // $ANTLR start "ruleSmartContract"
    // InternalSM2.g:72:1: ruleSmartContract returns [EObject current=null] : ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( ( (lv_operator_2_1= '^ ' | lv_operator_2_2= '> ' | lv_operator_2_3= '>=' ) ) ) ( (otherlv_3= RULE_ID ) ) ( ( ( (lv_operatorLessThan_4_1= '<' | lv_operatorLessThan_4_2= '<= ' ) ) ) ( (otherlv_5= RULE_ID ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ( (lv_imports_8_0= ruleLibrary ) )* ( (lv_interfaces_9_0= ruleInterface ) )* ( (lv_contracts_10_0= ruleContract ) ) this_CLOSEKEY_11= RULE_CLOSEKEY ) ;
    public final EObject ruleSmartContract() throws RecognitionException {
        EObject current = null;

        Token lv_compiler_0_0=null;
        Token otherlv_1=null;
        Token lv_operator_2_1=null;
        Token lv_operator_2_2=null;
        Token lv_operator_2_3=null;
        Token otherlv_3=null;
        Token lv_operatorLessThan_4_1=null;
        Token lv_operatorLessThan_4_2=null;
        Token otherlv_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        Token this_CLOSEKEY_11=null;
        EObject lv_imports_8_0 = null;

        EObject lv_interfaces_9_0 = null;

        EObject lv_contracts_10_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:78:2: ( ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( ( (lv_operator_2_1= '^ ' | lv_operator_2_2= '> ' | lv_operator_2_3= '>=' ) ) ) ( (otherlv_3= RULE_ID ) ) ( ( ( (lv_operatorLessThan_4_1= '<' | lv_operatorLessThan_4_2= '<= ' ) ) ) ( (otherlv_5= RULE_ID ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ( (lv_imports_8_0= ruleLibrary ) )* ( (lv_interfaces_9_0= ruleInterface ) )* ( (lv_contracts_10_0= ruleContract ) ) this_CLOSEKEY_11= RULE_CLOSEKEY ) )
            // InternalSM2.g:79:2: ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( ( (lv_operator_2_1= '^ ' | lv_operator_2_2= '> ' | lv_operator_2_3= '>=' ) ) ) ( (otherlv_3= RULE_ID ) ) ( ( ( (lv_operatorLessThan_4_1= '<' | lv_operatorLessThan_4_2= '<= ' ) ) ) ( (otherlv_5= RULE_ID ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ( (lv_imports_8_0= ruleLibrary ) )* ( (lv_interfaces_9_0= ruleInterface ) )* ( (lv_contracts_10_0= ruleContract ) ) this_CLOSEKEY_11= RULE_CLOSEKEY )
            {
            // InternalSM2.g:79:2: ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( ( (lv_operator_2_1= '^ ' | lv_operator_2_2= '> ' | lv_operator_2_3= '>=' ) ) ) ( (otherlv_3= RULE_ID ) ) ( ( ( (lv_operatorLessThan_4_1= '<' | lv_operatorLessThan_4_2= '<= ' ) ) ) ( (otherlv_5= RULE_ID ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ( (lv_imports_8_0= ruleLibrary ) )* ( (lv_interfaces_9_0= ruleInterface ) )* ( (lv_contracts_10_0= ruleContract ) ) this_CLOSEKEY_11= RULE_CLOSEKEY )
            // InternalSM2.g:80:3: ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( ( (lv_operator_2_1= '^ ' | lv_operator_2_2= '> ' | lv_operator_2_3= '>=' ) ) ) ( (otherlv_3= RULE_ID ) ) ( ( ( (lv_operatorLessThan_4_1= '<' | lv_operatorLessThan_4_2= '<= ' ) ) ) ( (otherlv_5= RULE_ID ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ( (lv_imports_8_0= ruleLibrary ) )* ( (lv_interfaces_9_0= ruleInterface ) )* ( (lv_contracts_10_0= ruleContract ) ) this_CLOSEKEY_11= RULE_CLOSEKEY
            {
            // InternalSM2.g:80:3: ( (lv_compiler_0_0= 'pragma' ) )
            // InternalSM2.g:81:4: (lv_compiler_0_0= 'pragma' )
            {
            // InternalSM2.g:81:4: (lv_compiler_0_0= 'pragma' )
            // InternalSM2.g:82:5: lv_compiler_0_0= 'pragma'
            {
            lv_compiler_0_0=(Token)match(input,38,FOLLOW_3); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_compiler_0_0, grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getSmartContractRule());
              					}
              					setWithLastConsumed(current, "compiler", lv_compiler_0_0, "pragma");
              				
            }

            }


            }

            otherlv_1=(Token)match(input,39,FOLLOW_4); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getSmartContractAccess().getSolidityKeyword_1());
              		
            }
            // InternalSM2.g:98:3: ( ( (lv_operator_2_1= '^ ' | lv_operator_2_2= '> ' | lv_operator_2_3= '>=' ) ) )
            // InternalSM2.g:99:4: ( (lv_operator_2_1= '^ ' | lv_operator_2_2= '> ' | lv_operator_2_3= '>=' ) )
            {
            // InternalSM2.g:99:4: ( (lv_operator_2_1= '^ ' | lv_operator_2_2= '> ' | lv_operator_2_3= '>=' ) )
            // InternalSM2.g:100:5: (lv_operator_2_1= '^ ' | lv_operator_2_2= '> ' | lv_operator_2_3= '>=' )
            {
            // InternalSM2.g:100:5: (lv_operator_2_1= '^ ' | lv_operator_2_2= '> ' | lv_operator_2_3= '>=' )
            int alt1=3;
            switch ( input.LA(1) ) {
            case 40:
                {
                alt1=1;
                }
                break;
            case 41:
                {
                alt1=2;
                }
                break;
            case 42:
                {
                alt1=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // InternalSM2.g:101:6: lv_operator_2_1= '^ '
                    {
                    lv_operator_2_1=(Token)match(input,40,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_operator_2_1, grammarAccess.getSmartContractAccess().getOperatorCircumflexAccentSpaceKeyword_2_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getSmartContractRule());
                      						}
                      						setWithLastConsumed(current, "operator", lv_operator_2_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:112:6: lv_operator_2_2= '> '
                    {
                    lv_operator_2_2=(Token)match(input,41,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_operator_2_2, grammarAccess.getSmartContractAccess().getOperatorGreaterThanSignSpaceKeyword_2_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getSmartContractRule());
                      						}
                      						setWithLastConsumed(current, "operator", lv_operator_2_2, null);
                      					
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:123:6: lv_operator_2_3= '>='
                    {
                    lv_operator_2_3=(Token)match(input,42,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_operator_2_3, grammarAccess.getSmartContractAccess().getOperatorGreaterThanSignEqualsSignKeyword_2_0_2());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getSmartContractRule());
                      						}
                      						setWithLastConsumed(current, "operator", lv_operator_2_3, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:136:3: ( (otherlv_3= RULE_ID ) )
            // InternalSM2.g:137:4: (otherlv_3= RULE_ID )
            {
            // InternalSM2.g:137:4: (otherlv_3= RULE_ID )
            // InternalSM2.g:138:5: otherlv_3= RULE_ID
            {
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getSmartContractRule());
              					}
              				
            }
            otherlv_3=(Token)match(input,RULE_ID,FOLLOW_6); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(otherlv_3, grammarAccess.getSmartContractAccess().getVersionCompilerVersionCrossReference_3_0());
              				
            }

            }


            }

            // InternalSM2.g:149:3: ( ( ( (lv_operatorLessThan_4_1= '<' | lv_operatorLessThan_4_2= '<= ' ) ) ) ( (otherlv_5= RULE_ID ) ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( ((LA3_0>=43 && LA3_0<=44)) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalSM2.g:150:4: ( ( (lv_operatorLessThan_4_1= '<' | lv_operatorLessThan_4_2= '<= ' ) ) ) ( (otherlv_5= RULE_ID ) )
                    {
                    // InternalSM2.g:150:4: ( ( (lv_operatorLessThan_4_1= '<' | lv_operatorLessThan_4_2= '<= ' ) ) )
                    // InternalSM2.g:151:5: ( (lv_operatorLessThan_4_1= '<' | lv_operatorLessThan_4_2= '<= ' ) )
                    {
                    // InternalSM2.g:151:5: ( (lv_operatorLessThan_4_1= '<' | lv_operatorLessThan_4_2= '<= ' ) )
                    // InternalSM2.g:152:6: (lv_operatorLessThan_4_1= '<' | lv_operatorLessThan_4_2= '<= ' )
                    {
                    // InternalSM2.g:152:6: (lv_operatorLessThan_4_1= '<' | lv_operatorLessThan_4_2= '<= ' )
                    int alt2=2;
                    int LA2_0 = input.LA(1);

                    if ( (LA2_0==43) ) {
                        alt2=1;
                    }
                    else if ( (LA2_0==44) ) {
                        alt2=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 2, 0, input);

                        throw nvae;
                    }
                    switch (alt2) {
                        case 1 :
                            // InternalSM2.g:153:7: lv_operatorLessThan_4_1= '<'
                            {
                            lv_operatorLessThan_4_1=(Token)match(input,43,FOLLOW_5); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_operatorLessThan_4_1, grammarAccess.getSmartContractAccess().getOperatorLessThanLessThanSignKeyword_4_0_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getSmartContractRule());
                              							}
                              							setWithLastConsumed(current, "operatorLessThan", lv_operatorLessThan_4_1, null);
                              						
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:164:7: lv_operatorLessThan_4_2= '<= '
                            {
                            lv_operatorLessThan_4_2=(Token)match(input,44,FOLLOW_5); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_operatorLessThan_4_2, grammarAccess.getSmartContractAccess().getOperatorLessThanLessThanSignEqualsSignSpaceKeyword_4_0_0_1());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getSmartContractRule());
                              							}
                              							setWithLastConsumed(current, "operatorLessThan", lv_operatorLessThan_4_2, null);
                              						
                            }

                            }
                            break;

                    }


                    }


                    }

                    // InternalSM2.g:177:4: ( (otherlv_5= RULE_ID ) )
                    // InternalSM2.g:178:5: (otherlv_5= RULE_ID )
                    {
                    // InternalSM2.g:178:5: (otherlv_5= RULE_ID )
                    // InternalSM2.g:179:6: otherlv_5= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getSmartContractRule());
                      						}
                      					
                    }
                    otherlv_5=(Token)match(input,RULE_ID,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(otherlv_5, grammarAccess.getSmartContractAccess().getVersionCompiler2VersionCrossReference_4_1_0());
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_8); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:195:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==RULE_EOLINE) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalSM2.g:196:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:201:3: ( (lv_imports_8_0= ruleLibrary ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==45) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalSM2.g:202:4: (lv_imports_8_0= ruleLibrary )
            	    {
            	    // InternalSM2.g:202:4: (lv_imports_8_0= ruleLibrary )
            	    // InternalSM2.g:203:5: lv_imports_8_0= ruleLibrary
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getImportsLibraryParserRuleCall_7_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_8);
            	    lv_imports_8_0=ruleLibrary();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"imports",
            	      						lv_imports_8_0,
            	      						"org.xtext.SM2.Library");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            // InternalSM2.g:220:3: ( (lv_interfaces_9_0= ruleInterface ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==47) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalSM2.g:221:4: (lv_interfaces_9_0= ruleInterface )
            	    {
            	    // InternalSM2.g:221:4: (lv_interfaces_9_0= ruleInterface )
            	    // InternalSM2.g:222:5: lv_interfaces_9_0= ruleInterface
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getInterfacesInterfaceParserRuleCall_8_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_8);
            	    lv_interfaces_9_0=ruleInterface();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"interfaces",
            	      						lv_interfaces_9_0,
            	      						"org.xtext.SM2.Interface");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            // InternalSM2.g:239:3: ( (lv_contracts_10_0= ruleContract ) )
            // InternalSM2.g:240:4: (lv_contracts_10_0= ruleContract )
            {
            // InternalSM2.g:240:4: (lv_contracts_10_0= ruleContract )
            // InternalSM2.g:241:5: lv_contracts_10_0= ruleContract
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getSmartContractAccess().getContractsContractParserRuleCall_9_0());
              				
            }
            pushFollow(FOLLOW_9);
            lv_contracts_10_0=ruleContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getSmartContractRule());
              					}
              					add(
              						current,
              						"contracts",
              						lv_contracts_10_0,
              						"org.xtext.SM2.Contract");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_11, grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_10());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSmartContract"


    // $ANTLR start "entryRuleLibrary"
    // InternalSM2.g:266:1: entryRuleLibrary returns [EObject current=null] : iv_ruleLibrary= ruleLibrary EOF ;
    public final EObject entryRuleLibrary() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLibrary = null;


        try {
            // InternalSM2.g:266:48: (iv_ruleLibrary= ruleLibrary EOF )
            // InternalSM2.g:267:2: iv_ruleLibrary= ruleLibrary EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLibraryRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLibrary=ruleLibrary();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLibrary; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLibrary"


    // $ANTLR start "ruleLibrary"
    // InternalSM2.g:273:1: ruleLibrary returns [EObject current=null] : (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) ;
    public final EObject ruleLibrary() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameLibrary_1_0=null;
        Token otherlv_2=null;
        Token lv_alias_3_0=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;


        	enterRule();

        try {
            // InternalSM2.g:279:2: ( (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:280:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:280:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:281:3: otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,45,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getLibraryAccess().getImportKeyword_0());
              		
            }
            // InternalSM2.g:285:3: ( (lv_nameLibrary_1_0= RULE_ID ) )
            // InternalSM2.g:286:4: (lv_nameLibrary_1_0= RULE_ID )
            {
            // InternalSM2.g:286:4: (lv_nameLibrary_1_0= RULE_ID )
            // InternalSM2.g:287:5: lv_nameLibrary_1_0= RULE_ID
            {
            lv_nameLibrary_1_0=(Token)match(input,RULE_ID,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameLibrary_1_0, grammarAccess.getLibraryAccess().getNameLibraryIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getLibraryRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameLibrary",
              						lv_nameLibrary_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:303:3: (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==46) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalSM2.g:304:4: otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,46,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getLibraryAccess().getAsKeyword_2_0());
                      			
                    }
                    // InternalSM2.g:308:4: ( (lv_alias_3_0= RULE_ID ) )
                    // InternalSM2.g:309:5: (lv_alias_3_0= RULE_ID )
                    {
                    // InternalSM2.g:309:5: (lv_alias_3_0= RULE_ID )
                    // InternalSM2.g:310:6: lv_alias_3_0= RULE_ID
                    {
                    lv_alias_3_0=(Token)match(input,RULE_ID,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_alias_3_0, grammarAccess.getLibraryAccess().getAliasIDTerminalRuleCall_2_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLibraryRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"alias",
                      							lv_alias_3_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_4, grammarAccess.getLibraryAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:331:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==RULE_EOLINE) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalSM2.g:332:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_5, grammarAccess.getLibraryAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLibrary"


    // $ANTLR start "entryRuleInterface"
    // InternalSM2.g:341:1: entryRuleInterface returns [EObject current=null] : iv_ruleInterface= ruleInterface EOF ;
    public final EObject entryRuleInterface() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInterface = null;


        try {
            // InternalSM2.g:341:50: (iv_ruleInterface= ruleInterface EOF )
            // InternalSM2.g:342:2: iv_ruleInterface= ruleInterface EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getInterfaceRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleInterface=ruleInterface();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleInterface; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInterface"


    // $ANTLR start "ruleInterface"
    // InternalSM2.g:348:1: ruleInterface returns [EObject current=null] : (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE ) ;
    public final EObject ruleInterface() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameInterface_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;
        Token this_CLOSEKEY_7=null;
        Token this_EOLINE_8=null;


        	enterRule();

        try {
            // InternalSM2.g:354:2: ( (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE ) )
            // InternalSM2.g:355:2: (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE )
            {
            // InternalSM2.g:355:2: (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE )
            // InternalSM2.g:356:3: otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (otherlv_4= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE this_CLOSEKEY_7= RULE_CLOSEKEY this_EOLINE_8= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,47,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getInterfaceAccess().getInterfaceKeyword_0());
              		
            }
            // InternalSM2.g:360:3: ( (lv_nameInterface_1_0= RULE_ID ) )
            // InternalSM2.g:361:4: (lv_nameInterface_1_0= RULE_ID )
            {
            // InternalSM2.g:361:4: (lv_nameInterface_1_0= RULE_ID )
            // InternalSM2.g:362:5: lv_nameInterface_1_0= RULE_ID
            {
            lv_nameInterface_1_0=(Token)match(input,RULE_ID,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameInterface_1_0, grammarAccess.getInterfaceAccess().getNameInterfaceIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getInterfaceRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameInterface",
              						lv_nameInterface_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getInterfaceAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_3, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_3());
              		
            }
            // InternalSM2.g:386:3: ( (otherlv_4= RULE_ID ) )
            // InternalSM2.g:387:4: (otherlv_4= RULE_ID )
            {
            // InternalSM2.g:387:4: (otherlv_4= RULE_ID )
            // InternalSM2.g:388:5: otherlv_4= RULE_ID
            {
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getInterfaceRule());
              					}
              				
            }
            otherlv_4=(Token)match(input,RULE_ID,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(otherlv_4, grammarAccess.getInterfaceAccess().getFunctionsHeadClauseCrossReference_4_0());
              				
            }

            }


            }

            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_5, grammarAccess.getInterfaceAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_6, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_6());
              		
            }
            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_7, grammarAccess.getInterfaceAccess().getCLOSEKEYTerminalRuleCall_7());
              		
            }
            this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_8, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInterface"


    // $ANTLR start "entryRuleContract"
    // InternalSM2.g:419:1: entryRuleContract returns [EObject current=null] : iv_ruleContract= ruleContract EOF ;
    public final EObject entryRuleContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleContract = null;


        try {
            // InternalSM2.g:419:49: (iv_ruleContract= ruleContract EOF )
            // InternalSM2.g:420:2: iv_ruleContract= ruleContract EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getContractRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleContract=ruleContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleContract; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleContract"


    // $ANTLR start "ruleContract"
    // InternalSM2.g:426:1: ruleContract returns [EObject current=null] : ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* ) ;
    public final EObject ruleContract() throws RecognitionException {
        EObject current = null;

        Token lv_contract_0_0=null;
        Token lv_nameContract_1_0=null;
        Token otherlv_2=null;
        Token lv_nameContractFather_3_0=null;
        Token this_OPENKEY_4=null;
        Token this_EOLINE_5=null;
        EObject lv_attributes_6_0 = null;

        EObject lv_constructor_7_0 = null;

        EObject lv_events_8_0 = null;

        EObject lv_modifier_9_0 = null;

        EObject lv_functions_10_0 = null;

        EObject lv_comments_11_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:432:2: ( ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* ) )
            // InternalSM2.g:433:2: ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* )
            {
            // InternalSM2.g:433:2: ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* )
            // InternalSM2.g:434:3: ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )*
            {
            // InternalSM2.g:434:3: ( (lv_contract_0_0= 'contract' ) )
            // InternalSM2.g:435:4: (lv_contract_0_0= 'contract' )
            {
            // InternalSM2.g:435:4: (lv_contract_0_0= 'contract' )
            // InternalSM2.g:436:5: lv_contract_0_0= 'contract'
            {
            lv_contract_0_0=(Token)match(input,48,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_contract_0_0, grammarAccess.getContractAccess().getContractContractKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getContractRule());
              					}
              					setWithLastConsumed(current, "contract", lv_contract_0_0, "contract");
              				
            }

            }


            }

            // InternalSM2.g:448:3: ( (lv_nameContract_1_0= RULE_ID ) )
            // InternalSM2.g:449:4: (lv_nameContract_1_0= RULE_ID )
            {
            // InternalSM2.g:449:4: (lv_nameContract_1_0= RULE_ID )
            // InternalSM2.g:450:5: lv_nameContract_1_0= RULE_ID
            {
            lv_nameContract_1_0=(Token)match(input,RULE_ID,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameContract_1_0, grammarAccess.getContractAccess().getNameContractIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getContractRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameContract",
              						lv_nameContract_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:466:3: (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==49) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalSM2.g:467:4: otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,49,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getContractAccess().getIsKeyword_2_0());
                      			
                    }
                    // InternalSM2.g:471:4: ( (lv_nameContractFather_3_0= RULE_ID ) )
                    // InternalSM2.g:472:5: (lv_nameContractFather_3_0= RULE_ID )
                    {
                    // InternalSM2.g:472:5: (lv_nameContractFather_3_0= RULE_ID )
                    // InternalSM2.g:473:6: lv_nameContractFather_3_0= RULE_ID
                    {
                    lv_nameContractFather_3_0=(Token)match(input,RULE_ID,FOLLOW_12); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_nameContractFather_3_0, grammarAccess.getContractAccess().getNameContractFatherIDTerminalRuleCall_2_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getContractRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"nameContractFather",
                      							lv_nameContractFather_3_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_OPENKEY_4=(Token)match(input,RULE_OPENKEY,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_4, grammarAccess.getContractAccess().getOPENKEYTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:494:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==RULE_EOLINE) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalSM2.g:495:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_16); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_5, grammarAccess.getContractAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:500:3: ( (lv_attributes_6_0= ruleAttributes ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==RULE_ID) ) {
                    int LA11_2 = input.LA(2);

                    if ( (LA11_2==RULE_ID||(LA11_2>=68 && LA11_2<=69)||(LA11_2>=83 && LA11_2<=84)||(LA11_2>=123 && LA11_2<=124)) ) {
                        alt11=1;
                    }


                }
                else if ( (LA11_0==74||(LA11_0>=76 && LA11_0<=78)||LA11_0==80||LA11_0==82||(LA11_0>=88 && LA11_0<=111)) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalSM2.g:501:4: (lv_attributes_6_0= ruleAttributes )
            	    {
            	    // InternalSM2.g:501:4: (lv_attributes_6_0= ruleAttributes )
            	    // InternalSM2.g:502:5: lv_attributes_6_0= ruleAttributes
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getAttributesAttributesParserRuleCall_5_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_16);
            	    lv_attributes_6_0=ruleAttributes();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"attributes",
            	      						lv_attributes_6_0,
            	      						"org.xtext.SM2.Attributes");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

            // InternalSM2.g:519:3: ( (lv_constructor_7_0= ruleConstructor ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==67) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalSM2.g:520:4: (lv_constructor_7_0= ruleConstructor )
                    {
                    // InternalSM2.g:520:4: (lv_constructor_7_0= ruleConstructor )
                    // InternalSM2.g:521:5: lv_constructor_7_0= ruleConstructor
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getContractAccess().getConstructorConstructorParserRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_17);
                    lv_constructor_7_0=ruleConstructor();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getContractRule());
                      					}
                      					set(
                      						current,
                      						"constructor",
                      						lv_constructor_7_0,
                      						"org.xtext.SM2.Constructor");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:538:3: ( (lv_events_8_0= ruleEvent ) )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==70) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalSM2.g:539:4: (lv_events_8_0= ruleEvent )
            	    {
            	    // InternalSM2.g:539:4: (lv_events_8_0= ruleEvent )
            	    // InternalSM2.g:540:5: lv_events_8_0= ruleEvent
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getEventsEventParserRuleCall_7_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_17);
            	    lv_events_8_0=ruleEvent();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"events",
            	      						lv_events_8_0,
            	      						"org.xtext.SM2.Event");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

            // InternalSM2.g:557:3: ( (lv_modifier_9_0= ruleModifier ) )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==71) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // InternalSM2.g:558:4: (lv_modifier_9_0= ruleModifier )
            	    {
            	    // InternalSM2.g:558:4: (lv_modifier_9_0= ruleModifier )
            	    // InternalSM2.g:559:5: lv_modifier_9_0= ruleModifier
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getModifierModifierParserRuleCall_8_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_18);
            	    lv_modifier_9_0=ruleModifier();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"modifier",
            	      						lv_modifier_9_0,
            	      						"org.xtext.SM2.Modifier");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);

            // InternalSM2.g:576:3: ( (lv_functions_10_0= ruleFunction ) )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==RULE_ID||LA15_0==113) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalSM2.g:577:4: (lv_functions_10_0= ruleFunction )
            	    {
            	    // InternalSM2.g:577:4: (lv_functions_10_0= ruleFunction )
            	    // InternalSM2.g:578:5: lv_functions_10_0= ruleFunction
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getFunctionsFunctionParserRuleCall_9_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_19);
            	    lv_functions_10_0=ruleFunction();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"functions",
            	      						lv_functions_10_0,
            	      						"org.xtext.SM2.Function");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

            // InternalSM2.g:595:3: ( (lv_comments_11_0= ruleComment ) )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( ((LA16_0>=120 && LA16_0<=121)) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // InternalSM2.g:596:4: (lv_comments_11_0= ruleComment )
            	    {
            	    // InternalSM2.g:596:4: (lv_comments_11_0= ruleComment )
            	    // InternalSM2.g:597:5: lv_comments_11_0= ruleComment
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getCommentsCommentParserRuleCall_10_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_20);
            	    lv_comments_11_0=ruleComment();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"comments",
            	      						lv_comments_11_0,
            	      						"org.xtext.SM2.Comment");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleContract"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:618:1: entryRuleAttributes returns [EObject current=null] : iv_ruleAttributes= ruleAttributes EOF ;
    public final EObject entryRuleAttributes() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttributes = null;


        try {
            // InternalSM2.g:618:51: (iv_ruleAttributes= ruleAttributes EOF )
            // InternalSM2.g:619:2: iv_ruleAttributes= ruleAttributes EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getAttributesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleAttributes=ruleAttributes();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleAttributes; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:625:1: ruleAttributes returns [EObject current=null] : (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) ;
    public final EObject ruleAttributes() throws RecognitionException {
        EObject current = null;

        EObject this_Property_0 = null;

        EObject this_DataType_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:631:2: ( (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) )
            // InternalSM2.g:632:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            {
            // InternalSM2.g:632:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==RULE_ID||(LA17_0>=77 && LA17_0<=78)||LA17_0==80||(LA17_0>=88 && LA17_0<=111)) ) {
                alt17=1;
            }
            else if ( (LA17_0==74||LA17_0==76||LA17_0==82) ) {
                alt17=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }
            switch (alt17) {
                case 1 :
                    // InternalSM2.g:633:3: this_Property_0= ruleProperty
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Property_0=ruleProperty();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Property_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:642:3: this_DataType_1= ruleDataType
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_DataType_1=ruleDataType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_DataType_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleVariables"
    // InternalSM2.g:654:1: entryRuleVariables returns [EObject current=null] : iv_ruleVariables= ruleVariables EOF ;
    public final EObject entryRuleVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVariables = null;


        try {
            // InternalSM2.g:654:50: (iv_ruleVariables= ruleVariables EOF )
            // InternalSM2.g:655:2: iv_ruleVariables= ruleVariables EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getVariablesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleVariables=ruleVariables();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleVariables; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVariables"


    // $ANTLR start "ruleVariables"
    // InternalSM2.g:661:1: ruleVariables returns [EObject current=null] : (this_MSGVariables_0= ruleMSGVariables | this_BlockVariables_1= ruleBlockVariables | this_TxVariables_2= ruleTxVariables ) ;
    public final EObject ruleVariables() throws RecognitionException {
        EObject current = null;

        EObject this_MSGVariables_0 = null;

        EObject this_BlockVariables_1 = null;

        EObject this_TxVariables_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:667:2: ( (this_MSGVariables_0= ruleMSGVariables | this_BlockVariables_1= ruleBlockVariables | this_TxVariables_2= ruleTxVariables ) )
            // InternalSM2.g:668:2: (this_MSGVariables_0= ruleMSGVariables | this_BlockVariables_1= ruleBlockVariables | this_TxVariables_2= ruleTxVariables )
            {
            // InternalSM2.g:668:2: (this_MSGVariables_0= ruleMSGVariables | this_BlockVariables_1= ruleBlockVariables | this_TxVariables_2= ruleTxVariables )
            int alt18=3;
            switch ( input.LA(1) ) {
            case 50:
                {
                alt18=1;
                }
                break;
            case 56:
            case 63:
                {
                alt18=2;
                }
                break;
            case 64:
                {
                alt18=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }

            switch (alt18) {
                case 1 :
                    // InternalSM2.g:669:3: this_MSGVariables_0= ruleMSGVariables
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getVariablesAccess().getMSGVariablesParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_MSGVariables_0=ruleMSGVariables();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_MSGVariables_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:678:3: this_BlockVariables_1= ruleBlockVariables
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getVariablesAccess().getBlockVariablesParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_BlockVariables_1=ruleBlockVariables();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_BlockVariables_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:687:3: this_TxVariables_2= ruleTxVariables
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getVariablesAccess().getTxVariablesParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_TxVariables_2=ruleTxVariables();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_TxVariables_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVariables"


    // $ANTLR start "entryRuleMSGVariables"
    // InternalSM2.g:699:1: entryRuleMSGVariables returns [EObject current=null] : iv_ruleMSGVariables= ruleMSGVariables EOF ;
    public final EObject entryRuleMSGVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMSGVariables = null;


        try {
            // InternalSM2.g:699:53: (iv_ruleMSGVariables= ruleMSGVariables EOF )
            // InternalSM2.g:700:2: iv_ruleMSGVariables= ruleMSGVariables EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMSGVariablesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleMSGVariables=ruleMSGVariables();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleMSGVariables; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMSGVariables"


    // $ANTLR start "ruleMSGVariables"
    // InternalSM2.g:706:1: ruleMSGVariables returns [EObject current=null] : (otherlv_0= 'msg' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'data' ) | ( (otherlv_8= 'value' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'value' ) | ( (otherlv_14= 'gas' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'gas' ) | ( (otherlv_20= 'sender' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sender' ) | ( (otherlv_26= 'sig' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyBytes_28= rulePropertyBytes | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'sig' ) ) (this_SEMICOLON_32= RULE_SEMICOLON this_EOLINE_33= RULE_EOLINE )? ) ;
    public final EObject ruleMSGVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_DOT_1=null;
        Token otherlv_2=null;
        Token this_OPENPARENTHESIS_3=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token this_OPENPARENTHESIS_9=null;
        Token this_CLOSEPARENTHESIS_12=null;
        Token otherlv_13=null;
        Token otherlv_14=null;
        Token this_OPENPARENTHESIS_15=null;
        Token this_CLOSEPARENTHESIS_18=null;
        Token otherlv_19=null;
        Token otherlv_20=null;
        Token this_OPENPARENTHESIS_21=null;
        Token this_CLOSEPARENTHESIS_24=null;
        Token otherlv_25=null;
        Token otherlv_26=null;
        Token this_OPENPARENTHESIS_27=null;
        Token this_CLOSEPARENTHESIS_30=null;
        Token otherlv_31=null;
        Token this_SEMICOLON_32=null;
        Token this_EOLINE_33=null;
        EObject this_PropertyBytes_4 = null;

        EObject this_SyntaxExpression_5 = null;

        EObject this_PropertyInteger_10 = null;

        EObject this_SyntaxExpression_11 = null;

        EObject this_PropertyInteger_16 = null;

        EObject this_SyntaxExpression_17 = null;

        EObject this_PropertyAddress_22 = null;

        EObject this_SyntaxExpression_23 = null;

        EObject this_PropertyBytes_28 = null;

        EObject this_SyntaxExpression_29 = null;



        	enterRule();

        try {
            // InternalSM2.g:712:2: ( (otherlv_0= 'msg' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'data' ) | ( (otherlv_8= 'value' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'value' ) | ( (otherlv_14= 'gas' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'gas' ) | ( (otherlv_20= 'sender' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sender' ) | ( (otherlv_26= 'sig' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyBytes_28= rulePropertyBytes | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'sig' ) ) (this_SEMICOLON_32= RULE_SEMICOLON this_EOLINE_33= RULE_EOLINE )? ) )
            // InternalSM2.g:713:2: (otherlv_0= 'msg' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'data' ) | ( (otherlv_8= 'value' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'value' ) | ( (otherlv_14= 'gas' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'gas' ) | ( (otherlv_20= 'sender' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sender' ) | ( (otherlv_26= 'sig' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyBytes_28= rulePropertyBytes | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'sig' ) ) (this_SEMICOLON_32= RULE_SEMICOLON this_EOLINE_33= RULE_EOLINE )? )
            {
            // InternalSM2.g:713:2: (otherlv_0= 'msg' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'data' ) | ( (otherlv_8= 'value' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'value' ) | ( (otherlv_14= 'gas' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'gas' ) | ( (otherlv_20= 'sender' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sender' ) | ( (otherlv_26= 'sig' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyBytes_28= rulePropertyBytes | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'sig' ) ) (this_SEMICOLON_32= RULE_SEMICOLON this_EOLINE_33= RULE_EOLINE )? )
            // InternalSM2.g:714:3: otherlv_0= 'msg' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'data' ) | ( (otherlv_8= 'value' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'value' ) | ( (otherlv_14= 'gas' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'gas' ) | ( (otherlv_20= 'sender' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sender' ) | ( (otherlv_26= 'sig' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyBytes_28= rulePropertyBytes | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'sig' ) ) (this_SEMICOLON_32= RULE_SEMICOLON this_EOLINE_33= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,50,FOLLOW_21); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getMSGVariablesAccess().getMsgKeyword_0());
              		
            }
            this_DOT_1=(Token)match(input,RULE_DOT,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_DOT_1, grammarAccess.getMSGVariablesAccess().getDOTTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:722:3: ( ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'data' ) | ( (otherlv_8= 'value' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'value' ) | ( (otherlv_14= 'gas' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'gas' ) | ( (otherlv_20= 'sender' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sender' ) | ( (otherlv_26= 'sig' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyBytes_28= rulePropertyBytes | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'sig' ) )
            int alt29=5;
            switch ( input.LA(1) ) {
            case 51:
                {
                alt29=1;
                }
                break;
            case 52:
                {
                alt29=2;
                }
                break;
            case 53:
                {
                alt29=3;
                }
                break;
            case 54:
                {
                alt29=4;
                }
                break;
            case 55:
                {
                alt29=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 29, 0, input);

                throw nvae;
            }

            switch (alt29) {
                case 1 :
                    // InternalSM2.g:723:4: ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'data' )
                    {
                    // InternalSM2.g:723:4: ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'data' )
                    int alt20=2;
                    alt20 = dfa20.predict(input);
                    switch (alt20) {
                        case 1 :
                            // InternalSM2.g:724:5: (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:724:5: (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:725:6: otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_2=(Token)match(input,51,FOLLOW_23); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_2, grammarAccess.getMSGVariablesAccess().getDataKeyword_2_0_0_0());
                              					
                            }
                            this_OPENPARENTHESIS_3=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_24); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_3, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_0_0_1());
                              					
                            }
                            // InternalSM2.g:733:6: (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression )
                            int alt19=2;
                            int LA19_0 = input.LA(1);

                            if ( ((LA19_0>=102 && LA19_0<=111)) ) {
                                alt19=1;
                            }
                            else if ( (LA19_0==RULE_STRING||(LA19_0>=RULE_INTEGER && LA19_0<=RULE_FLOAT)) ) {
                                alt19=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 19, 0, input);

                                throw nvae;
                            }
                            switch (alt19) {
                                case 1 :
                                    // InternalSM2.g:734:7: this_PropertyBytes_4= rulePropertyBytes
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyBytesParserRuleCall_2_0_0_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_25);
                                    this_PropertyBytes_4=rulePropertyBytes();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyBytes_4;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:743:7: this_SyntaxExpression_5= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_0_0_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_25);
                                    this_SyntaxExpression_5=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_5;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_0_0_3());
                              					
                            }

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:758:5: otherlv_7= 'data'
                            {
                            otherlv_7=(Token)match(input,51,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_7, grammarAccess.getMSGVariablesAccess().getDataKeyword_2_0_1());
                              				
                            }

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:764:4: ( (otherlv_8= 'value' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'value' )
                    {
                    // InternalSM2.g:764:4: ( (otherlv_8= 'value' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'value' )
                    int alt22=2;
                    alt22 = dfa22.predict(input);
                    switch (alt22) {
                        case 1 :
                            // InternalSM2.g:765:5: (otherlv_8= 'value' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:765:5: (otherlv_8= 'value' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:766:6: otherlv_8= 'value' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_8=(Token)match(input,52,FOLLOW_23); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_8, grammarAccess.getMSGVariablesAccess().getValueKeyword_2_1_0_0());
                              					
                            }
                            this_OPENPARENTHESIS_9=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_27); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_9, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_1_0_1());
                              					
                            }
                            // InternalSM2.g:774:6: (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression )
                            int alt21=2;
                            int LA21_0 = input.LA(1);

                            if ( ((LA21_0>=88 && LA21_0<=99)) ) {
                                alt21=1;
                            }
                            else if ( (LA21_0==RULE_STRING||(LA21_0>=RULE_INTEGER && LA21_0<=RULE_FLOAT)) ) {
                                alt21=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 21, 0, input);

                                throw nvae;
                            }
                            switch (alt21) {
                                case 1 :
                                    // InternalSM2.g:775:7: this_PropertyInteger_10= rulePropertyInteger
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyIntegerParserRuleCall_2_1_0_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_25);
                                    this_PropertyInteger_10=rulePropertyInteger();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyInteger_10;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:784:7: this_SyntaxExpression_11= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_1_0_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_25);
                                    this_SyntaxExpression_11=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_11;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_12=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_12, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_1_0_3());
                              					
                            }

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:799:5: otherlv_13= 'value'
                            {
                            otherlv_13=(Token)match(input,52,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_13, grammarAccess.getMSGVariablesAccess().getValueKeyword_2_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:805:4: ( (otherlv_14= 'gas' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'gas' )
                    {
                    // InternalSM2.g:805:4: ( (otherlv_14= 'gas' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'gas' )
                    int alt24=2;
                    alt24 = dfa24.predict(input);
                    switch (alt24) {
                        case 1 :
                            // InternalSM2.g:806:5: (otherlv_14= 'gas' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:806:5: (otherlv_14= 'gas' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:807:6: otherlv_14= 'gas' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_14=(Token)match(input,53,FOLLOW_23); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_14, grammarAccess.getMSGVariablesAccess().getGasKeyword_2_2_0_0());
                              					
                            }
                            this_OPENPARENTHESIS_15=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_27); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_15, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_2_0_1());
                              					
                            }
                            // InternalSM2.g:815:6: (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression )
                            int alt23=2;
                            int LA23_0 = input.LA(1);

                            if ( ((LA23_0>=88 && LA23_0<=99)) ) {
                                alt23=1;
                            }
                            else if ( (LA23_0==RULE_STRING||(LA23_0>=RULE_INTEGER && LA23_0<=RULE_FLOAT)) ) {
                                alt23=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 23, 0, input);

                                throw nvae;
                            }
                            switch (alt23) {
                                case 1 :
                                    // InternalSM2.g:816:7: this_PropertyInteger_16= rulePropertyInteger
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyIntegerParserRuleCall_2_2_0_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_25);
                                    this_PropertyInteger_16=rulePropertyInteger();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyInteger_16;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:825:7: this_SyntaxExpression_17= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_2_0_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_25);
                                    this_SyntaxExpression_17=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_17;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_18=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_18, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_2_0_3());
                              					
                            }

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:840:5: otherlv_19= 'gas'
                            {
                            otherlv_19=(Token)match(input,53,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_19, grammarAccess.getMSGVariablesAccess().getGasKeyword_2_2_1());
                              				
                            }

                            }
                            break;

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:846:4: ( (otherlv_20= 'sender' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sender' )
                    {
                    // InternalSM2.g:846:4: ( (otherlv_20= 'sender' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sender' )
                    int alt26=2;
                    alt26 = dfa26.predict(input);
                    switch (alt26) {
                        case 1 :
                            // InternalSM2.g:847:5: (otherlv_20= 'sender' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:847:5: (otherlv_20= 'sender' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:848:6: otherlv_20= 'sender' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_20=(Token)match(input,54,FOLLOW_23); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_20, grammarAccess.getMSGVariablesAccess().getSenderKeyword_2_3_0_0());
                              					
                            }
                            this_OPENPARENTHESIS_21=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_28); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_21, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_3_0_1());
                              					
                            }
                            // InternalSM2.g:856:6: (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression )
                            int alt25=2;
                            int LA25_0 = input.LA(1);

                            if ( (LA25_0==77||LA25_0==101) ) {
                                alt25=1;
                            }
                            else if ( (LA25_0==RULE_STRING||(LA25_0>=RULE_INTEGER && LA25_0<=RULE_FLOAT)) ) {
                                alt25=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 25, 0, input);

                                throw nvae;
                            }
                            switch (alt25) {
                                case 1 :
                                    // InternalSM2.g:857:7: this_PropertyAddress_22= rulePropertyAddress
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyAddressParserRuleCall_2_3_0_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_25);
                                    this_PropertyAddress_22=rulePropertyAddress();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyAddress_22;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:866:7: this_SyntaxExpression_23= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_3_0_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_25);
                                    this_SyntaxExpression_23=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_23;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_24=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_24, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_3_0_3());
                              					
                            }

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:881:5: otherlv_25= 'sender'
                            {
                            otherlv_25=(Token)match(input,54,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_25, grammarAccess.getMSGVariablesAccess().getSenderKeyword_2_3_1());
                              				
                            }

                            }
                            break;

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:887:4: ( (otherlv_26= 'sig' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyBytes_28= rulePropertyBytes | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'sig' )
                    {
                    // InternalSM2.g:887:4: ( (otherlv_26= 'sig' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyBytes_28= rulePropertyBytes | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'sig' )
                    int alt28=2;
                    alt28 = dfa28.predict(input);
                    switch (alt28) {
                        case 1 :
                            // InternalSM2.g:888:5: (otherlv_26= 'sig' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyBytes_28= rulePropertyBytes | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:888:5: (otherlv_26= 'sig' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyBytes_28= rulePropertyBytes | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:889:6: otherlv_26= 'sig' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyBytes_28= rulePropertyBytes | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_26=(Token)match(input,55,FOLLOW_23); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_26, grammarAccess.getMSGVariablesAccess().getSigKeyword_2_4_0_0());
                              					
                            }
                            this_OPENPARENTHESIS_27=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_24); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_27, grammarAccess.getMSGVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_4_0_1());
                              					
                            }
                            // InternalSM2.g:897:6: (this_PropertyBytes_28= rulePropertyBytes | this_SyntaxExpression_29= ruleSyntaxExpression )
                            int alt27=2;
                            int LA27_0 = input.LA(1);

                            if ( ((LA27_0>=102 && LA27_0<=111)) ) {
                                alt27=1;
                            }
                            else if ( (LA27_0==RULE_STRING||(LA27_0>=RULE_INTEGER && LA27_0<=RULE_FLOAT)) ) {
                                alt27=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 27, 0, input);

                                throw nvae;
                            }
                            switch (alt27) {
                                case 1 :
                                    // InternalSM2.g:898:7: this_PropertyBytes_28= rulePropertyBytes
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getMSGVariablesAccess().getPropertyBytesParserRuleCall_2_4_0_2_0());
                                      						
                                    }
                                    pushFollow(FOLLOW_25);
                                    this_PropertyBytes_28=rulePropertyBytes();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_PropertyBytes_28;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:907:7: this_SyntaxExpression_29= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      							newCompositeNode(grammarAccess.getMSGVariablesAccess().getSyntaxExpressionParserRuleCall_2_4_0_2_1());
                                      						
                                    }
                                    pushFollow(FOLLOW_25);
                                    this_SyntaxExpression_29=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							current = this_SyntaxExpression_29;
                                      							afterParserOrEnumRuleCall();
                                      						
                                    }

                                    }
                                    break;

                            }

                            this_CLOSEPARENTHESIS_30=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_30, grammarAccess.getMSGVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_4_0_3());
                              					
                            }

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:922:5: otherlv_31= 'sig'
                            {
                            otherlv_31=(Token)match(input,55,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_31, grammarAccess.getMSGVariablesAccess().getSigKeyword_2_4_1());
                              				
                            }

                            }
                            break;

                    }


                    }
                    break;

            }

            // InternalSM2.g:928:3: (this_SEMICOLON_32= RULE_SEMICOLON this_EOLINE_33= RULE_EOLINE )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==RULE_SEMICOLON) ) {
                int LA30_1 = input.LA(2);

                if ( (LA30_1==RULE_EOLINE) ) {
                    int LA30_3 = input.LA(3);

                    if ( (LA30_3==EOF||(LA30_3>=RULE_ID && LA30_3<=RULE_CLOSEKEY)||(LA30_3>=RULE_OPENPARENTHESIS && LA30_3<=RULE_STRING)||(LA30_3>=RULE_INTEGER && LA30_3<=RULE_SINGLENUMBER)||LA30_3==RULE_RETURN||(LA30_3>=RULE_NEW && LA30_3<=RULE_BREAK)||LA30_3==50||LA30_3==56||(LA30_3>=63 && LA30_3<=64)||LA30_3==73||(LA30_3>=77 && LA30_3<=78)||(LA30_3>=88 && LA30_3<=101)||(LA30_3>=103 && LA30_3<=111)||(LA30_3>=148 && LA30_3<=149)) ) {
                        alt30=1;
                    }
                }
            }
            switch (alt30) {
                case 1 :
                    // InternalSM2.g:929:4: this_SEMICOLON_32= RULE_SEMICOLON this_EOLINE_33= RULE_EOLINE
                    {
                    this_SEMICOLON_32=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_32, grammarAccess.getMSGVariablesAccess().getSEMICOLONTerminalRuleCall_3_0());
                      			
                    }
                    this_EOLINE_33=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_33, grammarAccess.getMSGVariablesAccess().getEOLINETerminalRuleCall_3_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMSGVariables"


    // $ANTLR start "entryRuleBlockVariables"
    // InternalSM2.g:942:1: entryRuleBlockVariables returns [EObject current=null] : iv_ruleBlockVariables= ruleBlockVariables EOF ;
    public final EObject entryRuleBlockVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBlockVariables = null;


        try {
            // InternalSM2.g:942:55: (iv_ruleBlockVariables= ruleBlockVariables EOF )
            // InternalSM2.g:943:2: iv_ruleBlockVariables= ruleBlockVariables EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getBlockVariablesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleBlockVariables=ruleBlockVariables();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleBlockVariables; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBlockVariables"


    // $ANTLR start "ruleBlockVariables"
    // InternalSM2.g:949:1: ruleBlockVariables returns [EObject current=null] : ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'difficulty' ) | ( (otherlv_8= 'number' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'number' ) | ( (otherlv_14= 'timestamp' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'timestamp' ) | ( (otherlv_20= 'coinbase' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'coinbase' ) | ( (otherlv_26= 'gaslimit' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'gaslimit' ) | ( (otherlv_32= 'blockhash' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS ) | otherlv_37= 'blockhash' ) ) ) | (otherlv_38= 'now' this_OPENPARENTHESIS_39= RULE_OPENPARENTHESIS (this_PropertyInteger_40= rulePropertyInteger | this_SyntaxExpression_41= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_42= RULE_CLOSEPARENTHESIS (this_SEMICOLON_43= RULE_SEMICOLON )? ) ) ;
    public final EObject ruleBlockVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_DOT_1=null;
        Token otherlv_2=null;
        Token this_OPENPARENTHESIS_3=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token this_OPENPARENTHESIS_9=null;
        Token this_CLOSEPARENTHESIS_12=null;
        Token otherlv_13=null;
        Token otherlv_14=null;
        Token this_OPENPARENTHESIS_15=null;
        Token this_CLOSEPARENTHESIS_18=null;
        Token otherlv_19=null;
        Token otherlv_20=null;
        Token this_OPENPARENTHESIS_21=null;
        Token this_CLOSEPARENTHESIS_24=null;
        Token otherlv_25=null;
        Token otherlv_26=null;
        Token this_OPENPARENTHESIS_27=null;
        Token this_CLOSEPARENTHESIS_30=null;
        Token otherlv_31=null;
        Token otherlv_32=null;
        Token this_OPENPARENTHESIS_33=null;
        Token this_CLOSEPARENTHESIS_36=null;
        Token otherlv_37=null;
        Token otherlv_38=null;
        Token this_OPENPARENTHESIS_39=null;
        Token this_CLOSEPARENTHESIS_42=null;
        Token this_SEMICOLON_43=null;
        EObject this_PropertyInteger_4 = null;

        EObject this_SyntaxExpression_5 = null;

        EObject this_PropertyInteger_10 = null;

        EObject this_SyntaxExpression_11 = null;

        EObject this_PropertyInteger_16 = null;

        EObject this_SyntaxExpression_17 = null;

        EObject this_PropertyAddress_22 = null;

        EObject this_SyntaxExpression_23 = null;

        EObject this_PropertyInteger_28 = null;

        EObject this_SyntaxExpression_29 = null;

        EObject this_PropertyInteger_34 = null;

        EObject this_SyntaxExpression_35 = null;

        EObject this_PropertyInteger_40 = null;

        EObject this_SyntaxExpression_41 = null;



        	enterRule();

        try {
            // InternalSM2.g:955:2: ( ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'difficulty' ) | ( (otherlv_8= 'number' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'number' ) | ( (otherlv_14= 'timestamp' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'timestamp' ) | ( (otherlv_20= 'coinbase' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'coinbase' ) | ( (otherlv_26= 'gaslimit' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'gaslimit' ) | ( (otherlv_32= 'blockhash' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS ) | otherlv_37= 'blockhash' ) ) ) | (otherlv_38= 'now' this_OPENPARENTHESIS_39= RULE_OPENPARENTHESIS (this_PropertyInteger_40= rulePropertyInteger | this_SyntaxExpression_41= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_42= RULE_CLOSEPARENTHESIS (this_SEMICOLON_43= RULE_SEMICOLON )? ) ) )
            // InternalSM2.g:956:2: ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'difficulty' ) | ( (otherlv_8= 'number' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'number' ) | ( (otherlv_14= 'timestamp' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'timestamp' ) | ( (otherlv_20= 'coinbase' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'coinbase' ) | ( (otherlv_26= 'gaslimit' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'gaslimit' ) | ( (otherlv_32= 'blockhash' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS ) | otherlv_37= 'blockhash' ) ) ) | (otherlv_38= 'now' this_OPENPARENTHESIS_39= RULE_OPENPARENTHESIS (this_PropertyInteger_40= rulePropertyInteger | this_SyntaxExpression_41= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_42= RULE_CLOSEPARENTHESIS (this_SEMICOLON_43= RULE_SEMICOLON )? ) )
            {
            // InternalSM2.g:956:2: ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'difficulty' ) | ( (otherlv_8= 'number' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'number' ) | ( (otherlv_14= 'timestamp' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'timestamp' ) | ( (otherlv_20= 'coinbase' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'coinbase' ) | ( (otherlv_26= 'gaslimit' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'gaslimit' ) | ( (otherlv_32= 'blockhash' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS ) | otherlv_37= 'blockhash' ) ) ) | (otherlv_38= 'now' this_OPENPARENTHESIS_39= RULE_OPENPARENTHESIS (this_PropertyInteger_40= rulePropertyInteger | this_SyntaxExpression_41= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_42= RULE_CLOSEPARENTHESIS (this_SEMICOLON_43= RULE_SEMICOLON )? ) )
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==56) ) {
                alt46=1;
            }
            else if ( (LA46_0==63) ) {
                alt46=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 46, 0, input);

                throw nvae;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:957:3: (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'difficulty' ) | ( (otherlv_8= 'number' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'number' ) | ( (otherlv_14= 'timestamp' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'timestamp' ) | ( (otherlv_20= 'coinbase' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'coinbase' ) | ( (otherlv_26= 'gaslimit' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'gaslimit' ) | ( (otherlv_32= 'blockhash' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS ) | otherlv_37= 'blockhash' ) ) )
                    {
                    // InternalSM2.g:957:3: (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'difficulty' ) | ( (otherlv_8= 'number' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'number' ) | ( (otherlv_14= 'timestamp' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'timestamp' ) | ( (otherlv_20= 'coinbase' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'coinbase' ) | ( (otherlv_26= 'gaslimit' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'gaslimit' ) | ( (otherlv_32= 'blockhash' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS ) | otherlv_37= 'blockhash' ) ) )
                    // InternalSM2.g:958:4: otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'difficulty' ) | ( (otherlv_8= 'number' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'number' ) | ( (otherlv_14= 'timestamp' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'timestamp' ) | ( (otherlv_20= 'coinbase' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'coinbase' ) | ( (otherlv_26= 'gaslimit' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'gaslimit' ) | ( (otherlv_32= 'blockhash' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS ) | otherlv_37= 'blockhash' ) )
                    {
                    otherlv_0=(Token)match(input,56,FOLLOW_21); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_0, grammarAccess.getBlockVariablesAccess().getBlockKeyword_0_0());
                      			
                    }
                    this_DOT_1=(Token)match(input,RULE_DOT,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_1, grammarAccess.getBlockVariablesAccess().getDOTTerminalRuleCall_0_1());
                      			
                    }
                    // InternalSM2.g:966:4: ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'difficulty' ) | ( (otherlv_8= 'number' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'number' ) | ( (otherlv_14= 'timestamp' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'timestamp' ) | ( (otherlv_20= 'coinbase' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'coinbase' ) | ( (otherlv_26= 'gaslimit' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'gaslimit' ) | ( (otherlv_32= 'blockhash' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS ) | otherlv_37= 'blockhash' ) )
                    int alt43=6;
                    switch ( input.LA(1) ) {
                    case 57:
                        {
                        alt43=1;
                        }
                        break;
                    case 58:
                        {
                        alt43=2;
                        }
                        break;
                    case 59:
                        {
                        alt43=3;
                        }
                        break;
                    case 60:
                        {
                        alt43=4;
                        }
                        break;
                    case 61:
                        {
                        alt43=5;
                        }
                        break;
                    case 62:
                        {
                        alt43=6;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 43, 0, input);

                        throw nvae;
                    }

                    switch (alt43) {
                        case 1 :
                            // InternalSM2.g:967:5: ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'difficulty' )
                            {
                            // InternalSM2.g:967:5: ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'difficulty' )
                            int alt32=2;
                            alt32 = dfa32.predict(input);
                            switch (alt32) {
                                case 1 :
                                    // InternalSM2.g:968:6: (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:968:6: (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:969:7: otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_2=(Token)match(input,57,FOLLOW_23); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(otherlv_2, grammarAccess.getBlockVariablesAccess().getDifficultyKeyword_0_2_0_0_0());
                                      						
                                    }
                                    this_OPENPARENTHESIS_3=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_27); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(this_OPENPARENTHESIS_3, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_0_0_1());
                                      						
                                    }
                                    // InternalSM2.g:977:7: (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression )
                                    int alt31=2;
                                    int LA31_0 = input.LA(1);

                                    if ( ((LA31_0>=88 && LA31_0<=99)) ) {
                                        alt31=1;
                                    }
                                    else if ( (LA31_0==RULE_STRING||(LA31_0>=RULE_INTEGER && LA31_0<=RULE_FLOAT)) ) {
                                        alt31=2;
                                    }
                                    else {
                                        if (state.backtracking>0) {state.failed=true; return current;}
                                        NoViableAltException nvae =
                                            new NoViableAltException("", 31, 0, input);

                                        throw nvae;
                                    }
                                    switch (alt31) {
                                        case 1 :
                                            // InternalSM2.g:978:8: this_PropertyInteger_4= rulePropertyInteger
                                            {
                                            if ( state.backtracking==0 ) {

                                              								newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_0_0_2_0());
                                              							
                                            }
                                            pushFollow(FOLLOW_25);
                                            this_PropertyInteger_4=rulePropertyInteger();

                                            state._fsp--;
                                            if (state.failed) return current;
                                            if ( state.backtracking==0 ) {

                                              								current = this_PropertyInteger_4;
                                              								afterParserOrEnumRuleCall();
                                              							
                                            }

                                            }
                                            break;
                                        case 2 :
                                            // InternalSM2.g:987:8: this_SyntaxExpression_5= ruleSyntaxExpression
                                            {
                                            if ( state.backtracking==0 ) {

                                              								newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_0_0_2_1());
                                              							
                                            }
                                            pushFollow(FOLLOW_25);
                                            this_SyntaxExpression_5=ruleSyntaxExpression();

                                            state._fsp--;
                                            if (state.failed) return current;
                                            if ( state.backtracking==0 ) {

                                              								current = this_SyntaxExpression_5;
                                              								afterParserOrEnumRuleCall();
                                              							
                                            }

                                            }
                                            break;

                                    }

                                    this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_0_0_3());
                                      						
                                    }

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1002:6: otherlv_7= 'difficulty'
                                    {
                                    otherlv_7=(Token)match(input,57,FOLLOW_2); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      						newLeafNode(otherlv_7, grammarAccess.getBlockVariablesAccess().getDifficultyKeyword_0_2_0_1());
                                      					
                                    }

                                    }
                                    break;

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:1008:5: ( (otherlv_8= 'number' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'number' )
                            {
                            // InternalSM2.g:1008:5: ( (otherlv_8= 'number' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'number' )
                            int alt34=2;
                            alt34 = dfa34.predict(input);
                            switch (alt34) {
                                case 1 :
                                    // InternalSM2.g:1009:6: (otherlv_8= 'number' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:1009:6: (otherlv_8= 'number' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:1010:7: otherlv_8= 'number' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_8=(Token)match(input,58,FOLLOW_23); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(otherlv_8, grammarAccess.getBlockVariablesAccess().getNumberKeyword_0_2_1_0_0());
                                      						
                                    }
                                    this_OPENPARENTHESIS_9=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_27); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(this_OPENPARENTHESIS_9, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_1_0_1());
                                      						
                                    }
                                    // InternalSM2.g:1018:7: (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression )
                                    int alt33=2;
                                    int LA33_0 = input.LA(1);

                                    if ( ((LA33_0>=88 && LA33_0<=99)) ) {
                                        alt33=1;
                                    }
                                    else if ( (LA33_0==RULE_STRING||(LA33_0>=RULE_INTEGER && LA33_0<=RULE_FLOAT)) ) {
                                        alt33=2;
                                    }
                                    else {
                                        if (state.backtracking>0) {state.failed=true; return current;}
                                        NoViableAltException nvae =
                                            new NoViableAltException("", 33, 0, input);

                                        throw nvae;
                                    }
                                    switch (alt33) {
                                        case 1 :
                                            // InternalSM2.g:1019:8: this_PropertyInteger_10= rulePropertyInteger
                                            {
                                            if ( state.backtracking==0 ) {

                                              								newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_1_0_2_0());
                                              							
                                            }
                                            pushFollow(FOLLOW_25);
                                            this_PropertyInteger_10=rulePropertyInteger();

                                            state._fsp--;
                                            if (state.failed) return current;
                                            if ( state.backtracking==0 ) {

                                              								current = this_PropertyInteger_10;
                                              								afterParserOrEnumRuleCall();
                                              							
                                            }

                                            }
                                            break;
                                        case 2 :
                                            // InternalSM2.g:1028:8: this_SyntaxExpression_11= ruleSyntaxExpression
                                            {
                                            if ( state.backtracking==0 ) {

                                              								newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_1_0_2_1());
                                              							
                                            }
                                            pushFollow(FOLLOW_25);
                                            this_SyntaxExpression_11=ruleSyntaxExpression();

                                            state._fsp--;
                                            if (state.failed) return current;
                                            if ( state.backtracking==0 ) {

                                              								current = this_SyntaxExpression_11;
                                              								afterParserOrEnumRuleCall();
                                              							
                                            }

                                            }
                                            break;

                                    }

                                    this_CLOSEPARENTHESIS_12=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(this_CLOSEPARENTHESIS_12, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_1_0_3());
                                      						
                                    }

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1043:6: otherlv_13= 'number'
                                    {
                                    otherlv_13=(Token)match(input,58,FOLLOW_2); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      						newLeafNode(otherlv_13, grammarAccess.getBlockVariablesAccess().getNumberKeyword_0_2_1_1());
                                      					
                                    }

                                    }
                                    break;

                            }


                            }
                            break;
                        case 3 :
                            // InternalSM2.g:1049:5: ( (otherlv_14= 'timestamp' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'timestamp' )
                            {
                            // InternalSM2.g:1049:5: ( (otherlv_14= 'timestamp' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'timestamp' )
                            int alt36=2;
                            alt36 = dfa36.predict(input);
                            switch (alt36) {
                                case 1 :
                                    // InternalSM2.g:1050:6: (otherlv_14= 'timestamp' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:1050:6: (otherlv_14= 'timestamp' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:1051:7: otherlv_14= 'timestamp' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_14=(Token)match(input,59,FOLLOW_23); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(otherlv_14, grammarAccess.getBlockVariablesAccess().getTimestampKeyword_0_2_2_0_0());
                                      						
                                    }
                                    this_OPENPARENTHESIS_15=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_27); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(this_OPENPARENTHESIS_15, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_2_0_1());
                                      						
                                    }
                                    // InternalSM2.g:1059:7: (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression )
                                    int alt35=2;
                                    int LA35_0 = input.LA(1);

                                    if ( ((LA35_0>=88 && LA35_0<=99)) ) {
                                        alt35=1;
                                    }
                                    else if ( (LA35_0==RULE_STRING||(LA35_0>=RULE_INTEGER && LA35_0<=RULE_FLOAT)) ) {
                                        alt35=2;
                                    }
                                    else {
                                        if (state.backtracking>0) {state.failed=true; return current;}
                                        NoViableAltException nvae =
                                            new NoViableAltException("", 35, 0, input);

                                        throw nvae;
                                    }
                                    switch (alt35) {
                                        case 1 :
                                            // InternalSM2.g:1060:8: this_PropertyInteger_16= rulePropertyInteger
                                            {
                                            if ( state.backtracking==0 ) {

                                              								newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_2_0_2_0());
                                              							
                                            }
                                            pushFollow(FOLLOW_25);
                                            this_PropertyInteger_16=rulePropertyInteger();

                                            state._fsp--;
                                            if (state.failed) return current;
                                            if ( state.backtracking==0 ) {

                                              								current = this_PropertyInteger_16;
                                              								afterParserOrEnumRuleCall();
                                              							
                                            }

                                            }
                                            break;
                                        case 2 :
                                            // InternalSM2.g:1069:8: this_SyntaxExpression_17= ruleSyntaxExpression
                                            {
                                            if ( state.backtracking==0 ) {

                                              								newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_2_0_2_1());
                                              							
                                            }
                                            pushFollow(FOLLOW_25);
                                            this_SyntaxExpression_17=ruleSyntaxExpression();

                                            state._fsp--;
                                            if (state.failed) return current;
                                            if ( state.backtracking==0 ) {

                                              								current = this_SyntaxExpression_17;
                                              								afterParserOrEnumRuleCall();
                                              							
                                            }

                                            }
                                            break;

                                    }

                                    this_CLOSEPARENTHESIS_18=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(this_CLOSEPARENTHESIS_18, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_2_0_3());
                                      						
                                    }

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1084:6: otherlv_19= 'timestamp'
                                    {
                                    otherlv_19=(Token)match(input,59,FOLLOW_2); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      						newLeafNode(otherlv_19, grammarAccess.getBlockVariablesAccess().getTimestampKeyword_0_2_2_1());
                                      					
                                    }

                                    }
                                    break;

                            }


                            }
                            break;
                        case 4 :
                            // InternalSM2.g:1090:5: ( (otherlv_20= 'coinbase' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'coinbase' )
                            {
                            // InternalSM2.g:1090:5: ( (otherlv_20= 'coinbase' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'coinbase' )
                            int alt38=2;
                            alt38 = dfa38.predict(input);
                            switch (alt38) {
                                case 1 :
                                    // InternalSM2.g:1091:6: (otherlv_20= 'coinbase' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:1091:6: (otherlv_20= 'coinbase' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:1092:7: otherlv_20= 'coinbase' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_20=(Token)match(input,60,FOLLOW_23); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(otherlv_20, grammarAccess.getBlockVariablesAccess().getCoinbaseKeyword_0_2_3_0_0());
                                      						
                                    }
                                    this_OPENPARENTHESIS_21=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_28); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(this_OPENPARENTHESIS_21, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_3_0_1());
                                      						
                                    }
                                    // InternalSM2.g:1100:7: (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression )
                                    int alt37=2;
                                    int LA37_0 = input.LA(1);

                                    if ( (LA37_0==77||LA37_0==101) ) {
                                        alt37=1;
                                    }
                                    else if ( (LA37_0==RULE_STRING||(LA37_0>=RULE_INTEGER && LA37_0<=RULE_FLOAT)) ) {
                                        alt37=2;
                                    }
                                    else {
                                        if (state.backtracking>0) {state.failed=true; return current;}
                                        NoViableAltException nvae =
                                            new NoViableAltException("", 37, 0, input);

                                        throw nvae;
                                    }
                                    switch (alt37) {
                                        case 1 :
                                            // InternalSM2.g:1101:8: this_PropertyAddress_22= rulePropertyAddress
                                            {
                                            if ( state.backtracking==0 ) {

                                              								newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyAddressParserRuleCall_0_2_3_0_2_0());
                                              							
                                            }
                                            pushFollow(FOLLOW_25);
                                            this_PropertyAddress_22=rulePropertyAddress();

                                            state._fsp--;
                                            if (state.failed) return current;
                                            if ( state.backtracking==0 ) {

                                              								current = this_PropertyAddress_22;
                                              								afterParserOrEnumRuleCall();
                                              							
                                            }

                                            }
                                            break;
                                        case 2 :
                                            // InternalSM2.g:1110:8: this_SyntaxExpression_23= ruleSyntaxExpression
                                            {
                                            if ( state.backtracking==0 ) {

                                              								newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_3_0_2_1());
                                              							
                                            }
                                            pushFollow(FOLLOW_25);
                                            this_SyntaxExpression_23=ruleSyntaxExpression();

                                            state._fsp--;
                                            if (state.failed) return current;
                                            if ( state.backtracking==0 ) {

                                              								current = this_SyntaxExpression_23;
                                              								afterParserOrEnumRuleCall();
                                              							
                                            }

                                            }
                                            break;

                                    }

                                    this_CLOSEPARENTHESIS_24=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(this_CLOSEPARENTHESIS_24, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_3_0_3());
                                      						
                                    }

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1125:6: otherlv_25= 'coinbase'
                                    {
                                    otherlv_25=(Token)match(input,60,FOLLOW_2); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      						newLeafNode(otherlv_25, grammarAccess.getBlockVariablesAccess().getCoinbaseKeyword_0_2_3_1());
                                      					
                                    }

                                    }
                                    break;

                            }


                            }
                            break;
                        case 5 :
                            // InternalSM2.g:1131:5: ( (otherlv_26= 'gaslimit' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'gaslimit' )
                            {
                            // InternalSM2.g:1131:5: ( (otherlv_26= 'gaslimit' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'gaslimit' )
                            int alt40=2;
                            alt40 = dfa40.predict(input);
                            switch (alt40) {
                                case 1 :
                                    // InternalSM2.g:1132:6: (otherlv_26= 'gaslimit' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:1132:6: (otherlv_26= 'gaslimit' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:1133:7: otherlv_26= 'gaslimit' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_26=(Token)match(input,61,FOLLOW_23); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(otherlv_26, grammarAccess.getBlockVariablesAccess().getGaslimitKeyword_0_2_4_0_0());
                                      						
                                    }
                                    this_OPENPARENTHESIS_27=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_27); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(this_OPENPARENTHESIS_27, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_4_0_1());
                                      						
                                    }
                                    // InternalSM2.g:1141:7: (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression )
                                    int alt39=2;
                                    int LA39_0 = input.LA(1);

                                    if ( ((LA39_0>=88 && LA39_0<=99)) ) {
                                        alt39=1;
                                    }
                                    else if ( (LA39_0==RULE_STRING||(LA39_0>=RULE_INTEGER && LA39_0<=RULE_FLOAT)) ) {
                                        alt39=2;
                                    }
                                    else {
                                        if (state.backtracking>0) {state.failed=true; return current;}
                                        NoViableAltException nvae =
                                            new NoViableAltException("", 39, 0, input);

                                        throw nvae;
                                    }
                                    switch (alt39) {
                                        case 1 :
                                            // InternalSM2.g:1142:8: this_PropertyInteger_28= rulePropertyInteger
                                            {
                                            if ( state.backtracking==0 ) {

                                              								newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_4_0_2_0());
                                              							
                                            }
                                            pushFollow(FOLLOW_25);
                                            this_PropertyInteger_28=rulePropertyInteger();

                                            state._fsp--;
                                            if (state.failed) return current;
                                            if ( state.backtracking==0 ) {

                                              								current = this_PropertyInteger_28;
                                              								afterParserOrEnumRuleCall();
                                              							
                                            }

                                            }
                                            break;
                                        case 2 :
                                            // InternalSM2.g:1151:8: this_SyntaxExpression_29= ruleSyntaxExpression
                                            {
                                            if ( state.backtracking==0 ) {

                                              								newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_4_0_2_1());
                                              							
                                            }
                                            pushFollow(FOLLOW_25);
                                            this_SyntaxExpression_29=ruleSyntaxExpression();

                                            state._fsp--;
                                            if (state.failed) return current;
                                            if ( state.backtracking==0 ) {

                                              								current = this_SyntaxExpression_29;
                                              								afterParserOrEnumRuleCall();
                                              							
                                            }

                                            }
                                            break;

                                    }

                                    this_CLOSEPARENTHESIS_30=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(this_CLOSEPARENTHESIS_30, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_4_0_3());
                                      						
                                    }

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1166:6: otherlv_31= 'gaslimit'
                                    {
                                    otherlv_31=(Token)match(input,61,FOLLOW_2); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      						newLeafNode(otherlv_31, grammarAccess.getBlockVariablesAccess().getGaslimitKeyword_0_2_4_1());
                                      					
                                    }

                                    }
                                    break;

                            }


                            }
                            break;
                        case 6 :
                            // InternalSM2.g:1172:5: ( (otherlv_32= 'blockhash' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS ) | otherlv_37= 'blockhash' )
                            {
                            // InternalSM2.g:1172:5: ( (otherlv_32= 'blockhash' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS ) | otherlv_37= 'blockhash' )
                            int alt42=2;
                            alt42 = dfa42.predict(input);
                            switch (alt42) {
                                case 1 :
                                    // InternalSM2.g:1173:6: (otherlv_32= 'blockhash' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:1173:6: (otherlv_32= 'blockhash' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:1174:7: otherlv_32= 'blockhash' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_32=(Token)match(input,62,FOLLOW_23); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(otherlv_32, grammarAccess.getBlockVariablesAccess().getBlockhashKeyword_0_2_5_0_0());
                                      						
                                    }
                                    this_OPENPARENTHESIS_33=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_27); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(this_OPENPARENTHESIS_33, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_0_2_5_0_1());
                                      						
                                    }
                                    // InternalSM2.g:1182:7: (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression )
                                    int alt41=2;
                                    int LA41_0 = input.LA(1);

                                    if ( ((LA41_0>=88 && LA41_0<=99)) ) {
                                        alt41=1;
                                    }
                                    else if ( (LA41_0==RULE_STRING||(LA41_0>=RULE_INTEGER && LA41_0<=RULE_FLOAT)) ) {
                                        alt41=2;
                                    }
                                    else {
                                        if (state.backtracking>0) {state.failed=true; return current;}
                                        NoViableAltException nvae =
                                            new NoViableAltException("", 41, 0, input);

                                        throw nvae;
                                    }
                                    switch (alt41) {
                                        case 1 :
                                            // InternalSM2.g:1183:8: this_PropertyInteger_34= rulePropertyInteger
                                            {
                                            if ( state.backtracking==0 ) {

                                              								newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_0_2_5_0_2_0());
                                              							
                                            }
                                            pushFollow(FOLLOW_25);
                                            this_PropertyInteger_34=rulePropertyInteger();

                                            state._fsp--;
                                            if (state.failed) return current;
                                            if ( state.backtracking==0 ) {

                                              								current = this_PropertyInteger_34;
                                              								afterParserOrEnumRuleCall();
                                              							
                                            }

                                            }
                                            break;
                                        case 2 :
                                            // InternalSM2.g:1192:8: this_SyntaxExpression_35= ruleSyntaxExpression
                                            {
                                            if ( state.backtracking==0 ) {

                                              								newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_0_2_5_0_2_1());
                                              							
                                            }
                                            pushFollow(FOLLOW_25);
                                            this_SyntaxExpression_35=ruleSyntaxExpression();

                                            state._fsp--;
                                            if (state.failed) return current;
                                            if ( state.backtracking==0 ) {

                                              								current = this_SyntaxExpression_35;
                                              								afterParserOrEnumRuleCall();
                                              							
                                            }

                                            }
                                            break;

                                    }

                                    this_CLOSEPARENTHESIS_36=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      							newLeafNode(this_CLOSEPARENTHESIS_36, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_5_0_3());
                                      						
                                    }

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1207:6: otherlv_37= 'blockhash'
                                    {
                                    otherlv_37=(Token)match(input,62,FOLLOW_2); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      						newLeafNode(otherlv_37, grammarAccess.getBlockVariablesAccess().getBlockhashKeyword_0_2_5_1());
                                      					
                                    }

                                    }
                                    break;

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1215:3: (otherlv_38= 'now' this_OPENPARENTHESIS_39= RULE_OPENPARENTHESIS (this_PropertyInteger_40= rulePropertyInteger | this_SyntaxExpression_41= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_42= RULE_CLOSEPARENTHESIS (this_SEMICOLON_43= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:1215:3: (otherlv_38= 'now' this_OPENPARENTHESIS_39= RULE_OPENPARENTHESIS (this_PropertyInteger_40= rulePropertyInteger | this_SyntaxExpression_41= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_42= RULE_CLOSEPARENTHESIS (this_SEMICOLON_43= RULE_SEMICOLON )? )
                    // InternalSM2.g:1216:4: otherlv_38= 'now' this_OPENPARENTHESIS_39= RULE_OPENPARENTHESIS (this_PropertyInteger_40= rulePropertyInteger | this_SyntaxExpression_41= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_42= RULE_CLOSEPARENTHESIS (this_SEMICOLON_43= RULE_SEMICOLON )?
                    {
                    otherlv_38=(Token)match(input,63,FOLLOW_23); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_38, grammarAccess.getBlockVariablesAccess().getNowKeyword_1_0());
                      			
                    }
                    this_OPENPARENTHESIS_39=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_OPENPARENTHESIS_39, grammarAccess.getBlockVariablesAccess().getOPENPARENTHESISTerminalRuleCall_1_1());
                      			
                    }
                    // InternalSM2.g:1224:4: (this_PropertyInteger_40= rulePropertyInteger | this_SyntaxExpression_41= ruleSyntaxExpression )
                    int alt44=2;
                    int LA44_0 = input.LA(1);

                    if ( ((LA44_0>=88 && LA44_0<=99)) ) {
                        alt44=1;
                    }
                    else if ( (LA44_0==RULE_STRING||(LA44_0>=RULE_INTEGER && LA44_0<=RULE_FLOAT)) ) {
                        alt44=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 44, 0, input);

                        throw nvae;
                    }
                    switch (alt44) {
                        case 1 :
                            // InternalSM2.g:1225:5: this_PropertyInteger_40= rulePropertyInteger
                            {
                            if ( state.backtracking==0 ) {

                              					newCompositeNode(grammarAccess.getBlockVariablesAccess().getPropertyIntegerParserRuleCall_1_2_0());
                              				
                            }
                            pushFollow(FOLLOW_25);
                            this_PropertyInteger_40=rulePropertyInteger();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					current = this_PropertyInteger_40;
                              					afterParserOrEnumRuleCall();
                              				
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:1234:5: this_SyntaxExpression_41= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              					newCompositeNode(grammarAccess.getBlockVariablesAccess().getSyntaxExpressionParserRuleCall_1_2_1());
                              				
                            }
                            pushFollow(FOLLOW_25);
                            this_SyntaxExpression_41=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					current = this_SyntaxExpression_41;
                              					afterParserOrEnumRuleCall();
                              				
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_42=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_CLOSEPARENTHESIS_42, grammarAccess.getBlockVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3());
                      			
                    }
                    // InternalSM2.g:1247:4: (this_SEMICOLON_43= RULE_SEMICOLON )?
                    int alt45=2;
                    int LA45_0 = input.LA(1);

                    if ( (LA45_0==RULE_SEMICOLON) ) {
                        int LA45_1 = input.LA(2);

                        if ( (LA45_1==RULE_EOLINE) ) {
                            int LA45_3 = input.LA(3);

                            if ( ((LA45_3>=RULE_EOLINE && LA45_3<=RULE_CLOSEKEY)||LA45_3==RULE_RETURN||LA45_3==RULE_BREAK) ) {
                                alt45=1;
                            }
                        }
                        else if ( (LA45_1==EOF||(LA45_1>=RULE_ID && LA45_1<=RULE_SEMICOLON)||LA45_1==RULE_CLOSEKEY||(LA45_1>=RULE_OPENPARENTHESIS && LA45_1<=RULE_STRING)||(LA45_1>=RULE_INTEGER && LA45_1<=RULE_SINGLENUMBER)||LA45_1==RULE_RETURN||(LA45_1>=RULE_NEW && LA45_1<=RULE_BREAK)||LA45_1==50||LA45_1==56||(LA45_1>=63 && LA45_1<=64)||LA45_1==73||(LA45_1>=77 && LA45_1<=78)||(LA45_1>=88 && LA45_1<=101)||(LA45_1>=103 && LA45_1<=111)||(LA45_1>=148 && LA45_1<=149)) ) {
                            alt45=1;
                        }
                    }
                    switch (alt45) {
                        case 1 :
                            // InternalSM2.g:1248:5: this_SEMICOLON_43= RULE_SEMICOLON
                            {
                            this_SEMICOLON_43=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_43, grammarAccess.getBlockVariablesAccess().getSEMICOLONTerminalRuleCall_1_4());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBlockVariables"


    // $ANTLR start "entryRuleTxVariables"
    // InternalSM2.g:1258:1: entryRuleTxVariables returns [EObject current=null] : iv_ruleTxVariables= ruleTxVariables EOF ;
    public final EObject entryRuleTxVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTxVariables = null;


        try {
            // InternalSM2.g:1258:52: (iv_ruleTxVariables= ruleTxVariables EOF )
            // InternalSM2.g:1259:2: iv_ruleTxVariables= ruleTxVariables EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getTxVariablesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleTxVariables=ruleTxVariables();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleTxVariables; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTxVariables"


    // $ANTLR start "ruleTxVariables"
    // InternalSM2.g:1265:1: ruleTxVariables returns [EObject current=null] : (otherlv_0= 'tx' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ( ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'gasprice' ) | ( (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ( ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'origin' ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? ) ;
    public final EObject ruleTxVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_DOT_1=null;
        Token otherlv_2=null;
        Token this_OPENPARENTHESIS_3=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token this_OPENPARENTHESIS_8=null;
        Token this_CLOSEPARENTHESIS_10=null;
        Token otherlv_11=null;
        Token this_SEMICOLON_12=null;
        Token this_EOLINE_13=null;
        EObject lv_inputparam_4_1 = null;

        EObject lv_inputparam_4_2 = null;

        EObject lv_inputparam_9_1 = null;

        EObject lv_inputparam_9_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:1271:2: ( (otherlv_0= 'tx' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ( ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'gasprice' ) | ( (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ( ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'origin' ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? ) )
            // InternalSM2.g:1272:2: (otherlv_0= 'tx' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ( ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'gasprice' ) | ( (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ( ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'origin' ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? )
            {
            // InternalSM2.g:1272:2: (otherlv_0= 'tx' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ( ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'gasprice' ) | ( (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ( ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'origin' ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? )
            // InternalSM2.g:1273:3: otherlv_0= 'tx' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ( ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'gasprice' ) | ( (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ( ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'origin' ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,64,FOLLOW_21); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getTxVariablesAccess().getTxKeyword_0());
              		
            }
            this_DOT_1=(Token)match(input,RULE_DOT,FOLLOW_30); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_DOT_1, grammarAccess.getTxVariablesAccess().getDOTTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1281:3: ( ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ( ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'gasprice' ) | ( (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ( ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'origin' )
            int alt50=3;
            alt50 = dfa50.predict(input);
            switch (alt50) {
                case 1 :
                    // InternalSM2.g:1282:4: ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ( ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'gasprice' )
                    {
                    // InternalSM2.g:1282:4: ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ( ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'gasprice' )
                    int alt48=2;
                    alt48 = dfa48.predict(input);
                    switch (alt48) {
                        case 1 :
                            // InternalSM2.g:1283:5: (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ( ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:1283:5: (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ( ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:1284:6: otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ( ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_2=(Token)match(input,65,FOLLOW_23); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(otherlv_2, grammarAccess.getTxVariablesAccess().getGaspriceKeyword_2_0_0_0());
                              					
                            }
                            this_OPENPARENTHESIS_3=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_28); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_OPENPARENTHESIS_3, grammarAccess.getTxVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_0_0_1());
                              					
                            }
                            // InternalSM2.g:1292:6: ( ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) ) )
                            // InternalSM2.g:1293:7: ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) )
                            {
                            // InternalSM2.g:1293:7: ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) )
                            // InternalSM2.g:1294:8: (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression )
                            {
                            // InternalSM2.g:1294:8: (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression )
                            int alt47=2;
                            int LA47_0 = input.LA(1);

                            if ( (LA47_0==77||LA47_0==101) ) {
                                alt47=1;
                            }
                            else if ( (LA47_0==RULE_STRING||(LA47_0>=RULE_INTEGER && LA47_0<=RULE_FLOAT)) ) {
                                alt47=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 47, 0, input);

                                throw nvae;
                            }
                            switch (alt47) {
                                case 1 :
                                    // InternalSM2.g:1295:9: lv_inputparam_4_1= rulePropertyAddress
                                    {
                                    if ( state.backtracking==0 ) {

                                      									newCompositeNode(grammarAccess.getTxVariablesAccess().getInputparamPropertyAddressParserRuleCall_2_0_0_2_0_0());
                                      								
                                    }
                                    pushFollow(FOLLOW_25);
                                    lv_inputparam_4_1=rulePropertyAddress();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      									if (current==null) {
                                      										current = createModelElementForParent(grammarAccess.getTxVariablesRule());
                                      									}
                                      									set(
                                      										current,
                                      										"inputparam",
                                      										lv_inputparam_4_1,
                                      										"org.xtext.SM2.PropertyAddress");
                                      									afterParserOrEnumRuleCall();
                                      								
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:1311:9: lv_inputparam_4_2= ruleSyntaxExpression
                                    {
                                    if ( state.backtracking==0 ) {

                                      									newCompositeNode(grammarAccess.getTxVariablesAccess().getInputparamSyntaxExpressionParserRuleCall_2_0_0_2_0_1());
                                      								
                                    }
                                    pushFollow(FOLLOW_25);
                                    lv_inputparam_4_2=ruleSyntaxExpression();

                                    state._fsp--;
                                    if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      									if (current==null) {
                                      										current = createModelElementForParent(grammarAccess.getTxVariablesRule());
                                      									}
                                      									set(
                                      										current,
                                      										"inputparam",
                                      										lv_inputparam_4_2,
                                      										"org.xtext.SM2.SyntaxExpression");
                                      									afterParserOrEnumRuleCall();
                                      								
                                    }

                                    }
                                    break;

                            }


                            }


                            }

                            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getTxVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_0_0_3());
                              					
                            }

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:1335:5: otherlv_6= 'gasprice'
                            {
                            otherlv_6=(Token)match(input,65,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(otherlv_6, grammarAccess.getTxVariablesAccess().getGaspriceKeyword_2_0_1());
                              				
                            }

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1341:4: ( (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ( ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:1341:4: ( (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ( ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:1342:5: (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ( ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS
                    {
                    // InternalSM2.g:1342:5: (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ( ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) ) ) )
                    // InternalSM2.g:1343:6: otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ( ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) ) )
                    {
                    otherlv_7=(Token)match(input,66,FOLLOW_23); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(otherlv_7, grammarAccess.getTxVariablesAccess().getOriginKeyword_2_1_0_0());
                      					
                    }
                    this_OPENPARENTHESIS_8=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(this_OPENPARENTHESIS_8, grammarAccess.getTxVariablesAccess().getOPENPARENTHESISTerminalRuleCall_2_1_0_1());
                      					
                    }
                    // InternalSM2.g:1351:6: ( ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) ) )
                    // InternalSM2.g:1352:7: ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) )
                    {
                    // InternalSM2.g:1352:7: ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) )
                    // InternalSM2.g:1353:8: (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression )
                    {
                    // InternalSM2.g:1353:8: (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression )
                    int alt49=2;
                    int LA49_0 = input.LA(1);

                    if ( ((LA49_0>=88 && LA49_0<=99)) ) {
                        alt49=1;
                    }
                    else if ( (LA49_0==RULE_STRING||(LA49_0>=RULE_INTEGER && LA49_0<=RULE_FLOAT)) ) {
                        alt49=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 49, 0, input);

                        throw nvae;
                    }
                    switch (alt49) {
                        case 1 :
                            // InternalSM2.g:1354:9: lv_inputparam_9_1= rulePropertyInteger
                            {
                            if ( state.backtracking==0 ) {

                              									newCompositeNode(grammarAccess.getTxVariablesAccess().getInputparamPropertyIntegerParserRuleCall_2_1_0_2_0_0());
                              								
                            }
                            pushFollow(FOLLOW_25);
                            lv_inputparam_9_1=rulePropertyInteger();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              									if (current==null) {
                              										current = createModelElementForParent(grammarAccess.getTxVariablesRule());
                              									}
                              									set(
                              										current,
                              										"inputparam",
                              										lv_inputparam_9_1,
                              										"org.xtext.SM2.PropertyInteger");
                              									afterParserOrEnumRuleCall();
                              								
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:1370:9: lv_inputparam_9_2= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              									newCompositeNode(grammarAccess.getTxVariablesAccess().getInputparamSyntaxExpressionParserRuleCall_2_1_0_2_0_1());
                              								
                            }
                            pushFollow(FOLLOW_25);
                            lv_inputparam_9_2=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              									if (current==null) {
                              										current = createModelElementForParent(grammarAccess.getTxVariablesRule());
                              									}
                              									set(
                              										current,
                              										"inputparam",
                              										lv_inputparam_9_2,
                              										"org.xtext.SM2.SyntaxExpression");
                              									afterParserOrEnumRuleCall();
                              								
                            }

                            }
                            break;

                    }


                    }


                    }


                    }

                    this_CLOSEPARENTHESIS_10=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_10, grammarAccess.getTxVariablesAccess().getCLOSEPARENTHESISTerminalRuleCall_2_1_1());
                      				
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1395:4: otherlv_11= 'origin'
                    {
                    otherlv_11=(Token)match(input,66,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_11, grammarAccess.getTxVariablesAccess().getOriginKeyword_2_2());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:1400:3: (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )?
            int alt51=2;
            int LA51_0 = input.LA(1);

            if ( (LA51_0==RULE_SEMICOLON) ) {
                int LA51_1 = input.LA(2);

                if ( (LA51_1==RULE_EOLINE) ) {
                    int LA51_3 = input.LA(3);

                    if ( (LA51_3==EOF||(LA51_3>=RULE_ID && LA51_3<=RULE_CLOSEKEY)||(LA51_3>=RULE_OPENPARENTHESIS && LA51_3<=RULE_STRING)||(LA51_3>=RULE_INTEGER && LA51_3<=RULE_SINGLENUMBER)||LA51_3==RULE_RETURN||(LA51_3>=RULE_NEW && LA51_3<=RULE_BREAK)||LA51_3==50||LA51_3==56||(LA51_3>=63 && LA51_3<=64)||LA51_3==73||(LA51_3>=77 && LA51_3<=78)||(LA51_3>=88 && LA51_3<=101)||(LA51_3>=103 && LA51_3<=111)||(LA51_3>=148 && LA51_3<=149)) ) {
                        alt51=1;
                    }
                }
            }
            switch (alt51) {
                case 1 :
                    // InternalSM2.g:1401:4: this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE
                    {
                    this_SEMICOLON_12=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_12, grammarAccess.getTxVariablesAccess().getSEMICOLONTerminalRuleCall_3_0());
                      			
                    }
                    this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_13, grammarAccess.getTxVariablesAccess().getEOLINETerminalRuleCall_3_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTxVariables"


    // $ANTLR start "entryRuleConstructor"
    // InternalSM2.g:1414:1: entryRuleConstructor returns [EObject current=null] : iv_ruleConstructor= ruleConstructor EOF ;
    public final EObject entryRuleConstructor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConstructor = null;


        try {
            // InternalSM2.g:1414:52: (iv_ruleConstructor= ruleConstructor EOF )
            // InternalSM2.g:1415:2: iv_ruleConstructor= ruleConstructor EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConstructorRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleConstructor=ruleConstructor();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleConstructor; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConstructor"


    // $ANTLR start "ruleConstructor"
    // InternalSM2.g:1421:1: ruleConstructor returns [EObject current=null] : (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY ) ;
    public final EObject ruleConstructor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_2=null;
        Token lv_type_3_1=null;
        Token lv_type_3_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token otherlv_6=null;
        Token this_CLOSEKEY_7=null;


        	enterRule();

        try {
            // InternalSM2.g:1427:2: ( (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY ) )
            // InternalSM2.g:1428:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY )
            {
            // InternalSM2.g:1428:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY )
            // InternalSM2.g:1429:3: otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,67,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getConstructorAccess().getConstructorKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_31); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConstructorAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1437:3: ( (otherlv_2= RULE_ID ) )*
            loop52:
            do {
                int alt52=2;
                int LA52_0 = input.LA(1);

                if ( (LA52_0==RULE_ID) ) {
                    alt52=1;
                }


                switch (alt52) {
            	case 1 :
            	    // InternalSM2.g:1438:4: (otherlv_2= RULE_ID )
            	    {
            	    // InternalSM2.g:1438:4: (otherlv_2= RULE_ID )
            	    // InternalSM2.g:1439:5: otherlv_2= RULE_ID
            	    {
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElement(grammarAccess.getConstructorRule());
            	      					}
            	      				
            	    }
            	    otherlv_2=(Token)match(input,RULE_ID,FOLLOW_31); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_2, grammarAccess.getConstructorAccess().getInputParamsInputParamCrossReference_2_0());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop52;
                }
            } while (true);

            // InternalSM2.g:1450:3: ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) )
            // InternalSM2.g:1451:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            {
            // InternalSM2.g:1451:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            // InternalSM2.g:1452:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            {
            // InternalSM2.g:1452:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==68) ) {
                alt53=1;
            }
            else if ( (LA53_0==69) ) {
                alt53=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 53, 0, input);

                throw nvae;
            }
            switch (alt53) {
                case 1 :
                    // InternalSM2.g:1453:6: lv_type_3_1= 'public'
                    {
                    lv_type_3_1=(Token)match(input,68,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_3_1, grammarAccess.getConstructorAccess().getTypePublicKeyword_3_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getConstructorRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_3_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1464:6: lv_type_3_2= 'internal'
                    {
                    lv_type_3_2=(Token)match(input,69,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_3_2, grammarAccess.getConstructorAccess().getTypeInternalKeyword_3_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getConstructorRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_3_2, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getConstructorAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_32); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getConstructorAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1485:3: ( (otherlv_6= RULE_ID ) )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==RULE_ID) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalSM2.g:1486:4: (otherlv_6= RULE_ID )
                    {
                    // InternalSM2.g:1486:4: (otherlv_6= RULE_ID )
                    // InternalSM2.g:1487:5: otherlv_6= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getConstructorRule());
                      					}
                      				
                    }
                    otherlv_6=(Token)match(input,RULE_ID,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_6, grammarAccess.getConstructorAccess().getAttributesAttributesCrossReference_6_0());
                      				
                    }

                    }


                    }
                    break;

            }

            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_7, grammarAccess.getConstructorAccess().getCLOSEKEYTerminalRuleCall_7());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConstructor"


    // $ANTLR start "entryRuleEvent"
    // InternalSM2.g:1506:1: entryRuleEvent returns [EObject current=null] : iv_ruleEvent= ruleEvent EOF ;
    public final EObject entryRuleEvent() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvent = null;


        try {
            // InternalSM2.g:1506:46: (iv_ruleEvent= ruleEvent EOF )
            // InternalSM2.g:1507:2: iv_ruleEvent= ruleEvent EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getEventRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleEvent=ruleEvent();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleEvent; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalSM2.g:1513:1: ruleEvent returns [EObject current=null] : (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject ruleEvent() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEvent_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token otherlv_3=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;


        	enterRule();

        try {
            // InternalSM2.g:1519:2: ( (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1520:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1520:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1521:3: otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,70,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getEventAccess().getEventKeyword_0());
              		
            }
            // InternalSM2.g:1525:3: ( (lv_nameEvent_1_0= RULE_ID ) )
            // InternalSM2.g:1526:4: (lv_nameEvent_1_0= RULE_ID )
            {
            // InternalSM2.g:1526:4: (lv_nameEvent_1_0= RULE_ID )
            // InternalSM2.g:1527:5: lv_nameEvent_1_0= RULE_ID
            {
            lv_nameEvent_1_0=(Token)match(input,RULE_ID,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameEvent_1_0, grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEventRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameEvent",
              						lv_nameEvent_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_33); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1547:3: ( (otherlv_3= RULE_ID ) )*
            loop55:
            do {
                int alt55=2;
                int LA55_0 = input.LA(1);

                if ( (LA55_0==RULE_ID) ) {
                    alt55=1;
                }


                switch (alt55) {
            	case 1 :
            	    // InternalSM2.g:1548:4: (otherlv_3= RULE_ID )
            	    {
            	    // InternalSM2.g:1548:4: (otherlv_3= RULE_ID )
            	    // InternalSM2.g:1549:5: otherlv_3= RULE_ID
            	    {
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElement(grammarAccess.getEventRule());
            	      					}
            	      				
            	    }
            	    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_33); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_3, grammarAccess.getEventAccess().getInputParamsInputParamCrossReference_3_0());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop55;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_5, grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1568:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==RULE_EOLINE) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalSM2.g:1569:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:1578:1: entryRuleModifier returns [EObject current=null] : iv_ruleModifier= ruleModifier EOF ;
    public final EObject entryRuleModifier() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModifier = null;


        try {
            // InternalSM2.g:1578:49: (iv_ruleModifier= ruleModifier EOF )
            // InternalSM2.g:1579:2: iv_ruleModifier= ruleModifier EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getModifierRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleModifier=ruleModifier();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleModifier; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:1585:1: ruleModifier returns [EObject current=null] : (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? ) ;
    public final EObject ruleModifier() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameModifier_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token otherlv_3=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_EOLINE_6=null;
        Token this_SEMICOLON_9=null;
        Token this_EOLINE_10=null;
        Token otherlv_11=null;
        Token this_CLOSEKEY_12=null;
        Token this_EOLINE_13=null;
        EObject lv_conditions_7_0 = null;

        EObject lv_expr_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1591:2: ( (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? ) )
            // InternalSM2.g:1592:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? )
            {
            // InternalSM2.g:1592:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? )
            // InternalSM2.g:1593:3: otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,71,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getModifierAccess().getModifierKeyword_0());
              		
            }
            // InternalSM2.g:1597:3: ( (lv_nameModifier_1_0= RULE_ID ) )
            // InternalSM2.g:1598:4: (lv_nameModifier_1_0= RULE_ID )
            {
            // InternalSM2.g:1598:4: (lv_nameModifier_1_0= RULE_ID )
            // InternalSM2.g:1599:5: lv_nameModifier_1_0= RULE_ID
            {
            lv_nameModifier_1_0=(Token)match(input,RULE_ID,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameModifier_1_0, grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getModifierRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameModifier",
              						lv_nameModifier_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_33); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1619:3: ( (otherlv_3= RULE_ID ) )*
            loop57:
            do {
                int alt57=2;
                int LA57_0 = input.LA(1);

                if ( (LA57_0==RULE_ID) ) {
                    alt57=1;
                }


                switch (alt57) {
            	case 1 :
            	    // InternalSM2.g:1620:4: (otherlv_3= RULE_ID )
            	    {
            	    // InternalSM2.g:1620:4: (otherlv_3= RULE_ID )
            	    // InternalSM2.g:1621:5: otherlv_3= RULE_ID
            	    {
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElement(grammarAccess.getModifierRule());
            	      					}
            	      				
            	    }
            	    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_33); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_3, grammarAccess.getModifierAccess().getInputParamsInputParamCrossReference_3_0());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop57;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_34); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1640:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==RULE_EOLINE) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // InternalSM2.g:1641:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_34); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:1646:3: ( (lv_conditions_7_0= ruleConditional ) )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==RULE_IF) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // InternalSM2.g:1647:4: (lv_conditions_7_0= ruleConditional )
                    {
                    // InternalSM2.g:1647:4: (lv_conditions_7_0= ruleConditional )
                    // InternalSM2.g:1648:5: lv_conditions_7_0= ruleConditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getModifierAccess().getConditionsConditionalParserRuleCall_7_0());
                      				
                    }
                    pushFollow(FOLLOW_34);
                    lv_conditions_7_0=ruleConditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getModifierRule());
                      					}
                      					add(
                      						current,
                      						"conditions",
                      						lv_conditions_7_0,
                      						"org.xtext.SM2.Conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1665:3: ( (lv_expr_8_0= ruleExpression ) )
            // InternalSM2.g:1666:4: (lv_expr_8_0= ruleExpression )
            {
            // InternalSM2.g:1666:4: (lv_expr_8_0= ruleExpression )
            // InternalSM2.g:1667:5: lv_expr_8_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getModifierAccess().getExprExpressionParserRuleCall_8_0());
              				
            }
            pushFollow(FOLLOW_7);
            lv_expr_8_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getModifierRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_8_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_35); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_9, grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_9());
              		
            }
            // InternalSM2.g:1688:3: (this_EOLINE_10= RULE_EOLINE )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==RULE_EOLINE) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // InternalSM2.g:1689:4: this_EOLINE_10= RULE_EOLINE
                    {
                    this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_36); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_10, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_10());
                      			
                    }

                    }
                    break;

            }

            otherlv_11=(Token)match(input,72,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_11, grammarAccess.getModifierAccess().get_Keyword_11());
              		
            }
            this_CLOSEKEY_12=(Token)match(input,RULE_CLOSEKEY,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_12, grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_12());
              		
            }
            // InternalSM2.g:1702:3: (this_EOLINE_13= RULE_EOLINE )?
            int alt61=2;
            int LA61_0 = input.LA(1);

            if ( (LA61_0==RULE_EOLINE) ) {
                alt61=1;
            }
            switch (alt61) {
                case 1 :
                    // InternalSM2.g:1703:4: this_EOLINE_13= RULE_EOLINE
                    {
                    this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_13, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_13());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:1712:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalSM2.g:1712:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalSM2.g:1713:2: iv_ruleDataType= ruleDataType EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getDataTypeRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleDataType; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:1719:1: ruleDataType returns [EObject current=null] : (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        EObject this_Mapping_0 = null;

        EObject this_Enum_1 = null;

        EObject this_Struct_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:1725:2: ( (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct ) )
            // InternalSM2.g:1726:2: (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct )
            {
            // InternalSM2.g:1726:2: (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct )
            int alt62=3;
            switch ( input.LA(1) ) {
            case 74:
                {
                alt62=1;
                }
                break;
            case 82:
                {
                alt62=2;
                }
                break;
            case 76:
                {
                alt62=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 62, 0, input);

                throw nvae;
            }

            switch (alt62) {
                case 1 :
                    // InternalSM2.g:1727:3: this_Mapping_0= ruleMapping
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getMappingParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Mapping_0=ruleMapping();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Mapping_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1736:3: this_Enum_1= ruleEnum
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Enum_1=ruleEnum();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Enum_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1745:3: this_Struct_2= ruleStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getStructParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Struct_2=ruleStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Struct_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleLogicalUnaryOperator"
    // InternalSM2.g:1757:1: entryRuleLogicalUnaryOperator returns [EObject current=null] : iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF ;
    public final EObject entryRuleLogicalUnaryOperator() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLogicalUnaryOperator = null;


        try {
            // InternalSM2.g:1757:61: (iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF )
            // InternalSM2.g:1758:2: iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLogicalUnaryOperatorRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLogicalUnaryOperator=ruleLogicalUnaryOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLogicalUnaryOperator; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLogicalUnaryOperator"


    // $ANTLR start "ruleLogicalUnaryOperator"
    // InternalSM2.g:1764:1: ruleLogicalUnaryOperator returns [EObject current=null] : ( (lv_operator_0_0= '!' ) ) ;
    public final EObject ruleLogicalUnaryOperator() throws RecognitionException {
        EObject current = null;

        Token lv_operator_0_0=null;


        	enterRule();

        try {
            // InternalSM2.g:1770:2: ( ( (lv_operator_0_0= '!' ) ) )
            // InternalSM2.g:1771:2: ( (lv_operator_0_0= '!' ) )
            {
            // InternalSM2.g:1771:2: ( (lv_operator_0_0= '!' ) )
            // InternalSM2.g:1772:3: (lv_operator_0_0= '!' )
            {
            // InternalSM2.g:1772:3: (lv_operator_0_0= '!' )
            // InternalSM2.g:1773:4: lv_operator_0_0= '!'
            {
            lv_operator_0_0=(Token)match(input,73,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(lv_operator_0_0, grammarAccess.getLogicalUnaryOperatorAccess().getOperatorExclamationMarkKeyword_0());
              			
            }
            if ( state.backtracking==0 ) {

              				if (current==null) {
              					current = createModelElement(grammarAccess.getLogicalUnaryOperatorRule());
              				}
              				setWithLastConsumed(current, "operator", lv_operator_0_0, "!");
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalUnaryOperator"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:1788:1: entryRuleMapping returns [EObject current=null] : iv_ruleMapping= ruleMapping EOF ;
    public final EObject entryRuleMapping() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMapping = null;


        try {
            // InternalSM2.g:1788:48: (iv_ruleMapping= ruleMapping EOF )
            // InternalSM2.g:1789:2: iv_ruleMapping= ruleMapping EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMappingRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleMapping=ruleMapping();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleMapping; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:1795:1: ruleMapping returns [EObject current=null] : (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON ) ;
    public final EObject ruleMapping() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token lv_nameMapping_8_0=null;
        Token this_SEMICOLON_9=null;
        Enumerator lv_key_2_0 = null;

        Enumerator lv_valueBasicType_5_0 = null;

        Enumerator lv_visibility_7_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1801:2: ( (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON ) )
            // InternalSM2.g:1802:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON )
            {
            // InternalSM2.g:1802:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON )
            // InternalSM2.g:1803:3: otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON
            {
            otherlv_0=(Token)match(input,74,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getMappingAccess().getMappingKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_37); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1811:3: ( (lv_key_2_0= ruleBasicType ) )
            // InternalSM2.g:1812:4: (lv_key_2_0= ruleBasicType )
            {
            // InternalSM2.g:1812:4: (lv_key_2_0= ruleBasicType )
            // InternalSM2.g:1813:5: lv_key_2_0= ruleBasicType
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getMappingAccess().getKeyBasicTypeEnumRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_38);
            lv_key_2_0=ruleBasicType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getMappingRule());
              					}
              					set(
              						current,
              						"key",
              						lv_key_2_0,
              						"org.xtext.SM2.BasicType");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,75,FOLLOW_39); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3());
              		
            }
            // InternalSM2.g:1834:3: ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) )
            int alt63=2;
            int LA63_0 = input.LA(1);

            if ( (LA63_0==RULE_ID) ) {
                alt63=1;
            }
            else if ( ((LA63_0>=77 && LA63_0<=78)||(LA63_0>=88 && LA63_0<=101)||(LA63_0>=103 && LA63_0<=111)||(LA63_0>=148 && LA63_0<=149)) ) {
                alt63=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 63, 0, input);

                throw nvae;
            }
            switch (alt63) {
                case 1 :
                    // InternalSM2.g:1835:4: ( (otherlv_4= RULE_ID ) )
                    {
                    // InternalSM2.g:1835:4: ( (otherlv_4= RULE_ID ) )
                    // InternalSM2.g:1836:5: (otherlv_4= RULE_ID )
                    {
                    // InternalSM2.g:1836:5: (otherlv_4= RULE_ID )
                    // InternalSM2.g:1837:6: otherlv_4= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getMappingRule());
                      						}
                      					
                    }
                    otherlv_4=(Token)match(input,RULE_ID,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(otherlv_4, grammarAccess.getMappingAccess().getValueStructCrossReference_4_0_0());
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1849:4: ( (lv_valueBasicType_5_0= ruleBasicType ) )
                    {
                    // InternalSM2.g:1849:4: ( (lv_valueBasicType_5_0= ruleBasicType ) )
                    // InternalSM2.g:1850:5: (lv_valueBasicType_5_0= ruleBasicType )
                    {
                    // InternalSM2.g:1850:5: (lv_valueBasicType_5_0= ruleBasicType )
                    // InternalSM2.g:1851:6: lv_valueBasicType_5_0= ruleBasicType
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getMappingAccess().getValueBasicTypeBasicTypeEnumRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_25);
                    lv_valueBasicType_5_0=ruleBasicType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getMappingRule());
                      						}
                      						set(
                      							current,
                      							"valueBasicType",
                      							lv_valueBasicType_5_0,
                      							"org.xtext.SM2.BasicType");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_40); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1873:3: ( (lv_visibility_7_0= ruleVisibility ) )?
            int alt64=2;
            int LA64_0 = input.LA(1);

            if ( ((LA64_0>=68 && LA64_0<=69)||(LA64_0>=123 && LA64_0<=124)) ) {
                alt64=1;
            }
            switch (alt64) {
                case 1 :
                    // InternalSM2.g:1874:4: (lv_visibility_7_0= ruleVisibility )
                    {
                    // InternalSM2.g:1874:4: (lv_visibility_7_0= ruleVisibility )
                    // InternalSM2.g:1875:5: lv_visibility_7_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_5);
                    lv_visibility_7_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getMappingRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_7_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1892:3: ( (lv_nameMapping_8_0= RULE_ID ) )
            // InternalSM2.g:1893:4: (lv_nameMapping_8_0= RULE_ID )
            {
            // InternalSM2.g:1893:4: (lv_nameMapping_8_0= RULE_ID )
            // InternalSM2.g:1894:5: lv_nameMapping_8_0= RULE_ID
            {
            lv_nameMapping_8_0=(Token)match(input,RULE_ID,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameMapping_8_0, grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getMappingRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameMapping",
              						lv_nameMapping_8_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_9, grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:1918:1: entryRuleStruct returns [EObject current=null] : iv_ruleStruct= ruleStruct EOF ;
    public final EObject entryRuleStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStruct = null;


        try {
            // InternalSM2.g:1918:47: (iv_ruleStruct= ruleStruct EOF )
            // InternalSM2.g:1919:2: iv_ruleStruct= ruleStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleStruct=ruleStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:1925:1: ruleStruct returns [EObject current=null] : (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany ) ;
    public final EObject ruleStruct() throws RecognitionException {
        EObject current = null;

        EObject this_PersonalizedStruct_0 = null;

        EObject this_User_1 = null;

        EObject this_Company_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:1931:2: ( (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany ) )
            // InternalSM2.g:1932:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )
            {
            // InternalSM2.g:1932:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )
            int alt65=3;
            alt65 = dfa65.predict(input);
            switch (alt65) {
                case 1 :
                    // InternalSM2.g:1933:3: this_PersonalizedStruct_0= rulePersonalizedStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructAccess().getPersonalizedStructParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PersonalizedStruct_0=rulePersonalizedStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PersonalizedStruct_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1942:3: this_User_1= ruleUser
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructAccess().getUserParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_User_1=ruleUser();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_User_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1951:3: this_Company_2= ruleCompany
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructAccess().getCompanyParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Company_2=ruleCompany();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Company_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRulePersonalizedStruct"
    // InternalSM2.g:1963:1: entryRulePersonalizedStruct returns [EObject current=null] : iv_rulePersonalizedStruct= rulePersonalizedStruct EOF ;
    public final EObject entryRulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonalizedStruct = null;


        try {
            // InternalSM2.g:1963:59: (iv_rulePersonalizedStruct= rulePersonalizedStruct EOF )
            // InternalSM2.g:1964:2: iv_rulePersonalizedStruct= rulePersonalizedStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPersonalizedStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePersonalizedStruct=rulePersonalizedStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePersonalizedStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonalizedStruct"


    // $ANTLR start "rulePersonalizedStruct"
    // InternalSM2.g:1970:1: rulePersonalizedStruct returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject rulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_CLOSEKEY_5=null;
        Token this_EOLINE_6=null;
        EObject lv_properties_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1976:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1977:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1977:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1978:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,76,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getPersonalizedStructAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:1982:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1983:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1983:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1984:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getPersonalizedStructAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPersonalizedStructRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_41); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2004:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==RULE_EOLINE) ) {
                alt66=1;
            }
            switch (alt66) {
                case 1 :
                    // InternalSM2.g:2005:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_42); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:2010:3: ( (lv_properties_4_0= ruleProperty ) )
            // InternalSM2.g:2011:4: (lv_properties_4_0= ruleProperty )
            {
            // InternalSM2.g:2011:4: (lv_properties_4_0= ruleProperty )
            // InternalSM2.g:2012:5: lv_properties_4_0= ruleProperty
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_9);
            lv_properties_4_0=ruleProperty();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getPersonalizedStructRule());
              					}
              					add(
              						current,
              						"properties",
              						lv_properties_4_0,
              						"org.xtext.SM2.Property");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_5, grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:2033:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt67=2;
            int LA67_0 = input.LA(1);

            if ( (LA67_0==RULE_EOLINE) ) {
                alt67=1;
            }
            switch (alt67) {
                case 1 :
                    // InternalSM2.g:2034:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonalizedStruct"


    // $ANTLR start "entryRuleUser"
    // InternalSM2.g:2043:1: entryRuleUser returns [EObject current=null] : iv_ruleUser= ruleUser EOF ;
    public final EObject entryRuleUser() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUser = null;


        try {
            // InternalSM2.g:2043:45: (iv_ruleUser= ruleUser EOF )
            // InternalSM2.g:2044:2: iv_ruleUser= ruleUser EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getUserRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleUser=ruleUser();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleUser; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUser"


    // $ANTLR start "ruleUser"
    // InternalSM2.g:2050:1: ruleUser returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'float' otherlv_27= 'amountAccount' (otherlv_28= '=' ( ( (lv_amount_29_0= RULE_INTEGER ) ) | this_FLOAT_30= RULE_FLOAT ) )? this_SEMICOLON_31= RULE_SEMICOLON (this_EOLINE_32= RULE_EOLINE )? this_CLOSEKEY_33= RULE_CLOSEKEY (this_EOLINE_34= RULE_EOLINE )? ) ;
    public final EObject ruleUser() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        Token otherlv_8=null;
        Token lv_nameUser_9_0=null;
        Token otherlv_10=null;
        Token this_STRING_11=null;
        Token this_SEMICOLON_12=null;
        Token this_EOLINE_13=null;
        Token otherlv_14=null;
        Token lv_surnameUser_15_0=null;
        Token otherlv_16=null;
        Token this_STRING_17=null;
        Token this_SEMICOLON_18=null;
        Token this_EOLINE_19=null;
        Token otherlv_20=null;
        Token lv_email_21_0=null;
        Token otherlv_22=null;
        Token this_EMAIL_23=null;
        Token this_SEMICOLON_24=null;
        Token this_EOLINE_25=null;
        Token otherlv_26=null;
        Token otherlv_27=null;
        Token otherlv_28=null;
        Token lv_amount_29_0=null;
        Token this_FLOAT_30=null;
        Token this_SEMICOLON_31=null;
        Token this_EOLINE_32=null;
        Token this_CLOSEKEY_33=null;
        Token this_EOLINE_34=null;


        	enterRule();

        try {
            // InternalSM2.g:2056:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'float' otherlv_27= 'amountAccount' (otherlv_28= '=' ( ( (lv_amount_29_0= RULE_INTEGER ) ) | this_FLOAT_30= RULE_FLOAT ) )? this_SEMICOLON_31= RULE_SEMICOLON (this_EOLINE_32= RULE_EOLINE )? this_CLOSEKEY_33= RULE_CLOSEKEY (this_EOLINE_34= RULE_EOLINE )? ) )
            // InternalSM2.g:2057:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'float' otherlv_27= 'amountAccount' (otherlv_28= '=' ( ( (lv_amount_29_0= RULE_INTEGER ) ) | this_FLOAT_30= RULE_FLOAT ) )? this_SEMICOLON_31= RULE_SEMICOLON (this_EOLINE_32= RULE_EOLINE )? this_CLOSEKEY_33= RULE_CLOSEKEY (this_EOLINE_34= RULE_EOLINE )? )
            {
            // InternalSM2.g:2057:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'float' otherlv_27= 'amountAccount' (otherlv_28= '=' ( ( (lv_amount_29_0= RULE_INTEGER ) ) | this_FLOAT_30= RULE_FLOAT ) )? this_SEMICOLON_31= RULE_SEMICOLON (this_EOLINE_32= RULE_EOLINE )? this_CLOSEKEY_33= RULE_CLOSEKEY (this_EOLINE_34= RULE_EOLINE )? )
            // InternalSM2.g:2058:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'float' otherlv_27= 'amountAccount' (otherlv_28= '=' ( ( (lv_amount_29_0= RULE_INTEGER ) ) | this_FLOAT_30= RULE_FLOAT ) )? this_SEMICOLON_31= RULE_SEMICOLON (this_EOLINE_32= RULE_EOLINE )? this_CLOSEKEY_33= RULE_CLOSEKEY (this_EOLINE_34= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,76,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getUserAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:2062:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:2063:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:2063:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:2064:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_43); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2084:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==RULE_EOLINE) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // InternalSM2.g:2085:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_44); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            otherlv_4=(Token)match(input,77,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getUserAccess().getAddressKeyword_4());
              		
            }
            // InternalSM2.g:2094:3: ( (lv_idAdress_5_0= RULE_ID ) )
            // InternalSM2.g:2095:4: (lv_idAdress_5_0= RULE_ID )
            {
            // InternalSM2.g:2095:4: (lv_idAdress_5_0= RULE_ID )
            // InternalSM2.g:2096:5: lv_idAdress_5_0= RULE_ID
            {
            lv_idAdress_5_0=(Token)match(input,RULE_ID,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_idAdress_5_0, grammarAccess.getUserAccess().getIdAdressIDTerminalRuleCall_5_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"idAdress",
              						lv_idAdress_5_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:2116:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==RULE_EOLINE) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // InternalSM2.g:2117:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_46); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }

            otherlv_8=(Token)match(input,78,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_8, grammarAccess.getUserAccess().getStringKeyword_8());
              		
            }
            // InternalSM2.g:2126:3: ( (lv_nameUser_9_0= RULE_STRING ) )
            // InternalSM2.g:2127:4: (lv_nameUser_9_0= RULE_STRING )
            {
            // InternalSM2.g:2127:4: (lv_nameUser_9_0= RULE_STRING )
            // InternalSM2.g:2128:5: lv_nameUser_9_0= RULE_STRING
            {
            lv_nameUser_9_0=(Token)match(input,RULE_STRING,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameUser_9_0, grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_9_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameUser",
              						lv_nameUser_9_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2144:3: (otherlv_10= '=' this_STRING_11= RULE_STRING )?
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( (LA70_0==79) ) {
                alt70=1;
            }
            switch (alt70) {
                case 1 :
                    // InternalSM2.g:2145:4: otherlv_10= '=' this_STRING_11= RULE_STRING
                    {
                    otherlv_10=(Token)match(input,79,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_10, grammarAccess.getUserAccess().getEqualsSignKeyword_10_0());
                      			
                    }
                    this_STRING_11=(Token)match(input,RULE_STRING,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_11, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_10_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_12=(Token)match(input,RULE_SEMICOLON,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_12, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_11());
              		
            }
            // InternalSM2.g:2158:3: (this_EOLINE_13= RULE_EOLINE )?
            int alt71=2;
            int LA71_0 = input.LA(1);

            if ( (LA71_0==RULE_EOLINE) ) {
                alt71=1;
            }
            switch (alt71) {
                case 1 :
                    // InternalSM2.g:2159:4: this_EOLINE_13= RULE_EOLINE
                    {
                    this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_46); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_13, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_12());
                      			
                    }

                    }
                    break;

            }

            otherlv_14=(Token)match(input,78,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_14, grammarAccess.getUserAccess().getStringKeyword_13());
              		
            }
            // InternalSM2.g:2168:3: ( (lv_surnameUser_15_0= RULE_STRING ) )
            // InternalSM2.g:2169:4: (lv_surnameUser_15_0= RULE_STRING )
            {
            // InternalSM2.g:2169:4: (lv_surnameUser_15_0= RULE_STRING )
            // InternalSM2.g:2170:5: lv_surnameUser_15_0= RULE_STRING
            {
            lv_surnameUser_15_0=(Token)match(input,RULE_STRING,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_surnameUser_15_0, grammarAccess.getUserAccess().getSurnameUserSTRINGTerminalRuleCall_14_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"surnameUser",
              						lv_surnameUser_15_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2186:3: (otherlv_16= '=' this_STRING_17= RULE_STRING )?
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==79) ) {
                alt72=1;
            }
            switch (alt72) {
                case 1 :
                    // InternalSM2.g:2187:4: otherlv_16= '=' this_STRING_17= RULE_STRING
                    {
                    otherlv_16=(Token)match(input,79,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_16, grammarAccess.getUserAccess().getEqualsSignKeyword_15_0());
                      			
                    }
                    this_STRING_17=(Token)match(input,RULE_STRING,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_17, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_15_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_18=(Token)match(input,RULE_SEMICOLON,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_18, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_16());
              		
            }
            // InternalSM2.g:2200:3: (this_EOLINE_19= RULE_EOLINE )?
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==RULE_EOLINE) ) {
                alt73=1;
            }
            switch (alt73) {
                case 1 :
                    // InternalSM2.g:2201:4: this_EOLINE_19= RULE_EOLINE
                    {
                    this_EOLINE_19=(Token)match(input,RULE_EOLINE,FOLLOW_46); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_19, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_17());
                      			
                    }

                    }
                    break;

            }

            otherlv_20=(Token)match(input,78,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_20, grammarAccess.getUserAccess().getStringKeyword_18());
              		
            }
            // InternalSM2.g:2210:3: ( (lv_email_21_0= RULE_STRING ) )
            // InternalSM2.g:2211:4: (lv_email_21_0= RULE_STRING )
            {
            // InternalSM2.g:2211:4: (lv_email_21_0= RULE_STRING )
            // InternalSM2.g:2212:5: lv_email_21_0= RULE_STRING
            {
            lv_email_21_0=(Token)match(input,RULE_STRING,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_email_21_0, grammarAccess.getUserAccess().getEmailSTRINGTerminalRuleCall_19_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"email",
              						lv_email_21_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2228:3: (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )?
            int alt74=2;
            int LA74_0 = input.LA(1);

            if ( (LA74_0==79) ) {
                alt74=1;
            }
            switch (alt74) {
                case 1 :
                    // InternalSM2.g:2229:4: otherlv_22= '=' this_EMAIL_23= RULE_EMAIL
                    {
                    otherlv_22=(Token)match(input,79,FOLLOW_49); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_22, grammarAccess.getUserAccess().getEqualsSignKeyword_20_0());
                      			
                    }
                    this_EMAIL_23=(Token)match(input,RULE_EMAIL,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EMAIL_23, grammarAccess.getUserAccess().getEMAILTerminalRuleCall_20_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_24=(Token)match(input,RULE_SEMICOLON,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_24, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_21());
              		
            }
            // InternalSM2.g:2242:3: (this_EOLINE_25= RULE_EOLINE )?
            int alt75=2;
            int LA75_0 = input.LA(1);

            if ( (LA75_0==RULE_EOLINE) ) {
                alt75=1;
            }
            switch (alt75) {
                case 1 :
                    // InternalSM2.g:2243:4: this_EOLINE_25= RULE_EOLINE
                    {
                    this_EOLINE_25=(Token)match(input,RULE_EOLINE,FOLLOW_51); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_25, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_22());
                      			
                    }

                    }
                    break;

            }

            otherlv_26=(Token)match(input,80,FOLLOW_52); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_26, grammarAccess.getUserAccess().getFloatKeyword_23());
              		
            }
            otherlv_27=(Token)match(input,81,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_27, grammarAccess.getUserAccess().getAmountAccountKeyword_24());
              		
            }
            // InternalSM2.g:2256:3: (otherlv_28= '=' ( ( (lv_amount_29_0= RULE_INTEGER ) ) | this_FLOAT_30= RULE_FLOAT ) )?
            int alt77=2;
            int LA77_0 = input.LA(1);

            if ( (LA77_0==79) ) {
                alt77=1;
            }
            switch (alt77) {
                case 1 :
                    // InternalSM2.g:2257:4: otherlv_28= '=' ( ( (lv_amount_29_0= RULE_INTEGER ) ) | this_FLOAT_30= RULE_FLOAT )
                    {
                    otherlv_28=(Token)match(input,79,FOLLOW_53); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_28, grammarAccess.getUserAccess().getEqualsSignKeyword_25_0());
                      			
                    }
                    // InternalSM2.g:2261:4: ( ( (lv_amount_29_0= RULE_INTEGER ) ) | this_FLOAT_30= RULE_FLOAT )
                    int alt76=2;
                    int LA76_0 = input.LA(1);

                    if ( (LA76_0==RULE_INTEGER) ) {
                        alt76=1;
                    }
                    else if ( (LA76_0==RULE_FLOAT) ) {
                        alt76=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 76, 0, input);

                        throw nvae;
                    }
                    switch (alt76) {
                        case 1 :
                            // InternalSM2.g:2262:5: ( (lv_amount_29_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:2262:5: ( (lv_amount_29_0= RULE_INTEGER ) )
                            // InternalSM2.g:2263:6: (lv_amount_29_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:2263:6: (lv_amount_29_0= RULE_INTEGER )
                            // InternalSM2.g:2264:7: lv_amount_29_0= RULE_INTEGER
                            {
                            lv_amount_29_0=(Token)match(input,RULE_INTEGER,FOLLOW_7); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_amount_29_0, grammarAccess.getUserAccess().getAmountINTEGERTerminalRuleCall_25_1_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getUserRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"amount",
                              								lv_amount_29_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:2281:5: this_FLOAT_30= RULE_FLOAT
                            {
                            this_FLOAT_30=(Token)match(input,RULE_FLOAT,FOLLOW_7); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_30, grammarAccess.getUserAccess().getFLOATTerminalRuleCall_25_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }
                    break;

            }

            this_SEMICOLON_31=(Token)match(input,RULE_SEMICOLON,FOLLOW_54); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_31, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_26());
              		
            }
            // InternalSM2.g:2291:3: (this_EOLINE_32= RULE_EOLINE )?
            int alt78=2;
            int LA78_0 = input.LA(1);

            if ( (LA78_0==RULE_EOLINE) ) {
                alt78=1;
            }
            switch (alt78) {
                case 1 :
                    // InternalSM2.g:2292:4: this_EOLINE_32= RULE_EOLINE
                    {
                    this_EOLINE_32=(Token)match(input,RULE_EOLINE,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_32, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_27());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_33=(Token)match(input,RULE_CLOSEKEY,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_33, grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_28());
              		
            }
            // InternalSM2.g:2301:3: (this_EOLINE_34= RULE_EOLINE )?
            int alt79=2;
            int LA79_0 = input.LA(1);

            if ( (LA79_0==RULE_EOLINE) ) {
                alt79=1;
            }
            switch (alt79) {
                case 1 :
                    // InternalSM2.g:2302:4: this_EOLINE_34= RULE_EOLINE
                    {
                    this_EOLINE_34=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_34, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_29());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUser"


    // $ANTLR start "entryRuleCompany"
    // InternalSM2.g:2311:1: entryRuleCompany returns [EObject current=null] : iv_ruleCompany= ruleCompany EOF ;
    public final EObject entryRuleCompany() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompany = null;


        try {
            // InternalSM2.g:2311:48: (iv_ruleCompany= ruleCompany EOF )
            // InternalSM2.g:2312:2: iv_ruleCompany= ruleCompany EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCompanyRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleCompany=ruleCompany();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleCompany; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompany"


    // $ANTLR start "ruleCompany"
    // InternalSM2.g:2318:1: ruleCompany returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? otherlv_32= 'float' otherlv_33= 'amountAccount' ( ( (lv_operator_34_0= ruleAssignmentOperator ) ) ( ( (lv_amount_35_0= RULE_INTEGER ) ) | this_FLOAT_36= RULE_FLOAT ) )? this_SEMICOLON_37= RULE_SEMICOLON (this_EOLINE_38= RULE_EOLINE )? this_CLOSEKEY_39= RULE_CLOSEKEY (this_EOLINE_40= RULE_EOLINE )? ) ;
    public final EObject ruleCompany() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        Token otherlv_8=null;
        Token lv_nameCompany_9_0=null;
        Token otherlv_10=null;
        Token this_STRING_11=null;
        Token this_SEMICOLON_12=null;
        Token this_EOLINE_13=null;
        Token otherlv_14=null;
        Token lv_city_15_0=null;
        Token otherlv_16=null;
        Token this_STRING_17=null;
        Token this_SEMICOLON_18=null;
        Token this_EOLINE_19=null;
        Token otherlv_20=null;
        Token lv_email_21_0=null;
        Token otherlv_22=null;
        Token this_EMAIL_23=null;
        Token this_SEMICOLON_24=null;
        Token this_EOLINE_25=null;
        Token otherlv_26=null;
        Token lv_telf_27_0=null;
        Token otherlv_28=null;
        Token this_STRING_29=null;
        Token this_SEMICOLON_30=null;
        Token this_EOLINE_31=null;
        Token otherlv_32=null;
        Token otherlv_33=null;
        Token lv_amount_35_0=null;
        Token this_FLOAT_36=null;
        Token this_SEMICOLON_37=null;
        Token this_EOLINE_38=null;
        Token this_CLOSEKEY_39=null;
        Token this_EOLINE_40=null;
        Enumerator lv_operator_34_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2324:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? otherlv_32= 'float' otherlv_33= 'amountAccount' ( ( (lv_operator_34_0= ruleAssignmentOperator ) ) ( ( (lv_amount_35_0= RULE_INTEGER ) ) | this_FLOAT_36= RULE_FLOAT ) )? this_SEMICOLON_37= RULE_SEMICOLON (this_EOLINE_38= RULE_EOLINE )? this_CLOSEKEY_39= RULE_CLOSEKEY (this_EOLINE_40= RULE_EOLINE )? ) )
            // InternalSM2.g:2325:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? otherlv_32= 'float' otherlv_33= 'amountAccount' ( ( (lv_operator_34_0= ruleAssignmentOperator ) ) ( ( (lv_amount_35_0= RULE_INTEGER ) ) | this_FLOAT_36= RULE_FLOAT ) )? this_SEMICOLON_37= RULE_SEMICOLON (this_EOLINE_38= RULE_EOLINE )? this_CLOSEKEY_39= RULE_CLOSEKEY (this_EOLINE_40= RULE_EOLINE )? )
            {
            // InternalSM2.g:2325:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? otherlv_32= 'float' otherlv_33= 'amountAccount' ( ( (lv_operator_34_0= ruleAssignmentOperator ) ) ( ( (lv_amount_35_0= RULE_INTEGER ) ) | this_FLOAT_36= RULE_FLOAT ) )? this_SEMICOLON_37= RULE_SEMICOLON (this_EOLINE_38= RULE_EOLINE )? this_CLOSEKEY_39= RULE_CLOSEKEY (this_EOLINE_40= RULE_EOLINE )? )
            // InternalSM2.g:2326:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? otherlv_32= 'float' otherlv_33= 'amountAccount' ( ( (lv_operator_34_0= ruleAssignmentOperator ) ) ( ( (lv_amount_35_0= RULE_INTEGER ) ) | this_FLOAT_36= RULE_FLOAT ) )? this_SEMICOLON_37= RULE_SEMICOLON (this_EOLINE_38= RULE_EOLINE )? this_CLOSEKEY_39= RULE_CLOSEKEY (this_EOLINE_40= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,76,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getCompanyAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:2330:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:2331:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:2331:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:2332:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getCompanyAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_43); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getCompanyAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2352:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt80=2;
            int LA80_0 = input.LA(1);

            if ( (LA80_0==RULE_EOLINE) ) {
                alt80=1;
            }
            switch (alt80) {
                case 1 :
                    // InternalSM2.g:2353:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_44); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            otherlv_4=(Token)match(input,77,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getCompanyAccess().getAddressKeyword_4());
              		
            }
            // InternalSM2.g:2362:3: ( (lv_idAdress_5_0= RULE_ID ) )
            // InternalSM2.g:2363:4: (lv_idAdress_5_0= RULE_ID )
            {
            // InternalSM2.g:2363:4: (lv_idAdress_5_0= RULE_ID )
            // InternalSM2.g:2364:5: lv_idAdress_5_0= RULE_ID
            {
            lv_idAdress_5_0=(Token)match(input,RULE_ID,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_idAdress_5_0, grammarAccess.getCompanyAccess().getIdAdressIDTerminalRuleCall_5_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"idAdress",
              						lv_idAdress_5_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:2384:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt81=2;
            int LA81_0 = input.LA(1);

            if ( (LA81_0==RULE_EOLINE) ) {
                alt81=1;
            }
            switch (alt81) {
                case 1 :
                    // InternalSM2.g:2385:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_46); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }

            otherlv_8=(Token)match(input,78,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_8, grammarAccess.getCompanyAccess().getStringKeyword_8());
              		
            }
            // InternalSM2.g:2394:3: ( (lv_nameCompany_9_0= RULE_STRING ) )
            // InternalSM2.g:2395:4: (lv_nameCompany_9_0= RULE_STRING )
            {
            // InternalSM2.g:2395:4: (lv_nameCompany_9_0= RULE_STRING )
            // InternalSM2.g:2396:5: lv_nameCompany_9_0= RULE_STRING
            {
            lv_nameCompany_9_0=(Token)match(input,RULE_STRING,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameCompany_9_0, grammarAccess.getCompanyAccess().getNameCompanySTRINGTerminalRuleCall_9_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameCompany",
              						lv_nameCompany_9_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2412:3: (otherlv_10= '=' this_STRING_11= RULE_STRING )?
            int alt82=2;
            int LA82_0 = input.LA(1);

            if ( (LA82_0==79) ) {
                alt82=1;
            }
            switch (alt82) {
                case 1 :
                    // InternalSM2.g:2413:4: otherlv_10= '=' this_STRING_11= RULE_STRING
                    {
                    otherlv_10=(Token)match(input,79,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_10, grammarAccess.getCompanyAccess().getEqualsSignKeyword_10_0());
                      			
                    }
                    this_STRING_11=(Token)match(input,RULE_STRING,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_11, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_10_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_12=(Token)match(input,RULE_SEMICOLON,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_12, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_11());
              		
            }
            // InternalSM2.g:2426:3: (this_EOLINE_13= RULE_EOLINE )?
            int alt83=2;
            int LA83_0 = input.LA(1);

            if ( (LA83_0==RULE_EOLINE) ) {
                alt83=1;
            }
            switch (alt83) {
                case 1 :
                    // InternalSM2.g:2427:4: this_EOLINE_13= RULE_EOLINE
                    {
                    this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_46); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_13, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_12());
                      			
                    }

                    }
                    break;

            }

            otherlv_14=(Token)match(input,78,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_14, grammarAccess.getCompanyAccess().getStringKeyword_13());
              		
            }
            // InternalSM2.g:2436:3: ( (lv_city_15_0= RULE_STRING ) )
            // InternalSM2.g:2437:4: (lv_city_15_0= RULE_STRING )
            {
            // InternalSM2.g:2437:4: (lv_city_15_0= RULE_STRING )
            // InternalSM2.g:2438:5: lv_city_15_0= RULE_STRING
            {
            lv_city_15_0=(Token)match(input,RULE_STRING,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_city_15_0, grammarAccess.getCompanyAccess().getCitySTRINGTerminalRuleCall_14_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"city",
              						lv_city_15_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2454:3: (otherlv_16= '=' this_STRING_17= RULE_STRING )?
            int alt84=2;
            int LA84_0 = input.LA(1);

            if ( (LA84_0==79) ) {
                alt84=1;
            }
            switch (alt84) {
                case 1 :
                    // InternalSM2.g:2455:4: otherlv_16= '=' this_STRING_17= RULE_STRING
                    {
                    otherlv_16=(Token)match(input,79,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_16, grammarAccess.getCompanyAccess().getEqualsSignKeyword_15_0());
                      			
                    }
                    this_STRING_17=(Token)match(input,RULE_STRING,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_17, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_15_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_18=(Token)match(input,RULE_SEMICOLON,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_18, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_16());
              		
            }
            // InternalSM2.g:2468:3: (this_EOLINE_19= RULE_EOLINE )?
            int alt85=2;
            int LA85_0 = input.LA(1);

            if ( (LA85_0==RULE_EOLINE) ) {
                alt85=1;
            }
            switch (alt85) {
                case 1 :
                    // InternalSM2.g:2469:4: this_EOLINE_19= RULE_EOLINE
                    {
                    this_EOLINE_19=(Token)match(input,RULE_EOLINE,FOLLOW_46); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_19, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_17());
                      			
                    }

                    }
                    break;

            }

            otherlv_20=(Token)match(input,78,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_20, grammarAccess.getCompanyAccess().getStringKeyword_18());
              		
            }
            // InternalSM2.g:2478:3: ( (lv_email_21_0= RULE_STRING ) )
            // InternalSM2.g:2479:4: (lv_email_21_0= RULE_STRING )
            {
            // InternalSM2.g:2479:4: (lv_email_21_0= RULE_STRING )
            // InternalSM2.g:2480:5: lv_email_21_0= RULE_STRING
            {
            lv_email_21_0=(Token)match(input,RULE_STRING,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_email_21_0, grammarAccess.getCompanyAccess().getEmailSTRINGTerminalRuleCall_19_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"email",
              						lv_email_21_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2496:3: (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )?
            int alt86=2;
            int LA86_0 = input.LA(1);

            if ( (LA86_0==79) ) {
                alt86=1;
            }
            switch (alt86) {
                case 1 :
                    // InternalSM2.g:2497:4: otherlv_22= '=' this_EMAIL_23= RULE_EMAIL
                    {
                    otherlv_22=(Token)match(input,79,FOLLOW_49); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_22, grammarAccess.getCompanyAccess().getEqualsSignKeyword_20_0());
                      			
                    }
                    this_EMAIL_23=(Token)match(input,RULE_EMAIL,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EMAIL_23, grammarAccess.getCompanyAccess().getEMAILTerminalRuleCall_20_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_24=(Token)match(input,RULE_SEMICOLON,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_24, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_21());
              		
            }
            // InternalSM2.g:2510:3: (this_EOLINE_25= RULE_EOLINE )?
            int alt87=2;
            int LA87_0 = input.LA(1);

            if ( (LA87_0==RULE_EOLINE) ) {
                alt87=1;
            }
            switch (alt87) {
                case 1 :
                    // InternalSM2.g:2511:4: this_EOLINE_25= RULE_EOLINE
                    {
                    this_EOLINE_25=(Token)match(input,RULE_EOLINE,FOLLOW_46); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_25, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_22());
                      			
                    }

                    }
                    break;

            }

            otherlv_26=(Token)match(input,78,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_26, grammarAccess.getCompanyAccess().getStringKeyword_23());
              		
            }
            // InternalSM2.g:2520:3: ( (lv_telf_27_0= RULE_STRING ) )
            // InternalSM2.g:2521:4: (lv_telf_27_0= RULE_STRING )
            {
            // InternalSM2.g:2521:4: (lv_telf_27_0= RULE_STRING )
            // InternalSM2.g:2522:5: lv_telf_27_0= RULE_STRING
            {
            lv_telf_27_0=(Token)match(input,RULE_STRING,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_telf_27_0, grammarAccess.getCompanyAccess().getTelfSTRINGTerminalRuleCall_24_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"telf",
              						lv_telf_27_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2538:3: (otherlv_28= '=' this_STRING_29= RULE_STRING )?
            int alt88=2;
            int LA88_0 = input.LA(1);

            if ( (LA88_0==79) ) {
                alt88=1;
            }
            switch (alt88) {
                case 1 :
                    // InternalSM2.g:2539:4: otherlv_28= '=' this_STRING_29= RULE_STRING
                    {
                    otherlv_28=(Token)match(input,79,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_28, grammarAccess.getCompanyAccess().getEqualsSignKeyword_25_0());
                      			
                    }
                    this_STRING_29=(Token)match(input,RULE_STRING,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_29, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_25_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_30=(Token)match(input,RULE_SEMICOLON,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_30, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_26());
              		
            }
            // InternalSM2.g:2552:3: (this_EOLINE_31= RULE_EOLINE )?
            int alt89=2;
            int LA89_0 = input.LA(1);

            if ( (LA89_0==RULE_EOLINE) ) {
                alt89=1;
            }
            switch (alt89) {
                case 1 :
                    // InternalSM2.g:2553:4: this_EOLINE_31= RULE_EOLINE
                    {
                    this_EOLINE_31=(Token)match(input,RULE_EOLINE,FOLLOW_51); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_31, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_27());
                      			
                    }

                    }
                    break;

            }

            otherlv_32=(Token)match(input,80,FOLLOW_52); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_32, grammarAccess.getCompanyAccess().getFloatKeyword_28());
              		
            }
            otherlv_33=(Token)match(input,81,FOLLOW_55); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_33, grammarAccess.getCompanyAccess().getAmountAccountKeyword_29());
              		
            }
            // InternalSM2.g:2566:3: ( ( (lv_operator_34_0= ruleAssignmentOperator ) ) ( ( (lv_amount_35_0= RULE_INTEGER ) ) | this_FLOAT_36= RULE_FLOAT ) )?
            int alt91=2;
            int LA91_0 = input.LA(1);

            if ( (LA91_0==79||(LA91_0>=143 && LA91_0<=147)) ) {
                alt91=1;
            }
            switch (alt91) {
                case 1 :
                    // InternalSM2.g:2567:4: ( (lv_operator_34_0= ruleAssignmentOperator ) ) ( ( (lv_amount_35_0= RULE_INTEGER ) ) | this_FLOAT_36= RULE_FLOAT )
                    {
                    // InternalSM2.g:2567:4: ( (lv_operator_34_0= ruleAssignmentOperator ) )
                    // InternalSM2.g:2568:5: (lv_operator_34_0= ruleAssignmentOperator )
                    {
                    // InternalSM2.g:2568:5: (lv_operator_34_0= ruleAssignmentOperator )
                    // InternalSM2.g:2569:6: lv_operator_34_0= ruleAssignmentOperator
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getCompanyAccess().getOperatorAssignmentOperatorEnumRuleCall_30_0_0());
                      					
                    }
                    pushFollow(FOLLOW_53);
                    lv_operator_34_0=ruleAssignmentOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getCompanyRule());
                      						}
                      						set(
                      							current,
                      							"operator",
                      							lv_operator_34_0,
                      							"org.xtext.SM2.AssignmentOperator");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2586:4: ( ( (lv_amount_35_0= RULE_INTEGER ) ) | this_FLOAT_36= RULE_FLOAT )
                    int alt90=2;
                    int LA90_0 = input.LA(1);

                    if ( (LA90_0==RULE_INTEGER) ) {
                        alt90=1;
                    }
                    else if ( (LA90_0==RULE_FLOAT) ) {
                        alt90=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 90, 0, input);

                        throw nvae;
                    }
                    switch (alt90) {
                        case 1 :
                            // InternalSM2.g:2587:5: ( (lv_amount_35_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:2587:5: ( (lv_amount_35_0= RULE_INTEGER ) )
                            // InternalSM2.g:2588:6: (lv_amount_35_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:2588:6: (lv_amount_35_0= RULE_INTEGER )
                            // InternalSM2.g:2589:7: lv_amount_35_0= RULE_INTEGER
                            {
                            lv_amount_35_0=(Token)match(input,RULE_INTEGER,FOLLOW_7); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_amount_35_0, grammarAccess.getCompanyAccess().getAmountINTEGERTerminalRuleCall_30_1_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getCompanyRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"amount",
                              								lv_amount_35_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:2606:5: this_FLOAT_36= RULE_FLOAT
                            {
                            this_FLOAT_36=(Token)match(input,RULE_FLOAT,FOLLOW_7); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_36, grammarAccess.getCompanyAccess().getFLOATTerminalRuleCall_30_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }
                    break;

            }

            this_SEMICOLON_37=(Token)match(input,RULE_SEMICOLON,FOLLOW_54); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_37, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_31());
              		
            }
            // InternalSM2.g:2616:3: (this_EOLINE_38= RULE_EOLINE )?
            int alt92=2;
            int LA92_0 = input.LA(1);

            if ( (LA92_0==RULE_EOLINE) ) {
                alt92=1;
            }
            switch (alt92) {
                case 1 :
                    // InternalSM2.g:2617:4: this_EOLINE_38= RULE_EOLINE
                    {
                    this_EOLINE_38=(Token)match(input,RULE_EOLINE,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_38, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_32());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_39=(Token)match(input,RULE_CLOSEKEY,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_39, grammarAccess.getCompanyAccess().getCLOSEKEYTerminalRuleCall_33());
              		
            }
            // InternalSM2.g:2626:3: (this_EOLINE_40= RULE_EOLINE )?
            int alt93=2;
            int LA93_0 = input.LA(1);

            if ( (LA93_0==RULE_EOLINE) ) {
                alt93=1;
            }
            switch (alt93) {
                case 1 :
                    // InternalSM2.g:2627:4: this_EOLINE_40= RULE_EOLINE
                    {
                    this_EOLINE_40=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_40, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_34());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompany"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:2636:1: entryRuleEnum returns [EObject current=null] : iv_ruleEnum= ruleEnum EOF ;
    public final EObject entryRuleEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnum = null;


        try {
            // InternalSM2.g:2636:45: (iv_ruleEnum= ruleEnum EOF )
            // InternalSM2.g:2637:2: iv_ruleEnum= ruleEnum EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getEnumRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleEnum=ruleEnum();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleEnum; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:2643:1: ruleEnum returns [EObject current=null] : (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( (otherlv_3= RULE_ID ) ) this_CLOSEKEY_4= RULE_CLOSEKEY this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject ruleEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEnum_1_0=null;
        Token this_OPENKEY_2=null;
        Token otherlv_3=null;
        Token this_CLOSEKEY_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;


        	enterRule();

        try {
            // InternalSM2.g:2649:2: ( (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( (otherlv_3= RULE_ID ) ) this_CLOSEKEY_4= RULE_CLOSEKEY this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:2650:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( (otherlv_3= RULE_ID ) ) this_CLOSEKEY_4= RULE_CLOSEKEY this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:2650:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( (otherlv_3= RULE_ID ) ) this_CLOSEKEY_4= RULE_CLOSEKEY this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:2651:3: otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( (otherlv_3= RULE_ID ) ) this_CLOSEKEY_4= RULE_CLOSEKEY this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,82,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getEnumAccess().getEnumKeyword_0());
              		
            }
            // InternalSM2.g:2655:3: ( (lv_nameEnum_1_0= RULE_ID ) )
            // InternalSM2.g:2656:4: (lv_nameEnum_1_0= RULE_ID )
            {
            // InternalSM2.g:2656:4: (lv_nameEnum_1_0= RULE_ID )
            // InternalSM2.g:2657:5: lv_nameEnum_1_0= RULE_ID
            {
            lv_nameEnum_1_0=(Token)match(input,RULE_ID,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameEnum_1_0, grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEnumRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameEnum",
              						lv_nameEnum_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2677:3: ( (otherlv_3= RULE_ID ) )
            // InternalSM2.g:2678:4: (otherlv_3= RULE_ID )
            {
            // InternalSM2.g:2678:4: (otherlv_3= RULE_ID )
            // InternalSM2.g:2679:5: otherlv_3= RULE_ID
            {
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEnumRule());
              					}
              				
            }
            otherlv_3=(Token)match(input,RULE_ID,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(otherlv_3, grammarAccess.getEnumAccess().getLiteralLiteralCrossReference_3_0());
              				
            }

            }


            }

            this_CLOSEKEY_4=(Token)match(input,RULE_CLOSEKEY,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_4, grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_4());
              		
            }
            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_5, grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:2698:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt94=2;
            int LA94_0 = input.LA(1);

            if ( (LA94_0==RULE_EOLINE) ) {
                alt94=1;
            }
            switch (alt94) {
                case 1 :
                    // InternalSM2.g:2699:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleArray"
    // InternalSM2.g:2708:1: entryRuleArray returns [String current=null] : iv_ruleArray= ruleArray EOF ;
    public final String entryRuleArray() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleArray = null;


        try {
            // InternalSM2.g:2708:45: (iv_ruleArray= ruleArray EOF )
            // InternalSM2.g:2709:2: iv_ruleArray= ruleArray EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArrayRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArray=ruleArray();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArray.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArray"


    // $ANTLR start "ruleArray"
    // InternalSM2.g:2715:1: ruleArray returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '[]' | (kw= '[' (this_SINGLENUMBER_2= RULE_SINGLENUMBER | this_INTEGER_3= RULE_INTEGER ) kw= ']' ) ) (kw= '[]' | (kw= '[' (this_SINGLENUMBER_7= RULE_SINGLENUMBER | this_INTEGER_8= RULE_INTEGER ) kw= ']' ) )* ) ;
    public final AntlrDatatypeRuleToken ruleArray() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_SINGLENUMBER_2=null;
        Token this_INTEGER_3=null;
        Token this_SINGLENUMBER_7=null;
        Token this_INTEGER_8=null;


        	enterRule();

        try {
            // InternalSM2.g:2721:2: ( ( (kw= '[]' | (kw= '[' (this_SINGLENUMBER_2= RULE_SINGLENUMBER | this_INTEGER_3= RULE_INTEGER ) kw= ']' ) ) (kw= '[]' | (kw= '[' (this_SINGLENUMBER_7= RULE_SINGLENUMBER | this_INTEGER_8= RULE_INTEGER ) kw= ']' ) )* ) )
            // InternalSM2.g:2722:2: ( (kw= '[]' | (kw= '[' (this_SINGLENUMBER_2= RULE_SINGLENUMBER | this_INTEGER_3= RULE_INTEGER ) kw= ']' ) ) (kw= '[]' | (kw= '[' (this_SINGLENUMBER_7= RULE_SINGLENUMBER | this_INTEGER_8= RULE_INTEGER ) kw= ']' ) )* )
            {
            // InternalSM2.g:2722:2: ( (kw= '[]' | (kw= '[' (this_SINGLENUMBER_2= RULE_SINGLENUMBER | this_INTEGER_3= RULE_INTEGER ) kw= ']' ) ) (kw= '[]' | (kw= '[' (this_SINGLENUMBER_7= RULE_SINGLENUMBER | this_INTEGER_8= RULE_INTEGER ) kw= ']' ) )* )
            // InternalSM2.g:2723:3: (kw= '[]' | (kw= '[' (this_SINGLENUMBER_2= RULE_SINGLENUMBER | this_INTEGER_3= RULE_INTEGER ) kw= ']' ) ) (kw= '[]' | (kw= '[' (this_SINGLENUMBER_7= RULE_SINGLENUMBER | this_INTEGER_8= RULE_INTEGER ) kw= ']' ) )*
            {
            // InternalSM2.g:2723:3: (kw= '[]' | (kw= '[' (this_SINGLENUMBER_2= RULE_SINGLENUMBER | this_INTEGER_3= RULE_INTEGER ) kw= ']' ) )
            int alt96=2;
            int LA96_0 = input.LA(1);

            if ( (LA96_0==83) ) {
                alt96=1;
            }
            else if ( (LA96_0==84) ) {
                alt96=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 96, 0, input);

                throw nvae;
            }
            switch (alt96) {
                case 1 :
                    // InternalSM2.g:2724:4: kw= '[]'
                    {
                    kw=(Token)match(input,83,FOLLOW_56); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current.merge(kw);
                      				newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_0_0());
                      			
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2730:4: (kw= '[' (this_SINGLENUMBER_2= RULE_SINGLENUMBER | this_INTEGER_3= RULE_INTEGER ) kw= ']' )
                    {
                    // InternalSM2.g:2730:4: (kw= '[' (this_SINGLENUMBER_2= RULE_SINGLENUMBER | this_INTEGER_3= RULE_INTEGER ) kw= ']' )
                    // InternalSM2.g:2731:5: kw= '[' (this_SINGLENUMBER_2= RULE_SINGLENUMBER | this_INTEGER_3= RULE_INTEGER ) kw= ']'
                    {
                    kw=(Token)match(input,84,FOLLOW_57); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					current.merge(kw);
                      					newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_0_1_0());
                      				
                    }
                    // InternalSM2.g:2736:5: (this_SINGLENUMBER_2= RULE_SINGLENUMBER | this_INTEGER_3= RULE_INTEGER )
                    int alt95=2;
                    int LA95_0 = input.LA(1);

                    if ( (LA95_0==RULE_SINGLENUMBER) ) {
                        alt95=1;
                    }
                    else if ( (LA95_0==RULE_INTEGER) ) {
                        alt95=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 95, 0, input);

                        throw nvae;
                    }
                    switch (alt95) {
                        case 1 :
                            // InternalSM2.g:2737:6: this_SINGLENUMBER_2= RULE_SINGLENUMBER
                            {
                            this_SINGLENUMBER_2=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_58); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current.merge(this_SINGLENUMBER_2);
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_SINGLENUMBER_2, grammarAccess.getArrayAccess().getSINGLENUMBERTerminalRuleCall_0_1_1_0());
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:2745:6: this_INTEGER_3= RULE_INTEGER
                            {
                            this_INTEGER_3=(Token)match(input,RULE_INTEGER,FOLLOW_58); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current.merge(this_INTEGER_3);
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_INTEGER_3, grammarAccess.getArrayAccess().getINTEGERTerminalRuleCall_0_1_1_1());
                              					
                            }

                            }
                            break;

                    }

                    kw=(Token)match(input,85,FOLLOW_56); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					current.merge(kw);
                      					newLeafNode(kw, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_0_1_2());
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2760:3: (kw= '[]' | (kw= '[' (this_SINGLENUMBER_7= RULE_SINGLENUMBER | this_INTEGER_8= RULE_INTEGER ) kw= ']' ) )*
            loop98:
            do {
                int alt98=3;
                int LA98_0 = input.LA(1);

                if ( (LA98_0==83) ) {
                    alt98=1;
                }
                else if ( (LA98_0==84) ) {
                    alt98=2;
                }


                switch (alt98) {
            	case 1 :
            	    // InternalSM2.g:2761:4: kw= '[]'
            	    {
            	    kw=(Token)match(input,83,FOLLOW_56); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      				current.merge(kw);
            	      				newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_1_0());
            	      			
            	    }

            	    }
            	    break;
            	case 2 :
            	    // InternalSM2.g:2767:4: (kw= '[' (this_SINGLENUMBER_7= RULE_SINGLENUMBER | this_INTEGER_8= RULE_INTEGER ) kw= ']' )
            	    {
            	    // InternalSM2.g:2767:4: (kw= '[' (this_SINGLENUMBER_7= RULE_SINGLENUMBER | this_INTEGER_8= RULE_INTEGER ) kw= ']' )
            	    // InternalSM2.g:2768:5: kw= '[' (this_SINGLENUMBER_7= RULE_SINGLENUMBER | this_INTEGER_8= RULE_INTEGER ) kw= ']'
            	    {
            	    kw=(Token)match(input,84,FOLLOW_57); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					current.merge(kw);
            	      					newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_1_1_0());
            	      				
            	    }
            	    // InternalSM2.g:2773:5: (this_SINGLENUMBER_7= RULE_SINGLENUMBER | this_INTEGER_8= RULE_INTEGER )
            	    int alt97=2;
            	    int LA97_0 = input.LA(1);

            	    if ( (LA97_0==RULE_SINGLENUMBER) ) {
            	        alt97=1;
            	    }
            	    else if ( (LA97_0==RULE_INTEGER) ) {
            	        alt97=2;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return current;}
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 97, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt97) {
            	        case 1 :
            	            // InternalSM2.g:2774:6: this_SINGLENUMBER_7= RULE_SINGLENUMBER
            	            {
            	            this_SINGLENUMBER_7=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_58); if (state.failed) return current;
            	            if ( state.backtracking==0 ) {

            	              						current.merge(this_SINGLENUMBER_7);
            	              					
            	            }
            	            if ( state.backtracking==0 ) {

            	              						newLeafNode(this_SINGLENUMBER_7, grammarAccess.getArrayAccess().getSINGLENUMBERTerminalRuleCall_1_1_1_0());
            	              					
            	            }

            	            }
            	            break;
            	        case 2 :
            	            // InternalSM2.g:2782:6: this_INTEGER_8= RULE_INTEGER
            	            {
            	            this_INTEGER_8=(Token)match(input,RULE_INTEGER,FOLLOW_58); if (state.failed) return current;
            	            if ( state.backtracking==0 ) {

            	              						current.merge(this_INTEGER_8);
            	              					
            	            }
            	            if ( state.backtracking==0 ) {

            	              						newLeafNode(this_INTEGER_8, grammarAccess.getArrayAccess().getINTEGERTerminalRuleCall_1_1_1_1());
            	              					
            	            }

            	            }
            	            break;

            	    }

            	    kw=(Token)match(input,85,FOLLOW_56); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					current.merge(kw);
            	      					newLeafNode(kw, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_1_1_2());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop98;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArray"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:2801:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // InternalSM2.g:2801:49: (iv_ruleProperty= ruleProperty EOF )
            // InternalSM2.g:2802:2: iv_ruleProperty= ruleProperty EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleProperty=ruleProperty();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleProperty; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:2808:1: ruleProperty returns [EObject current=null] : (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        EObject this_PropertyString_0 = null;

        EObject this_PropertyInteger_1 = null;

        EObject this_PropertyFloat_2 = null;

        EObject this_PropertyAddress_3 = null;

        EObject this_PropertyBoolean_4 = null;

        EObject this_PropertyBytes_5 = null;

        EObject this_PropertyStruct_6 = null;



        	enterRule();

        try {
            // InternalSM2.g:2814:2: ( (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct ) )
            // InternalSM2.g:2815:2: (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct )
            {
            // InternalSM2.g:2815:2: (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct )
            int alt99=7;
            switch ( input.LA(1) ) {
            case 78:
                {
                alt99=1;
                }
                break;
            case 88:
            case 89:
            case 90:
            case 91:
            case 92:
            case 93:
            case 94:
            case 95:
            case 96:
            case 97:
            case 98:
            case 99:
                {
                alt99=2;
                }
                break;
            case 80:
                {
                alt99=3;
                }
                break;
            case 77:
            case 101:
                {
                alt99=4;
                }
                break;
            case 100:
                {
                alt99=5;
                }
                break;
            case 102:
            case 103:
            case 104:
            case 105:
            case 106:
            case 107:
            case 108:
            case 109:
            case 110:
            case 111:
                {
                alt99=6;
                }
                break;
            case RULE_ID:
                {
                alt99=7;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 99, 0, input);

                throw nvae;
            }

            switch (alt99) {
                case 1 :
                    // InternalSM2.g:2816:3: this_PropertyString_0= rulePropertyString
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyStringParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyString_0=rulePropertyString();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyString_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2825:3: this_PropertyInteger_1= rulePropertyInteger
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyIntegerParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyInteger_1=rulePropertyInteger();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyInteger_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2834:3: this_PropertyFloat_2= rulePropertyFloat
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyFloatParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyFloat_2=rulePropertyFloat();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyFloat_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:2843:3: this_PropertyAddress_3= rulePropertyAddress
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyAddressParserRuleCall_3());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyAddress_3=rulePropertyAddress();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyAddress_3;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:2852:3: this_PropertyBoolean_4= rulePropertyBoolean
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyBooleanParserRuleCall_4());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyBoolean_4=rulePropertyBoolean();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyBoolean_4;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 6 :
                    // InternalSM2.g:2861:3: this_PropertyBytes_5= rulePropertyBytes
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyBytesParserRuleCall_5());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyBytes_5=rulePropertyBytes();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyBytes_5;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 7 :
                    // InternalSM2.g:2870:3: this_PropertyStruct_6= rulePropertyStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyStructParserRuleCall_6());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyStruct_6=rulePropertyStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyStruct_6;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRulePropertyString"
    // InternalSM2.g:2882:1: entryRulePropertyString returns [EObject current=null] : iv_rulePropertyString= rulePropertyString EOF ;
    public final EObject entryRulePropertyString() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyString = null;


        try {
            // InternalSM2.g:2882:55: (iv_rulePropertyString= rulePropertyString EOF )
            // InternalSM2.g:2883:2: iv_rulePropertyString= rulePropertyString EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyStringRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyString=rulePropertyString();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyString; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyString"


    // $ANTLR start "rulePropertyString"
    // InternalSM2.g:2889:1: rulePropertyString returns [EObject current=null] : ( ( (lv_type_0_0= 'string' ) ) ( ( (lv_storageData_1_0= 'memory' ) ) | otherlv_2= 'storage' )? (otherlv_3= '=' ( (lv_inicialization_4_0= RULE_STRING ) ) )? this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject rulePropertyString() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token lv_storageData_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_inicialization_4_0=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;


        	enterRule();

        try {
            // InternalSM2.g:2895:2: ( ( ( (lv_type_0_0= 'string' ) ) ( ( (lv_storageData_1_0= 'memory' ) ) | otherlv_2= 'storage' )? (otherlv_3= '=' ( (lv_inicialization_4_0= RULE_STRING ) ) )? this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:2896:2: ( ( (lv_type_0_0= 'string' ) ) ( ( (lv_storageData_1_0= 'memory' ) ) | otherlv_2= 'storage' )? (otherlv_3= '=' ( (lv_inicialization_4_0= RULE_STRING ) ) )? this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:2896:2: ( ( (lv_type_0_0= 'string' ) ) ( ( (lv_storageData_1_0= 'memory' ) ) | otherlv_2= 'storage' )? (otherlv_3= '=' ( (lv_inicialization_4_0= RULE_STRING ) ) )? this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:2897:3: ( (lv_type_0_0= 'string' ) ) ( ( (lv_storageData_1_0= 'memory' ) ) | otherlv_2= 'storage' )? (otherlv_3= '=' ( (lv_inicialization_4_0= RULE_STRING ) ) )? this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )?
            {
            // InternalSM2.g:2897:3: ( (lv_type_0_0= 'string' ) )
            // InternalSM2.g:2898:4: (lv_type_0_0= 'string' )
            {
            // InternalSM2.g:2898:4: (lv_type_0_0= 'string' )
            // InternalSM2.g:2899:5: lv_type_0_0= 'string'
            {
            lv_type_0_0=(Token)match(input,78,FOLLOW_59); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_type_0_0, grammarAccess.getPropertyStringAccess().getTypeStringKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyStringRule());
              					}
              					setWithLastConsumed(current, "type", lv_type_0_0, "string");
              				
            }

            }


            }

            // InternalSM2.g:2911:3: ( ( (lv_storageData_1_0= 'memory' ) ) | otherlv_2= 'storage' )?
            int alt100=3;
            int LA100_0 = input.LA(1);

            if ( (LA100_0==86) ) {
                alt100=1;
            }
            else if ( (LA100_0==87) ) {
                alt100=2;
            }
            switch (alt100) {
                case 1 :
                    // InternalSM2.g:2912:4: ( (lv_storageData_1_0= 'memory' ) )
                    {
                    // InternalSM2.g:2912:4: ( (lv_storageData_1_0= 'memory' ) )
                    // InternalSM2.g:2913:5: (lv_storageData_1_0= 'memory' )
                    {
                    // InternalSM2.g:2913:5: (lv_storageData_1_0= 'memory' )
                    // InternalSM2.g:2914:6: lv_storageData_1_0= 'memory'
                    {
                    lv_storageData_1_0=(Token)match(input,86,FOLLOW_48); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_storageData_1_0, grammarAccess.getPropertyStringAccess().getStorageDataMemoryKeyword_1_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyStringRule());
                      						}
                      						setWithLastConsumed(current, "storageData", lv_storageData_1_0, "memory");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2927:4: otherlv_2= 'storage'
                    {
                    otherlv_2=(Token)match(input,87,FOLLOW_48); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getPropertyStringAccess().getStorageKeyword_1_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:2932:3: (otherlv_3= '=' ( (lv_inicialization_4_0= RULE_STRING ) ) )?
            int alt101=2;
            int LA101_0 = input.LA(1);

            if ( (LA101_0==79) ) {
                alt101=1;
            }
            switch (alt101) {
                case 1 :
                    // InternalSM2.g:2933:4: otherlv_3= '=' ( (lv_inicialization_4_0= RULE_STRING ) )
                    {
                    otherlv_3=(Token)match(input,79,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_3, grammarAccess.getPropertyStringAccess().getEqualsSignKeyword_2_0());
                      			
                    }
                    // InternalSM2.g:2937:4: ( (lv_inicialization_4_0= RULE_STRING ) )
                    // InternalSM2.g:2938:5: (lv_inicialization_4_0= RULE_STRING )
                    {
                    // InternalSM2.g:2938:5: (lv_inicialization_4_0= RULE_STRING )
                    // InternalSM2.g:2939:6: lv_inicialization_4_0= RULE_STRING
                    {
                    lv_inicialization_4_0=(Token)match(input,RULE_STRING,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_inicialization_4_0, grammarAccess.getPropertyStringAccess().getInicializationSTRINGTerminalRuleCall_2_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyStringRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"inicialization",
                      							lv_inicialization_4_0,
                      							"org.eclipse.xtext.common.Terminals.STRING");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_5, grammarAccess.getPropertyStringAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:2960:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt102=2;
            int LA102_0 = input.LA(1);

            if ( (LA102_0==RULE_EOLINE) ) {
                alt102=1;
            }
            switch (alt102) {
                case 1 :
                    // InternalSM2.g:2961:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getPropertyStringAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyString"


    // $ANTLR start "entryRulePropertyInteger"
    // InternalSM2.g:2970:1: entryRulePropertyInteger returns [EObject current=null] : iv_rulePropertyInteger= rulePropertyInteger EOF ;
    public final EObject entryRulePropertyInteger() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyInteger = null;


        try {
            // InternalSM2.g:2970:56: (iv_rulePropertyInteger= rulePropertyInteger EOF )
            // InternalSM2.g:2971:2: iv_rulePropertyInteger= rulePropertyInteger EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyIntegerRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyInteger=rulePropertyInteger();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyInteger; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyInteger"


    // $ANTLR start "rulePropertyInteger"
    // InternalSM2.g:2977:1: rulePropertyInteger returns [EObject current=null] : ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) ( (lv_operator_4_0= ruleAssignmentOperator ) ) ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyInteger() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_1=null;
        Token lv_type_0_2=null;
        Token lv_type_0_3=null;
        Token lv_type_0_4=null;
        Token lv_type_0_5=null;
        Token lv_type_0_6=null;
        Token lv_type_0_7=null;
        Token lv_type_0_8=null;
        Token lv_type_0_9=null;
        Token lv_type_0_10=null;
        Token lv_type_0_11=null;
        Token lv_type_0_12=null;
        Token lv_nameProperty_3_0=null;
        Token lv_inicialization_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;

        Enumerator lv_operator_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2983:2: ( ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) ( (lv_operator_4_0= ruleAssignmentOperator ) ) ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2984:2: ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) ( (lv_operator_4_0= ruleAssignmentOperator ) ) ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2984:2: ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) ( (lv_operator_4_0= ruleAssignmentOperator ) ) ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2985:3: ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) ( (lv_operator_4_0= ruleAssignmentOperator ) ) ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:2985:3: ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) ) )
            // InternalSM2.g:2986:4: ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) )
            {
            // InternalSM2.g:2986:4: ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) )
            // InternalSM2.g:2987:5: (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' )
            {
            // InternalSM2.g:2987:5: (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' )
            int alt103=12;
            switch ( input.LA(1) ) {
            case 88:
                {
                alt103=1;
                }
                break;
            case 89:
                {
                alt103=2;
                }
                break;
            case 90:
                {
                alt103=3;
                }
                break;
            case 91:
                {
                alt103=4;
                }
                break;
            case 92:
                {
                alt103=5;
                }
                break;
            case 93:
                {
                alt103=6;
                }
                break;
            case 94:
                {
                alt103=7;
                }
                break;
            case 95:
                {
                alt103=8;
                }
                break;
            case 96:
                {
                alt103=9;
                }
                break;
            case 97:
                {
                alt103=10;
                }
                break;
            case 98:
                {
                alt103=11;
                }
                break;
            case 99:
                {
                alt103=12;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 103, 0, input);

                throw nvae;
            }

            switch (alt103) {
                case 1 :
                    // InternalSM2.g:2988:6: lv_type_0_1= 'int'
                    {
                    lv_type_0_1=(Token)match(input,88,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_1, grammarAccess.getPropertyIntegerAccess().getTypeIntKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2999:6: lv_type_0_2= 'uint'
                    {
                    lv_type_0_2=(Token)match(input,89,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_2, grammarAccess.getPropertyIntegerAccess().getTypeUintKeyword_0_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_2, null);
                      					
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:3010:6: lv_type_0_3= 'uint2'
                    {
                    lv_type_0_3=(Token)match(input,90,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_3, grammarAccess.getPropertyIntegerAccess().getTypeUint2Keyword_0_0_2());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_3, null);
                      					
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:3021:6: lv_type_0_4= 'uint4'
                    {
                    lv_type_0_4=(Token)match(input,91,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_4, grammarAccess.getPropertyIntegerAccess().getTypeUint4Keyword_0_0_3());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_4, null);
                      					
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:3032:6: lv_type_0_5= 'uint8'
                    {
                    lv_type_0_5=(Token)match(input,92,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_5, grammarAccess.getPropertyIntegerAccess().getTypeUint8Keyword_0_0_4());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_5, null);
                      					
                    }

                    }
                    break;
                case 6 :
                    // InternalSM2.g:3043:6: lv_type_0_6= 'uint16'
                    {
                    lv_type_0_6=(Token)match(input,93,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_6, grammarAccess.getPropertyIntegerAccess().getTypeUint16Keyword_0_0_5());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_6, null);
                      					
                    }

                    }
                    break;
                case 7 :
                    // InternalSM2.g:3054:6: lv_type_0_7= 'uint24'
                    {
                    lv_type_0_7=(Token)match(input,94,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_7, grammarAccess.getPropertyIntegerAccess().getTypeUint24Keyword_0_0_6());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_7, null);
                      					
                    }

                    }
                    break;
                case 8 :
                    // InternalSM2.g:3065:6: lv_type_0_8= 'uint32'
                    {
                    lv_type_0_8=(Token)match(input,95,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_8, grammarAccess.getPropertyIntegerAccess().getTypeUint32Keyword_0_0_7());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_8, null);
                      					
                    }

                    }
                    break;
                case 9 :
                    // InternalSM2.g:3076:6: lv_type_0_9= 'uint64'
                    {
                    lv_type_0_9=(Token)match(input,96,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_9, grammarAccess.getPropertyIntegerAccess().getTypeUint64Keyword_0_0_8());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_9, null);
                      					
                    }

                    }
                    break;
                case 10 :
                    // InternalSM2.g:3087:6: lv_type_0_10= 'uint128'
                    {
                    lv_type_0_10=(Token)match(input,97,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_10, grammarAccess.getPropertyIntegerAccess().getTypeUint128Keyword_0_0_9());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_10, null);
                      					
                    }

                    }
                    break;
                case 11 :
                    // InternalSM2.g:3098:6: lv_type_0_11= 'uint160'
                    {
                    lv_type_0_11=(Token)match(input,98,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_11, grammarAccess.getPropertyIntegerAccess().getTypeUint160Keyword_0_0_10());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_11, null);
                      					
                    }

                    }
                    break;
                case 12 :
                    // InternalSM2.g:3109:6: lv_type_0_12= 'uint256'
                    {
                    lv_type_0_12=(Token)match(input,99,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_12, grammarAccess.getPropertyIntegerAccess().getTypeUint256Keyword_0_0_11());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_12, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:3122:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt104=2;
            int LA104_0 = input.LA(1);

            if ( ((LA104_0>=83 && LA104_0<=84)) ) {
                alt104=1;
            }
            switch (alt104) {
                case 1 :
                    // InternalSM2.g:3123:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3123:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3124:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyIntegerAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_40);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyIntegerRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3141:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt105=2;
            int LA105_0 = input.LA(1);

            if ( ((LA105_0>=68 && LA105_0<=69)||(LA105_0>=123 && LA105_0<=124)) ) {
                alt105=1;
            }
            switch (alt105) {
                case 1 :
                    // InternalSM2.g:3142:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3142:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3143:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyIntegerAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_5);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyIntegerRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3160:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:3161:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:3161:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:3162:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_61); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyIntegerAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyIntegerRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3178:3: ( (lv_operator_4_0= ruleAssignmentOperator ) )
            // InternalSM2.g:3179:4: (lv_operator_4_0= ruleAssignmentOperator )
            {
            // InternalSM2.g:3179:4: (lv_operator_4_0= ruleAssignmentOperator )
            // InternalSM2.g:3180:5: lv_operator_4_0= ruleAssignmentOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getPropertyIntegerAccess().getOperatorAssignmentOperatorEnumRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_62);
            lv_operator_4_0=ruleAssignmentOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getPropertyIntegerRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_4_0,
              						"org.xtext.SM2.AssignmentOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3197:3: ( (lv_inicialization_5_0= RULE_INTEGER ) )?
            int alt106=2;
            int LA106_0 = input.LA(1);

            if ( (LA106_0==RULE_INTEGER) ) {
                alt106=1;
            }
            switch (alt106) {
                case 1 :
                    // InternalSM2.g:3198:4: (lv_inicialization_5_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:3198:4: (lv_inicialization_5_0= RULE_INTEGER )
                    // InternalSM2.g:3199:5: lv_inicialization_5_0= RULE_INTEGER
                    {
                    lv_inicialization_5_0=(Token)match(input,RULE_INTEGER,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_inicialization_5_0, grammarAccess.getPropertyIntegerAccess().getInicializationINTEGERTerminalRuleCall_5_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"inicialization",
                      						lv_inicialization_5_0,
                      						"org.xtext.SM2.INTEGER");
                      				
                    }

                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyIntegerAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:3219:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt107=2;
            int LA107_0 = input.LA(1);

            if ( (LA107_0==RULE_EOLINE) ) {
                alt107=1;
            }
            switch (alt107) {
                case 1 :
                    // InternalSM2.g:3220:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyIntegerAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyInteger"


    // $ANTLR start "entryRulePropertyFloat"
    // InternalSM2.g:3229:1: entryRulePropertyFloat returns [EObject current=null] : iv_rulePropertyFloat= rulePropertyFloat EOF ;
    public final EObject entryRulePropertyFloat() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyFloat = null;


        try {
            // InternalSM2.g:3229:54: (iv_rulePropertyFloat= rulePropertyFloat EOF )
            // InternalSM2.g:3230:2: iv_rulePropertyFloat= rulePropertyFloat EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyFloatRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyFloat=rulePropertyFloat();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyFloat; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyFloat"


    // $ANTLR start "rulePropertyFloat"
    // InternalSM2.g:3236:1: rulePropertyFloat returns [EObject current=null] : ( ( (lv_type_0_0= 'float' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) ( ( (lv_operator_6_0= ruleAssignmentOperator ) ) ( (lv_inicialization_7_0= RULE_FLOAT ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) ;
    public final EObject rulePropertyFloat() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token lv_storageData_3_0=null;
        Token otherlv_4=null;
        Token lv_nameProperty_5_0=null;
        Token lv_inicialization_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;

        Enumerator lv_operator_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3242:2: ( ( ( (lv_type_0_0= 'float' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) ( ( (lv_operator_6_0= ruleAssignmentOperator ) ) ( (lv_inicialization_7_0= RULE_FLOAT ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) )
            // InternalSM2.g:3243:2: ( ( (lv_type_0_0= 'float' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) ( ( (lv_operator_6_0= ruleAssignmentOperator ) ) ( (lv_inicialization_7_0= RULE_FLOAT ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            {
            // InternalSM2.g:3243:2: ( ( (lv_type_0_0= 'float' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) ( ( (lv_operator_6_0= ruleAssignmentOperator ) ) ( (lv_inicialization_7_0= RULE_FLOAT ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            // InternalSM2.g:3244:3: ( (lv_type_0_0= 'float' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) ( ( (lv_operator_6_0= ruleAssignmentOperator ) ) ( (lv_inicialization_7_0= RULE_FLOAT ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )?
            {
            // InternalSM2.g:3244:3: ( (lv_type_0_0= 'float' ) )
            // InternalSM2.g:3245:4: (lv_type_0_0= 'float' )
            {
            // InternalSM2.g:3245:4: (lv_type_0_0= 'float' )
            // InternalSM2.g:3246:5: lv_type_0_0= 'float'
            {
            lv_type_0_0=(Token)match(input,80,FOLLOW_63); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_type_0_0, grammarAccess.getPropertyFloatAccess().getTypeFloatKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyFloatRule());
              					}
              					setWithLastConsumed(current, "type", lv_type_0_0, "float");
              				
            }

            }


            }

            // InternalSM2.g:3258:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt108=2;
            int LA108_0 = input.LA(1);

            if ( ((LA108_0>=83 && LA108_0<=84)) ) {
                alt108=1;
            }
            switch (alt108) {
                case 1 :
                    // InternalSM2.g:3259:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3259:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3260:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyFloatAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_64);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyFloatRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3277:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt109=2;
            int LA109_0 = input.LA(1);

            if ( ((LA109_0>=68 && LA109_0<=69)||(LA109_0>=123 && LA109_0<=124)) ) {
                alt109=1;
            }
            switch (alt109) {
                case 1 :
                    // InternalSM2.g:3278:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3278:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3279:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyFloatAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_65);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyFloatRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3296:3: ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )?
            int alt110=3;
            int LA110_0 = input.LA(1);

            if ( (LA110_0==86) ) {
                alt110=1;
            }
            else if ( (LA110_0==87) ) {
                alt110=2;
            }
            switch (alt110) {
                case 1 :
                    // InternalSM2.g:3297:4: ( (lv_storageData_3_0= 'memory' ) )
                    {
                    // InternalSM2.g:3297:4: ( (lv_storageData_3_0= 'memory' ) )
                    // InternalSM2.g:3298:5: (lv_storageData_3_0= 'memory' )
                    {
                    // InternalSM2.g:3298:5: (lv_storageData_3_0= 'memory' )
                    // InternalSM2.g:3299:6: lv_storageData_3_0= 'memory'
                    {
                    lv_storageData_3_0=(Token)match(input,86,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_storageData_3_0, grammarAccess.getPropertyFloatAccess().getStorageDataMemoryKeyword_3_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyFloatRule());
                      						}
                      						setWithLastConsumed(current, "storageData", lv_storageData_3_0, "memory");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3312:4: otherlv_4= 'storage'
                    {
                    otherlv_4=(Token)match(input,87,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyFloatAccess().getStorageKeyword_3_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:3317:3: ( (lv_nameProperty_5_0= RULE_ID ) )
            // InternalSM2.g:3318:4: (lv_nameProperty_5_0= RULE_ID )
            {
            // InternalSM2.g:3318:4: (lv_nameProperty_5_0= RULE_ID )
            // InternalSM2.g:3319:5: lv_nameProperty_5_0= RULE_ID
            {
            lv_nameProperty_5_0=(Token)match(input,RULE_ID,FOLLOW_55); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_5_0, grammarAccess.getPropertyFloatAccess().getNamePropertyIDTerminalRuleCall_4_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyFloatRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_5_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3335:3: ( ( (lv_operator_6_0= ruleAssignmentOperator ) ) ( (lv_inicialization_7_0= RULE_FLOAT ) ) )?
            int alt111=2;
            int LA111_0 = input.LA(1);

            if ( (LA111_0==79||(LA111_0>=143 && LA111_0<=147)) ) {
                alt111=1;
            }
            switch (alt111) {
                case 1 :
                    // InternalSM2.g:3336:4: ( (lv_operator_6_0= ruleAssignmentOperator ) ) ( (lv_inicialization_7_0= RULE_FLOAT ) )
                    {
                    // InternalSM2.g:3336:4: ( (lv_operator_6_0= ruleAssignmentOperator ) )
                    // InternalSM2.g:3337:5: (lv_operator_6_0= ruleAssignmentOperator )
                    {
                    // InternalSM2.g:3337:5: (lv_operator_6_0= ruleAssignmentOperator )
                    // InternalSM2.g:3338:6: lv_operator_6_0= ruleAssignmentOperator
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getPropertyFloatAccess().getOperatorAssignmentOperatorEnumRuleCall_5_0_0());
                      					
                    }
                    pushFollow(FOLLOW_66);
                    lv_operator_6_0=ruleAssignmentOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getPropertyFloatRule());
                      						}
                      						set(
                      							current,
                      							"operator",
                      							lv_operator_6_0,
                      							"org.xtext.SM2.AssignmentOperator");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:3355:4: ( (lv_inicialization_7_0= RULE_FLOAT ) )
                    // InternalSM2.g:3356:5: (lv_inicialization_7_0= RULE_FLOAT )
                    {
                    // InternalSM2.g:3356:5: (lv_inicialization_7_0= RULE_FLOAT )
                    // InternalSM2.g:3357:6: lv_inicialization_7_0= RULE_FLOAT
                    {
                    lv_inicialization_7_0=(Token)match(input,RULE_FLOAT,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_inicialization_7_0, grammarAccess.getPropertyFloatAccess().getInicializationFLOATTerminalRuleCall_5_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyFloatRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"inicialization",
                      							lv_inicialization_7_0,
                      							"org.xtext.SM2.FLOAT");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getPropertyFloatAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:3378:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt112=2;
            int LA112_0 = input.LA(1);

            if ( (LA112_0==RULE_EOLINE) ) {
                alt112=1;
            }
            switch (alt112) {
                case 1 :
                    // InternalSM2.g:3379:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getPropertyFloatAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyFloat"


    // $ANTLR start "entryRulePropertyBoolean"
    // InternalSM2.g:3388:1: entryRulePropertyBoolean returns [EObject current=null] : iv_rulePropertyBoolean= rulePropertyBoolean EOF ;
    public final EObject entryRulePropertyBoolean() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyBoolean = null;


        try {
            // InternalSM2.g:3388:56: (iv_rulePropertyBoolean= rulePropertyBoolean EOF )
            // InternalSM2.g:3389:2: iv_rulePropertyBoolean= rulePropertyBoolean EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyBooleanRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyBoolean=rulePropertyBoolean();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyBoolean; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyBoolean"


    // $ANTLR start "rulePropertyBoolean"
    // InternalSM2.g:3395:1: rulePropertyBoolean returns [EObject current=null] : ( ( (lv_type_0_0= 'bool' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) ;
    public final EObject rulePropertyBoolean() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token lv_storageData_3_0=null;
        Token otherlv_4=null;
        Token lv_nameProperty_5_0=null;
        Token otherlv_6=null;
        Token lv_inicialization_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3401:2: ( ( ( (lv_type_0_0= 'bool' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) )
            // InternalSM2.g:3402:2: ( ( (lv_type_0_0= 'bool' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            {
            // InternalSM2.g:3402:2: ( ( (lv_type_0_0= 'bool' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            // InternalSM2.g:3403:3: ( (lv_type_0_0= 'bool' ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )?
            {
            // InternalSM2.g:3403:3: ( (lv_type_0_0= 'bool' ) )
            // InternalSM2.g:3404:4: (lv_type_0_0= 'bool' )
            {
            // InternalSM2.g:3404:4: (lv_type_0_0= 'bool' )
            // InternalSM2.g:3405:5: lv_type_0_0= 'bool'
            {
            lv_type_0_0=(Token)match(input,100,FOLLOW_63); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_type_0_0, grammarAccess.getPropertyBooleanAccess().getTypeBoolKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyBooleanRule());
              					}
              					setWithLastConsumed(current, "type", lv_type_0_0, "bool");
              				
            }

            }


            }

            // InternalSM2.g:3417:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt113=2;
            int LA113_0 = input.LA(1);

            if ( ((LA113_0>=83 && LA113_0<=84)) ) {
                alt113=1;
            }
            switch (alt113) {
                case 1 :
                    // InternalSM2.g:3418:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3418:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3419:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBooleanAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_64);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBooleanRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3436:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt114=2;
            int LA114_0 = input.LA(1);

            if ( ((LA114_0>=68 && LA114_0<=69)||(LA114_0>=123 && LA114_0<=124)) ) {
                alt114=1;
            }
            switch (alt114) {
                case 1 :
                    // InternalSM2.g:3437:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3437:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3438:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBooleanAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_65);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBooleanRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3455:3: ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )?
            int alt115=3;
            int LA115_0 = input.LA(1);

            if ( (LA115_0==86) ) {
                alt115=1;
            }
            else if ( (LA115_0==87) ) {
                alt115=2;
            }
            switch (alt115) {
                case 1 :
                    // InternalSM2.g:3456:4: ( (lv_storageData_3_0= 'memory' ) )
                    {
                    // InternalSM2.g:3456:4: ( (lv_storageData_3_0= 'memory' ) )
                    // InternalSM2.g:3457:5: (lv_storageData_3_0= 'memory' )
                    {
                    // InternalSM2.g:3457:5: (lv_storageData_3_0= 'memory' )
                    // InternalSM2.g:3458:6: lv_storageData_3_0= 'memory'
                    {
                    lv_storageData_3_0=(Token)match(input,86,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_storageData_3_0, grammarAccess.getPropertyBooleanAccess().getStorageDataMemoryKeyword_3_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBooleanRule());
                      						}
                      						setWithLastConsumed(current, "storageData", lv_storageData_3_0, "memory");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3471:4: otherlv_4= 'storage'
                    {
                    otherlv_4=(Token)match(input,87,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyBooleanAccess().getStorageKeyword_3_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:3476:3: ( (lv_nameProperty_5_0= RULE_ID ) )
            // InternalSM2.g:3477:4: (lv_nameProperty_5_0= RULE_ID )
            {
            // InternalSM2.g:3477:4: (lv_nameProperty_5_0= RULE_ID )
            // InternalSM2.g:3478:5: lv_nameProperty_5_0= RULE_ID
            {
            lv_nameProperty_5_0=(Token)match(input,RULE_ID,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_5_0, grammarAccess.getPropertyBooleanAccess().getNamePropertyIDTerminalRuleCall_4_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyBooleanRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_5_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3494:3: (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_BOOLVALUE ) ) )?
            int alt116=2;
            int LA116_0 = input.LA(1);

            if ( (LA116_0==79) ) {
                alt116=1;
            }
            switch (alt116) {
                case 1 :
                    // InternalSM2.g:3495:4: otherlv_6= '=' ( (lv_inicialization_7_0= RULE_BOOLVALUE ) )
                    {
                    otherlv_6=(Token)match(input,79,FOLLOW_67); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_6, grammarAccess.getPropertyBooleanAccess().getEqualsSignKeyword_5_0());
                      			
                    }
                    // InternalSM2.g:3499:4: ( (lv_inicialization_7_0= RULE_BOOLVALUE ) )
                    // InternalSM2.g:3500:5: (lv_inicialization_7_0= RULE_BOOLVALUE )
                    {
                    // InternalSM2.g:3500:5: (lv_inicialization_7_0= RULE_BOOLVALUE )
                    // InternalSM2.g:3501:6: lv_inicialization_7_0= RULE_BOOLVALUE
                    {
                    lv_inicialization_7_0=(Token)match(input,RULE_BOOLVALUE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_inicialization_7_0, grammarAccess.getPropertyBooleanAccess().getInicializationBOOLVALUETerminalRuleCall_5_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBooleanRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"inicialization",
                      							lv_inicialization_7_0,
                      							"org.xtext.SM2.BOOLVALUE");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getPropertyBooleanAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:3522:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt117=2;
            int LA117_0 = input.LA(1);

            if ( (LA117_0==RULE_EOLINE) ) {
                alt117=1;
            }
            switch (alt117) {
                case 1 :
                    // InternalSM2.g:3523:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getPropertyBooleanAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyBoolean"


    // $ANTLR start "entryRulePropertyAddress"
    // InternalSM2.g:3532:1: entryRulePropertyAddress returns [EObject current=null] : iv_rulePropertyAddress= rulePropertyAddress EOF ;
    public final EObject entryRulePropertyAddress() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyAddress = null;


        try {
            // InternalSM2.g:3532:56: (iv_rulePropertyAddress= rulePropertyAddress EOF )
            // InternalSM2.g:3533:2: iv_rulePropertyAddress= rulePropertyAddress EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyAddressRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyAddress=rulePropertyAddress();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyAddress; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyAddress"


    // $ANTLR start "rulePropertyAddress"
    // InternalSM2.g:3539:1: rulePropertyAddress returns [EObject current=null] : ( ( ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyAddress() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_1=null;
        Token lv_type_0_2=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;

        EObject lv_inicialization_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3545:2: ( ( ( ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:3546:2: ( ( ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:3546:2: ( ( ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:3547:3: ( ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:3547:3: ( ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) ) )
            // InternalSM2.g:3548:4: ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) )
            {
            // InternalSM2.g:3548:4: ( (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' ) )
            // InternalSM2.g:3549:5: (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' )
            {
            // InternalSM2.g:3549:5: (lv_type_0_1= 'address' | lv_type_0_2= 'address payable' )
            int alt118=2;
            int LA118_0 = input.LA(1);

            if ( (LA118_0==77) ) {
                alt118=1;
            }
            else if ( (LA118_0==101) ) {
                alt118=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 118, 0, input);

                throw nvae;
            }
            switch (alt118) {
                case 1 :
                    // InternalSM2.g:3550:6: lv_type_0_1= 'address'
                    {
                    lv_type_0_1=(Token)match(input,77,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_1, grammarAccess.getPropertyAddressAccess().getTypeAddressKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyAddressRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3561:6: lv_type_0_2= 'address payable'
                    {
                    lv_type_0_2=(Token)match(input,101,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_2, grammarAccess.getPropertyAddressAccess().getTypeAddressPayableKeyword_0_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyAddressRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_2, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:3574:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt119=2;
            int LA119_0 = input.LA(1);

            if ( ((LA119_0>=83 && LA119_0<=84)) ) {
                alt119=1;
            }
            switch (alt119) {
                case 1 :
                    // InternalSM2.g:3575:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3575:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3576:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyAddressAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_40);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3593:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt120=2;
            int LA120_0 = input.LA(1);

            if ( ((LA120_0>=68 && LA120_0<=69)||(LA120_0>=123 && LA120_0<=124)) ) {
                alt120=1;
            }
            switch (alt120) {
                case 1 :
                    // InternalSM2.g:3594:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3594:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3595:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyAddressAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_5);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3612:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:3613:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:3613:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:3614:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyAddressAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyAddressRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3630:3: (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )?
            int alt121=2;
            int LA121_0 = input.LA(1);

            if ( (LA121_0==79) ) {
                alt121=1;
            }
            switch (alt121) {
                case 1 :
                    // InternalSM2.g:3631:4: otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    {
                    otherlv_4=(Token)match(input,79,FOLLOW_24); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyAddressAccess().getEqualsSignKeyword_4_0());
                      			
                    }
                    // InternalSM2.g:3635:4: ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    // InternalSM2.g:3636:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    {
                    // InternalSM2.g:3636:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    // InternalSM2.g:3637:6: lv_inicialization_5_0= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getPropertyAddressAccess().getInicializationSyntaxExpressionParserRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_7);
                    lv_inicialization_5_0=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                      						}
                      						set(
                      							current,
                      							"inicialization",
                      							lv_inicialization_5_0,
                      							"org.xtext.SM2.SyntaxExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyAddressAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:3659:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt122=2;
            int LA122_0 = input.LA(1);

            if ( (LA122_0==RULE_EOLINE) ) {
                alt122=1;
            }
            switch (alt122) {
                case 1 :
                    // InternalSM2.g:3660:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyAddressAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyAddress"


    // $ANTLR start "entryRulePropertyBytes"
    // InternalSM2.g:3669:1: entryRulePropertyBytes returns [EObject current=null] : iv_rulePropertyBytes= rulePropertyBytes EOF ;
    public final EObject entryRulePropertyBytes() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyBytes = null;


        try {
            // InternalSM2.g:3669:54: (iv_rulePropertyBytes= rulePropertyBytes EOF )
            // InternalSM2.g:3670:2: iv_rulePropertyBytes= rulePropertyBytes EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyBytesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyBytes=rulePropertyBytes();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyBytes; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyBytes"


    // $ANTLR start "rulePropertyBytes"
    // InternalSM2.g:3676:1: rulePropertyBytes returns [EObject current=null] : ( ( ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) ;
    public final EObject rulePropertyBytes() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_1=null;
        Token lv_type_0_2=null;
        Token lv_type_0_3=null;
        Token lv_type_0_4=null;
        Token lv_type_0_5=null;
        Token lv_type_0_6=null;
        Token lv_type_0_7=null;
        Token lv_type_0_8=null;
        Token lv_type_0_9=null;
        Token lv_type_0_10=null;
        Token lv_storageData_3_0=null;
        Token otherlv_4=null;
        Token lv_nameProperty_5_0=null;
        Token otherlv_6=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;

        EObject lv_inicialization_7_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3682:2: ( ( ( ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) )
            // InternalSM2.g:3683:2: ( ( ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            {
            // InternalSM2.g:3683:2: ( ( ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            // InternalSM2.g:3684:3: ( ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )?
            {
            // InternalSM2.g:3684:3: ( ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) ) )
            // InternalSM2.g:3685:4: ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) )
            {
            // InternalSM2.g:3685:4: ( (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' ) )
            // InternalSM2.g:3686:5: (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' )
            {
            // InternalSM2.g:3686:5: (lv_type_0_1= 'bytes' | lv_type_0_2= 'bytes2' | lv_type_0_3= 'bytes3' | lv_type_0_4= 'bytes4' | lv_type_0_5= 'bytes5' | lv_type_0_6= 'bytes6' | lv_type_0_7= 'bytes7' | lv_type_0_8= 'bytes8' | lv_type_0_9= 'bytes16' | lv_type_0_10= 'bytes32' )
            int alt123=10;
            switch ( input.LA(1) ) {
            case 102:
                {
                alt123=1;
                }
                break;
            case 103:
                {
                alt123=2;
                }
                break;
            case 104:
                {
                alt123=3;
                }
                break;
            case 105:
                {
                alt123=4;
                }
                break;
            case 106:
                {
                alt123=5;
                }
                break;
            case 107:
                {
                alt123=6;
                }
                break;
            case 108:
                {
                alt123=7;
                }
                break;
            case 109:
                {
                alt123=8;
                }
                break;
            case 110:
                {
                alt123=9;
                }
                break;
            case 111:
                {
                alt123=10;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 123, 0, input);

                throw nvae;
            }

            switch (alt123) {
                case 1 :
                    // InternalSM2.g:3687:6: lv_type_0_1= 'bytes'
                    {
                    lv_type_0_1=(Token)match(input,102,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_1, grammarAccess.getPropertyBytesAccess().getTypeBytesKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3698:6: lv_type_0_2= 'bytes2'
                    {
                    lv_type_0_2=(Token)match(input,103,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_2, grammarAccess.getPropertyBytesAccess().getTypeBytes2Keyword_0_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_2, null);
                      					
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:3709:6: lv_type_0_3= 'bytes3'
                    {
                    lv_type_0_3=(Token)match(input,104,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_3, grammarAccess.getPropertyBytesAccess().getTypeBytes3Keyword_0_0_2());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_3, null);
                      					
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:3720:6: lv_type_0_4= 'bytes4'
                    {
                    lv_type_0_4=(Token)match(input,105,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_4, grammarAccess.getPropertyBytesAccess().getTypeBytes4Keyword_0_0_3());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_4, null);
                      					
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:3731:6: lv_type_0_5= 'bytes5'
                    {
                    lv_type_0_5=(Token)match(input,106,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_5, grammarAccess.getPropertyBytesAccess().getTypeBytes5Keyword_0_0_4());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_5, null);
                      					
                    }

                    }
                    break;
                case 6 :
                    // InternalSM2.g:3742:6: lv_type_0_6= 'bytes6'
                    {
                    lv_type_0_6=(Token)match(input,107,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_6, grammarAccess.getPropertyBytesAccess().getTypeBytes6Keyword_0_0_5());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_6, null);
                      					
                    }

                    }
                    break;
                case 7 :
                    // InternalSM2.g:3753:6: lv_type_0_7= 'bytes7'
                    {
                    lv_type_0_7=(Token)match(input,108,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_7, grammarAccess.getPropertyBytesAccess().getTypeBytes7Keyword_0_0_6());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_7, null);
                      					
                    }

                    }
                    break;
                case 8 :
                    // InternalSM2.g:3764:6: lv_type_0_8= 'bytes8'
                    {
                    lv_type_0_8=(Token)match(input,109,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_8, grammarAccess.getPropertyBytesAccess().getTypeBytes8Keyword_0_0_7());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_8, null);
                      					
                    }

                    }
                    break;
                case 9 :
                    // InternalSM2.g:3775:6: lv_type_0_9= 'bytes16'
                    {
                    lv_type_0_9=(Token)match(input,110,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_9, grammarAccess.getPropertyBytesAccess().getTypeBytes16Keyword_0_0_8());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_9, null);
                      					
                    }

                    }
                    break;
                case 10 :
                    // InternalSM2.g:3786:6: lv_type_0_10= 'bytes32'
                    {
                    lv_type_0_10=(Token)match(input,111,FOLLOW_63); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_0_10, grammarAccess.getPropertyBytesAccess().getTypeBytes32Keyword_0_0_9());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_0_10, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:3799:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt124=2;
            int LA124_0 = input.LA(1);

            if ( ((LA124_0>=83 && LA124_0<=84)) ) {
                alt124=1;
            }
            switch (alt124) {
                case 1 :
                    // InternalSM2.g:3800:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3800:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3801:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBytesAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_64);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3818:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt125=2;
            int LA125_0 = input.LA(1);

            if ( ((LA125_0>=68 && LA125_0<=69)||(LA125_0>=123 && LA125_0<=124)) ) {
                alt125=1;
            }
            switch (alt125) {
                case 1 :
                    // InternalSM2.g:3819:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3819:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3820:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBytesAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_65);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3837:3: ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )?
            int alt126=3;
            int LA126_0 = input.LA(1);

            if ( (LA126_0==86) ) {
                alt126=1;
            }
            else if ( (LA126_0==87) ) {
                alt126=2;
            }
            switch (alt126) {
                case 1 :
                    // InternalSM2.g:3838:4: ( (lv_storageData_3_0= 'memory' ) )
                    {
                    // InternalSM2.g:3838:4: ( (lv_storageData_3_0= 'memory' ) )
                    // InternalSM2.g:3839:5: (lv_storageData_3_0= 'memory' )
                    {
                    // InternalSM2.g:3839:5: (lv_storageData_3_0= 'memory' )
                    // InternalSM2.g:3840:6: lv_storageData_3_0= 'memory'
                    {
                    lv_storageData_3_0=(Token)match(input,86,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_storageData_3_0, grammarAccess.getPropertyBytesAccess().getStorageDataMemoryKeyword_3_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "storageData", lv_storageData_3_0, "memory");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3853:4: otherlv_4= 'storage'
                    {
                    otherlv_4=(Token)match(input,87,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyBytesAccess().getStorageKeyword_3_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:3858:3: ( (lv_nameProperty_5_0= RULE_ID ) )
            // InternalSM2.g:3859:4: (lv_nameProperty_5_0= RULE_ID )
            {
            // InternalSM2.g:3859:4: (lv_nameProperty_5_0= RULE_ID )
            // InternalSM2.g:3860:5: lv_nameProperty_5_0= RULE_ID
            {
            lv_nameProperty_5_0=(Token)match(input,RULE_ID,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_5_0, grammarAccess.getPropertyBytesAccess().getNamePropertyIDTerminalRuleCall_4_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyBytesRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_5_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3876:3: (otherlv_6= '=' ( (lv_inicialization_7_0= ruleSyntaxExpression ) ) )?
            int alt127=2;
            int LA127_0 = input.LA(1);

            if ( (LA127_0==79) ) {
                alt127=1;
            }
            switch (alt127) {
                case 1 :
                    // InternalSM2.g:3877:4: otherlv_6= '=' ( (lv_inicialization_7_0= ruleSyntaxExpression ) )
                    {
                    otherlv_6=(Token)match(input,79,FOLLOW_24); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_6, grammarAccess.getPropertyBytesAccess().getEqualsSignKeyword_5_0());
                      			
                    }
                    // InternalSM2.g:3881:4: ( (lv_inicialization_7_0= ruleSyntaxExpression ) )
                    // InternalSM2.g:3882:5: (lv_inicialization_7_0= ruleSyntaxExpression )
                    {
                    // InternalSM2.g:3882:5: (lv_inicialization_7_0= ruleSyntaxExpression )
                    // InternalSM2.g:3883:6: lv_inicialization_7_0= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getPropertyBytesAccess().getInicializationSyntaxExpressionParserRuleCall_5_1_0());
                      					
                    }
                    pushFollow(FOLLOW_7);
                    lv_inicialization_7_0=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                      						}
                      						set(
                      							current,
                      							"inicialization",
                      							lv_inicialization_7_0,
                      							"org.xtext.SM2.SyntaxExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getPropertyBytesAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:3905:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt128=2;
            int LA128_0 = input.LA(1);

            if ( (LA128_0==RULE_EOLINE) ) {
                alt128=1;
            }
            switch (alt128) {
                case 1 :
                    // InternalSM2.g:3906:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getPropertyBytesAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyBytes"


    // $ANTLR start "entryRulePropertyStruct"
    // InternalSM2.g:3915:1: entryRulePropertyStruct returns [EObject current=null] : iv_rulePropertyStruct= rulePropertyStruct EOF ;
    public final EObject entryRulePropertyStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyStruct = null;


        try {
            // InternalSM2.g:3915:55: (iv_rulePropertyStruct= rulePropertyStruct EOF )
            // InternalSM2.g:3916:2: iv_rulePropertyStruct= rulePropertyStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyStruct=rulePropertyStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyStruct"


    // $ANTLR start "rulePropertyStruct"
    // InternalSM2.g:3922:1: rulePropertyStruct returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;

        EObject lv_inicialization_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3928:2: ( ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:3929:2: ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:3929:2: ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:3930:3: ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:3930:3: ( (otherlv_0= RULE_ID ) )
            // InternalSM2.g:3931:4: (otherlv_0= RULE_ID )
            {
            // InternalSM2.g:3931:4: (otherlv_0= RULE_ID )
            // InternalSM2.g:3932:5: otherlv_0= RULE_ID
            {
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyStructRule());
              					}
              				
            }
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_60); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(otherlv_0, grammarAccess.getPropertyStructAccess().getAssignedStructStructCrossReference_0_0());
              				
            }

            }


            }

            // InternalSM2.g:3943:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt129=2;
            int LA129_0 = input.LA(1);

            if ( ((LA129_0>=83 && LA129_0<=84)) ) {
                alt129=1;
            }
            switch (alt129) {
                case 1 :
                    // InternalSM2.g:3944:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3944:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3945:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyStructAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_40);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyStructRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3962:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt130=2;
            int LA130_0 = input.LA(1);

            if ( ((LA130_0>=68 && LA130_0<=69)||(LA130_0>=123 && LA130_0<=124)) ) {
                alt130=1;
            }
            switch (alt130) {
                case 1 :
                    // InternalSM2.g:3963:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3963:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3964:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyStructAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_5);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyStructRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3981:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:3982:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:3982:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:3983:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyStructAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyStructRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:3999:3: (otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) ) )?
            int alt131=2;
            int LA131_0 = input.LA(1);

            if ( (LA131_0==79) ) {
                alt131=1;
            }
            switch (alt131) {
                case 1 :
                    // InternalSM2.g:4000:4: otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    {
                    otherlv_4=(Token)match(input,79,FOLLOW_24); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_4, grammarAccess.getPropertyStructAccess().getEqualsSignKeyword_4_0());
                      			
                    }
                    // InternalSM2.g:4004:4: ( (lv_inicialization_5_0= ruleSyntaxExpression ) )
                    // InternalSM2.g:4005:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    {
                    // InternalSM2.g:4005:5: (lv_inicialization_5_0= ruleSyntaxExpression )
                    // InternalSM2.g:4006:6: lv_inicialization_5_0= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getPropertyStructAccess().getInicializationSyntaxExpressionParserRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_7);
                    lv_inicialization_5_0=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getPropertyStructRule());
                      						}
                      						set(
                      							current,
                      							"inicialization",
                      							lv_inicialization_5_0,
                      							"org.xtext.SM2.SyntaxExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyStructAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:4028:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt132=2;
            int LA132_0 = input.LA(1);

            if ( (LA132_0==RULE_EOLINE) ) {
                alt132=1;
            }
            switch (alt132) {
                case 1 :
                    // InternalSM2.g:4029:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyStructAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyStruct"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:4038:1: entryRuleRestriction returns [EObject current=null] : iv_ruleRestriction= ruleRestriction EOF ;
    public final EObject entryRuleRestriction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestriction = null;


        try {
            // InternalSM2.g:4038:52: (iv_ruleRestriction= ruleRestriction EOF )
            // InternalSM2.g:4039:2: iv_ruleRestriction= ruleRestriction EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRestrictionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRestriction=ruleRestriction();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRestriction; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:4045:1: ruleRestriction returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) ;
    public final EObject ruleRestriction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        EObject lv_expr1_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        EObject lv_expr2_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4051:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) )
            // InternalSM2.g:4052:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            {
            // InternalSM2.g:4052:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            // InternalSM2.g:4053:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,112,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getRestrictionAccess().getRequireKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:4061:3: ( (lv_expr1_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:4062:4: (lv_expr1_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:4062:4: (lv_expr1_2_0= ruleSyntaxExpression )
            // InternalSM2.g:4063:5: lv_expr1_2_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr1SyntaxExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_68);
            lv_expr1_2_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"expr1",
              						lv_expr1_2_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4080:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:4081:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:4081:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:4082:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_24);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4099:3: ( (lv_expr2_4_0= ruleSyntaxExpression ) )
            // InternalSM2.g:4100:4: (lv_expr2_4_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:4100:4: (lv_expr2_4_0= ruleSyntaxExpression )
            // InternalSM2.g:4101:5: lv_expr2_4_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr2SyntaxExpressionParserRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_25);
            lv_expr2_4_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"expr2",
              						lv_expr2_4_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_7, grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:4134:1: entryRuleRestrictionGas returns [EObject current=null] : iv_ruleRestrictionGas= ruleRestrictionGas EOF ;
    public final EObject entryRuleRestrictionGas() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionGas = null;


        try {
            // InternalSM2.g:4134:55: (iv_ruleRestrictionGas= ruleRestrictionGas EOF )
            // InternalSM2.g:4135:2: iv_ruleRestrictionGas= ruleRestrictionGas EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRestrictionGasRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionGas=ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRestrictionGas; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:4141:1: ruleRestrictionGas returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE ) ;
    public final EObject ruleRestrictionGas() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_amount_4_0=null;
        Token this_FLOAT_5=null;
        Token this_CLOSEPARENTHESIS_7=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        EObject lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        Enumerator lv_typeCoin_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4147:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE ) )
            // InternalSM2.g:4148:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )
            {
            // InternalSM2.g:4148:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )
            // InternalSM2.g:4149:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,112,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getRestrictionGasAccess().getRequireKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:4157:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:4158:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:4158:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2.g:4159:5: lv_expr_2_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_68);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_2_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4176:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:4177:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:4177:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:4178:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_53);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4195:3: ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT )
            int alt133=2;
            int LA133_0 = input.LA(1);

            if ( (LA133_0==RULE_INTEGER) ) {
                alt133=1;
            }
            else if ( (LA133_0==RULE_FLOAT) ) {
                alt133=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 133, 0, input);

                throw nvae;
            }
            switch (alt133) {
                case 1 :
                    // InternalSM2.g:4196:4: ( (lv_amount_4_0= RULE_INTEGER ) )
                    {
                    // InternalSM2.g:4196:4: ( (lv_amount_4_0= RULE_INTEGER ) )
                    // InternalSM2.g:4197:5: (lv_amount_4_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:4197:5: (lv_amount_4_0= RULE_INTEGER )
                    // InternalSM2.g:4198:6: lv_amount_4_0= RULE_INTEGER
                    {
                    lv_amount_4_0=(Token)match(input,RULE_INTEGER,FOLLOW_69); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_amount_4_0, grammarAccess.getRestrictionGasAccess().getAmountINTEGERTerminalRuleCall_4_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getRestrictionGasRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"amount",
                      							lv_amount_4_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4215:4: this_FLOAT_5= RULE_FLOAT
                    {
                    this_FLOAT_5=(Token)match(input,RULE_FLOAT,FOLLOW_69); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_FLOAT_5, grammarAccess.getRestrictionGasAccess().getFLOATTerminalRuleCall_4_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:4220:3: ( (lv_typeCoin_6_0= ruleCoin ) )
            // InternalSM2.g:4221:4: (lv_typeCoin_6_0= ruleCoin )
            {
            // InternalSM2.g:4221:4: (lv_typeCoin_6_0= ruleCoin )
            // InternalSM2.g:4222:5: lv_typeCoin_6_0= ruleCoin
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0());
              				
            }
            pushFollow(FOLLOW_25);
            lv_typeCoin_6_0=ruleCoin();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"typeCoin",
              						lv_typeCoin_6_0,
              						"org.xtext.SM2.Coin");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_7=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_7, grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }
            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_9, grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleFunction"
    // InternalSM2.g:4255:1: entryRuleFunction returns [EObject current=null] : iv_ruleFunction= ruleFunction EOF ;
    public final EObject entryRuleFunction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFunction = null;


        try {
            // InternalSM2.g:4255:49: (iv_ruleFunction= ruleFunction EOF )
            // InternalSM2.g:4256:2: iv_ruleFunction= ruleFunction EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getFunctionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleFunction=ruleFunction();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleFunction; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFunction"


    // $ANTLR start "ruleFunction"
    // InternalSM2.g:4262:1: ruleFunction returns [EObject current=null] : (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions ) ;
    public final EObject ruleFunction() throws RecognitionException {
        EObject current = null;

        EObject this_PredefinedFunctions_0 = null;

        EObject this_PersonalizedFunctions_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:4268:2: ( (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions ) )
            // InternalSM2.g:4269:2: (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions )
            {
            // InternalSM2.g:4269:2: (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions )
            int alt134=2;
            int LA134_0 = input.LA(1);

            if ( (LA134_0==113) ) {
                alt134=1;
            }
            else if ( (LA134_0==RULE_ID) ) {
                alt134=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 134, 0, input);

                throw nvae;
            }
            switch (alt134) {
                case 1 :
                    // InternalSM2.g:4270:3: this_PredefinedFunctions_0= rulePredefinedFunctions
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getFunctionAccess().getPredefinedFunctionsParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PredefinedFunctions_0=rulePredefinedFunctions();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PredefinedFunctions_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4279:3: this_PersonalizedFunctions_1= rulePersonalizedFunctions
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getFunctionAccess().getPersonalizedFunctionsParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PersonalizedFunctions_1=rulePersonalizedFunctions();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PersonalizedFunctions_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFunction"


    // $ANTLR start "entryRulePredefinedFunctions"
    // InternalSM2.g:4291:1: entryRulePredefinedFunctions returns [EObject current=null] : iv_rulePredefinedFunctions= rulePredefinedFunctions EOF ;
    public final EObject entryRulePredefinedFunctions() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePredefinedFunctions = null;


        try {
            // InternalSM2.g:4291:60: (iv_rulePredefinedFunctions= rulePredefinedFunctions EOF )
            // InternalSM2.g:4292:2: iv_rulePredefinedFunctions= rulePredefinedFunctions EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPredefinedFunctionsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePredefinedFunctions=rulePredefinedFunctions();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePredefinedFunctions; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePredefinedFunctions"


    // $ANTLR start "rulePredefinedFunctions"
    // InternalSM2.g:4298:1: rulePredefinedFunctions returns [EObject current=null] : this_Kill_0= ruleKill ;
    public final EObject rulePredefinedFunctions() throws RecognitionException {
        EObject current = null;

        EObject this_Kill_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4304:2: (this_Kill_0= ruleKill )
            // InternalSM2.g:4305:2: this_Kill_0= ruleKill
            {
            if ( state.backtracking==0 ) {

              		newCompositeNode(grammarAccess.getPredefinedFunctionsAccess().getKillParserRuleCall());
              	
            }
            pushFollow(FOLLOW_2);
            this_Kill_0=ruleKill();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current = this_Kill_0;
              		afterParserOrEnumRuleCall();
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePredefinedFunctions"


    // $ANTLR start "entryRulePersonalizedFunctions"
    // InternalSM2.g:4316:1: entryRulePersonalizedFunctions returns [EObject current=null] : iv_rulePersonalizedFunctions= rulePersonalizedFunctions EOF ;
    public final EObject entryRulePersonalizedFunctions() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonalizedFunctions = null;


        try {
            // InternalSM2.g:4316:62: (iv_rulePersonalizedFunctions= rulePersonalizedFunctions EOF )
            // InternalSM2.g:4317:2: iv_rulePersonalizedFunctions= rulePersonalizedFunctions EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPersonalizedFunctionsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePersonalizedFunctions=rulePersonalizedFunctions();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePersonalizedFunctions; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonalizedFunctions"


    // $ANTLR start "rulePersonalizedFunctions"
    // InternalSM2.g:4323:1: rulePersonalizedFunctions returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restriction_3_0= ruleRestriction ) )? ( (lv_restrictionGas_4_0= ruleRestrictionGas ) )? ( (lv_localAttributes_5_0= ruleAttributes ) )? ( (lv_conditions_6_0= ruleConditional ) )? ( (lv_expression_7_0= ruleExpression ) )+ (this_EOLINE_8= RULE_EOLINE )? (this_RETURN_9= RULE_RETURN ( (lv_value_10_0= RULE_ID ) ) this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE ) ;
    public final EObject rulePersonalizedFunctions() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENKEY_1=null;
        Token this_EOLINE_2=null;
        Token this_EOLINE_8=null;
        Token this_RETURN_9=null;
        Token lv_value_10_0=null;
        Token this_SEMICOLON_11=null;
        Token this_EOLINE_12=null;
        Token this_CLOSEKEY_13=null;
        Token this_EOLINE_14=null;
        EObject lv_restriction_3_0 = null;

        EObject lv_restrictionGas_4_0 = null;

        EObject lv_localAttributes_5_0 = null;

        EObject lv_conditions_6_0 = null;

        EObject lv_expression_7_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4329:2: ( ( ( (otherlv_0= RULE_ID ) ) this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restriction_3_0= ruleRestriction ) )? ( (lv_restrictionGas_4_0= ruleRestrictionGas ) )? ( (lv_localAttributes_5_0= ruleAttributes ) )? ( (lv_conditions_6_0= ruleConditional ) )? ( (lv_expression_7_0= ruleExpression ) )+ (this_EOLINE_8= RULE_EOLINE )? (this_RETURN_9= RULE_RETURN ( (lv_value_10_0= RULE_ID ) ) this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE ) )
            // InternalSM2.g:4330:2: ( ( (otherlv_0= RULE_ID ) ) this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restriction_3_0= ruleRestriction ) )? ( (lv_restrictionGas_4_0= ruleRestrictionGas ) )? ( (lv_localAttributes_5_0= ruleAttributes ) )? ( (lv_conditions_6_0= ruleConditional ) )? ( (lv_expression_7_0= ruleExpression ) )+ (this_EOLINE_8= RULE_EOLINE )? (this_RETURN_9= RULE_RETURN ( (lv_value_10_0= RULE_ID ) ) this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE )
            {
            // InternalSM2.g:4330:2: ( ( (otherlv_0= RULE_ID ) ) this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restriction_3_0= ruleRestriction ) )? ( (lv_restrictionGas_4_0= ruleRestrictionGas ) )? ( (lv_localAttributes_5_0= ruleAttributes ) )? ( (lv_conditions_6_0= ruleConditional ) )? ( (lv_expression_7_0= ruleExpression ) )+ (this_EOLINE_8= RULE_EOLINE )? (this_RETURN_9= RULE_RETURN ( (lv_value_10_0= RULE_ID ) ) this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE )
            // InternalSM2.g:4331:3: ( (otherlv_0= RULE_ID ) ) this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restriction_3_0= ruleRestriction ) )? ( (lv_restrictionGas_4_0= ruleRestrictionGas ) )? ( (lv_localAttributes_5_0= ruleAttributes ) )? ( (lv_conditions_6_0= ruleConditional ) )? ( (lv_expression_7_0= ruleExpression ) )+ (this_EOLINE_8= RULE_EOLINE )? (this_RETURN_9= RULE_RETURN ( (lv_value_10_0= RULE_ID ) ) this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE
            {
            // InternalSM2.g:4331:3: ( (otherlv_0= RULE_ID ) )
            // InternalSM2.g:4332:4: (otherlv_0= RULE_ID )
            {
            // InternalSM2.g:4332:4: (otherlv_0= RULE_ID )
            // InternalSM2.g:4333:5: otherlv_0= RULE_ID
            {
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPersonalizedFunctionsRule());
              					}
              				
            }
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(otherlv_0, grammarAccess.getPersonalizedFunctionsAccess().getHeadHeadClauseCrossReference_0_0());
              				
            }

            }


            }

            this_OPENKEY_1=(Token)match(input,RULE_OPENKEY,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_1, grammarAccess.getPersonalizedFunctionsAccess().getOPENKEYTerminalRuleCall_1());
              		
            }
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_70); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_2, grammarAccess.getPersonalizedFunctionsAccess().getEOLINETerminalRuleCall_2());
              		
            }
            // InternalSM2.g:4352:3: ( (lv_restriction_3_0= ruleRestriction ) )?
            int alt135=2;
            alt135 = dfa135.predict(input);
            switch (alt135) {
                case 1 :
                    // InternalSM2.g:4353:4: (lv_restriction_3_0= ruleRestriction )
                    {
                    // InternalSM2.g:4353:4: (lv_restriction_3_0= ruleRestriction )
                    // InternalSM2.g:4354:5: lv_restriction_3_0= ruleRestriction
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getRestrictionRestrictionParserRuleCall_3_0());
                      				
                    }
                    pushFollow(FOLLOW_70);
                    lv_restriction_3_0=ruleRestriction();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"restriction",
                      						lv_restriction_3_0,
                      						"org.xtext.SM2.Restriction");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:4371:3: ( (lv_restrictionGas_4_0= ruleRestrictionGas ) )?
            int alt136=2;
            int LA136_0 = input.LA(1);

            if ( (LA136_0==112) ) {
                alt136=1;
            }
            switch (alt136) {
                case 1 :
                    // InternalSM2.g:4372:4: (lv_restrictionGas_4_0= ruleRestrictionGas )
                    {
                    // InternalSM2.g:4372:4: (lv_restrictionGas_4_0= ruleRestrictionGas )
                    // InternalSM2.g:4373:5: lv_restrictionGas_4_0= ruleRestrictionGas
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getRestrictionGasRestrictionGasParserRuleCall_4_0());
                      				
                    }
                    pushFollow(FOLLOW_71);
                    lv_restrictionGas_4_0=ruleRestrictionGas();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"restrictionGas",
                      						lv_restrictionGas_4_0,
                      						"org.xtext.SM2.RestrictionGas");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:4390:3: ( (lv_localAttributes_5_0= ruleAttributes ) )?
            int alt137=2;
            alt137 = dfa137.predict(input);
            switch (alt137) {
                case 1 :
                    // InternalSM2.g:4391:4: (lv_localAttributes_5_0= ruleAttributes )
                    {
                    // InternalSM2.g:4391:4: (lv_localAttributes_5_0= ruleAttributes )
                    // InternalSM2.g:4392:5: lv_localAttributes_5_0= ruleAttributes
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getLocalAttributesAttributesParserRuleCall_5_0());
                      				
                    }
                    pushFollow(FOLLOW_34);
                    lv_localAttributes_5_0=ruleAttributes();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"localAttributes",
                      						lv_localAttributes_5_0,
                      						"org.xtext.SM2.Attributes");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:4409:3: ( (lv_conditions_6_0= ruleConditional ) )?
            int alt138=2;
            int LA138_0 = input.LA(1);

            if ( (LA138_0==RULE_IF) ) {
                alt138=1;
            }
            switch (alt138) {
                case 1 :
                    // InternalSM2.g:4410:4: (lv_conditions_6_0= ruleConditional )
                    {
                    // InternalSM2.g:4410:4: (lv_conditions_6_0= ruleConditional )
                    // InternalSM2.g:4411:5: lv_conditions_6_0= ruleConditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getConditionsConditionalParserRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_34);
                    lv_conditions_6_0=ruleConditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"conditions",
                      						lv_conditions_6_0,
                      						"org.xtext.SM2.Conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:4428:3: ( (lv_expression_7_0= ruleExpression ) )+
            int cnt139=0;
            loop139:
            do {
                int alt139=2;
                int LA139_0 = input.LA(1);

                if ( (LA139_0==RULE_ID||LA139_0==RULE_OPENPARENTHESIS||LA139_0==RULE_STRING||(LA139_0>=RULE_INTEGER && LA139_0<=RULE_SINGLENUMBER)||(LA139_0>=RULE_NEW && LA139_0<=RULE_DELETE)||LA139_0==50||LA139_0==56||(LA139_0>=63 && LA139_0<=64)||LA139_0==73||(LA139_0>=77 && LA139_0<=78)||(LA139_0>=88 && LA139_0<=101)||(LA139_0>=103 && LA139_0<=111)||(LA139_0>=148 && LA139_0<=149)) ) {
                    alt139=1;
                }


                switch (alt139) {
            	case 1 :
            	    // InternalSM2.g:4429:4: (lv_expression_7_0= ruleExpression )
            	    {
            	    // InternalSM2.g:4429:4: (lv_expression_7_0= ruleExpression )
            	    // InternalSM2.g:4430:5: lv_expression_7_0= ruleExpression
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getExpressionExpressionParserRuleCall_7_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_72);
            	    lv_expression_7_0=ruleExpression();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
            	      					}
            	      					add(
            	      						current,
            	      						"expression",
            	      						lv_expression_7_0,
            	      						"org.xtext.SM2.Expression");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt139 >= 1 ) break loop139;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(139, input);
                        throw eee;
                }
                cnt139++;
            } while (true);

            // InternalSM2.g:4447:3: (this_EOLINE_8= RULE_EOLINE )?
            int alt140=2;
            int LA140_0 = input.LA(1);

            if ( (LA140_0==RULE_EOLINE) ) {
                alt140=1;
            }
            switch (alt140) {
                case 1 :
                    // InternalSM2.g:4448:4: this_EOLINE_8= RULE_EOLINE
                    {
                    this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_73); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_8, grammarAccess.getPersonalizedFunctionsAccess().getEOLINETerminalRuleCall_8());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:4453:3: (this_RETURN_9= RULE_RETURN ( (lv_value_10_0= RULE_ID ) ) this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )?
            int alt141=2;
            int LA141_0 = input.LA(1);

            if ( (LA141_0==RULE_RETURN) ) {
                alt141=1;
            }
            switch (alt141) {
                case 1 :
                    // InternalSM2.g:4454:4: this_RETURN_9= RULE_RETURN ( (lv_value_10_0= RULE_ID ) ) this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE
                    {
                    this_RETURN_9=(Token)match(input,RULE_RETURN,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_RETURN_9, grammarAccess.getPersonalizedFunctionsAccess().getRETURNTerminalRuleCall_9_0());
                      			
                    }
                    // InternalSM2.g:4458:4: ( (lv_value_10_0= RULE_ID ) )
                    // InternalSM2.g:4459:5: (lv_value_10_0= RULE_ID )
                    {
                    // InternalSM2.g:4459:5: (lv_value_10_0= RULE_ID )
                    // InternalSM2.g:4460:6: lv_value_10_0= RULE_ID
                    {
                    lv_value_10_0=(Token)match(input,RULE_ID,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_value_10_0, grammarAccess.getPersonalizedFunctionsAccess().getValueIDTerminalRuleCall_9_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPersonalizedFunctionsRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"value",
                      							lv_value_10_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }

                    this_SEMICOLON_11=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_11, grammarAccess.getPersonalizedFunctionsAccess().getSEMICOLONTerminalRuleCall_9_2());
                      			
                    }
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_12, grammarAccess.getPersonalizedFunctionsAccess().getEOLINETerminalRuleCall_9_3());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_13=(Token)match(input,RULE_CLOSEKEY,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_13, grammarAccess.getPersonalizedFunctionsAccess().getCLOSEKEYTerminalRuleCall_10());
              		
            }
            this_EOLINE_14=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_14, grammarAccess.getPersonalizedFunctionsAccess().getEOLINETerminalRuleCall_11());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonalizedFunctions"


    // $ANTLR start "entryRuleKill"
    // InternalSM2.g:4497:1: entryRuleKill returns [EObject current=null] : iv_ruleKill= ruleKill EOF ;
    public final EObject entryRuleKill() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleKill = null;


        try {
            // InternalSM2.g:4497:45: (iv_ruleKill= ruleKill EOF )
            // InternalSM2.g:4498:2: iv_ruleKill= ruleKill EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getKillRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleKill=ruleKill();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleKill; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleKill"


    // $ANTLR start "ruleKill"
    // InternalSM2.g:4504:1: ruleKill returns [EObject current=null] : (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( (lv_addressValueCondition_10_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS otherlv_12= 'selfdestruct' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ( (lv_addressValue_14_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS this_SEMICOLON_16= RULE_SEMICOLON (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY ) ;
    public final EObject ruleKill() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token otherlv_3=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_IF_6=null;
        Token this_OPENPARENTHESIS_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token this_CLOSEPARENTHESIS_11=null;
        Token otherlv_12=null;
        Token this_OPENPARENTHESIS_13=null;
        Token this_CLOSEPARENTHESIS_15=null;
        Token this_SEMICOLON_16=null;
        Token this_EOLINE_17=null;
        Token this_CLOSEKEY_18=null;
        EObject lv_addressValueCondition_10_0 = null;

        EObject lv_addressValue_14_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4510:2: ( (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( (lv_addressValueCondition_10_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS otherlv_12= 'selfdestruct' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ( (lv_addressValue_14_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS this_SEMICOLON_16= RULE_SEMICOLON (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY ) )
            // InternalSM2.g:4511:2: (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( (lv_addressValueCondition_10_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS otherlv_12= 'selfdestruct' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ( (lv_addressValue_14_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS this_SEMICOLON_16= RULE_SEMICOLON (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY )
            {
            // InternalSM2.g:4511:2: (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( (lv_addressValueCondition_10_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS otherlv_12= 'selfdestruct' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ( (lv_addressValue_14_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS this_SEMICOLON_16= RULE_SEMICOLON (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY )
            // InternalSM2.g:4512:3: otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( (lv_addressValueCondition_10_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_11= RULE_CLOSEPARENTHESIS otherlv_12= 'selfdestruct' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ( (lv_addressValue_14_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS this_SEMICOLON_16= RULE_SEMICOLON (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,113,FOLLOW_74); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getKillAccess().getFunctionKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,114,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getKillAccess().getKillKeyword_1());
              		
            }
            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_33); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getKillAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:4524:3: ( (otherlv_3= RULE_ID ) )?
            int alt142=2;
            int LA142_0 = input.LA(1);

            if ( (LA142_0==RULE_ID) ) {
                alt142=1;
            }
            switch (alt142) {
                case 1 :
                    // InternalSM2.g:4525:4: (otherlv_3= RULE_ID )
                    {
                    // InternalSM2.g:4525:4: (otherlv_3= RULE_ID )
                    // InternalSM2.g:4526:5: otherlv_3= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getKillRule());
                      					}
                      				
                    }
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_3, grammarAccess.getKillAccess().getInputParamInputParamCrossReference_3_0());
                      				
                    }

                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getKillAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_75); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getKillAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            this_IF_6=(Token)match(input,RULE_IF,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_IF_6, grammarAccess.getKillAccess().getIFTerminalRuleCall_6());
              		
            }
            this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_76); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getKillAccess().getOPENPARENTHESISTerminalRuleCall_7());
              		
            }
            otherlv_8=(Token)match(input,115,FOLLOW_77); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_8, grammarAccess.getKillAccess().getMsgSenderKeyword_8());
              		
            }
            otherlv_9=(Token)match(input,116,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_9, grammarAccess.getKillAccess().getEqualsSignEqualsSignKeyword_9());
              		
            }
            // InternalSM2.g:4561:3: ( (lv_addressValueCondition_10_0= ruleSyntaxExpression ) )
            // InternalSM2.g:4562:4: (lv_addressValueCondition_10_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:4562:4: (lv_addressValueCondition_10_0= ruleSyntaxExpression )
            // InternalSM2.g:4563:5: lv_addressValueCondition_10_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getKillAccess().getAddressValueConditionSyntaxExpressionParserRuleCall_10_0());
              				
            }
            pushFollow(FOLLOW_25);
            lv_addressValueCondition_10_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getKillRule());
              					}
              					set(
              						current,
              						"addressValueCondition",
              						lv_addressValueCondition_10_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_11=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_78); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_11, grammarAccess.getKillAccess().getCLOSEPARENTHESISTerminalRuleCall_11());
              		
            }
            otherlv_12=(Token)match(input,117,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_12, grammarAccess.getKillAccess().getSelfdestructKeyword_12());
              		
            }
            this_OPENPARENTHESIS_13=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_13, grammarAccess.getKillAccess().getOPENPARENTHESISTerminalRuleCall_13());
              		
            }
            // InternalSM2.g:4592:3: ( (lv_addressValue_14_0= ruleSyntaxExpression ) )
            // InternalSM2.g:4593:4: (lv_addressValue_14_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:4593:4: (lv_addressValue_14_0= ruleSyntaxExpression )
            // InternalSM2.g:4594:5: lv_addressValue_14_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getKillAccess().getAddressValueSyntaxExpressionParserRuleCall_14_0());
              				
            }
            pushFollow(FOLLOW_25);
            lv_addressValue_14_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getKillRule());
              					}
              					set(
              						current,
              						"addressValue",
              						lv_addressValue_14_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_15=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_15, grammarAccess.getKillAccess().getCLOSEPARENTHESISTerminalRuleCall_15());
              		
            }
            this_SEMICOLON_16=(Token)match(input,RULE_SEMICOLON,FOLLOW_54); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_16, grammarAccess.getKillAccess().getSEMICOLONTerminalRuleCall_16());
              		
            }
            // InternalSM2.g:4619:3: (this_EOLINE_17= RULE_EOLINE )?
            int alt143=2;
            int LA143_0 = input.LA(1);

            if ( (LA143_0==RULE_EOLINE) ) {
                alt143=1;
            }
            switch (alt143) {
                case 1 :
                    // InternalSM2.g:4620:4: this_EOLINE_17= RULE_EOLINE
                    {
                    this_EOLINE_17=(Token)match(input,RULE_EOLINE,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_17, grammarAccess.getKillAccess().getEOLINETerminalRuleCall_17());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_18=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_18, grammarAccess.getKillAccess().getCLOSEKEYTerminalRuleCall_18());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleKill"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:4633:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // InternalSM2.g:4633:51: (iv_ruleExpression= ruleExpression EOF )
            // InternalSM2.g:4634:2: iv_ruleExpression= ruleExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:4640:1: ruleExpression returns [EObject current=null] : (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables | this_LogicalExpression_5= ruleLogicalExpression | this_CreateObjectExpression_6= ruleCreateObjectExpression | this_TypeCastingExpression_7= ruleTypeCastingExpression | this_DeleteExpression_8= ruleDeleteExpression | this_TupleExpression_9= ruleTupleExpression ) ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_ArithmethicalExpression_0 = null;

        EObject this_ArithmethicalLogicalExpression_1 = null;

        EObject this_SyntaxExpression_2 = null;

        EObject this_TimeExpression_3 = null;

        EObject this_Variables_4 = null;

        EObject this_LogicalExpression_5 = null;

        EObject this_CreateObjectExpression_6 = null;

        EObject this_TypeCastingExpression_7 = null;

        EObject this_DeleteExpression_8 = null;

        EObject this_TupleExpression_9 = null;



        	enterRule();

        try {
            // InternalSM2.g:4646:2: ( (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables | this_LogicalExpression_5= ruleLogicalExpression | this_CreateObjectExpression_6= ruleCreateObjectExpression | this_TypeCastingExpression_7= ruleTypeCastingExpression | this_DeleteExpression_8= ruleDeleteExpression | this_TupleExpression_9= ruleTupleExpression ) )
            // InternalSM2.g:4647:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables | this_LogicalExpression_5= ruleLogicalExpression | this_CreateObjectExpression_6= ruleCreateObjectExpression | this_TypeCastingExpression_7= ruleTypeCastingExpression | this_DeleteExpression_8= ruleDeleteExpression | this_TupleExpression_9= ruleTupleExpression )
            {
            // InternalSM2.g:4647:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables | this_LogicalExpression_5= ruleLogicalExpression | this_CreateObjectExpression_6= ruleCreateObjectExpression | this_TypeCastingExpression_7= ruleTypeCastingExpression | this_DeleteExpression_8= ruleDeleteExpression | this_TupleExpression_9= ruleTupleExpression )
            int alt144=10;
            alt144 = dfa144.predict(input);
            switch (alt144) {
                case 1 :
                    // InternalSM2.g:4648:3: this_ArithmethicalExpression_0= ruleArithmethicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalExpression_0=ruleArithmethicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ArithmethicalExpression_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4657:3: this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalLogicalExpressionParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalLogicalExpression_1=ruleArithmethicalLogicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ArithmethicalLogicalExpression_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:4666:3: this_SyntaxExpression_2= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_SyntaxExpression_2=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_SyntaxExpression_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:4675:3: this_TimeExpression_3= ruleTimeExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getTimeExpressionParserRuleCall_3());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_TimeExpression_3=ruleTimeExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_TimeExpression_3;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:4684:3: this_Variables_4= ruleVariables
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getVariablesParserRuleCall_4());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Variables_4=ruleVariables();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Variables_4;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 6 :
                    // InternalSM2.g:4693:3: this_LogicalExpression_5= ruleLogicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getLogicalExpressionParserRuleCall_5());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_LogicalExpression_5=ruleLogicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_LogicalExpression_5;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 7 :
                    // InternalSM2.g:4702:3: this_CreateObjectExpression_6= ruleCreateObjectExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getCreateObjectExpressionParserRuleCall_6());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_CreateObjectExpression_6=ruleCreateObjectExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_CreateObjectExpression_6;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 8 :
                    // InternalSM2.g:4711:3: this_TypeCastingExpression_7= ruleTypeCastingExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getTypeCastingExpressionParserRuleCall_7());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_TypeCastingExpression_7=ruleTypeCastingExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_TypeCastingExpression_7;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 9 :
                    // InternalSM2.g:4720:3: this_DeleteExpression_8= ruleDeleteExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getDeleteExpressionParserRuleCall_8());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_DeleteExpression_8=ruleDeleteExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_DeleteExpression_8;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 10 :
                    // InternalSM2.g:4729:3: this_TupleExpression_9= ruleTupleExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getTupleExpressionParserRuleCall_9());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_TupleExpression_9=ruleTupleExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_TupleExpression_9;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleLogicalExpression"
    // InternalSM2.g:4741:1: entryRuleLogicalExpression returns [EObject current=null] : iv_ruleLogicalExpression= ruleLogicalExpression EOF ;
    public final EObject entryRuleLogicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLogicalExpression = null;


        try {
            // InternalSM2.g:4741:58: (iv_ruleLogicalExpression= ruleLogicalExpression EOF )
            // InternalSM2.g:4742:2: iv_ruleLogicalExpression= ruleLogicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLogicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLogicalExpression=ruleLogicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLogicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLogicalExpression"


    // $ANTLR start "ruleLogicalExpression"
    // InternalSM2.g:4748:1: ruleLogicalExpression returns [EObject current=null] : ( ( (lv_operator_0_0= ruleLogicalUnaryOperator ) ) ( ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) ) ) ) ;
    public final EObject ruleLogicalExpression() throws RecognitionException {
        EObject current = null;

        EObject lv_operator_0_0 = null;

        EObject lv_expr1_1_1 = null;

        EObject lv_expr1_1_2 = null;

        EObject lv_expr1_1_3 = null;



        	enterRule();

        try {
            // InternalSM2.g:4754:2: ( ( ( (lv_operator_0_0= ruleLogicalUnaryOperator ) ) ( ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) ) ) ) )
            // InternalSM2.g:4755:2: ( ( (lv_operator_0_0= ruleLogicalUnaryOperator ) ) ( ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) ) ) )
            {
            // InternalSM2.g:4755:2: ( ( (lv_operator_0_0= ruleLogicalUnaryOperator ) ) ( ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) ) ) )
            // InternalSM2.g:4756:3: ( (lv_operator_0_0= ruleLogicalUnaryOperator ) ) ( ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) ) )
            {
            // InternalSM2.g:4756:3: ( (lv_operator_0_0= ruleLogicalUnaryOperator ) )
            // InternalSM2.g:4757:4: (lv_operator_0_0= ruleLogicalUnaryOperator )
            {
            // InternalSM2.g:4757:4: (lv_operator_0_0= ruleLogicalUnaryOperator )
            // InternalSM2.g:4758:5: lv_operator_0_0= ruleLogicalUnaryOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getLogicalExpressionAccess().getOperatorLogicalUnaryOperatorParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_79);
            lv_operator_0_0=ruleLogicalUnaryOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getLogicalExpressionRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_0_0,
              						"org.xtext.SM2.LogicalUnaryOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4775:3: ( ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) ) )
            // InternalSM2.g:4776:4: ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) )
            {
            // InternalSM2.g:4776:4: ( (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression ) )
            // InternalSM2.g:4777:5: (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression )
            {
            // InternalSM2.g:4777:5: (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression )
            int alt145=3;
            alt145 = dfa145.predict(input);
            switch (alt145) {
                case 1 :
                    // InternalSM2.g:4778:6: lv_expr1_1_1= ruleArithmethicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getLogicalExpressionAccess().getExpr1ArithmethicalExpressionParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_expr1_1_1=ruleArithmethicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getLogicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"expr1",
                      							lv_expr1_1_1,
                      							"org.xtext.SM2.ArithmethicalExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4794:6: lv_expr1_1_2= ruleArithmethicalLogicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getLogicalExpressionAccess().getExpr1ArithmethicalLogicalExpressionParserRuleCall_1_0_1());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_expr1_1_2=ruleArithmethicalLogicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getLogicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"expr1",
                      							lv_expr1_1_2,
                      							"org.xtext.SM2.ArithmethicalLogicalExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:4810:6: lv_expr1_1_3= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getLogicalExpressionAccess().getExpr1SyntaxExpressionParserRuleCall_1_0_2());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_expr1_1_3=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getLogicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"expr1",
                      							lv_expr1_1_3,
                      							"org.xtext.SM2.SyntaxExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }
                    break;

            }


            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalExpression"


    // $ANTLR start "entryRuleArithmethicalExpression"
    // InternalSM2.g:4832:1: entryRuleArithmethicalExpression returns [EObject current=null] : iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF ;
    public final EObject entryRuleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalExpression = null;


        try {
            // InternalSM2.g:4832:64: (iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF )
            // InternalSM2.g:4833:2: iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmethicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalExpression=ruleArithmethicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArithmethicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalExpression"


    // $ANTLR start "ruleArithmethicalExpression"
    // InternalSM2.g:4839:1: ruleArithmethicalExpression returns [EObject current=null] : ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( ( (lv_operatorArithmethical_4_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_5_0= ruleAssignmentOperator ) ) ) ( ( (lv_op2_6_0= RULE_INTEGER ) ) | this_FLOAT_7= RULE_FLOAT | this_ID_8= RULE_ID ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT | this_ID_12= RULE_ID ) ( ( (lv_operatorArithmethical_13_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_14_0= ruleAssignmentOperator ) ) ) ( ( (lv_op2_15_0= RULE_INTEGER ) ) | this_FLOAT_16= RULE_FLOAT | this_ID_17= RULE_ID ) (this_SEMICOLON_18= RULE_SEMICOLON this_EOLINE_19= RULE_EOLINE )? ) ) ;
    public final EObject ruleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token lv_op1_1_0=null;
        Token this_FLOAT_2=null;
        Token this_ID_3=null;
        Token lv_op2_6_0=null;
        Token this_FLOAT_7=null;
        Token this_ID_8=null;
        Token this_CLOSEPARENTHESIS_9=null;
        Token lv_op1_10_0=null;
        Token this_FLOAT_11=null;
        Token this_ID_12=null;
        Token lv_op2_15_0=null;
        Token this_FLOAT_16=null;
        Token this_ID_17=null;
        Token this_SEMICOLON_18=null;
        Token this_EOLINE_19=null;
        Enumerator lv_operatorArithmethical_4_0 = null;

        Enumerator lv_operatorAssignmentArithmethical_5_0 = null;

        Enumerator lv_operatorArithmethical_13_0 = null;

        Enumerator lv_operatorAssignmentArithmethical_14_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4845:2: ( ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( ( (lv_operatorArithmethical_4_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_5_0= ruleAssignmentOperator ) ) ) ( ( (lv_op2_6_0= RULE_INTEGER ) ) | this_FLOAT_7= RULE_FLOAT | this_ID_8= RULE_ID ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT | this_ID_12= RULE_ID ) ( ( (lv_operatorArithmethical_13_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_14_0= ruleAssignmentOperator ) ) ) ( ( (lv_op2_15_0= RULE_INTEGER ) ) | this_FLOAT_16= RULE_FLOAT | this_ID_17= RULE_ID ) (this_SEMICOLON_18= RULE_SEMICOLON this_EOLINE_19= RULE_EOLINE )? ) ) )
            // InternalSM2.g:4846:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( ( (lv_operatorArithmethical_4_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_5_0= ruleAssignmentOperator ) ) ) ( ( (lv_op2_6_0= RULE_INTEGER ) ) | this_FLOAT_7= RULE_FLOAT | this_ID_8= RULE_ID ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT | this_ID_12= RULE_ID ) ( ( (lv_operatorArithmethical_13_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_14_0= ruleAssignmentOperator ) ) ) ( ( (lv_op2_15_0= RULE_INTEGER ) ) | this_FLOAT_16= RULE_FLOAT | this_ID_17= RULE_ID ) (this_SEMICOLON_18= RULE_SEMICOLON this_EOLINE_19= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:4846:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( ( (lv_operatorArithmethical_4_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_5_0= ruleAssignmentOperator ) ) ) ( ( (lv_op2_6_0= RULE_INTEGER ) ) | this_FLOAT_7= RULE_FLOAT | this_ID_8= RULE_ID ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT | this_ID_12= RULE_ID ) ( ( (lv_operatorArithmethical_13_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_14_0= ruleAssignmentOperator ) ) ) ( ( (lv_op2_15_0= RULE_INTEGER ) ) | this_FLOAT_16= RULE_FLOAT | this_ID_17= RULE_ID ) (this_SEMICOLON_18= RULE_SEMICOLON this_EOLINE_19= RULE_EOLINE )? ) )
            int alt153=2;
            int LA153_0 = input.LA(1);

            if ( (LA153_0==RULE_OPENPARENTHESIS) ) {
                alt153=1;
            }
            else if ( (LA153_0==RULE_ID||(LA153_0>=RULE_INTEGER && LA153_0<=RULE_FLOAT)) ) {
                alt153=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 153, 0, input);

                throw nvae;
            }
            switch (alt153) {
                case 1 :
                    // InternalSM2.g:4847:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( ( (lv_operatorArithmethical_4_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_5_0= ruleAssignmentOperator ) ) ) ( ( (lv_op2_6_0= RULE_INTEGER ) ) | this_FLOAT_7= RULE_FLOAT | this_ID_8= RULE_ID ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:4847:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( ( (lv_operatorArithmethical_4_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_5_0= ruleAssignmentOperator ) ) ) ( ( (lv_op2_6_0= RULE_INTEGER ) ) | this_FLOAT_7= RULE_FLOAT | this_ID_8= RULE_ID ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:4848:4: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( ( (lv_operatorArithmethical_4_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_5_0= ruleAssignmentOperator ) ) ) ( ( (lv_op2_6_0= RULE_INTEGER ) ) | this_FLOAT_7= RULE_FLOAT | this_ID_8= RULE_ID ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS
                    {
                    this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_80); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0());
                      			
                    }
                    // InternalSM2.g:4852:4: ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID )
                    int alt146=3;
                    switch ( input.LA(1) ) {
                    case RULE_INTEGER:
                        {
                        alt146=1;
                        }
                        break;
                    case RULE_FLOAT:
                        {
                        alt146=2;
                        }
                        break;
                    case RULE_ID:
                        {
                        alt146=3;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 146, 0, input);

                        throw nvae;
                    }

                    switch (alt146) {
                        case 1 :
                            // InternalSM2.g:4853:5: ( (lv_op1_1_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4853:5: ( (lv_op1_1_0= RULE_INTEGER ) )
                            // InternalSM2.g:4854:6: (lv_op1_1_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4854:6: (lv_op1_1_0= RULE_INTEGER )
                            // InternalSM2.g:4855:7: lv_op1_1_0= RULE_INTEGER
                            {
                            lv_op1_1_0=(Token)match(input,RULE_INTEGER,FOLLOW_81); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op1_1_0, grammarAccess.getArithmethicalExpressionAccess().getOp1INTEGERTerminalRuleCall_0_1_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op1",
                              								lv_op1_1_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4872:5: this_FLOAT_2= RULE_FLOAT
                            {
                            this_FLOAT_2=(Token)match(input,RULE_FLOAT,FOLLOW_81); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_2, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_0_1_1());
                              				
                            }

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:4877:5: this_ID_3= RULE_ID
                            {
                            this_ID_3=(Token)match(input,RULE_ID,FOLLOW_81); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_ID_3, grammarAccess.getArithmethicalExpressionAccess().getIDTerminalRuleCall_0_1_2());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:4882:4: ( ( (lv_operatorArithmethical_4_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_5_0= ruleAssignmentOperator ) ) )
                    int alt147=2;
                    int LA147_0 = input.LA(1);

                    if ( ((LA147_0>=138 && LA147_0<=142)) ) {
                        alt147=1;
                    }
                    else if ( (LA147_0==79||(LA147_0>=143 && LA147_0<=147)) ) {
                        alt147=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 147, 0, input);

                        throw nvae;
                    }
                    switch (alt147) {
                        case 1 :
                            // InternalSM2.g:4883:5: ( (lv_operatorArithmethical_4_0= ruleArithmeticalOperator ) )
                            {
                            // InternalSM2.g:4883:5: ( (lv_operatorArithmethical_4_0= ruleArithmeticalOperator ) )
                            // InternalSM2.g:4884:6: (lv_operatorArithmethical_4_0= ruleArithmeticalOperator )
                            {
                            // InternalSM2.g:4884:6: (lv_operatorArithmethical_4_0= ruleArithmeticalOperator )
                            // InternalSM2.g:4885:7: lv_operatorArithmethical_4_0= ruleArithmeticalOperator
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmethicalArithmeticalOperatorEnumRuleCall_0_2_0_0());
                              						
                            }
                            pushFollow(FOLLOW_80);
                            lv_operatorArithmethical_4_0=ruleArithmeticalOperator();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							set(
                              								current,
                              								"operatorArithmethical",
                              								lv_operatorArithmethical_4_0,
                              								"org.xtext.SM2.ArithmeticalOperator");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4903:5: ( (lv_operatorAssignmentArithmethical_5_0= ruleAssignmentOperator ) )
                            {
                            // InternalSM2.g:4903:5: ( (lv_operatorAssignmentArithmethical_5_0= ruleAssignmentOperator ) )
                            // InternalSM2.g:4904:6: (lv_operatorAssignmentArithmethical_5_0= ruleAssignmentOperator )
                            {
                            // InternalSM2.g:4904:6: (lv_operatorAssignmentArithmethical_5_0= ruleAssignmentOperator )
                            // InternalSM2.g:4905:7: lv_operatorAssignmentArithmethical_5_0= ruleAssignmentOperator
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignmentArithmethicalAssignmentOperatorEnumRuleCall_0_2_1_0());
                              						
                            }
                            pushFollow(FOLLOW_80);
                            lv_operatorAssignmentArithmethical_5_0=ruleAssignmentOperator();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							set(
                              								current,
                              								"operatorAssignmentArithmethical",
                              								lv_operatorAssignmentArithmethical_5_0,
                              								"org.xtext.SM2.AssignmentOperator");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }

                    // InternalSM2.g:4923:4: ( ( (lv_op2_6_0= RULE_INTEGER ) ) | this_FLOAT_7= RULE_FLOAT | this_ID_8= RULE_ID )
                    int alt148=3;
                    switch ( input.LA(1) ) {
                    case RULE_INTEGER:
                        {
                        alt148=1;
                        }
                        break;
                    case RULE_FLOAT:
                        {
                        alt148=2;
                        }
                        break;
                    case RULE_ID:
                        {
                        alt148=3;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 148, 0, input);

                        throw nvae;
                    }

                    switch (alt148) {
                        case 1 :
                            // InternalSM2.g:4924:5: ( (lv_op2_6_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4924:5: ( (lv_op2_6_0= RULE_INTEGER ) )
                            // InternalSM2.g:4925:6: (lv_op2_6_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4925:6: (lv_op2_6_0= RULE_INTEGER )
                            // InternalSM2.g:4926:7: lv_op2_6_0= RULE_INTEGER
                            {
                            lv_op2_6_0=(Token)match(input,RULE_INTEGER,FOLLOW_25); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op2_6_0, grammarAccess.getArithmethicalExpressionAccess().getOp2INTEGERTerminalRuleCall_0_3_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op2",
                              								lv_op2_6_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4943:5: this_FLOAT_7= RULE_FLOAT
                            {
                            this_FLOAT_7=(Token)match(input,RULE_FLOAT,FOLLOW_25); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_7, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_0_3_1());
                              				
                            }

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:4948:5: this_ID_8= RULE_ID
                            {
                            this_ID_8=(Token)match(input,RULE_ID,FOLLOW_25); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_ID_8, grammarAccess.getArithmethicalExpressionAccess().getIDTerminalRuleCall_0_3_2());
                              				
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_9=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_CLOSEPARENTHESIS_9, grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4959:3: ( ( ( (lv_op1_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT | this_ID_12= RULE_ID ) ( ( (lv_operatorArithmethical_13_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_14_0= ruleAssignmentOperator ) ) ) ( ( (lv_op2_15_0= RULE_INTEGER ) ) | this_FLOAT_16= RULE_FLOAT | this_ID_17= RULE_ID ) (this_SEMICOLON_18= RULE_SEMICOLON this_EOLINE_19= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:4959:3: ( ( ( (lv_op1_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT | this_ID_12= RULE_ID ) ( ( (lv_operatorArithmethical_13_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_14_0= ruleAssignmentOperator ) ) ) ( ( (lv_op2_15_0= RULE_INTEGER ) ) | this_FLOAT_16= RULE_FLOAT | this_ID_17= RULE_ID ) (this_SEMICOLON_18= RULE_SEMICOLON this_EOLINE_19= RULE_EOLINE )? )
                    // InternalSM2.g:4960:4: ( ( (lv_op1_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT | this_ID_12= RULE_ID ) ( ( (lv_operatorArithmethical_13_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_14_0= ruleAssignmentOperator ) ) ) ( ( (lv_op2_15_0= RULE_INTEGER ) ) | this_FLOAT_16= RULE_FLOAT | this_ID_17= RULE_ID ) (this_SEMICOLON_18= RULE_SEMICOLON this_EOLINE_19= RULE_EOLINE )?
                    {
                    // InternalSM2.g:4960:4: ( ( (lv_op1_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT | this_ID_12= RULE_ID )
                    int alt149=3;
                    switch ( input.LA(1) ) {
                    case RULE_INTEGER:
                        {
                        alt149=1;
                        }
                        break;
                    case RULE_FLOAT:
                        {
                        alt149=2;
                        }
                        break;
                    case RULE_ID:
                        {
                        alt149=3;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 149, 0, input);

                        throw nvae;
                    }

                    switch (alt149) {
                        case 1 :
                            // InternalSM2.g:4961:5: ( (lv_op1_10_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4961:5: ( (lv_op1_10_0= RULE_INTEGER ) )
                            // InternalSM2.g:4962:6: (lv_op1_10_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4962:6: (lv_op1_10_0= RULE_INTEGER )
                            // InternalSM2.g:4963:7: lv_op1_10_0= RULE_INTEGER
                            {
                            lv_op1_10_0=(Token)match(input,RULE_INTEGER,FOLLOW_81); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op1_10_0, grammarAccess.getArithmethicalExpressionAccess().getOp1INTEGERTerminalRuleCall_1_0_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op1",
                              								lv_op1_10_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4980:5: this_FLOAT_11= RULE_FLOAT
                            {
                            this_FLOAT_11=(Token)match(input,RULE_FLOAT,FOLLOW_81); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_11, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_1_0_1());
                              				
                            }

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:4985:5: this_ID_12= RULE_ID
                            {
                            this_ID_12=(Token)match(input,RULE_ID,FOLLOW_81); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_ID_12, grammarAccess.getArithmethicalExpressionAccess().getIDTerminalRuleCall_1_0_2());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:4990:4: ( ( (lv_operatorArithmethical_13_0= ruleArithmeticalOperator ) ) | ( (lv_operatorAssignmentArithmethical_14_0= ruleAssignmentOperator ) ) )
                    int alt150=2;
                    int LA150_0 = input.LA(1);

                    if ( ((LA150_0>=138 && LA150_0<=142)) ) {
                        alt150=1;
                    }
                    else if ( (LA150_0==79||(LA150_0>=143 && LA150_0<=147)) ) {
                        alt150=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 150, 0, input);

                        throw nvae;
                    }
                    switch (alt150) {
                        case 1 :
                            // InternalSM2.g:4991:5: ( (lv_operatorArithmethical_13_0= ruleArithmeticalOperator ) )
                            {
                            // InternalSM2.g:4991:5: ( (lv_operatorArithmethical_13_0= ruleArithmeticalOperator ) )
                            // InternalSM2.g:4992:6: (lv_operatorArithmethical_13_0= ruleArithmeticalOperator )
                            {
                            // InternalSM2.g:4992:6: (lv_operatorArithmethical_13_0= ruleArithmeticalOperator )
                            // InternalSM2.g:4993:7: lv_operatorArithmethical_13_0= ruleArithmeticalOperator
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmethicalArithmeticalOperatorEnumRuleCall_1_1_0_0());
                              						
                            }
                            pushFollow(FOLLOW_80);
                            lv_operatorArithmethical_13_0=ruleArithmeticalOperator();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							set(
                              								current,
                              								"operatorArithmethical",
                              								lv_operatorArithmethical_13_0,
                              								"org.xtext.SM2.ArithmeticalOperator");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:5011:5: ( (lv_operatorAssignmentArithmethical_14_0= ruleAssignmentOperator ) )
                            {
                            // InternalSM2.g:5011:5: ( (lv_operatorAssignmentArithmethical_14_0= ruleAssignmentOperator ) )
                            // InternalSM2.g:5012:6: (lv_operatorAssignmentArithmethical_14_0= ruleAssignmentOperator )
                            {
                            // InternalSM2.g:5012:6: (lv_operatorAssignmentArithmethical_14_0= ruleAssignmentOperator )
                            // InternalSM2.g:5013:7: lv_operatorAssignmentArithmethical_14_0= ruleAssignmentOperator
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignmentArithmethicalAssignmentOperatorEnumRuleCall_1_1_1_0());
                              						
                            }
                            pushFollow(FOLLOW_80);
                            lv_operatorAssignmentArithmethical_14_0=ruleAssignmentOperator();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							set(
                              								current,
                              								"operatorAssignmentArithmethical",
                              								lv_operatorAssignmentArithmethical_14_0,
                              								"org.xtext.SM2.AssignmentOperator");
                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }


                            }


                            }
                            break;

                    }

                    // InternalSM2.g:5031:4: ( ( (lv_op2_15_0= RULE_INTEGER ) ) | this_FLOAT_16= RULE_FLOAT | this_ID_17= RULE_ID )
                    int alt151=3;
                    switch ( input.LA(1) ) {
                    case RULE_INTEGER:
                        {
                        alt151=1;
                        }
                        break;
                    case RULE_FLOAT:
                        {
                        alt151=2;
                        }
                        break;
                    case RULE_ID:
                        {
                        alt151=3;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 151, 0, input);

                        throw nvae;
                    }

                    switch (alt151) {
                        case 1 :
                            // InternalSM2.g:5032:5: ( (lv_op2_15_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:5032:5: ( (lv_op2_15_0= RULE_INTEGER ) )
                            // InternalSM2.g:5033:6: (lv_op2_15_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:5033:6: (lv_op2_15_0= RULE_INTEGER )
                            // InternalSM2.g:5034:7: lv_op2_15_0= RULE_INTEGER
                            {
                            lv_op2_15_0=(Token)match(input,RULE_INTEGER,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op2_15_0, grammarAccess.getArithmethicalExpressionAccess().getOp2INTEGERTerminalRuleCall_1_2_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op2",
                              								lv_op2_15_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:5051:5: this_FLOAT_16= RULE_FLOAT
                            {
                            this_FLOAT_16=(Token)match(input,RULE_FLOAT,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_16, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_1_2_1());
                              				
                            }

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:5056:5: this_ID_17= RULE_ID
                            {
                            this_ID_17=(Token)match(input,RULE_ID,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_ID_17, grammarAccess.getArithmethicalExpressionAccess().getIDTerminalRuleCall_1_2_2());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:5061:4: (this_SEMICOLON_18= RULE_SEMICOLON this_EOLINE_19= RULE_EOLINE )?
                    int alt152=2;
                    int LA152_0 = input.LA(1);

                    if ( (LA152_0==RULE_SEMICOLON) ) {
                        int LA152_1 = input.LA(2);

                        if ( (LA152_1==RULE_EOLINE) ) {
                            int LA152_3 = input.LA(3);

                            if ( (LA152_3==EOF||(LA152_3>=RULE_ID && LA152_3<=RULE_CLOSEKEY)||(LA152_3>=RULE_OPENPARENTHESIS && LA152_3<=RULE_STRING)||(LA152_3>=RULE_INTEGER && LA152_3<=RULE_SINGLENUMBER)||LA152_3==RULE_RETURN||(LA152_3>=RULE_NEW && LA152_3<=RULE_BREAK)||LA152_3==50||LA152_3==56||(LA152_3>=63 && LA152_3<=64)||LA152_3==73||(LA152_3>=77 && LA152_3<=78)||(LA152_3>=88 && LA152_3<=101)||(LA152_3>=103 && LA152_3<=111)||(LA152_3>=148 && LA152_3<=149)) ) {
                                alt152=1;
                            }
                        }
                    }
                    switch (alt152) {
                        case 1 :
                            // InternalSM2.g:5062:5: this_SEMICOLON_18= RULE_SEMICOLON this_EOLINE_19= RULE_EOLINE
                            {
                            this_SEMICOLON_18=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_18, grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0());
                              				
                            }
                            this_EOLINE_19=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_19, grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalExpression"


    // $ANTLR start "entryRuleArithmethicalLogicalExpression"
    // InternalSM2.g:5076:1: entryRuleArithmethicalLogicalExpression returns [EObject current=null] : iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF ;
    public final EObject entryRuleArithmethicalLogicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalLogicalExpression = null;


        try {
            // InternalSM2.g:5076:71: (iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF )
            // InternalSM2.g:5077:2: iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalLogicalExpression=ruleArithmethicalLogicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArithmethicalLogicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalLogicalExpression"


    // $ANTLR start "ruleArithmethicalLogicalExpression"
    // InternalSM2.g:5083:1: ruleArithmethicalLogicalExpression returns [EObject current=null] : (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator1_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) ( (lv_operator2_8_0= ruleComparationOperator ) ) ( ( (lv_expr_9_0= ruleArithmethicalExpression ) ) | this_STRING_10= RULE_STRING | this_INTEGER_11= RULE_INTEGER | this_FLOAT_12= RULE_FLOAT ) this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON this_EOLINE_15= RULE_EOLINE )? ) ;
    public final EObject ruleArithmethicalLogicalExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token lv_op1_1_0=null;
        Token this_FLOAT_2=null;
        Token this_ID_3=null;
        Token lv_op2_5_0=null;
        Token this_FLOAT_6=null;
        Token this_ID_7=null;
        Token this_STRING_10=null;
        Token this_INTEGER_11=null;
        Token this_FLOAT_12=null;
        Token this_CLOSEPARENTHESIS_13=null;
        Token this_SEMICOLON_14=null;
        Token this_EOLINE_15=null;
        Enumerator lv_operator1_4_0 = null;

        Enumerator lv_operator2_8_0 = null;

        EObject lv_expr_9_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:5089:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator1_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) ( (lv_operator2_8_0= ruleComparationOperator ) ) ( ( (lv_expr_9_0= ruleArithmethicalExpression ) ) | this_STRING_10= RULE_STRING | this_INTEGER_11= RULE_INTEGER | this_FLOAT_12= RULE_FLOAT ) this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON this_EOLINE_15= RULE_EOLINE )? ) )
            // InternalSM2.g:5090:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator1_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) ( (lv_operator2_8_0= ruleComparationOperator ) ) ( ( (lv_expr_9_0= ruleArithmethicalExpression ) ) | this_STRING_10= RULE_STRING | this_INTEGER_11= RULE_INTEGER | this_FLOAT_12= RULE_FLOAT ) this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON this_EOLINE_15= RULE_EOLINE )? )
            {
            // InternalSM2.g:5090:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator1_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) ( (lv_operator2_8_0= ruleComparationOperator ) ) ( ( (lv_expr_9_0= ruleArithmethicalExpression ) ) | this_STRING_10= RULE_STRING | this_INTEGER_11= RULE_INTEGER | this_FLOAT_12= RULE_FLOAT ) this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON this_EOLINE_15= RULE_EOLINE )? )
            // InternalSM2.g:5091:3: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID ) ( (lv_operator1_4_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID ) ( (lv_operator2_8_0= ruleComparationOperator ) ) ( ( (lv_expr_9_0= ruleArithmethicalExpression ) ) | this_STRING_10= RULE_STRING | this_INTEGER_11= RULE_INTEGER | this_FLOAT_12= RULE_FLOAT ) this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON this_EOLINE_15= RULE_EOLINE )?
            {
            this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_80); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0());
              		
            }
            // InternalSM2.g:5095:3: ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT | this_ID_3= RULE_ID )
            int alt154=3;
            switch ( input.LA(1) ) {
            case RULE_INTEGER:
                {
                alt154=1;
                }
                break;
            case RULE_FLOAT:
                {
                alt154=2;
                }
                break;
            case RULE_ID:
                {
                alt154=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 154, 0, input);

                throw nvae;
            }

            switch (alt154) {
                case 1 :
                    // InternalSM2.g:5096:4: ( (lv_op1_1_0= RULE_INTEGER ) )
                    {
                    // InternalSM2.g:5096:4: ( (lv_op1_1_0= RULE_INTEGER ) )
                    // InternalSM2.g:5097:5: (lv_op1_1_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:5097:5: (lv_op1_1_0= RULE_INTEGER )
                    // InternalSM2.g:5098:6: lv_op1_1_0= RULE_INTEGER
                    {
                    lv_op1_1_0=(Token)match(input,RULE_INTEGER,FOLLOW_82); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op1_1_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOp1INTEGERTerminalRuleCall_1_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalLogicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op1",
                      							lv_op1_1_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5115:4: this_FLOAT_2= RULE_FLOAT
                    {
                    this_FLOAT_2=(Token)match(input,RULE_FLOAT,FOLLOW_82); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_FLOAT_2, grammarAccess.getArithmethicalLogicalExpressionAccess().getFLOATTerminalRuleCall_1_1());
                      			
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:5120:4: this_ID_3= RULE_ID
                    {
                    this_ID_3=(Token)match(input,RULE_ID,FOLLOW_82); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_ID_3, grammarAccess.getArithmethicalLogicalExpressionAccess().getIDTerminalRuleCall_1_2());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:5125:3: ( (lv_operator1_4_0= ruleArithmeticalOperator ) )
            // InternalSM2.g:5126:4: (lv_operator1_4_0= ruleArithmeticalOperator )
            {
            // InternalSM2.g:5126:4: (lv_operator1_4_0= ruleArithmeticalOperator )
            // InternalSM2.g:5127:5: lv_operator1_4_0= ruleArithmeticalOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator1ArithmeticalOperatorEnumRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_80);
            lv_operator1_4_0=ruleArithmeticalOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"operator1",
              						lv_operator1_4_0,
              						"org.xtext.SM2.ArithmeticalOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:5144:3: ( ( (lv_op2_5_0= RULE_INTEGER ) ) | this_FLOAT_6= RULE_FLOAT | this_ID_7= RULE_ID )
            int alt155=3;
            switch ( input.LA(1) ) {
            case RULE_INTEGER:
                {
                alt155=1;
                }
                break;
            case RULE_FLOAT:
                {
                alt155=2;
                }
                break;
            case RULE_ID:
                {
                alt155=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 155, 0, input);

                throw nvae;
            }

            switch (alt155) {
                case 1 :
                    // InternalSM2.g:5145:4: ( (lv_op2_5_0= RULE_INTEGER ) )
                    {
                    // InternalSM2.g:5145:4: ( (lv_op2_5_0= RULE_INTEGER ) )
                    // InternalSM2.g:5146:5: (lv_op2_5_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:5146:5: (lv_op2_5_0= RULE_INTEGER )
                    // InternalSM2.g:5147:6: lv_op2_5_0= RULE_INTEGER
                    {
                    lv_op2_5_0=(Token)match(input,RULE_INTEGER,FOLLOW_68); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op2_5_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOp2INTEGERTerminalRuleCall_3_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalLogicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op2",
                      							lv_op2_5_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5164:4: this_FLOAT_6= RULE_FLOAT
                    {
                    this_FLOAT_6=(Token)match(input,RULE_FLOAT,FOLLOW_68); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_FLOAT_6, grammarAccess.getArithmethicalLogicalExpressionAccess().getFLOATTerminalRuleCall_3_1());
                      			
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:5169:4: this_ID_7= RULE_ID
                    {
                    this_ID_7=(Token)match(input,RULE_ID,FOLLOW_68); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_ID_7, grammarAccess.getArithmethicalLogicalExpressionAccess().getIDTerminalRuleCall_3_2());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:5174:3: ( (lv_operator2_8_0= ruleComparationOperator ) )
            // InternalSM2.g:5175:4: (lv_operator2_8_0= ruleComparationOperator )
            {
            // InternalSM2.g:5175:4: (lv_operator2_8_0= ruleComparationOperator )
            // InternalSM2.g:5176:5: lv_operator2_8_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator2ComparationOperatorEnumRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_83);
            lv_operator2_8_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"operator2",
              						lv_operator2_8_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:5193:3: ( ( (lv_expr_9_0= ruleArithmethicalExpression ) ) | this_STRING_10= RULE_STRING | this_INTEGER_11= RULE_INTEGER | this_FLOAT_12= RULE_FLOAT )
            int alt156=4;
            switch ( input.LA(1) ) {
            case RULE_ID:
            case RULE_OPENPARENTHESIS:
                {
                alt156=1;
                }
                break;
            case RULE_INTEGER:
                {
                int LA156_2 = input.LA(2);

                if ( (LA156_2==79||(LA156_2>=138 && LA156_2<=147)) ) {
                    alt156=1;
                }
                else if ( (LA156_2==RULE_CLOSEPARENTHESIS) ) {
                    alt156=3;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 156, 2, input);

                    throw nvae;
                }
                }
                break;
            case RULE_FLOAT:
                {
                int LA156_3 = input.LA(2);

                if ( (LA156_3==RULE_CLOSEPARENTHESIS) ) {
                    alt156=4;
                }
                else if ( (LA156_3==79||(LA156_3>=138 && LA156_3<=147)) ) {
                    alt156=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 156, 3, input);

                    throw nvae;
                }
                }
                break;
            case RULE_STRING:
                {
                alt156=2;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 156, 0, input);

                throw nvae;
            }

            switch (alt156) {
                case 1 :
                    // InternalSM2.g:5194:4: ( (lv_expr_9_0= ruleArithmethicalExpression ) )
                    {
                    // InternalSM2.g:5194:4: ( (lv_expr_9_0= ruleArithmethicalExpression ) )
                    // InternalSM2.g:5195:5: (lv_expr_9_0= ruleArithmethicalExpression )
                    {
                    // InternalSM2.g:5195:5: (lv_expr_9_0= ruleArithmethicalExpression )
                    // InternalSM2.g:5196:6: lv_expr_9_0= ruleArithmethicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getExprArithmethicalExpressionParserRuleCall_5_0_0());
                      					
                    }
                    pushFollow(FOLLOW_25);
                    lv_expr_9_0=ruleArithmethicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"expr",
                      							lv_expr_9_0,
                      							"org.xtext.SM2.ArithmethicalExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5214:4: this_STRING_10= RULE_STRING
                    {
                    this_STRING_10=(Token)match(input,RULE_STRING,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_10, grammarAccess.getArithmethicalLogicalExpressionAccess().getSTRINGTerminalRuleCall_5_1());
                      			
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:5219:4: this_INTEGER_11= RULE_INTEGER
                    {
                    this_INTEGER_11=(Token)match(input,RULE_INTEGER,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_INTEGER_11, grammarAccess.getArithmethicalLogicalExpressionAccess().getINTEGERTerminalRuleCall_5_2());
                      			
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:5224:4: this_FLOAT_12= RULE_FLOAT
                    {
                    this_FLOAT_12=(Token)match(input,RULE_FLOAT,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_FLOAT_12, grammarAccess.getArithmethicalLogicalExpressionAccess().getFLOATTerminalRuleCall_5_3());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEPARENTHESIS_13=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_13, grammarAccess.getArithmethicalLogicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:5233:3: (this_SEMICOLON_14= RULE_SEMICOLON this_EOLINE_15= RULE_EOLINE )?
            int alt157=2;
            int LA157_0 = input.LA(1);

            if ( (LA157_0==RULE_SEMICOLON) ) {
                int LA157_1 = input.LA(2);

                if ( (LA157_1==RULE_EOLINE) ) {
                    int LA157_3 = input.LA(3);

                    if ( (LA157_3==EOF||(LA157_3>=RULE_ID && LA157_3<=RULE_CLOSEKEY)||(LA157_3>=RULE_OPENPARENTHESIS && LA157_3<=RULE_STRING)||(LA157_3>=RULE_INTEGER && LA157_3<=RULE_SINGLENUMBER)||LA157_3==RULE_RETURN||(LA157_3>=RULE_NEW && LA157_3<=RULE_BREAK)||LA157_3==50||LA157_3==56||(LA157_3>=63 && LA157_3<=64)||LA157_3==73||(LA157_3>=77 && LA157_3<=78)||(LA157_3>=88 && LA157_3<=101)||(LA157_3>=103 && LA157_3<=111)||(LA157_3>=148 && LA157_3<=149)) ) {
                        alt157=1;
                    }
                }
            }
            switch (alt157) {
                case 1 :
                    // InternalSM2.g:5234:4: this_SEMICOLON_14= RULE_SEMICOLON this_EOLINE_15= RULE_EOLINE
                    {
                    this_SEMICOLON_14=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_14, grammarAccess.getArithmethicalLogicalExpressionAccess().getSEMICOLONTerminalRuleCall_7_0());
                      			
                    }
                    this_EOLINE_15=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_15, grammarAccess.getArithmethicalLogicalExpressionAccess().getEOLINETerminalRuleCall_7_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalLogicalExpression"


    // $ANTLR start "entryRuleCreateObjectExpression"
    // InternalSM2.g:5247:1: entryRuleCreateObjectExpression returns [EObject current=null] : iv_ruleCreateObjectExpression= ruleCreateObjectExpression EOF ;
    public final EObject entryRuleCreateObjectExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCreateObjectExpression = null;


        try {
            // InternalSM2.g:5247:63: (iv_ruleCreateObjectExpression= ruleCreateObjectExpression EOF )
            // InternalSM2.g:5248:2: iv_ruleCreateObjectExpression= ruleCreateObjectExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCreateObjectExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleCreateObjectExpression=ruleCreateObjectExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleCreateObjectExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCreateObjectExpression"


    // $ANTLR start "ruleCreateObjectExpression"
    // InternalSM2.g:5254:1: ruleCreateObjectExpression returns [EObject current=null] : ( ( (lv_expr_0_0= RULE_NEW ) ) ( ( ( (lv_typeDefined_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_SyntaxExpression_3= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_type_5_0= ruleBasicType ) ) ( ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_SyntaxExpression_8= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) ) ) ;
    public final EObject ruleCreateObjectExpression() throws RecognitionException {
        EObject current = null;

        Token lv_expr_0_0=null;
        Token lv_typeDefined_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENPARENTHESIS_7=null;
        Token this_CLOSEPARENTHESIS_9=null;
        EObject this_SyntaxExpression_3 = null;

        Enumerator lv_type_5_0 = null;

        EObject this_SyntaxExpression_8 = null;



        	enterRule();

        try {
            // InternalSM2.g:5260:2: ( ( ( (lv_expr_0_0= RULE_NEW ) ) ( ( ( (lv_typeDefined_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_SyntaxExpression_3= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_type_5_0= ruleBasicType ) ) ( ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_SyntaxExpression_8= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) ) ) )
            // InternalSM2.g:5261:2: ( ( (lv_expr_0_0= RULE_NEW ) ) ( ( ( (lv_typeDefined_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_SyntaxExpression_3= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_type_5_0= ruleBasicType ) ) ( ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_SyntaxExpression_8= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) ) )
            {
            // InternalSM2.g:5261:2: ( ( (lv_expr_0_0= RULE_NEW ) ) ( ( ( (lv_typeDefined_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_SyntaxExpression_3= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_type_5_0= ruleBasicType ) ) ( ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_SyntaxExpression_8= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) ) )
            // InternalSM2.g:5262:3: ( (lv_expr_0_0= RULE_NEW ) ) ( ( ( (lv_typeDefined_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_SyntaxExpression_3= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_type_5_0= ruleBasicType ) ) ( ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_SyntaxExpression_8= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) )
            {
            // InternalSM2.g:5262:3: ( (lv_expr_0_0= RULE_NEW ) )
            // InternalSM2.g:5263:4: (lv_expr_0_0= RULE_NEW )
            {
            // InternalSM2.g:5263:4: (lv_expr_0_0= RULE_NEW )
            // InternalSM2.g:5264:5: lv_expr_0_0= RULE_NEW
            {
            lv_expr_0_0=(Token)match(input,RULE_NEW,FOLLOW_39); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr_0_0, grammarAccess.getCreateObjectExpressionAccess().getExprNEWTerminalRuleCall_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCreateObjectExpressionRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr",
              						lv_expr_0_0,
              						"org.xtext.SM2.NEW");
              				
            }

            }


            }

            // InternalSM2.g:5280:3: ( ( ( (lv_typeDefined_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_SyntaxExpression_3= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_type_5_0= ruleBasicType ) ) ( ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_SyntaxExpression_8= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) )
            int alt161=2;
            int LA161_0 = input.LA(1);

            if ( (LA161_0==RULE_ID) ) {
                alt161=1;
            }
            else if ( ((LA161_0>=77 && LA161_0<=78)||(LA161_0>=88 && LA161_0<=101)||(LA161_0>=103 && LA161_0<=111)||(LA161_0>=148 && LA161_0<=149)) ) {
                alt161=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 161, 0, input);

                throw nvae;
            }
            switch (alt161) {
                case 1 :
                    // InternalSM2.g:5281:4: ( ( (lv_typeDefined_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_SyntaxExpression_3= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:5281:4: ( ( (lv_typeDefined_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_SyntaxExpression_3= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:5282:5: ( (lv_typeDefined_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_SyntaxExpression_3= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                    {
                    // InternalSM2.g:5282:5: ( (lv_typeDefined_1_0= RULE_ID ) )
                    // InternalSM2.g:5283:6: (lv_typeDefined_1_0= RULE_ID )
                    {
                    // InternalSM2.g:5283:6: (lv_typeDefined_1_0= RULE_ID )
                    // InternalSM2.g:5284:7: lv_typeDefined_1_0= RULE_ID
                    {
                    lv_typeDefined_1_0=(Token)match(input,RULE_ID,FOLLOW_23); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_typeDefined_1_0, grammarAccess.getCreateObjectExpressionAccess().getTypeDefinedIDTerminalRuleCall_1_0_0_0());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getCreateObjectExpressionRule());
                      							}
                      							setWithLastConsumed(
                      								current,
                      								"typeDefined",
                      								lv_typeDefined_1_0,
                      								"org.eclipse.xtext.common.Terminals.ID");
                      						
                    }

                    }


                    }

                    this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_84); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getCreateObjectExpressionAccess().getOPENPARENTHESISTerminalRuleCall_1_0_1());
                      				
                    }
                    // InternalSM2.g:5304:5: (this_SyntaxExpression_3= ruleSyntaxExpression )?
                    int alt158=2;
                    int LA158_0 = input.LA(1);

                    if ( (LA158_0==RULE_STRING||(LA158_0>=RULE_INTEGER && LA158_0<=RULE_FLOAT)) ) {
                        alt158=1;
                    }
                    switch (alt158) {
                        case 1 :
                            // InternalSM2.g:5305:6: this_SyntaxExpression_3= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getCreateObjectExpressionAccess().getSyntaxExpressionParserRuleCall_1_0_2());
                              					
                            }
                            pushFollow(FOLLOW_25);
                            this_SyntaxExpression_3=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_3;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getCreateObjectExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_3());
                      				
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5320:4: ( ( ( (lv_type_5_0= ruleBasicType ) ) ( ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_SyntaxExpression_8= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:5320:4: ( ( ( (lv_type_5_0= ruleBasicType ) ) ( ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_SyntaxExpression_8= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:5321:5: ( ( (lv_type_5_0= ruleBasicType ) ) ( ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_SyntaxExpression_8= ruleSyntaxExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS
                    {
                    // InternalSM2.g:5321:5: ( ( (lv_type_5_0= ruleBasicType ) ) ( ruleArray )? )
                    // InternalSM2.g:5322:6: ( (lv_type_5_0= ruleBasicType ) ) ( ruleArray )?
                    {
                    // InternalSM2.g:5322:6: ( (lv_type_5_0= ruleBasicType ) )
                    // InternalSM2.g:5323:7: (lv_type_5_0= ruleBasicType )
                    {
                    // InternalSM2.g:5323:7: (lv_type_5_0= ruleBasicType )
                    // InternalSM2.g:5324:8: lv_type_5_0= ruleBasicType
                    {
                    if ( state.backtracking==0 ) {

                      								newCompositeNode(grammarAccess.getCreateObjectExpressionAccess().getTypeBasicTypeEnumRuleCall_1_1_0_0_0());
                      							
                    }
                    pushFollow(FOLLOW_85);
                    lv_type_5_0=ruleBasicType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      								if (current==null) {
                      									current = createModelElementForParent(grammarAccess.getCreateObjectExpressionRule());
                      								}
                      								set(
                      									current,
                      									"type",
                      									lv_type_5_0,
                      									"org.xtext.SM2.BasicType");
                      								afterParserOrEnumRuleCall();
                      							
                    }

                    }


                    }

                    // InternalSM2.g:5341:6: ( ruleArray )?
                    int alt159=2;
                    int LA159_0 = input.LA(1);

                    if ( ((LA159_0>=83 && LA159_0<=84)) ) {
                        alt159=1;
                    }
                    switch (alt159) {
                        case 1 :
                            // InternalSM2.g:5342:7: ruleArray
                            {
                            if ( state.backtracking==0 ) {

                              							newCompositeNode(grammarAccess.getCreateObjectExpressionAccess().getArrayParserRuleCall_1_1_0_1());
                              						
                            }
                            pushFollow(FOLLOW_23);
                            ruleArray();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							afterParserOrEnumRuleCall();
                              						
                            }

                            }
                            break;

                    }


                    }

                    this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_84); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getCreateObjectExpressionAccess().getOPENPARENTHESISTerminalRuleCall_1_1_1());
                      				
                    }
                    // InternalSM2.g:5355:5: (this_SyntaxExpression_8= ruleSyntaxExpression )?
                    int alt160=2;
                    int LA160_0 = input.LA(1);

                    if ( (LA160_0==RULE_STRING||(LA160_0>=RULE_INTEGER && LA160_0<=RULE_FLOAT)) ) {
                        alt160=1;
                    }
                    switch (alt160) {
                        case 1 :
                            // InternalSM2.g:5356:6: this_SyntaxExpression_8= ruleSyntaxExpression
                            {
                            if ( state.backtracking==0 ) {

                              						newCompositeNode(grammarAccess.getCreateObjectExpressionAccess().getSyntaxExpressionParserRuleCall_1_1_2());
                              					
                            }
                            pushFollow(FOLLOW_25);
                            this_SyntaxExpression_8=ruleSyntaxExpression();

                            state._fsp--;
                            if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						current = this_SyntaxExpression_8;
                              						afterParserOrEnumRuleCall();
                              					
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_9=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_CLOSEPARENTHESIS_9, grammarAccess.getCreateObjectExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_3());
                      				
                    }

                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCreateObjectExpression"


    // $ANTLR start "entryRuleTypeCastingExpression"
    // InternalSM2.g:5375:1: entryRuleTypeCastingExpression returns [EObject current=null] : iv_ruleTypeCastingExpression= ruleTypeCastingExpression EOF ;
    public final EObject entryRuleTypeCastingExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTypeCastingExpression = null;


        try {
            // InternalSM2.g:5375:62: (iv_ruleTypeCastingExpression= ruleTypeCastingExpression EOF )
            // InternalSM2.g:5376:2: iv_ruleTypeCastingExpression= ruleTypeCastingExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getTypeCastingExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleTypeCastingExpression=ruleTypeCastingExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleTypeCastingExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeCastingExpression"


    // $ANTLR start "ruleTypeCastingExpression"
    // InternalSM2.g:5382:1: ruleTypeCastingExpression returns [EObject current=null] : ( ( ( (lv_typeCasting_0_0= ruleBasicType ) ) this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? ) | ( ( (lv_typeCasting_6_0= ruleBasicType ) ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS this_STRING_8= RULE_STRING this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS (this_SEMICOLON_10= RULE_SEMICOLON this_EOLINE_11= RULE_EOLINE )? ) ) ;
    public final EObject ruleTypeCastingExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_2=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;
        Token this_OPENPARENTHESIS_7=null;
        Token this_STRING_8=null;
        Token this_CLOSEPARENTHESIS_9=null;
        Token this_SEMICOLON_10=null;
        Token this_EOLINE_11=null;
        Enumerator lv_typeCasting_0_0 = null;

        Enumerator lv_typeCasting_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:5388:2: ( ( ( ( (lv_typeCasting_0_0= ruleBasicType ) ) this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? ) | ( ( (lv_typeCasting_6_0= ruleBasicType ) ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS this_STRING_8= RULE_STRING this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS (this_SEMICOLON_10= RULE_SEMICOLON this_EOLINE_11= RULE_EOLINE )? ) ) )
            // InternalSM2.g:5389:2: ( ( ( (lv_typeCasting_0_0= ruleBasicType ) ) this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? ) | ( ( (lv_typeCasting_6_0= ruleBasicType ) ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS this_STRING_8= RULE_STRING this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS (this_SEMICOLON_10= RULE_SEMICOLON this_EOLINE_11= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:5389:2: ( ( ( (lv_typeCasting_0_0= ruleBasicType ) ) this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? ) | ( ( (lv_typeCasting_6_0= ruleBasicType ) ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS this_STRING_8= RULE_STRING this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS (this_SEMICOLON_10= RULE_SEMICOLON this_EOLINE_11= RULE_EOLINE )? ) )
            int alt164=2;
            alt164 = dfa164.predict(input);
            switch (alt164) {
                case 1 :
                    // InternalSM2.g:5390:3: ( ( (lv_typeCasting_0_0= ruleBasicType ) ) this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:5390:3: ( ( (lv_typeCasting_0_0= ruleBasicType ) ) this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? )
                    // InternalSM2.g:5391:4: ( (lv_typeCasting_0_0= ruleBasicType ) ) this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )?
                    {
                    // InternalSM2.g:5391:4: ( (lv_typeCasting_0_0= ruleBasicType ) )
                    // InternalSM2.g:5392:5: (lv_typeCasting_0_0= ruleBasicType )
                    {
                    // InternalSM2.g:5392:5: (lv_typeCasting_0_0= ruleBasicType )
                    // InternalSM2.g:5393:6: lv_typeCasting_0_0= ruleBasicType
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getTypeCastingExpressionAccess().getTypeCastingBasicTypeEnumRuleCall_0_0_0());
                      					
                    }
                    pushFollow(FOLLOW_23);
                    lv_typeCasting_0_0=ruleBasicType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getTypeCastingExpressionRule());
                      						}
                      						set(
                      							current,
                      							"typeCasting",
                      							lv_typeCasting_0_0,
                      							"org.xtext.SM2.BasicType");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getTypeCastingExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_1());
                      			
                    }
                    // InternalSM2.g:5414:4: ( (otherlv_2= RULE_ID ) )
                    // InternalSM2.g:5415:5: (otherlv_2= RULE_ID )
                    {
                    // InternalSM2.g:5415:5: (otherlv_2= RULE_ID )
                    // InternalSM2.g:5416:6: otherlv_2= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getTypeCastingExpressionRule());
                      						}
                      					
                    }
                    otherlv_2=(Token)match(input,RULE_ID,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(otherlv_2, grammarAccess.getTypeCastingExpressionAccess().getParamTypeCastingExpressionCrossReference_0_2_0());
                      					
                    }

                    }


                    }

                    this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getTypeCastingExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_3());
                      			
                    }
                    // InternalSM2.g:5431:4: (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )?
                    int alt162=2;
                    int LA162_0 = input.LA(1);

                    if ( (LA162_0==RULE_SEMICOLON) ) {
                        int LA162_1 = input.LA(2);

                        if ( (LA162_1==RULE_EOLINE) ) {
                            int LA162_3 = input.LA(3);

                            if ( (LA162_3==EOF||(LA162_3>=RULE_ID && LA162_3<=RULE_CLOSEKEY)||(LA162_3>=RULE_OPENPARENTHESIS && LA162_3<=RULE_STRING)||(LA162_3>=RULE_INTEGER && LA162_3<=RULE_SINGLENUMBER)||LA162_3==RULE_RETURN||(LA162_3>=RULE_NEW && LA162_3<=RULE_BREAK)||LA162_3==50||LA162_3==56||(LA162_3>=63 && LA162_3<=64)||LA162_3==73||(LA162_3>=77 && LA162_3<=78)||(LA162_3>=88 && LA162_3<=101)||(LA162_3>=103 && LA162_3<=111)||(LA162_3>=148 && LA162_3<=149)) ) {
                                alt162=1;
                            }
                        }
                    }
                    switch (alt162) {
                        case 1 :
                            // InternalSM2.g:5432:5: this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE
                            {
                            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_4, grammarAccess.getTypeCastingExpressionAccess().getSEMICOLONTerminalRuleCall_0_4_0());
                              				
                            }
                            this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_5, grammarAccess.getTypeCastingExpressionAccess().getEOLINETerminalRuleCall_0_4_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5443:3: ( ( (lv_typeCasting_6_0= ruleBasicType ) ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS this_STRING_8= RULE_STRING this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS (this_SEMICOLON_10= RULE_SEMICOLON this_EOLINE_11= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:5443:3: ( ( (lv_typeCasting_6_0= ruleBasicType ) ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS this_STRING_8= RULE_STRING this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS (this_SEMICOLON_10= RULE_SEMICOLON this_EOLINE_11= RULE_EOLINE )? )
                    // InternalSM2.g:5444:4: ( (lv_typeCasting_6_0= ruleBasicType ) ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS this_STRING_8= RULE_STRING this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS (this_SEMICOLON_10= RULE_SEMICOLON this_EOLINE_11= RULE_EOLINE )?
                    {
                    // InternalSM2.g:5444:4: ( (lv_typeCasting_6_0= ruleBasicType ) )
                    // InternalSM2.g:5445:5: (lv_typeCasting_6_0= ruleBasicType )
                    {
                    // InternalSM2.g:5445:5: (lv_typeCasting_6_0= ruleBasicType )
                    // InternalSM2.g:5446:6: lv_typeCasting_6_0= ruleBasicType
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getTypeCastingExpressionAccess().getTypeCastingBasicTypeEnumRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_23);
                    lv_typeCasting_6_0=ruleBasicType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getTypeCastingExpressionRule());
                      						}
                      						set(
                      							current,
                      							"typeCasting",
                      							lv_typeCasting_6_0,
                      							"org.xtext.SM2.BasicType");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getTypeCastingExpressionAccess().getOPENPARENTHESISTerminalRuleCall_1_1());
                      			
                    }
                    this_STRING_8=(Token)match(input,RULE_STRING,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_8, grammarAccess.getTypeCastingExpressionAccess().getSTRINGTerminalRuleCall_1_2());
                      			
                    }
                    this_CLOSEPARENTHESIS_9=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_26); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_CLOSEPARENTHESIS_9, grammarAccess.getTypeCastingExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3());
                      			
                    }
                    // InternalSM2.g:5475:4: (this_SEMICOLON_10= RULE_SEMICOLON this_EOLINE_11= RULE_EOLINE )?
                    int alt163=2;
                    int LA163_0 = input.LA(1);

                    if ( (LA163_0==RULE_SEMICOLON) ) {
                        int LA163_1 = input.LA(2);

                        if ( (LA163_1==RULE_EOLINE) ) {
                            int LA163_3 = input.LA(3);

                            if ( (LA163_3==EOF||(LA163_3>=RULE_ID && LA163_3<=RULE_CLOSEKEY)||(LA163_3>=RULE_OPENPARENTHESIS && LA163_3<=RULE_STRING)||(LA163_3>=RULE_INTEGER && LA163_3<=RULE_SINGLENUMBER)||LA163_3==RULE_RETURN||(LA163_3>=RULE_NEW && LA163_3<=RULE_BREAK)||LA163_3==50||LA163_3==56||(LA163_3>=63 && LA163_3<=64)||LA163_3==73||(LA163_3>=77 && LA163_3<=78)||(LA163_3>=88 && LA163_3<=101)||(LA163_3>=103 && LA163_3<=111)||(LA163_3>=148 && LA163_3<=149)) ) {
                                alt163=1;
                            }
                        }
                    }
                    switch (alt163) {
                        case 1 :
                            // InternalSM2.g:5476:5: this_SEMICOLON_10= RULE_SEMICOLON this_EOLINE_11= RULE_EOLINE
                            {
                            this_SEMICOLON_10=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_10, grammarAccess.getTypeCastingExpressionAccess().getSEMICOLONTerminalRuleCall_1_4_0());
                              				
                            }
                            this_EOLINE_11=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_11, grammarAccess.getTypeCastingExpressionAccess().getEOLINETerminalRuleCall_1_4_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeCastingExpression"


    // $ANTLR start "entryRuleDeleteExpression"
    // InternalSM2.g:5490:1: entryRuleDeleteExpression returns [EObject current=null] : iv_ruleDeleteExpression= ruleDeleteExpression EOF ;
    public final EObject entryRuleDeleteExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDeleteExpression = null;


        try {
            // InternalSM2.g:5490:57: (iv_ruleDeleteExpression= ruleDeleteExpression EOF )
            // InternalSM2.g:5491:2: iv_ruleDeleteExpression= ruleDeleteExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getDeleteExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleDeleteExpression=ruleDeleteExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleDeleteExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDeleteExpression"


    // $ANTLR start "ruleDeleteExpression"
    // InternalSM2.g:5497:1: ruleDeleteExpression returns [EObject current=null] : (this_DELETE_0= RULE_DELETE ( (lv_expression_1_0= RULE_ID ) ) this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE ) ;
    public final EObject ruleDeleteExpression() throws RecognitionException {
        EObject current = null;

        Token this_DELETE_0=null;
        Token lv_expression_1_0=null;
        Token this_SEMICOLON_2=null;
        Token this_EOLINE_3=null;


        	enterRule();

        try {
            // InternalSM2.g:5503:2: ( (this_DELETE_0= RULE_DELETE ( (lv_expression_1_0= RULE_ID ) ) this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE ) )
            // InternalSM2.g:5504:2: (this_DELETE_0= RULE_DELETE ( (lv_expression_1_0= RULE_ID ) ) this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )
            {
            // InternalSM2.g:5504:2: (this_DELETE_0= RULE_DELETE ( (lv_expression_1_0= RULE_ID ) ) this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )
            // InternalSM2.g:5505:3: this_DELETE_0= RULE_DELETE ( (lv_expression_1_0= RULE_ID ) ) this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE
            {
            this_DELETE_0=(Token)match(input,RULE_DELETE,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_DELETE_0, grammarAccess.getDeleteExpressionAccess().getDELETETerminalRuleCall_0());
              		
            }
            // InternalSM2.g:5509:3: ( (lv_expression_1_0= RULE_ID ) )
            // InternalSM2.g:5510:4: (lv_expression_1_0= RULE_ID )
            {
            // InternalSM2.g:5510:4: (lv_expression_1_0= RULE_ID )
            // InternalSM2.g:5511:5: lv_expression_1_0= RULE_ID
            {
            lv_expression_1_0=(Token)match(input,RULE_ID,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expression_1_0, grammarAccess.getDeleteExpressionAccess().getExpressionIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getDeleteExpressionRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expression",
              						lv_expression_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_SEMICOLON_2=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_2, grammarAccess.getDeleteExpressionAccess().getSEMICOLONTerminalRuleCall_2());
              		
            }
            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_3, grammarAccess.getDeleteExpressionAccess().getEOLINETerminalRuleCall_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDeleteExpression"


    // $ANTLR start "entryRuleTupleExpression"
    // InternalSM2.g:5539:1: entryRuleTupleExpression returns [EObject current=null] : iv_ruleTupleExpression= ruleTupleExpression EOF ;
    public final EObject entryRuleTupleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTupleExpression = null;


        try {
            // InternalSM2.g:5539:56: (iv_ruleTupleExpression= ruleTupleExpression EOF )
            // InternalSM2.g:5540:2: iv_ruleTupleExpression= ruleTupleExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getTupleExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleTupleExpression=ruleTupleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleTupleExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTupleExpression"


    // $ANTLR start "ruleTupleExpression"
    // InternalSM2.g:5546:1: ruleTupleExpression returns [EObject current=null] : (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_expression_1_0= ruleExpression ) ) (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS ) ;
    public final EObject ruleTupleExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token this_COMMA_2=null;
        Token this_CLOSEPARENTHESIS_3=null;
        EObject lv_expression_1_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:5552:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_expression_1_0= ruleExpression ) ) (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:5553:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_expression_1_0= ruleExpression ) ) (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:5553:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_expression_1_0= ruleExpression ) ) (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:5554:3: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_expression_1_0= ruleExpression ) ) (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS
            {
            this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_34); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getTupleExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0());
              		
            }
            // InternalSM2.g:5558:3: ( ( (lv_expression_1_0= ruleExpression ) ) (this_COMMA_2= RULE_COMMA )? )+
            int cnt166=0;
            loop166:
            do {
                int alt166=2;
                int LA166_0 = input.LA(1);

                if ( (LA166_0==RULE_ID||LA166_0==RULE_OPENPARENTHESIS||LA166_0==RULE_STRING||(LA166_0>=RULE_INTEGER && LA166_0<=RULE_SINGLENUMBER)||(LA166_0>=RULE_NEW && LA166_0<=RULE_DELETE)||LA166_0==50||LA166_0==56||(LA166_0>=63 && LA166_0<=64)||LA166_0==73||(LA166_0>=77 && LA166_0<=78)||(LA166_0>=88 && LA166_0<=101)||(LA166_0>=103 && LA166_0<=111)||(LA166_0>=148 && LA166_0<=149)) ) {
                    alt166=1;
                }


                switch (alt166) {
            	case 1 :
            	    // InternalSM2.g:5559:4: ( (lv_expression_1_0= ruleExpression ) ) (this_COMMA_2= RULE_COMMA )?
            	    {
            	    // InternalSM2.g:5559:4: ( (lv_expression_1_0= ruleExpression ) )
            	    // InternalSM2.g:5560:5: (lv_expression_1_0= ruleExpression )
            	    {
            	    // InternalSM2.g:5560:5: (lv_expression_1_0= ruleExpression )
            	    // InternalSM2.g:5561:6: lv_expression_1_0= ruleExpression
            	    {
            	    if ( state.backtracking==0 ) {

            	      						newCompositeNode(grammarAccess.getTupleExpressionAccess().getExpressionExpressionParserRuleCall_1_0_0());
            	      					
            	    }
            	    pushFollow(FOLLOW_86);
            	    lv_expression_1_0=ruleExpression();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      						if (current==null) {
            	      							current = createModelElementForParent(grammarAccess.getTupleExpressionRule());
            	      						}
            	      						add(
            	      							current,
            	      							"expression",
            	      							lv_expression_1_0,
            	      							"org.xtext.SM2.Expression");
            	      						afterParserOrEnumRuleCall();
            	      					
            	    }

            	    }


            	    }

            	    // InternalSM2.g:5578:4: (this_COMMA_2= RULE_COMMA )?
            	    int alt165=2;
            	    int LA165_0 = input.LA(1);

            	    if ( (LA165_0==RULE_COMMA) ) {
            	        alt165=1;
            	    }
            	    switch (alt165) {
            	        case 1 :
            	            // InternalSM2.g:5579:5: this_COMMA_2= RULE_COMMA
            	            {
            	            this_COMMA_2=(Token)match(input,RULE_COMMA,FOLLOW_87); if (state.failed) return current;
            	            if ( state.backtracking==0 ) {

            	              					newLeafNode(this_COMMA_2, grammarAccess.getTupleExpressionAccess().getCOMMATerminalRuleCall_1_1());
            	              				
            	            }

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt166 >= 1 ) break loop166;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(166, input);
                        throw eee;
                }
                cnt166++;
            } while (true);

            this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getTupleExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_2());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTupleExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:5593:1: entryRuleSyntaxExpression returns [EObject current=null] : iv_ruleSyntaxExpression= ruleSyntaxExpression EOF ;
    public final EObject entryRuleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSyntaxExpression = null;


        try {
            // InternalSM2.g:5593:57: (iv_ruleSyntaxExpression= ruleSyntaxExpression EOF )
            // InternalSM2.g:5594:2: iv_ruleSyntaxExpression= ruleSyntaxExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSyntaxExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSyntaxExpression=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSyntaxExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:5600:1: ruleSyntaxExpression returns [EObject current=null] : ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) ) ;
    public final EObject ruleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        Token lv_expr_0_0=null;
        Token this_INTEGER_1=null;
        Token this_FLOAT_2=null;
        Token this_SEMICOLON_3=null;
        Token this_EOLINE_4=null;


        	enterRule();

        try {
            // InternalSM2.g:5606:2: ( ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) ) )
            // InternalSM2.g:5607:2: ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:5607:2: ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) )
            int alt169=2;
            int LA169_0 = input.LA(1);

            if ( (LA169_0==RULE_STRING) ) {
                alt169=1;
            }
            else if ( ((LA169_0>=RULE_INTEGER && LA169_0<=RULE_FLOAT)) ) {
                alt169=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 169, 0, input);

                throw nvae;
            }
            switch (alt169) {
                case 1 :
                    // InternalSM2.g:5608:3: ( (lv_expr_0_0= RULE_STRING ) )
                    {
                    // InternalSM2.g:5608:3: ( (lv_expr_0_0= RULE_STRING ) )
                    // InternalSM2.g:5609:4: (lv_expr_0_0= RULE_STRING )
                    {
                    // InternalSM2.g:5609:4: (lv_expr_0_0= RULE_STRING )
                    // InternalSM2.g:5610:5: lv_expr_0_0= RULE_STRING
                    {
                    lv_expr_0_0=(Token)match(input,RULE_STRING,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_expr_0_0, grammarAccess.getSyntaxExpressionAccess().getExprSTRINGTerminalRuleCall_0_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getSyntaxExpressionRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"expr",
                      						lv_expr_0_0,
                      						"org.eclipse.xtext.common.Terminals.STRING");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5627:3: ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:5627:3: ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? )
                    // InternalSM2.g:5628:4: (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )?
                    {
                    // InternalSM2.g:5628:4: (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT )
                    int alt167=2;
                    int LA167_0 = input.LA(1);

                    if ( (LA167_0==RULE_INTEGER) ) {
                        alt167=1;
                    }
                    else if ( (LA167_0==RULE_FLOAT) ) {
                        alt167=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 167, 0, input);

                        throw nvae;
                    }
                    switch (alt167) {
                        case 1 :
                            // InternalSM2.g:5629:5: this_INTEGER_1= RULE_INTEGER
                            {
                            this_INTEGER_1=(Token)match(input,RULE_INTEGER,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_INTEGER_1, grammarAccess.getSyntaxExpressionAccess().getINTEGERTerminalRuleCall_1_0_0());
                              				
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:5634:5: this_FLOAT_2= RULE_FLOAT
                            {
                            this_FLOAT_2=(Token)match(input,RULE_FLOAT,FOLLOW_26); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_2, grammarAccess.getSyntaxExpressionAccess().getFLOATTerminalRuleCall_1_0_1());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:5639:4: (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )?
                    int alt168=2;
                    int LA168_0 = input.LA(1);

                    if ( (LA168_0==RULE_SEMICOLON) ) {
                        int LA168_1 = input.LA(2);

                        if ( (LA168_1==RULE_EOLINE) ) {
                            alt168=1;
                        }
                    }
                    switch (alt168) {
                        case 1 :
                            // InternalSM2.g:5640:5: this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE
                            {
                            this_SEMICOLON_3=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_3, grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0());
                              				
                            }
                            this_EOLINE_4=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_4, grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleWhileLoop"
    // InternalSM2.g:5654:1: entryRuleWhileLoop returns [EObject current=null] : iv_ruleWhileLoop= ruleWhileLoop EOF ;
    public final EObject entryRuleWhileLoop() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleWhileLoop = null;


        try {
            // InternalSM2.g:5654:50: (iv_ruleWhileLoop= ruleWhileLoop EOF )
            // InternalSM2.g:5655:2: iv_ruleWhileLoop= ruleWhileLoop EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getWhileLoopRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleWhileLoop=ruleWhileLoop();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleWhileLoop; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleWhileLoop"


    // $ANTLR start "ruleWhileLoop"
    // InternalSM2.g:5661:1: ruleWhileLoop returns [EObject current=null] : (otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= RULE_ID ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restrictionGas_8_0= ruleRestrictionGas ) ) ( (lv_loops_9_0= ruleLoops ) )? this_EOLINE_10= RULE_EOLINE ( (lv_conditions_11_0= ruleConditional ) )? this_EOLINE_12= RULE_EOLINE ( (lv_expressions_13_0= ruleExpression ) ) (this_EOLINE_14= RULE_EOLINE )? (this_BREAK_15= RULE_BREAK this_SEMICOLON_16= RULE_SEMICOLON )? (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY (this_EOLINE_19= RULE_EOLINE )? ) ;
    public final EObject ruleWhileLoop() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_expr1_2_0=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_OPENKEY_6=null;
        Token this_EOLINE_7=null;
        Token this_EOLINE_10=null;
        Token this_EOLINE_12=null;
        Token this_EOLINE_14=null;
        Token this_BREAK_15=null;
        Token this_SEMICOLON_16=null;
        Token this_EOLINE_17=null;
        Token this_CLOSEKEY_18=null;
        Token this_EOLINE_19=null;
        Enumerator lv_operator_3_0 = null;

        EObject lv_expr2_4_0 = null;

        EObject lv_restrictionGas_8_0 = null;

        EObject lv_loops_9_0 = null;

        EObject lv_conditions_11_0 = null;

        EObject lv_expressions_13_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:5667:2: ( (otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= RULE_ID ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restrictionGas_8_0= ruleRestrictionGas ) ) ( (lv_loops_9_0= ruleLoops ) )? this_EOLINE_10= RULE_EOLINE ( (lv_conditions_11_0= ruleConditional ) )? this_EOLINE_12= RULE_EOLINE ( (lv_expressions_13_0= ruleExpression ) ) (this_EOLINE_14= RULE_EOLINE )? (this_BREAK_15= RULE_BREAK this_SEMICOLON_16= RULE_SEMICOLON )? (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY (this_EOLINE_19= RULE_EOLINE )? ) )
            // InternalSM2.g:5668:2: (otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= RULE_ID ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restrictionGas_8_0= ruleRestrictionGas ) ) ( (lv_loops_9_0= ruleLoops ) )? this_EOLINE_10= RULE_EOLINE ( (lv_conditions_11_0= ruleConditional ) )? this_EOLINE_12= RULE_EOLINE ( (lv_expressions_13_0= ruleExpression ) ) (this_EOLINE_14= RULE_EOLINE )? (this_BREAK_15= RULE_BREAK this_SEMICOLON_16= RULE_SEMICOLON )? (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY (this_EOLINE_19= RULE_EOLINE )? )
            {
            // InternalSM2.g:5668:2: (otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= RULE_ID ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restrictionGas_8_0= ruleRestrictionGas ) ) ( (lv_loops_9_0= ruleLoops ) )? this_EOLINE_10= RULE_EOLINE ( (lv_conditions_11_0= ruleConditional ) )? this_EOLINE_12= RULE_EOLINE ( (lv_expressions_13_0= ruleExpression ) ) (this_EOLINE_14= RULE_EOLINE )? (this_BREAK_15= RULE_BREAK this_SEMICOLON_16= RULE_SEMICOLON )? (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY (this_EOLINE_19= RULE_EOLINE )? )
            // InternalSM2.g:5669:3: otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= RULE_ID ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restrictionGas_8_0= ruleRestrictionGas ) ) ( (lv_loops_9_0= ruleLoops ) )? this_EOLINE_10= RULE_EOLINE ( (lv_conditions_11_0= ruleConditional ) )? this_EOLINE_12= RULE_EOLINE ( (lv_expressions_13_0= ruleExpression ) ) (this_EOLINE_14= RULE_EOLINE )? (this_BREAK_15= RULE_BREAK this_SEMICOLON_16= RULE_SEMICOLON )? (this_EOLINE_17= RULE_EOLINE )? this_CLOSEKEY_18= RULE_CLOSEKEY (this_EOLINE_19= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,118,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getWhileLoopAccess().getWhileKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getWhileLoopAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:5677:3: ( (lv_expr1_2_0= RULE_ID ) )
            // InternalSM2.g:5678:4: (lv_expr1_2_0= RULE_ID )
            {
            // InternalSM2.g:5678:4: (lv_expr1_2_0= RULE_ID )
            // InternalSM2.g:5679:5: lv_expr1_2_0= RULE_ID
            {
            lv_expr1_2_0=(Token)match(input,RULE_ID,FOLLOW_68); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr1_2_0, grammarAccess.getWhileLoopAccess().getExpr1IDTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getWhileLoopRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr1",
              						lv_expr1_2_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:5695:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:5696:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:5696:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:5697:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getWhileLoopAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_34);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:5714:3: ( (lv_expr2_4_0= ruleExpression ) )
            // InternalSM2.g:5715:4: (lv_expr2_4_0= ruleExpression )
            {
            // InternalSM2.g:5715:4: (lv_expr2_4_0= ruleExpression )
            // InternalSM2.g:5716:5: lv_expr2_4_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getWhileLoopAccess().getExpr2ExpressionParserRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_25);
            lv_expr2_4_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
              					}
              					set(
              						current,
              						"expr2",
              						lv_expr2_4_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getWhileLoopAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            this_OPENKEY_6=(Token)match(input,RULE_OPENKEY,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_6, grammarAccess.getWhileLoopAccess().getOPENKEYTerminalRuleCall_6());
              		
            }
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_88); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_7, grammarAccess.getWhileLoopAccess().getEOLINETerminalRuleCall_7());
              		
            }
            // InternalSM2.g:5745:3: ( (lv_restrictionGas_8_0= ruleRestrictionGas ) )
            // InternalSM2.g:5746:4: (lv_restrictionGas_8_0= ruleRestrictionGas )
            {
            // InternalSM2.g:5746:4: (lv_restrictionGas_8_0= ruleRestrictionGas )
            // InternalSM2.g:5747:5: lv_restrictionGas_8_0= ruleRestrictionGas
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getWhileLoopAccess().getRestrictionGasRestrictionGasParserRuleCall_8_0());
              				
            }
            pushFollow(FOLLOW_89);
            lv_restrictionGas_8_0=ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
              					}
              					set(
              						current,
              						"restrictionGas",
              						lv_restrictionGas_8_0,
              						"org.xtext.SM2.RestrictionGas");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:5764:3: ( (lv_loops_9_0= ruleLoops ) )?
            int alt170=2;
            int LA170_0 = input.LA(1);

            if ( ((LA170_0>=118 && LA170_0<=119)) ) {
                alt170=1;
            }
            switch (alt170) {
                case 1 :
                    // InternalSM2.g:5765:4: (lv_loops_9_0= ruleLoops )
                    {
                    // InternalSM2.g:5765:4: (lv_loops_9_0= ruleLoops )
                    // InternalSM2.g:5766:5: lv_loops_9_0= ruleLoops
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getWhileLoopAccess().getLoopsLoopsParserRuleCall_9_0());
                      				
                    }
                    pushFollow(FOLLOW_13);
                    lv_loops_9_0=ruleLoops();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
                      					}
                      					add(
                      						current,
                      						"loops",
                      						lv_loops_9_0,
                      						"org.xtext.SM2.Loops");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_90); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_10, grammarAccess.getWhileLoopAccess().getEOLINETerminalRuleCall_10());
              		
            }
            // InternalSM2.g:5787:3: ( (lv_conditions_11_0= ruleConditional ) )?
            int alt171=2;
            int LA171_0 = input.LA(1);

            if ( (LA171_0==RULE_IF) ) {
                alt171=1;
            }
            switch (alt171) {
                case 1 :
                    // InternalSM2.g:5788:4: (lv_conditions_11_0= ruleConditional )
                    {
                    // InternalSM2.g:5788:4: (lv_conditions_11_0= ruleConditional )
                    // InternalSM2.g:5789:5: lv_conditions_11_0= ruleConditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getWhileLoopAccess().getConditionsConditionalParserRuleCall_11_0());
                      				
                    }
                    pushFollow(FOLLOW_13);
                    lv_conditions_11_0=ruleConditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
                      					}
                      					add(
                      						current,
                      						"conditions",
                      						lv_conditions_11_0,
                      						"org.xtext.SM2.Conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_34); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_12, grammarAccess.getWhileLoopAccess().getEOLINETerminalRuleCall_12());
              		
            }
            // InternalSM2.g:5810:3: ( (lv_expressions_13_0= ruleExpression ) )
            // InternalSM2.g:5811:4: (lv_expressions_13_0= ruleExpression )
            {
            // InternalSM2.g:5811:4: (lv_expressions_13_0= ruleExpression )
            // InternalSM2.g:5812:5: lv_expressions_13_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getWhileLoopAccess().getExpressionsExpressionParserRuleCall_13_0());
              				
            }
            pushFollow(FOLLOW_91);
            lv_expressions_13_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
              					}
              					add(
              						current,
              						"expressions",
              						lv_expressions_13_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:5829:3: (this_EOLINE_14= RULE_EOLINE )?
            int alt172=2;
            int LA172_0 = input.LA(1);

            if ( (LA172_0==RULE_EOLINE) ) {
                alt172=1;
            }
            switch (alt172) {
                case 1 :
                    // InternalSM2.g:5830:4: this_EOLINE_14= RULE_EOLINE
                    {
                    this_EOLINE_14=(Token)match(input,RULE_EOLINE,FOLLOW_91); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_14, grammarAccess.getWhileLoopAccess().getEOLINETerminalRuleCall_14());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:5835:3: (this_BREAK_15= RULE_BREAK this_SEMICOLON_16= RULE_SEMICOLON )?
            int alt173=2;
            int LA173_0 = input.LA(1);

            if ( (LA173_0==RULE_BREAK) ) {
                alt173=1;
            }
            switch (alt173) {
                case 1 :
                    // InternalSM2.g:5836:4: this_BREAK_15= RULE_BREAK this_SEMICOLON_16= RULE_SEMICOLON
                    {
                    this_BREAK_15=(Token)match(input,RULE_BREAK,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_BREAK_15, grammarAccess.getWhileLoopAccess().getBREAKTerminalRuleCall_15_0());
                      			
                    }
                    this_SEMICOLON_16=(Token)match(input,RULE_SEMICOLON,FOLLOW_54); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_16, grammarAccess.getWhileLoopAccess().getSEMICOLONTerminalRuleCall_15_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:5845:3: (this_EOLINE_17= RULE_EOLINE )?
            int alt174=2;
            int LA174_0 = input.LA(1);

            if ( (LA174_0==RULE_EOLINE) ) {
                alt174=1;
            }
            switch (alt174) {
                case 1 :
                    // InternalSM2.g:5846:4: this_EOLINE_17= RULE_EOLINE
                    {
                    this_EOLINE_17=(Token)match(input,RULE_EOLINE,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_17, grammarAccess.getWhileLoopAccess().getEOLINETerminalRuleCall_16());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_18=(Token)match(input,RULE_CLOSEKEY,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_18, grammarAccess.getWhileLoopAccess().getCLOSEKEYTerminalRuleCall_17());
              		
            }
            // InternalSM2.g:5855:3: (this_EOLINE_19= RULE_EOLINE )?
            int alt175=2;
            int LA175_0 = input.LA(1);

            if ( (LA175_0==RULE_EOLINE) ) {
                int LA175_1 = input.LA(2);

                if ( (LA175_1==EOF) ) {
                    alt175=1;
                }
                else if ( (LA175_1==RULE_EOLINE) ) {
                    int LA175_4 = input.LA(3);

                    if ( (LA175_4==RULE_EOLINE||LA175_4==RULE_IF) ) {
                        alt175=1;
                    }
                }
            }
            switch (alt175) {
                case 1 :
                    // InternalSM2.g:5856:4: this_EOLINE_19= RULE_EOLINE
                    {
                    this_EOLINE_19=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_19, grammarAccess.getWhileLoopAccess().getEOLINETerminalRuleCall_18());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleWhileLoop"


    // $ANTLR start "entryRuleForLoop"
    // InternalSM2.g:5865:1: entryRuleForLoop returns [EObject current=null] : iv_ruleForLoop= ruleForLoop EOF ;
    public final EObject entryRuleForLoop() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleForLoop = null;


        try {
            // InternalSM2.g:5865:48: (iv_ruleForLoop= ruleForLoop EOF )
            // InternalSM2.g:5866:2: iv_ruleForLoop= ruleForLoop EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getForLoopRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleForLoop=ruleForLoop();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleForLoop; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleForLoop"


    // $ANTLR start "ruleForLoop"
    // InternalSM2.g:5872:1: ruleForLoop returns [EObject current=null] : (otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INTEGER ) ) ) this_SEMICOLON_6= RULE_SEMICOLON this_ArithmethicalLogicalExpression_7= ruleArithmethicalLogicalExpression this_SEMICOLON_8= RULE_SEMICOLON ( ( ( (lv_nameCounterIteration_9_0= RULE_ID ) ) ( (lv_operator_10_0= ruleLoopOperator ) ) ) | ( ( (lv_operator_11_0= ruleLoopOperator ) ) ( (lv_nameCounterIteration_12_0= RULE_ID ) ) ) ) this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS this_OPENKEY_14= RULE_OPENKEY this_EOLINE_15= RULE_EOLINE ( (lv_restrictionGas_16_0= ruleRestrictionGas ) ) ( (lv_loops_17_0= ruleLoops ) )? this_EOLINE_18= RULE_EOLINE ( (lv_conditions_19_0= ruleConditional ) )? this_EOLINE_20= RULE_EOLINE ( (lv_expressions_21_0= ruleExpression ) ) (this_EOLINE_22= RULE_EOLINE )? (this_BREAK_23= RULE_BREAK this_SEMICOLON_24= RULE_SEMICOLON )? (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )? ) ;
    public final EObject ruleForLoop() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_typeCounter_2_1=null;
        Token lv_typeCounter_2_2=null;
        Token lv_nameCounter_3_0=null;
        Token otherlv_4=null;
        Token lv_value_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_SEMICOLON_8=null;
        Token lv_nameCounterIteration_9_0=null;
        Token lv_nameCounterIteration_12_0=null;
        Token this_CLOSEPARENTHESIS_13=null;
        Token this_OPENKEY_14=null;
        Token this_EOLINE_15=null;
        Token this_EOLINE_18=null;
        Token this_EOLINE_20=null;
        Token this_EOLINE_22=null;
        Token this_BREAK_23=null;
        Token this_SEMICOLON_24=null;
        Token this_EOLINE_25=null;
        Token this_CLOSEKEY_26=null;
        Token this_EOLINE_27=null;
        EObject this_ArithmethicalLogicalExpression_7 = null;

        Enumerator lv_operator_10_0 = null;

        Enumerator lv_operator_11_0 = null;

        EObject lv_restrictionGas_16_0 = null;

        EObject lv_loops_17_0 = null;

        EObject lv_conditions_19_0 = null;

        EObject lv_expressions_21_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:5878:2: ( (otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INTEGER ) ) ) this_SEMICOLON_6= RULE_SEMICOLON this_ArithmethicalLogicalExpression_7= ruleArithmethicalLogicalExpression this_SEMICOLON_8= RULE_SEMICOLON ( ( ( (lv_nameCounterIteration_9_0= RULE_ID ) ) ( (lv_operator_10_0= ruleLoopOperator ) ) ) | ( ( (lv_operator_11_0= ruleLoopOperator ) ) ( (lv_nameCounterIteration_12_0= RULE_ID ) ) ) ) this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS this_OPENKEY_14= RULE_OPENKEY this_EOLINE_15= RULE_EOLINE ( (lv_restrictionGas_16_0= ruleRestrictionGas ) ) ( (lv_loops_17_0= ruleLoops ) )? this_EOLINE_18= RULE_EOLINE ( (lv_conditions_19_0= ruleConditional ) )? this_EOLINE_20= RULE_EOLINE ( (lv_expressions_21_0= ruleExpression ) ) (this_EOLINE_22= RULE_EOLINE )? (this_BREAK_23= RULE_BREAK this_SEMICOLON_24= RULE_SEMICOLON )? (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )? ) )
            // InternalSM2.g:5879:2: (otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INTEGER ) ) ) this_SEMICOLON_6= RULE_SEMICOLON this_ArithmethicalLogicalExpression_7= ruleArithmethicalLogicalExpression this_SEMICOLON_8= RULE_SEMICOLON ( ( ( (lv_nameCounterIteration_9_0= RULE_ID ) ) ( (lv_operator_10_0= ruleLoopOperator ) ) ) | ( ( (lv_operator_11_0= ruleLoopOperator ) ) ( (lv_nameCounterIteration_12_0= RULE_ID ) ) ) ) this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS this_OPENKEY_14= RULE_OPENKEY this_EOLINE_15= RULE_EOLINE ( (lv_restrictionGas_16_0= ruleRestrictionGas ) ) ( (lv_loops_17_0= ruleLoops ) )? this_EOLINE_18= RULE_EOLINE ( (lv_conditions_19_0= ruleConditional ) )? this_EOLINE_20= RULE_EOLINE ( (lv_expressions_21_0= ruleExpression ) ) (this_EOLINE_22= RULE_EOLINE )? (this_BREAK_23= RULE_BREAK this_SEMICOLON_24= RULE_SEMICOLON )? (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )? )
            {
            // InternalSM2.g:5879:2: (otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INTEGER ) ) ) this_SEMICOLON_6= RULE_SEMICOLON this_ArithmethicalLogicalExpression_7= ruleArithmethicalLogicalExpression this_SEMICOLON_8= RULE_SEMICOLON ( ( ( (lv_nameCounterIteration_9_0= RULE_ID ) ) ( (lv_operator_10_0= ruleLoopOperator ) ) ) | ( ( (lv_operator_11_0= ruleLoopOperator ) ) ( (lv_nameCounterIteration_12_0= RULE_ID ) ) ) ) this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS this_OPENKEY_14= RULE_OPENKEY this_EOLINE_15= RULE_EOLINE ( (lv_restrictionGas_16_0= ruleRestrictionGas ) ) ( (lv_loops_17_0= ruleLoops ) )? this_EOLINE_18= RULE_EOLINE ( (lv_conditions_19_0= ruleConditional ) )? this_EOLINE_20= RULE_EOLINE ( (lv_expressions_21_0= ruleExpression ) ) (this_EOLINE_22= RULE_EOLINE )? (this_BREAK_23= RULE_BREAK this_SEMICOLON_24= RULE_SEMICOLON )? (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )? )
            // InternalSM2.g:5880:3: otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INTEGER ) ) ) this_SEMICOLON_6= RULE_SEMICOLON this_ArithmethicalLogicalExpression_7= ruleArithmethicalLogicalExpression this_SEMICOLON_8= RULE_SEMICOLON ( ( ( (lv_nameCounterIteration_9_0= RULE_ID ) ) ( (lv_operator_10_0= ruleLoopOperator ) ) ) | ( ( (lv_operator_11_0= ruleLoopOperator ) ) ( (lv_nameCounterIteration_12_0= RULE_ID ) ) ) ) this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS this_OPENKEY_14= RULE_OPENKEY this_EOLINE_15= RULE_EOLINE ( (lv_restrictionGas_16_0= ruleRestrictionGas ) ) ( (lv_loops_17_0= ruleLoops ) )? this_EOLINE_18= RULE_EOLINE ( (lv_conditions_19_0= ruleConditional ) )? this_EOLINE_20= RULE_EOLINE ( (lv_expressions_21_0= ruleExpression ) ) (this_EOLINE_22= RULE_EOLINE )? (this_BREAK_23= RULE_BREAK this_SEMICOLON_24= RULE_SEMICOLON )? (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,119,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getForLoopAccess().getForKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_92); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getForLoopAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:5888:3: ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INTEGER ) ) )
            // InternalSM2.g:5889:4: ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INTEGER ) )
            {
            // InternalSM2.g:5889:4: ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) )
            // InternalSM2.g:5890:5: ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) )
            {
            // InternalSM2.g:5890:5: ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) )
            // InternalSM2.g:5891:6: (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' )
            {
            // InternalSM2.g:5891:6: (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' )
            int alt176=2;
            int LA176_0 = input.LA(1);

            if ( (LA176_0==89) ) {
                alt176=1;
            }
            else if ( (LA176_0==88) ) {
                alt176=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 176, 0, input);

                throw nvae;
            }
            switch (alt176) {
                case 1 :
                    // InternalSM2.g:5892:7: lv_typeCounter_2_1= 'uint'
                    {
                    lv_typeCounter_2_1=(Token)match(input,89,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_typeCounter_2_1, grammarAccess.getForLoopAccess().getTypeCounterUintKeyword_2_0_0_0());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getForLoopRule());
                      							}
                      							setWithLastConsumed(current, "typeCounter", lv_typeCounter_2_1, null);
                      						
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:5903:7: lv_typeCounter_2_2= 'int'
                    {
                    lv_typeCounter_2_2=(Token)match(input,88,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_typeCounter_2_2, grammarAccess.getForLoopAccess().getTypeCounterIntKeyword_2_0_0_1());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getForLoopRule());
                      							}
                      							setWithLastConsumed(current, "typeCounter", lv_typeCounter_2_2, null);
                      						
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:5916:4: ( (lv_nameCounter_3_0= RULE_ID ) )
            // InternalSM2.g:5917:5: (lv_nameCounter_3_0= RULE_ID )
            {
            // InternalSM2.g:5917:5: (lv_nameCounter_3_0= RULE_ID )
            // InternalSM2.g:5918:6: lv_nameCounter_3_0= RULE_ID
            {
            lv_nameCounter_3_0=(Token)match(input,RULE_ID,FOLLOW_93); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						newLeafNode(lv_nameCounter_3_0, grammarAccess.getForLoopAccess().getNameCounterIDTerminalRuleCall_2_1_0());
              					
            }
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElement(grammarAccess.getForLoopRule());
              						}
              						setWithLastConsumed(
              							current,
              							"nameCounter",
              							lv_nameCounter_3_0,
              							"org.eclipse.xtext.common.Terminals.ID");
              					
            }

            }


            }

            otherlv_4=(Token)match(input,79,FOLLOW_94); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_4, grammarAccess.getForLoopAccess().getEqualsSignKeyword_2_2());
              			
            }
            // InternalSM2.g:5938:4: ( (lv_value_5_0= RULE_INTEGER ) )
            // InternalSM2.g:5939:5: (lv_value_5_0= RULE_INTEGER )
            {
            // InternalSM2.g:5939:5: (lv_value_5_0= RULE_INTEGER )
            // InternalSM2.g:5940:6: lv_value_5_0= RULE_INTEGER
            {
            lv_value_5_0=(Token)match(input,RULE_INTEGER,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						newLeafNode(lv_value_5_0, grammarAccess.getForLoopAccess().getValueINTEGERTerminalRuleCall_2_3_0());
              					
            }
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElement(grammarAccess.getForLoopRule());
              						}
              						setWithLastConsumed(
              							current,
              							"value",
              							lv_value_5_0,
              							"org.xtext.SM2.INTEGER");
              					
            }

            }


            }


            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getForLoopAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            if ( state.backtracking==0 ) {

              			newCompositeNode(grammarAccess.getForLoopAccess().getArithmethicalLogicalExpressionParserRuleCall_4());
              		
            }
            pushFollow(FOLLOW_7);
            this_ArithmethicalLogicalExpression_7=ruleArithmethicalLogicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			current = this_ArithmethicalLogicalExpression_7;
              			afterParserOrEnumRuleCall();
              		
            }
            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_95); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getForLoopAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:5973:3: ( ( ( (lv_nameCounterIteration_9_0= RULE_ID ) ) ( (lv_operator_10_0= ruleLoopOperator ) ) ) | ( ( (lv_operator_11_0= ruleLoopOperator ) ) ( (lv_nameCounterIteration_12_0= RULE_ID ) ) ) )
            int alt177=2;
            int LA177_0 = input.LA(1);

            if ( (LA177_0==RULE_ID) ) {
                alt177=1;
            }
            else if ( ((LA177_0>=131 && LA177_0<=132)) ) {
                alt177=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 177, 0, input);

                throw nvae;
            }
            switch (alt177) {
                case 1 :
                    // InternalSM2.g:5974:4: ( ( (lv_nameCounterIteration_9_0= RULE_ID ) ) ( (lv_operator_10_0= ruleLoopOperator ) ) )
                    {
                    // InternalSM2.g:5974:4: ( ( (lv_nameCounterIteration_9_0= RULE_ID ) ) ( (lv_operator_10_0= ruleLoopOperator ) ) )
                    // InternalSM2.g:5975:5: ( (lv_nameCounterIteration_9_0= RULE_ID ) ) ( (lv_operator_10_0= ruleLoopOperator ) )
                    {
                    // InternalSM2.g:5975:5: ( (lv_nameCounterIteration_9_0= RULE_ID ) )
                    // InternalSM2.g:5976:6: (lv_nameCounterIteration_9_0= RULE_ID )
                    {
                    // InternalSM2.g:5976:6: (lv_nameCounterIteration_9_0= RULE_ID )
                    // InternalSM2.g:5977:7: lv_nameCounterIteration_9_0= RULE_ID
                    {
                    lv_nameCounterIteration_9_0=(Token)match(input,RULE_ID,FOLLOW_95); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_nameCounterIteration_9_0, grammarAccess.getForLoopAccess().getNameCounterIterationIDTerminalRuleCall_6_0_0_0());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getForLoopRule());
                      							}
                      							setWithLastConsumed(
                      								current,
                      								"nameCounterIteration",
                      								lv_nameCounterIteration_9_0,
                      								"org.eclipse.xtext.common.Terminals.ID");
                      						
                    }

                    }


                    }

                    // InternalSM2.g:5993:5: ( (lv_operator_10_0= ruleLoopOperator ) )
                    // InternalSM2.g:5994:6: (lv_operator_10_0= ruleLoopOperator )
                    {
                    // InternalSM2.g:5994:6: (lv_operator_10_0= ruleLoopOperator )
                    // InternalSM2.g:5995:7: lv_operator_10_0= ruleLoopOperator
                    {
                    if ( state.backtracking==0 ) {

                      							newCompositeNode(grammarAccess.getForLoopAccess().getOperatorLoopOperatorEnumRuleCall_6_0_1_0());
                      						
                    }
                    pushFollow(FOLLOW_25);
                    lv_operator_10_0=ruleLoopOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElementForParent(grammarAccess.getForLoopRule());
                      							}
                      							set(
                      								current,
                      								"operator",
                      								lv_operator_10_0,
                      								"org.xtext.SM2.LoopOperator");
                      							afterParserOrEnumRuleCall();
                      						
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6014:4: ( ( (lv_operator_11_0= ruleLoopOperator ) ) ( (lv_nameCounterIteration_12_0= RULE_ID ) ) )
                    {
                    // InternalSM2.g:6014:4: ( ( (lv_operator_11_0= ruleLoopOperator ) ) ( (lv_nameCounterIteration_12_0= RULE_ID ) ) )
                    // InternalSM2.g:6015:5: ( (lv_operator_11_0= ruleLoopOperator ) ) ( (lv_nameCounterIteration_12_0= RULE_ID ) )
                    {
                    // InternalSM2.g:6015:5: ( (lv_operator_11_0= ruleLoopOperator ) )
                    // InternalSM2.g:6016:6: (lv_operator_11_0= ruleLoopOperator )
                    {
                    // InternalSM2.g:6016:6: (lv_operator_11_0= ruleLoopOperator )
                    // InternalSM2.g:6017:7: lv_operator_11_0= ruleLoopOperator
                    {
                    if ( state.backtracking==0 ) {

                      							newCompositeNode(grammarAccess.getForLoopAccess().getOperatorLoopOperatorEnumRuleCall_6_1_0_0());
                      						
                    }
                    pushFollow(FOLLOW_5);
                    lv_operator_11_0=ruleLoopOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElementForParent(grammarAccess.getForLoopRule());
                      							}
                      							set(
                      								current,
                      								"operator",
                      								lv_operator_11_0,
                      								"org.xtext.SM2.LoopOperator");
                      							afterParserOrEnumRuleCall();
                      						
                    }

                    }


                    }

                    // InternalSM2.g:6034:5: ( (lv_nameCounterIteration_12_0= RULE_ID ) )
                    // InternalSM2.g:6035:6: (lv_nameCounterIteration_12_0= RULE_ID )
                    {
                    // InternalSM2.g:6035:6: (lv_nameCounterIteration_12_0= RULE_ID )
                    // InternalSM2.g:6036:7: lv_nameCounterIteration_12_0= RULE_ID
                    {
                    lv_nameCounterIteration_12_0=(Token)match(input,RULE_ID,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_nameCounterIteration_12_0, grammarAccess.getForLoopAccess().getNameCounterIterationIDTerminalRuleCall_6_1_1_0());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getForLoopRule());
                      							}
                      							setWithLastConsumed(
                      								current,
                      								"nameCounterIteration",
                      								lv_nameCounterIteration_12_0,
                      								"org.eclipse.xtext.common.Terminals.ID");
                      						
                    }

                    }


                    }


                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_13=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_13, grammarAccess.getForLoopAccess().getCLOSEPARENTHESISTerminalRuleCall_7());
              		
            }
            this_OPENKEY_14=(Token)match(input,RULE_OPENKEY,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_14, grammarAccess.getForLoopAccess().getOPENKEYTerminalRuleCall_8());
              		
            }
            this_EOLINE_15=(Token)match(input,RULE_EOLINE,FOLLOW_88); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_15, grammarAccess.getForLoopAccess().getEOLINETerminalRuleCall_9());
              		
            }
            // InternalSM2.g:6066:3: ( (lv_restrictionGas_16_0= ruleRestrictionGas ) )
            // InternalSM2.g:6067:4: (lv_restrictionGas_16_0= ruleRestrictionGas )
            {
            // InternalSM2.g:6067:4: (lv_restrictionGas_16_0= ruleRestrictionGas )
            // InternalSM2.g:6068:5: lv_restrictionGas_16_0= ruleRestrictionGas
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getForLoopAccess().getRestrictionGasRestrictionGasParserRuleCall_10_0());
              				
            }
            pushFollow(FOLLOW_89);
            lv_restrictionGas_16_0=ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getForLoopRule());
              					}
              					set(
              						current,
              						"restrictionGas",
              						lv_restrictionGas_16_0,
              						"org.xtext.SM2.RestrictionGas");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:6085:3: ( (lv_loops_17_0= ruleLoops ) )?
            int alt178=2;
            int LA178_0 = input.LA(1);

            if ( ((LA178_0>=118 && LA178_0<=119)) ) {
                alt178=1;
            }
            switch (alt178) {
                case 1 :
                    // InternalSM2.g:6086:4: (lv_loops_17_0= ruleLoops )
                    {
                    // InternalSM2.g:6086:4: (lv_loops_17_0= ruleLoops )
                    // InternalSM2.g:6087:5: lv_loops_17_0= ruleLoops
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getForLoopAccess().getLoopsLoopsParserRuleCall_11_0());
                      				
                    }
                    pushFollow(FOLLOW_13);
                    lv_loops_17_0=ruleLoops();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getForLoopRule());
                      					}
                      					add(
                      						current,
                      						"loops",
                      						lv_loops_17_0,
                      						"org.xtext.SM2.Loops");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            this_EOLINE_18=(Token)match(input,RULE_EOLINE,FOLLOW_90); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_18, grammarAccess.getForLoopAccess().getEOLINETerminalRuleCall_12());
              		
            }
            // InternalSM2.g:6108:3: ( (lv_conditions_19_0= ruleConditional ) )?
            int alt179=2;
            int LA179_0 = input.LA(1);

            if ( (LA179_0==RULE_IF) ) {
                alt179=1;
            }
            switch (alt179) {
                case 1 :
                    // InternalSM2.g:6109:4: (lv_conditions_19_0= ruleConditional )
                    {
                    // InternalSM2.g:6109:4: (lv_conditions_19_0= ruleConditional )
                    // InternalSM2.g:6110:5: lv_conditions_19_0= ruleConditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getForLoopAccess().getConditionsConditionalParserRuleCall_13_0());
                      				
                    }
                    pushFollow(FOLLOW_13);
                    lv_conditions_19_0=ruleConditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getForLoopRule());
                      					}
                      					add(
                      						current,
                      						"conditions",
                      						lv_conditions_19_0,
                      						"org.xtext.SM2.Conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            this_EOLINE_20=(Token)match(input,RULE_EOLINE,FOLLOW_34); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_20, grammarAccess.getForLoopAccess().getEOLINETerminalRuleCall_14());
              		
            }
            // InternalSM2.g:6131:3: ( (lv_expressions_21_0= ruleExpression ) )
            // InternalSM2.g:6132:4: (lv_expressions_21_0= ruleExpression )
            {
            // InternalSM2.g:6132:4: (lv_expressions_21_0= ruleExpression )
            // InternalSM2.g:6133:5: lv_expressions_21_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getForLoopAccess().getExpressionsExpressionParserRuleCall_15_0());
              				
            }
            pushFollow(FOLLOW_91);
            lv_expressions_21_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getForLoopRule());
              					}
              					add(
              						current,
              						"expressions",
              						lv_expressions_21_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:6150:3: (this_EOLINE_22= RULE_EOLINE )?
            int alt180=2;
            int LA180_0 = input.LA(1);

            if ( (LA180_0==RULE_EOLINE) ) {
                alt180=1;
            }
            switch (alt180) {
                case 1 :
                    // InternalSM2.g:6151:4: this_EOLINE_22= RULE_EOLINE
                    {
                    this_EOLINE_22=(Token)match(input,RULE_EOLINE,FOLLOW_91); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_22, grammarAccess.getForLoopAccess().getEOLINETerminalRuleCall_16());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:6156:3: (this_BREAK_23= RULE_BREAK this_SEMICOLON_24= RULE_SEMICOLON )?
            int alt181=2;
            int LA181_0 = input.LA(1);

            if ( (LA181_0==RULE_BREAK) ) {
                alt181=1;
            }
            switch (alt181) {
                case 1 :
                    // InternalSM2.g:6157:4: this_BREAK_23= RULE_BREAK this_SEMICOLON_24= RULE_SEMICOLON
                    {
                    this_BREAK_23=(Token)match(input,RULE_BREAK,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_BREAK_23, grammarAccess.getForLoopAccess().getBREAKTerminalRuleCall_17_0());
                      			
                    }
                    this_SEMICOLON_24=(Token)match(input,RULE_SEMICOLON,FOLLOW_54); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_24, grammarAccess.getForLoopAccess().getSEMICOLONTerminalRuleCall_17_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:6166:3: (this_EOLINE_25= RULE_EOLINE )?
            int alt182=2;
            int LA182_0 = input.LA(1);

            if ( (LA182_0==RULE_EOLINE) ) {
                alt182=1;
            }
            switch (alt182) {
                case 1 :
                    // InternalSM2.g:6167:4: this_EOLINE_25= RULE_EOLINE
                    {
                    this_EOLINE_25=(Token)match(input,RULE_EOLINE,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_25, grammarAccess.getForLoopAccess().getEOLINETerminalRuleCall_18());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_26=(Token)match(input,RULE_CLOSEKEY,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_26, grammarAccess.getForLoopAccess().getCLOSEKEYTerminalRuleCall_19());
              		
            }
            // InternalSM2.g:6176:3: (this_EOLINE_27= RULE_EOLINE )?
            int alt183=2;
            int LA183_0 = input.LA(1);

            if ( (LA183_0==RULE_EOLINE) ) {
                int LA183_1 = input.LA(2);

                if ( (LA183_1==EOF) ) {
                    alt183=1;
                }
                else if ( (LA183_1==RULE_EOLINE) ) {
                    int LA183_4 = input.LA(3);

                    if ( (LA183_4==RULE_EOLINE||LA183_4==RULE_IF) ) {
                        alt183=1;
                    }
                }
            }
            switch (alt183) {
                case 1 :
                    // InternalSM2.g:6177:4: this_EOLINE_27= RULE_EOLINE
                    {
                    this_EOLINE_27=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_27, grammarAccess.getForLoopAccess().getEOLINETerminalRuleCall_20());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleForLoop"


    // $ANTLR start "entryRuleLoops"
    // InternalSM2.g:6186:1: entryRuleLoops returns [EObject current=null] : iv_ruleLoops= ruleLoops EOF ;
    public final EObject entryRuleLoops() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLoops = null;


        try {
            // InternalSM2.g:6186:46: (iv_ruleLoops= ruleLoops EOF )
            // InternalSM2.g:6187:2: iv_ruleLoops= ruleLoops EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLoopsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLoops=ruleLoops();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLoops; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLoops"


    // $ANTLR start "ruleLoops"
    // InternalSM2.g:6193:1: ruleLoops returns [EObject current=null] : (this_WhileLoop_0= ruleWhileLoop | this_ForLoop_1= ruleForLoop ) ;
    public final EObject ruleLoops() throws RecognitionException {
        EObject current = null;

        EObject this_WhileLoop_0 = null;

        EObject this_ForLoop_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:6199:2: ( (this_WhileLoop_0= ruleWhileLoop | this_ForLoop_1= ruleForLoop ) )
            // InternalSM2.g:6200:2: (this_WhileLoop_0= ruleWhileLoop | this_ForLoop_1= ruleForLoop )
            {
            // InternalSM2.g:6200:2: (this_WhileLoop_0= ruleWhileLoop | this_ForLoop_1= ruleForLoop )
            int alt184=2;
            int LA184_0 = input.LA(1);

            if ( (LA184_0==118) ) {
                alt184=1;
            }
            else if ( (LA184_0==119) ) {
                alt184=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 184, 0, input);

                throw nvae;
            }
            switch (alt184) {
                case 1 :
                    // InternalSM2.g:6201:3: this_WhileLoop_0= ruleWhileLoop
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getLoopsAccess().getWhileLoopParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_WhileLoop_0=ruleWhileLoop();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_WhileLoop_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:6210:3: this_ForLoop_1= ruleForLoop
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getLoopsAccess().getForLoopParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ForLoop_1=ruleForLoop();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ForLoop_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLoops"


    // $ANTLR start "entryRuleTimeExpression"
    // InternalSM2.g:6222:1: entryRuleTimeExpression returns [EObject current=null] : iv_ruleTimeExpression= ruleTimeExpression EOF ;
    public final EObject entryRuleTimeExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTimeExpression = null;


        try {
            // InternalSM2.g:6222:55: (iv_ruleTimeExpression= ruleTimeExpression EOF )
            // InternalSM2.g:6223:2: iv_ruleTimeExpression= ruleTimeExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getTimeExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleTimeExpression=ruleTimeExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleTimeExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTimeExpression"


    // $ANTLR start "ruleTimeExpression"
    // InternalSM2.g:6229:1: ruleTimeExpression returns [EObject current=null] : ( ( ( (lv_time_0_1= RULE_INTEGER | lv_time_0_2= RULE_SINGLENUMBER ) ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) ;
    public final EObject ruleTimeExpression() throws RecognitionException {
        EObject current = null;

        Token lv_time_0_1=null;
        Token lv_time_0_2=null;
        Token this_SEMICOLON_2=null;
        Token this_EOLINE_3=null;
        Enumerator lv_unit_1_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:6235:2: ( ( ( ( (lv_time_0_1= RULE_INTEGER | lv_time_0_2= RULE_SINGLENUMBER ) ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) )
            // InternalSM2.g:6236:2: ( ( ( (lv_time_0_1= RULE_INTEGER | lv_time_0_2= RULE_SINGLENUMBER ) ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
            {
            // InternalSM2.g:6236:2: ( ( ( (lv_time_0_1= RULE_INTEGER | lv_time_0_2= RULE_SINGLENUMBER ) ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
            // InternalSM2.g:6237:3: ( ( (lv_time_0_1= RULE_INTEGER | lv_time_0_2= RULE_SINGLENUMBER ) ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
            {
            // InternalSM2.g:6237:3: ( ( (lv_time_0_1= RULE_INTEGER | lv_time_0_2= RULE_SINGLENUMBER ) ) )
            // InternalSM2.g:6238:4: ( (lv_time_0_1= RULE_INTEGER | lv_time_0_2= RULE_SINGLENUMBER ) )
            {
            // InternalSM2.g:6238:4: ( (lv_time_0_1= RULE_INTEGER | lv_time_0_2= RULE_SINGLENUMBER ) )
            // InternalSM2.g:6239:5: (lv_time_0_1= RULE_INTEGER | lv_time_0_2= RULE_SINGLENUMBER )
            {
            // InternalSM2.g:6239:5: (lv_time_0_1= RULE_INTEGER | lv_time_0_2= RULE_SINGLENUMBER )
            int alt185=2;
            int LA185_0 = input.LA(1);

            if ( (LA185_0==RULE_INTEGER) ) {
                alt185=1;
            }
            else if ( (LA185_0==RULE_SINGLENUMBER) ) {
                alt185=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 185, 0, input);

                throw nvae;
            }
            switch (alt185) {
                case 1 :
                    // InternalSM2.g:6240:6: lv_time_0_1= RULE_INTEGER
                    {
                    lv_time_0_1=(Token)match(input,RULE_INTEGER,FOLLOW_96); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_time_0_1, grammarAccess.getTimeExpressionAccess().getTimeINTEGERTerminalRuleCall_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getTimeExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"time",
                      							lv_time_0_1,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:6255:6: lv_time_0_2= RULE_SINGLENUMBER
                    {
                    lv_time_0_2=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_96); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_time_0_2, grammarAccess.getTimeExpressionAccess().getTimeSINGLENUMBERTerminalRuleCall_0_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getTimeExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"time",
                      							lv_time_0_2,
                      							"org.xtext.SM2.SINGLENUMBER");
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:6272:3: ( (lv_unit_1_0= ruleTimeUnit ) )
            // InternalSM2.g:6273:4: (lv_unit_1_0= ruleTimeUnit )
            {
            // InternalSM2.g:6273:4: (lv_unit_1_0= ruleTimeUnit )
            // InternalSM2.g:6274:5: lv_unit_1_0= ruleTimeUnit
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getTimeExpressionAccess().getUnitTimeUnitEnumRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_26);
            lv_unit_1_0=ruleTimeUnit();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getTimeExpressionRule());
              					}
              					set(
              						current,
              						"unit",
              						lv_unit_1_0,
              						"org.xtext.SM2.TimeUnit");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:6291:3: (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
            int alt186=2;
            int LA186_0 = input.LA(1);

            if ( (LA186_0==RULE_SEMICOLON) ) {
                int LA186_1 = input.LA(2);

                if ( (LA186_1==RULE_EOLINE) ) {
                    int LA186_3 = input.LA(3);

                    if ( (LA186_3==EOF||(LA186_3>=RULE_ID && LA186_3<=RULE_CLOSEKEY)||(LA186_3>=RULE_OPENPARENTHESIS && LA186_3<=RULE_STRING)||(LA186_3>=RULE_INTEGER && LA186_3<=RULE_SINGLENUMBER)||LA186_3==RULE_RETURN||(LA186_3>=RULE_NEW && LA186_3<=RULE_BREAK)||LA186_3==50||LA186_3==56||(LA186_3>=63 && LA186_3<=64)||LA186_3==73||(LA186_3>=77 && LA186_3<=78)||(LA186_3>=88 && LA186_3<=101)||(LA186_3>=103 && LA186_3<=111)||(LA186_3>=148 && LA186_3<=149)) ) {
                        alt186=1;
                    }
                }
            }
            switch (alt186) {
                case 1 :
                    // InternalSM2.g:6292:4: this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE
                    {
                    this_SEMICOLON_2=(Token)match(input,RULE_SEMICOLON,FOLLOW_13); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_2, grammarAccess.getTimeExpressionAccess().getSEMICOLONTerminalRuleCall_2_0());
                      			
                    }
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getTimeExpressionAccess().getEOLINETerminalRuleCall_2_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeExpression"


    // $ANTLR start "entryRuleConditional"
    // InternalSM2.g:6305:1: entryRuleConditional returns [EObject current=null] : iv_ruleConditional= ruleConditional EOF ;
    public final EObject entryRuleConditional() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConditional = null;


        try {
            // InternalSM2.g:6305:52: (iv_ruleConditional= ruleConditional EOF )
            // InternalSM2.g:6306:2: iv_ruleConditional= ruleConditional EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConditionalRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleConditional=ruleConditional();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleConditional; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConditional"


    // $ANTLR start "ruleConditional"
    // InternalSM2.g:6312:1: ruleConditional returns [EObject current=null] : (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) ) ;
    public final EObject ruleConditional() throws RecognitionException {
        EObject current = null;

        Token this_IF_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_CLOSEKEY_7=null;
        Token this_ELSE_8=null;
        EObject this_LogicalUnaryOperator_2 = null;

        EObject lv_expression_3_0 = null;

        EObject lv_expressions_6_0 = null;

        EObject lv_needOtherCondition_9_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:6318:2: ( (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) ) )
            // InternalSM2.g:6319:2: (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) )
            {
            // InternalSM2.g:6319:2: (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) )
            // InternalSM2.g:6320:3: this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) )
            {
            this_IF_0=(Token)match(input,RULE_IF,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_IF_0, grammarAccess.getConditionalAccess().getIFTerminalRuleCall_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_34); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConditionalAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:6328:3: (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )?
            int alt187=2;
            alt187 = dfa187.predict(input);
            switch (alt187) {
                case 1 :
                    // InternalSM2.g:6329:4: this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator
                    {
                    if ( state.backtracking==0 ) {

                      				newCompositeNode(grammarAccess.getConditionalAccess().getLogicalUnaryOperatorParserRuleCall_2());
                      			
                    }
                    pushFollow(FOLLOW_34);
                    this_LogicalUnaryOperator_2=ruleLogicalUnaryOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = this_LogicalUnaryOperator_2;
                      				afterParserOrEnumRuleCall();
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:6338:3: ( (lv_expression_3_0= ruleExpression ) )
            // InternalSM2.g:6339:4: (lv_expression_3_0= ruleExpression )
            {
            // InternalSM2.g:6339:4: (lv_expression_3_0= ruleExpression )
            // InternalSM2.g:6340:5: lv_expression_3_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getConditionalAccess().getExpressionExpressionParserRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_25);
            lv_expression_3_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getConditionalRule());
              					}
              					set(
              						current,
              						"expression",
              						lv_expression_3_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getConditionalAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_97); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getConditionalAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:6365:3: ( (lv_expressions_6_0= ruleExpression ) )*
            loop188:
            do {
                int alt188=2;
                int LA188_0 = input.LA(1);

                if ( (LA188_0==RULE_ID||LA188_0==RULE_OPENPARENTHESIS||LA188_0==RULE_STRING||(LA188_0>=RULE_INTEGER && LA188_0<=RULE_SINGLENUMBER)||(LA188_0>=RULE_NEW && LA188_0<=RULE_DELETE)||LA188_0==50||LA188_0==56||(LA188_0>=63 && LA188_0<=64)||LA188_0==73||(LA188_0>=77 && LA188_0<=78)||(LA188_0>=88 && LA188_0<=101)||(LA188_0>=103 && LA188_0<=111)||(LA188_0>=148 && LA188_0<=149)) ) {
                    alt188=1;
                }


                switch (alt188) {
            	case 1 :
            	    // InternalSM2.g:6366:4: (lv_expressions_6_0= ruleExpression )
            	    {
            	    // InternalSM2.g:6366:4: (lv_expressions_6_0= ruleExpression )
            	    // InternalSM2.g:6367:5: lv_expressions_6_0= ruleExpression
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getConditionalAccess().getExpressionsExpressionParserRuleCall_6_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_97);
            	    lv_expressions_6_0=ruleExpression();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getConditionalRule());
            	      					}
            	      					add(
            	      						current,
            	      						"expressions",
            	      						lv_expressions_6_0,
            	      						"org.xtext.SM2.Expression");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop188;
                }
            } while (true);

            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_98); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_7, grammarAccess.getConditionalAccess().getCLOSEKEYTerminalRuleCall_7());
              		
            }
            // InternalSM2.g:6388:3: (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) )
            // InternalSM2.g:6389:4: this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) )
            {
            this_ELSE_8=(Token)match(input,RULE_ELSE,FOLLOW_75); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(this_ELSE_8, grammarAccess.getConditionalAccess().getELSETerminalRuleCall_8_0());
              			
            }
            // InternalSM2.g:6393:4: ( (lv_needOtherCondition_9_0= ruleConditional ) )
            // InternalSM2.g:6394:5: (lv_needOtherCondition_9_0= ruleConditional )
            {
            // InternalSM2.g:6394:5: (lv_needOtherCondition_9_0= ruleConditional )
            // InternalSM2.g:6395:6: lv_needOtherCondition_9_0= ruleConditional
            {
            if ( state.backtracking==0 ) {

              						newCompositeNode(grammarAccess.getConditionalAccess().getNeedOtherConditionConditionalParserRuleCall_8_1_0());
              					
            }
            pushFollow(FOLLOW_2);
            lv_needOtherCondition_9_0=ruleConditional();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElementForParent(grammarAccess.getConditionalRule());
              						}
              						set(
              							current,
              							"needOtherCondition",
              							lv_needOtherCondition_9_0,
              							"org.xtext.SM2.Conditional");
              						afterParserOrEnumRuleCall();
              					
            }

            }


            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConditional"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:6417:1: entryRuleComment returns [EObject current=null] : iv_ruleComment= ruleComment EOF ;
    public final EObject entryRuleComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleComment = null;


        try {
            // InternalSM2.g:6417:48: (iv_ruleComment= ruleComment EOF )
            // InternalSM2.g:6418:2: iv_ruleComment= ruleComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleComment=ruleComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:6424:1: ruleComment returns [EObject current=null] : (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) ;
    public final EObject ruleComment() throws RecognitionException {
        EObject current = null;

        EObject this_ShortComment_0 = null;

        EObject this_LongComment_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:6430:2: ( (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) )
            // InternalSM2.g:6431:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            {
            // InternalSM2.g:6431:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            int alt189=2;
            int LA189_0 = input.LA(1);

            if ( (LA189_0==120) ) {
                alt189=1;
            }
            else if ( (LA189_0==121) ) {
                alt189=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 189, 0, input);

                throw nvae;
            }
            switch (alt189) {
                case 1 :
                    // InternalSM2.g:6432:3: this_ShortComment_0= ruleShortComment
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ShortComment_0=ruleShortComment();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ShortComment_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:6441:3: this_LongComment_1= ruleLongComment
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_LongComment_1=ruleLongComment();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_LongComment_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:6453:1: entryRuleShortComment returns [EObject current=null] : iv_ruleShortComment= ruleShortComment EOF ;
    public final EObject entryRuleShortComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleShortComment = null;


        try {
            // InternalSM2.g:6453:53: (iv_ruleShortComment= ruleShortComment EOF )
            // InternalSM2.g:6454:2: iv_ruleShortComment= ruleShortComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getShortCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleShortComment=ruleShortComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleShortComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:6460:1: ruleShortComment returns [EObject current=null] : (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) ) ;
    public final EObject ruleShortComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expr_1_0=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:6466:2: ( (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) ) )
            // InternalSM2.g:6467:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) )
            {
            // InternalSM2.g:6467:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) )
            // InternalSM2.g:6468:3: otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE )
            {
            otherlv_0=(Token)match(input,120,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0());
              		
            }
            // InternalSM2.g:6472:3: ( (lv_expr_1_0= RULE_STRING ) )
            // InternalSM2.g:6473:4: (lv_expr_1_0= RULE_STRING )
            {
            // InternalSM2.g:6473:4: (lv_expr_1_0= RULE_STRING )
            // InternalSM2.g:6474:5: lv_expr_1_0= RULE_STRING
            {
            lv_expr_1_0=(Token)match(input,RULE_STRING,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr_1_0, grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getShortCommentRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr",
              						lv_expr_1_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:6490:3: ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE )
            // InternalSM2.g:6491:4: ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE
            {
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(this_EOLINE_2, grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:6501:1: entryRuleLongComment returns [EObject current=null] : iv_ruleLongComment= ruleLongComment EOF ;
    public final EObject entryRuleLongComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLongComment = null;


        try {
            // InternalSM2.g:6501:52: (iv_ruleLongComment= ruleLongComment EOF )
            // InternalSM2.g:6502:2: iv_ruleLongComment= ruleLongComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLongCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLongComment=ruleLongComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLongComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:6508:1: ruleLongComment returns [EObject current=null] : (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) ) ;
    public final EObject ruleLongComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expression_1_1=null;
        Token lv_expression_1_2=null;
        Token lv_expression_1_3=null;
        Token lv_expression_1_4=null;
        Token lv_expression_1_5=null;
        Token lv_expression_1_6=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSM2.g:6514:2: ( (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) ) )
            // InternalSM2.g:6515:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) )
            {
            // InternalSM2.g:6515:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) )
            // InternalSM2.g:6516:3: otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' )
            {
            otherlv_0=(Token)match(input,121,FOLLOW_99); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0());
              		
            }
            // InternalSM2.g:6520:3: ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )?
            int alt191=2;
            int LA191_0 = input.LA(1);

            if ( (LA191_0==RULE_STRING||(LA191_0>=RULE_PARAMSLONGCOMENT && LA191_0<=RULE_NOTICELONGCOMENT)) ) {
                alt191=1;
            }
            switch (alt191) {
                case 1 :
                    // InternalSM2.g:6521:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
                    {
                    // InternalSM2.g:6521:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
                    // InternalSM2.g:6522:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
                    {
                    // InternalSM2.g:6522:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
                    int alt190=6;
                    switch ( input.LA(1) ) {
                    case RULE_STRING:
                        {
                        alt190=1;
                        }
                        break;
                    case RULE_PARAMSLONGCOMENT:
                        {
                        alt190=2;
                        }
                        break;
                    case RULE_DEVLONGCOMENT:
                        {
                        alt190=3;
                        }
                        break;
                    case RULE_RETURNSLONGCOMENT:
                        {
                        alt190=4;
                        }
                        break;
                    case RULE_TITLELONGCOMENT:
                        {
                        alt190=5;
                        }
                        break;
                    case RULE_NOTICELONGCOMENT:
                        {
                        alt190=6;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 190, 0, input);

                        throw nvae;
                    }

                    switch (alt190) {
                        case 1 :
                            // InternalSM2.g:6523:6: lv_expression_1_1= RULE_STRING
                            {
                            lv_expression_1_1=(Token)match(input,RULE_STRING,FOLLOW_100); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_1, grammarAccess.getLongCommentAccess().getExpressionSTRINGTerminalRuleCall_1_0_0());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_1,
                              							"org.eclipse.xtext.common.Terminals.STRING");
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:6538:6: lv_expression_1_2= RULE_PARAMSLONGCOMENT
                            {
                            lv_expression_1_2=(Token)match(input,RULE_PARAMSLONGCOMENT,FOLLOW_100); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_2, grammarAccess.getLongCommentAccess().getExpressionPARAMSLONGCOMENTTerminalRuleCall_1_0_1());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_2,
                              							"org.xtext.SM2.PARAMSLONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:6553:6: lv_expression_1_3= RULE_DEVLONGCOMENT
                            {
                            lv_expression_1_3=(Token)match(input,RULE_DEVLONGCOMENT,FOLLOW_100); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_3, grammarAccess.getLongCommentAccess().getExpressionDEVLONGCOMENTTerminalRuleCall_1_0_2());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_3,
                              							"org.xtext.SM2.DEVLONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 4 :
                            // InternalSM2.g:6568:6: lv_expression_1_4= RULE_RETURNSLONGCOMENT
                            {
                            lv_expression_1_4=(Token)match(input,RULE_RETURNSLONGCOMENT,FOLLOW_100); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_4, grammarAccess.getLongCommentAccess().getExpressionRETURNSLONGCOMENTTerminalRuleCall_1_0_3());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_4,
                              							"org.xtext.SM2.RETURNSLONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 5 :
                            // InternalSM2.g:6583:6: lv_expression_1_5= RULE_TITLELONGCOMENT
                            {
                            lv_expression_1_5=(Token)match(input,RULE_TITLELONGCOMENT,FOLLOW_100); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_5, grammarAccess.getLongCommentAccess().getExpressionTITLELONGCOMENTTerminalRuleCall_1_0_4());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_5,
                              							"org.xtext.SM2.TITLELONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 6 :
                            // InternalSM2.g:6598:6: lv_expression_1_6= RULE_NOTICELONGCOMENT
                            {
                            lv_expression_1_6=(Token)match(input,RULE_NOTICELONGCOMENT,FOLLOW_100); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_6, grammarAccess.getLongCommentAccess().getExpressionNOTICELONGCOMENTTerminalRuleCall_1_0_5());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_6,
                              							"org.xtext.SM2.NOTICELONGCOMENT");
                              					
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }

            // InternalSM2.g:6615:3: ( ( '*/' )=>otherlv_2= '*/' )
            // InternalSM2.g:6616:4: ( '*/' )=>otherlv_2= '*/'
            {
            otherlv_2=(Token)match(input,122,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_2, grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:6626:1: ruleVisibility returns [Enumerator current=null] : ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) ;
    public final Enumerator ruleVisibility() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalSM2.g:6632:2: ( ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) )
            // InternalSM2.g:6633:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            {
            // InternalSM2.g:6633:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            int alt192=4;
            switch ( input.LA(1) ) {
            case 68:
                {
                alt192=1;
                }
                break;
            case 123:
                {
                alt192=2;
                }
                break;
            case 69:
                {
                alt192=3;
                }
                break;
            case 124:
                {
                alt192=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 192, 0, input);

                throw nvae;
            }

            switch (alt192) {
                case 1 :
                    // InternalSM2.g:6634:3: (enumLiteral_0= 'public' )
                    {
                    // InternalSM2.g:6634:3: (enumLiteral_0= 'public' )
                    // InternalSM2.g:6635:4: enumLiteral_0= 'public'
                    {
                    enumLiteral_0=(Token)match(input,68,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6642:3: (enumLiteral_1= 'private' )
                    {
                    // InternalSM2.g:6642:3: (enumLiteral_1= 'private' )
                    // InternalSM2.g:6643:4: enumLiteral_1= 'private'
                    {
                    enumLiteral_1=(Token)match(input,123,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:6650:3: (enumLiteral_2= 'internal' )
                    {
                    // InternalSM2.g:6650:3: (enumLiteral_2= 'internal' )
                    // InternalSM2.g:6651:4: enumLiteral_2= 'internal'
                    {
                    enumLiteral_2=(Token)match(input,69,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:6658:3: (enumLiteral_3= 'external' )
                    {
                    // InternalSM2.g:6658:3: (enumLiteral_3= 'external' )
                    // InternalSM2.g:6659:4: enumLiteral_3= 'external'
                    {
                    enumLiteral_3=(Token)match(input,124,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:6669:1: ruleCoin returns [Enumerator current=null] : ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) ;
    public final Enumerator ruleCoin() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:6675:2: ( ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) )
            // InternalSM2.g:6676:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            {
            // InternalSM2.g:6676:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            int alt193=6;
            switch ( input.LA(1) ) {
            case 125:
                {
                alt193=1;
                }
                break;
            case 126:
                {
                alt193=2;
                }
                break;
            case 127:
                {
                alt193=3;
                }
                break;
            case 128:
                {
                alt193=4;
                }
                break;
            case 129:
                {
                alt193=5;
                }
                break;
            case 130:
                {
                alt193=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 193, 0, input);

                throw nvae;
            }

            switch (alt193) {
                case 1 :
                    // InternalSM2.g:6677:3: (enumLiteral_0= 'ether' )
                    {
                    // InternalSM2.g:6677:3: (enumLiteral_0= 'ether' )
                    // InternalSM2.g:6678:4: enumLiteral_0= 'ether'
                    {
                    enumLiteral_0=(Token)match(input,125,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6685:3: (enumLiteral_1= 'wei' )
                    {
                    // InternalSM2.g:6685:3: (enumLiteral_1= 'wei' )
                    // InternalSM2.g:6686:4: enumLiteral_1= 'wei'
                    {
                    enumLiteral_1=(Token)match(input,126,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:6693:3: (enumLiteral_2= 'gwei' )
                    {
                    // InternalSM2.g:6693:3: (enumLiteral_2= 'gwei' )
                    // InternalSM2.g:6694:4: enumLiteral_2= 'gwei'
                    {
                    enumLiteral_2=(Token)match(input,127,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:6701:3: (enumLiteral_3= 'pwei' )
                    {
                    // InternalSM2.g:6701:3: (enumLiteral_3= 'pwei' )
                    // InternalSM2.g:6702:4: enumLiteral_3= 'pwei'
                    {
                    enumLiteral_3=(Token)match(input,128,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:6709:3: (enumLiteral_4= 'finney' )
                    {
                    // InternalSM2.g:6709:3: (enumLiteral_4= 'finney' )
                    // InternalSM2.g:6710:4: enumLiteral_4= 'finney'
                    {
                    enumLiteral_4=(Token)match(input,129,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:6717:3: (enumLiteral_5= 'szabo' )
                    {
                    // InternalSM2.g:6717:3: (enumLiteral_5= 'szabo' )
                    // InternalSM2.g:6718:4: enumLiteral_5= 'szabo'
                    {
                    enumLiteral_5=(Token)match(input,130,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleLoopOperator"
    // InternalSM2.g:6728:1: ruleLoopOperator returns [Enumerator current=null] : ( (enumLiteral_0= '--' ) | (enumLiteral_1= '++' ) ) ;
    public final Enumerator ruleLoopOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSM2.g:6734:2: ( ( (enumLiteral_0= '--' ) | (enumLiteral_1= '++' ) ) )
            // InternalSM2.g:6735:2: ( (enumLiteral_0= '--' ) | (enumLiteral_1= '++' ) )
            {
            // InternalSM2.g:6735:2: ( (enumLiteral_0= '--' ) | (enumLiteral_1= '++' ) )
            int alt194=2;
            int LA194_0 = input.LA(1);

            if ( (LA194_0==131) ) {
                alt194=1;
            }
            else if ( (LA194_0==132) ) {
                alt194=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 194, 0, input);

                throw nvae;
            }
            switch (alt194) {
                case 1 :
                    // InternalSM2.g:6736:3: (enumLiteral_0= '--' )
                    {
                    // InternalSM2.g:6736:3: (enumLiteral_0= '--' )
                    // InternalSM2.g:6737:4: enumLiteral_0= '--'
                    {
                    enumLiteral_0=(Token)match(input,131,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLoopOperatorAccess().getDECREMENTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getLoopOperatorAccess().getDECREMENTEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6744:3: (enumLiteral_1= '++' )
                    {
                    // InternalSM2.g:6744:3: (enumLiteral_1= '++' )
                    // InternalSM2.g:6745:4: enumLiteral_1= '++'
                    {
                    enumLiteral_1=(Token)match(input,132,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLoopOperatorAccess().getINCREMENTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getLoopOperatorAccess().getINCREMENTEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLoopOperator"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:6755:1: ruleComparationOperator returns [Enumerator current=null] : ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) ;
    public final Enumerator ruleComparationOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:6761:2: ( ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) )
            // InternalSM2.g:6762:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            {
            // InternalSM2.g:6762:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            int alt195=6;
            switch ( input.LA(1) ) {
            case 133:
                {
                alt195=1;
                }
                break;
            case 43:
                {
                alt195=2;
                }
                break;
            case 42:
                {
                alt195=3;
                }
                break;
            case 134:
                {
                alt195=4;
                }
                break;
            case 116:
                {
                alt195=5;
                }
                break;
            case 135:
                {
                alt195=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 195, 0, input);

                throw nvae;
            }

            switch (alt195) {
                case 1 :
                    // InternalSM2.g:6763:3: (enumLiteral_0= '>' )
                    {
                    // InternalSM2.g:6763:3: (enumLiteral_0= '>' )
                    // InternalSM2.g:6764:4: enumLiteral_0= '>'
                    {
                    enumLiteral_0=(Token)match(input,133,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6771:3: (enumLiteral_1= '<' )
                    {
                    // InternalSM2.g:6771:3: (enumLiteral_1= '<' )
                    // InternalSM2.g:6772:4: enumLiteral_1= '<'
                    {
                    enumLiteral_1=(Token)match(input,43,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:6779:3: (enumLiteral_2= '>=' )
                    {
                    // InternalSM2.g:6779:3: (enumLiteral_2= '>=' )
                    // InternalSM2.g:6780:4: enumLiteral_2= '>='
                    {
                    enumLiteral_2=(Token)match(input,42,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:6787:3: (enumLiteral_3= '<=' )
                    {
                    // InternalSM2.g:6787:3: (enumLiteral_3= '<=' )
                    // InternalSM2.g:6788:4: enumLiteral_3= '<='
                    {
                    enumLiteral_3=(Token)match(input,134,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:6795:3: (enumLiteral_4= '==' )
                    {
                    // InternalSM2.g:6795:3: (enumLiteral_4= '==' )
                    // InternalSM2.g:6796:4: enumLiteral_4= '=='
                    {
                    enumLiteral_4=(Token)match(input,116,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:6803:3: (enumLiteral_5= '!=' )
                    {
                    // InternalSM2.g:6803:3: (enumLiteral_5= '!=' )
                    // InternalSM2.g:6804:4: enumLiteral_5= '!='
                    {
                    enumLiteral_5=(Token)match(input,135,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:6814:1: ruleLogicalPairOperator returns [Enumerator current=null] : ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) ;
    public final Enumerator ruleLogicalPairOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSM2.g:6820:2: ( ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) )
            // InternalSM2.g:6821:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            {
            // InternalSM2.g:6821:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            int alt196=2;
            int LA196_0 = input.LA(1);

            if ( (LA196_0==136) ) {
                alt196=1;
            }
            else if ( (LA196_0==137) ) {
                alt196=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 196, 0, input);

                throw nvae;
            }
            switch (alt196) {
                case 1 :
                    // InternalSM2.g:6822:3: (enumLiteral_0= '&&' )
                    {
                    // InternalSM2.g:6822:3: (enumLiteral_0= '&&' )
                    // InternalSM2.g:6823:4: enumLiteral_0= '&&'
                    {
                    enumLiteral_0=(Token)match(input,136,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6830:3: (enumLiteral_1= '||' )
                    {
                    // InternalSM2.g:6830:3: (enumLiteral_1= '||' )
                    // InternalSM2.g:6831:4: enumLiteral_1= '||'
                    {
                    enumLiteral_1=(Token)match(input,137,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:6841:1: ruleArithmeticalOperator returns [Enumerator current=null] : ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) ;
    public final Enumerator ruleArithmeticalOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;


        	enterRule();

        try {
            // InternalSM2.g:6847:2: ( ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) )
            // InternalSM2.g:6848:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            {
            // InternalSM2.g:6848:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            int alt197=5;
            switch ( input.LA(1) ) {
            case 138:
                {
                alt197=1;
                }
                break;
            case 139:
                {
                alt197=2;
                }
                break;
            case 140:
                {
                alt197=3;
                }
                break;
            case 141:
                {
                alt197=4;
                }
                break;
            case 142:
                {
                alt197=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 197, 0, input);

                throw nvae;
            }

            switch (alt197) {
                case 1 :
                    // InternalSM2.g:6849:3: (enumLiteral_0= '+' )
                    {
                    // InternalSM2.g:6849:3: (enumLiteral_0= '+' )
                    // InternalSM2.g:6850:4: enumLiteral_0= '+'
                    {
                    enumLiteral_0=(Token)match(input,138,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6857:3: (enumLiteral_1= '-' )
                    {
                    // InternalSM2.g:6857:3: (enumLiteral_1= '-' )
                    // InternalSM2.g:6858:4: enumLiteral_1= '-'
                    {
                    enumLiteral_1=(Token)match(input,139,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:6865:3: (enumLiteral_2= '*' )
                    {
                    // InternalSM2.g:6865:3: (enumLiteral_2= '*' )
                    // InternalSM2.g:6866:4: enumLiteral_2= '*'
                    {
                    enumLiteral_2=(Token)match(input,140,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:6873:3: (enumLiteral_3= '/' )
                    {
                    // InternalSM2.g:6873:3: (enumLiteral_3= '/' )
                    // InternalSM2.g:6874:4: enumLiteral_3= '/'
                    {
                    enumLiteral_3=(Token)match(input,141,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:6881:3: (enumLiteral_4= '%' )
                    {
                    // InternalSM2.g:6881:3: (enumLiteral_4= '%' )
                    // InternalSM2.g:6882:4: enumLiteral_4= '%'
                    {
                    enumLiteral_4=(Token)match(input,142,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmeticalOperator"


    // $ANTLR start "ruleAssignmentOperator"
    // InternalSM2.g:6892:1: ruleAssignmentOperator returns [Enumerator current=null] : ( (enumLiteral_0= '=' ) | (enumLiteral_1= '+=' ) | (enumLiteral_2= '-=' ) | (enumLiteral_3= '*=' ) | (enumLiteral_4= '/=' ) | (enumLiteral_5= '%=' ) ) ;
    public final Enumerator ruleAssignmentOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:6898:2: ( ( (enumLiteral_0= '=' ) | (enumLiteral_1= '+=' ) | (enumLiteral_2= '-=' ) | (enumLiteral_3= '*=' ) | (enumLiteral_4= '/=' ) | (enumLiteral_5= '%=' ) ) )
            // InternalSM2.g:6899:2: ( (enumLiteral_0= '=' ) | (enumLiteral_1= '+=' ) | (enumLiteral_2= '-=' ) | (enumLiteral_3= '*=' ) | (enumLiteral_4= '/=' ) | (enumLiteral_5= '%=' ) )
            {
            // InternalSM2.g:6899:2: ( (enumLiteral_0= '=' ) | (enumLiteral_1= '+=' ) | (enumLiteral_2= '-=' ) | (enumLiteral_3= '*=' ) | (enumLiteral_4= '/=' ) | (enumLiteral_5= '%=' ) )
            int alt198=6;
            switch ( input.LA(1) ) {
            case 79:
                {
                alt198=1;
                }
                break;
            case 143:
                {
                alt198=2;
                }
                break;
            case 144:
                {
                alt198=3;
                }
                break;
            case 145:
                {
                alt198=4;
                }
                break;
            case 146:
                {
                alt198=5;
                }
                break;
            case 147:
                {
                alt198=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 198, 0, input);

                throw nvae;
            }

            switch (alt198) {
                case 1 :
                    // InternalSM2.g:6900:3: (enumLiteral_0= '=' )
                    {
                    // InternalSM2.g:6900:3: (enumLiteral_0= '=' )
                    // InternalSM2.g:6901:4: enumLiteral_0= '='
                    {
                    enumLiteral_0=(Token)match(input,79,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getAssignmentOperatorAccess().getASSIGNMENTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getAssignmentOperatorAccess().getASSIGNMENTEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6908:3: (enumLiteral_1= '+=' )
                    {
                    // InternalSM2.g:6908:3: (enumLiteral_1= '+=' )
                    // InternalSM2.g:6909:4: enumLiteral_1= '+='
                    {
                    enumLiteral_1=(Token)match(input,143,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getAssignmentOperatorAccess().getADDASSIGNMENTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getAssignmentOperatorAccess().getADDASSIGNMENTEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:6916:3: (enumLiteral_2= '-=' )
                    {
                    // InternalSM2.g:6916:3: (enumLiteral_2= '-=' )
                    // InternalSM2.g:6917:4: enumLiteral_2= '-='
                    {
                    enumLiteral_2=(Token)match(input,144,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getAssignmentOperatorAccess().getLESSASSIGNMENTEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getAssignmentOperatorAccess().getLESSASSIGNMENTEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:6924:3: (enumLiteral_3= '*=' )
                    {
                    // InternalSM2.g:6924:3: (enumLiteral_3= '*=' )
                    // InternalSM2.g:6925:4: enumLiteral_3= '*='
                    {
                    enumLiteral_3=(Token)match(input,145,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getAssignmentOperatorAccess().getMULTIPLYASSIGNMENTEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getAssignmentOperatorAccess().getMULTIPLYASSIGNMENTEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:6932:3: (enumLiteral_4= '/=' )
                    {
                    // InternalSM2.g:6932:3: (enumLiteral_4= '/=' )
                    // InternalSM2.g:6933:4: enumLiteral_4= '/='
                    {
                    enumLiteral_4=(Token)match(input,146,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getAssignmentOperatorAccess().getDIVIDEASSIGNMENTEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getAssignmentOperatorAccess().getDIVIDEASSIGNMENTEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:6940:3: (enumLiteral_5= '%=' )
                    {
                    // InternalSM2.g:6940:3: (enumLiteral_5= '%=' )
                    // InternalSM2.g:6941:4: enumLiteral_5= '%='
                    {
                    enumLiteral_5=(Token)match(input,147,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getAssignmentOperatorAccess().getMODULOASSIGNMENTEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getAssignmentOperatorAccess().getMODULOASSIGNMENTEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAssignmentOperator"


    // $ANTLR start "ruleBasicType"
    // InternalSM2.g:6951:1: ruleBasicType returns [Enumerator current=null] : ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint2' ) | (enumLiteral_3= 'uint4' ) | (enumLiteral_4= 'uint8' ) | (enumLiteral_5= 'uint16' ) | (enumLiteral_6= 'uint24' ) | (enumLiteral_7= 'uint32' ) | (enumLiteral_8= 'uint64' ) | (enumLiteral_9= 'uint128' ) | (enumLiteral_10= 'uint160' ) | (enumLiteral_11= 'uint256' ) | (enumLiteral_12= 'string' ) | (enumLiteral_13= 'address' ) | (enumLiteral_14= 'address payable' ) | (enumLiteral_15= 'double' ) | (enumLiteral_16= 'bool' ) | (enumLiteral_17= 'byte' ) | (enumLiteral_18= 'bytes2' ) | (enumLiteral_19= 'bytes3' ) | (enumLiteral_20= 'bytes4' ) | (enumLiteral_21= 'bytes5' ) | (enumLiteral_22= 'bytes6' ) | (enumLiteral_23= 'bytes7' ) | (enumLiteral_24= 'bytes8' ) | (enumLiteral_25= 'bytes16' ) | (enumLiteral_26= 'bytes32' ) ) ;
    public final Enumerator ruleBasicType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;
        Token enumLiteral_8=null;
        Token enumLiteral_9=null;
        Token enumLiteral_10=null;
        Token enumLiteral_11=null;
        Token enumLiteral_12=null;
        Token enumLiteral_13=null;
        Token enumLiteral_14=null;
        Token enumLiteral_15=null;
        Token enumLiteral_16=null;
        Token enumLiteral_17=null;
        Token enumLiteral_18=null;
        Token enumLiteral_19=null;
        Token enumLiteral_20=null;
        Token enumLiteral_21=null;
        Token enumLiteral_22=null;
        Token enumLiteral_23=null;
        Token enumLiteral_24=null;
        Token enumLiteral_25=null;
        Token enumLiteral_26=null;


        	enterRule();

        try {
            // InternalSM2.g:6957:2: ( ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint2' ) | (enumLiteral_3= 'uint4' ) | (enumLiteral_4= 'uint8' ) | (enumLiteral_5= 'uint16' ) | (enumLiteral_6= 'uint24' ) | (enumLiteral_7= 'uint32' ) | (enumLiteral_8= 'uint64' ) | (enumLiteral_9= 'uint128' ) | (enumLiteral_10= 'uint160' ) | (enumLiteral_11= 'uint256' ) | (enumLiteral_12= 'string' ) | (enumLiteral_13= 'address' ) | (enumLiteral_14= 'address payable' ) | (enumLiteral_15= 'double' ) | (enumLiteral_16= 'bool' ) | (enumLiteral_17= 'byte' ) | (enumLiteral_18= 'bytes2' ) | (enumLiteral_19= 'bytes3' ) | (enumLiteral_20= 'bytes4' ) | (enumLiteral_21= 'bytes5' ) | (enumLiteral_22= 'bytes6' ) | (enumLiteral_23= 'bytes7' ) | (enumLiteral_24= 'bytes8' ) | (enumLiteral_25= 'bytes16' ) | (enumLiteral_26= 'bytes32' ) ) )
            // InternalSM2.g:6958:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint2' ) | (enumLiteral_3= 'uint4' ) | (enumLiteral_4= 'uint8' ) | (enumLiteral_5= 'uint16' ) | (enumLiteral_6= 'uint24' ) | (enumLiteral_7= 'uint32' ) | (enumLiteral_8= 'uint64' ) | (enumLiteral_9= 'uint128' ) | (enumLiteral_10= 'uint160' ) | (enumLiteral_11= 'uint256' ) | (enumLiteral_12= 'string' ) | (enumLiteral_13= 'address' ) | (enumLiteral_14= 'address payable' ) | (enumLiteral_15= 'double' ) | (enumLiteral_16= 'bool' ) | (enumLiteral_17= 'byte' ) | (enumLiteral_18= 'bytes2' ) | (enumLiteral_19= 'bytes3' ) | (enumLiteral_20= 'bytes4' ) | (enumLiteral_21= 'bytes5' ) | (enumLiteral_22= 'bytes6' ) | (enumLiteral_23= 'bytes7' ) | (enumLiteral_24= 'bytes8' ) | (enumLiteral_25= 'bytes16' ) | (enumLiteral_26= 'bytes32' ) )
            {
            // InternalSM2.g:6958:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint2' ) | (enumLiteral_3= 'uint4' ) | (enumLiteral_4= 'uint8' ) | (enumLiteral_5= 'uint16' ) | (enumLiteral_6= 'uint24' ) | (enumLiteral_7= 'uint32' ) | (enumLiteral_8= 'uint64' ) | (enumLiteral_9= 'uint128' ) | (enumLiteral_10= 'uint160' ) | (enumLiteral_11= 'uint256' ) | (enumLiteral_12= 'string' ) | (enumLiteral_13= 'address' ) | (enumLiteral_14= 'address payable' ) | (enumLiteral_15= 'double' ) | (enumLiteral_16= 'bool' ) | (enumLiteral_17= 'byte' ) | (enumLiteral_18= 'bytes2' ) | (enumLiteral_19= 'bytes3' ) | (enumLiteral_20= 'bytes4' ) | (enumLiteral_21= 'bytes5' ) | (enumLiteral_22= 'bytes6' ) | (enumLiteral_23= 'bytes7' ) | (enumLiteral_24= 'bytes8' ) | (enumLiteral_25= 'bytes16' ) | (enumLiteral_26= 'bytes32' ) )
            int alt199=27;
            switch ( input.LA(1) ) {
            case 88:
                {
                alt199=1;
                }
                break;
            case 89:
                {
                alt199=2;
                }
                break;
            case 90:
                {
                alt199=3;
                }
                break;
            case 91:
                {
                alt199=4;
                }
                break;
            case 92:
                {
                alt199=5;
                }
                break;
            case 93:
                {
                alt199=6;
                }
                break;
            case 94:
                {
                alt199=7;
                }
                break;
            case 95:
                {
                alt199=8;
                }
                break;
            case 96:
                {
                alt199=9;
                }
                break;
            case 97:
                {
                alt199=10;
                }
                break;
            case 98:
                {
                alt199=11;
                }
                break;
            case 99:
                {
                alt199=12;
                }
                break;
            case 78:
                {
                alt199=13;
                }
                break;
            case 77:
                {
                alt199=14;
                }
                break;
            case 101:
                {
                alt199=15;
                }
                break;
            case 148:
                {
                alt199=16;
                }
                break;
            case 100:
                {
                alt199=17;
                }
                break;
            case 149:
                {
                alt199=18;
                }
                break;
            case 103:
                {
                alt199=19;
                }
                break;
            case 104:
                {
                alt199=20;
                }
                break;
            case 105:
                {
                alt199=21;
                }
                break;
            case 106:
                {
                alt199=22;
                }
                break;
            case 107:
                {
                alt199=23;
                }
                break;
            case 108:
                {
                alt199=24;
                }
                break;
            case 109:
                {
                alt199=25;
                }
                break;
            case 110:
                {
                alt199=26;
                }
                break;
            case 111:
                {
                alt199=27;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 199, 0, input);

                throw nvae;
            }

            switch (alt199) {
                case 1 :
                    // InternalSM2.g:6959:3: (enumLiteral_0= 'int' )
                    {
                    // InternalSM2.g:6959:3: (enumLiteral_0= 'int' )
                    // InternalSM2.g:6960:4: enumLiteral_0= 'int'
                    {
                    enumLiteral_0=(Token)match(input,88,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getINTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getBasicTypeAccess().getINTEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6967:3: (enumLiteral_1= 'uint' )
                    {
                    // InternalSM2.g:6967:3: (enumLiteral_1= 'uint' )
                    // InternalSM2.g:6968:4: enumLiteral_1= 'uint'
                    {
                    enumLiteral_1=(Token)match(input,89,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getBasicTypeAccess().getUINTEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:6975:3: (enumLiteral_2= 'uint2' )
                    {
                    // InternalSM2.g:6975:3: (enumLiteral_2= 'uint2' )
                    // InternalSM2.g:6976:4: enumLiteral_2= 'uint2'
                    {
                    enumLiteral_2=(Token)match(input,90,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT2EnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getBasicTypeAccess().getUINT2EnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:6983:3: (enumLiteral_3= 'uint4' )
                    {
                    // InternalSM2.g:6983:3: (enumLiteral_3= 'uint4' )
                    // InternalSM2.g:6984:4: enumLiteral_3= 'uint4'
                    {
                    enumLiteral_3=(Token)match(input,91,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT4EnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getBasicTypeAccess().getUINT4EnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:6991:3: (enumLiteral_4= 'uint8' )
                    {
                    // InternalSM2.g:6991:3: (enumLiteral_4= 'uint8' )
                    // InternalSM2.g:6992:4: enumLiteral_4= 'uint8'
                    {
                    enumLiteral_4=(Token)match(input,92,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT8EnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getBasicTypeAccess().getUINT8EnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:6999:3: (enumLiteral_5= 'uint16' )
                    {
                    // InternalSM2.g:6999:3: (enumLiteral_5= 'uint16' )
                    // InternalSM2.g:7000:4: enumLiteral_5= 'uint16'
                    {
                    enumLiteral_5=(Token)match(input,93,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT16EnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getBasicTypeAccess().getUINT16EnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:7007:3: (enumLiteral_6= 'uint24' )
                    {
                    // InternalSM2.g:7007:3: (enumLiteral_6= 'uint24' )
                    // InternalSM2.g:7008:4: enumLiteral_6= 'uint24'
                    {
                    enumLiteral_6=(Token)match(input,94,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT24EnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_6, grammarAccess.getBasicTypeAccess().getUINT24EnumLiteralDeclaration_6());
                      			
                    }

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:7015:3: (enumLiteral_7= 'uint32' )
                    {
                    // InternalSM2.g:7015:3: (enumLiteral_7= 'uint32' )
                    // InternalSM2.g:7016:4: enumLiteral_7= 'uint32'
                    {
                    enumLiteral_7=(Token)match(input,95,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT32EnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_7, grammarAccess.getBasicTypeAccess().getUINT32EnumLiteralDeclaration_7());
                      			
                    }

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:7023:3: (enumLiteral_8= 'uint64' )
                    {
                    // InternalSM2.g:7023:3: (enumLiteral_8= 'uint64' )
                    // InternalSM2.g:7024:4: enumLiteral_8= 'uint64'
                    {
                    enumLiteral_8=(Token)match(input,96,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT64EnumLiteralDeclaration_8().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_8, grammarAccess.getBasicTypeAccess().getUINT64EnumLiteralDeclaration_8());
                      			
                    }

                    }


                    }
                    break;
                case 10 :
                    // InternalSM2.g:7031:3: (enumLiteral_9= 'uint128' )
                    {
                    // InternalSM2.g:7031:3: (enumLiteral_9= 'uint128' )
                    // InternalSM2.g:7032:4: enumLiteral_9= 'uint128'
                    {
                    enumLiteral_9=(Token)match(input,97,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT128EnumLiteralDeclaration_9().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_9, grammarAccess.getBasicTypeAccess().getUINT128EnumLiteralDeclaration_9());
                      			
                    }

                    }


                    }
                    break;
                case 11 :
                    // InternalSM2.g:7039:3: (enumLiteral_10= 'uint160' )
                    {
                    // InternalSM2.g:7039:3: (enumLiteral_10= 'uint160' )
                    // InternalSM2.g:7040:4: enumLiteral_10= 'uint160'
                    {
                    enumLiteral_10=(Token)match(input,98,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT160EnumLiteralDeclaration_10().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_10, grammarAccess.getBasicTypeAccess().getUINT160EnumLiteralDeclaration_10());
                      			
                    }

                    }


                    }
                    break;
                case 12 :
                    // InternalSM2.g:7047:3: (enumLiteral_11= 'uint256' )
                    {
                    // InternalSM2.g:7047:3: (enumLiteral_11= 'uint256' )
                    // InternalSM2.g:7048:4: enumLiteral_11= 'uint256'
                    {
                    enumLiteral_11=(Token)match(input,99,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT256EnumLiteralDeclaration_11().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_11, grammarAccess.getBasicTypeAccess().getUINT256EnumLiteralDeclaration_11());
                      			
                    }

                    }


                    }
                    break;
                case 13 :
                    // InternalSM2.g:7055:3: (enumLiteral_12= 'string' )
                    {
                    // InternalSM2.g:7055:3: (enumLiteral_12= 'string' )
                    // InternalSM2.g:7056:4: enumLiteral_12= 'string'
                    {
                    enumLiteral_12=(Token)match(input,78,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getSTRINGEnumLiteralDeclaration_12().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_12, grammarAccess.getBasicTypeAccess().getSTRINGEnumLiteralDeclaration_12());
                      			
                    }

                    }


                    }
                    break;
                case 14 :
                    // InternalSM2.g:7063:3: (enumLiteral_13= 'address' )
                    {
                    // InternalSM2.g:7063:3: (enumLiteral_13= 'address' )
                    // InternalSM2.g:7064:4: enumLiteral_13= 'address'
                    {
                    enumLiteral_13=(Token)match(input,77,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getADDRESSEnumLiteralDeclaration_13().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_13, grammarAccess.getBasicTypeAccess().getADDRESSEnumLiteralDeclaration_13());
                      			
                    }

                    }


                    }
                    break;
                case 15 :
                    // InternalSM2.g:7071:3: (enumLiteral_14= 'address payable' )
                    {
                    // InternalSM2.g:7071:3: (enumLiteral_14= 'address payable' )
                    // InternalSM2.g:7072:4: enumLiteral_14= 'address payable'
                    {
                    enumLiteral_14=(Token)match(input,101,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_14().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_14, grammarAccess.getBasicTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_14());
                      			
                    }

                    }


                    }
                    break;
                case 16 :
                    // InternalSM2.g:7079:3: (enumLiteral_15= 'double' )
                    {
                    // InternalSM2.g:7079:3: (enumLiteral_15= 'double' )
                    // InternalSM2.g:7080:4: enumLiteral_15= 'double'
                    {
                    enumLiteral_15=(Token)match(input,148,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getDOUBLEEnumLiteralDeclaration_15().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_15, grammarAccess.getBasicTypeAccess().getDOUBLEEnumLiteralDeclaration_15());
                      			
                    }

                    }


                    }
                    break;
                case 17 :
                    // InternalSM2.g:7087:3: (enumLiteral_16= 'bool' )
                    {
                    // InternalSM2.g:7087:3: (enumLiteral_16= 'bool' )
                    // InternalSM2.g:7088:4: enumLiteral_16= 'bool'
                    {
                    enumLiteral_16=(Token)match(input,100,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBOOLEANEnumLiteralDeclaration_16().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_16, grammarAccess.getBasicTypeAccess().getBOOLEANEnumLiteralDeclaration_16());
                      			
                    }

                    }


                    }
                    break;
                case 18 :
                    // InternalSM2.g:7095:3: (enumLiteral_17= 'byte' )
                    {
                    // InternalSM2.g:7095:3: (enumLiteral_17= 'byte' )
                    // InternalSM2.g:7096:4: enumLiteral_17= 'byte'
                    {
                    enumLiteral_17=(Token)match(input,149,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTEEnumLiteralDeclaration_17().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_17, grammarAccess.getBasicTypeAccess().getBYTEEnumLiteralDeclaration_17());
                      			
                    }

                    }


                    }
                    break;
                case 19 :
                    // InternalSM2.g:7103:3: (enumLiteral_18= 'bytes2' )
                    {
                    // InternalSM2.g:7103:3: (enumLiteral_18= 'bytes2' )
                    // InternalSM2.g:7104:4: enumLiteral_18= 'bytes2'
                    {
                    enumLiteral_18=(Token)match(input,103,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE2EnumLiteralDeclaration_18().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_18, grammarAccess.getBasicTypeAccess().getBYTE2EnumLiteralDeclaration_18());
                      			
                    }

                    }


                    }
                    break;
                case 20 :
                    // InternalSM2.g:7111:3: (enumLiteral_19= 'bytes3' )
                    {
                    // InternalSM2.g:7111:3: (enumLiteral_19= 'bytes3' )
                    // InternalSM2.g:7112:4: enumLiteral_19= 'bytes3'
                    {
                    enumLiteral_19=(Token)match(input,104,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE3EnumLiteralDeclaration_19().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_19, grammarAccess.getBasicTypeAccess().getBYTE3EnumLiteralDeclaration_19());
                      			
                    }

                    }


                    }
                    break;
                case 21 :
                    // InternalSM2.g:7119:3: (enumLiteral_20= 'bytes4' )
                    {
                    // InternalSM2.g:7119:3: (enumLiteral_20= 'bytes4' )
                    // InternalSM2.g:7120:4: enumLiteral_20= 'bytes4'
                    {
                    enumLiteral_20=(Token)match(input,105,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE4EnumLiteralDeclaration_20().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_20, grammarAccess.getBasicTypeAccess().getBYTE4EnumLiteralDeclaration_20());
                      			
                    }

                    }


                    }
                    break;
                case 22 :
                    // InternalSM2.g:7127:3: (enumLiteral_21= 'bytes5' )
                    {
                    // InternalSM2.g:7127:3: (enumLiteral_21= 'bytes5' )
                    // InternalSM2.g:7128:4: enumLiteral_21= 'bytes5'
                    {
                    enumLiteral_21=(Token)match(input,106,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE5EnumLiteralDeclaration_21().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_21, grammarAccess.getBasicTypeAccess().getBYTE5EnumLiteralDeclaration_21());
                      			
                    }

                    }


                    }
                    break;
                case 23 :
                    // InternalSM2.g:7135:3: (enumLiteral_22= 'bytes6' )
                    {
                    // InternalSM2.g:7135:3: (enumLiteral_22= 'bytes6' )
                    // InternalSM2.g:7136:4: enumLiteral_22= 'bytes6'
                    {
                    enumLiteral_22=(Token)match(input,107,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE6EnumLiteralDeclaration_22().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_22, grammarAccess.getBasicTypeAccess().getBYTE6EnumLiteralDeclaration_22());
                      			
                    }

                    }


                    }
                    break;
                case 24 :
                    // InternalSM2.g:7143:3: (enumLiteral_23= 'bytes7' )
                    {
                    // InternalSM2.g:7143:3: (enumLiteral_23= 'bytes7' )
                    // InternalSM2.g:7144:4: enumLiteral_23= 'bytes7'
                    {
                    enumLiteral_23=(Token)match(input,108,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE7EnumLiteralDeclaration_23().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_23, grammarAccess.getBasicTypeAccess().getBYTE7EnumLiteralDeclaration_23());
                      			
                    }

                    }


                    }
                    break;
                case 25 :
                    // InternalSM2.g:7151:3: (enumLiteral_24= 'bytes8' )
                    {
                    // InternalSM2.g:7151:3: (enumLiteral_24= 'bytes8' )
                    // InternalSM2.g:7152:4: enumLiteral_24= 'bytes8'
                    {
                    enumLiteral_24=(Token)match(input,109,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE8EnumLiteralDeclaration_24().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_24, grammarAccess.getBasicTypeAccess().getBYTE8EnumLiteralDeclaration_24());
                      			
                    }

                    }


                    }
                    break;
                case 26 :
                    // InternalSM2.g:7159:3: (enumLiteral_25= 'bytes16' )
                    {
                    // InternalSM2.g:7159:3: (enumLiteral_25= 'bytes16' )
                    // InternalSM2.g:7160:4: enumLiteral_25= 'bytes16'
                    {
                    enumLiteral_25=(Token)match(input,110,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE16EnumLiteralDeclaration_25().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_25, grammarAccess.getBasicTypeAccess().getBYTE16EnumLiteralDeclaration_25());
                      			
                    }

                    }


                    }
                    break;
                case 27 :
                    // InternalSM2.g:7167:3: (enumLiteral_26= 'bytes32' )
                    {
                    // InternalSM2.g:7167:3: (enumLiteral_26= 'bytes32' )
                    // InternalSM2.g:7168:4: enumLiteral_26= 'bytes32'
                    {
                    enumLiteral_26=(Token)match(input,111,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE32EnumLiteralDeclaration_26().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_26, grammarAccess.getBasicTypeAccess().getBYTE32EnumLiteralDeclaration_26());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBasicType"


    // $ANTLR start "ruleTimeUnit"
    // InternalSM2.g:7178:1: ruleTimeUnit returns [Enumerator current=null] : ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) ) ;
    public final Enumerator ruleTimeUnit() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:7184:2: ( ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) ) )
            // InternalSM2.g:7185:2: ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) )
            {
            // InternalSM2.g:7185:2: ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) )
            int alt200=6;
            switch ( input.LA(1) ) {
            case 150:
                {
                alt200=1;
                }
                break;
            case 151:
                {
                alt200=2;
                }
                break;
            case 152:
                {
                alt200=3;
                }
                break;
            case 153:
                {
                alt200=4;
                }
                break;
            case 154:
                {
                alt200=5;
                }
                break;
            case 155:
                {
                alt200=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 200, 0, input);

                throw nvae;
            }

            switch (alt200) {
                case 1 :
                    // InternalSM2.g:7186:3: (enumLiteral_0= 'seconds' )
                    {
                    // InternalSM2.g:7186:3: (enumLiteral_0= 'seconds' )
                    // InternalSM2.g:7187:4: enumLiteral_0= 'seconds'
                    {
                    enumLiteral_0=(Token)match(input,150,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getSECONDSEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getTimeUnitAccess().getSECONDSEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:7194:3: (enumLiteral_1= 'minutes' )
                    {
                    // InternalSM2.g:7194:3: (enumLiteral_1= 'minutes' )
                    // InternalSM2.g:7195:4: enumLiteral_1= 'minutes'
                    {
                    enumLiteral_1=(Token)match(input,151,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getMINUTESEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getTimeUnitAccess().getMINUTESEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:7202:3: (enumLiteral_2= 'hours' )
                    {
                    // InternalSM2.g:7202:3: (enumLiteral_2= 'hours' )
                    // InternalSM2.g:7203:4: enumLiteral_2= 'hours'
                    {
                    enumLiteral_2=(Token)match(input,152,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getHOURSEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getTimeUnitAccess().getHOURSEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:7210:3: (enumLiteral_3= 'days' )
                    {
                    // InternalSM2.g:7210:3: (enumLiteral_3= 'days' )
                    // InternalSM2.g:7211:4: enumLiteral_3= 'days'
                    {
                    enumLiteral_3=(Token)match(input,153,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getDAYSEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getTimeUnitAccess().getDAYSEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:7218:3: (enumLiteral_4= 'weeks' )
                    {
                    // InternalSM2.g:7218:3: (enumLiteral_4= 'weeks' )
                    // InternalSM2.g:7219:4: enumLiteral_4= 'weeks'
                    {
                    enumLiteral_4=(Token)match(input,154,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getWEEKSEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getTimeUnitAccess().getWEEKSEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:7226:3: (enumLiteral_5= 'years' )
                    {
                    // InternalSM2.g:7226:3: (enumLiteral_5= 'years' )
                    // InternalSM2.g:7227:4: enumLiteral_5= 'years'
                    {
                    enumLiteral_5=(Token)match(input,155,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getYEARSEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getTimeUnitAccess().getYEARSEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeUnit"

    // $ANTLR start synpred2_InternalSM2
    public final void synpred2_InternalSM2_fragment() throws RecognitionException {   
        // InternalSM2.g:6616:4: ( '*/' )
        // InternalSM2.g:6616:5: '*/'
        {
        match(input,122,FOLLOW_2); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred2_InternalSM2

    // Delegated rules

    public final boolean synpred2_InternalSM2() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred2_InternalSM2_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA20 dfa20 = new DFA20(this);
    protected DFA22 dfa22 = new DFA22(this);
    protected DFA24 dfa24 = new DFA24(this);
    protected DFA26 dfa26 = new DFA26(this);
    protected DFA28 dfa28 = new DFA28(this);
    protected DFA32 dfa32 = new DFA32(this);
    protected DFA34 dfa34 = new DFA34(this);
    protected DFA36 dfa36 = new DFA36(this);
    protected DFA38 dfa38 = new DFA38(this);
    protected DFA40 dfa40 = new DFA40(this);
    protected DFA42 dfa42 = new DFA42(this);
    protected DFA50 dfa50 = new DFA50(this);
    protected DFA48 dfa48 = new DFA48(this);
    protected DFA65 dfa65 = new DFA65(this);
    protected DFA135 dfa135 = new DFA135(this);
    protected DFA137 dfa137 = new DFA137(this);
    protected DFA144 dfa144 = new DFA144(this);
    protected DFA145 dfa145 = new DFA145(this);
    protected DFA164 dfa164 = new DFA164(this);
    protected DFA187 dfa187 = new DFA187(this);
    static final String dfa_1s = "\24\uffff";
    static final String dfa_2s = "\1\uffff\1\2\22\uffff";
    static final String dfa_3s = "\1\63\1\4\1\uffff\15\4\1\uffff\1\6\1\uffff\1\4";
    static final String dfa_4s = "\1\63\1\u0095\1\uffff\1\u0095\1\u009b\2\u0095\11\174\1\uffff\1\6\1\uffff\1\u0095";
    static final String dfa_5s = "\2\uffff\1\2\15\uffff\1\1\1\uffff\1\1\1\uffff";
    static final String dfa_6s = "\24\uffff}>";
    static final String[] dfa_7s = {
            "\1\1",
            "\4\2\2\uffff\1\3\2\2\1\uffff\3\2\1\uffff\1\2\1\uffff\4\2\32\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\16\2\1\uffff\11\2\44\uffff\2\2",
            "",
            "\1\2\5\uffff\1\2\1\uffff\1\6\1\uffff\1\4\1\5\1\2\3\uffff\2\2\34\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\16\2\1\20\1\7\1\10\1\11\1\12\1\13\1\14\1\15\1\16\1\17\44\uffff\2\2",
            "\1\2\1\21\4\uffff\1\2\1\22\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\3\2\10\uffff\16\2\1\uffff\11\2\32\uffff\22\2",
            "\1\2\1\21\4\uffff\1\2\1\22\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\3\2\10\uffff\16\2\1\uffff\11\2\32\uffff\14\2",
            "\1\2\5\uffff\1\2\1\22\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\16\2\1\uffff\11\2\44\uffff\2\2",
            "\1\22\5\uffff\1\2\71\uffff\2\22\15\uffff\2\22\1\uffff\2\22\43\uffff\2\22",
            "\1\22\5\uffff\1\2\71\uffff\2\22\15\uffff\2\22\1\uffff\2\22\43\uffff\2\22",
            "\1\22\5\uffff\1\2\71\uffff\2\22\15\uffff\2\22\1\uffff\2\22\43\uffff\2\22",
            "\1\22\5\uffff\1\2\71\uffff\2\22\15\uffff\2\22\1\uffff\2\22\43\uffff\2\22",
            "\1\22\5\uffff\1\2\71\uffff\2\22\15\uffff\2\22\1\uffff\2\22\43\uffff\2\22",
            "\1\22\5\uffff\1\2\71\uffff\2\22\15\uffff\2\22\1\uffff\2\22\43\uffff\2\22",
            "\1\22\5\uffff\1\2\71\uffff\2\22\15\uffff\2\22\1\uffff\2\22\43\uffff\2\22",
            "\1\22\5\uffff\1\2\71\uffff\2\22\15\uffff\2\22\1\uffff\2\22\43\uffff\2\22",
            "\1\22\5\uffff\1\2\71\uffff\2\22\15\uffff\2\22\1\uffff\2\22\43\uffff\2\22",
            "",
            "\1\23",
            "",
            "\1\2\5\uffff\1\2\1\22\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\16\2\1\uffff\11\2\44\uffff\2\2"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final short[] dfa_2 = DFA.unpackEncodedString(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final char[] dfa_4 = DFA.unpackEncodedStringToUnsignedChars(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[] dfa_6 = DFA.unpackEncodedString(dfa_6s);
    static final short[][] dfa_7 = unpackEncodedStringArray(dfa_7s);

    class DFA20 extends DFA {

        public DFA20(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 20;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "723:4: ( (otherlv_2= 'data' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyBytes_4= rulePropertyBytes | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'data' )";
        }
    }
    static final String dfa_8s = "\26\uffff";
    static final String dfa_9s = "\1\uffff\1\2\24\uffff";
    static final String dfa_10s = "\1\64\1\4\1\uffff\20\4\1\6\1\uffff\1\4";
    static final String dfa_11s = "\1\64\1\u0095\1\uffff\1\u0095\1\u009b\2\u0095\14\174\1\6\1\uffff\1\u0095";
    static final String dfa_12s = "\2\uffff\1\2\21\uffff\1\1\1\uffff";
    static final String dfa_13s = "\26\uffff}>";
    static final String[] dfa_14s = {
            "\1\1",
            "\4\2\2\uffff\1\3\2\2\1\uffff\3\2\1\uffff\1\2\1\uffff\4\2\32\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\16\2\1\uffff\11\2\44\uffff\2\2",
            "",
            "\1\2\5\uffff\1\2\1\uffff\1\6\1\uffff\1\4\1\5\1\2\3\uffff\2\2\34\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\1\7\1\10\1\11\1\12\1\13\1\14\1\15\1\16\1\17\1\20\1\21\1\22\2\2\1\uffff\11\2\44\uffff\2\2",
            "\1\2\1\23\4\uffff\1\2\1\24\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\3\2\10\uffff\16\2\1\uffff\11\2\32\uffff\22\2",
            "\1\2\1\23\4\uffff\1\2\1\24\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\3\2\10\uffff\16\2\1\uffff\11\2\32\uffff\14\2",
            "\1\2\5\uffff\1\2\1\24\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\16\2\1\uffff\11\2\44\uffff\2\2",
            "\1\24\5\uffff\1\2\71\uffff\2\24\15\uffff\2\24\46\uffff\2\24",
            "\1\24\5\uffff\1\2\71\uffff\2\24\15\uffff\2\24\46\uffff\2\24",
            "\1\24\5\uffff\1\2\71\uffff\2\24\15\uffff\2\24\46\uffff\2\24",
            "\1\24\5\uffff\1\2\71\uffff\2\24\15\uffff\2\24\46\uffff\2\24",
            "\1\24\5\uffff\1\2\71\uffff\2\24\15\uffff\2\24\46\uffff\2\24",
            "\1\24\5\uffff\1\2\71\uffff\2\24\15\uffff\2\24\46\uffff\2\24",
            "\1\24\5\uffff\1\2\71\uffff\2\24\15\uffff\2\24\46\uffff\2\24",
            "\1\24\5\uffff\1\2\71\uffff\2\24\15\uffff\2\24\46\uffff\2\24",
            "\1\24\5\uffff\1\2\71\uffff\2\24\15\uffff\2\24\46\uffff\2\24",
            "\1\24\5\uffff\1\2\71\uffff\2\24\15\uffff\2\24\46\uffff\2\24",
            "\1\24\5\uffff\1\2\71\uffff\2\24\15\uffff\2\24\46\uffff\2\24",
            "\1\24\5\uffff\1\2\71\uffff\2\24\15\uffff\2\24\46\uffff\2\24",
            "\1\25",
            "",
            "\1\2\5\uffff\1\2\1\24\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\16\2\1\uffff\11\2\44\uffff\2\2"
    };

    static final short[] dfa_8 = DFA.unpackEncodedString(dfa_8s);
    static final short[] dfa_9 = DFA.unpackEncodedString(dfa_9s);
    static final char[] dfa_10 = DFA.unpackEncodedStringToUnsignedChars(dfa_10s);
    static final char[] dfa_11 = DFA.unpackEncodedStringToUnsignedChars(dfa_11s);
    static final short[] dfa_12 = DFA.unpackEncodedString(dfa_12s);
    static final short[] dfa_13 = DFA.unpackEncodedString(dfa_13s);
    static final short[][] dfa_14 = unpackEncodedStringArray(dfa_14s);

    class DFA22 extends DFA {

        public DFA22(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 22;
            this.eot = dfa_8;
            this.eof = dfa_9;
            this.min = dfa_10;
            this.max = dfa_11;
            this.accept = dfa_12;
            this.special = dfa_13;
            this.transition = dfa_14;
        }
        public String getDescription() {
            return "764:4: ( (otherlv_8= 'value' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'value' )";
        }
    }
    static final String dfa_15s = "\27\uffff";
    static final String dfa_16s = "\1\uffff\1\2\25\uffff";
    static final String dfa_17s = "\1\65\1\4\1\uffff\20\4\2\uffff\1\6\1\4";
    static final String dfa_18s = "\1\65\1\u0095\1\uffff\1\u0095\14\174\1\u0095\1\u009b\1\u0095\2\uffff\1\6\1\u0095";
    static final String dfa_19s = "\2\uffff\1\2\20\uffff\2\1\2\uffff";
    static final String dfa_20s = "\27\uffff}>";
    static final String[] dfa_21s = {
            "\1\1",
            "\4\2\2\uffff\1\3\2\2\1\uffff\3\2\1\uffff\1\2\1\uffff\4\2\32\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\16\2\1\uffff\11\2\44\uffff\2\2",
            "",
            "\1\2\5\uffff\1\2\1\uffff\1\20\1\uffff\1\21\1\22\1\2\3\uffff\2\2\34\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\14\1\15\1\16\1\17\2\2\1\uffff\11\2\44\uffff\2\2",
            "\1\23\5\uffff\1\2\71\uffff\2\23\15\uffff\2\23\46\uffff\2\23",
            "\1\23\5\uffff\1\2\71\uffff\2\23\15\uffff\2\23\46\uffff\2\23",
            "\1\23\5\uffff\1\2\71\uffff\2\23\15\uffff\2\23\46\uffff\2\23",
            "\1\23\5\uffff\1\2\71\uffff\2\23\15\uffff\2\23\46\uffff\2\23",
            "\1\23\5\uffff\1\2\71\uffff\2\23\15\uffff\2\23\46\uffff\2\23",
            "\1\23\5\uffff\1\2\71\uffff\2\23\15\uffff\2\23\46\uffff\2\23",
            "\1\23\5\uffff\1\2\71\uffff\2\23\15\uffff\2\23\46\uffff\2\23",
            "\1\23\5\uffff\1\2\71\uffff\2\23\15\uffff\2\23\46\uffff\2\23",
            "\1\23\5\uffff\1\2\71\uffff\2\23\15\uffff\2\23\46\uffff\2\23",
            "\1\23\5\uffff\1\2\71\uffff\2\23\15\uffff\2\23\46\uffff\2\23",
            "\1\23\5\uffff\1\2\71\uffff\2\23\15\uffff\2\23\46\uffff\2\23",
            "\1\23\5\uffff\1\2\71\uffff\2\23\15\uffff\2\23\46\uffff\2\23",
            "\1\2\5\uffff\1\2\1\24\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\16\2\1\uffff\11\2\44\uffff\2\2",
            "\1\2\1\25\4\uffff\1\2\1\24\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\3\2\10\uffff\16\2\1\uffff\11\2\32\uffff\22\2",
            "\1\2\1\25\4\uffff\1\2\1\24\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\3\2\10\uffff\16\2\1\uffff\11\2\32\uffff\14\2",
            "",
            "",
            "\1\26",
            "\1\2\5\uffff\1\2\1\24\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\16\2\1\uffff\11\2\44\uffff\2\2"
    };

    static final short[] dfa_15 = DFA.unpackEncodedString(dfa_15s);
    static final short[] dfa_16 = DFA.unpackEncodedString(dfa_16s);
    static final char[] dfa_17 = DFA.unpackEncodedStringToUnsignedChars(dfa_17s);
    static final char[] dfa_18 = DFA.unpackEncodedStringToUnsignedChars(dfa_18s);
    static final short[] dfa_19 = DFA.unpackEncodedString(dfa_19s);
    static final short[] dfa_20 = DFA.unpackEncodedString(dfa_20s);
    static final short[][] dfa_21 = unpackEncodedStringArray(dfa_21s);

    class DFA24 extends DFA {

        public DFA24(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 24;
            this.eot = dfa_15;
            this.eof = dfa_16;
            this.min = dfa_17;
            this.max = dfa_18;
            this.accept = dfa_19;
            this.special = dfa_20;
            this.transition = dfa_21;
        }
        public String getDescription() {
            return "805:4: ( (otherlv_14= 'gas' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'gas' )";
        }
    }
    static final String dfa_22s = "\14\uffff";
    static final String dfa_23s = "\1\uffff\1\3\12\uffff";
    static final String dfa_24s = "\1\66\2\4\1\uffff\5\4\1\6\1\uffff\1\4";
    static final String dfa_25s = "\1\66\2\u0095\1\uffff\1\u009b\2\u0095\2\174\1\6\1\uffff\1\u0095";
    static final String dfa_26s = "\3\uffff\1\2\6\uffff\1\1\1\uffff";
    static final String dfa_27s = "\14\uffff}>";
    static final String[] dfa_28s = {
            "\1\1",
            "\4\3\2\uffff\1\2\2\3\1\uffff\3\3\1\uffff\1\3\1\uffff\4\3\32\uffff\1\3\5\uffff\1\3\6\uffff\2\3\10\uffff\1\3\3\uffff\2\3\11\uffff\16\3\1\uffff\11\3\44\uffff\2\3",
            "\1\3\5\uffff\1\3\1\uffff\1\6\1\uffff\1\4\1\5\1\3\3\uffff\2\3\34\uffff\1\3\5\uffff\1\3\6\uffff\2\3\10\uffff\1\3\3\uffff\1\7\1\3\11\uffff\15\3\1\10\1\uffff\11\3\44\uffff\2\3",
            "",
            "\1\3\1\11\4\uffff\1\3\1\12\1\3\1\uffff\3\3\3\uffff\3\3\33\uffff\1\3\5\uffff\1\3\6\uffff\2\3\10\uffff\1\3\3\uffff\3\3\10\uffff\16\3\1\uffff\11\3\32\uffff\22\3",
            "\1\3\1\11\4\uffff\1\3\1\12\1\3\1\uffff\3\3\3\uffff\3\3\33\uffff\1\3\5\uffff\1\3\6\uffff\2\3\10\uffff\1\3\3\uffff\3\3\10\uffff\16\3\1\uffff\11\3\32\uffff\14\3",
            "\1\3\5\uffff\1\3\1\12\1\3\1\uffff\3\3\3\uffff\3\3\33\uffff\1\3\5\uffff\1\3\6\uffff\2\3\10\uffff\1\3\3\uffff\2\3\11\uffff\16\3\1\uffff\11\3\44\uffff\2\3",
            "\1\12\5\uffff\1\3\71\uffff\2\12\15\uffff\2\12\46\uffff\2\12",
            "\1\12\5\uffff\1\3\71\uffff\2\12\15\uffff\2\12\46\uffff\2\12",
            "\1\13",
            "",
            "\1\3\5\uffff\1\3\1\12\1\3\1\uffff\3\3\3\uffff\3\3\33\uffff\1\3\5\uffff\1\3\6\uffff\2\3\10\uffff\1\3\3\uffff\2\3\11\uffff\16\3\1\uffff\11\3\44\uffff\2\3"
    };

    static final short[] dfa_22 = DFA.unpackEncodedString(dfa_22s);
    static final short[] dfa_23 = DFA.unpackEncodedString(dfa_23s);
    static final char[] dfa_24 = DFA.unpackEncodedStringToUnsignedChars(dfa_24s);
    static final char[] dfa_25 = DFA.unpackEncodedStringToUnsignedChars(dfa_25s);
    static final short[] dfa_26 = DFA.unpackEncodedString(dfa_26s);
    static final short[] dfa_27 = DFA.unpackEncodedString(dfa_27s);
    static final short[][] dfa_28 = unpackEncodedStringArray(dfa_28s);

    class DFA26 extends DFA {

        public DFA26(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 26;
            this.eot = dfa_22;
            this.eof = dfa_23;
            this.min = dfa_24;
            this.max = dfa_25;
            this.accept = dfa_26;
            this.special = dfa_27;
            this.transition = dfa_28;
        }
        public String getDescription() {
            return "846:4: ( (otherlv_20= 'sender' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sender' )";
        }
    }
    static final String dfa_29s = "\1\67\1\4\1\uffff\15\4\1\uffff\1\6\1\uffff\1\4";
    static final String dfa_30s = "\1\67\1\u0095\1\uffff\1\u0095\1\u009b\2\u0095\11\174\1\uffff\1\6\1\uffff\1\u0095";
    static final char[] dfa_29 = DFA.unpackEncodedStringToUnsignedChars(dfa_29s);
    static final char[] dfa_30 = DFA.unpackEncodedStringToUnsignedChars(dfa_30s);

    class DFA28 extends DFA {

        public DFA28(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 28;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_29;
            this.max = dfa_30;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "887:4: ( (otherlv_26= 'sig' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyBytes_28= rulePropertyBytes | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'sig' )";
        }
    }
    static final String dfa_31s = "\1\71\1\4\1\uffff\20\4\1\6\1\uffff\1\4";
    static final String dfa_32s = "\1\71\1\u0095\1\uffff\1\u0095\1\u009b\2\u0095\14\174\1\6\1\uffff\1\u0095";
    static final char[] dfa_31 = DFA.unpackEncodedStringToUnsignedChars(dfa_31s);
    static final char[] dfa_32 = DFA.unpackEncodedStringToUnsignedChars(dfa_32s);

    class DFA32 extends DFA {

        public DFA32(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 32;
            this.eot = dfa_8;
            this.eof = dfa_9;
            this.min = dfa_31;
            this.max = dfa_32;
            this.accept = dfa_12;
            this.special = dfa_13;
            this.transition = dfa_14;
        }
        public String getDescription() {
            return "967:5: ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS (this_PropertyInteger_4= rulePropertyInteger | this_SyntaxExpression_5= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | otherlv_7= 'difficulty' )";
        }
    }
    static final String dfa_33s = "\1\72\1\4\1\uffff\20\4\1\6\1\uffff\1\4";
    static final String dfa_34s = "\1\72\1\u0095\1\uffff\1\u0095\1\u009b\2\u0095\14\174\1\6\1\uffff\1\u0095";
    static final char[] dfa_33 = DFA.unpackEncodedStringToUnsignedChars(dfa_33s);
    static final char[] dfa_34 = DFA.unpackEncodedStringToUnsignedChars(dfa_34s);

    class DFA34 extends DFA {

        public DFA34(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 34;
            this.eot = dfa_8;
            this.eof = dfa_9;
            this.min = dfa_33;
            this.max = dfa_34;
            this.accept = dfa_12;
            this.special = dfa_13;
            this.transition = dfa_14;
        }
        public String getDescription() {
            return "1008:5: ( (otherlv_8= 'number' this_OPENPARENTHESIS_9= RULE_OPENPARENTHESIS (this_PropertyInteger_10= rulePropertyInteger | this_SyntaxExpression_11= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS ) | otherlv_13= 'number' )";
        }
    }
    static final String dfa_35s = "\1\73\1\4\1\uffff\20\4\1\6\1\uffff\1\4";
    static final String dfa_36s = "\1\73\1\u0095\1\uffff\1\u0095\1\u009b\2\u0095\14\174\1\6\1\uffff\1\u0095";
    static final char[] dfa_35 = DFA.unpackEncodedStringToUnsignedChars(dfa_35s);
    static final char[] dfa_36 = DFA.unpackEncodedStringToUnsignedChars(dfa_36s);

    class DFA36 extends DFA {

        public DFA36(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 36;
            this.eot = dfa_8;
            this.eof = dfa_9;
            this.min = dfa_35;
            this.max = dfa_36;
            this.accept = dfa_12;
            this.special = dfa_13;
            this.transition = dfa_14;
        }
        public String getDescription() {
            return "1049:5: ( (otherlv_14= 'timestamp' this_OPENPARENTHESIS_15= RULE_OPENPARENTHESIS (this_PropertyInteger_16= rulePropertyInteger | this_SyntaxExpression_17= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_18= RULE_CLOSEPARENTHESIS ) | otherlv_19= 'timestamp' )";
        }
    }
    static final String dfa_37s = "\1\uffff\1\2\12\uffff";
    static final String dfa_38s = "\1\74\1\4\1\uffff\6\4\1\6\1\uffff\1\4";
    static final String dfa_39s = "\1\74\1\u0095\1\uffff\1\u0095\1\u009b\2\u0095\2\174\1\6\1\uffff\1\u0095";
    static final String dfa_40s = "\2\uffff\1\2\7\uffff\1\1\1\uffff";
    static final String[] dfa_41s = {
            "\1\1",
            "\4\2\2\uffff\1\3\2\2\1\uffff\3\2\1\uffff\1\2\1\uffff\4\2\32\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\16\2\1\uffff\11\2\44\uffff\2\2",
            "",
            "\1\2\5\uffff\1\2\1\uffff\1\6\1\uffff\1\4\1\5\1\2\3\uffff\2\2\34\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\1\7\1\2\11\uffff\15\2\1\10\1\uffff\11\2\44\uffff\2\2",
            "\1\2\1\11\4\uffff\1\2\1\12\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\3\2\10\uffff\16\2\1\uffff\11\2\32\uffff\22\2",
            "\1\2\1\11\4\uffff\1\2\1\12\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\3\2\10\uffff\16\2\1\uffff\11\2\32\uffff\14\2",
            "\1\2\5\uffff\1\2\1\12\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\16\2\1\uffff\11\2\44\uffff\2\2",
            "\1\12\5\uffff\1\2\71\uffff\2\12\15\uffff\2\12\46\uffff\2\12",
            "\1\12\5\uffff\1\2\71\uffff\2\12\15\uffff\2\12\46\uffff\2\12",
            "\1\13",
            "",
            "\1\2\5\uffff\1\2\1\12\1\2\1\uffff\3\2\3\uffff\3\2\33\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\2\3\uffff\2\2\11\uffff\16\2\1\uffff\11\2\44\uffff\2\2"
    };
    static final short[] dfa_37 = DFA.unpackEncodedString(dfa_37s);
    static final char[] dfa_38 = DFA.unpackEncodedStringToUnsignedChars(dfa_38s);
    static final char[] dfa_39 = DFA.unpackEncodedStringToUnsignedChars(dfa_39s);
    static final short[] dfa_40 = DFA.unpackEncodedString(dfa_40s);
    static final short[][] dfa_41 = unpackEncodedStringArray(dfa_41s);

    class DFA38 extends DFA {

        public DFA38(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 38;
            this.eot = dfa_22;
            this.eof = dfa_37;
            this.min = dfa_38;
            this.max = dfa_39;
            this.accept = dfa_40;
            this.special = dfa_27;
            this.transition = dfa_41;
        }
        public String getDescription() {
            return "1090:5: ( (otherlv_20= 'coinbase' this_OPENPARENTHESIS_21= RULE_OPENPARENTHESIS (this_PropertyAddress_22= rulePropertyAddress | this_SyntaxExpression_23= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'coinbase' )";
        }
    }
    static final String dfa_42s = "\1\75\1\4\1\uffff\20\4\1\6\1\uffff\1\4";
    static final String dfa_43s = "\1\75\1\u0095\1\uffff\1\u0095\1\u009b\2\u0095\14\174\1\6\1\uffff\1\u0095";
    static final char[] dfa_42 = DFA.unpackEncodedStringToUnsignedChars(dfa_42s);
    static final char[] dfa_43 = DFA.unpackEncodedStringToUnsignedChars(dfa_43s);

    class DFA40 extends DFA {

        public DFA40(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 40;
            this.eot = dfa_8;
            this.eof = dfa_9;
            this.min = dfa_42;
            this.max = dfa_43;
            this.accept = dfa_12;
            this.special = dfa_13;
            this.transition = dfa_14;
        }
        public String getDescription() {
            return "1131:5: ( (otherlv_26= 'gaslimit' this_OPENPARENTHESIS_27= RULE_OPENPARENTHESIS (this_PropertyInteger_28= rulePropertyInteger | this_SyntaxExpression_29= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'gaslimit' )";
        }
    }
    static final String dfa_44s = "\1\76\1\4\1\uffff\20\4\1\6\1\uffff\1\4";
    static final String dfa_45s = "\1\76\1\u0095\1\uffff\1\u0095\1\u009b\2\u0095\14\174\1\6\1\uffff\1\u0095";
    static final char[] dfa_44 = DFA.unpackEncodedStringToUnsignedChars(dfa_44s);
    static final char[] dfa_45 = DFA.unpackEncodedStringToUnsignedChars(dfa_45s);

    class DFA42 extends DFA {

        public DFA42(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 42;
            this.eot = dfa_8;
            this.eof = dfa_9;
            this.min = dfa_44;
            this.max = dfa_45;
            this.accept = dfa_12;
            this.special = dfa_13;
            this.transition = dfa_14;
        }
        public String getDescription() {
            return "1172:5: ( (otherlv_32= 'blockhash' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS (this_PropertyInteger_34= rulePropertyInteger | this_SyntaxExpression_35= ruleSyntaxExpression ) this_CLOSEPARENTHESIS_36= RULE_CLOSEPARENTHESIS ) | otherlv_37= 'blockhash' )";
        }
    }
    static final String dfa_46s = "\2\uffff\1\4\24\uffff";
    static final String dfa_47s = "\1\101\1\uffff\2\4\1\uffff\17\4\1\6\1\uffff\1\4";
    static final String dfa_48s = "\1\102\1\uffff\2\u0095\1\uffff\1\u009b\2\u0095\14\174\1\6\1\uffff\1\u0095";
    static final String dfa_49s = "\1\uffff\1\1\2\uffff\1\3\20\uffff\1\2\1\uffff";
    static final String[] dfa_50s = {
            "\1\1\1\2",
            "",
            "\4\4\2\uffff\1\3\2\4\1\uffff\3\4\1\uffff\1\4\1\uffff\4\4\32\uffff\1\4\5\uffff\1\4\6\uffff\2\4\10\uffff\1\4\3\uffff\2\4\11\uffff\16\4\1\uffff\11\4\44\uffff\2\4",
            "\1\4\5\uffff\1\4\1\uffff\1\7\1\uffff\1\5\1\6\1\4\3\uffff\2\4\34\uffff\1\4\5\uffff\1\4\6\uffff\2\4\10\uffff\1\4\3\uffff\2\4\11\uffff\1\10\1\11\1\12\1\13\1\14\1\15\1\16\1\17\1\20\1\21\1\22\1\23\2\4\1\uffff\11\4\44\uffff\2\4",
            "",
            "\1\4\1\24\4\uffff\1\4\1\25\1\4\1\uffff\3\4\3\uffff\3\4\33\uffff\1\4\5\uffff\1\4\6\uffff\2\4\10\uffff\1\4\3\uffff\3\4\10\uffff\16\4\1\uffff\11\4\32\uffff\22\4",
            "\1\4\1\24\4\uffff\1\4\1\25\1\4\1\uffff\3\4\3\uffff\3\4\33\uffff\1\4\5\uffff\1\4\6\uffff\2\4\10\uffff\1\4\3\uffff\3\4\10\uffff\16\4\1\uffff\11\4\32\uffff\14\4",
            "\1\4\5\uffff\1\4\1\25\1\4\1\uffff\3\4\3\uffff\3\4\33\uffff\1\4\5\uffff\1\4\6\uffff\2\4\10\uffff\1\4\3\uffff\2\4\11\uffff\16\4\1\uffff\11\4\44\uffff\2\4",
            "\1\25\5\uffff\1\4\71\uffff\2\25\15\uffff\2\25\46\uffff\2\25",
            "\1\25\5\uffff\1\4\71\uffff\2\25\15\uffff\2\25\46\uffff\2\25",
            "\1\25\5\uffff\1\4\71\uffff\2\25\15\uffff\2\25\46\uffff\2\25",
            "\1\25\5\uffff\1\4\71\uffff\2\25\15\uffff\2\25\46\uffff\2\25",
            "\1\25\5\uffff\1\4\71\uffff\2\25\15\uffff\2\25\46\uffff\2\25",
            "\1\25\5\uffff\1\4\71\uffff\2\25\15\uffff\2\25\46\uffff\2\25",
            "\1\25\5\uffff\1\4\71\uffff\2\25\15\uffff\2\25\46\uffff\2\25",
            "\1\25\5\uffff\1\4\71\uffff\2\25\15\uffff\2\25\46\uffff\2\25",
            "\1\25\5\uffff\1\4\71\uffff\2\25\15\uffff\2\25\46\uffff\2\25",
            "\1\25\5\uffff\1\4\71\uffff\2\25\15\uffff\2\25\46\uffff\2\25",
            "\1\25\5\uffff\1\4\71\uffff\2\25\15\uffff\2\25\46\uffff\2\25",
            "\1\25\5\uffff\1\4\71\uffff\2\25\15\uffff\2\25\46\uffff\2\25",
            "\1\26",
            "",
            "\1\4\5\uffff\1\4\1\25\1\4\1\uffff\3\4\3\uffff\3\4\33\uffff\1\4\5\uffff\1\4\6\uffff\2\4\10\uffff\1\4\3\uffff\2\4\11\uffff\16\4\1\uffff\11\4\44\uffff\2\4"
    };
    static final short[] dfa_46 = DFA.unpackEncodedString(dfa_46s);
    static final char[] dfa_47 = DFA.unpackEncodedStringToUnsignedChars(dfa_47s);
    static final char[] dfa_48 = DFA.unpackEncodedStringToUnsignedChars(dfa_48s);
    static final short[] dfa_49 = DFA.unpackEncodedString(dfa_49s);
    static final short[][] dfa_50 = unpackEncodedStringArray(dfa_50s);

    class DFA50 extends DFA {

        public DFA50(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 50;
            this.eot = dfa_15;
            this.eof = dfa_46;
            this.min = dfa_47;
            this.max = dfa_48;
            this.accept = dfa_49;
            this.special = dfa_20;
            this.transition = dfa_50;
        }
        public String getDescription() {
            return "1281:3: ( ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ( ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'gasprice' ) | ( (otherlv_7= 'origin' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ( ( (lv_inputparam_9_1= rulePropertyInteger | lv_inputparam_9_2= ruleSyntaxExpression ) ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'origin' )";
        }
    }
    static final String dfa_51s = "\1\101\2\4\1\uffff\5\4\1\6\1\uffff\1\4";
    static final String dfa_52s = "\1\101\2\u0095\1\uffff\1\u009b\2\u0095\2\174\1\6\1\uffff\1\u0095";
    static final char[] dfa_51 = DFA.unpackEncodedStringToUnsignedChars(dfa_51s);
    static final char[] dfa_52 = DFA.unpackEncodedStringToUnsignedChars(dfa_52s);

    class DFA48 extends DFA {

        public DFA48(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 48;
            this.eot = dfa_22;
            this.eof = dfa_23;
            this.min = dfa_51;
            this.max = dfa_52;
            this.accept = dfa_26;
            this.special = dfa_27;
            this.transition = dfa_28;
        }
        public String getDescription() {
            return "1282:4: ( (otherlv_2= 'gasprice' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ( ( (lv_inputparam_4_1= rulePropertyAddress | lv_inputparam_4_2= ruleSyntaxExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'gasprice' )";
        }
    }
    static final String dfa_53s = "\36\uffff";
    static final String dfa_54s = "\1\114\1\4\1\10\3\4\1\uffff\1\5\1\6\1\7\1\14\1\5\1\14\1\6\1\5\1\116\1\14\1\5\1\14\1\6\1\5\1\116\1\14\1\5\1\15\1\6\1\5\1\116\2\uffff";
    static final String dfa_55s = "\1\114\1\4\1\10\2\157\1\174\1\uffff\1\117\2\116\1\14\1\117\1\14\1\116\1\5\1\116\1\14\1\117\1\14\1\116\1\5\1\116\1\14\1\117\1\15\1\120\1\5\1\120\2\uffff";
    static final String dfa_56s = "\6\uffff\1\1\25\uffff\1\2\1\3";
    static final String dfa_57s = "\36\uffff}>";
    static final String[] dfa_58s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\6\1\uffff\1\4\106\uffff\1\5\1\6\1\uffff\1\6\7\uffff\30\6",
            "\1\6\110\uffff\1\5\1\6\1\uffff\1\6\7\uffff\30\6",
            "\1\7\77\uffff\2\6\15\uffff\2\6\46\uffff\2\6",
            "",
            "\1\10\111\uffff\1\6",
            "\1\11\1\6\106\uffff\1\12",
            "\1\6\106\uffff\1\12",
            "\1\13",
            "\1\15\111\uffff\1\14",
            "\1\16",
            "\1\17\107\uffff\1\20",
            "\1\15",
            "\1\20",
            "\1\21",
            "\1\23\111\uffff\1\22",
            "\1\24",
            "\1\25\107\uffff\1\26",
            "\1\23",
            "\1\26",
            "\1\27",
            "\1\31\111\uffff\1\30",
            "\1\32",
            "\1\33\107\uffff\1\35\1\uffff\1\34",
            "\1\31",
            "\1\35\1\uffff\1\34",
            "",
            ""
    };

    static final short[] dfa_53 = DFA.unpackEncodedString(dfa_53s);
    static final char[] dfa_54 = DFA.unpackEncodedStringToUnsignedChars(dfa_54s);
    static final char[] dfa_55 = DFA.unpackEncodedStringToUnsignedChars(dfa_55s);
    static final short[] dfa_56 = DFA.unpackEncodedString(dfa_56s);
    static final short[] dfa_57 = DFA.unpackEncodedString(dfa_57s);
    static final short[][] dfa_58 = unpackEncodedStringArray(dfa_58s);

    class DFA65 extends DFA {

        public DFA65(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 65;
            this.eot = dfa_53;
            this.eof = dfa_53;
            this.min = dfa_54;
            this.max = dfa_55;
            this.accept = dfa_56;
            this.special = dfa_57;
            this.transition = dfa_58;
        }
        public String getDescription() {
            return "1932:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )";
        }
    }
    static final String dfa_59s = "\22\uffff";
    static final String dfa_60s = "\1\4\1\12\1\uffff\1\14\1\52\2\5\6\14\1\6\1\uffff\2\5\1\52";
    static final String dfa_61s = "\1\u0095\1\12\1\uffff\1\17\3\u0087\6\17\1\6\1\uffff\2\u0082\1\u0087";
    static final String dfa_62s = "\2\uffff\1\2\13\uffff\1\1\3\uffff";
    static final String dfa_63s = "\22\uffff}>";
    static final String[] dfa_64s = {
            "\1\2\5\uffff\1\2\1\uffff\1\2\1\uffff\3\2\2\uffff\3\2\34\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\2\2\1\uffff\3\2\1\uffff\1\2\1\uffff\1\2\5\uffff\30\2\1\1\43\uffff\2\2",
            "\1\3",
            "",
            "\1\4\1\uffff\1\5\1\6",
            "\1\11\1\10\110\uffff\1\13\20\uffff\1\7\1\12\1\14",
            "\1\15\44\uffff\1\11\1\10\110\uffff\1\13\20\uffff\1\7\1\12\1\14",
            "\1\15\44\uffff\1\11\1\10\110\uffff\1\13\20\uffff\1\7\1\12\1\14",
            "\1\16\1\uffff\1\17\1\20",
            "\1\16\1\uffff\1\17\1\20",
            "\1\16\1\uffff\1\17\1\20",
            "\1\16\1\uffff\1\17\1\20",
            "\1\16\1\uffff\1\17\1\20",
            "\1\16\1\uffff\1\17\1\20",
            "\1\21",
            "",
            "\1\16\5\uffff\1\16\161\uffff\6\2",
            "\1\16\5\uffff\1\16\161\uffff\6\2",
            "\1\11\1\10\110\uffff\1\13\20\uffff\1\7\1\12\1\14"
    };

    static final short[] dfa_59 = DFA.unpackEncodedString(dfa_59s);
    static final char[] dfa_60 = DFA.unpackEncodedStringToUnsignedChars(dfa_60s);
    static final char[] dfa_61 = DFA.unpackEncodedStringToUnsignedChars(dfa_61s);
    static final short[] dfa_62 = DFA.unpackEncodedString(dfa_62s);
    static final short[] dfa_63 = DFA.unpackEncodedString(dfa_63s);
    static final short[][] dfa_64 = unpackEncodedStringArray(dfa_64s);

    class DFA135 extends DFA {

        public DFA135(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 135;
            this.eot = dfa_59;
            this.eof = dfa_59;
            this.min = dfa_60;
            this.max = dfa_61;
            this.accept = dfa_62;
            this.special = dfa_63;
            this.transition = dfa_64;
        }
        public String getDescription() {
            return "4352:3: ( (lv_restriction_3_0= ruleRestriction ) )?";
        }
    }
    static final String dfa_65s = "\35\uffff";
    static final String dfa_66s = "\1\4\1\5\14\4\1\uffff\15\4\1\uffff";
    static final String dfa_67s = "\1\u0095\1\127\14\174\1\uffff\14\174\1\u0093\1\uffff";
    static final String dfa_68s = "\16\uffff\1\1\15\uffff\1\2";
    static final String dfa_69s = "\35\uffff}>";
    static final String[] dfa_70s = {
            "\1\33\5\uffff\1\34\1\uffff\1\34\1\uffff\3\34\2\uffff\3\34\34\uffff\1\34\5\uffff\1\34\6\uffff\2\34\10\uffff\1\34\1\16\1\uffff\1\16\1\17\1\1\1\uffff\1\16\1\uffff\1\16\5\uffff\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\14\1\15\1\21\1\20\1\16\1\22\1\23\1\24\1\25\1\26\1\27\1\30\1\31\1\32\44\uffff\2\34",
            "\1\16\4\uffff\1\34\104\uffff\1\16\6\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\46\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\46\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\46\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\46\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\46\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\46\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\46\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\46\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\46\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\46\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\46\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\46\uffff\2\16",
            "",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\46\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\46\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\1\uffff\2\16\43\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\1\uffff\2\16\43\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\1\uffff\2\16\43\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\1\uffff\2\16\43\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\1\uffff\2\16\43\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\1\uffff\2\16\43\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\1\uffff\2\16\43\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\1\uffff\2\16\43\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\1\uffff\2\16\43\uffff\2\16",
            "\1\16\5\uffff\1\34\71\uffff\2\16\15\uffff\2\16\1\uffff\2\16\43\uffff\2\16",
            "\1\16\77\uffff\2\16\11\uffff\1\34\3\uffff\2\16\46\uffff\2\16\15\uffff\12\34",
            ""
    };

    static final short[] dfa_65 = DFA.unpackEncodedString(dfa_65s);
    static final char[] dfa_66 = DFA.unpackEncodedStringToUnsignedChars(dfa_66s);
    static final char[] dfa_67 = DFA.unpackEncodedStringToUnsignedChars(dfa_67s);
    static final short[] dfa_68 = DFA.unpackEncodedString(dfa_68s);
    static final short[] dfa_69 = DFA.unpackEncodedString(dfa_69s);
    static final short[][] dfa_70 = unpackEncodedStringArray(dfa_70s);

    class DFA137 extends DFA {

        public DFA137(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 137;
            this.eot = dfa_65;
            this.eof = dfa_65;
            this.min = dfa_66;
            this.max = dfa_67;
            this.accept = dfa_68;
            this.special = dfa_69;
            this.transition = dfa_70;
        }
        public String getDescription() {
            return "4390:3: ( (lv_localAttributes_5_0= ruleAttributes ) )?";
        }
    }
    static final String dfa_71s = "\43\uffff";
    static final String dfa_72s = "\2\uffff\2\5\37\uffff";
    static final String dfa_73s = "\4\4\10\uffff\2\4\1\117\1\uffff\21\4\2\uffff";
    static final String dfa_74s = "\2\u0095\1\u009b\1\u0095\10\uffff\1\u009b\1\u0095\1\u0093\1\uffff\13\17\6\u0095\2\uffff";
    static final String dfa_75s = "\4\uffff\1\1\1\3\1\4\1\5\1\6\1\7\1\10\1\11\3\uffff\1\12\21\uffff\1\2\1\1";
    static final String dfa_76s = "\43\uffff}>";
    static final String[] dfa_77s = {
            "\1\4\5\uffff\1\1\1\uffff\1\5\1\uffff\1\2\1\3\1\6\3\uffff\1\11\1\13\34\uffff\1\7\5\uffff\1\7\6\uffff\2\7\10\uffff\1\10\3\uffff\2\12\11\uffff\16\12\1\uffff\11\12\44\uffff\2\12",
            "\1\16\5\uffff\1\17\1\uffff\1\17\1\uffff\1\14\1\15\1\17\3\uffff\2\17\34\uffff\1\17\5\uffff\1\17\6\uffff\2\17\10\uffff\1\17\3\uffff\2\17\11\uffff\16\17\1\uffff\11\17\44\uffff\2\17",
            "\4\5\2\uffff\3\5\1\uffff\3\5\1\uffff\1\5\1\uffff\4\5\32\uffff\1\5\5\uffff\1\5\6\uffff\2\5\10\uffff\1\5\3\uffff\2\5\1\4\10\uffff\16\5\1\uffff\11\5\32\uffff\12\4\2\5\6\6",
            "\4\5\2\uffff\3\5\1\uffff\3\5\1\uffff\1\5\1\uffff\4\5\32\uffff\1\5\5\uffff\1\5\6\uffff\2\5\10\uffff\1\5\3\uffff\2\5\1\4\10\uffff\16\5\1\uffff\11\5\32\uffff\12\4\2\5",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\2\17\4\uffff\3\17\1\uffff\3\17\3\uffff\3\17\33\uffff\1\17\5\uffff\1\17\6\uffff\2\17\10\uffff\1\17\3\uffff\2\17\1\25\10\uffff\16\17\1\uffff\11\17\32\uffff\1\20\1\21\1\22\1\23\1\24\1\26\1\27\1\30\1\31\1\32\10\17",
            "\2\17\4\uffff\3\17\1\uffff\3\17\3\uffff\3\17\33\uffff\1\17\5\uffff\1\17\6\uffff\2\17\10\uffff\1\17\3\uffff\2\17\1\25\10\uffff\16\17\1\uffff\11\17\32\uffff\1\20\1\21\1\22\1\23\1\24\1\26\1\27\1\30\1\31\1\32\2\17",
            "\1\25\72\uffff\1\20\1\21\1\22\1\23\1\24\1\26\1\27\1\30\1\31\1\32",
            "",
            "\1\35\11\uffff\1\33\1\34",
            "\1\35\11\uffff\1\33\1\34",
            "\1\35\11\uffff\1\33\1\34",
            "\1\35\11\uffff\1\33\1\34",
            "\1\35\11\uffff\1\33\1\34",
            "\1\40\11\uffff\1\36\1\37",
            "\1\40\11\uffff\1\36\1\37",
            "\1\40\11\uffff\1\36\1\37",
            "\1\40\11\uffff\1\36\1\37",
            "\1\40\11\uffff\1\36\1\37",
            "\1\40\11\uffff\1\36\1\37",
            "\2\17\4\uffff\1\17\1\42\1\17\1\uffff\3\17\3\uffff\3\17\23\uffff\2\41\6\uffff\1\17\5\uffff\1\17\6\uffff\2\17\10\uffff\1\17\3\uffff\2\17\11\uffff\16\17\1\uffff\11\17\4\uffff\1\41\20\uffff\3\41\14\uffff\2\17",
            "\2\17\4\uffff\1\17\1\42\1\17\1\uffff\3\17\3\uffff\3\17\23\uffff\2\41\6\uffff\1\17\5\uffff\1\17\6\uffff\2\17\10\uffff\1\17\3\uffff\2\17\11\uffff\16\17\1\uffff\11\17\4\uffff\1\41\20\uffff\3\41\14\uffff\2\17",
            "\2\17\4\uffff\1\17\1\42\1\17\1\uffff\3\17\3\uffff\3\17\23\uffff\2\41\6\uffff\1\17\5\uffff\1\17\6\uffff\2\17\10\uffff\1\17\3\uffff\2\17\11\uffff\16\17\1\uffff\11\17\4\uffff\1\41\20\uffff\3\41\14\uffff\2\17",
            "\2\17\4\uffff\1\17\1\42\1\17\1\uffff\3\17\3\uffff\3\17\33\uffff\1\17\5\uffff\1\17\6\uffff\2\17\10\uffff\1\17\3\uffff\2\17\11\uffff\16\17\1\uffff\11\17\44\uffff\2\17",
            "\2\17\4\uffff\1\17\1\42\1\17\1\uffff\3\17\3\uffff\3\17\33\uffff\1\17\5\uffff\1\17\6\uffff\2\17\10\uffff\1\17\3\uffff\2\17\11\uffff\16\17\1\uffff\11\17\44\uffff\2\17",
            "\2\17\4\uffff\1\17\1\42\1\17\1\uffff\3\17\3\uffff\3\17\33\uffff\1\17\5\uffff\1\17\6\uffff\2\17\10\uffff\1\17\3\uffff\2\17\11\uffff\16\17\1\uffff\11\17\44\uffff\2\17",
            "",
            ""
    };

    static final short[] dfa_71 = DFA.unpackEncodedString(dfa_71s);
    static final short[] dfa_72 = DFA.unpackEncodedString(dfa_72s);
    static final char[] dfa_73 = DFA.unpackEncodedStringToUnsignedChars(dfa_73s);
    static final char[] dfa_74 = DFA.unpackEncodedStringToUnsignedChars(dfa_74s);
    static final short[] dfa_75 = DFA.unpackEncodedString(dfa_75s);
    static final short[] dfa_76 = DFA.unpackEncodedString(dfa_76s);
    static final short[][] dfa_77 = unpackEncodedStringArray(dfa_77s);

    class DFA144 extends DFA {

        public DFA144(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 144;
            this.eot = dfa_71;
            this.eof = dfa_72;
            this.min = dfa_73;
            this.max = dfa_74;
            this.accept = dfa_75;
            this.special = dfa_76;
            this.transition = dfa_77;
        }
        public String getDescription() {
            return "4647:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression | this_Variables_4= ruleVariables | this_LogicalExpression_5= ruleLogicalExpression | this_CreateObjectExpression_6= ruleCreateObjectExpression | this_TypeCastingExpression_7= ruleTypeCastingExpression | this_DeleteExpression_8= ruleDeleteExpression | this_TupleExpression_9= ruleTupleExpression )";
        }
    }
    static final String dfa_78s = "\2\uffff\2\5\16\uffff";
    static final String dfa_79s = "\4\4\2\uffff\3\117\5\4\3\13\1\uffff";
    static final String dfa_80s = "\2\17\2\u0095\2\uffff\3\u0093\5\17\3\u0087\1\uffff";
    static final String dfa_81s = "\4\uffff\1\1\1\3\13\uffff\1\2";
    static final String[] dfa_82s = {
            "\1\4\5\uffff\1\1\1\uffff\1\5\1\uffff\1\2\1\3",
            "\1\10\11\uffff\1\6\1\7",
            "\4\5\2\uffff\3\5\1\uffff\3\5\1\uffff\1\5\1\uffff\4\5\32\uffff\1\5\5\uffff\1\5\6\uffff\2\5\10\uffff\1\5\3\uffff\2\5\1\4\10\uffff\16\5\1\uffff\11\5\32\uffff\12\4\2\5",
            "\4\5\2\uffff\3\5\1\uffff\3\5\1\uffff\1\5\1\uffff\4\5\32\uffff\1\5\5\uffff\1\5\6\uffff\2\5\10\uffff\1\5\3\uffff\2\5\1\4\10\uffff\16\5\1\uffff\11\5\32\uffff\12\4\2\5",
            "",
            "",
            "\1\4\72\uffff\1\11\1\12\1\13\1\14\1\15\5\4",
            "\1\4\72\uffff\1\11\1\12\1\13\1\14\1\15\5\4",
            "\1\4\72\uffff\1\11\1\12\1\13\1\14\1\15\5\4",
            "\1\20\11\uffff\1\16\1\17",
            "\1\20\11\uffff\1\16\1\17",
            "\1\20\11\uffff\1\16\1\17",
            "\1\20\11\uffff\1\16\1\17",
            "\1\20\11\uffff\1\16\1\17",
            "\1\4\36\uffff\2\21\110\uffff\1\21\20\uffff\3\21",
            "\1\4\36\uffff\2\21\110\uffff\1\21\20\uffff\3\21",
            "\1\4\36\uffff\2\21\110\uffff\1\21\20\uffff\3\21",
            ""
    };
    static final short[] dfa_78 = DFA.unpackEncodedString(dfa_78s);
    static final char[] dfa_79 = DFA.unpackEncodedStringToUnsignedChars(dfa_79s);
    static final char[] dfa_80 = DFA.unpackEncodedStringToUnsignedChars(dfa_80s);
    static final short[] dfa_81 = DFA.unpackEncodedString(dfa_81s);
    static final short[][] dfa_82 = unpackEncodedStringArray(dfa_82s);

    class DFA145 extends DFA {

        public DFA145(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 145;
            this.eot = dfa_59;
            this.eof = dfa_78;
            this.min = dfa_79;
            this.max = dfa_80;
            this.accept = dfa_81;
            this.special = dfa_63;
            this.transition = dfa_82;
        }
        public String getDescription() {
            return "4777:5: (lv_expr1_1_1= ruleArithmethicalExpression | lv_expr1_1_2= ruleArithmethicalLogicalExpression | lv_expr1_1_3= ruleSyntaxExpression )";
        }
    }
    static final String dfa_83s = "\37\uffff";
    static final String dfa_84s = "\1\115\33\12\1\4\2\uffff";
    static final String dfa_85s = "\1\u0095\33\12\1\14\2\uffff";
    static final String dfa_86s = "\35\uffff\1\2\1\1";
    static final String dfa_87s = "\37\uffff}>";
    static final String[] dfa_88s = {
            "\1\16\1\15\11\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\14\1\21\1\17\1\uffff\1\23\1\24\1\25\1\26\1\27\1\30\1\31\1\32\1\33\44\uffff\1\20\1\22",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\34",
            "\1\36\7\uffff\1\35",
            "",
            ""
    };

    static final short[] dfa_83 = DFA.unpackEncodedString(dfa_83s);
    static final char[] dfa_84 = DFA.unpackEncodedStringToUnsignedChars(dfa_84s);
    static final char[] dfa_85 = DFA.unpackEncodedStringToUnsignedChars(dfa_85s);
    static final short[] dfa_86 = DFA.unpackEncodedString(dfa_86s);
    static final short[] dfa_87 = DFA.unpackEncodedString(dfa_87s);
    static final short[][] dfa_88 = unpackEncodedStringArray(dfa_88s);

    class DFA164 extends DFA {

        public DFA164(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 164;
            this.eot = dfa_83;
            this.eof = dfa_83;
            this.min = dfa_84;
            this.max = dfa_85;
            this.accept = dfa_86;
            this.special = dfa_87;
            this.transition = dfa_88;
        }
        public String getDescription() {
            return "5389:2: ( ( ( (lv_typeCasting_0_0= ruleBasicType ) ) this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? ) | ( ( (lv_typeCasting_6_0= ruleBasicType ) ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS this_STRING_8= RULE_STRING this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS (this_SEMICOLON_10= RULE_SEMICOLON this_EOLINE_11= RULE_EOLINE )? ) )";
        }
    }
    static final String dfa_89s = "\131\uffff";
    static final String dfa_90s = "\2\4\1\uffff\1\4\2\uffff\1\117\1\uffff\2\4\1\117\26\4\3\uffff\6\4\1\uffff\7\4\2\13\1\117\1\13\3\117\1\uffff\26\4\3\5\3\13\1\6\2\13";
    static final String dfa_91s = "\2\u0095\1\uffff\1\u0095\2\uffff\1\u0093\1\uffff\1\u009b\1\u0095\1\u0093\26\17\3\uffff\6\u0095\1\uffff\7\17\3\u0093\1\13\3\u0093\1\uffff\26\17\6\13\1\6\2\13";
    static final String dfa_92s = "\2\uffff\1\2\1\uffff\2\1\1\uffff\1\1\31\uffff\3\1\6\uffff\1\1\16\uffff\1\1\37\uffff";
    static final String dfa_93s = "\131\uffff}>";
    static final String[] dfa_94s = {
            "\1\2\5\uffff\1\2\1\uffff\1\2\1\uffff\3\2\3\uffff\2\2\34\uffff\1\2\5\uffff\1\2\6\uffff\2\2\10\uffff\1\1\3\uffff\2\2\11\uffff\16\2\1\uffff\11\2\44\uffff\2\2",
            "\1\6\5\uffff\1\3\1\uffff\1\7\1\uffff\1\4\1\5\1\7\3\uffff\2\7\34\uffff\1\7\5\uffff\1\7\6\uffff\2\7\10\uffff\1\7\3\uffff\2\7\11\uffff\16\7\1\uffff\11\7\44\uffff\2\7",
            "",
            "\1\12\5\uffff\1\7\1\uffff\1\7\1\uffff\1\10\1\11\1\7\3\uffff\2\7\34\uffff\1\7\5\uffff\1\7\6\uffff\2\7\10\uffff\1\7\3\uffff\2\7\11\uffff\16\7\1\uffff\11\7\44\uffff\2\7",
            "",
            "",
            "\1\20\72\uffff\1\13\1\14\1\15\1\16\1\17\1\21\1\22\1\23\1\24\1\25",
            "",
            "\2\7\4\uffff\3\7\1\uffff\3\7\3\uffff\3\7\33\uffff\1\7\5\uffff\1\7\6\uffff\2\7\10\uffff\1\7\3\uffff\2\7\1\33\10\uffff\16\7\1\uffff\11\7\32\uffff\1\26\1\27\1\30\1\31\1\32\1\34\1\35\1\36\1\37\1\40\10\7",
            "\2\7\4\uffff\3\7\1\uffff\3\7\3\uffff\3\7\33\uffff\1\7\5\uffff\1\7\6\uffff\2\7\10\uffff\1\7\3\uffff\2\7\1\33\10\uffff\16\7\1\uffff\11\7\32\uffff\1\26\1\27\1\30\1\31\1\32\1\34\1\35\1\36\1\37\1\40\2\7",
            "\1\33\72\uffff\1\26\1\27\1\30\1\31\1\32\1\34\1\35\1\36\1\37\1\40",
            "\1\43\11\uffff\1\41\1\42",
            "\1\43\11\uffff\1\41\1\42",
            "\1\43\11\uffff\1\41\1\42",
            "\1\43\11\uffff\1\41\1\42",
            "\1\43\11\uffff\1\41\1\42",
            "\1\43\11\uffff\1\41\1\42",
            "\1\43\11\uffff\1\41\1\42",
            "\1\43\11\uffff\1\41\1\42",
            "\1\43\11\uffff\1\41\1\42",
            "\1\43\11\uffff\1\41\1\42",
            "\1\43\11\uffff\1\41\1\42",
            "\1\46\11\uffff\1\44\1\45",
            "\1\46\11\uffff\1\44\1\45",
            "\1\46\11\uffff\1\44\1\45",
            "\1\46\11\uffff\1\44\1\45",
            "\1\46\11\uffff\1\44\1\45",
            "\1\51\11\uffff\1\47\1\50",
            "\1\51\11\uffff\1\47\1\50",
            "\1\51\11\uffff\1\47\1\50",
            "\1\51\11\uffff\1\47\1\50",
            "\1\51\11\uffff\1\47\1\50",
            "\1\51\11\uffff\1\47\1\50",
            "",
            "",
            "",
            "\2\52\4\uffff\3\52\1\uffff\3\52\3\uffff\3\52\23\uffff\1\55\1\54\6\uffff\1\52\5\uffff\1\52\6\uffff\2\52\10\uffff\1\52\3\uffff\2\52\11\uffff\16\52\1\uffff\11\52\4\uffff\1\57\20\uffff\1\53\1\56\1\60\14\uffff\2\52",
            "\2\52\4\uffff\3\52\1\uffff\3\52\3\uffff\3\52\23\uffff\1\55\1\54\6\uffff\1\52\5\uffff\1\52\6\uffff\2\52\10\uffff\1\52\3\uffff\2\52\11\uffff\16\52\1\uffff\11\52\4\uffff\1\57\20\uffff\1\53\1\56\1\60\14\uffff\2\52",
            "\2\52\4\uffff\3\52\1\uffff\3\52\3\uffff\3\52\23\uffff\1\55\1\54\6\uffff\1\52\5\uffff\1\52\6\uffff\2\52\10\uffff\1\52\3\uffff\2\52\11\uffff\16\52\1\uffff\11\52\4\uffff\1\57\20\uffff\1\53\1\56\1\60\14\uffff\2\52",
            "\2\52\4\uffff\3\52\1\uffff\3\52\3\uffff\3\52\33\uffff\1\52\5\uffff\1\52\6\uffff\2\52\10\uffff\1\52\3\uffff\2\52\11\uffff\16\52\1\uffff\11\52\44\uffff\2\52",
            "\2\52\4\uffff\3\52\1\uffff\3\52\3\uffff\3\52\33\uffff\1\52\5\uffff\1\52\6\uffff\2\52\10\uffff\1\52\3\uffff\2\52\11\uffff\16\52\1\uffff\11\52\44\uffff\2\52",
            "\2\52\4\uffff\3\52\1\uffff\3\52\3\uffff\3\52\33\uffff\1\52\5\uffff\1\52\6\uffff\2\52\10\uffff\1\52\3\uffff\2\52\11\uffff\16\52\1\uffff\11\52\44\uffff\2\52",
            "",
            "\1\64\5\uffff\1\61\1\uffff\1\65\1\uffff\1\62\1\63",
            "\1\64\5\uffff\1\61\1\uffff\1\65\1\uffff\1\62\1\63",
            "\1\64\5\uffff\1\61\1\uffff\1\65\1\uffff\1\62\1\63",
            "\1\64\5\uffff\1\61\1\uffff\1\65\1\uffff\1\62\1\63",
            "\1\64\5\uffff\1\61\1\uffff\1\65\1\uffff\1\62\1\63",
            "\1\64\5\uffff\1\61\1\uffff\1\65\1\uffff\1\62\1\63",
            "\1\70\11\uffff\1\66\1\67",
            "\1\71\103\uffff\1\77\72\uffff\1\72\1\73\1\74\1\75\1\76\1\100\1\101\1\102\1\103\1\104",
            "\1\71\103\uffff\1\77\72\uffff\1\72\1\73\1\74\1\75\1\76\1\100\1\101\1\102\1\103\1\104",
            "\1\77\72\uffff\1\72\1\73\1\74\1\75\1\76\1\100\1\101\1\102\1\103\1\104",
            "\1\71",
            "\1\112\72\uffff\1\105\1\106\1\107\1\110\1\111\1\113\1\114\1\115\1\116\1\117",
            "\1\112\72\uffff\1\105\1\106\1\107\1\110\1\111\1\113\1\114\1\115\1\116\1\117",
            "\1\112\72\uffff\1\105\1\106\1\107\1\110\1\111\1\113\1\114\1\115\1\116\1\117",
            "",
            "\1\122\11\uffff\1\120\1\121",
            "\1\122\11\uffff\1\120\1\121",
            "\1\122\11\uffff\1\120\1\121",
            "\1\122\11\uffff\1\120\1\121",
            "\1\122\11\uffff\1\120\1\121",
            "\1\122\11\uffff\1\120\1\121",
            "\1\122\11\uffff\1\120\1\121",
            "\1\122\11\uffff\1\120\1\121",
            "\1\122\11\uffff\1\120\1\121",
            "\1\122\11\uffff\1\120\1\121",
            "\1\122\11\uffff\1\120\1\121",
            "\1\125\11\uffff\1\123\1\124",
            "\1\125\11\uffff\1\123\1\124",
            "\1\125\11\uffff\1\123\1\124",
            "\1\125\11\uffff\1\123\1\124",
            "\1\125\11\uffff\1\123\1\124",
            "\1\125\11\uffff\1\123\1\124",
            "\1\125\11\uffff\1\123\1\124",
            "\1\125\11\uffff\1\123\1\124",
            "\1\125\11\uffff\1\123\1\124",
            "\1\125\11\uffff\1\123\1\124",
            "\1\125\11\uffff\1\123\1\124",
            "\1\126\5\uffff\1\71",
            "\1\126\5\uffff\1\71",
            "\1\126\5\uffff\1\71",
            "\1\127",
            "\1\127",
            "\1\127",
            "\1\130",
            "\1\71",
            "\1\71"
    };

    static final short[] dfa_89 = DFA.unpackEncodedString(dfa_89s);
    static final char[] dfa_90 = DFA.unpackEncodedStringToUnsignedChars(dfa_90s);
    static final char[] dfa_91 = DFA.unpackEncodedStringToUnsignedChars(dfa_91s);
    static final short[] dfa_92 = DFA.unpackEncodedString(dfa_92s);
    static final short[] dfa_93 = DFA.unpackEncodedString(dfa_93s);
    static final short[][] dfa_94 = unpackEncodedStringArray(dfa_94s);

    class DFA187 extends DFA {

        public DFA187(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 187;
            this.eot = dfa_89;
            this.eof = dfa_89;
            this.min = dfa_90;
            this.max = dfa_91;
            this.accept = dfa_92;
            this.special = dfa_93;
            this.transition = dfa_94;
        }
        public String getDescription() {
            return "6328:3: (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )?";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000070000000000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000180000000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0001A00000000040L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000400000000020L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000042L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0002000000000100L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000052L,0x0302FFFFFF0574C8L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000012L,0x0302FFFFFF0574C8L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000012L,0x03020000000000C0L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000000012L,0x0302000000000080L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000000012L,0x0302000000000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000000002L,0x0300000000000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x00F8000000000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x000000000000D000L,0x0000FFC000000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x000000000000D000L,0x0000FFCFFF000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x000000000000D000L,0x0000FFE000002000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x7E00000000000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000006L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000000010L,0x0000000000000030L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000000000090L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000000000810L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x810400000039D450L,0x0000FFFFFF006201L,0x0000000000300000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000000040L,0x0000000000000100L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000100L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000000000000L,0x0000FFBFFF006000L,0x0000000000300000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000000000010L,0x0000FFBFFF006000L,0x0000000000300000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000000000000010L,0x1800000000000030L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000000050L,0x0000FFFFFF016000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000000000010L,0x0000FFFFFF016000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000000000000040L,0x0000000000002000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000000000000000L,0x0000000000002000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000000040L,0x0000000000004000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000000020L,0x0000000000008000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000000000040L,0x0000000000010000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x000000000000C000L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x00000000000000C0L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0000000000000020L,0x0000000000008000L,0x00000000000F8000L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0000000000000002L,0x0000000000180000L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0000000000014000L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0000000000000020L,0x0000000000C08000L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0000000000000010L,0x1800000000180030L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L,0x00000000000F8000L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x0000000000004020L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x0000000000000010L,0x1800000000D80030L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x0000000000000010L,0x1800000000C00030L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0000000000000010L,0x0000000000C00000L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x00000C0000000000L,0x0010000000000000L,0x00000000000000E0L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x0000000000000000L,0xE000000000000000L,0x0000000000000007L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x810400000039D450L,0x0001FFFFFF057601L,0x0000000000300000L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x810400000039D450L,0x0000FFFFFF057601L,0x0000000000300000L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0x81040000003DD4D0L,0x0000FFFFFF006201L,0x0000000000300000L});
    public static final BitSet FOLLOW_73 = new BitSet(new long[]{0x0000000000040080L});
    public static final BitSet FOLLOW_74 = new BitSet(new long[]{0x0000000000000000L,0x0004000000000000L});
    public static final BitSet FOLLOW_75 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_76 = new BitSet(new long[]{0x0000000000000000L,0x0008000000000000L});
    public static final BitSet FOLLOW_77 = new BitSet(new long[]{0x0000000000000000L,0x0010000000000000L});
    public static final BitSet FOLLOW_78 = new BitSet(new long[]{0x0000000000000000L,0x0020000000000000L});
    public static final BitSet FOLLOW_79 = new BitSet(new long[]{0x000000000000D410L,0x0000FFC000000000L});
    public static final BitSet FOLLOW_80 = new BitSet(new long[]{0x000000000000C010L});
    public static final BitSet FOLLOW_81 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L,0x00000000000FFC00L});
    public static final BitSet FOLLOW_82 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000007C00L});
    public static final BitSet FOLLOW_83 = new BitSet(new long[]{0x000000000000D410L});
    public static final BitSet FOLLOW_84 = new BitSet(new long[]{0x000000000000D800L,0x0000FFC000000000L});
    public static final BitSet FOLLOW_85 = new BitSet(new long[]{0x0000000000000400L,0x0000000000180000L});
    public static final BitSet FOLLOW_86 = new BitSet(new long[]{0x810400000079DC50L,0x0000FFFFFF006201L,0x0000000000300000L});
    public static final BitSet FOLLOW_87 = new BitSet(new long[]{0x810400000039DC50L,0x0000FFFFFF006201L,0x0000000000300000L});
    public static final BitSet FOLLOW_88 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
    public static final BitSet FOLLOW_89 = new BitSet(new long[]{0x0000000000000040L,0x00C0000000000000L});
    public static final BitSet FOLLOW_90 = new BitSet(new long[]{0x0000000000080040L});
    public static final BitSet FOLLOW_91 = new BitSet(new long[]{0x00000000008000C0L});
    public static final BitSet FOLLOW_92 = new BitSet(new long[]{0x0000000000000000L,0x0000000003000000L});
    public static final BitSet FOLLOW_93 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_94 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_95 = new BitSet(new long[]{0x0000000000000010L,0x0000000000000000L,0x0000000000000018L});
    public static final BitSet FOLLOW_96 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x000000000FC00000L});
    public static final BitSet FOLLOW_97 = new BitSet(new long[]{0x810400000039D4D0L,0x0000FFFFFF006201L,0x0000000000300000L});
    public static final BitSet FOLLOW_98 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_99 = new BitSet(new long[]{0x000000003E001000L,0x0400000000000000L});
    public static final BitSet FOLLOW_100 = new BitSet(new long[]{0x0000000000000000L,0x0400000000000000L});

}