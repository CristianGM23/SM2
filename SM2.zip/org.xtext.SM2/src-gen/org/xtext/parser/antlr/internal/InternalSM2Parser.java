package org.xtext.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_ID", "RULE_OPENKEY", "RULE_CLOSEKEY", "RULE_NUMBER", "RULE_DOT", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_STRING", "RULE_EMAIL", "RULE_FLOAT", "RULE_INTEGER", "RULE_COMMA", "RULE_PARAMSLONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_NOTICELONGCOMENT", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'pragma'", "'solidity'", "'contract'", "'is'", "'^'", "'>'", "'>='", "'<'", "'<='", "'import'", "'as'", "'inteface'", "'constructor'", "'public'", "'internal'", "'='", "'event'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'address'", "'string'", "'uint'", "'amountAccount'", "'enum'", "'[]'", "'memory'", "'local'", "'require'", "'function'", "'//'", "'/*'", "'*/'", "'int'", "'uint8'", "'uint256'", "'address payable'", "'double'", "'bool'", "'byte'", "'bytes32'", "'private'", "'external'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'=='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'"
    };
    public static final int T__50=50;
    public static final int RULE_OPENPARENTHESIS=11;
    public static final int RULE_EOLINE=5;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int RULE_CLOSEKEY=8;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_PARAMSLONGCOMENT=18;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=6;
    public static final int RULE_COMMA=17;
    public static final int RULE_RETURNSLONGCOMENT=20;
    public static final int T__28=28;
    public static final int RULE_INT=23;
    public static final int T__29=29;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=24;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int RULE_SEMICOLON=4;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_TITLELONGCOMENT=21;
    public static final int RULE_STRING=13;
    public static final int RULE_EMAIL=14;
    public static final int RULE_NOTICELONGCOMENT=22;
    public static final int RULE_SL_COMMENT=25;
    public static final int T__37=37;
    public static final int RULE_OPENKEY=7;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__77=77;
    public static final int T__34=34;
    public static final int T__78=78;
    public static final int RULE_CLOSEPARENTHESIS=12;
    public static final int T__35=35;
    public static final int T__79=79;
    public static final int T__36=36;
    public static final int T__73=73;
    public static final int RULE_DOT=10;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__74=74;
    public static final int T__31=31;
    public static final int T__75=75;
    public static final int T__32=32;
    public static final int T__76=76;
    public static final int T__80=80;
    public static final int T__81=81;
    public static final int T__82=82;
    public static final int T__83=83;
    public static final int RULE_WS=26;
    public static final int RULE_ANY_OTHER=27;
    public static final int RULE_NUMBER=9;
    public static final int RULE_DEVLONGCOMENT=19;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int RULE_FLOAT=15;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__84=84;
    public static final int T__41=41;
    public static final int T__85=85;
    public static final int RULE_INTEGER=16;
    public static final int T__42=42;
    public static final int T__86=86;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }



     	private SM2GrammarAccess grammarAccess;

        public InternalSM2Parser(TokenStream input, SM2GrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "SmartContract";
       	}

       	@Override
       	protected SM2GrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleSmartContract"
    // InternalSM2.g:65:1: entryRuleSmartContract returns [EObject current=null] : iv_ruleSmartContract= ruleSmartContract EOF ;
    public final EObject entryRuleSmartContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSmartContract = null;


        try {
            // InternalSM2.g:65:54: (iv_ruleSmartContract= ruleSmartContract EOF )
            // InternalSM2.g:66:2: iv_ruleSmartContract= ruleSmartContract EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSmartContractRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSmartContract=ruleSmartContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSmartContract; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSmartContract"


    // $ANTLR start "ruleSmartContract"
    // InternalSM2.g:72:1: ruleSmartContract returns [EObject current=null] : ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contract_7_0= 'contract' ) ) ( (lv_nameContract_8_0= RULE_ID ) ) (otherlv_9= 'is' ( (lv_nameContractFather_10_0= RULE_ID ) ) )? this_OPENKEY_11= RULE_OPENKEY (this_EOLINE_12= RULE_EOLINE )? ( (lv_attributes_13_0= ruleAttributes ) )* ( (lv_constructor_14_0= ruleConstructor ) )? ( (lv_events_15_0= ruleEvent ) )* ( (lv_modifier_16_0= ruleModifier ) )* ( (lv_clauses_17_0= ruleClause ) )* ( (lv_comments_18_0= ruleComment ) )* this_CLOSEKEY_19= RULE_CLOSEKEY ) ;
    public final EObject ruleSmartContract() throws RecognitionException {
        EObject current = null;

        Token lv_compiler_0_0=null;
        Token otherlv_1=null;
        Token this_SEMICOLON_3=null;
        Token this_EOLINE_4=null;
        Token lv_contract_7_0=null;
        Token lv_nameContract_8_0=null;
        Token otherlv_9=null;
        Token lv_nameContractFather_10_0=null;
        Token this_OPENKEY_11=null;
        Token this_EOLINE_12=null;
        Token this_CLOSEKEY_19=null;
        EObject lv_VersionCompiler_2_0 = null;

        EObject lv_imports_5_0 = null;

        EObject lv_interfaces_6_0 = null;

        EObject lv_attributes_13_0 = null;

        EObject lv_constructor_14_0 = null;

        EObject lv_events_15_0 = null;

        EObject lv_modifier_16_0 = null;

        EObject lv_clauses_17_0 = null;

        EObject lv_comments_18_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:78:2: ( ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contract_7_0= 'contract' ) ) ( (lv_nameContract_8_0= RULE_ID ) ) (otherlv_9= 'is' ( (lv_nameContractFather_10_0= RULE_ID ) ) )? this_OPENKEY_11= RULE_OPENKEY (this_EOLINE_12= RULE_EOLINE )? ( (lv_attributes_13_0= ruleAttributes ) )* ( (lv_constructor_14_0= ruleConstructor ) )? ( (lv_events_15_0= ruleEvent ) )* ( (lv_modifier_16_0= ruleModifier ) )* ( (lv_clauses_17_0= ruleClause ) )* ( (lv_comments_18_0= ruleComment ) )* this_CLOSEKEY_19= RULE_CLOSEKEY ) )
            // InternalSM2.g:79:2: ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contract_7_0= 'contract' ) ) ( (lv_nameContract_8_0= RULE_ID ) ) (otherlv_9= 'is' ( (lv_nameContractFather_10_0= RULE_ID ) ) )? this_OPENKEY_11= RULE_OPENKEY (this_EOLINE_12= RULE_EOLINE )? ( (lv_attributes_13_0= ruleAttributes ) )* ( (lv_constructor_14_0= ruleConstructor ) )? ( (lv_events_15_0= ruleEvent ) )* ( (lv_modifier_16_0= ruleModifier ) )* ( (lv_clauses_17_0= ruleClause ) )* ( (lv_comments_18_0= ruleComment ) )* this_CLOSEKEY_19= RULE_CLOSEKEY )
            {
            // InternalSM2.g:79:2: ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contract_7_0= 'contract' ) ) ( (lv_nameContract_8_0= RULE_ID ) ) (otherlv_9= 'is' ( (lv_nameContractFather_10_0= RULE_ID ) ) )? this_OPENKEY_11= RULE_OPENKEY (this_EOLINE_12= RULE_EOLINE )? ( (lv_attributes_13_0= ruleAttributes ) )* ( (lv_constructor_14_0= ruleConstructor ) )? ( (lv_events_15_0= ruleEvent ) )* ( (lv_modifier_16_0= ruleModifier ) )* ( (lv_clauses_17_0= ruleClause ) )* ( (lv_comments_18_0= ruleComment ) )* this_CLOSEKEY_19= RULE_CLOSEKEY )
            // InternalSM2.g:80:3: ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contract_7_0= 'contract' ) ) ( (lv_nameContract_8_0= RULE_ID ) ) (otherlv_9= 'is' ( (lv_nameContractFather_10_0= RULE_ID ) ) )? this_OPENKEY_11= RULE_OPENKEY (this_EOLINE_12= RULE_EOLINE )? ( (lv_attributes_13_0= ruleAttributes ) )* ( (lv_constructor_14_0= ruleConstructor ) )? ( (lv_events_15_0= ruleEvent ) )* ( (lv_modifier_16_0= ruleModifier ) )* ( (lv_clauses_17_0= ruleClause ) )* ( (lv_comments_18_0= ruleComment ) )* this_CLOSEKEY_19= RULE_CLOSEKEY
            {
            // InternalSM2.g:80:3: ( (lv_compiler_0_0= 'pragma' ) )
            // InternalSM2.g:81:4: (lv_compiler_0_0= 'pragma' )
            {
            // InternalSM2.g:81:4: (lv_compiler_0_0= 'pragma' )
            // InternalSM2.g:82:5: lv_compiler_0_0= 'pragma'
            {
            lv_compiler_0_0=(Token)match(input,28,FOLLOW_3); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_compiler_0_0, grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getSmartContractRule());
              					}
              					setWithLastConsumed(current, "compiler", lv_compiler_0_0, "pragma");
              				
            }

            }


            }

            otherlv_1=(Token)match(input,29,FOLLOW_4); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getSmartContractAccess().getSolidityKeyword_1());
              		
            }
            // InternalSM2.g:98:3: ( (lv_VersionCompiler_2_0= ruleVersion ) )
            // InternalSM2.g:99:4: (lv_VersionCompiler_2_0= ruleVersion )
            {
            // InternalSM2.g:99:4: (lv_VersionCompiler_2_0= ruleVersion )
            // InternalSM2.g:100:5: lv_VersionCompiler_2_0= ruleVersion
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_5);
            lv_VersionCompiler_2_0=ruleVersion();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getSmartContractRule());
              					}
              					set(
              						current,
              						"VersionCompiler",
              						lv_VersionCompiler_2_0,
              						"org.xtext.SM2.Version");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_SEMICOLON_3=(Token)match(input,RULE_SEMICOLON,FOLLOW_6); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_3, grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:121:3: (this_EOLINE_4= RULE_EOLINE )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_EOLINE) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalSM2.g:122:4: this_EOLINE_4= RULE_EOLINE
                    {
                    this_EOLINE_4=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_4, grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:127:3: ( (lv_imports_5_0= ruleImport ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==37) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSM2.g:128:4: (lv_imports_5_0= ruleImport )
            	    {
            	    // InternalSM2.g:128:4: (lv_imports_5_0= ruleImport )
            	    // InternalSM2.g:129:5: lv_imports_5_0= ruleImport
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_5_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_7);
            	    lv_imports_5_0=ruleImport();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"imports",
            	      						lv_imports_5_0,
            	      						"org.xtext.SM2.Import");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalSM2.g:146:3: ( (lv_interfaces_6_0= ruleInterface ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==39) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalSM2.g:147:4: (lv_interfaces_6_0= ruleInterface )
            	    {
            	    // InternalSM2.g:147:4: (lv_interfaces_6_0= ruleInterface )
            	    // InternalSM2.g:148:5: lv_interfaces_6_0= ruleInterface
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getInterfacesInterfaceParserRuleCall_6_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_8);
            	    lv_interfaces_6_0=ruleInterface();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"interfaces",
            	      						lv_interfaces_6_0,
            	      						"org.xtext.SM2.Interface");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            // InternalSM2.g:165:3: ( (lv_contract_7_0= 'contract' ) )
            // InternalSM2.g:166:4: (lv_contract_7_0= 'contract' )
            {
            // InternalSM2.g:166:4: (lv_contract_7_0= 'contract' )
            // InternalSM2.g:167:5: lv_contract_7_0= 'contract'
            {
            lv_contract_7_0=(Token)match(input,30,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_contract_7_0, grammarAccess.getSmartContractAccess().getContractContractKeyword_7_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getSmartContractRule());
              					}
              					addWithLastConsumed(current, "contract", lv_contract_7_0, "contract");
              				
            }

            }


            }

            // InternalSM2.g:179:3: ( (lv_nameContract_8_0= RULE_ID ) )
            // InternalSM2.g:180:4: (lv_nameContract_8_0= RULE_ID )
            {
            // InternalSM2.g:180:4: (lv_nameContract_8_0= RULE_ID )
            // InternalSM2.g:181:5: lv_nameContract_8_0= RULE_ID
            {
            lv_nameContract_8_0=(Token)match(input,RULE_ID,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameContract_8_0, grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_8_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getSmartContractRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameContract",
              						lv_nameContract_8_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:197:3: (otherlv_9= 'is' ( (lv_nameContractFather_10_0= RULE_ID ) ) )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==31) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalSM2.g:198:4: otherlv_9= 'is' ( (lv_nameContractFather_10_0= RULE_ID ) )
                    {
                    otherlv_9=(Token)match(input,31,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_9, grammarAccess.getSmartContractAccess().getIsKeyword_9_0());
                      			
                    }
                    // InternalSM2.g:202:4: ( (lv_nameContractFather_10_0= RULE_ID ) )
                    // InternalSM2.g:203:5: (lv_nameContractFather_10_0= RULE_ID )
                    {
                    // InternalSM2.g:203:5: (lv_nameContractFather_10_0= RULE_ID )
                    // InternalSM2.g:204:6: lv_nameContractFather_10_0= RULE_ID
                    {
                    lv_nameContractFather_10_0=(Token)match(input,RULE_ID,FOLLOW_11); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_nameContractFather_10_0, grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_9_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getSmartContractRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"nameContractFather",
                      							lv_nameContractFather_10_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_OPENKEY_11=(Token)match(input,RULE_OPENKEY,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_11, grammarAccess.getSmartContractAccess().getOPENKEYTerminalRuleCall_10());
              		
            }
            // InternalSM2.g:225:3: (this_EOLINE_12= RULE_EOLINE )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==RULE_EOLINE) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalSM2.g:226:4: this_EOLINE_12= RULE_EOLINE
                    {
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_13); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_12, grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_11());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:231:3: ( (lv_attributes_13_0= ruleAttributes ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==RULE_ID||LA6_0==47||(LA6_0>=49 && LA6_0<=52)||LA6_0==54||(LA6_0>=63 && LA6_0<=70)) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalSM2.g:232:4: (lv_attributes_13_0= ruleAttributes )
            	    {
            	    // InternalSM2.g:232:4: (lv_attributes_13_0= ruleAttributes )
            	    // InternalSM2.g:233:5: lv_attributes_13_0= ruleAttributes
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_12_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_13);
            	    lv_attributes_13_0=ruleAttributes();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"attributes",
            	      						lv_attributes_13_0,
            	      						"org.xtext.SM2.Attributes");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            // InternalSM2.g:250:3: ( (lv_constructor_14_0= ruleConstructor ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==40) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalSM2.g:251:4: (lv_constructor_14_0= ruleConstructor )
                    {
                    // InternalSM2.g:251:4: (lv_constructor_14_0= ruleConstructor )
                    // InternalSM2.g:252:5: lv_constructor_14_0= ruleConstructor
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getSmartContractAccess().getConstructorConstructorParserRuleCall_13_0());
                      				
                    }
                    pushFollow(FOLLOW_14);
                    lv_constructor_14_0=ruleConstructor();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
                      					}
                      					set(
                      						current,
                      						"constructor",
                      						lv_constructor_14_0,
                      						"org.xtext.SM2.Constructor");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:269:3: ( (lv_events_15_0= ruleEvent ) )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==44) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalSM2.g:270:4: (lv_events_15_0= ruleEvent )
            	    {
            	    // InternalSM2.g:270:4: (lv_events_15_0= ruleEvent )
            	    // InternalSM2.g:271:5: lv_events_15_0= ruleEvent
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getEventsEventParserRuleCall_14_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_14);
            	    lv_events_15_0=ruleEvent();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"events",
            	      						lv_events_15_0,
            	      						"org.xtext.SM2.Event");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            // InternalSM2.g:288:3: ( (lv_modifier_16_0= ruleModifier ) )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==45) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalSM2.g:289:4: (lv_modifier_16_0= ruleModifier )
            	    {
            	    // InternalSM2.g:289:4: (lv_modifier_16_0= ruleModifier )
            	    // InternalSM2.g:290:5: lv_modifier_16_0= ruleModifier
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_15_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_15);
            	    lv_modifier_16_0=ruleModifier();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"modifier",
            	      						lv_modifier_16_0,
            	      						"org.xtext.SM2.Modifier");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

            // InternalSM2.g:307:3: ( (lv_clauses_17_0= ruleClause ) )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==59) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalSM2.g:308:4: (lv_clauses_17_0= ruleClause )
            	    {
            	    // InternalSM2.g:308:4: (lv_clauses_17_0= ruleClause )
            	    // InternalSM2.g:309:5: lv_clauses_17_0= ruleClause
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_16_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_16);
            	    lv_clauses_17_0=ruleClause();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"clauses",
            	      						lv_clauses_17_0,
            	      						"org.xtext.SM2.Clause");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

            // InternalSM2.g:326:3: ( (lv_comments_18_0= ruleComment ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( ((LA11_0>=60 && LA11_0<=61)) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalSM2.g:327:4: (lv_comments_18_0= ruleComment )
            	    {
            	    // InternalSM2.g:327:4: (lv_comments_18_0= ruleComment )
            	    // InternalSM2.g:328:5: lv_comments_18_0= ruleComment
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_17_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_17);
            	    lv_comments_18_0=ruleComment();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"comments",
            	      						lv_comments_18_0,
            	      						"org.xtext.SM2.Comment");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

            this_CLOSEKEY_19=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_19, grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_18());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSmartContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:353:1: entryRuleVersion returns [EObject current=null] : iv_ruleVersion= ruleVersion EOF ;
    public final EObject entryRuleVersion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVersion = null;


        try {
            // InternalSM2.g:353:48: (iv_ruleVersion= ruleVersion EOF )
            // InternalSM2.g:354:2: iv_ruleVersion= ruleVersion EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getVersionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleVersion=ruleVersion();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleVersion; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:360:1: ruleVersion returns [EObject current=null] : ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? ) ) ;
    public final EObject ruleVersion() throws RecognitionException {
        EObject current = null;

        Token lv_symbol_0_0=null;
        Token lv_numberVersion_1_0=null;
        Token this_DOT_2=null;
        Token lv_numberVersion2_3_0=null;
        Token this_DOT_4=null;
        Token lv_numberVersion3_5_0=null;
        Token lv_symbol_6_1=null;
        Token lv_symbol_6_2=null;
        Token lv_numberVersion_7_0=null;
        Token this_DOT_8=null;
        Token lv_numberVersion2_9_0=null;
        Token this_DOT_10=null;
        Token lv_numberVersion3_11_0=null;
        Token lv_symbol2_12_1=null;
        Token lv_symbol2_12_2=null;
        Token lv_numberVersionOptional_13_0=null;
        Token this_DOT_14=null;
        Token lv_numberVersionOptional2_15_0=null;
        Token this_DOT_16=null;
        Token lv_numberVersionOptional3_17_0=null;


        	enterRule();

        try {
            // InternalSM2.g:366:2: ( ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? ) ) )
            // InternalSM2.g:367:2: ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? ) )
            {
            // InternalSM2.g:367:2: ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? ) )
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==32) ) {
                alt15=1;
            }
            else if ( ((LA15_0>=33 && LA15_0<=34)) ) {
                alt15=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }
            switch (alt15) {
                case 1 :
                    // InternalSM2.g:368:3: ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) )
                    {
                    // InternalSM2.g:368:3: ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) )
                    // InternalSM2.g:369:4: ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) )
                    {
                    // InternalSM2.g:369:4: ( (lv_symbol_0_0= '^' ) )
                    // InternalSM2.g:370:5: (lv_symbol_0_0= '^' )
                    {
                    // InternalSM2.g:370:5: (lv_symbol_0_0= '^' )
                    // InternalSM2.g:371:6: lv_symbol_0_0= '^'
                    {
                    lv_symbol_0_0=(Token)match(input,32,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_symbol_0_0, grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(current, "symbol", lv_symbol_0_0, "^");
                      					
                    }

                    }


                    }

                    // InternalSM2.g:383:4: ( (lv_numberVersion_1_0= RULE_NUMBER ) )
                    // InternalSM2.g:384:5: (lv_numberVersion_1_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:384:5: (lv_numberVersion_1_0= RULE_NUMBER )
                    // InternalSM2.g:385:6: lv_numberVersion_1_0= RULE_NUMBER
                    {
                    lv_numberVersion_1_0=(Token)match(input,RULE_NUMBER,FOLLOW_19); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion_1_0, grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_0_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion",
                      							lv_numberVersion_1_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_2=(Token)match(input,RULE_DOT,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_2, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_2());
                      			
                    }
                    // InternalSM2.g:405:4: ( (lv_numberVersion2_3_0= RULE_NUMBER ) )
                    // InternalSM2.g:406:5: (lv_numberVersion2_3_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:406:5: (lv_numberVersion2_3_0= RULE_NUMBER )
                    // InternalSM2.g:407:6: lv_numberVersion2_3_0= RULE_NUMBER
                    {
                    lv_numberVersion2_3_0=(Token)match(input,RULE_NUMBER,FOLLOW_19); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion2_3_0, grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_0_3_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion2",
                      							lv_numberVersion2_3_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_4=(Token)match(input,RULE_DOT,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_4, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_4());
                      			
                    }
                    // InternalSM2.g:427:4: ( (lv_numberVersion3_5_0= RULE_NUMBER ) )
                    // InternalSM2.g:428:5: (lv_numberVersion3_5_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:428:5: (lv_numberVersion3_5_0= RULE_NUMBER )
                    // InternalSM2.g:429:6: lv_numberVersion3_5_0= RULE_NUMBER
                    {
                    lv_numberVersion3_5_0=(Token)match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion3_5_0, grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_0_5_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion3",
                      							lv_numberVersion3_5_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:447:3: ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? )
                    {
                    // InternalSM2.g:447:3: ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? )
                    // InternalSM2.g:448:4: ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )?
                    {
                    // InternalSM2.g:448:4: ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) )
                    // InternalSM2.g:449:5: ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) )
                    {
                    // InternalSM2.g:449:5: ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) )
                    // InternalSM2.g:450:6: (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' )
                    {
                    // InternalSM2.g:450:6: (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' )
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==33) ) {
                        alt12=1;
                    }
                    else if ( (LA12_0==34) ) {
                        alt12=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 12, 0, input);

                        throw nvae;
                    }
                    switch (alt12) {
                        case 1 :
                            // InternalSM2.g:451:7: lv_symbol_6_1= '>'
                            {
                            lv_symbol_6_1=(Token)match(input,33,FOLLOW_18); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_symbol_6_1, grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_1_0_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(current, "symbol", lv_symbol_6_1, null);
                              						
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:462:7: lv_symbol_6_2= '>='
                            {
                            lv_symbol_6_2=(Token)match(input,34,FOLLOW_18); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_symbol_6_2, grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_1_0_0_1());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(current, "symbol", lv_symbol_6_2, null);
                              						
                            }

                            }
                            break;

                    }


                    }


                    }

                    // InternalSM2.g:475:4: ( (lv_numberVersion_7_0= RULE_NUMBER ) )
                    // InternalSM2.g:476:5: (lv_numberVersion_7_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:476:5: (lv_numberVersion_7_0= RULE_NUMBER )
                    // InternalSM2.g:477:6: lv_numberVersion_7_0= RULE_NUMBER
                    {
                    lv_numberVersion_7_0=(Token)match(input,RULE_NUMBER,FOLLOW_19); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion_7_0, grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_1_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion",
                      							lv_numberVersion_7_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_8=(Token)match(input,RULE_DOT,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_8, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_2());
                      			
                    }
                    // InternalSM2.g:497:4: ( (lv_numberVersion2_9_0= RULE_NUMBER ) )
                    // InternalSM2.g:498:5: (lv_numberVersion2_9_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:498:5: (lv_numberVersion2_9_0= RULE_NUMBER )
                    // InternalSM2.g:499:6: lv_numberVersion2_9_0= RULE_NUMBER
                    {
                    lv_numberVersion2_9_0=(Token)match(input,RULE_NUMBER,FOLLOW_19); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion2_9_0, grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_1_3_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion2",
                      							lv_numberVersion2_9_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_10=(Token)match(input,RULE_DOT,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_10, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_4());
                      			
                    }
                    // InternalSM2.g:519:4: ( (lv_numberVersion3_11_0= RULE_NUMBER ) )
                    // InternalSM2.g:520:5: (lv_numberVersion3_11_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:520:5: (lv_numberVersion3_11_0= RULE_NUMBER )
                    // InternalSM2.g:521:6: lv_numberVersion3_11_0= RULE_NUMBER
                    {
                    lv_numberVersion3_11_0=(Token)match(input,RULE_NUMBER,FOLLOW_20); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion3_11_0, grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_1_5_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion3",
                      							lv_numberVersion3_11_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }

                    // InternalSM2.g:537:4: ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )?
                    int alt14=2;
                    int LA14_0 = input.LA(1);

                    if ( ((LA14_0>=35 && LA14_0<=36)) ) {
                        alt14=1;
                    }
                    switch (alt14) {
                        case 1 :
                            // InternalSM2.g:538:5: ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) )
                            {
                            // InternalSM2.g:538:5: ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) )
                            // InternalSM2.g:539:6: ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) )
                            {
                            // InternalSM2.g:539:6: ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) )
                            // InternalSM2.g:540:7: (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' )
                            {
                            // InternalSM2.g:540:7: (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' )
                            int alt13=2;
                            int LA13_0 = input.LA(1);

                            if ( (LA13_0==35) ) {
                                alt13=1;
                            }
                            else if ( (LA13_0==36) ) {
                                alt13=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 13, 0, input);

                                throw nvae;
                            }
                            switch (alt13) {
                                case 1 :
                                    // InternalSM2.g:541:8: lv_symbol2_12_1= '<'
                                    {
                                    lv_symbol2_12_1=(Token)match(input,35,FOLLOW_18); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      								newLeafNode(lv_symbol2_12_1, grammarAccess.getVersionAccess().getSymbol2LessThanSignKeyword_1_6_0_0_0());
                                      							
                                    }
                                    if ( state.backtracking==0 ) {

                                      								if (current==null) {
                                      									current = createModelElement(grammarAccess.getVersionRule());
                                      								}
                                      								setWithLastConsumed(current, "symbol2", lv_symbol2_12_1, null);
                                      							
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:552:8: lv_symbol2_12_2= '<='
                                    {
                                    lv_symbol2_12_2=(Token)match(input,36,FOLLOW_18); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      								newLeafNode(lv_symbol2_12_2, grammarAccess.getVersionAccess().getSymbol2LessThanSignEqualsSignKeyword_1_6_0_0_1());
                                      							
                                    }
                                    if ( state.backtracking==0 ) {

                                      								if (current==null) {
                                      									current = createModelElement(grammarAccess.getVersionRule());
                                      								}
                                      								setWithLastConsumed(current, "symbol2", lv_symbol2_12_2, null);
                                      							
                                    }

                                    }
                                    break;

                            }


                            }


                            }

                            // InternalSM2.g:565:5: ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) )
                            // InternalSM2.g:566:6: (lv_numberVersionOptional_13_0= RULE_NUMBER )
                            {
                            // InternalSM2.g:566:6: (lv_numberVersionOptional_13_0= RULE_NUMBER )
                            // InternalSM2.g:567:7: lv_numberVersionOptional_13_0= RULE_NUMBER
                            {
                            lv_numberVersionOptional_13_0=(Token)match(input,RULE_NUMBER,FOLLOW_19); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_numberVersionOptional_13_0, grammarAccess.getVersionAccess().getNumberVersionOptionalNUMBERTerminalRuleCall_1_6_1_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"numberVersionOptional",
                              								lv_numberVersionOptional_13_0,
                              								"org.xtext.SM2.NUMBER");
                              						
                            }

                            }


                            }

                            this_DOT_14=(Token)match(input,RULE_DOT,FOLLOW_18); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_DOT_14, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_2());
                              				
                            }
                            // InternalSM2.g:587:5: ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) )
                            // InternalSM2.g:588:6: (lv_numberVersionOptional2_15_0= RULE_NUMBER )
                            {
                            // InternalSM2.g:588:6: (lv_numberVersionOptional2_15_0= RULE_NUMBER )
                            // InternalSM2.g:589:7: lv_numberVersionOptional2_15_0= RULE_NUMBER
                            {
                            lv_numberVersionOptional2_15_0=(Token)match(input,RULE_NUMBER,FOLLOW_19); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_numberVersionOptional2_15_0, grammarAccess.getVersionAccess().getNumberVersionOptional2NUMBERTerminalRuleCall_1_6_3_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"numberVersionOptional2",
                              								lv_numberVersionOptional2_15_0,
                              								"org.xtext.SM2.NUMBER");
                              						
                            }

                            }


                            }

                            this_DOT_16=(Token)match(input,RULE_DOT,FOLLOW_18); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_DOT_16, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_4());
                              				
                            }
                            // InternalSM2.g:609:5: ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) )
                            // InternalSM2.g:610:6: (lv_numberVersionOptional3_17_0= RULE_NUMBER )
                            {
                            // InternalSM2.g:610:6: (lv_numberVersionOptional3_17_0= RULE_NUMBER )
                            // InternalSM2.g:611:7: lv_numberVersionOptional3_17_0= RULE_NUMBER
                            {
                            lv_numberVersionOptional3_17_0=(Token)match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_numberVersionOptional3_17_0, grammarAccess.getVersionAccess().getNumberVersionOptional3NUMBERTerminalRuleCall_1_6_5_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"numberVersionOptional3",
                              								lv_numberVersionOptional3_17_0,
                              								"org.xtext.SM2.NUMBER");
                              						
                            }

                            }


                            }


                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleImport"
    // InternalSM2.g:633:1: entryRuleImport returns [EObject current=null] : iv_ruleImport= ruleImport EOF ;
    public final EObject entryRuleImport() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleImport = null;


        try {
            // InternalSM2.g:633:47: (iv_ruleImport= ruleImport EOF )
            // InternalSM2.g:634:2: iv_ruleImport= ruleImport EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getImportRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleImport=ruleImport();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleImport; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2.g:640:1: ruleImport returns [EObject current=null] : (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) ;
    public final EObject ruleImport() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameLibrary_1_0=null;
        Token otherlv_2=null;
        Token lv_alias_3_0=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;


        	enterRule();

        try {
            // InternalSM2.g:646:2: ( (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:647:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:647:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:648:3: otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,37,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getImportAccess().getImportKeyword_0());
              		
            }
            // InternalSM2.g:652:3: ( (lv_nameLibrary_1_0= RULE_ID ) )
            // InternalSM2.g:653:4: (lv_nameLibrary_1_0= RULE_ID )
            {
            // InternalSM2.g:653:4: (lv_nameLibrary_1_0= RULE_ID )
            // InternalSM2.g:654:5: lv_nameLibrary_1_0= RULE_ID
            {
            lv_nameLibrary_1_0=(Token)match(input,RULE_ID,FOLLOW_21); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameLibrary_1_0, grammarAccess.getImportAccess().getNameLibraryIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getImportRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameLibrary",
              						lv_nameLibrary_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:670:3: (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==38) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalSM2.g:671:4: otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,38,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getImportAccess().getAsKeyword_2_0());
                      			
                    }
                    // InternalSM2.g:675:4: ( (lv_alias_3_0= RULE_ID ) )
                    // InternalSM2.g:676:5: (lv_alias_3_0= RULE_ID )
                    {
                    // InternalSM2.g:676:5: (lv_alias_3_0= RULE_ID )
                    // InternalSM2.g:677:6: lv_alias_3_0= RULE_ID
                    {
                    lv_alias_3_0=(Token)match(input,RULE_ID,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_alias_3_0, grammarAccess.getImportAccess().getAliasIDTerminalRuleCall_2_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getImportRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"alias",
                      							lv_alias_3_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_4, grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:698:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==RULE_EOLINE) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalSM2.g:699:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_5, grammarAccess.getImportAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleInterface"
    // InternalSM2.g:708:1: entryRuleInterface returns [EObject current=null] : iv_ruleInterface= ruleInterface EOF ;
    public final EObject entryRuleInterface() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInterface = null;


        try {
            // InternalSM2.g:708:50: (iv_ruleInterface= ruleInterface EOF )
            // InternalSM2.g:709:2: iv_ruleInterface= ruleInterface EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getInterfaceRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleInterface=ruleInterface();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleInterface; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInterface"


    // $ANTLR start "ruleInterface"
    // InternalSM2.g:715:1: ruleInterface returns [EObject current=null] : (otherlv_0= 'inteface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (lv_clauses_8_0= ruleHeadClause ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE ) ;
    public final EObject ruleInterface() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameInterface_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_EOLINE_5=null;
        Token this_EOLINE_7=null;
        Token this_SEMICOLON_9=null;
        Token this_EOLINE_10=null;
        Token this_CLOSEKEY_11=null;
        Token this_EOLINE_12=null;
        EObject lv_enums_4_0 = null;

        EObject lv_structs_6_0 = null;

        EObject lv_clauses_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:721:2: ( (otherlv_0= 'inteface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (lv_clauses_8_0= ruleHeadClause ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE ) )
            // InternalSM2.g:722:2: (otherlv_0= 'inteface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (lv_clauses_8_0= ruleHeadClause ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE )
            {
            // InternalSM2.g:722:2: (otherlv_0= 'inteface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (lv_clauses_8_0= ruleHeadClause ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE )
            // InternalSM2.g:723:3: otherlv_0= 'inteface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (lv_clauses_8_0= ruleHeadClause ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,39,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getInterfaceAccess().getIntefaceKeyword_0());
              		
            }
            // InternalSM2.g:727:3: ( (lv_nameInterface_1_0= RULE_ID ) )
            // InternalSM2.g:728:4: (lv_nameInterface_1_0= RULE_ID )
            {
            // InternalSM2.g:728:4: (lv_nameInterface_1_0= RULE_ID )
            // InternalSM2.g:729:5: lv_nameInterface_1_0= RULE_ID
            {
            lv_nameInterface_1_0=(Token)match(input,RULE_ID,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameInterface_1_0, grammarAccess.getInterfaceAccess().getNameInterfaceIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getInterfaceRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameInterface",
              						lv_nameInterface_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getInterfaceAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_3, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_3());
              		
            }
            // InternalSM2.g:753:3: ( (lv_enums_4_0= ruleEnum ) )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==54) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalSM2.g:754:4: (lv_enums_4_0= ruleEnum )
            	    {
            	    // InternalSM2.g:754:4: (lv_enums_4_0= ruleEnum )
            	    // InternalSM2.g:755:5: lv_enums_4_0= ruleEnum
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getInterfaceAccess().getEnumsEnumParserRuleCall_4_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_24);
            	    lv_enums_4_0=ruleEnum();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getInterfaceRule());
            	      					}
            	      					add(
            	      						current,
            	      						"enums",
            	      						lv_enums_4_0,
            	      						"org.xtext.SM2.Enum");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

            this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_5, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_5());
              		
            }
            // InternalSM2.g:776:3: ( (lv_structs_6_0= ruleStruct ) )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==49) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalSM2.g:777:4: (lv_structs_6_0= ruleStruct )
            	    {
            	    // InternalSM2.g:777:4: (lv_structs_6_0= ruleStruct )
            	    // InternalSM2.g:778:5: lv_structs_6_0= ruleStruct
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getInterfaceAccess().getStructsStructParserRuleCall_6_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_25);
            	    lv_structs_6_0=ruleStruct();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getInterfaceRule());
            	      					}
            	      					add(
            	      						current,
            	      						"structs",
            	      						lv_structs_6_0,
            	      						"org.xtext.SM2.Struct");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_7, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_7());
              		
            }
            // InternalSM2.g:799:3: ( (lv_clauses_8_0= ruleHeadClause ) )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==59) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalSM2.g:800:4: (lv_clauses_8_0= ruleHeadClause )
            	    {
            	    // InternalSM2.g:800:4: (lv_clauses_8_0= ruleHeadClause )
            	    // InternalSM2.g:801:5: lv_clauses_8_0= ruleHeadClause
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getInterfaceAccess().getClausesHeadClauseParserRuleCall_8_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_26);
            	    lv_clauses_8_0=ruleHeadClause();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getInterfaceRule());
            	      					}
            	      					add(
            	      						current,
            	      						"clauses",
            	      						lv_clauses_8_0,
            	      						"org.xtext.SM2.HeadClause");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_9, grammarAccess.getInterfaceAccess().getSEMICOLONTerminalRuleCall_9());
              		
            }
            this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_10, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_10());
              		
            }
            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_11, grammarAccess.getInterfaceAccess().getCLOSEKEYTerminalRuleCall_11());
              		
            }
            this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_12, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_12());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInterface"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:838:1: entryRuleAttributes returns [EObject current=null] : iv_ruleAttributes= ruleAttributes EOF ;
    public final EObject entryRuleAttributes() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttributes = null;


        try {
            // InternalSM2.g:838:51: (iv_ruleAttributes= ruleAttributes EOF )
            // InternalSM2.g:839:2: iv_ruleAttributes= ruleAttributes EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getAttributesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleAttributes=ruleAttributes();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleAttributes; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:845:1: ruleAttributes returns [EObject current=null] : (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) ;
    public final EObject ruleAttributes() throws RecognitionException {
        EObject current = null;

        EObject this_Property_0 = null;

        EObject this_DataType_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:851:2: ( (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) )
            // InternalSM2.g:852:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            {
            // InternalSM2.g:852:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( ((LA21_0>=50 && LA21_0<=52)||(LA21_0>=63 && LA21_0<=70)) ) {
                alt21=1;
            }
            else if ( (LA21_0==RULE_ID||LA21_0==47||LA21_0==49||LA21_0==54) ) {
                alt21=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }
            switch (alt21) {
                case 1 :
                    // InternalSM2.g:853:3: this_Property_0= ruleProperty
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Property_0=ruleProperty();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Property_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:862:3: this_DataType_1= ruleDataType
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_DataType_1=ruleDataType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_DataType_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleConstructor"
    // InternalSM2.g:874:1: entryRuleConstructor returns [EObject current=null] : iv_ruleConstructor= ruleConstructor EOF ;
    public final EObject entryRuleConstructor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConstructor = null;


        try {
            // InternalSM2.g:874:52: (iv_ruleConstructor= ruleConstructor EOF )
            // InternalSM2.g:875:2: iv_ruleConstructor= ruleConstructor EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConstructorRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleConstructor=ruleConstructor();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleConstructor; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConstructor"


    // $ANTLR start "ruleConstructor"
    // InternalSM2.g:881:1: ruleConstructor returns [EObject current=null] : (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )* otherlv_7= '=' ( (lv_value_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY ) ;
    public final EObject ruleConstructor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_2=null;
        Token lv_type_3_1=null;
        Token lv_type_3_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token this_CLOSEKEY_9=null;
        EObject lv_value_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:887:2: ( (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )* otherlv_7= '=' ( (lv_value_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY ) )
            // InternalSM2.g:888:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )* otherlv_7= '=' ( (lv_value_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY )
            {
            // InternalSM2.g:888:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )* otherlv_7= '=' ( (lv_value_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY )
            // InternalSM2.g:889:3: otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )* otherlv_7= '=' ( (lv_value_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,40,FOLLOW_28); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getConstructorAccess().getConstructorKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConstructorAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:897:3: ( (otherlv_2= RULE_ID ) )
            // InternalSM2.g:898:4: (otherlv_2= RULE_ID )
            {
            // InternalSM2.g:898:4: (otherlv_2= RULE_ID )
            // InternalSM2.g:899:5: otherlv_2= RULE_ID
            {
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getConstructorRule());
              					}
              				
            }
            otherlv_2=(Token)match(input,RULE_ID,FOLLOW_29); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(otherlv_2, grammarAccess.getConstructorAccess().getInputParamsInputParamCrossReference_2_0());
              				
            }

            }


            }

            // InternalSM2.g:910:3: ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) )
            // InternalSM2.g:911:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            {
            // InternalSM2.g:911:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            // InternalSM2.g:912:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            {
            // InternalSM2.g:912:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==41) ) {
                alt22=1;
            }
            else if ( (LA22_0==42) ) {
                alt22=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }
            switch (alt22) {
                case 1 :
                    // InternalSM2.g:913:6: lv_type_3_1= 'public'
                    {
                    lv_type_3_1=(Token)match(input,41,FOLLOW_30); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_3_1, grammarAccess.getConstructorAccess().getTypePublicKeyword_3_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getConstructorRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_3_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:924:6: lv_type_3_2= 'internal'
                    {
                    lv_type_3_2=(Token)match(input,42,FOLLOW_30); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_3_2, grammarAccess.getConstructorAccess().getTypeInternalKeyword_3_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getConstructorRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_3_2, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getConstructorAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_31); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getConstructorAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:945:3: ( (otherlv_6= RULE_ID ) )*
            loop23:
            do {
                int alt23=2;
                int LA23_0 = input.LA(1);

                if ( (LA23_0==RULE_ID) ) {
                    alt23=1;
                }


                switch (alt23) {
            	case 1 :
            	    // InternalSM2.g:946:4: (otherlv_6= RULE_ID )
            	    {
            	    // InternalSM2.g:946:4: (otherlv_6= RULE_ID )
            	    // InternalSM2.g:947:5: otherlv_6= RULE_ID
            	    {
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElement(grammarAccess.getConstructorRule());
            	      					}
            	      				
            	    }
            	    otherlv_6=(Token)match(input,RULE_ID,FOLLOW_31); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_6, grammarAccess.getConstructorAccess().getAttributesAttributesCrossReference_6_0());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop23;
                }
            } while (true);

            otherlv_7=(Token)match(input,43,FOLLOW_32); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_7, grammarAccess.getConstructorAccess().getEqualsSignKeyword_7());
              		
            }
            // InternalSM2.g:962:3: ( (lv_value_8_0= ruleExpression ) )
            // InternalSM2.g:963:4: (lv_value_8_0= ruleExpression )
            {
            // InternalSM2.g:963:4: (lv_value_8_0= ruleExpression )
            // InternalSM2.g:964:5: lv_value_8_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getConstructorAccess().getValueExpressionParserRuleCall_8_0());
              				
            }
            pushFollow(FOLLOW_27);
            lv_value_8_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getConstructorRule());
              					}
              					set(
              						current,
              						"value",
              						lv_value_8_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEKEY_9=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_9, grammarAccess.getConstructorAccess().getCLOSEKEYTerminalRuleCall_9());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConstructor"


    // $ANTLR start "entryRuleEvent"
    // InternalSM2.g:989:1: entryRuleEvent returns [EObject current=null] : iv_ruleEvent= ruleEvent EOF ;
    public final EObject entryRuleEvent() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvent = null;


        try {
            // InternalSM2.g:989:46: (iv_ruleEvent= ruleEvent EOF )
            // InternalSM2.g:990:2: iv_ruleEvent= ruleEvent EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getEventRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleEvent=ruleEvent();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleEvent; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalSM2.g:996:1: ruleEvent returns [EObject current=null] : (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject ruleEvent() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEvent_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;
        EObject lv_inputParams_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1002:2: ( (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1003:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1003:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1004:3: otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,44,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getEventAccess().getEventKeyword_0());
              		
            }
            // InternalSM2.g:1008:3: ( (lv_nameEvent_1_0= RULE_ID ) )
            // InternalSM2.g:1009:4: (lv_nameEvent_1_0= RULE_ID )
            {
            // InternalSM2.g:1009:4: (lv_nameEvent_1_0= RULE_ID )
            // InternalSM2.g:1010:5: lv_nameEvent_1_0= RULE_ID
            {
            lv_nameEvent_1_0=(Token)match(input,RULE_ID,FOLLOW_28); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameEvent_1_0, grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEventRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameEvent",
              						lv_nameEvent_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_33); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1030:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( ((LA24_0>=50 && LA24_0<=52)||(LA24_0>=63 && LA24_0<=70)) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalSM2.g:1031:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1031:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:1032:5: lv_inputParams_3_0= ruleInputParam
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_33);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getEventRule());
            	      					}
            	      					add(
            	      						current,
            	      						"inputParams",
            	      						lv_inputParams_3_0,
            	      						"org.xtext.SM2.InputParam");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_5, grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1057:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==RULE_EOLINE) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalSM2.g:1058:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:1067:1: entryRuleModifier returns [EObject current=null] : iv_ruleModifier= ruleModifier EOF ;
    public final EObject entryRuleModifier() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModifier = null;


        try {
            // InternalSM2.g:1067:49: (iv_ruleModifier= ruleModifier EOF )
            // InternalSM2.g:1068:2: iv_ruleModifier= ruleModifier EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getModifierRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleModifier=ruleModifier();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleModifier; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:1074:1: ruleModifier returns [EObject current=null] : (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? ) ;
    public final EObject ruleModifier() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameModifier_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_EOLINE_6=null;
        Token lv_expr_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Token otherlv_10=null;
        Token this_CLOSEKEY_11=null;
        Token this_EOLINE_12=null;
        EObject lv_inputParams_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1080:2: ( (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? ) )
            // InternalSM2.g:1081:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? )
            {
            // InternalSM2.g:1081:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? )
            // InternalSM2.g:1082:3: otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,45,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getModifierAccess().getModifierKeyword_0());
              		
            }
            // InternalSM2.g:1086:3: ( (lv_nameModifier_1_0= RULE_ID ) )
            // InternalSM2.g:1087:4: (lv_nameModifier_1_0= RULE_ID )
            {
            // InternalSM2.g:1087:4: (lv_nameModifier_1_0= RULE_ID )
            // InternalSM2.g:1088:5: lv_nameModifier_1_0= RULE_ID
            {
            lv_nameModifier_1_0=(Token)match(input,RULE_ID,FOLLOW_28); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameModifier_1_0, grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getModifierRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameModifier",
              						lv_nameModifier_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_33); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1108:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( ((LA26_0>=50 && LA26_0<=52)||(LA26_0>=63 && LA26_0<=70)) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalSM2.g:1109:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1109:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:1110:5: lv_inputParams_3_0= ruleInputParam
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_33);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getModifierRule());
            	      					}
            	      					add(
            	      						current,
            	      						"inputParams",
            	      						lv_inputParams_3_0,
            	      						"org.xtext.SM2.InputParam");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_34); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1135:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==RULE_EOLINE) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalSM2.g:1136:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_35); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:1141:3: ( (lv_expr_7_0= RULE_STRING ) )
            // InternalSM2.g:1142:4: (lv_expr_7_0= RULE_STRING )
            {
            // InternalSM2.g:1142:4: (lv_expr_7_0= RULE_STRING )
            // InternalSM2.g:1143:5: lv_expr_7_0= RULE_STRING
            {
            lv_expr_7_0=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr_7_0, grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getModifierRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr",
              						lv_expr_7_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_36); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8());
              		
            }
            // InternalSM2.g:1163:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==RULE_EOLINE) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalSM2.g:1164:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_37); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9());
                      			
                    }

                    }
                    break;

            }

            otherlv_10=(Token)match(input,46,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_10, grammarAccess.getModifierAccess().get_Keyword_10());
              		
            }
            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_11, grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11());
              		
            }
            // InternalSM2.g:1177:3: (this_EOLINE_12= RULE_EOLINE )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==RULE_EOLINE) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalSM2.g:1178:4: this_EOLINE_12= RULE_EOLINE
                    {
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_12, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:1187:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalSM2.g:1187:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalSM2.g:1188:2: iv_ruleDataType= ruleDataType EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getDataTypeRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleDataType; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:1194:1: ruleDataType returns [EObject current=null] : (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        Token this_ID_2=null;
        EObject this_CompositeType_0 = null;

        EObject this_Enum_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1200:2: ( (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID ) )
            // InternalSM2.g:1201:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID )
            {
            // InternalSM2.g:1201:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID )
            int alt30=3;
            switch ( input.LA(1) ) {
            case 47:
            case 49:
                {
                alt30=1;
                }
                break;
            case 54:
                {
                alt30=2;
                }
                break;
            case RULE_ID:
                {
                alt30=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 30, 0, input);

                throw nvae;
            }

            switch (alt30) {
                case 1 :
                    // InternalSM2.g:1202:3: this_CompositeType_0= ruleCompositeType
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_CompositeType_0=ruleCompositeType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_CompositeType_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1211:3: this_Enum_1= ruleEnum
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Enum_1=ruleEnum();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Enum_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1220:3: this_ID_2= RULE_ID
                    {
                    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(this_ID_2, grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2());
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2.g:1228:1: entryRuleCompositeType returns [EObject current=null] : iv_ruleCompositeType= ruleCompositeType EOF ;
    public final EObject entryRuleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompositeType = null;


        try {
            // InternalSM2.g:1228:54: (iv_ruleCompositeType= ruleCompositeType EOF )
            // InternalSM2.g:1229:2: iv_ruleCompositeType= ruleCompositeType EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCompositeTypeRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleCompositeType=ruleCompositeType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleCompositeType; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2.g:1235:1: ruleCompositeType returns [EObject current=null] : (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) ;
    public final EObject ruleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject this_Mapping_0 = null;

        EObject this_Struct_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1241:2: ( (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) )
            // InternalSM2.g:1242:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            {
            // InternalSM2.g:1242:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==47) ) {
                alt31=1;
            }
            else if ( (LA31_0==49) ) {
                alt31=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 31, 0, input);

                throw nvae;
            }
            switch (alt31) {
                case 1 :
                    // InternalSM2.g:1243:3: this_Mapping_0= ruleMapping
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Mapping_0=ruleMapping();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Mapping_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1252:3: this_Struct_1= ruleStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Struct_1=ruleStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Struct_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:1264:1: entryRuleMapping returns [EObject current=null] : iv_ruleMapping= ruleMapping EOF ;
    public final EObject entryRuleMapping() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMapping = null;


        try {
            // InternalSM2.g:1264:48: (iv_ruleMapping= ruleMapping EOF )
            // InternalSM2.g:1265:2: iv_ruleMapping= ruleMapping EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMappingRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleMapping=ruleMapping();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleMapping; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:1271:1: ruleMapping returns [EObject current=null] : (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON ) ;
    public final EObject ruleMapping() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_3=null;
        Token lv_expr_4_0=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token lv_nameMapping_7_0=null;
        Token this_SEMICOLON_8=null;
        Enumerator lv_type_2_0 = null;

        Enumerator lv_visibility_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1277:2: ( (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON ) )
            // InternalSM2.g:1278:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON )
            {
            // InternalSM2.g:1278:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON )
            // InternalSM2.g:1279:3: otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON
            {
            otherlv_0=(Token)match(input,47,FOLLOW_28); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getMappingAccess().getMappingKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_38); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1287:3: ( (lv_type_2_0= ruleSingularType ) )
            // InternalSM2.g:1288:4: (lv_type_2_0= ruleSingularType )
            {
            // InternalSM2.g:1288:4: (lv_type_2_0= ruleSingularType )
            // InternalSM2.g:1289:5: lv_type_2_0= ruleSingularType
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_39);
            lv_type_2_0=ruleSingularType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getMappingRule());
              					}
              					set(
              						current,
              						"type",
              						lv_type_2_0,
              						"org.xtext.SM2.SingularType");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,48,FOLLOW_35); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3());
              		
            }
            // InternalSM2.g:1310:3: ( (lv_expr_4_0= RULE_STRING ) )
            // InternalSM2.g:1311:4: (lv_expr_4_0= RULE_STRING )
            {
            // InternalSM2.g:1311:4: (lv_expr_4_0= RULE_STRING )
            // InternalSM2.g:1312:5: lv_expr_4_0= RULE_STRING
            {
            lv_expr_4_0=(Token)match(input,RULE_STRING,FOLLOW_30); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr_4_0, grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getMappingRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr",
              						lv_expr_4_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_40); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1332:3: ( (lv_visibility_6_0= ruleVisibility ) )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( ((LA32_0>=41 && LA32_0<=42)||(LA32_0>=71 && LA32_0<=72)) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalSM2.g:1333:4: (lv_visibility_6_0= ruleVisibility )
                    {
                    // InternalSM2.g:1333:4: (lv_visibility_6_0= ruleVisibility )
                    // InternalSM2.g:1334:5: lv_visibility_6_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_9);
                    lv_visibility_6_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getMappingRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_6_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1351:3: ( (lv_nameMapping_7_0= RULE_ID ) )
            // InternalSM2.g:1352:4: (lv_nameMapping_7_0= RULE_ID )
            {
            // InternalSM2.g:1352:4: (lv_nameMapping_7_0= RULE_ID )
            // InternalSM2.g:1353:5: lv_nameMapping_7_0= RULE_ID
            {
            lv_nameMapping_7_0=(Token)match(input,RULE_ID,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameMapping_7_0, grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getMappingRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameMapping",
              						lv_nameMapping_7_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:1377:1: entryRuleStruct returns [EObject current=null] : iv_ruleStruct= ruleStruct EOF ;
    public final EObject entryRuleStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStruct = null;


        try {
            // InternalSM2.g:1377:47: (iv_ruleStruct= ruleStruct EOF )
            // InternalSM2.g:1378:2: iv_ruleStruct= ruleStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleStruct=ruleStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:1384:1: ruleStruct returns [EObject current=null] : ( ( (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser ) ) ) ;
    public final EObject ruleStruct() throws RecognitionException {
        EObject current = null;

        EObject lv_typeStruct_0_1 = null;

        EObject lv_typeStruct_0_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:1390:2: ( ( ( (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser ) ) ) )
            // InternalSM2.g:1391:2: ( ( (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser ) ) )
            {
            // InternalSM2.g:1391:2: ( ( (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser ) ) )
            // InternalSM2.g:1392:3: ( (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser ) )
            {
            // InternalSM2.g:1392:3: ( (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser ) )
            // InternalSM2.g:1393:4: (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser )
            {
            // InternalSM2.g:1393:4: (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser )
            int alt33=2;
            alt33 = dfa33.predict(input);
            switch (alt33) {
                case 1 :
                    // InternalSM2.g:1394:5: lv_typeStruct_0_1= rulePersonalizedStruct
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getStructAccess().getTypeStructPersonalizedStructParserRuleCall_0_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_typeStruct_0_1=rulePersonalizedStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getStructRule());
                      					}
                      					set(
                      						current,
                      						"typeStruct",
                      						lv_typeStruct_0_1,
                      						"org.xtext.SM2.PersonalizedStruct");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1410:5: lv_typeStruct_0_2= ruleUser
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getStructAccess().getTypeStructUserParserRuleCall_0_1());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_typeStruct_0_2=ruleUser();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getStructRule());
                      					}
                      					set(
                      						current,
                      						"typeStruct",
                      						lv_typeStruct_0_2,
                      						"org.xtext.SM2.User");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }
                    break;

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRulePersonalizedStruct"
    // InternalSM2.g:1431:1: entryRulePersonalizedStruct returns [EObject current=null] : iv_rulePersonalizedStruct= rulePersonalizedStruct EOF ;
    public final EObject entryRulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonalizedStruct = null;


        try {
            // InternalSM2.g:1431:59: (iv_rulePersonalizedStruct= rulePersonalizedStruct EOF )
            // InternalSM2.g:1432:2: iv_rulePersonalizedStruct= rulePersonalizedStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPersonalizedStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePersonalizedStruct=rulePersonalizedStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePersonalizedStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonalizedStruct"


    // $ANTLR start "rulePersonalizedStruct"
    // InternalSM2.g:1438:1: rulePersonalizedStruct returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject rulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_CLOSEKEY_5=null;
        Token this_EOLINE_6=null;
        EObject lv_properties_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1444:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1445:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1445:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1446:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,49,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getPersonalizedStructAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:1450:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1451:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1451:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1452:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getPersonalizedStructAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPersonalizedStructRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_41); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1472:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==RULE_EOLINE) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalSM2.g:1473:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_38); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:1478:3: ( (lv_properties_4_0= ruleProperty ) )+
            int cnt35=0;
            loop35:
            do {
                int alt35=2;
                int LA35_0 = input.LA(1);

                if ( ((LA35_0>=50 && LA35_0<=52)||(LA35_0>=63 && LA35_0<=70)) ) {
                    alt35=1;
                }


                switch (alt35) {
            	case 1 :
            	    // InternalSM2.g:1479:4: (lv_properties_4_0= ruleProperty )
            	    {
            	    // InternalSM2.g:1479:4: (lv_properties_4_0= ruleProperty )
            	    // InternalSM2.g:1480:5: lv_properties_4_0= ruleProperty
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_42);
            	    lv_properties_4_0=ruleProperty();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getPersonalizedStructRule());
            	      					}
            	      					add(
            	      						current,
            	      						"properties",
            	      						lv_properties_4_0,
            	      						"org.xtext.SM2.Property");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt35 >= 1 ) break loop35;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(35, input);
                        throw eee;
                }
                cnt35++;
            } while (true);

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_5, grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1501:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt36=2;
            alt36 = dfa36.predict(input);
            switch (alt36) {
                case 1 :
                    // InternalSM2.g:1502:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonalizedStruct"


    // $ANTLR start "entryRuleUser"
    // InternalSM2.g:1511:1: entryRuleUser returns [EObject current=null] : iv_ruleUser= ruleUser EOF ;
    public final EObject entryRuleUser() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUser = null;


        try {
            // InternalSM2.g:1511:45: (iv_ruleUser= ruleUser EOF )
            // InternalSM2.g:1512:2: iv_ruleUser= ruleUser EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getUserRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleUser=ruleUser();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleUser; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUser"


    // $ANTLR start "ruleUser"
    // InternalSM2.g:1518:1: ruleUser returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' otherlv_29= 'amountAccount' ( (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) ) | this_INTEGER_32= RULE_INTEGER )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) ;
    public final EObject ruleUser() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_0=null;
        Token otherlv_6=null;
        Token this_STRING_7=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Token otherlv_10=null;
        Token lv_nameUser_11_0=null;
        Token otherlv_12=null;
        Token this_STRING_13=null;
        Token this_SEMICOLON_14=null;
        Token this_EOLINE_15=null;
        Token otherlv_16=null;
        Token lv_surname_17_0=null;
        Token otherlv_18=null;
        Token this_STRING_19=null;
        Token this_SEMICOLON_20=null;
        Token this_EOLINE_21=null;
        Token otherlv_22=null;
        Token lv_email_23_0=null;
        Token otherlv_24=null;
        Token this_EMAIL_25=null;
        Token this_SEMICOLON_26=null;
        Token this_EOLINE_27=null;
        Token otherlv_28=null;
        Token otherlv_29=null;
        Token otherlv_30=null;
        Token lv_amount_31_0=null;
        Token this_INTEGER_32=null;
        Token this_SEMICOLON_33=null;
        Token this_EOLINE_34=null;
        Token this_CLOSEKEY_35=null;
        Token this_EOLINE_36=null;


        	enterRule();

        try {
            // InternalSM2.g:1524:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' otherlv_29= 'amountAccount' ( (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) ) | this_INTEGER_32= RULE_INTEGER )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) )
            // InternalSM2.g:1525:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' otherlv_29= 'amountAccount' ( (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) ) | this_INTEGER_32= RULE_INTEGER )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            {
            // InternalSM2.g:1525:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' otherlv_29= 'amountAccount' ( (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) ) | this_INTEGER_32= RULE_INTEGER )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            // InternalSM2.g:1526:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' otherlv_29= 'amountAccount' ( (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) ) | this_INTEGER_32= RULE_INTEGER )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,49,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getUserAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:1530:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1531:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1531:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1532:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_43); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1552:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==RULE_EOLINE) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalSM2.g:1553:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_44); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            otherlv_4=(Token)match(input,50,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getUserAccess().getAddressKeyword_4());
              		
            }
            // InternalSM2.g:1562:3: ( (lv_idAdress_5_0= RULE_ID ) )
            // InternalSM2.g:1563:4: (lv_idAdress_5_0= RULE_ID )
            {
            // InternalSM2.g:1563:4: (lv_idAdress_5_0= RULE_ID )
            // InternalSM2.g:1564:5: lv_idAdress_5_0= RULE_ID
            {
            lv_idAdress_5_0=(Token)match(input,RULE_ID,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_idAdress_5_0, grammarAccess.getUserAccess().getIdAdressIDTerminalRuleCall_5_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"idAdress",
              						lv_idAdress_5_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:1580:3: (otherlv_6= '=' this_STRING_7= RULE_STRING )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==43) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:1581:4: otherlv_6= '=' this_STRING_7= RULE_STRING
                    {
                    otherlv_6=(Token)match(input,43,FOLLOW_35); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_6, grammarAccess.getUserAccess().getEqualsSignKeyword_6_0());
                      			
                    }
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_7, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_6_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_46); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            // InternalSM2.g:1594:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==RULE_EOLINE) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalSM2.g:1595:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_8());
                      			
                    }

                    }
                    break;

            }

            otherlv_10=(Token)match(input,51,FOLLOW_35); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_10, grammarAccess.getUserAccess().getStringKeyword_9());
              		
            }
            // InternalSM2.g:1604:3: ( (lv_nameUser_11_0= RULE_STRING ) )
            // InternalSM2.g:1605:4: (lv_nameUser_11_0= RULE_STRING )
            {
            // InternalSM2.g:1605:4: (lv_nameUser_11_0= RULE_STRING )
            // InternalSM2.g:1606:5: lv_nameUser_11_0= RULE_STRING
            {
            lv_nameUser_11_0=(Token)match(input,RULE_STRING,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameUser_11_0, grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_10_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameUser",
              						lv_nameUser_11_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1622:3: (otherlv_12= '=' this_STRING_13= RULE_STRING )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==43) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalSM2.g:1623:4: otherlv_12= '=' this_STRING_13= RULE_STRING
                    {
                    otherlv_12=(Token)match(input,43,FOLLOW_35); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_12, grammarAccess.getUserAccess().getEqualsSignKeyword_11_0());
                      			
                    }
                    this_STRING_13=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_13, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_11_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_14=(Token)match(input,RULE_SEMICOLON,FOLLOW_46); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_14, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_12());
              		
            }
            // InternalSM2.g:1636:3: (this_EOLINE_15= RULE_EOLINE )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==RULE_EOLINE) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalSM2.g:1637:4: this_EOLINE_15= RULE_EOLINE
                    {
                    this_EOLINE_15=(Token)match(input,RULE_EOLINE,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_15, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_13());
                      			
                    }

                    }
                    break;

            }

            otherlv_16=(Token)match(input,51,FOLLOW_35); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_16, grammarAccess.getUserAccess().getStringKeyword_14());
              		
            }
            // InternalSM2.g:1646:3: ( (lv_surname_17_0= RULE_STRING ) )
            // InternalSM2.g:1647:4: (lv_surname_17_0= RULE_STRING )
            {
            // InternalSM2.g:1647:4: (lv_surname_17_0= RULE_STRING )
            // InternalSM2.g:1648:5: lv_surname_17_0= RULE_STRING
            {
            lv_surname_17_0=(Token)match(input,RULE_STRING,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_surname_17_0, grammarAccess.getUserAccess().getSurnameSTRINGTerminalRuleCall_15_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"surname",
              						lv_surname_17_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1664:3: (otherlv_18= '=' this_STRING_19= RULE_STRING )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==43) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalSM2.g:1665:4: otherlv_18= '=' this_STRING_19= RULE_STRING
                    {
                    otherlv_18=(Token)match(input,43,FOLLOW_35); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_18, grammarAccess.getUserAccess().getEqualsSignKeyword_16_0());
                      			
                    }
                    this_STRING_19=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_19, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_16_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_20=(Token)match(input,RULE_SEMICOLON,FOLLOW_46); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_20, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_17());
              		
            }
            // InternalSM2.g:1678:3: (this_EOLINE_21= RULE_EOLINE )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==RULE_EOLINE) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalSM2.g:1679:4: this_EOLINE_21= RULE_EOLINE
                    {
                    this_EOLINE_21=(Token)match(input,RULE_EOLINE,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_21, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_18());
                      			
                    }

                    }
                    break;

            }

            otherlv_22=(Token)match(input,51,FOLLOW_35); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_22, grammarAccess.getUserAccess().getStringKeyword_19());
              		
            }
            // InternalSM2.g:1688:3: ( (lv_email_23_0= RULE_STRING ) )
            // InternalSM2.g:1689:4: (lv_email_23_0= RULE_STRING )
            {
            // InternalSM2.g:1689:4: (lv_email_23_0= RULE_STRING )
            // InternalSM2.g:1690:5: lv_email_23_0= RULE_STRING
            {
            lv_email_23_0=(Token)match(input,RULE_STRING,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_email_23_0, grammarAccess.getUserAccess().getEmailSTRINGTerminalRuleCall_20_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"email",
              						lv_email_23_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1706:3: (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==43) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:1707:4: otherlv_24= '=' this_EMAIL_25= RULE_EMAIL
                    {
                    otherlv_24=(Token)match(input,43,FOLLOW_48); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_24, grammarAccess.getUserAccess().getEqualsSignKeyword_21_0());
                      			
                    }
                    this_EMAIL_25=(Token)match(input,RULE_EMAIL,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EMAIL_25, grammarAccess.getUserAccess().getEMAILTerminalRuleCall_21_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_26=(Token)match(input,RULE_SEMICOLON,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_26, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_22());
              		
            }
            // InternalSM2.g:1720:3: (this_EOLINE_27= RULE_EOLINE )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==RULE_EOLINE) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalSM2.g:1721:4: this_EOLINE_27= RULE_EOLINE
                    {
                    this_EOLINE_27=(Token)match(input,RULE_EOLINE,FOLLOW_50); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_27, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_23());
                      			
                    }

                    }
                    break;

            }

            otherlv_28=(Token)match(input,52,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_28, grammarAccess.getUserAccess().getUintKeyword_24());
              		
            }
            otherlv_29=(Token)match(input,53,FOLLOW_52); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_29, grammarAccess.getUserAccess().getAmountAccountKeyword_25());
              		
            }
            // InternalSM2.g:1734:3: ( (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) ) | this_INTEGER_32= RULE_INTEGER )?
            int alt46=3;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==43) ) {
                alt46=1;
            }
            else if ( (LA46_0==RULE_INTEGER) ) {
                alt46=2;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:1735:4: (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) )
                    {
                    // InternalSM2.g:1735:4: (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) )
                    // InternalSM2.g:1736:5: otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) )
                    {
                    otherlv_30=(Token)match(input,43,FOLLOW_53); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_30, grammarAccess.getUserAccess().getEqualsSignKeyword_26_0_0());
                      				
                    }
                    // InternalSM2.g:1740:5: ( (lv_amount_31_0= RULE_FLOAT ) )
                    // InternalSM2.g:1741:6: (lv_amount_31_0= RULE_FLOAT )
                    {
                    // InternalSM2.g:1741:6: (lv_amount_31_0= RULE_FLOAT )
                    // InternalSM2.g:1742:7: lv_amount_31_0= RULE_FLOAT
                    {
                    lv_amount_31_0=(Token)match(input,RULE_FLOAT,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_amount_31_0, grammarAccess.getUserAccess().getAmountFLOATTerminalRuleCall_26_0_1_0());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getUserRule());
                      							}
                      							setWithLastConsumed(
                      								current,
                      								"amount",
                      								lv_amount_31_0,
                      								"org.xtext.SM2.FLOAT");
                      						
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1760:4: this_INTEGER_32= RULE_INTEGER
                    {
                    this_INTEGER_32=(Token)match(input,RULE_INTEGER,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_INTEGER_32, grammarAccess.getUserAccess().getINTEGERTerminalRuleCall_26_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_33=(Token)match(input,RULE_SEMICOLON,FOLLOW_54); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_33, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_27());
              		
            }
            // InternalSM2.g:1769:3: (this_EOLINE_34= RULE_EOLINE )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==RULE_EOLINE) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalSM2.g:1770:4: this_EOLINE_34= RULE_EOLINE
                    {
                    this_EOLINE_34=(Token)match(input,RULE_EOLINE,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_34, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_28());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_35=(Token)match(input,RULE_CLOSEKEY,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_35, grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_29());
              		
            }
            // InternalSM2.g:1779:3: (this_EOLINE_36= RULE_EOLINE )?
            int alt48=2;
            alt48 = dfa48.predict(input);
            switch (alt48) {
                case 1 :
                    // InternalSM2.g:1780:4: this_EOLINE_36= RULE_EOLINE
                    {
                    this_EOLINE_36=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_36, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_30());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUser"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:1789:1: entryRuleEnum returns [EObject current=null] : iv_ruleEnum= ruleEnum EOF ;
    public final EObject entryRuleEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnum = null;


        try {
            // InternalSM2.g:1789:45: (iv_ruleEnum= ruleEnum EOF )
            // InternalSM2.g:1790:2: iv_ruleEnum= ruleEnum EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getEnumRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleEnum=ruleEnum();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleEnum; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:1796:1: ruleEnum returns [EObject current=null] : (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEnum_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_STRING_3=null;
        Token this_COMMA_4=null;
        Token this_CLOSEKEY_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;


        	enterRule();

        try {
            // InternalSM2.g:1802:2: ( (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:1803:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:1803:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:1804:3: otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,54,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getEnumAccess().getEnumKeyword_0());
              		
            }
            // InternalSM2.g:1808:3: ( (lv_nameEnum_1_0= RULE_ID ) )
            // InternalSM2.g:1809:4: (lv_nameEnum_1_0= RULE_ID )
            {
            // InternalSM2.g:1809:4: (lv_nameEnum_1_0= RULE_ID )
            // InternalSM2.g:1810:5: lv_nameEnum_1_0= RULE_ID
            {
            lv_nameEnum_1_0=(Token)match(input,RULE_ID,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameEnum_1_0, grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEnumRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameEnum",
              						lv_nameEnum_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_35); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1830:3: (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+
            int cnt50=0;
            loop50:
            do {
                int alt50=2;
                int LA50_0 = input.LA(1);

                if ( (LA50_0==RULE_STRING) ) {
                    alt50=1;
                }


                switch (alt50) {
            	case 1 :
            	    // InternalSM2.g:1831:4: this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )?
            	    {
            	    this_STRING_3=(Token)match(input,RULE_STRING,FOLLOW_55); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      				newLeafNode(this_STRING_3, grammarAccess.getEnumAccess().getSTRINGTerminalRuleCall_3_0());
            	      			
            	    }
            	    // InternalSM2.g:1835:4: (this_COMMA_4= RULE_COMMA )?
            	    int alt49=2;
            	    int LA49_0 = input.LA(1);

            	    if ( (LA49_0==RULE_COMMA) ) {
            	        alt49=1;
            	    }
            	    switch (alt49) {
            	        case 1 :
            	            // InternalSM2.g:1836:5: this_COMMA_4= RULE_COMMA
            	            {
            	            this_COMMA_4=(Token)match(input,RULE_COMMA,FOLLOW_56); if (state.failed) return current;
            	            if ( state.backtracking==0 ) {

            	              					newLeafNode(this_COMMA_4, grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_3_1());
            	              				
            	            }

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt50 >= 1 ) break loop50;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(50, input);
                        throw eee;
                }
                cnt50++;
            } while (true);

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_5, grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_4());
              		
            }
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1850:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt51=2;
            alt51 = dfa51.predict(input);
            switch (alt51) {
                case 1 :
                    // InternalSM2.g:1851:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:1860:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // InternalSM2.g:1860:49: (iv_ruleProperty= ruleProperty EOF )
            // InternalSM2.g:1861:2: iv_ruleProperty= ruleProperty EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleProperty=ruleProperty();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleProperty; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:1867:1: ruleProperty returns [EObject current=null] : ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INTEGER_5= RULE_INTEGER )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        Token lv_nameProperty_2_0=null;
        Token otherlv_3=null;
        Token lv_inicialization_4_0=null;
        Token this_INTEGER_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        Enumerator lv_type_0_0 = null;

        Enumerator lv_visibility_1_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1873:2: ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INTEGER_5= RULE_INTEGER )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:1874:2: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INTEGER_5= RULE_INTEGER )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:1874:2: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INTEGER_5= RULE_INTEGER )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:1875:3: ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INTEGER_5= RULE_INTEGER )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:1875:3: ( (lv_type_0_0= ruleSingularType ) )
            // InternalSM2.g:1876:4: (lv_type_0_0= ruleSingularType )
            {
            // InternalSM2.g:1876:4: (lv_type_0_0= ruleSingularType )
            // InternalSM2.g:1877:5: lv_type_0_0= ruleSingularType
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_40);
            lv_type_0_0=ruleSingularType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getPropertyRule());
              					}
              					set(
              						current,
              						"type",
              						lv_type_0_0,
              						"org.xtext.SM2.SingularType");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:1894:3: ( (lv_visibility_1_0= ruleVisibility ) )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( ((LA52_0>=41 && LA52_0<=42)||(LA52_0>=71 && LA52_0<=72)) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalSM2.g:1895:4: (lv_visibility_1_0= ruleVisibility )
                    {
                    // InternalSM2.g:1895:4: (lv_visibility_1_0= ruleVisibility )
                    // InternalSM2.g:1896:5: lv_visibility_1_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_9);
                    lv_visibility_1_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_1_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1913:3: ( (lv_nameProperty_2_0= RULE_ID ) )
            // InternalSM2.g:1914:4: (lv_nameProperty_2_0= RULE_ID )
            {
            // InternalSM2.g:1914:4: (lv_nameProperty_2_0= RULE_ID )
            // InternalSM2.g:1915:5: lv_nameProperty_2_0= RULE_ID
            {
            lv_nameProperty_2_0=(Token)match(input,RULE_ID,FOLLOW_57); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_2_0, grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_2_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            otherlv_3=(Token)match(input,43,FOLLOW_58); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getPropertyAccess().getEqualsSignKeyword_3());
              		
            }
            // InternalSM2.g:1935:3: ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INTEGER_5= RULE_INTEGER )?
            int alt53=3;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==RULE_STRING) ) {
                alt53=1;
            }
            else if ( (LA53_0==RULE_INTEGER) ) {
                alt53=2;
            }
            switch (alt53) {
                case 1 :
                    // InternalSM2.g:1936:4: ( (lv_inicialization_4_0= RULE_STRING ) )
                    {
                    // InternalSM2.g:1936:4: ( (lv_inicialization_4_0= RULE_STRING ) )
                    // InternalSM2.g:1937:5: (lv_inicialization_4_0= RULE_STRING )
                    {
                    // InternalSM2.g:1937:5: (lv_inicialization_4_0= RULE_STRING )
                    // InternalSM2.g:1938:6: lv_inicialization_4_0= RULE_STRING
                    {
                    lv_inicialization_4_0=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_inicialization_4_0, grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"inicialization",
                      							lv_inicialization_4_0,
                      							"org.eclipse.xtext.common.Terminals.STRING");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1955:4: this_INTEGER_5= RULE_INTEGER
                    {
                    this_INTEGER_5=(Token)match(input,RULE_INTEGER,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_INTEGER_5, grammarAccess.getPropertyAccess().getINTEGERTerminalRuleCall_4_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1964:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==RULE_EOLINE) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalSM2.g:1965:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:1974:1: entryRuleInputParam returns [EObject current=null] : iv_ruleInputParam= ruleInputParam EOF ;
    public final EObject entryRuleInputParam() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputParam = null;


        try {
            // InternalSM2.g:1974:51: (iv_ruleInputParam= ruleInputParam EOF )
            // InternalSM2.g:1975:2: iv_ruleInputParam= ruleInputParam EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getInputParamRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleInputParam=ruleInputParam();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleInputParam; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:1981:1: ruleInputParam returns [EObject current=null] : ( ( ( (lv_type_0_0= ruleSingularType ) ) ( ( (lv_isArray_1_0= '[]' ) ) ( (lv_needMoreDimensionArray_2_0= '[]' ) )* )? ( ( (lv_storage_3_0= 'memory' ) ) | otherlv_4= 'local' )? ( (lv_nameParam_5_0= RULE_ID ) ) ) ( (lv_comma_6_0= RULE_COMMA ) )? ) ;
    public final EObject ruleInputParam() throws RecognitionException {
        EObject current = null;

        Token lv_isArray_1_0=null;
        Token lv_needMoreDimensionArray_2_0=null;
        Token lv_storage_3_0=null;
        Token otherlv_4=null;
        Token lv_nameParam_5_0=null;
        Token lv_comma_6_0=null;
        Enumerator lv_type_0_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1987:2: ( ( ( ( (lv_type_0_0= ruleSingularType ) ) ( ( (lv_isArray_1_0= '[]' ) ) ( (lv_needMoreDimensionArray_2_0= '[]' ) )* )? ( ( (lv_storage_3_0= 'memory' ) ) | otherlv_4= 'local' )? ( (lv_nameParam_5_0= RULE_ID ) ) ) ( (lv_comma_6_0= RULE_COMMA ) )? ) )
            // InternalSM2.g:1988:2: ( ( ( (lv_type_0_0= ruleSingularType ) ) ( ( (lv_isArray_1_0= '[]' ) ) ( (lv_needMoreDimensionArray_2_0= '[]' ) )* )? ( ( (lv_storage_3_0= 'memory' ) ) | otherlv_4= 'local' )? ( (lv_nameParam_5_0= RULE_ID ) ) ) ( (lv_comma_6_0= RULE_COMMA ) )? )
            {
            // InternalSM2.g:1988:2: ( ( ( (lv_type_0_0= ruleSingularType ) ) ( ( (lv_isArray_1_0= '[]' ) ) ( (lv_needMoreDimensionArray_2_0= '[]' ) )* )? ( ( (lv_storage_3_0= 'memory' ) ) | otherlv_4= 'local' )? ( (lv_nameParam_5_0= RULE_ID ) ) ) ( (lv_comma_6_0= RULE_COMMA ) )? )
            // InternalSM2.g:1989:3: ( ( (lv_type_0_0= ruleSingularType ) ) ( ( (lv_isArray_1_0= '[]' ) ) ( (lv_needMoreDimensionArray_2_0= '[]' ) )* )? ( ( (lv_storage_3_0= 'memory' ) ) | otherlv_4= 'local' )? ( (lv_nameParam_5_0= RULE_ID ) ) ) ( (lv_comma_6_0= RULE_COMMA ) )?
            {
            // InternalSM2.g:1989:3: ( ( (lv_type_0_0= ruleSingularType ) ) ( ( (lv_isArray_1_0= '[]' ) ) ( (lv_needMoreDimensionArray_2_0= '[]' ) )* )? ( ( (lv_storage_3_0= 'memory' ) ) | otherlv_4= 'local' )? ( (lv_nameParam_5_0= RULE_ID ) ) )
            // InternalSM2.g:1990:4: ( (lv_type_0_0= ruleSingularType ) ) ( ( (lv_isArray_1_0= '[]' ) ) ( (lv_needMoreDimensionArray_2_0= '[]' ) )* )? ( ( (lv_storage_3_0= 'memory' ) ) | otherlv_4= 'local' )? ( (lv_nameParam_5_0= RULE_ID ) )
            {
            // InternalSM2.g:1990:4: ( (lv_type_0_0= ruleSingularType ) )
            // InternalSM2.g:1991:5: (lv_type_0_0= ruleSingularType )
            {
            // InternalSM2.g:1991:5: (lv_type_0_0= ruleSingularType )
            // InternalSM2.g:1992:6: lv_type_0_0= ruleSingularType
            {
            if ( state.backtracking==0 ) {

              						newCompositeNode(grammarAccess.getInputParamAccess().getTypeSingularTypeEnumRuleCall_0_0_0());
              					
            }
            pushFollow(FOLLOW_59);
            lv_type_0_0=ruleSingularType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElementForParent(grammarAccess.getInputParamRule());
              						}
              						set(
              							current,
              							"type",
              							lv_type_0_0,
              							"org.xtext.SM2.SingularType");
              						afterParserOrEnumRuleCall();
              					
            }

            }


            }

            // InternalSM2.g:2009:4: ( ( (lv_isArray_1_0= '[]' ) ) ( (lv_needMoreDimensionArray_2_0= '[]' ) )* )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==55) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalSM2.g:2010:5: ( (lv_isArray_1_0= '[]' ) ) ( (lv_needMoreDimensionArray_2_0= '[]' ) )*
                    {
                    // InternalSM2.g:2010:5: ( (lv_isArray_1_0= '[]' ) )
                    // InternalSM2.g:2011:6: (lv_isArray_1_0= '[]' )
                    {
                    // InternalSM2.g:2011:6: (lv_isArray_1_0= '[]' )
                    // InternalSM2.g:2012:7: lv_isArray_1_0= '[]'
                    {
                    lv_isArray_1_0=(Token)match(input,55,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_isArray_1_0, grammarAccess.getInputParamAccess().getIsArrayLeftSquareBracketRightSquareBracketKeyword_0_1_0_0());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getInputParamRule());
                      							}
                      							setWithLastConsumed(current, "isArray", lv_isArray_1_0, "[]");
                      						
                    }

                    }


                    }

                    // InternalSM2.g:2024:5: ( (lv_needMoreDimensionArray_2_0= '[]' ) )*
                    loop55:
                    do {
                        int alt55=2;
                        int LA55_0 = input.LA(1);

                        if ( (LA55_0==55) ) {
                            alt55=1;
                        }


                        switch (alt55) {
                    	case 1 :
                    	    // InternalSM2.g:2025:6: (lv_needMoreDimensionArray_2_0= '[]' )
                    	    {
                    	    // InternalSM2.g:2025:6: (lv_needMoreDimensionArray_2_0= '[]' )
                    	    // InternalSM2.g:2026:7: lv_needMoreDimensionArray_2_0= '[]'
                    	    {
                    	    lv_needMoreDimensionArray_2_0=(Token)match(input,55,FOLLOW_59); if (state.failed) return current;
                    	    if ( state.backtracking==0 ) {

                    	      							newLeafNode(lv_needMoreDimensionArray_2_0, grammarAccess.getInputParamAccess().getNeedMoreDimensionArrayLeftSquareBracketRightSquareBracketKeyword_0_1_1_0());
                    	      						
                    	    }
                    	    if ( state.backtracking==0 ) {

                    	      							if (current==null) {
                    	      								current = createModelElement(grammarAccess.getInputParamRule());
                    	      							}
                    	      							setWithLastConsumed(current, "needMoreDimensionArray", lv_needMoreDimensionArray_2_0, "[]");
                    	      						
                    	    }

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop55;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalSM2.g:2039:4: ( ( (lv_storage_3_0= 'memory' ) ) | otherlv_4= 'local' )?
            int alt57=3;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==56) ) {
                alt57=1;
            }
            else if ( (LA57_0==57) ) {
                alt57=2;
            }
            switch (alt57) {
                case 1 :
                    // InternalSM2.g:2040:5: ( (lv_storage_3_0= 'memory' ) )
                    {
                    // InternalSM2.g:2040:5: ( (lv_storage_3_0= 'memory' ) )
                    // InternalSM2.g:2041:6: (lv_storage_3_0= 'memory' )
                    {
                    // InternalSM2.g:2041:6: (lv_storage_3_0= 'memory' )
                    // InternalSM2.g:2042:7: lv_storage_3_0= 'memory'
                    {
                    lv_storage_3_0=(Token)match(input,56,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_storage_3_0, grammarAccess.getInputParamAccess().getStorageMemoryKeyword_0_2_0_0());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getInputParamRule());
                      							}
                      							setWithLastConsumed(current, "storage", lv_storage_3_0, "memory");
                      						
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2055:5: otherlv_4= 'local'
                    {
                    otherlv_4=(Token)match(input,57,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_4, grammarAccess.getInputParamAccess().getLocalKeyword_0_2_1());
                      				
                    }

                    }
                    break;

            }

            // InternalSM2.g:2060:4: ( (lv_nameParam_5_0= RULE_ID ) )
            // InternalSM2.g:2061:5: (lv_nameParam_5_0= RULE_ID )
            {
            // InternalSM2.g:2061:5: (lv_nameParam_5_0= RULE_ID )
            // InternalSM2.g:2062:6: lv_nameParam_5_0= RULE_ID
            {
            lv_nameParam_5_0=(Token)match(input,RULE_ID,FOLLOW_60); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						newLeafNode(lv_nameParam_5_0, grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_3_0());
              					
            }
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElement(grammarAccess.getInputParamRule());
              						}
              						setWithLastConsumed(
              							current,
              							"nameParam",
              							lv_nameParam_5_0,
              							"org.eclipse.xtext.common.Terminals.ID");
              					
            }

            }


            }


            }

            // InternalSM2.g:2079:3: ( (lv_comma_6_0= RULE_COMMA ) )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==RULE_COMMA) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // InternalSM2.g:2080:4: (lv_comma_6_0= RULE_COMMA )
                    {
                    // InternalSM2.g:2080:4: (lv_comma_6_0= RULE_COMMA )
                    // InternalSM2.g:2081:5: lv_comma_6_0= RULE_COMMA
                    {
                    lv_comma_6_0=(Token)match(input,RULE_COMMA,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_comma_6_0, grammarAccess.getInputParamAccess().getCommaCOMMATerminalRuleCall_1_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getInputParamRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"comma",
                      						lv_comma_6_0,
                      						"org.xtext.SM2.COMMA");
                      				
                    }

                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:2101:1: entryRuleRestriction returns [EObject current=null] : iv_ruleRestriction= ruleRestriction EOF ;
    public final EObject entryRuleRestriction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestriction = null;


        try {
            // InternalSM2.g:2101:52: (iv_ruleRestriction= ruleRestriction EOF )
            // InternalSM2.g:2102:2: iv_ruleRestriction= ruleRestriction EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRestrictionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRestriction=ruleRestriction();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRestriction; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:2108:1: ruleRestriction returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) ;
    public final EObject ruleRestriction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        EObject lv_expr1_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        EObject lv_expr2_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2114:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) )
            // InternalSM2.g:2115:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            {
            // InternalSM2.g:2115:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            // InternalSM2.g:2116:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,58,FOLLOW_28); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getRestrictionAccess().getRequireKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_32); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:2124:3: ( (lv_expr1_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:2125:4: (lv_expr1_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:2125:4: (lv_expr1_2_0= ruleSyntaxExpression )
            // InternalSM2.g:2126:5: lv_expr1_2_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr1SyntaxExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_61);
            lv_expr1_2_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"expr1",
              						lv_expr1_2_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2143:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:2144:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:2144:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:2145:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_32);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2162:3: ( (lv_expr2_4_0= ruleSyntaxExpression ) )
            // InternalSM2.g:2163:4: (lv_expr2_4_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:2163:4: (lv_expr2_4_0= ruleSyntaxExpression )
            // InternalSM2.g:2164:5: lv_expr2_4_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr2SyntaxExpressionParserRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_30);
            lv_expr2_4_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"expr2",
              						lv_expr2_4_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_7, grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:2197:1: entryRuleRestrictionGas returns [EObject current=null] : iv_ruleRestrictionGas= ruleRestrictionGas EOF ;
    public final EObject entryRuleRestrictionGas() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionGas = null;


        try {
            // InternalSM2.g:2197:55: (iv_ruleRestrictionGas= ruleRestrictionGas EOF )
            // InternalSM2.g:2198:2: iv_ruleRestrictionGas= ruleRestrictionGas EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRestrictionGasRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionGas=ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRestrictionGas; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:2204:1: ruleRestrictionGas returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_NUMBER ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) ;
    public final EObject ruleRestrictionGas() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_amount_4_0=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        EObject lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        Enumerator lv_typeCoin_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2210:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_NUMBER ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) )
            // InternalSM2.g:2211:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_NUMBER ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            {
            // InternalSM2.g:2211:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_NUMBER ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            // InternalSM2.g:2212:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_NUMBER ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,58,FOLLOW_28); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getRestrictionGasAccess().getRequireKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_32); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:2220:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:2221:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:2221:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2.g:2222:5: lv_expr_2_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_61);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_2_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2239:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:2240:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:2240:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:2241:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_18);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2258:3: ( (lv_amount_4_0= RULE_NUMBER ) )
            // InternalSM2.g:2259:4: (lv_amount_4_0= RULE_NUMBER )
            {
            // InternalSM2.g:2259:4: (lv_amount_4_0= RULE_NUMBER )
            // InternalSM2.g:2260:5: lv_amount_4_0= RULE_NUMBER
            {
            lv_amount_4_0=(Token)match(input,RULE_NUMBER,FOLLOW_62); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_amount_4_0, grammarAccess.getRestrictionGasAccess().getAmountNUMBERTerminalRuleCall_4_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getRestrictionGasRule());
              					}
              					setWithLastConsumed(
              						current,
              						"amount",
              						lv_amount_4_0,
              						"org.xtext.SM2.NUMBER");
              				
            }

            }


            }

            // InternalSM2.g:2276:3: ( (lv_typeCoin_5_0= ruleCoin ) )
            // InternalSM2.g:2277:4: (lv_typeCoin_5_0= ruleCoin )
            {
            // InternalSM2.g:2277:4: (lv_typeCoin_5_0= ruleCoin )
            // InternalSM2.g:2278:5: lv_typeCoin_5_0= ruleCoin
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0());
              				
            }
            pushFollow(FOLLOW_30);
            lv_typeCoin_5_0=ruleCoin();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"typeCoin",
              						lv_typeCoin_5_0,
              						"org.xtext.SM2.Coin");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }
            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_7, grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_8, grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2.g:2311:1: entryRuleClause returns [EObject current=null] : iv_ruleClause= ruleClause EOF ;
    public final EObject entryRuleClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClause = null;


        try {
            // InternalSM2.g:2311:47: (iv_ruleClause= ruleClause EOF )
            // InternalSM2.g:2312:2: iv_ruleClause= ruleClause EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getClauseRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleClause=ruleClause();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleClause; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2.g:2318:1: ruleClause returns [EObject current=null] : (this_HeadClause_0= ruleHeadClause this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restriction_3_0= ruleRestriction ) )? ( (lv_restrictionGas_4_0= ruleRestrictionGas ) )? ( (lv_localAttributes_5_0= ruleAttributes ) )? ( (lv_expression_6_0= ruleExpression ) )+ (this_EOLINE_7= RULE_EOLINE )? this_CLOSEKEY_8= RULE_CLOSEKEY this_EOLINE_9= RULE_EOLINE ) ;
    public final EObject ruleClause() throws RecognitionException {
        EObject current = null;

        Token this_OPENKEY_1=null;
        Token this_EOLINE_2=null;
        Token this_EOLINE_7=null;
        Token this_CLOSEKEY_8=null;
        Token this_EOLINE_9=null;
        EObject this_HeadClause_0 = null;

        EObject lv_restriction_3_0 = null;

        EObject lv_restrictionGas_4_0 = null;

        EObject lv_localAttributes_5_0 = null;

        EObject lv_expression_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2324:2: ( (this_HeadClause_0= ruleHeadClause this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restriction_3_0= ruleRestriction ) )? ( (lv_restrictionGas_4_0= ruleRestrictionGas ) )? ( (lv_localAttributes_5_0= ruleAttributes ) )? ( (lv_expression_6_0= ruleExpression ) )+ (this_EOLINE_7= RULE_EOLINE )? this_CLOSEKEY_8= RULE_CLOSEKEY this_EOLINE_9= RULE_EOLINE ) )
            // InternalSM2.g:2325:2: (this_HeadClause_0= ruleHeadClause this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restriction_3_0= ruleRestriction ) )? ( (lv_restrictionGas_4_0= ruleRestrictionGas ) )? ( (lv_localAttributes_5_0= ruleAttributes ) )? ( (lv_expression_6_0= ruleExpression ) )+ (this_EOLINE_7= RULE_EOLINE )? this_CLOSEKEY_8= RULE_CLOSEKEY this_EOLINE_9= RULE_EOLINE )
            {
            // InternalSM2.g:2325:2: (this_HeadClause_0= ruleHeadClause this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restriction_3_0= ruleRestriction ) )? ( (lv_restrictionGas_4_0= ruleRestrictionGas ) )? ( (lv_localAttributes_5_0= ruleAttributes ) )? ( (lv_expression_6_0= ruleExpression ) )+ (this_EOLINE_7= RULE_EOLINE )? this_CLOSEKEY_8= RULE_CLOSEKEY this_EOLINE_9= RULE_EOLINE )
            // InternalSM2.g:2326:3: this_HeadClause_0= ruleHeadClause this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restriction_3_0= ruleRestriction ) )? ( (lv_restrictionGas_4_0= ruleRestrictionGas ) )? ( (lv_localAttributes_5_0= ruleAttributes ) )? ( (lv_expression_6_0= ruleExpression ) )+ (this_EOLINE_7= RULE_EOLINE )? this_CLOSEKEY_8= RULE_CLOSEKEY this_EOLINE_9= RULE_EOLINE
            {
            if ( state.backtracking==0 ) {

              			newCompositeNode(grammarAccess.getClauseAccess().getHeadClauseParserRuleCall_0());
              		
            }
            pushFollow(FOLLOW_11);
            this_HeadClause_0=ruleHeadClause();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			current = this_HeadClause_0;
              			afterParserOrEnumRuleCall();
              		
            }
            this_OPENKEY_1=(Token)match(input,RULE_OPENKEY,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_1, grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_1());
              		
            }
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_63); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_2, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2342:3: ( (lv_restriction_3_0= ruleRestriction ) )?
            int alt59=2;
            alt59 = dfa59.predict(input);
            switch (alt59) {
                case 1 :
                    // InternalSM2.g:2343:4: (lv_restriction_3_0= ruleRestriction )
                    {
                    // InternalSM2.g:2343:4: (lv_restriction_3_0= ruleRestriction )
                    // InternalSM2.g:2344:5: lv_restriction_3_0= ruleRestriction
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_3_0());
                      				
                    }
                    pushFollow(FOLLOW_63);
                    lv_restriction_3_0=ruleRestriction();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getClauseRule());
                      					}
                      					add(
                      						current,
                      						"restriction",
                      						lv_restriction_3_0,
                      						"org.xtext.SM2.Restriction");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2361:3: ( (lv_restrictionGas_4_0= ruleRestrictionGas ) )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==58) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // InternalSM2.g:2362:4: (lv_restrictionGas_4_0= ruleRestrictionGas )
                    {
                    // InternalSM2.g:2362:4: (lv_restrictionGas_4_0= ruleRestrictionGas )
                    // InternalSM2.g:2363:5: lv_restrictionGas_4_0= ruleRestrictionGas
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_4_0());
                      				
                    }
                    pushFollow(FOLLOW_64);
                    lv_restrictionGas_4_0=ruleRestrictionGas();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getClauseRule());
                      					}
                      					add(
                      						current,
                      						"restrictionGas",
                      						lv_restrictionGas_4_0,
                      						"org.xtext.SM2.RestrictionGas");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2380:3: ( (lv_localAttributes_5_0= ruleAttributes ) )?
            int alt61=2;
            int LA61_0 = input.LA(1);

            if ( (LA61_0==RULE_ID||LA61_0==47||(LA61_0>=49 && LA61_0<=52)||LA61_0==54||(LA61_0>=63 && LA61_0<=70)) ) {
                alt61=1;
            }
            switch (alt61) {
                case 1 :
                    // InternalSM2.g:2381:4: (lv_localAttributes_5_0= ruleAttributes )
                    {
                    // InternalSM2.g:2381:4: (lv_localAttributes_5_0= ruleAttributes )
                    // InternalSM2.g:2382:5: lv_localAttributes_5_0= ruleAttributes
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getClauseAccess().getLocalAttributesAttributesParserRuleCall_5_0());
                      				
                    }
                    pushFollow(FOLLOW_32);
                    lv_localAttributes_5_0=ruleAttributes();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getClauseRule());
                      					}
                      					add(
                      						current,
                      						"localAttributes",
                      						lv_localAttributes_5_0,
                      						"org.xtext.SM2.Attributes");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2399:3: ( (lv_expression_6_0= ruleExpression ) )+
            int cnt62=0;
            loop62:
            do {
                int alt62=2;
                int LA62_0 = input.LA(1);

                if ( (LA62_0==RULE_OPENPARENTHESIS||LA62_0==RULE_STRING||LA62_0==RULE_INTEGER) ) {
                    alt62=1;
                }


                switch (alt62) {
            	case 1 :
            	    // InternalSM2.g:2400:4: (lv_expression_6_0= ruleExpression )
            	    {
            	    // InternalSM2.g:2400:4: (lv_expression_6_0= ruleExpression )
            	    // InternalSM2.g:2401:5: lv_expression_6_0= ruleExpression
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_6_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_65);
            	    lv_expression_6_0=ruleExpression();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getClauseRule());
            	      					}
            	      					add(
            	      						current,
            	      						"expression",
            	      						lv_expression_6_0,
            	      						"org.xtext.SM2.Expression");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt62 >= 1 ) break loop62;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(62, input);
                        throw eee;
                }
                cnt62++;
            } while (true);

            // InternalSM2.g:2418:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt63=2;
            int LA63_0 = input.LA(1);

            if ( (LA63_0==RULE_EOLINE) ) {
                alt63=1;
            }
            switch (alt63) {
                case 1 :
                    // InternalSM2.g:2419:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_8=(Token)match(input,RULE_CLOSEKEY,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_8, grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_8());
              		
            }
            this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_9, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_9());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRuleHeadClause"
    // InternalSM2.g:2436:1: entryRuleHeadClause returns [EObject current=null] : iv_ruleHeadClause= ruleHeadClause EOF ;
    public final EObject entryRuleHeadClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleHeadClause = null;


        try {
            // InternalSM2.g:2436:51: (iv_ruleHeadClause= ruleHeadClause EOF )
            // InternalSM2.g:2437:2: iv_ruleHeadClause= ruleHeadClause EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getHeadClauseRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleHeadClause=ruleHeadClause();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleHeadClause; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleHeadClause"


    // $ANTLR start "ruleHeadClause"
    // InternalSM2.g:2443:1: ruleHeadClause returns [EObject current=null] : (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) ;
    public final EObject ruleHeadClause() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameFunction_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Enumerator lv_visibilityAccess_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2449:2: ( (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2450:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2450:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2451:3: otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS
            {
            otherlv_0=(Token)match(input,59,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getHeadClauseAccess().getFunctionKeyword_0());
              		
            }
            // InternalSM2.g:2455:3: ( (lv_nameFunction_1_0= RULE_ID ) )
            // InternalSM2.g:2456:4: (lv_nameFunction_1_0= RULE_ID )
            {
            // InternalSM2.g:2456:4: (lv_nameFunction_1_0= RULE_ID )
            // InternalSM2.g:2457:5: lv_nameFunction_1_0= RULE_ID
            {
            lv_nameFunction_1_0=(Token)match(input,RULE_ID,FOLLOW_28); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameFunction_1_0, grammarAccess.getHeadClauseAccess().getNameFunctionIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getHeadClauseRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameFunction",
              						lv_nameFunction_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_40); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getHeadClauseAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2477:3: ( (otherlv_3= RULE_ID ) )*
            loop64:
            do {
                int alt64=2;
                int LA64_0 = input.LA(1);

                if ( (LA64_0==RULE_ID) ) {
                    alt64=1;
                }


                switch (alt64) {
            	case 1 :
            	    // InternalSM2.g:2478:4: (otherlv_3= RULE_ID )
            	    {
            	    // InternalSM2.g:2478:4: (otherlv_3= RULE_ID )
            	    // InternalSM2.g:2479:5: otherlv_3= RULE_ID
            	    {
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElement(grammarAccess.getHeadClauseRule());
            	      					}
            	      				
            	    }
            	    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_40); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_3, grammarAccess.getHeadClauseAccess().getInputParamsInputParamCrossReference_3_0());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop64;
                }
            } while (true);

            // InternalSM2.g:2490:3: ( (lv_visibilityAccess_4_0= ruleVisibility ) )
            // InternalSM2.g:2491:4: (lv_visibilityAccess_4_0= ruleVisibility )
            {
            // InternalSM2.g:2491:4: (lv_visibilityAccess_4_0= ruleVisibility )
            // InternalSM2.g:2492:5: lv_visibilityAccess_4_0= ruleVisibility
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getHeadClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_66);
            lv_visibilityAccess_4_0=ruleVisibility();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getHeadClauseRule());
              					}
              					set(
              						current,
              						"visibilityAccess",
              						lv_visibilityAccess_4_0,
              						"org.xtext.SM2.Visibility");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2509:3: ( (otherlv_5= RULE_ID ) )?
            int alt65=2;
            int LA65_0 = input.LA(1);

            if ( (LA65_0==RULE_ID) ) {
                alt65=1;
            }
            switch (alt65) {
                case 1 :
                    // InternalSM2.g:2510:4: (otherlv_5= RULE_ID )
                    {
                    // InternalSM2.g:2510:4: (otherlv_5= RULE_ID )
                    // InternalSM2.g:2511:5: otherlv_5= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getHeadClauseRule());
                      					}
                      				
                    }
                    otherlv_5=(Token)match(input,RULE_ID,FOLLOW_30); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_5, grammarAccess.getHeadClauseAccess().getModifierModifierCrossReference_5_0());
                      				
                    }

                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getHeadClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleHeadClause"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:2530:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // InternalSM2.g:2530:51: (iv_ruleExpression= ruleExpression EOF )
            // InternalSM2.g:2531:2: iv_ruleExpression= ruleExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:2537:1: ruleExpression returns [EObject current=null] : (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression ) ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_ArithmethicalExpression_0 = null;

        EObject this_ArithmethicalLogicalExpression_1 = null;

        EObject this_SyntaxExpression_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:2543:2: ( (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression ) )
            // InternalSM2.g:2544:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression )
            {
            // InternalSM2.g:2544:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression )
            int alt66=3;
            alt66 = dfa66.predict(input);
            switch (alt66) {
                case 1 :
                    // InternalSM2.g:2545:3: this_ArithmethicalExpression_0= ruleArithmethicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalExpression_0=ruleArithmethicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ArithmethicalExpression_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2554:3: this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalLogicalExpressionParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalLogicalExpression_1=ruleArithmethicalLogicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ArithmethicalLogicalExpression_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2563:3: this_SyntaxExpression_2= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_SyntaxExpression_2=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_SyntaxExpression_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleArithmethicalExpression"
    // InternalSM2.g:2575:1: entryRuleArithmethicalExpression returns [EObject current=null] : iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF ;
    public final EObject entryRuleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalExpression = null;


        try {
            // InternalSM2.g:2575:64: (iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF )
            // InternalSM2.g:2576:2: iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmethicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalExpression=ruleArithmethicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArithmethicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalExpression"


    // $ANTLR start "ruleArithmethicalExpression"
    // InternalSM2.g:2582:1: ruleArithmethicalExpression returns [EObject current=null] : ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INTEGER ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INTEGER ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= RULE_INTEGER ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INTEGER ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) ) ;
    public final EObject ruleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token lv_op1_1_0=null;
        Token lv_op2_3_0=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token lv_op1_5_0=null;
        Token lv_op2_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Enumerator lv_operator_2_0 = null;

        Enumerator lv_operator_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2588:2: ( ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INTEGER ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INTEGER ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= RULE_INTEGER ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INTEGER ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) ) )
            // InternalSM2.g:2589:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INTEGER ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INTEGER ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= RULE_INTEGER ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INTEGER ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:2589:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INTEGER ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INTEGER ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= RULE_INTEGER ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INTEGER ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) )
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==RULE_OPENPARENTHESIS) ) {
                alt68=1;
            }
            else if ( (LA68_0==RULE_INTEGER) ) {
                alt68=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 68, 0, input);

                throw nvae;
            }
            switch (alt68) {
                case 1 :
                    // InternalSM2.g:2590:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INTEGER ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INTEGER ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:2590:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INTEGER ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INTEGER ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:2591:4: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INTEGER ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INTEGER ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                    {
                    this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_67); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0());
                      			
                    }
                    // InternalSM2.g:2595:4: ( (lv_op1_1_0= RULE_INTEGER ) )
                    // InternalSM2.g:2596:5: (lv_op1_1_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:2596:5: (lv_op1_1_0= RULE_INTEGER )
                    // InternalSM2.g:2597:6: lv_op1_1_0= RULE_INTEGER
                    {
                    lv_op1_1_0=(Token)match(input,RULE_INTEGER,FOLLOW_68); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op1_1_0, grammarAccess.getArithmethicalExpressionAccess().getOp1INTEGERTerminalRuleCall_0_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op1",
                      							lv_op1_1_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2613:4: ( (lv_operator_2_0= ruleArithmeticalOperator ) )
                    // InternalSM2.g:2614:5: (lv_operator_2_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2.g:2614:5: (lv_operator_2_0= ruleArithmeticalOperator )
                    // InternalSM2.g:2615:6: lv_operator_2_0= ruleArithmeticalOperator
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0());
                      					
                    }
                    pushFollow(FOLLOW_67);
                    lv_operator_2_0=ruleArithmeticalOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"operator",
                      							lv_operator_2_0,
                      							"org.xtext.SM2.ArithmeticalOperator");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2632:4: ( (lv_op2_3_0= RULE_INTEGER ) )
                    // InternalSM2.g:2633:5: (lv_op2_3_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:2633:5: (lv_op2_3_0= RULE_INTEGER )
                    // InternalSM2.g:2634:6: lv_op2_3_0= RULE_INTEGER
                    {
                    lv_op2_3_0=(Token)match(input,RULE_INTEGER,FOLLOW_30); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op2_3_0, grammarAccess.getArithmethicalExpressionAccess().getOp2INTEGERTerminalRuleCall_0_3_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op2",
                      							lv_op2_3_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }

                    this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2656:3: ( ( (lv_op1_5_0= RULE_INTEGER ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INTEGER ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:2656:3: ( ( (lv_op1_5_0= RULE_INTEGER ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INTEGER ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? )
                    // InternalSM2.g:2657:4: ( (lv_op1_5_0= RULE_INTEGER ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INTEGER ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )?
                    {
                    // InternalSM2.g:2657:4: ( (lv_op1_5_0= RULE_INTEGER ) )
                    // InternalSM2.g:2658:5: (lv_op1_5_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:2658:5: (lv_op1_5_0= RULE_INTEGER )
                    // InternalSM2.g:2659:6: lv_op1_5_0= RULE_INTEGER
                    {
                    lv_op1_5_0=(Token)match(input,RULE_INTEGER,FOLLOW_68); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op1_5_0, grammarAccess.getArithmethicalExpressionAccess().getOp1INTEGERTerminalRuleCall_1_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op1",
                      							lv_op1_5_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2675:4: ( (lv_operator_6_0= ruleArithmeticalOperator ) )
                    // InternalSM2.g:2676:5: (lv_operator_6_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2.g:2676:5: (lv_operator_6_0= ruleArithmeticalOperator )
                    // InternalSM2.g:2677:6: lv_operator_6_0= ruleArithmeticalOperator
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_67);
                    lv_operator_6_0=ruleArithmeticalOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"operator",
                      							lv_operator_6_0,
                      							"org.xtext.SM2.ArithmeticalOperator");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2694:4: ( (lv_op2_7_0= RULE_INTEGER ) )
                    // InternalSM2.g:2695:5: (lv_op2_7_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:2695:5: (lv_op2_7_0= RULE_INTEGER )
                    // InternalSM2.g:2696:6: lv_op2_7_0= RULE_INTEGER
                    {
                    lv_op2_7_0=(Token)match(input,RULE_INTEGER,FOLLOW_69); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op2_7_0, grammarAccess.getArithmethicalExpressionAccess().getOp2INTEGERTerminalRuleCall_1_2_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op2",
                      							lv_op2_7_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2712:4: (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )?
                    int alt67=2;
                    int LA67_0 = input.LA(1);

                    if ( (LA67_0==RULE_SEMICOLON) ) {
                        alt67=1;
                    }
                    switch (alt67) {
                        case 1 :
                            // InternalSM2.g:2713:5: this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE
                            {
                            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_8, grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0());
                              				
                            }
                            this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_9, grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalExpression"


    // $ANTLR start "entryRuleArithmethicalLogicalExpression"
    // InternalSM2.g:2727:1: entryRuleArithmethicalLogicalExpression returns [EObject current=null] : iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF ;
    public final EObject entryRuleArithmethicalLogicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalLogicalExpression = null;


        try {
            // InternalSM2.g:2727:71: (iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF )
            // InternalSM2.g:2728:2: iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalLogicalExpression=ruleArithmethicalLogicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArithmethicalLogicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalLogicalExpression"


    // $ANTLR start "ruleArithmethicalLogicalExpression"
    // InternalSM2.g:2734:1: ruleArithmethicalLogicalExpression returns [EObject current=null] : (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INTEGER ) ) ( (lv_operator1_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INTEGER ) ) ( (lv_operator2_4_0= ruleComparationOperator ) ) ( ( (lv_expr_5_0= ruleArithmethicalExpression ) ) | this_INTEGER_6= RULE_INTEGER ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) ;
    public final EObject ruleArithmethicalLogicalExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token lv_op1_1_0=null;
        Token lv_op2_3_0=null;
        Token this_INTEGER_6=null;
        Token this_CLOSEPARENTHESIS_7=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Enumerator lv_operator1_2_0 = null;

        Enumerator lv_operator2_4_0 = null;

        EObject lv_expr_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2740:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INTEGER ) ) ( (lv_operator1_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INTEGER ) ) ( (lv_operator2_4_0= ruleComparationOperator ) ) ( ( (lv_expr_5_0= ruleArithmethicalExpression ) ) | this_INTEGER_6= RULE_INTEGER ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) )
            // InternalSM2.g:2741:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INTEGER ) ) ( (lv_operator1_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INTEGER ) ) ( (lv_operator2_4_0= ruleComparationOperator ) ) ( ( (lv_expr_5_0= ruleArithmethicalExpression ) ) | this_INTEGER_6= RULE_INTEGER ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? )
            {
            // InternalSM2.g:2741:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INTEGER ) ) ( (lv_operator1_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INTEGER ) ) ( (lv_operator2_4_0= ruleComparationOperator ) ) ( ( (lv_expr_5_0= ruleArithmethicalExpression ) ) | this_INTEGER_6= RULE_INTEGER ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? )
            // InternalSM2.g:2742:3: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INTEGER ) ) ( (lv_operator1_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INTEGER ) ) ( (lv_operator2_4_0= ruleComparationOperator ) ) ( ( (lv_expr_5_0= ruleArithmethicalExpression ) ) | this_INTEGER_6= RULE_INTEGER ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )?
            {
            this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_67); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0());
              		
            }
            // InternalSM2.g:2746:3: ( (lv_op1_1_0= RULE_INTEGER ) )
            // InternalSM2.g:2747:4: (lv_op1_1_0= RULE_INTEGER )
            {
            // InternalSM2.g:2747:4: (lv_op1_1_0= RULE_INTEGER )
            // InternalSM2.g:2748:5: lv_op1_1_0= RULE_INTEGER
            {
            lv_op1_1_0=(Token)match(input,RULE_INTEGER,FOLLOW_68); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_op1_1_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOp1INTEGERTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					setWithLastConsumed(
              						current,
              						"op1",
              						lv_op1_1_0,
              						"org.xtext.SM2.INTEGER");
              				
            }

            }


            }

            // InternalSM2.g:2764:3: ( (lv_operator1_2_0= ruleArithmeticalOperator ) )
            // InternalSM2.g:2765:4: (lv_operator1_2_0= ruleArithmeticalOperator )
            {
            // InternalSM2.g:2765:4: (lv_operator1_2_0= ruleArithmeticalOperator )
            // InternalSM2.g:2766:5: lv_operator1_2_0= ruleArithmeticalOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator1ArithmeticalOperatorEnumRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_67);
            lv_operator1_2_0=ruleArithmeticalOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"operator1",
              						lv_operator1_2_0,
              						"org.xtext.SM2.ArithmeticalOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2783:3: ( (lv_op2_3_0= RULE_INTEGER ) )
            // InternalSM2.g:2784:4: (lv_op2_3_0= RULE_INTEGER )
            {
            // InternalSM2.g:2784:4: (lv_op2_3_0= RULE_INTEGER )
            // InternalSM2.g:2785:5: lv_op2_3_0= RULE_INTEGER
            {
            lv_op2_3_0=(Token)match(input,RULE_INTEGER,FOLLOW_61); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_op2_3_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOp2INTEGERTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					setWithLastConsumed(
              						current,
              						"op2",
              						lv_op2_3_0,
              						"org.xtext.SM2.INTEGER");
              				
            }

            }


            }

            // InternalSM2.g:2801:3: ( (lv_operator2_4_0= ruleComparationOperator ) )
            // InternalSM2.g:2802:4: (lv_operator2_4_0= ruleComparationOperator )
            {
            // InternalSM2.g:2802:4: (lv_operator2_4_0= ruleComparationOperator )
            // InternalSM2.g:2803:5: lv_operator2_4_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator2ComparationOperatorEnumRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_70);
            lv_operator2_4_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"operator2",
              						lv_operator2_4_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2820:3: ( ( (lv_expr_5_0= ruleArithmethicalExpression ) ) | this_INTEGER_6= RULE_INTEGER )
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==RULE_OPENPARENTHESIS) ) {
                alt69=1;
            }
            else if ( (LA69_0==RULE_INTEGER) ) {
                int LA69_2 = input.LA(2);

                if ( ((LA69_2>=83 && LA69_2<=86)) ) {
                    alt69=1;
                }
                else if ( (LA69_2==RULE_CLOSEPARENTHESIS) ) {
                    alt69=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 69, 2, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 69, 0, input);

                throw nvae;
            }
            switch (alt69) {
                case 1 :
                    // InternalSM2.g:2821:4: ( (lv_expr_5_0= ruleArithmethicalExpression ) )
                    {
                    // InternalSM2.g:2821:4: ( (lv_expr_5_0= ruleArithmethicalExpression ) )
                    // InternalSM2.g:2822:5: (lv_expr_5_0= ruleArithmethicalExpression )
                    {
                    // InternalSM2.g:2822:5: (lv_expr_5_0= ruleArithmethicalExpression )
                    // InternalSM2.g:2823:6: lv_expr_5_0= ruleArithmethicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getExprArithmethicalExpressionParserRuleCall_5_0_0());
                      					
                    }
                    pushFollow(FOLLOW_30);
                    lv_expr_5_0=ruleArithmethicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"expr",
                      							lv_expr_5_0,
                      							"org.xtext.SM2.ArithmethicalExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2841:4: this_INTEGER_6= RULE_INTEGER
                    {
                    this_INTEGER_6=(Token)match(input,RULE_INTEGER,FOLLOW_30); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_INTEGER_6, grammarAccess.getArithmethicalLogicalExpressionAccess().getINTEGERTerminalRuleCall_5_1());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEPARENTHESIS_7=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_69); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_7, grammarAccess.getArithmethicalLogicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:2850:3: (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )?
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( (LA70_0==RULE_SEMICOLON) ) {
                alt70=1;
            }
            switch (alt70) {
                case 1 :
                    // InternalSM2.g:2851:4: this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE
                    {
                    this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_8, grammarAccess.getArithmethicalLogicalExpressionAccess().getSEMICOLONTerminalRuleCall_7_0());
                      			
                    }
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getArithmethicalLogicalExpressionAccess().getEOLINETerminalRuleCall_7_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalLogicalExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:2864:1: entryRuleSyntaxExpression returns [EObject current=null] : iv_ruleSyntaxExpression= ruleSyntaxExpression EOF ;
    public final EObject entryRuleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSyntaxExpression = null;


        try {
            // InternalSM2.g:2864:57: (iv_ruleSyntaxExpression= ruleSyntaxExpression EOF )
            // InternalSM2.g:2865:2: iv_ruleSyntaxExpression= ruleSyntaxExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSyntaxExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSyntaxExpression=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSyntaxExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:2871:1: ruleSyntaxExpression returns [EObject current=null] : ( ( (lv_text_0_0= RULE_STRING ) ) | (this_INTEGER_1= RULE_INTEGER (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) ) ;
    public final EObject ruleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        Token lv_text_0_0=null;
        Token this_INTEGER_1=null;
        Token this_SEMICOLON_2=null;
        Token this_EOLINE_3=null;


        	enterRule();

        try {
            // InternalSM2.g:2877:2: ( ( ( (lv_text_0_0= RULE_STRING ) ) | (this_INTEGER_1= RULE_INTEGER (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) ) )
            // InternalSM2.g:2878:2: ( ( (lv_text_0_0= RULE_STRING ) ) | (this_INTEGER_1= RULE_INTEGER (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:2878:2: ( ( (lv_text_0_0= RULE_STRING ) ) | (this_INTEGER_1= RULE_INTEGER (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) )
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==RULE_STRING) ) {
                alt72=1;
            }
            else if ( (LA72_0==RULE_INTEGER) ) {
                alt72=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 72, 0, input);

                throw nvae;
            }
            switch (alt72) {
                case 1 :
                    // InternalSM2.g:2879:3: ( (lv_text_0_0= RULE_STRING ) )
                    {
                    // InternalSM2.g:2879:3: ( (lv_text_0_0= RULE_STRING ) )
                    // InternalSM2.g:2880:4: (lv_text_0_0= RULE_STRING )
                    {
                    // InternalSM2.g:2880:4: (lv_text_0_0= RULE_STRING )
                    // InternalSM2.g:2881:5: lv_text_0_0= RULE_STRING
                    {
                    lv_text_0_0=(Token)match(input,RULE_STRING,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_text_0_0, grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getSyntaxExpressionRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"text",
                      						lv_text_0_0,
                      						"org.eclipse.xtext.common.Terminals.STRING");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2898:3: (this_INTEGER_1= RULE_INTEGER (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:2898:3: (this_INTEGER_1= RULE_INTEGER (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
                    // InternalSM2.g:2899:4: this_INTEGER_1= RULE_INTEGER (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
                    {
                    this_INTEGER_1=(Token)match(input,RULE_INTEGER,FOLLOW_69); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_INTEGER_1, grammarAccess.getSyntaxExpressionAccess().getINTEGERTerminalRuleCall_1_0());
                      			
                    }
                    // InternalSM2.g:2903:4: (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
                    int alt71=2;
                    int LA71_0 = input.LA(1);

                    if ( (LA71_0==RULE_SEMICOLON) ) {
                        alt71=1;
                    }
                    switch (alt71) {
                        case 1 :
                            // InternalSM2.g:2904:5: this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE
                            {
                            this_SEMICOLON_2=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_2, grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0());
                              				
                            }
                            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_3, grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:2918:1: entryRuleComment returns [EObject current=null] : iv_ruleComment= ruleComment EOF ;
    public final EObject entryRuleComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleComment = null;


        try {
            // InternalSM2.g:2918:48: (iv_ruleComment= ruleComment EOF )
            // InternalSM2.g:2919:2: iv_ruleComment= ruleComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleComment=ruleComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:2925:1: ruleComment returns [EObject current=null] : (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) ;
    public final EObject ruleComment() throws RecognitionException {
        EObject current = null;

        EObject this_ShortComment_0 = null;

        EObject this_LongComment_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:2931:2: ( (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) )
            // InternalSM2.g:2932:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            {
            // InternalSM2.g:2932:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==60) ) {
                alt73=1;
            }
            else if ( (LA73_0==61) ) {
                alt73=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 73, 0, input);

                throw nvae;
            }
            switch (alt73) {
                case 1 :
                    // InternalSM2.g:2933:3: this_ShortComment_0= ruleShortComment
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ShortComment_0=ruleShortComment();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ShortComment_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2942:3: this_LongComment_1= ruleLongComment
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_LongComment_1=ruleLongComment();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_LongComment_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:2954:1: entryRuleShortComment returns [EObject current=null] : iv_ruleShortComment= ruleShortComment EOF ;
    public final EObject entryRuleShortComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleShortComment = null;


        try {
            // InternalSM2.g:2954:53: (iv_ruleShortComment= ruleShortComment EOF )
            // InternalSM2.g:2955:2: iv_ruleShortComment= ruleShortComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getShortCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleShortComment=ruleShortComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleShortComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:2961:1: ruleShortComment returns [EObject current=null] : (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) ) ;
    public final EObject ruleShortComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expr_1_0=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:2967:2: ( (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) ) )
            // InternalSM2.g:2968:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) )
            {
            // InternalSM2.g:2968:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) )
            // InternalSM2.g:2969:3: otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE )
            {
            otherlv_0=(Token)match(input,60,FOLLOW_35); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0());
              		
            }
            // InternalSM2.g:2973:3: ( (lv_expr_1_0= RULE_STRING ) )
            // InternalSM2.g:2974:4: (lv_expr_1_0= RULE_STRING )
            {
            // InternalSM2.g:2974:4: (lv_expr_1_0= RULE_STRING )
            // InternalSM2.g:2975:5: lv_expr_1_0= RULE_STRING
            {
            lv_expr_1_0=(Token)match(input,RULE_STRING,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr_1_0, grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getShortCommentRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr",
              						lv_expr_1_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2991:3: ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE )
            // InternalSM2.g:2992:4: ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE
            {
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(this_EOLINE_2, grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:3002:1: entryRuleLongComment returns [EObject current=null] : iv_ruleLongComment= ruleLongComment EOF ;
    public final EObject entryRuleLongComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLongComment = null;


        try {
            // InternalSM2.g:3002:52: (iv_ruleLongComment= ruleLongComment EOF )
            // InternalSM2.g:3003:2: iv_ruleLongComment= ruleLongComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLongCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLongComment=ruleLongComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLongComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:3009:1: ruleLongComment returns [EObject current=null] : (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' ) ) ;
    public final EObject ruleLongComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expression_1_1=null;
        Token lv_expression_1_2=null;
        Token lv_expression_1_3=null;
        Token lv_expression_1_4=null;
        Token lv_expression_1_5=null;
        Token lv_expression_1_6=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSM2.g:3015:2: ( (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' ) ) )
            // InternalSM2.g:3016:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' ) )
            {
            // InternalSM2.g:3016:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' ) )
            // InternalSM2.g:3017:3: otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' )
            {
            otherlv_0=(Token)match(input,61,FOLLOW_71); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0());
              		
            }
            // InternalSM2.g:3021:3: ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )
            // InternalSM2.g:3022:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
            {
            // InternalSM2.g:3022:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
            // InternalSM2.g:3023:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
            {
            // InternalSM2.g:3023:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
            int alt74=6;
            switch ( input.LA(1) ) {
            case RULE_STRING:
                {
                alt74=1;
                }
                break;
            case RULE_PARAMSLONGCOMENT:
                {
                alt74=2;
                }
                break;
            case RULE_DEVLONGCOMENT:
                {
                alt74=3;
                }
                break;
            case RULE_RETURNSLONGCOMENT:
                {
                alt74=4;
                }
                break;
            case RULE_TITLELONGCOMENT:
                {
                alt74=5;
                }
                break;
            case RULE_NOTICELONGCOMENT:
                {
                alt74=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 74, 0, input);

                throw nvae;
            }

            switch (alt74) {
                case 1 :
                    // InternalSM2.g:3024:6: lv_expression_1_1= RULE_STRING
                    {
                    lv_expression_1_1=(Token)match(input,RULE_STRING,FOLLOW_72); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_1, grammarAccess.getLongCommentAccess().getExpressionSTRINGTerminalRuleCall_1_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_1,
                      							"org.eclipse.xtext.common.Terminals.STRING");
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3039:6: lv_expression_1_2= RULE_PARAMSLONGCOMENT
                    {
                    lv_expression_1_2=(Token)match(input,RULE_PARAMSLONGCOMENT,FOLLOW_72); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_2, grammarAccess.getLongCommentAccess().getExpressionPARAMSLONGCOMENTTerminalRuleCall_1_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_2,
                      							"org.xtext.SM2.PARAMSLONGCOMENT");
                      					
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:3054:6: lv_expression_1_3= RULE_DEVLONGCOMENT
                    {
                    lv_expression_1_3=(Token)match(input,RULE_DEVLONGCOMENT,FOLLOW_72); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_3, grammarAccess.getLongCommentAccess().getExpressionDEVLONGCOMENTTerminalRuleCall_1_0_2());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_3,
                      							"org.xtext.SM2.DEVLONGCOMENT");
                      					
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:3069:6: lv_expression_1_4= RULE_RETURNSLONGCOMENT
                    {
                    lv_expression_1_4=(Token)match(input,RULE_RETURNSLONGCOMENT,FOLLOW_72); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_4, grammarAccess.getLongCommentAccess().getExpressionRETURNSLONGCOMENTTerminalRuleCall_1_0_3());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_4,
                      							"org.xtext.SM2.RETURNSLONGCOMENT");
                      					
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:3084:6: lv_expression_1_5= RULE_TITLELONGCOMENT
                    {
                    lv_expression_1_5=(Token)match(input,RULE_TITLELONGCOMENT,FOLLOW_72); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_5, grammarAccess.getLongCommentAccess().getExpressionTITLELONGCOMENTTerminalRuleCall_1_0_4());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_5,
                      							"org.xtext.SM2.TITLELONGCOMENT");
                      					
                    }

                    }
                    break;
                case 6 :
                    // InternalSM2.g:3099:6: lv_expression_1_6= RULE_NOTICELONGCOMENT
                    {
                    lv_expression_1_6=(Token)match(input,RULE_NOTICELONGCOMENT,FOLLOW_72); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_6, grammarAccess.getLongCommentAccess().getExpressionNOTICELONGCOMENTTerminalRuleCall_1_0_5());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_6,
                      							"org.xtext.SM2.NOTICELONGCOMENT");
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:3116:3: ( ( '*/' )=>otherlv_2= '*/' )
            // InternalSM2.g:3117:4: ( '*/' )=>otherlv_2= '*/'
            {
            otherlv_2=(Token)match(input,62,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_2, grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "ruleSingularType"
    // InternalSM2.g:3127:1: ruleSingularType returns [Enumerator current=null] : ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) ) ;
    public final Enumerator ruleSingularType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;
        Token enumLiteral_8=null;
        Token enumLiteral_9=null;
        Token enumLiteral_10=null;


        	enterRule();

        try {
            // InternalSM2.g:3133:2: ( ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) ) )
            // InternalSM2.g:3134:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) )
            {
            // InternalSM2.g:3134:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) )
            int alt75=11;
            switch ( input.LA(1) ) {
            case 63:
                {
                alt75=1;
                }
                break;
            case 52:
                {
                alt75=2;
                }
                break;
            case 64:
                {
                alt75=3;
                }
                break;
            case 65:
                {
                alt75=4;
                }
                break;
            case 51:
                {
                alt75=5;
                }
                break;
            case 50:
                {
                alt75=6;
                }
                break;
            case 66:
                {
                alt75=7;
                }
                break;
            case 67:
                {
                alt75=8;
                }
                break;
            case 68:
                {
                alt75=9;
                }
                break;
            case 69:
                {
                alt75=10;
                }
                break;
            case 70:
                {
                alt75=11;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 75, 0, input);

                throw nvae;
            }

            switch (alt75) {
                case 1 :
                    // InternalSM2.g:3135:3: (enumLiteral_0= 'int' )
                    {
                    // InternalSM2.g:3135:3: (enumLiteral_0= 'int' )
                    // InternalSM2.g:3136:4: enumLiteral_0= 'int'
                    {
                    enumLiteral_0=(Token)match(input,63,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3143:3: (enumLiteral_1= 'uint' )
                    {
                    // InternalSM2.g:3143:3: (enumLiteral_1= 'uint' )
                    // InternalSM2.g:3144:4: enumLiteral_1= 'uint'
                    {
                    enumLiteral_1=(Token)match(input,52,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3151:3: (enumLiteral_2= 'uint8' )
                    {
                    // InternalSM2.g:3151:3: (enumLiteral_2= 'uint8' )
                    // InternalSM2.g:3152:4: enumLiteral_2= 'uint8'
                    {
                    enumLiteral_2=(Token)match(input,64,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:3159:3: (enumLiteral_3= 'uint256' )
                    {
                    // InternalSM2.g:3159:3: (enumLiteral_3= 'uint256' )
                    // InternalSM2.g:3160:4: enumLiteral_3= 'uint256'
                    {
                    enumLiteral_3=(Token)match(input,65,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:3167:3: (enumLiteral_4= 'string' )
                    {
                    // InternalSM2.g:3167:3: (enumLiteral_4= 'string' )
                    // InternalSM2.g:3168:4: enumLiteral_4= 'string'
                    {
                    enumLiteral_4=(Token)match(input,51,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:3175:3: (enumLiteral_5= 'address' )
                    {
                    // InternalSM2.g:3175:3: (enumLiteral_5= 'address' )
                    // InternalSM2.g:3176:4: enumLiteral_5= 'address'
                    {
                    enumLiteral_5=(Token)match(input,50,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:3183:3: (enumLiteral_6= 'address payable' )
                    {
                    // InternalSM2.g:3183:3: (enumLiteral_6= 'address payable' )
                    // InternalSM2.g:3184:4: enumLiteral_6= 'address payable'
                    {
                    enumLiteral_6=(Token)match(input,66,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_6, grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6());
                      			
                    }

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:3191:3: (enumLiteral_7= 'double' )
                    {
                    // InternalSM2.g:3191:3: (enumLiteral_7= 'double' )
                    // InternalSM2.g:3192:4: enumLiteral_7= 'double'
                    {
                    enumLiteral_7=(Token)match(input,67,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_7, grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7());
                      			
                    }

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:3199:3: (enumLiteral_8= 'bool' )
                    {
                    // InternalSM2.g:3199:3: (enumLiteral_8= 'bool' )
                    // InternalSM2.g:3200:4: enumLiteral_8= 'bool'
                    {
                    enumLiteral_8=(Token)match(input,68,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_8, grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8());
                      			
                    }

                    }


                    }
                    break;
                case 10 :
                    // InternalSM2.g:3207:3: (enumLiteral_9= 'byte' )
                    {
                    // InternalSM2.g:3207:3: (enumLiteral_9= 'byte' )
                    // InternalSM2.g:3208:4: enumLiteral_9= 'byte'
                    {
                    enumLiteral_9=(Token)match(input,69,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getBYTEEnumLiteralDeclaration_9().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_9, grammarAccess.getSingularTypeAccess().getBYTEEnumLiteralDeclaration_9());
                      			
                    }

                    }


                    }
                    break;
                case 11 :
                    // InternalSM2.g:3215:3: (enumLiteral_10= 'bytes32' )
                    {
                    // InternalSM2.g:3215:3: (enumLiteral_10= 'bytes32' )
                    // InternalSM2.g:3216:4: enumLiteral_10= 'bytes32'
                    {
                    enumLiteral_10=(Token)match(input,70,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getBYTE32EnumLiteralDeclaration_10().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_10, grammarAccess.getSingularTypeAccess().getBYTE32EnumLiteralDeclaration_10());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:3226:1: ruleVisibility returns [Enumerator current=null] : ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) ;
    public final Enumerator ruleVisibility() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalSM2.g:3232:2: ( ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) )
            // InternalSM2.g:3233:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            {
            // InternalSM2.g:3233:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            int alt76=4;
            switch ( input.LA(1) ) {
            case 41:
                {
                alt76=1;
                }
                break;
            case 71:
                {
                alt76=2;
                }
                break;
            case 42:
                {
                alt76=3;
                }
                break;
            case 72:
                {
                alt76=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 76, 0, input);

                throw nvae;
            }

            switch (alt76) {
                case 1 :
                    // InternalSM2.g:3234:3: (enumLiteral_0= 'public' )
                    {
                    // InternalSM2.g:3234:3: (enumLiteral_0= 'public' )
                    // InternalSM2.g:3235:4: enumLiteral_0= 'public'
                    {
                    enumLiteral_0=(Token)match(input,41,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3242:3: (enumLiteral_1= 'private' )
                    {
                    // InternalSM2.g:3242:3: (enumLiteral_1= 'private' )
                    // InternalSM2.g:3243:4: enumLiteral_1= 'private'
                    {
                    enumLiteral_1=(Token)match(input,71,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3250:3: (enumLiteral_2= 'internal' )
                    {
                    // InternalSM2.g:3250:3: (enumLiteral_2= 'internal' )
                    // InternalSM2.g:3251:4: enumLiteral_2= 'internal'
                    {
                    enumLiteral_2=(Token)match(input,42,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:3258:3: (enumLiteral_3= 'external' )
                    {
                    // InternalSM2.g:3258:3: (enumLiteral_3= 'external' )
                    // InternalSM2.g:3259:4: enumLiteral_3= 'external'
                    {
                    enumLiteral_3=(Token)match(input,72,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:3269:1: ruleCoin returns [Enumerator current=null] : ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) ;
    public final Enumerator ruleCoin() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:3275:2: ( ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) )
            // InternalSM2.g:3276:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            {
            // InternalSM2.g:3276:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            int alt77=6;
            switch ( input.LA(1) ) {
            case 73:
                {
                alt77=1;
                }
                break;
            case 74:
                {
                alt77=2;
                }
                break;
            case 75:
                {
                alt77=3;
                }
                break;
            case 76:
                {
                alt77=4;
                }
                break;
            case 77:
                {
                alt77=5;
                }
                break;
            case 78:
                {
                alt77=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 77, 0, input);

                throw nvae;
            }

            switch (alt77) {
                case 1 :
                    // InternalSM2.g:3277:3: (enumLiteral_0= 'ether' )
                    {
                    // InternalSM2.g:3277:3: (enumLiteral_0= 'ether' )
                    // InternalSM2.g:3278:4: enumLiteral_0= 'ether'
                    {
                    enumLiteral_0=(Token)match(input,73,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3285:3: (enumLiteral_1= 'wei' )
                    {
                    // InternalSM2.g:3285:3: (enumLiteral_1= 'wei' )
                    // InternalSM2.g:3286:4: enumLiteral_1= 'wei'
                    {
                    enumLiteral_1=(Token)match(input,74,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3293:3: (enumLiteral_2= 'gwei' )
                    {
                    // InternalSM2.g:3293:3: (enumLiteral_2= 'gwei' )
                    // InternalSM2.g:3294:4: enumLiteral_2= 'gwei'
                    {
                    enumLiteral_2=(Token)match(input,75,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:3301:3: (enumLiteral_3= 'pwei' )
                    {
                    // InternalSM2.g:3301:3: (enumLiteral_3= 'pwei' )
                    // InternalSM2.g:3302:4: enumLiteral_3= 'pwei'
                    {
                    enumLiteral_3=(Token)match(input,76,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:3309:3: (enumLiteral_4= 'finney' )
                    {
                    // InternalSM2.g:3309:3: (enumLiteral_4= 'finney' )
                    // InternalSM2.g:3310:4: enumLiteral_4= 'finney'
                    {
                    enumLiteral_4=(Token)match(input,77,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:3317:3: (enumLiteral_5= 'szabo' )
                    {
                    // InternalSM2.g:3317:3: (enumLiteral_5= 'szabo' )
                    // InternalSM2.g:3318:4: enumLiteral_5= 'szabo'
                    {
                    enumLiteral_5=(Token)match(input,78,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:3328:1: ruleComparationOperator returns [Enumerator current=null] : ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) ;
    public final Enumerator ruleComparationOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:3334:2: ( ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) )
            // InternalSM2.g:3335:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            {
            // InternalSM2.g:3335:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            int alt78=6;
            switch ( input.LA(1) ) {
            case 33:
                {
                alt78=1;
                }
                break;
            case 35:
                {
                alt78=2;
                }
                break;
            case 34:
                {
                alt78=3;
                }
                break;
            case 36:
                {
                alt78=4;
                }
                break;
            case 79:
                {
                alt78=5;
                }
                break;
            case 80:
                {
                alt78=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 78, 0, input);

                throw nvae;
            }

            switch (alt78) {
                case 1 :
                    // InternalSM2.g:3336:3: (enumLiteral_0= '>' )
                    {
                    // InternalSM2.g:3336:3: (enumLiteral_0= '>' )
                    // InternalSM2.g:3337:4: enumLiteral_0= '>'
                    {
                    enumLiteral_0=(Token)match(input,33,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3344:3: (enumLiteral_1= '<' )
                    {
                    // InternalSM2.g:3344:3: (enumLiteral_1= '<' )
                    // InternalSM2.g:3345:4: enumLiteral_1= '<'
                    {
                    enumLiteral_1=(Token)match(input,35,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3352:3: (enumLiteral_2= '>=' )
                    {
                    // InternalSM2.g:3352:3: (enumLiteral_2= '>=' )
                    // InternalSM2.g:3353:4: enumLiteral_2= '>='
                    {
                    enumLiteral_2=(Token)match(input,34,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:3360:3: (enumLiteral_3= '<=' )
                    {
                    // InternalSM2.g:3360:3: (enumLiteral_3= '<=' )
                    // InternalSM2.g:3361:4: enumLiteral_3= '<='
                    {
                    enumLiteral_3=(Token)match(input,36,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:3368:3: (enumLiteral_4= '==' )
                    {
                    // InternalSM2.g:3368:3: (enumLiteral_4= '==' )
                    // InternalSM2.g:3369:4: enumLiteral_4= '=='
                    {
                    enumLiteral_4=(Token)match(input,79,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:3376:3: (enumLiteral_5= '!=' )
                    {
                    // InternalSM2.g:3376:3: (enumLiteral_5= '!=' )
                    // InternalSM2.g:3377:4: enumLiteral_5= '!='
                    {
                    enumLiteral_5=(Token)match(input,80,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:3387:1: ruleLogicalPairOperator returns [Enumerator current=null] : ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) ;
    public final Enumerator ruleLogicalPairOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSM2.g:3393:2: ( ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) )
            // InternalSM2.g:3394:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            {
            // InternalSM2.g:3394:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            int alt79=2;
            int LA79_0 = input.LA(1);

            if ( (LA79_0==81) ) {
                alt79=1;
            }
            else if ( (LA79_0==82) ) {
                alt79=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 79, 0, input);

                throw nvae;
            }
            switch (alt79) {
                case 1 :
                    // InternalSM2.g:3395:3: (enumLiteral_0= '&&' )
                    {
                    // InternalSM2.g:3395:3: (enumLiteral_0= '&&' )
                    // InternalSM2.g:3396:4: enumLiteral_0= '&&'
                    {
                    enumLiteral_0=(Token)match(input,81,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3403:3: (enumLiteral_1= '||' )
                    {
                    // InternalSM2.g:3403:3: (enumLiteral_1= '||' )
                    // InternalSM2.g:3404:4: enumLiteral_1= '||'
                    {
                    enumLiteral_1=(Token)match(input,82,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:3414:1: ruleArithmeticalOperator returns [Enumerator current=null] : ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) ) ;
    public final Enumerator ruleArithmeticalOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalSM2.g:3420:2: ( ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) ) )
            // InternalSM2.g:3421:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) )
            {
            // InternalSM2.g:3421:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) )
            int alt80=4;
            switch ( input.LA(1) ) {
            case 83:
                {
                alt80=1;
                }
                break;
            case 84:
                {
                alt80=2;
                }
                break;
            case 85:
                {
                alt80=3;
                }
                break;
            case 86:
                {
                alt80=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 80, 0, input);

                throw nvae;
            }

            switch (alt80) {
                case 1 :
                    // InternalSM2.g:3422:3: (enumLiteral_0= '+' )
                    {
                    // InternalSM2.g:3422:3: (enumLiteral_0= '+' )
                    // InternalSM2.g:3423:4: enumLiteral_0= '+'
                    {
                    enumLiteral_0=(Token)match(input,83,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3430:3: (enumLiteral_1= '-' )
                    {
                    // InternalSM2.g:3430:3: (enumLiteral_1= '-' )
                    // InternalSM2.g:3431:4: enumLiteral_1= '-'
                    {
                    enumLiteral_1=(Token)match(input,84,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3438:3: (enumLiteral_2= '*' )
                    {
                    // InternalSM2.g:3438:3: (enumLiteral_2= '*' )
                    // InternalSM2.g:3439:4: enumLiteral_2= '*'
                    {
                    enumLiteral_2=(Token)match(input,85,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:3446:3: (enumLiteral_3= '/' )
                    {
                    // InternalSM2.g:3446:3: (enumLiteral_3= '/' )
                    // InternalSM2.g:3447:4: enumLiteral_3= '/'
                    {
                    enumLiteral_3=(Token)match(input,86,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmeticalOperator"

    // Delegated rules


    protected DFA33 dfa33 = new DFA33(this);
    protected DFA36 dfa36 = new DFA36(this);
    protected DFA48 dfa48 = new DFA48(this);
    protected DFA51 dfa51 = new DFA51(this);
    protected DFA59 dfa59 = new DFA59(this);
    protected DFA66 dfa66 = new DFA66(this);
    static final String dfa_1s = "\16\uffff";
    static final String dfa_2s = "\1\61\1\6\1\7\1\5\1\62\1\uffff\1\6\2\4\1\uffff\1\4\1\5\1\10\1\6";
    static final String dfa_3s = "\1\61\1\6\1\7\2\106\1\uffff\1\110\1\53\1\20\1\uffff\1\4\2\106\1\110";
    static final String dfa_4s = "\5\uffff\1\1\3\uffff\1\2\4\uffff";
    static final String dfa_5s = "\16\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\4\54\uffff\1\6\2\5\12\uffff\10\5",
            "\1\6\2\5\12\uffff\10\5",
            "",
            "\1\7\42\uffff\2\5\34\uffff\2\5",
            "\1\11\46\uffff\1\10",
            "\1\5\10\uffff\1\12\2\uffff\1\5",
            "",
            "\1\13",
            "\1\14\2\uffff\1\5\51\uffff\1\5\1\15\1\5\12\uffff\10\5",
            "\1\5\51\uffff\1\5\1\15\1\5\12\uffff\10\5",
            "\1\5\6\uffff\1\11\33\uffff\2\5\34\uffff\2\5"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA33 extends DFA {

        public DFA33(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 33;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "1393:4: (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser )";
        }
    }
    static final String dfa_7s = "\1\2\1\4\14\uffff";
    static final String dfa_8s = "\1\5\1\4\1\uffff\1\6\1\uffff\1\13\6\6\1\14\1\4";
    static final String dfa_9s = "\2\106\1\uffff\1\6\1\uffff\1\13\2\110\5\14\1\73";
    static final String dfa_10s = "\2\uffff\1\2\1\uffff\1\1\11\uffff";
    static final String[] dfa_11s = {
            "\1\1\1\2\1\uffff\1\2\2\uffff\1\2\1\uffff\1\2\2\uffff\1\2\27\uffff\1\2\3\uffff\2\2\1\uffff\1\2\1\uffff\4\2\1\uffff\1\2\4\uffff\3\2\1\uffff\10\2",
            "\1\2\2\4\1\uffff\1\4\2\uffff\1\4\1\uffff\1\4\2\uffff\1\4\27\uffff\1\4\3\uffff\2\4\1\uffff\1\4\1\uffff\4\4\1\uffff\1\4\4\uffff\1\3\2\4\1\uffff\10\4",
            "",
            "\1\5",
            "",
            "\1\6",
            "\1\7\42\uffff\1\10\1\12\34\uffff\1\11\1\13",
            "\1\7\42\uffff\1\10\1\12\34\uffff\1\11\1\13",
            "\1\14\5\uffff\1\15",
            "\1\14\5\uffff\1\15",
            "\1\14\5\uffff\1\15",
            "\1\14\5\uffff\1\15",
            "\1\15",
            "\1\2\2\uffff\1\4\63\uffff\1\2"
    };
    static final short[] dfa_7 = DFA.unpackEncodedString(dfa_7s);
    static final char[] dfa_8 = DFA.unpackEncodedStringToUnsignedChars(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final short[] dfa_10 = DFA.unpackEncodedString(dfa_10s);
    static final short[][] dfa_11 = unpackEncodedStringArray(dfa_11s);

    class DFA36 extends DFA {

        public DFA36(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 36;
            this.eot = dfa_1;
            this.eof = dfa_7;
            this.min = dfa_8;
            this.max = dfa_9;
            this.accept = dfa_10;
            this.special = dfa_5;
            this.transition = dfa_11;
        }
        public String getDescription() {
            return "1501:3: (this_EOLINE_6= RULE_EOLINE )?";
        }
    }
    static final String dfa_12s = "\1\2\1\3\14\uffff";
    static final String dfa_13s = "\1\5\1\4\2\uffff\1\6\1\13\6\6\1\14\1\4";
    static final String dfa_14s = "\2\106\2\uffff\1\6\1\13\2\110\5\14\1\73";
    static final String dfa_15s = "\2\uffff\1\2\1\1\12\uffff";
    static final String[] dfa_16s = {
            "\1\1\1\2\1\uffff\1\2\2\uffff\1\2\1\uffff\1\2\2\uffff\1\2\27\uffff\1\2\3\uffff\2\2\1\uffff\1\2\1\uffff\4\2\1\uffff\1\2\4\uffff\3\2\1\uffff\10\2",
            "\1\2\2\3\1\uffff\1\3\2\uffff\1\3\1\uffff\1\3\2\uffff\1\3\27\uffff\1\3\3\uffff\2\3\1\uffff\1\3\1\uffff\4\3\1\uffff\1\3\4\uffff\1\4\2\3\1\uffff\10\3",
            "",
            "",
            "\1\5",
            "\1\6",
            "\1\7\42\uffff\1\10\1\12\34\uffff\1\11\1\13",
            "\1\7\42\uffff\1\10\1\12\34\uffff\1\11\1\13",
            "\1\14\5\uffff\1\15",
            "\1\14\5\uffff\1\15",
            "\1\14\5\uffff\1\15",
            "\1\14\5\uffff\1\15",
            "\1\15",
            "\1\2\2\uffff\1\3\63\uffff\1\2"
    };
    static final short[] dfa_12 = DFA.unpackEncodedString(dfa_12s);
    static final char[] dfa_13 = DFA.unpackEncodedStringToUnsignedChars(dfa_13s);
    static final char[] dfa_14 = DFA.unpackEncodedStringToUnsignedChars(dfa_14s);
    static final short[] dfa_15 = DFA.unpackEncodedString(dfa_15s);
    static final short[][] dfa_16 = unpackEncodedStringArray(dfa_16s);

    class DFA48 extends DFA {

        public DFA48(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 48;
            this.eot = dfa_1;
            this.eof = dfa_12;
            this.min = dfa_13;
            this.max = dfa_14;
            this.accept = dfa_15;
            this.special = dfa_5;
            this.transition = dfa_16;
        }
        public String getDescription() {
            return "1779:3: (this_EOLINE_36= RULE_EOLINE )?";
        }
    }
    static final String dfa_17s = "\116\uffff";
    static final String dfa_18s = "\1\2\1\4\114\uffff";
    static final String dfa_19s = "\2\5\1\uffff\1\4\1\uffff\1\6\1\7\1\5\1\62\13\6\1\4\4\6\1\53\1\4\1\5\3\4\1\5\1\63\1\15\1\4\1\5\1\10\1\5\1\6\1\4\1\10\1\6\1\4\1\15\1\5\1\6\1\4\1\63\1\15\1\13\1\4\1\6\1\15\1\5\5\6\1\4\1\63\1\15\1\14\2\4\1\16\1\5\1\4\1\64\1\65\1\4\1\17\1\4\1\5\1\4\1\10\1\5\1\4";
    static final String dfa_20s = "\2\106\1\uffff\1\73\1\uffff\1\6\1\7\2\106\13\110\1\53\4\6\1\53\1\20\1\63\1\20\2\4\1\106\1\63\1\15\1\4\3\106\1\110\1\53\1\106\1\110\1\106\1\15\1\63\1\6\1\4\1\63\1\15\1\13\1\53\1\110\1\15\1\63\1\110\4\14\1\4\1\63\1\15\1\14\1\73\1\53\1\16\1\64\1\4\1\64\1\65\1\53\1\17\1\4\1\10\1\4\1\10\2\106";
    static final String dfa_21s = "\2\uffff\1\2\1\uffff\1\1\111\uffff";
    static final String dfa_22s = "\116\uffff}>";
    static final String[] dfa_23s = {
            "\1\1\1\2\1\uffff\1\2\2\uffff\1\2\1\uffff\1\2\2\uffff\1\2\27\uffff\1\2\3\uffff\2\2\1\uffff\1\2\1\uffff\4\2\1\uffff\1\2\4\uffff\3\2\1\uffff\10\2",
            "\1\3\1\4\1\uffff\1\4\2\uffff\1\4\1\uffff\1\4\2\uffff\1\4\27\uffff\1\4\3\uffff\2\4\1\uffff\1\4\1\uffff\1\5\3\4\1\uffff\1\4\4\uffff\3\4\1\uffff\10\4",
            "",
            "\1\2\1\4\53\uffff\1\4\11\uffff\1\2",
            "",
            "\1\6",
            "\1\7",
            "\1\10\54\uffff\1\11\1\16\1\13\12\uffff\1\12\1\14\1\15\1\17\1\20\1\21\1\22\1\23",
            "\1\11\1\16\1\13\12\uffff\1\12\1\14\1\15\1\17\1\20\1\21\1\22\1\23",
            "\1\24\42\uffff\1\25\1\27\34\uffff\1\26\1\30",
            "\1\31\42\uffff\1\25\1\27\34\uffff\1\26\1\30",
            "\1\31\42\uffff\1\25\1\27\34\uffff\1\26\1\30",
            "\1\31\42\uffff\1\25\1\27\34\uffff\1\26\1\30",
            "\1\31\42\uffff\1\25\1\27\34\uffff\1\26\1\30",
            "\1\31\42\uffff\1\25\1\27\34\uffff\1\26\1\30",
            "\1\31\42\uffff\1\25\1\27\34\uffff\1\26\1\30",
            "\1\31\42\uffff\1\25\1\27\34\uffff\1\26\1\30",
            "\1\31\42\uffff\1\25\1\27\34\uffff\1\26\1\30",
            "\1\31\42\uffff\1\25\1\27\34\uffff\1\26\1\30",
            "\1\31\42\uffff\1\25\1\27\34\uffff\1\26\1\30",
            "\1\33\46\uffff\1\32",
            "\1\31",
            "\1\31",
            "\1\31",
            "\1\31",
            "\1\34",
            "\1\37\10\uffff\1\35\2\uffff\1\36",
            "\1\40\55\uffff\1\41",
            "\1\37\10\uffff\1\42\2\uffff\1\36",
            "\1\43",
            "\1\37",
            "\1\44\2\uffff\1\45\51\uffff\1\46\1\16\1\13\12\uffff\1\12\1\14\1\15\1\17\1\20\1\21\1\22\1\23",
            "\1\41",
            "\1\47",
            "\1\37",
            "\1\50\2\uffff\1\45\51\uffff\1\46\1\51\1\13\12\uffff\1\12\1\14\1\15\1\17\1\20\1\21\1\22\1\23",
            "\1\45\51\uffff\1\46\1\16\1\13\12\uffff\1\12\1\14\1\15\1\17\1\20\1\21\1\22\1\23",
            "\1\52\1\4\1\uffff\1\4\37\uffff\1\4\3\uffff\2\4\1\uffff\1\4\1\uffff\1\5\3\4\1\uffff\1\4\4\uffff\3\4\1\uffff\10\4",
            "\1\31\42\uffff\1\25\1\27\34\uffff\1\26\1\30",
            "\1\54\46\uffff\1\53",
            "\1\45\51\uffff\1\46\1\51\1\13\12\uffff\1\12\1\14\1\15\1\17\1\20\1\21\1\22\1\23",
            "\1\31\6\uffff\1\47\33\uffff\1\25\1\27\34\uffff\1\26\1\30",
            "\2\2\1\4\1\uffff\1\4\37\uffff\1\4\3\uffff\2\4\1\uffff\1\4\1\uffff\1\5\3\4\1\uffff\1\4\4\uffff\1\55\2\4\1\uffff\10\4",
            "\1\56",
            "\1\57\55\uffff\1\60",
            "\1\61",
            "\1\54",
            "\1\60",
            "\1\62",
            "\1\63",
            "\1\65\46\uffff\1\64",
            "\1\66\42\uffff\1\67\1\71\34\uffff\1\70\1\72",
            "\1\73",
            "\1\74\55\uffff\1\75",
            "\1\66\42\uffff\1\67\1\71\34\uffff\1\70\1\72",
            "\1\76\5\uffff\1\77",
            "\1\76\5\uffff\1\77",
            "\1\76\5\uffff\1\77",
            "\1\76\5\uffff\1\77",
            "\1\65",
            "\1\75",
            "\1\100",
            "\1\77",
            "\1\2\2\uffff\1\4\63\uffff\1\2",
            "\1\102\46\uffff\1\101",
            "\1\103",
            "\1\104\56\uffff\1\105",
            "\1\102",
            "\1\105",
            "\1\106",
            "\1\111\13\uffff\1\110\32\uffff\1\107",
            "\1\112",
            "\1\111",
            "\1\113\2\uffff\1\114",
            "\1\111",
            "\1\114",
            "\1\115\1\4\1\uffff\1\4\37\uffff\1\4\3\uffff\2\4\1\uffff\1\4\1\uffff\1\5\3\4\1\uffff\1\4\4\uffff\3\4\1\uffff\10\4",
            "\2\2\1\4\1\uffff\1\4\37\uffff\1\4\3\uffff\2\4\1\uffff\1\4\1\uffff\1\5\3\4\1\uffff\1\4\4\uffff\1\55\2\4\1\uffff\10\4"
    };

    static final short[] dfa_17 = DFA.unpackEncodedString(dfa_17s);
    static final short[] dfa_18 = DFA.unpackEncodedString(dfa_18s);
    static final char[] dfa_19 = DFA.unpackEncodedStringToUnsignedChars(dfa_19s);
    static final char[] dfa_20 = DFA.unpackEncodedStringToUnsignedChars(dfa_20s);
    static final short[] dfa_21 = DFA.unpackEncodedString(dfa_21s);
    static final short[] dfa_22 = DFA.unpackEncodedString(dfa_22s);
    static final short[][] dfa_23 = unpackEncodedStringArray(dfa_23s);

    class DFA51 extends DFA {

        public DFA51(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 51;
            this.eot = dfa_17;
            this.eof = dfa_18;
            this.min = dfa_19;
            this.max = dfa_20;
            this.accept = dfa_21;
            this.special = dfa_22;
            this.transition = dfa_23;
        }
        public String getDescription() {
            return "1850:3: (this_EOLINE_7= RULE_EOLINE )?";
        }
    }
    static final String dfa_24s = "\17\uffff";
    static final String dfa_25s = "\1\6\1\13\1\uffff\1\15\1\41\1\4\6\11\1\5\1\uffff\1\41";
    static final String dfa_26s = "\1\106\1\13\1\uffff\1\20\2\120\6\20\1\5\1\uffff\1\120";
    static final String dfa_27s = "\2\uffff\1\2\12\uffff\1\1\1\uffff";
    static final String dfa_28s = "\17\uffff}>";
    static final String[] dfa_29s = {
            "\1\2\4\uffff\1\2\1\uffff\1\2\2\uffff\1\2\36\uffff\1\2\1\uffff\4\2\1\uffff\1\2\3\uffff\1\1\4\uffff\10\2",
            "\1\3",
            "",
            "\1\4\2\uffff\1\5",
            "\1\6\1\10\1\7\1\11\52\uffff\1\12\1\13",
            "\1\14\34\uffff\1\6\1\10\1\7\1\11\52\uffff\1\12\1\13",
            "\1\2\3\uffff\1\15\2\uffff\1\15",
            "\1\2\3\uffff\1\15\2\uffff\1\15",
            "\1\2\3\uffff\1\15\2\uffff\1\15",
            "\1\2\3\uffff\1\15\2\uffff\1\15",
            "\1\2\3\uffff\1\15\2\uffff\1\15",
            "\1\2\3\uffff\1\15\2\uffff\1\15",
            "\1\16",
            "",
            "\1\6\1\10\1\7\1\11\52\uffff\1\12\1\13"
    };

    static final short[] dfa_24 = DFA.unpackEncodedString(dfa_24s);
    static final char[] dfa_25 = DFA.unpackEncodedStringToUnsignedChars(dfa_25s);
    static final char[] dfa_26 = DFA.unpackEncodedStringToUnsignedChars(dfa_26s);
    static final short[] dfa_27 = DFA.unpackEncodedString(dfa_27s);
    static final short[] dfa_28 = DFA.unpackEncodedString(dfa_28s);
    static final short[][] dfa_29 = unpackEncodedStringArray(dfa_29s);

    class DFA59 extends DFA {

        public DFA59(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 59;
            this.eot = dfa_24;
            this.eof = dfa_24;
            this.min = dfa_25;
            this.max = dfa_26;
            this.accept = dfa_27;
            this.special = dfa_28;
            this.transition = dfa_29;
        }
        public String getDescription() {
            return "2342:3: ( (lv_restriction_3_0= ruleRestriction ) )?";
        }
    }
    static final String dfa_30s = "\14\uffff";
    static final String dfa_31s = "\2\uffff\1\3\11\uffff";
    static final String dfa_32s = "\1\13\1\20\1\4\1\uffff\1\123\1\uffff\4\20\1\14\1\uffff";
    static final String dfa_33s = "\2\20\1\126\1\uffff\1\126\1\uffff\4\20\1\120\1\uffff";
    static final String dfa_34s = "\3\uffff\1\3\1\uffff\1\1\5\uffff\1\2";
    static final String dfa_35s = "\14\uffff}>";
    static final String[] dfa_36s = {
            "\1\1\1\uffff\1\3\2\uffff\1\2",
            "\1\4",
            "\2\3\2\uffff\1\3\2\uffff\1\3\1\uffff\1\3\2\uffff\1\3\102\uffff\4\5",
            "",
            "\1\6\1\7\1\10\1\11",
            "",
            "\1\12",
            "\1\12",
            "\1\12",
            "\1\12",
            "\1\5\24\uffff\4\13\52\uffff\2\13",
            ""
    };

    static final short[] dfa_30 = DFA.unpackEncodedString(dfa_30s);
    static final short[] dfa_31 = DFA.unpackEncodedString(dfa_31s);
    static final char[] dfa_32 = DFA.unpackEncodedStringToUnsignedChars(dfa_32s);
    static final char[] dfa_33 = DFA.unpackEncodedStringToUnsignedChars(dfa_33s);
    static final short[] dfa_34 = DFA.unpackEncodedString(dfa_34s);
    static final short[] dfa_35 = DFA.unpackEncodedString(dfa_35s);
    static final short[][] dfa_36 = unpackEncodedStringArray(dfa_36s);

    class DFA66 extends DFA {

        public DFA66(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 66;
            this.eot = dfa_30;
            this.eof = dfa_31;
            this.min = dfa_32;
            this.max = dfa_33;
            this.accept = dfa_34;
            this.special = dfa_35;
            this.transition = dfa_36;
        }
        public String getDescription() {
            return "2544:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000700000000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x000000A040000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x000000A040000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000008040000000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000080000080L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0xB85EB10000000160L,0x000000000000007FL});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0xB85EB10000000140L,0x000000000000007FL});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x3800300000000100L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x3800200000000100L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x3800000000000100L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x3000000000000100L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000001800000002L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000004000000010L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0040000000000020L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0002800000000020L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0800000000000010L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000060000000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000080000000040L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000000012800L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x801C000000001000L,0x000000000000007FL});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000000000002020L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000400000000020L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x801C000000000000L,0x000000000000007FL});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000060000000040L,0x0000000000000180L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x801C000000000020L,0x000000000000007FL});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x801C000000000100L,0x000000000000007FL});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0004000000000020L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000080000000010L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0008000000000020L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0010000000000020L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0000080000010010L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0000000000000120L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0000000000022100L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0000000000002100L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0000000000012010L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0380000000000040L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x0000001E00000000L,0x0000000000018000L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x0000000000000000L,0x0000000000007E00L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x845E800000012840L,0x000000000000007FL});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x805E800000012840L,0x000000000000007FL});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0000000000012920L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0000000000001040L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x0000000000000000L,0x0000000000780000L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x0000000000010800L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x00000000007C2000L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0x4000000000000000L});

}