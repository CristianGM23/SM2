package org.xtext.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_DOT", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_ID", "RULE_OPENKEY", "RULE_CLOSEKEY", "RULE_NUMVERSION1", "RULE_NUMVERSION2", "RULE_NUMVERSION3", "RULE_STRING", "RULE_COMMA", "RULE_INT", "RULE_FLOAT", "RULE_BOOLVALUE", "RULE_IF", "RULE_ELSE", "RULE_RETURN", "RULE_RETURNS", "RULE_EMIT", "RULE_BREAK", "RULE_CONTINUE", "RULE_NEW", "RULE_DELETE", "RULE_PARAMSLONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_NOTICELONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_EMAIL", "RULE_CONSTANT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'msg'", "'data'", "'value'", "'gas'", "'sender'", "'sig'", "'block'", "'difficulty'", "'number'", "'timestamp'", "'coinbase'", "'gaslimit'", "'blockhash'", "'now'", "'tx'", "'gasprice'", "'origin'", "'contract'", "'is'", "'pragma'", "'solidity'", "'^'", "'>'", "'>='", "'constructor'", "'public'", "'internal'", "'import'", "'modifier'", "'_;'", "'int'", "'uint'", "'uint8'", "'string'", "'address'", "'address payable'", "'double'", "'bool'", "'bytes'", "'bytes2'", "'bytes3'", "'bytes4'", "'bytes5'", "'bytes6'", "'bytes7'", "'bytes8'", "'bytes16'", "'bytes32'", "'mapping'", "'=>'", "'struct'", "'enum'", "'[]'", "'['", "']'", "'memory'", "'storage'", "'='", "'newString'", "'uint2'", "'uint4'", "'uint16'", "'uint24'", "'uint32'", "'uint64'", "'uint128'", "'uint160'", "'uint256'", "'float'", "'0.0'", "'true'", "'0x'", "'require'", "'function'", "'selfdesctruct'", "'keccack256'", "'sha256'", "'sha3'", "'//'", "'/*'", "'*/'", "'!'", "'private'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'<'", "'<='", "'=='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'", "'%'"
    };
    public static final int T__50=50;
    public static final int RULE_RETURNS=23;
    public static final int RULE_OPENPARENTHESIS=5;
    public static final int RULE_EOLINE=8;
    public static final int T__59=59;
    public static final int RULE_EMIT=24;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__137=137;
    public static final int T__52=52;
    public static final int T__136=136;
    public static final int T__53=53;
    public static final int T__139=139;
    public static final int T__54=54;
    public static final int T__138=138;
    public static final int T__133=133;
    public static final int T__132=132;
    public static final int RULE_PARAMSLONGCOMENT=29;
    public static final int T__60=60;
    public static final int T__135=135;
    public static final int T__61=61;
    public static final int T__134=134;
    public static final int RULE_ID=9;
    public static final int RULE_RETURN=22;
    public static final int T__131=131;
    public static final int T__130=130;
    public static final int RULE_INT=17;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=36;
    public static final int T__67=67;
    public static final int T__129=129;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__126=126;
    public static final int T__63=63;
    public static final int T__125=125;
    public static final int T__64=64;
    public static final int T__128=128;
    public static final int T__65=65;
    public static final int T__127=127;
    public static final int RULE_DELETE=28;
    public static final int RULE_TITLELONGCOMENT=33;
    public static final int RULE_NOTICELONGCOMENT=31;
    public static final int RULE_EMAIL=34;
    public static final int RULE_CONSTANT=35;
    public static final int RULE_OPENKEY=10;
    public static final int RULE_CLOSEPARENTHESIS=6;
    public static final int RULE_IF=20;
    public static final int RULE_DOT=4;
    public static final int RULE_CONTINUE=26;
    public static final int RULE_DEVLONGCOMENT=30;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int RULE_FLOAT=18;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__91=91;
    public static final int T__100=100;
    public static final int T__92=92;
    public static final int T__93=93;
    public static final int T__102=102;
    public static final int T__94=94;
    public static final int T__101=101;
    public static final int RULE_NEW=27;
    public static final int T__90=90;
    public static final int T__99=99;
    public static final int RULE_CLOSEKEY=11;
    public static final int T__95=95;
    public static final int T__96=96;
    public static final int T__97=97;
    public static final int T__98=98;
    public static final int RULE_COMMA=16;
    public static final int RULE_RETURNSLONGCOMENT=32;
    public static final int RULE_SEMICOLON=7;
    public static final int RULE_NUMVERSION3=14;
    public static final int RULE_NUMVERSION2=13;
    public static final int RULE_ELSE=21;
    public static final int RULE_NUMVERSION1=12;
    public static final int T__122=122;
    public static final int T__70=70;
    public static final int T__121=121;
    public static final int T__71=71;
    public static final int T__124=124;
    public static final int RULE_BOOLVALUE=19;
    public static final int T__72=72;
    public static final int T__123=123;
    public static final int T__120=120;
    public static final int RULE_STRING=15;
    public static final int RULE_SL_COMMENT=37;
    public static final int RULE_BREAK=25;
    public static final int T__77=77;
    public static final int T__119=119;
    public static final int T__78=78;
    public static final int T__118=118;
    public static final int T__79=79;
    public static final int T__73=73;
    public static final int T__115=115;
    public static final int EOF=-1;
    public static final int T__74=74;
    public static final int T__114=114;
    public static final int T__75=75;
    public static final int T__117=117;
    public static final int T__76=76;
    public static final int T__116=116;
    public static final int T__80=80;
    public static final int T__111=111;
    public static final int T__81=81;
    public static final int T__110=110;
    public static final int T__82=82;
    public static final int T__113=113;
    public static final int T__83=83;
    public static final int T__112=112;
    public static final int RULE_WS=38;
    public static final int RULE_ANY_OTHER=39;
    public static final int T__88=88;
    public static final int T__108=108;
    public static final int T__89=89;
    public static final int T__107=107;
    public static final int T__109=109;
    public static final int T__84=84;
    public static final int T__104=104;
    public static final int T__85=85;
    public static final int T__103=103;
    public static final int T__86=86;
    public static final int T__106=106;
    public static final int T__87=87;
    public static final int T__105=105;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }



     	private SM2GrammarAccess grammarAccess;

        public InternalSM2Parser(TokenStream input, SM2GrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "File";
       	}

       	@Override
       	protected SM2GrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleFile"
    // InternalSM2.g:65:1: entryRuleFile returns [EObject current=null] : iv_ruleFile= ruleFile EOF ;
    public final EObject entryRuleFile() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFile = null;


        try {
            // InternalSM2.g:65:45: (iv_ruleFile= ruleFile EOF )
            // InternalSM2.g:66:2: iv_ruleFile= ruleFile EOF
            {
             newCompositeNode(grammarAccess.getFileRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFile=ruleFile();

            state._fsp--;

             current =iv_ruleFile; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFile"


    // $ANTLR start "ruleFile"
    // InternalSM2.g:72:1: ruleFile returns [EObject current=null] : ( ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_properties_2_0= ruleProperties ) )* ( (lv_contract_3_0= ruleContract ) ) ( (lv_comments_4_0= ruleComment ) )* ) ;
    public final EObject ruleFile() throws RecognitionException {
        EObject current = null;

        EObject lv_version_0_0 = null;

        EObject lv_properties_2_0 = null;

        EObject lv_contract_3_0 = null;

        EObject lv_comments_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:78:2: ( ( ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_properties_2_0= ruleProperties ) )* ( (lv_contract_3_0= ruleContract ) ) ( (lv_comments_4_0= ruleComment ) )* ) )
            // InternalSM2.g:79:2: ( ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_properties_2_0= ruleProperties ) )* ( (lv_contract_3_0= ruleContract ) ) ( (lv_comments_4_0= ruleComment ) )* )
            {
            // InternalSM2.g:79:2: ( ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_properties_2_0= ruleProperties ) )* ( (lv_contract_3_0= ruleContract ) ) ( (lv_comments_4_0= ruleComment ) )* )
            // InternalSM2.g:80:3: ( (lv_version_0_0= ruleVersion ) ) ruleImport ( (lv_properties_2_0= ruleProperties ) )* ( (lv_contract_3_0= ruleContract ) ) ( (lv_comments_4_0= ruleComment ) )*
            {
            // InternalSM2.g:80:3: ( (lv_version_0_0= ruleVersion ) )
            // InternalSM2.g:81:4: (lv_version_0_0= ruleVersion )
            {
            // InternalSM2.g:81:4: (lv_version_0_0= ruleVersion )
            // InternalSM2.g:82:5: lv_version_0_0= ruleVersion
            {

            					newCompositeNode(grammarAccess.getFileAccess().getVersionVersionParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_3);
            lv_version_0_0=ruleVersion();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFileRule());
            					}
            					set(
            						current,
            						"version",
            						lv_version_0_0,
            						"org.xtext.SM2.Version");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            			newCompositeNode(grammarAccess.getFileAccess().getImportParserRuleCall_1());
            		
            pushFollow(FOLLOW_4);
            ruleImport();

            state._fsp--;


            			afterParserOrEnumRuleCall();
            		
            // InternalSM2.g:106:3: ( (lv_properties_2_0= ruleProperties ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=70 && LA1_0<=75)||LA1_0==77||(LA1_0>=99 && LA1_0<=108)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalSM2.g:107:4: (lv_properties_2_0= ruleProperties )
            	    {
            	    // InternalSM2.g:107:4: (lv_properties_2_0= ruleProperties )
            	    // InternalSM2.g:108:5: lv_properties_2_0= ruleProperties
            	    {

            	    					newCompositeNode(grammarAccess.getFileAccess().getPropertiesPropertiesParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_4);
            	    lv_properties_2_0=ruleProperties();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFileRule());
            	    					}
            	    					add(
            	    						current,
            	    						"properties",
            	    						lv_properties_2_0,
            	    						"org.xtext.SM2.Properties");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            // InternalSM2.g:125:3: ( (lv_contract_3_0= ruleContract ) )
            // InternalSM2.g:126:4: (lv_contract_3_0= ruleContract )
            {
            // InternalSM2.g:126:4: (lv_contract_3_0= ruleContract )
            // InternalSM2.g:127:5: lv_contract_3_0= ruleContract
            {

            					newCompositeNode(grammarAccess.getFileAccess().getContractContractParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_5);
            lv_contract_3_0=ruleContract();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFileRule());
            					}
            					set(
            						current,
            						"contract",
            						lv_contract_3_0,
            						"org.xtext.SM2.Contract");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:144:3: ( (lv_comments_4_0= ruleComment ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>=118 && LA2_0<=119)) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSM2.g:145:4: (lv_comments_4_0= ruleComment )
            	    {
            	    // InternalSM2.g:145:4: (lv_comments_4_0= ruleComment )
            	    // InternalSM2.g:146:5: lv_comments_4_0= ruleComment
            	    {

            	    					newCompositeNode(grammarAccess.getFileAccess().getCommentsCommentParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_5);
            	    lv_comments_4_0=ruleComment();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFileRule());
            	    					}
            	    					add(
            	    						current,
            	    						"comments",
            	    						lv_comments_4_0,
            	    						"org.xtext.SM2.Comment");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFile"


    // $ANTLR start "entryRuleMSGVariables"
    // InternalSM2.g:167:1: entryRuleMSGVariables returns [EObject current=null] : iv_ruleMSGVariables= ruleMSGVariables EOF ;
    public final EObject entryRuleMSGVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMSGVariables = null;


        try {
            // InternalSM2.g:167:53: (iv_ruleMSGVariables= ruleMSGVariables EOF )
            // InternalSM2.g:168:2: iv_ruleMSGVariables= ruleMSGVariables EOF
            {
             newCompositeNode(grammarAccess.getMSGVariablesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMSGVariables=ruleMSGVariables();

            state._fsp--;

             current =iv_ruleMSGVariables; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMSGVariables"


    // $ANTLR start "ruleMSGVariables"
    // InternalSM2.g:174:1: ruleMSGVariables returns [EObject current=null] : (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation ) ;
    public final EObject ruleMSGVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_MSGOperation_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:180:2: ( (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation ) )
            // InternalSM2.g:181:2: (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation )
            {
            // InternalSM2.g:181:2: (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation )
            // InternalSM2.g:182:3: otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation
            {
            otherlv_0=(Token)match(input,40,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getMSGVariablesAccess().getMsgKeyword_0());
            		

            			newCompositeNode(grammarAccess.getMSGVariablesAccess().getMSGOperationParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_MSGOperation_1=ruleMSGOperation();

            state._fsp--;


            			current = this_MSGOperation_1;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMSGVariables"


    // $ANTLR start "entryRuleMSGOperation"
    // InternalSM2.g:198:1: entryRuleMSGOperation returns [EObject current=null] : iv_ruleMSGOperation= ruleMSGOperation EOF ;
    public final EObject entryRuleMSGOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMSGOperation = null;


        try {
            // InternalSM2.g:198:53: (iv_ruleMSGOperation= ruleMSGOperation EOF )
            // InternalSM2.g:199:2: iv_ruleMSGOperation= ruleMSGOperation EOF
            {
             newCompositeNode(grammarAccess.getMSGOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMSGOperation=ruleMSGOperation();

            state._fsp--;

             current =iv_ruleMSGOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMSGOperation"


    // $ANTLR start "ruleMSGOperation"
    // InternalSM2.g:205:1: ruleMSGOperation returns [EObject current=null] : (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? ) ;
    public final EObject ruleMSGOperation() throws RecognitionException {
        EObject current = null;

        Token this_DOT_0=null;
        Token otherlv_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token this_OPENPARENTHESIS_7=null;
        Token this_CLOSEPARENTHESIS_9=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token this_OPENPARENTHESIS_12=null;
        Token this_CLOSEPARENTHESIS_14=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token this_OPENPARENTHESIS_17=null;
        Token this_CLOSEPARENTHESIS_19=null;
        Token otherlv_20=null;
        Token otherlv_21=null;
        Token this_OPENPARENTHESIS_22=null;
        Token this_CLOSEPARENTHESIS_24=null;
        Token otherlv_25=null;
        Token this_SEMICOLON_26=null;
        Token this_EOLINE_27=null;


        	enterRule();

        try {
            // InternalSM2.g:211:2: ( (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? ) )
            // InternalSM2.g:212:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? )
            {
            // InternalSM2.g:212:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? )
            // InternalSM2.g:213:3: this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )?
            {
            this_DOT_0=(Token)match(input,RULE_DOT,FOLLOW_7); 

            			newLeafNode(this_DOT_0, grammarAccess.getMSGOperationAccess().getDOTTerminalRuleCall_0());
            		
            // InternalSM2.g:217:3: ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) )
            int alt8=5;
            switch ( input.LA(1) ) {
            case 41:
                {
                alt8=1;
                }
                break;
            case 42:
                {
                alt8=2;
                }
                break;
            case 43:
                {
                alt8=3;
                }
                break;
            case 44:
                {
                alt8=4;
                }
                break;
            case 45:
                {
                alt8=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // InternalSM2.g:218:4: ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' )
                    {
                    // InternalSM2.g:218:4: ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' )
                    int alt3=2;
                    int LA3_0 = input.LA(1);

                    if ( (LA3_0==41) ) {
                        int LA3_1 = input.LA(2);

                        if ( (LA3_1==RULE_OPENPARENTHESIS) ) {
                            alt3=1;
                        }
                        else if ( (LA3_1==EOF||LA3_1==RULE_SEMICOLON) ) {
                            alt3=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 3, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 3, 0, input);

                        throw nvae;
                    }
                    switch (alt3) {
                        case 1 :
                            // InternalSM2.g:219:5: (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:219:5: (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:220:6: otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_1=(Token)match(input,41,FOLLOW_8); 

                            						newLeafNode(otherlv_1, grammarAccess.getMSGOperationAccess().getDataKeyword_1_0_0_0());
                            					
                            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_0_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_0_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:241:5: otherlv_5= 'data'
                            {
                            otherlv_5=(Token)match(input,41,FOLLOW_11); 

                            					newLeafNode(otherlv_5, grammarAccess.getMSGOperationAccess().getDataKeyword_1_0_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:247:4: ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' )
                    {
                    // InternalSM2.g:247:4: ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' )
                    int alt4=2;
                    int LA4_0 = input.LA(1);

                    if ( (LA4_0==42) ) {
                        int LA4_1 = input.LA(2);

                        if ( (LA4_1==EOF||LA4_1==RULE_SEMICOLON) ) {
                            alt4=2;
                        }
                        else if ( (LA4_1==RULE_OPENPARENTHESIS) ) {
                            alt4=1;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 4, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 0, input);

                        throw nvae;
                    }
                    switch (alt4) {
                        case 1 :
                            // InternalSM2.g:248:5: (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:248:5: (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:249:6: otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_6=(Token)match(input,42,FOLLOW_8); 

                            						newLeafNode(otherlv_6, grammarAccess.getMSGOperationAccess().getValueKeyword_1_1_0_0());
                            					
                            this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_1_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_9=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_9, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:270:5: otherlv_10= 'value'
                            {
                            otherlv_10=(Token)match(input,42,FOLLOW_11); 

                            					newLeafNode(otherlv_10, grammarAccess.getMSGOperationAccess().getValueKeyword_1_1_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:276:4: ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' )
                    {
                    // InternalSM2.g:276:4: ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' )
                    int alt5=2;
                    int LA5_0 = input.LA(1);

                    if ( (LA5_0==43) ) {
                        int LA5_1 = input.LA(2);

                        if ( (LA5_1==RULE_OPENPARENTHESIS) ) {
                            alt5=1;
                        }
                        else if ( (LA5_1==EOF||LA5_1==RULE_SEMICOLON) ) {
                            alt5=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 5, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 5, 0, input);

                        throw nvae;
                    }
                    switch (alt5) {
                        case 1 :
                            // InternalSM2.g:277:5: (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:277:5: (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:278:6: otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_11=(Token)match(input,43,FOLLOW_8); 

                            						newLeafNode(otherlv_11, grammarAccess.getMSGOperationAccess().getGasKeyword_1_2_0_0());
                            					
                            this_OPENPARENTHESIS_12=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_12, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_2_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_2_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_14=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_14, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_2_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:299:5: otherlv_15= 'gas'
                            {
                            otherlv_15=(Token)match(input,43,FOLLOW_11); 

                            					newLeafNode(otherlv_15, grammarAccess.getMSGOperationAccess().getGasKeyword_1_2_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:305:4: ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' )
                    {
                    // InternalSM2.g:305:4: ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' )
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( (LA6_0==44) ) {
                        int LA6_1 = input.LA(2);

                        if ( (LA6_1==RULE_OPENPARENTHESIS) ) {
                            alt6=1;
                        }
                        else if ( (LA6_1==EOF||LA6_1==RULE_SEMICOLON) ) {
                            alt6=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 6, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 6, 0, input);

                        throw nvae;
                    }
                    switch (alt6) {
                        case 1 :
                            // InternalSM2.g:306:5: (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:306:5: (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:307:6: otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_16=(Token)match(input,44,FOLLOW_8); 

                            						newLeafNode(otherlv_16, grammarAccess.getMSGOperationAccess().getSenderKeyword_1_3_0_0());
                            					
                            this_OPENPARENTHESIS_17=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_17, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_3_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_3_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_19=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_19, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:328:5: otherlv_20= 'sender'
                            {
                            otherlv_20=(Token)match(input,44,FOLLOW_11); 

                            					newLeafNode(otherlv_20, grammarAccess.getMSGOperationAccess().getSenderKeyword_1_3_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:334:4: ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' )
                    {
                    // InternalSM2.g:334:4: ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' )
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==45) ) {
                        int LA7_1 = input.LA(2);

                        if ( (LA7_1==EOF||LA7_1==RULE_SEMICOLON) ) {
                            alt7=2;
                        }
                        else if ( (LA7_1==RULE_OPENPARENTHESIS) ) {
                            alt7=1;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 7, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 7, 0, input);

                        throw nvae;
                    }
                    switch (alt7) {
                        case 1 :
                            // InternalSM2.g:335:5: (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:335:5: (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:336:6: otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_21=(Token)match(input,45,FOLLOW_8); 

                            						newLeafNode(otherlv_21, grammarAccess.getMSGOperationAccess().getSigKeyword_1_4_0_0());
                            					
                            this_OPENPARENTHESIS_22=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_22, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_4_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_4_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_24=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_24, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_4_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:357:5: otherlv_25= 'sig'
                            {
                            otherlv_25=(Token)match(input,45,FOLLOW_11); 

                            					newLeafNode(otherlv_25, grammarAccess.getMSGOperationAccess().getSigKeyword_1_4_1());
                            				

                            }
                            break;

                    }


                    }
                    break;

            }

            // InternalSM2.g:363:3: (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==RULE_SEMICOLON) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalSM2.g:364:4: this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE
                    {
                    this_SEMICOLON_26=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

                    				newLeafNode(this_SEMICOLON_26, grammarAccess.getMSGOperationAccess().getSEMICOLONTerminalRuleCall_2_0());
                    			
                    this_EOLINE_27=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_27, grammarAccess.getMSGOperationAccess().getEOLINETerminalRuleCall_2_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMSGOperation"


    // $ANTLR start "entryRuleBlockOperation"
    // InternalSM2.g:377:1: entryRuleBlockOperation returns [EObject current=null] : iv_ruleBlockOperation= ruleBlockOperation EOF ;
    public final EObject entryRuleBlockOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBlockOperation = null;


        try {
            // InternalSM2.g:377:55: (iv_ruleBlockOperation= ruleBlockOperation EOF )
            // InternalSM2.g:378:2: iv_ruleBlockOperation= ruleBlockOperation EOF
            {
             newCompositeNode(grammarAccess.getBlockOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBlockOperation=ruleBlockOperation();

            state._fsp--;

             current =iv_ruleBlockOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBlockOperation"


    // $ANTLR start "ruleBlockOperation"
    // InternalSM2.g:384:1: ruleBlockOperation returns [EObject current=null] : ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? ) ) ;
    public final EObject ruleBlockOperation() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_DOT_1=null;
        Token otherlv_2=null;
        Token this_OPENPARENTHESIS_3=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token this_OPENPARENTHESIS_8=null;
        Token this_CLOSEPARENTHESIS_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token this_OPENPARENTHESIS_13=null;
        Token this_CLOSEPARENTHESIS_15=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token this_OPENPARENTHESIS_18=null;
        Token this_CLOSEPARENTHESIS_20=null;
        Token otherlv_21=null;
        Token otherlv_22=null;
        Token this_OPENPARENTHESIS_23=null;
        Token this_CLOSEPARENTHESIS_25=null;
        Token otherlv_26=null;
        Token otherlv_27=null;
        Token this_OPENPARENTHESIS_28=null;
        Token this_CLOSEPARENTHESIS_30=null;
        Token otherlv_31=null;
        Token otherlv_32=null;
        Token this_OPENPARENTHESIS_33=null;
        Token this_CLOSEPARENTHESIS_35=null;
        Token this_SEMICOLON_36=null;


        	enterRule();

        try {
            // InternalSM2.g:390:2: ( ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? ) ) )
            // InternalSM2.g:391:2: ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? ) )
            {
            // InternalSM2.g:391:2: ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? ) )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==46) ) {
                alt18=1;
            }
            else if ( (LA18_0==53) ) {
                alt18=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    // InternalSM2.g:392:3: (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) )
                    {
                    // InternalSM2.g:392:3: (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) )
                    // InternalSM2.g:393:4: otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) )
                    {
                    otherlv_0=(Token)match(input,46,FOLLOW_6); 

                    				newLeafNode(otherlv_0, grammarAccess.getBlockOperationAccess().getBlockKeyword_0_0());
                    			
                    this_DOT_1=(Token)match(input,RULE_DOT,FOLLOW_13); 

                    				newLeafNode(this_DOT_1, grammarAccess.getBlockOperationAccess().getDOTTerminalRuleCall_0_1());
                    			
                    // InternalSM2.g:401:4: ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) )
                    int alt16=6;
                    switch ( input.LA(1) ) {
                    case 47:
                        {
                        alt16=1;
                        }
                        break;
                    case 48:
                        {
                        alt16=2;
                        }
                        break;
                    case 49:
                        {
                        alt16=3;
                        }
                        break;
                    case 50:
                        {
                        alt16=4;
                        }
                        break;
                    case 51:
                        {
                        alt16=5;
                        }
                        break;
                    case 52:
                        {
                        alt16=6;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 16, 0, input);

                        throw nvae;
                    }

                    switch (alt16) {
                        case 1 :
                            // InternalSM2.g:402:5: ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' )
                            {
                            // InternalSM2.g:402:5: ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' )
                            int alt10=2;
                            int LA10_0 = input.LA(1);

                            if ( (LA10_0==47) ) {
                                int LA10_1 = input.LA(2);

                                if ( (LA10_1==EOF) ) {
                                    alt10=2;
                                }
                                else if ( (LA10_1==RULE_OPENPARENTHESIS) ) {
                                    alt10=1;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 10, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 10, 0, input);

                                throw nvae;
                            }
                            switch (alt10) {
                                case 1 :
                                    // InternalSM2.g:403:6: (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:403:6: (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:404:7: otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_2=(Token)match(input,47,FOLLOW_8); 

                                    							newLeafNode(otherlv_2, grammarAccess.getBlockOperationAccess().getDifficultyKeyword_0_2_0_0_0());
                                    						
                                    this_OPENPARENTHESIS_3=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                                    							newLeafNode(this_OPENPARENTHESIS_3, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_0_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_0_0_2());
                                    						
                                    pushFollow(FOLLOW_10);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_0_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:425:6: otherlv_6= 'difficulty'
                                    {
                                    otherlv_6=(Token)match(input,47,FOLLOW_2); 

                                    						newLeafNode(otherlv_6, grammarAccess.getBlockOperationAccess().getDifficultyKeyword_0_2_0_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:431:5: ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' )
                            {
                            // InternalSM2.g:431:5: ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' )
                            int alt11=2;
                            int LA11_0 = input.LA(1);

                            if ( (LA11_0==48) ) {
                                int LA11_1 = input.LA(2);

                                if ( (LA11_1==RULE_OPENPARENTHESIS) ) {
                                    alt11=1;
                                }
                                else if ( (LA11_1==EOF) ) {
                                    alt11=2;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 11, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 11, 0, input);

                                throw nvae;
                            }
                            switch (alt11) {
                                case 1 :
                                    // InternalSM2.g:432:6: (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:432:6: (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:433:7: otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_7=(Token)match(input,48,FOLLOW_8); 

                                    							newLeafNode(otherlv_7, grammarAccess.getBlockOperationAccess().getNumberKeyword_0_2_1_0_0());
                                    						
                                    this_OPENPARENTHESIS_8=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                                    							newLeafNode(this_OPENPARENTHESIS_8, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_1_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_1_0_2());
                                    						
                                    pushFollow(FOLLOW_10);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_10=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_10, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_1_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:454:6: otherlv_11= 'number'
                                    {
                                    otherlv_11=(Token)match(input,48,FOLLOW_2); 

                                    						newLeafNode(otherlv_11, grammarAccess.getBlockOperationAccess().getNumberKeyword_0_2_1_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 3 :
                            // InternalSM2.g:460:5: ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' )
                            {
                            // InternalSM2.g:460:5: ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' )
                            int alt12=2;
                            int LA12_0 = input.LA(1);

                            if ( (LA12_0==49) ) {
                                int LA12_1 = input.LA(2);

                                if ( (LA12_1==RULE_OPENPARENTHESIS) ) {
                                    alt12=1;
                                }
                                else if ( (LA12_1==EOF) ) {
                                    alt12=2;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 12, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 12, 0, input);

                                throw nvae;
                            }
                            switch (alt12) {
                                case 1 :
                                    // InternalSM2.g:461:6: (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:461:6: (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:462:7: otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_12=(Token)match(input,49,FOLLOW_8); 

                                    							newLeafNode(otherlv_12, grammarAccess.getBlockOperationAccess().getTimestampKeyword_0_2_2_0_0());
                                    						
                                    this_OPENPARENTHESIS_13=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                                    							newLeafNode(this_OPENPARENTHESIS_13, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_2_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_2_0_2());
                                    						
                                    pushFollow(FOLLOW_10);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_15=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_15, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_2_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:483:6: otherlv_16= 'timestamp'
                                    {
                                    otherlv_16=(Token)match(input,49,FOLLOW_2); 

                                    						newLeafNode(otherlv_16, grammarAccess.getBlockOperationAccess().getTimestampKeyword_0_2_2_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 4 :
                            // InternalSM2.g:489:5: ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' )
                            {
                            // InternalSM2.g:489:5: ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' )
                            int alt13=2;
                            int LA13_0 = input.LA(1);

                            if ( (LA13_0==50) ) {
                                int LA13_1 = input.LA(2);

                                if ( (LA13_1==EOF) ) {
                                    alt13=2;
                                }
                                else if ( (LA13_1==RULE_OPENPARENTHESIS) ) {
                                    alt13=1;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 13, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 13, 0, input);

                                throw nvae;
                            }
                            switch (alt13) {
                                case 1 :
                                    // InternalSM2.g:490:6: (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:490:6: (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:491:7: otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_17=(Token)match(input,50,FOLLOW_8); 

                                    							newLeafNode(otherlv_17, grammarAccess.getBlockOperationAccess().getCoinbaseKeyword_0_2_3_0_0());
                                    						
                                    this_OPENPARENTHESIS_18=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                                    							newLeafNode(this_OPENPARENTHESIS_18, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_3_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_3_0_2());
                                    						
                                    pushFollow(FOLLOW_10);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_20=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_20, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_3_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:512:6: otherlv_21= 'coinbase'
                                    {
                                    otherlv_21=(Token)match(input,50,FOLLOW_2); 

                                    						newLeafNode(otherlv_21, grammarAccess.getBlockOperationAccess().getCoinbaseKeyword_0_2_3_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 5 :
                            // InternalSM2.g:518:5: ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' )
                            {
                            // InternalSM2.g:518:5: ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' )
                            int alt14=2;
                            int LA14_0 = input.LA(1);

                            if ( (LA14_0==51) ) {
                                int LA14_1 = input.LA(2);

                                if ( (LA14_1==RULE_OPENPARENTHESIS) ) {
                                    alt14=1;
                                }
                                else if ( (LA14_1==EOF) ) {
                                    alt14=2;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 14, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 14, 0, input);

                                throw nvae;
                            }
                            switch (alt14) {
                                case 1 :
                                    // InternalSM2.g:519:6: (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:519:6: (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:520:7: otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_22=(Token)match(input,51,FOLLOW_8); 

                                    							newLeafNode(otherlv_22, grammarAccess.getBlockOperationAccess().getGaslimitKeyword_0_2_4_0_0());
                                    						
                                    this_OPENPARENTHESIS_23=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                                    							newLeafNode(this_OPENPARENTHESIS_23, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_4_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_4_0_2());
                                    						
                                    pushFollow(FOLLOW_10);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_25=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_25, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_4_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:541:6: otherlv_26= 'gaslimit'
                                    {
                                    otherlv_26=(Token)match(input,51,FOLLOW_2); 

                                    						newLeafNode(otherlv_26, grammarAccess.getBlockOperationAccess().getGaslimitKeyword_0_2_4_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 6 :
                            // InternalSM2.g:547:5: ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' )
                            {
                            // InternalSM2.g:547:5: ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' )
                            int alt15=2;
                            int LA15_0 = input.LA(1);

                            if ( (LA15_0==52) ) {
                                int LA15_1 = input.LA(2);

                                if ( (LA15_1==RULE_OPENPARENTHESIS) ) {
                                    alt15=1;
                                }
                                else if ( (LA15_1==EOF) ) {
                                    alt15=2;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 15, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 15, 0, input);

                                throw nvae;
                            }
                            switch (alt15) {
                                case 1 :
                                    // InternalSM2.g:548:6: (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:548:6: (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:549:7: otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_27=(Token)match(input,52,FOLLOW_8); 

                                    							newLeafNode(otherlv_27, grammarAccess.getBlockOperationAccess().getBlockhashKeyword_0_2_5_0_0());
                                    						
                                    this_OPENPARENTHESIS_28=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                                    							newLeafNode(this_OPENPARENTHESIS_28, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_5_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_5_0_2());
                                    						
                                    pushFollow(FOLLOW_10);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_30=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_30, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_5_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:570:6: otherlv_31= 'blockhash'
                                    {
                                    otherlv_31=(Token)match(input,52,FOLLOW_2); 

                                    						newLeafNode(otherlv_31, grammarAccess.getBlockOperationAccess().getBlockhashKeyword_0_2_5_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:578:3: (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:578:3: (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? )
                    // InternalSM2.g:579:4: otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )?
                    {
                    otherlv_32=(Token)match(input,53,FOLLOW_8); 

                    				newLeafNode(otherlv_32, grammarAccess.getBlockOperationAccess().getNowKeyword_1_0());
                    			
                    this_OPENPARENTHESIS_33=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                    				newLeafNode(this_OPENPARENTHESIS_33, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1());
                    			

                    				newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_1_2());
                    			
                    pushFollow(FOLLOW_10);
                    ruleExpression();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			
                    this_CLOSEPARENTHESIS_35=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                    				newLeafNode(this_CLOSEPARENTHESIS_35, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3());
                    			
                    // InternalSM2.g:598:4: (this_SEMICOLON_36= RULE_SEMICOLON )?
                    int alt17=2;
                    int LA17_0 = input.LA(1);

                    if ( (LA17_0==RULE_SEMICOLON) ) {
                        alt17=1;
                    }
                    switch (alt17) {
                        case 1 :
                            // InternalSM2.g:599:5: this_SEMICOLON_36= RULE_SEMICOLON
                            {
                            this_SEMICOLON_36=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_36, grammarAccess.getBlockOperationAccess().getSEMICOLONTerminalRuleCall_1_4());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBlockOperation"


    // $ANTLR start "entryRuleTxVariables"
    // InternalSM2.g:609:1: entryRuleTxVariables returns [EObject current=null] : iv_ruleTxVariables= ruleTxVariables EOF ;
    public final EObject entryRuleTxVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTxVariables = null;


        try {
            // InternalSM2.g:609:52: (iv_ruleTxVariables= ruleTxVariables EOF )
            // InternalSM2.g:610:2: iv_ruleTxVariables= ruleTxVariables EOF
            {
             newCompositeNode(grammarAccess.getTxVariablesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTxVariables=ruleTxVariables();

            state._fsp--;

             current =iv_ruleTxVariables; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTxVariables"


    // $ANTLR start "ruleTxVariables"
    // InternalSM2.g:616:1: ruleTxVariables returns [EObject current=null] : (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation ) ;
    public final EObject ruleTxVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_TxOperation_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:622:2: ( (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation ) )
            // InternalSM2.g:623:2: (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation )
            {
            // InternalSM2.g:623:2: (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation )
            // InternalSM2.g:624:3: otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation
            {
            otherlv_0=(Token)match(input,54,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getTxVariablesAccess().getTxKeyword_0());
            		

            			newCompositeNode(grammarAccess.getTxVariablesAccess().getTxOperationParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_TxOperation_1=ruleTxOperation();

            state._fsp--;


            			current = this_TxOperation_1;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTxVariables"


    // $ANTLR start "entryRuleTxOperation"
    // InternalSM2.g:640:1: entryRuleTxOperation returns [EObject current=null] : iv_ruleTxOperation= ruleTxOperation EOF ;
    public final EObject entryRuleTxOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTxOperation = null;


        try {
            // InternalSM2.g:640:52: (iv_ruleTxOperation= ruleTxOperation EOF )
            // InternalSM2.g:641:2: iv_ruleTxOperation= ruleTxOperation EOF
            {
             newCompositeNode(grammarAccess.getTxOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTxOperation=ruleTxOperation();

            state._fsp--;

             current =iv_ruleTxOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTxOperation"


    // $ANTLR start "ruleTxOperation"
    // InternalSM2.g:647:1: ruleTxOperation returns [EObject current=null] : (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? ) ;
    public final EObject ruleTxOperation() throws RecognitionException {
        EObject current = null;

        Token this_DOT_0=null;
        Token otherlv_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token this_OPENPARENTHESIS_7=null;
        Token this_CLOSEPARENTHESIS_9=null;
        Token otherlv_10=null;
        Token this_SEMICOLON_11=null;
        Token this_EOLINE_12=null;


        	enterRule();

        try {
            // InternalSM2.g:653:2: ( (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? ) )
            // InternalSM2.g:654:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? )
            {
            // InternalSM2.g:654:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? )
            // InternalSM2.g:655:3: this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )?
            {
            this_DOT_0=(Token)match(input,RULE_DOT,FOLLOW_14); 

            			newLeafNode(this_DOT_0, grammarAccess.getTxOperationAccess().getDOTTerminalRuleCall_0());
            		
            // InternalSM2.g:659:3: ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' )
            int alt20=3;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==55) ) {
                alt20=1;
            }
            else if ( (LA20_0==56) ) {
                int LA20_2 = input.LA(2);

                if ( (LA20_2==RULE_OPENPARENTHESIS) ) {
                    alt20=2;
                }
                else if ( (LA20_2==EOF||LA20_2==RULE_SEMICOLON) ) {
                    alt20=3;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 20, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;
            }
            switch (alt20) {
                case 1 :
                    // InternalSM2.g:660:4: ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' )
                    {
                    // InternalSM2.g:660:4: ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' )
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( (LA19_0==55) ) {
                        int LA19_1 = input.LA(2);

                        if ( (LA19_1==RULE_OPENPARENTHESIS) ) {
                            alt19=1;
                        }
                        else if ( (LA19_1==EOF||LA19_1==RULE_SEMICOLON) ) {
                            alt19=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 19, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 19, 0, input);

                        throw nvae;
                    }
                    switch (alt19) {
                        case 1 :
                            // InternalSM2.g:661:5: (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:661:5: (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:662:6: otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_1=(Token)match(input,55,FOLLOW_8); 

                            						newLeafNode(otherlv_1, grammarAccess.getTxOperationAccess().getGaspriceKeyword_1_0_0_0());
                            					
                            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                            						newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getTxOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_0_0_1());
                            					

                            						newCompositeNode(grammarAccess.getTxOperationAccess().getExpressionParserRuleCall_1_0_0_2());
                            					
                            pushFollow(FOLLOW_10);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                            						newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getTxOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:683:5: otherlv_5= 'gasprice'
                            {
                            otherlv_5=(Token)match(input,55,FOLLOW_11); 

                            					newLeafNode(otherlv_5, grammarAccess.getTxOperationAccess().getGaspriceKeyword_1_0_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:689:4: ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:689:4: ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:690:5: (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS
                    {
                    // InternalSM2.g:690:5: (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression )
                    // InternalSM2.g:691:6: otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression
                    {
                    otherlv_6=(Token)match(input,56,FOLLOW_8); 

                    						newLeafNode(otherlv_6, grammarAccess.getTxOperationAccess().getOriginKeyword_1_1_0_0());
                    					
                    this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

                    						newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getTxOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1_0_1());
                    					

                    						newCompositeNode(grammarAccess.getTxOperationAccess().getExpressionParserRuleCall_1_1_0_2());
                    					
                    pushFollow(FOLLOW_10);
                    ruleExpression();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }

                    this_CLOSEPARENTHESIS_9=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                    					newLeafNode(this_CLOSEPARENTHESIS_9, grammarAccess.getTxOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_1());
                    				

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:713:4: otherlv_10= 'origin'
                    {
                    otherlv_10=(Token)match(input,56,FOLLOW_11); 

                    				newLeafNode(otherlv_10, grammarAccess.getTxOperationAccess().getOriginKeyword_1_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:718:3: (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==RULE_SEMICOLON) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalSM2.g:719:4: this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE
                    {
                    this_SEMICOLON_11=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

                    				newLeafNode(this_SEMICOLON_11, grammarAccess.getTxOperationAccess().getSEMICOLONTerminalRuleCall_2_0());
                    			
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_12, grammarAccess.getTxOperationAccess().getEOLINETerminalRuleCall_2_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTxOperation"


    // $ANTLR start "entryRuleContract"
    // InternalSM2.g:732:1: entryRuleContract returns [EObject current=null] : iv_ruleContract= ruleContract EOF ;
    public final EObject entryRuleContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleContract = null;


        try {
            // InternalSM2.g:732:49: (iv_ruleContract= ruleContract EOF )
            // InternalSM2.g:733:2: iv_ruleContract= ruleContract EOF
            {
             newCompositeNode(grammarAccess.getContractRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleContract=ruleContract();

            state._fsp--;

             current =iv_ruleContract; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleContract"


    // $ANTLR start "ruleContract"
    // InternalSM2.g:739:1: ruleContract returns [EObject current=null] : (otherlv_0= 'contract' ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY ) ;
    public final EObject ruleContract() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameContract_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token this_OPENKEY_4=null;
        Token this_EOLINE_5=null;
        Token this_CLOSEKEY_11=null;
        EObject lv_constructor_6_0 = null;

        EObject lv_comments_7_0 = null;

        EObject lv_attributes_8_0 = null;

        EObject lv_modifier_9_0 = null;

        EObject lv_clauses_10_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:745:2: ( (otherlv_0= 'contract' ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY ) )
            // InternalSM2.g:746:2: (otherlv_0= 'contract' ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY )
            {
            // InternalSM2.g:746:2: (otherlv_0= 'contract' ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY )
            // InternalSM2.g:747:3: otherlv_0= 'contract' ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) ) ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,57,FOLLOW_15); 

            			newLeafNode(otherlv_0, grammarAccess.getContractAccess().getContractKeyword_0());
            		
            // InternalSM2.g:751:3: ( (lv_nameContract_1_0= RULE_ID ) )
            // InternalSM2.g:752:4: (lv_nameContract_1_0= RULE_ID )
            {
            // InternalSM2.g:752:4: (lv_nameContract_1_0= RULE_ID )
            // InternalSM2.g:753:5: lv_nameContract_1_0= RULE_ID
            {
            lv_nameContract_1_0=(Token)match(input,RULE_ID,FOLLOW_16); 

            					newLeafNode(lv_nameContract_1_0, grammarAccess.getContractAccess().getNameContractIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getContractRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameContract",
            						lv_nameContract_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:769:3: (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==58) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalSM2.g:770:4: otherlv_2= 'is' ( (otherlv_3= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,58,FOLLOW_15); 

                    				newLeafNode(otherlv_2, grammarAccess.getContractAccess().getIsKeyword_2_0());
                    			
                    // InternalSM2.g:774:4: ( (otherlv_3= RULE_ID ) )
                    // InternalSM2.g:775:5: (otherlv_3= RULE_ID )
                    {
                    // InternalSM2.g:775:5: (otherlv_3= RULE_ID )
                    // InternalSM2.g:776:6: otherlv_3= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getContractRule());
                    						}
                    					
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_17); 

                    						newLeafNode(otherlv_3, grammarAccess.getContractAccess().getNameContractFatherContractCrossReference_2_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            this_OPENKEY_4=(Token)match(input,RULE_OPENKEY,FOLLOW_18); 

            			newLeafNode(this_OPENKEY_4, grammarAccess.getContractAccess().getOPENKEYTerminalRuleCall_3());
            		
            // InternalSM2.g:792:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==RULE_EOLINE) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalSM2.g:793:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_18); 

                    				newLeafNode(this_EOLINE_5, grammarAccess.getContractAccess().getEOLINETerminalRuleCall_4());
                    			

                    }
                    break;

            }

            // InternalSM2.g:798:3: ( (lv_constructor_6_0= ruleConstructor ) )
            // InternalSM2.g:799:4: (lv_constructor_6_0= ruleConstructor )
            {
            // InternalSM2.g:799:4: (lv_constructor_6_0= ruleConstructor )
            // InternalSM2.g:800:5: lv_constructor_6_0= ruleConstructor
            {

            					newCompositeNode(grammarAccess.getContractAccess().getConstructorConstructorParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_19);
            lv_constructor_6_0=ruleConstructor();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getContractRule());
            					}
            					add(
            						current,
            						"constructor",
            						lv_constructor_6_0,
            						"org.xtext.SM2.Constructor");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:817:3: ( (lv_comments_7_0= ruleComment ) )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( ((LA24_0>=118 && LA24_0<=119)) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalSM2.g:818:4: (lv_comments_7_0= ruleComment )
            	    {
            	    // InternalSM2.g:818:4: (lv_comments_7_0= ruleComment )
            	    // InternalSM2.g:819:5: lv_comments_7_0= ruleComment
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getCommentsCommentParserRuleCall_6_0());
            	    				
            	    pushFollow(FOLLOW_19);
            	    lv_comments_7_0=ruleComment();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"comments",
            	    						lv_comments_7_0,
            	    						"org.xtext.SM2.Comment");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);

            // InternalSM2.g:836:3: ( (lv_attributes_8_0= ruleAttributes ) )*
            loop25:
            do {
                int alt25=2;
                int LA25_0 = input.LA(1);

                if ( (LA25_0==RULE_ID||(LA25_0>=74 && LA25_0<=75)||(LA25_0>=78 && LA25_0<=88)||(LA25_0>=90 && LA25_0<=91)) ) {
                    alt25=1;
                }


                switch (alt25) {
            	case 1 :
            	    // InternalSM2.g:837:4: (lv_attributes_8_0= ruleAttributes )
            	    {
            	    // InternalSM2.g:837:4: (lv_attributes_8_0= ruleAttributes )
            	    // InternalSM2.g:838:5: lv_attributes_8_0= ruleAttributes
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getAttributesAttributesParserRuleCall_7_0());
            	    				
            	    pushFollow(FOLLOW_20);
            	    lv_attributes_8_0=ruleAttributes();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"attributes",
            	    						lv_attributes_8_0,
            	    						"org.xtext.SM2.Attributes");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop25;
                }
            } while (true);

            // InternalSM2.g:855:3: ( (lv_modifier_9_0= ruleModifier ) )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0==68) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalSM2.g:856:4: (lv_modifier_9_0= ruleModifier )
            	    {
            	    // InternalSM2.g:856:4: (lv_modifier_9_0= ruleModifier )
            	    // InternalSM2.g:857:5: lv_modifier_9_0= ruleModifier
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getModifierModifierParserRuleCall_8_0());
            	    				
            	    pushFollow(FOLLOW_21);
            	    lv_modifier_9_0=ruleModifier();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"modifier",
            	    						lv_modifier_9_0,
            	    						"org.xtext.SM2.Modifier");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

            // InternalSM2.g:874:3: ( (lv_clauses_10_0= ruleClause ) )*
            loop27:
            do {
                int alt27=2;
                int LA27_0 = input.LA(1);

                if ( (LA27_0==113) ) {
                    alt27=1;
                }


                switch (alt27) {
            	case 1 :
            	    // InternalSM2.g:875:4: (lv_clauses_10_0= ruleClause )
            	    {
            	    // InternalSM2.g:875:4: (lv_clauses_10_0= ruleClause )
            	    // InternalSM2.g:876:5: lv_clauses_10_0= ruleClause
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getClausesClauseParserRuleCall_9_0());
            	    				
            	    pushFollow(FOLLOW_22);
            	    lv_clauses_10_0=ruleClause();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"clauses",
            	    						lv_clauses_10_0,
            	    						"org.xtext.SM2.Clause");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop27;
                }
            } while (true);

            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); 

            			newLeafNode(this_CLOSEKEY_11, grammarAccess.getContractAccess().getCLOSEKEYTerminalRuleCall_10());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:901:1: entryRuleVersion returns [EObject current=null] : iv_ruleVersion= ruleVersion EOF ;
    public final EObject entryRuleVersion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVersion = null;


        try {
            // InternalSM2.g:901:48: (iv_ruleVersion= ruleVersion EOF )
            // InternalSM2.g:902:2: iv_ruleVersion= ruleVersion EOF
            {
             newCompositeNode(grammarAccess.getVersionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVersion=ruleVersion();

            state._fsp--;

             current =iv_ruleVersion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:908:1: ruleVersion returns [EObject current=null] : (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) (this_SEMICOLON_8= RULE_SEMICOLON | ( (otherlv_9= RULE_ID ) ) ) this_EOLINE_10= RULE_EOLINE ) ;
    public final EObject ruleVersion() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_symbol_2_1=null;
        Token lv_symbol_2_2=null;
        Token lv_symbol_2_3=null;
        Token lv_numberVersion_3_0=null;
        Token this_DOT_4=null;
        Token lv_numberVersion2_5_0=null;
        Token this_DOT_6=null;
        Token lv_numberVersion3_7_0=null;
        Token this_SEMICOLON_8=null;
        Token otherlv_9=null;
        Token this_EOLINE_10=null;


        	enterRule();

        try {
            // InternalSM2.g:914:2: ( (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) (this_SEMICOLON_8= RULE_SEMICOLON | ( (otherlv_9= RULE_ID ) ) ) this_EOLINE_10= RULE_EOLINE ) )
            // InternalSM2.g:915:2: (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) (this_SEMICOLON_8= RULE_SEMICOLON | ( (otherlv_9= RULE_ID ) ) ) this_EOLINE_10= RULE_EOLINE )
            {
            // InternalSM2.g:915:2: (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) (this_SEMICOLON_8= RULE_SEMICOLON | ( (otherlv_9= RULE_ID ) ) ) this_EOLINE_10= RULE_EOLINE )
            // InternalSM2.g:916:3: otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) ) this_DOT_6= RULE_DOT ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) ) (this_SEMICOLON_8= RULE_SEMICOLON | ( (otherlv_9= RULE_ID ) ) ) this_EOLINE_10= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,59,FOLLOW_23); 

            			newLeafNode(otherlv_0, grammarAccess.getVersionAccess().getPragmaKeyword_0());
            		
            otherlv_1=(Token)match(input,60,FOLLOW_24); 

            			newLeafNode(otherlv_1, grammarAccess.getVersionAccess().getSolidityKeyword_1());
            		
            // InternalSM2.g:924:3: ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) )
            // InternalSM2.g:925:4: ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) )
            {
            // InternalSM2.g:925:4: ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) )
            // InternalSM2.g:926:5: (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' )
            {
            // InternalSM2.g:926:5: (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' )
            int alt28=3;
            switch ( input.LA(1) ) {
            case 61:
                {
                alt28=1;
                }
                break;
            case 62:
                {
                alt28=2;
                }
                break;
            case 63:
                {
                alt28=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 28, 0, input);

                throw nvae;
            }

            switch (alt28) {
                case 1 :
                    // InternalSM2.g:927:6: lv_symbol_2_1= '^'
                    {
                    lv_symbol_2_1=(Token)match(input,61,FOLLOW_25); 

                    						newLeafNode(lv_symbol_2_1, grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_2_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_2_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:938:6: lv_symbol_2_2= '>'
                    {
                    lv_symbol_2_2=(Token)match(input,62,FOLLOW_25); 

                    						newLeafNode(lv_symbol_2_2, grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_2_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_2_2, null);
                    					

                    }
                    break;
                case 3 :
                    // InternalSM2.g:949:6: lv_symbol_2_3= '>='
                    {
                    lv_symbol_2_3=(Token)match(input,63,FOLLOW_25); 

                    						newLeafNode(lv_symbol_2_3, grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_2_0_2());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_2_3, null);
                    					

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:962:3: ( (lv_numberVersion_3_0= RULE_NUMVERSION1 ) )
            // InternalSM2.g:963:4: (lv_numberVersion_3_0= RULE_NUMVERSION1 )
            {
            // InternalSM2.g:963:4: (lv_numberVersion_3_0= RULE_NUMVERSION1 )
            // InternalSM2.g:964:5: lv_numberVersion_3_0= RULE_NUMVERSION1
            {
            lv_numberVersion_3_0=(Token)match(input,RULE_NUMVERSION1,FOLLOW_6); 

            					newLeafNode(lv_numberVersion_3_0, grammarAccess.getVersionAccess().getNumberVersionNUMVERSION1TerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVersionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"numberVersion",
            						lv_numberVersion_3_0,
            						"org.xtext.SM2.NUMVERSION1");
            				

            }


            }

            this_DOT_4=(Token)match(input,RULE_DOT,FOLLOW_26); 

            			newLeafNode(this_DOT_4, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_4());
            		
            // InternalSM2.g:984:3: ( (lv_numberVersion2_5_0= RULE_NUMVERSION2 ) )
            // InternalSM2.g:985:4: (lv_numberVersion2_5_0= RULE_NUMVERSION2 )
            {
            // InternalSM2.g:985:4: (lv_numberVersion2_5_0= RULE_NUMVERSION2 )
            // InternalSM2.g:986:5: lv_numberVersion2_5_0= RULE_NUMVERSION2
            {
            lv_numberVersion2_5_0=(Token)match(input,RULE_NUMVERSION2,FOLLOW_6); 

            					newLeafNode(lv_numberVersion2_5_0, grammarAccess.getVersionAccess().getNumberVersion2NUMVERSION2TerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVersionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"numberVersion2",
            						lv_numberVersion2_5_0,
            						"org.xtext.SM2.NUMVERSION2");
            				

            }


            }

            this_DOT_6=(Token)match(input,RULE_DOT,FOLLOW_27); 

            			newLeafNode(this_DOT_6, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_6());
            		
            // InternalSM2.g:1006:3: ( (lv_numberVersion3_7_0= RULE_NUMVERSION3 ) )
            // InternalSM2.g:1007:4: (lv_numberVersion3_7_0= RULE_NUMVERSION3 )
            {
            // InternalSM2.g:1007:4: (lv_numberVersion3_7_0= RULE_NUMVERSION3 )
            // InternalSM2.g:1008:5: lv_numberVersion3_7_0= RULE_NUMVERSION3
            {
            lv_numberVersion3_7_0=(Token)match(input,RULE_NUMVERSION3,FOLLOW_28); 

            					newLeafNode(lv_numberVersion3_7_0, grammarAccess.getVersionAccess().getNumberVersion3NUMVERSION3TerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVersionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"numberVersion3",
            						lv_numberVersion3_7_0,
            						"org.xtext.SM2.NUMVERSION3");
            				

            }


            }

            // InternalSM2.g:1024:3: (this_SEMICOLON_8= RULE_SEMICOLON | ( (otherlv_9= RULE_ID ) ) )
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==RULE_SEMICOLON) ) {
                alt29=1;
            }
            else if ( (LA29_0==RULE_ID) ) {
                alt29=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 29, 0, input);

                throw nvae;
            }
            switch (alt29) {
                case 1 :
                    // InternalSM2.g:1025:4: this_SEMICOLON_8= RULE_SEMICOLON
                    {
                    this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

                    				newLeafNode(this_SEMICOLON_8, grammarAccess.getVersionAccess().getSEMICOLONTerminalRuleCall_8_0());
                    			

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1030:4: ( (otherlv_9= RULE_ID ) )
                    {
                    // InternalSM2.g:1030:4: ( (otherlv_9= RULE_ID ) )
                    // InternalSM2.g:1031:5: (otherlv_9= RULE_ID )
                    {
                    // InternalSM2.g:1031:5: (otherlv_9= RULE_ID )
                    // InternalSM2.g:1032:6: otherlv_9= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    					
                    otherlv_9=(Token)match(input,RULE_ID,FOLLOW_12); 

                    						newLeafNode(otherlv_9, grammarAccess.getVersionAccess().getOptionalversionVersionCrossReference_8_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_10, grammarAccess.getVersionAccess().getEOLINETerminalRuleCall_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleConstructor"
    // InternalSM2.g:1052:1: entryRuleConstructor returns [EObject current=null] : iv_ruleConstructor= ruleConstructor EOF ;
    public final EObject entryRuleConstructor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConstructor = null;


        try {
            // InternalSM2.g:1052:52: (iv_ruleConstructor= ruleConstructor EOF )
            // InternalSM2.g:1053:2: iv_ruleConstructor= ruleConstructor EOF
            {
             newCompositeNode(grammarAccess.getConstructorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConstructor=ruleConstructor();

            state._fsp--;

             current =iv_ruleConstructor; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConstructor"


    // $ANTLR start "ruleConstructor"
    // InternalSM2.g:1059:1: ruleConstructor returns [EObject current=null] : (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY ) ;
    public final EObject ruleConstructor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_type_3_1=null;
        Token lv_type_3_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_CLOSEKEY_7=null;
        EObject lv_inputParams_2_0 = null;

        EObject lv_Attributes_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1065:2: ( (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY ) )
            // InternalSM2.g:1066:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY )
            {
            // InternalSM2.g:1066:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY )
            // InternalSM2.g:1067:3: otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,64,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getConstructorAccess().getConstructorKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_29); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConstructorAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:1075:3: ( (lv_inputParams_2_0= ruleInputParam ) )*
            loop30:
            do {
                int alt30=2;
                int LA30_0 = input.LA(1);

                if ( ((LA30_0>=70 && LA30_0<=77)) ) {
                    alt30=1;
                }


                switch (alt30) {
            	case 1 :
            	    // InternalSM2.g:1076:4: (lv_inputParams_2_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1076:4: (lv_inputParams_2_0= ruleInputParam )
            	    // InternalSM2.g:1077:5: lv_inputParams_2_0= ruleInputParam
            	    {

            	    					newCompositeNode(grammarAccess.getConstructorAccess().getInputParamsInputParamParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_29);
            	    lv_inputParams_2_0=ruleInputParam();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConstructorRule());
            	    					}
            	    					add(
            	    						current,
            	    						"inputParams",
            	    						lv_inputParams_2_0,
            	    						"org.xtext.SM2.InputParam");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop30;
                }
            } while (true);

            // InternalSM2.g:1094:3: ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) )
            // InternalSM2.g:1095:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            {
            // InternalSM2.g:1095:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            // InternalSM2.g:1096:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            {
            // InternalSM2.g:1096:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==65) ) {
                alt31=1;
            }
            else if ( (LA31_0==66) ) {
                alt31=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 31, 0, input);

                throw nvae;
            }
            switch (alt31) {
                case 1 :
                    // InternalSM2.g:1097:6: lv_type_3_1= 'public'
                    {
                    lv_type_3_1=(Token)match(input,65,FOLLOW_10); 

                    						newLeafNode(lv_type_3_1, grammarAccess.getConstructorAccess().getTypePublicKeyword_3_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getConstructorRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_3_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1108:6: lv_type_3_2= 'internal'
                    {
                    lv_type_3_2=(Token)match(input,66,FOLLOW_10); 

                    						newLeafNode(lv_type_3_2, grammarAccess.getConstructorAccess().getTypeInternalKeyword_3_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getConstructorRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_3_2, null);
                    					

                    }
                    break;

            }


            }


            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_17); 

            			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getConstructorAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
            		
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_30); 

            			newLeafNode(this_OPENKEY_5, grammarAccess.getConstructorAccess().getOPENKEYTerminalRuleCall_5());
            		
            // InternalSM2.g:1129:3: ( (lv_Attributes_6_0= ruleAttributes ) )
            // InternalSM2.g:1130:4: (lv_Attributes_6_0= ruleAttributes )
            {
            // InternalSM2.g:1130:4: (lv_Attributes_6_0= ruleAttributes )
            // InternalSM2.g:1131:5: lv_Attributes_6_0= ruleAttributes
            {

            					newCompositeNode(grammarAccess.getConstructorAccess().getAttributesAttributesParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_31);
            lv_Attributes_6_0=ruleAttributes();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getConstructorRule());
            					}
            					add(
            						current,
            						"Attributes",
            						lv_Attributes_6_0,
            						"org.xtext.SM2.Attributes");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); 

            			newLeafNode(this_CLOSEKEY_7, grammarAccess.getConstructorAccess().getCLOSEKEYTerminalRuleCall_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConstructor"


    // $ANTLR start "entryRuleImport"
    // InternalSM2.g:1156:1: entryRuleImport returns [String current=null] : iv_ruleImport= ruleImport EOF ;
    public final String entryRuleImport() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleImport = null;


        try {
            // InternalSM2.g:1156:46: (iv_ruleImport= ruleImport EOF )
            // InternalSM2.g:1157:2: iv_ruleImport= ruleImport EOF
            {
             newCompositeNode(grammarAccess.getImportRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleImport=ruleImport();

            state._fsp--;

             current =iv_ruleImport.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2.g:1163:1: ruleImport returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? ) ;
    public final AntlrDatatypeRuleToken ruleImport() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_STRING_1=null;
        Token this_SEMICOLON_2=null;
        Token this_EOLINE_3=null;


        	enterRule();

        try {
            // InternalSM2.g:1169:2: ( (kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? ) )
            // InternalSM2.g:1170:2: (kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? )
            {
            // InternalSM2.g:1170:2: (kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? )
            // InternalSM2.g:1171:3: kw= 'import' this_STRING_1= RULE_STRING this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )?
            {
            kw=(Token)match(input,67,FOLLOW_32); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getImportAccess().getImportKeyword_0());
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_33); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getImportAccess().getSTRINGTerminalRuleCall_1());
            		
            this_SEMICOLON_2=(Token)match(input,RULE_SEMICOLON,FOLLOW_34); 

            			current.merge(this_SEMICOLON_2);
            		

            			newLeafNode(this_SEMICOLON_2, grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_2());
            		
            // InternalSM2.g:1190:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==RULE_EOLINE) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalSM2.g:1191:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				current.merge(this_EOLINE_3);
                    			

                    				newLeafNode(this_EOLINE_3, grammarAccess.getImportAccess().getEOLINETerminalRuleCall_3());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:1203:1: entryRuleAttributes returns [EObject current=null] : iv_ruleAttributes= ruleAttributes EOF ;
    public final EObject entryRuleAttributes() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttributes = null;


        try {
            // InternalSM2.g:1203:51: (iv_ruleAttributes= ruleAttributes EOF )
            // InternalSM2.g:1204:2: iv_ruleAttributes= ruleAttributes EOF
            {
             newCompositeNode(grammarAccess.getAttributesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAttributes=ruleAttributes();

            state._fsp--;

             current =iv_ruleAttributes; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:1210:1: ruleAttributes returns [EObject current=null] : this_DataType_0= ruleDataType ;
    public final EObject ruleAttributes() throws RecognitionException {
        EObject current = null;

        EObject this_DataType_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1216:2: (this_DataType_0= ruleDataType )
            // InternalSM2.g:1217:2: this_DataType_0= ruleDataType
            {

            		newCompositeNode(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall());
            	
            pushFollow(FOLLOW_2);
            this_DataType_0=ruleDataType();

            state._fsp--;


            		current = this_DataType_0;
            		afterParserOrEnumRuleCall();
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:1228:1: entryRuleModifier returns [EObject current=null] : iv_ruleModifier= ruleModifier EOF ;
    public final EObject entryRuleModifier() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModifier = null;


        try {
            // InternalSM2.g:1228:49: (iv_ruleModifier= ruleModifier EOF )
            // InternalSM2.g:1229:2: iv_ruleModifier= ruleModifier EOF
            {
             newCompositeNode(grammarAccess.getModifierRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModifier=ruleModifier();

            state._fsp--;

             current =iv_ruleModifier; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:1235:1: ruleModifier returns [EObject current=null] : (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? ) ;
    public final EObject ruleModifier() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameModifier_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_EOLINE_6=null;
        Token lv_expr_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Token otherlv_10=null;
        Token this_CLOSEKEY_11=null;
        Token this_EOLINE_12=null;
        EObject lv_inputParams_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1241:2: ( (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? ) )
            // InternalSM2.g:1242:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? )
            {
            // InternalSM2.g:1242:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? )
            // InternalSM2.g:1243:3: otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,68,FOLLOW_15); 

            			newLeafNode(otherlv_0, grammarAccess.getModifierAccess().getModifierKeyword_0());
            		
            // InternalSM2.g:1247:3: ( (lv_nameModifier_1_0= RULE_ID ) )
            // InternalSM2.g:1248:4: (lv_nameModifier_1_0= RULE_ID )
            {
            // InternalSM2.g:1248:4: (lv_nameModifier_1_0= RULE_ID )
            // InternalSM2.g:1249:5: lv_nameModifier_1_0= RULE_ID
            {
            lv_nameModifier_1_0=(Token)match(input,RULE_ID,FOLLOW_8); 

            					newLeafNode(lv_nameModifier_1_0, grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getModifierRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameModifier",
            						lv_nameModifier_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_35); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		
            // InternalSM2.g:1269:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop33:
            do {
                int alt33=2;
                int LA33_0 = input.LA(1);

                if ( ((LA33_0>=70 && LA33_0<=77)) ) {
                    alt33=1;
                }


                switch (alt33) {
            	case 1 :
            	    // InternalSM2.g:1270:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1270:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:1271:5: lv_inputParams_3_0= ruleInputParam
            	    {

            	    					newCompositeNode(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_35);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModifierRule());
            	    					}
            	    					add(
            	    						current,
            	    						"inputParams",
            	    						lv_inputParams_3_0,
            	    						"org.xtext.SM2.InputParam");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop33;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_17); 

            			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
            		
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_36); 

            			newLeafNode(this_OPENKEY_5, grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5());
            		
            // InternalSM2.g:1296:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==RULE_EOLINE) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalSM2.g:1297:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_32); 

                    				newLeafNode(this_EOLINE_6, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }

            // InternalSM2.g:1302:3: ( (lv_expr_7_0= RULE_STRING ) )
            // InternalSM2.g:1303:4: (lv_expr_7_0= RULE_STRING )
            {
            // InternalSM2.g:1303:4: (lv_expr_7_0= RULE_STRING )
            // InternalSM2.g:1304:5: lv_expr_7_0= RULE_STRING
            {
            lv_expr_7_0=(Token)match(input,RULE_STRING,FOLLOW_33); 

            					newLeafNode(lv_expr_7_0, grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getModifierRule());
            					}
            					setWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_37); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8());
            		
            // InternalSM2.g:1324:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==RULE_EOLINE) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalSM2.g:1325:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_38); 

                    				newLeafNode(this_EOLINE_9, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9());
                    			

                    }
                    break;

            }

            otherlv_10=(Token)match(input,69,FOLLOW_31); 

            			newLeafNode(otherlv_10, grammarAccess.getModifierAccess().get_Keyword_10());
            		
            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_34); 

            			newLeafNode(this_CLOSEKEY_11, grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11());
            		
            // InternalSM2.g:1338:3: (this_EOLINE_12= RULE_EOLINE )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==RULE_EOLINE) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalSM2.g:1339:4: this_EOLINE_12= RULE_EOLINE
                    {
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_12, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:1348:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalSM2.g:1348:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalSM2.g:1349:2: iv_ruleDataType= ruleDataType EOF
            {
             newCompositeNode(grammarAccess.getDataTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;

             current =iv_ruleDataType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:1355:1: ruleDataType returns [EObject current=null] : (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID | ruleTypeAddress | ruleTypeBytes ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        Token this_ID_2=null;
        EObject this_CompositeType_0 = null;

        EObject this_Enum_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1361:2: ( (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID | ruleTypeAddress | ruleTypeBytes ) )
            // InternalSM2.g:1362:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID | ruleTypeAddress | ruleTypeBytes )
            {
            // InternalSM2.g:1362:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID | ruleTypeAddress | ruleTypeBytes )
            int alt37=5;
            switch ( input.LA(1) ) {
            case 88:
            case 90:
                {
                alt37=1;
                }
                break;
            case 91:
                {
                alt37=2;
                }
                break;
            case RULE_ID:
                {
                alt37=3;
                }
                break;
            case 74:
            case 75:
                {
                alt37=4;
                }
                break;
            case 78:
            case 79:
            case 80:
            case 81:
            case 82:
            case 83:
            case 84:
            case 85:
            case 86:
            case 87:
                {
                alt37=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 37, 0, input);

                throw nvae;
            }

            switch (alt37) {
                case 1 :
                    // InternalSM2.g:1363:3: this_CompositeType_0= ruleCompositeType
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_CompositeType_0=ruleCompositeType();

                    state._fsp--;


                    			current = this_CompositeType_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1372:3: this_Enum_1= ruleEnum
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Enum_1=ruleEnum();

                    state._fsp--;


                    			current = this_Enum_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1381:3: this_ID_2= RULE_ID
                    {
                    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			newLeafNode(this_ID_2, grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:1386:3: ruleTypeAddress
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getTypeAddressParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    ruleTypeAddress();

                    state._fsp--;


                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:1394:3: ruleTypeBytes
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getTypeBytesParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    ruleTypeBytes();

                    state._fsp--;


                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2.g:1405:1: entryRuleCompositeType returns [EObject current=null] : iv_ruleCompositeType= ruleCompositeType EOF ;
    public final EObject entryRuleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompositeType = null;


        try {
            // InternalSM2.g:1405:54: (iv_ruleCompositeType= ruleCompositeType EOF )
            // InternalSM2.g:1406:2: iv_ruleCompositeType= ruleCompositeType EOF
            {
             newCompositeNode(grammarAccess.getCompositeTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCompositeType=ruleCompositeType();

            state._fsp--;

             current =iv_ruleCompositeType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2.g:1412:1: ruleCompositeType returns [EObject current=null] : (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) ;
    public final EObject ruleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject this_Mapping_0 = null;

        EObject this_Struct_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1418:2: ( (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) )
            // InternalSM2.g:1419:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            {
            // InternalSM2.g:1419:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==88) ) {
                alt38=1;
            }
            else if ( (LA38_0==90) ) {
                alt38=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 38, 0, input);

                throw nvae;
            }
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:1420:3: this_Mapping_0= ruleMapping
                    {

                    			newCompositeNode(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Mapping_0=ruleMapping();

                    state._fsp--;


                    			current = this_Mapping_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1429:3: this_Struct_1= ruleStruct
                    {

                    			newCompositeNode(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Struct_1=ruleStruct();

                    state._fsp--;


                    			current = this_Struct_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleSingularType"
    // InternalSM2.g:1441:1: entryRuleSingularType returns [EObject current=null] : iv_ruleSingularType= ruleSingularType EOF ;
    public final EObject entryRuleSingularType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSingularType = null;


        try {
            // InternalSM2.g:1441:53: (iv_ruleSingularType= ruleSingularType EOF )
            // InternalSM2.g:1442:2: iv_ruleSingularType= ruleSingularType EOF
            {
             newCompositeNode(grammarAccess.getSingularTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSingularType=ruleSingularType();

            state._fsp--;

             current =iv_ruleSingularType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSingularType"


    // $ANTLR start "ruleSingularType"
    // InternalSM2.g:1448:1: ruleSingularType returns [EObject current=null] : (otherlv_0= 'int' | otherlv_1= 'uint' | otherlv_2= 'uint8' | otherlv_3= 'string' | otherlv_4= 'address' | otherlv_5= 'address payable' | otherlv_6= 'double' | otherlv_7= 'bool' ) ;
    public final EObject ruleSingularType() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;


        	enterRule();

        try {
            // InternalSM2.g:1454:2: ( (otherlv_0= 'int' | otherlv_1= 'uint' | otherlv_2= 'uint8' | otherlv_3= 'string' | otherlv_4= 'address' | otherlv_5= 'address payable' | otherlv_6= 'double' | otherlv_7= 'bool' ) )
            // InternalSM2.g:1455:2: (otherlv_0= 'int' | otherlv_1= 'uint' | otherlv_2= 'uint8' | otherlv_3= 'string' | otherlv_4= 'address' | otherlv_5= 'address payable' | otherlv_6= 'double' | otherlv_7= 'bool' )
            {
            // InternalSM2.g:1455:2: (otherlv_0= 'int' | otherlv_1= 'uint' | otherlv_2= 'uint8' | otherlv_3= 'string' | otherlv_4= 'address' | otherlv_5= 'address payable' | otherlv_6= 'double' | otherlv_7= 'bool' )
            int alt39=8;
            switch ( input.LA(1) ) {
            case 70:
                {
                alt39=1;
                }
                break;
            case 71:
                {
                alt39=2;
                }
                break;
            case 72:
                {
                alt39=3;
                }
                break;
            case 73:
                {
                alt39=4;
                }
                break;
            case 74:
                {
                alt39=5;
                }
                break;
            case 75:
                {
                alt39=6;
                }
                break;
            case 76:
                {
                alt39=7;
                }
                break;
            case 77:
                {
                alt39=8;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 39, 0, input);

                throw nvae;
            }

            switch (alt39) {
                case 1 :
                    // InternalSM2.g:1456:3: otherlv_0= 'int'
                    {
                    otherlv_0=(Token)match(input,70,FOLLOW_2); 

                    			newLeafNode(otherlv_0, grammarAccess.getSingularTypeAccess().getIntKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1461:3: otherlv_1= 'uint'
                    {
                    otherlv_1=(Token)match(input,71,FOLLOW_2); 

                    			newLeafNode(otherlv_1, grammarAccess.getSingularTypeAccess().getUintKeyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1466:3: otherlv_2= 'uint8'
                    {
                    otherlv_2=(Token)match(input,72,FOLLOW_2); 

                    			newLeafNode(otherlv_2, grammarAccess.getSingularTypeAccess().getUint8Keyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:1471:3: otherlv_3= 'string'
                    {
                    otherlv_3=(Token)match(input,73,FOLLOW_2); 

                    			newLeafNode(otherlv_3, grammarAccess.getSingularTypeAccess().getStringKeyword_3());
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:1476:3: otherlv_4= 'address'
                    {
                    otherlv_4=(Token)match(input,74,FOLLOW_2); 

                    			newLeafNode(otherlv_4, grammarAccess.getSingularTypeAccess().getAddressKeyword_4());
                    		

                    }
                    break;
                case 6 :
                    // InternalSM2.g:1481:3: otherlv_5= 'address payable'
                    {
                    otherlv_5=(Token)match(input,75,FOLLOW_2); 

                    			newLeafNode(otherlv_5, grammarAccess.getSingularTypeAccess().getAddressPayableKeyword_5());
                    		

                    }
                    break;
                case 7 :
                    // InternalSM2.g:1486:3: otherlv_6= 'double'
                    {
                    otherlv_6=(Token)match(input,76,FOLLOW_2); 

                    			newLeafNode(otherlv_6, grammarAccess.getSingularTypeAccess().getDoubleKeyword_6());
                    		

                    }
                    break;
                case 8 :
                    // InternalSM2.g:1491:3: otherlv_7= 'bool'
                    {
                    otherlv_7=(Token)match(input,77,FOLLOW_2); 

                    			newLeafNode(otherlv_7, grammarAccess.getSingularTypeAccess().getBoolKeyword_7());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "entryRuleTypeAddress"
    // InternalSM2.g:1499:1: entryRuleTypeAddress returns [String current=null] : iv_ruleTypeAddress= ruleTypeAddress EOF ;
    public final String entryRuleTypeAddress() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeAddress = null;


        try {
            // InternalSM2.g:1499:51: (iv_ruleTypeAddress= ruleTypeAddress EOF )
            // InternalSM2.g:1500:2: iv_ruleTypeAddress= ruleTypeAddress EOF
            {
             newCompositeNode(grammarAccess.getTypeAddressRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeAddress=ruleTypeAddress();

            state._fsp--;

             current =iv_ruleTypeAddress.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeAddress"


    // $ANTLR start "ruleTypeAddress"
    // InternalSM2.g:1506:1: ruleTypeAddress returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'address' | kw= 'address payable' ) ;
    public final AntlrDatatypeRuleToken ruleTypeAddress() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSM2.g:1512:2: ( (kw= 'address' | kw= 'address payable' ) )
            // InternalSM2.g:1513:2: (kw= 'address' | kw= 'address payable' )
            {
            // InternalSM2.g:1513:2: (kw= 'address' | kw= 'address payable' )
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==74) ) {
                alt40=1;
            }
            else if ( (LA40_0==75) ) {
                alt40=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 40, 0, input);

                throw nvae;
            }
            switch (alt40) {
                case 1 :
                    // InternalSM2.g:1514:3: kw= 'address'
                    {
                    kw=(Token)match(input,74,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAddressAccess().getAddressKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1520:3: kw= 'address payable'
                    {
                    kw=(Token)match(input,75,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAddressAccess().getAddressPayableKeyword_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeAddress"


    // $ANTLR start "entryRuleTypeBytes"
    // InternalSM2.g:1529:1: entryRuleTypeBytes returns [String current=null] : iv_ruleTypeBytes= ruleTypeBytes EOF ;
    public final String entryRuleTypeBytes() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeBytes = null;


        try {
            // InternalSM2.g:1529:49: (iv_ruleTypeBytes= ruleTypeBytes EOF )
            // InternalSM2.g:1530:2: iv_ruleTypeBytes= ruleTypeBytes EOF
            {
             newCompositeNode(grammarAccess.getTypeBytesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeBytes=ruleTypeBytes();

            state._fsp--;

             current =iv_ruleTypeBytes.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeBytes"


    // $ANTLR start "ruleTypeBytes"
    // InternalSM2.g:1536:1: ruleTypeBytes returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'bytes' | kw= 'bytes2' | kw= 'bytes3' | kw= 'bytes4' | kw= 'bytes5' | kw= 'bytes6' | kw= 'bytes7' | kw= 'bytes8' | kw= 'bytes16' | kw= 'bytes32' ) ;
    public final AntlrDatatypeRuleToken ruleTypeBytes() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSM2.g:1542:2: ( (kw= 'bytes' | kw= 'bytes2' | kw= 'bytes3' | kw= 'bytes4' | kw= 'bytes5' | kw= 'bytes6' | kw= 'bytes7' | kw= 'bytes8' | kw= 'bytes16' | kw= 'bytes32' ) )
            // InternalSM2.g:1543:2: (kw= 'bytes' | kw= 'bytes2' | kw= 'bytes3' | kw= 'bytes4' | kw= 'bytes5' | kw= 'bytes6' | kw= 'bytes7' | kw= 'bytes8' | kw= 'bytes16' | kw= 'bytes32' )
            {
            // InternalSM2.g:1543:2: (kw= 'bytes' | kw= 'bytes2' | kw= 'bytes3' | kw= 'bytes4' | kw= 'bytes5' | kw= 'bytes6' | kw= 'bytes7' | kw= 'bytes8' | kw= 'bytes16' | kw= 'bytes32' )
            int alt41=10;
            switch ( input.LA(1) ) {
            case 78:
                {
                alt41=1;
                }
                break;
            case 79:
                {
                alt41=2;
                }
                break;
            case 80:
                {
                alt41=3;
                }
                break;
            case 81:
                {
                alt41=4;
                }
                break;
            case 82:
                {
                alt41=5;
                }
                break;
            case 83:
                {
                alt41=6;
                }
                break;
            case 84:
                {
                alt41=7;
                }
                break;
            case 85:
                {
                alt41=8;
                }
                break;
            case 86:
                {
                alt41=9;
                }
                break;
            case 87:
                {
                alt41=10;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 41, 0, input);

                throw nvae;
            }

            switch (alt41) {
                case 1 :
                    // InternalSM2.g:1544:3: kw= 'bytes'
                    {
                    kw=(Token)match(input,78,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytesKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1550:3: kw= 'bytes2'
                    {
                    kw=(Token)match(input,79,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes2Keyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1556:3: kw= 'bytes3'
                    {
                    kw=(Token)match(input,80,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes3Keyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:1562:3: kw= 'bytes4'
                    {
                    kw=(Token)match(input,81,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes4Keyword_3());
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:1568:3: kw= 'bytes5'
                    {
                    kw=(Token)match(input,82,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes5Keyword_4());
                    		

                    }
                    break;
                case 6 :
                    // InternalSM2.g:1574:3: kw= 'bytes6'
                    {
                    kw=(Token)match(input,83,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes6Keyword_5());
                    		

                    }
                    break;
                case 7 :
                    // InternalSM2.g:1580:3: kw= 'bytes7'
                    {
                    kw=(Token)match(input,84,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes7Keyword_6());
                    		

                    }
                    break;
                case 8 :
                    // InternalSM2.g:1586:3: kw= 'bytes8'
                    {
                    kw=(Token)match(input,85,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes8Keyword_7());
                    		

                    }
                    break;
                case 9 :
                    // InternalSM2.g:1592:3: kw= 'bytes16'
                    {
                    kw=(Token)match(input,86,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes16Keyword_8());
                    		

                    }
                    break;
                case 10 :
                    // InternalSM2.g:1598:3: kw= 'bytes32'
                    {
                    kw=(Token)match(input,87,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes32Keyword_9());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeBytes"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:1607:1: entryRuleMapping returns [EObject current=null] : iv_ruleMapping= ruleMapping EOF ;
    public final EObject entryRuleMapping() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMapping = null;


        try {
            // InternalSM2.g:1607:48: (iv_ruleMapping= ruleMapping EOF )
            // InternalSM2.g:1608:2: iv_ruleMapping= ruleMapping EOF
            {
             newCompositeNode(grammarAccess.getMappingRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMapping=ruleMapping();

            state._fsp--;

             current =iv_ruleMapping; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:1614:1: ruleMapping returns [EObject current=null] : (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON ) ;
    public final EObject ruleMapping() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_3=null;
        Token lv_expr_4_0=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token lv_nameMapping_7_0=null;
        Token this_SEMICOLON_8=null;
        EObject lv_type_2_0 = null;

        Enumerator lv_visibility_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1620:2: ( (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON ) )
            // InternalSM2.g:1621:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON )
            {
            // InternalSM2.g:1621:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON )
            // InternalSM2.g:1622:3: otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON
            {
            otherlv_0=(Token)match(input,88,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getMappingAccess().getMappingKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_39); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:1630:3: ( (lv_type_2_0= ruleSingularType ) )
            // InternalSM2.g:1631:4: (lv_type_2_0= ruleSingularType )
            {
            // InternalSM2.g:1631:4: (lv_type_2_0= ruleSingularType )
            // InternalSM2.g:1632:5: lv_type_2_0= ruleSingularType
            {

            					newCompositeNode(grammarAccess.getMappingAccess().getTypeSingularTypeParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_40);
            lv_type_2_0=ruleSingularType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMappingRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_2_0,
            						"org.xtext.SM2.SingularType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,89,FOLLOW_32); 

            			newLeafNode(otherlv_3, grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3());
            		
            // InternalSM2.g:1653:3: ( (lv_expr_4_0= RULE_STRING ) )
            // InternalSM2.g:1654:4: (lv_expr_4_0= RULE_STRING )
            {
            // InternalSM2.g:1654:4: (lv_expr_4_0= RULE_STRING )
            // InternalSM2.g:1655:5: lv_expr_4_0= RULE_STRING
            {
            lv_expr_4_0=(Token)match(input,RULE_STRING,FOLLOW_10); 

            					newLeafNode(lv_expr_4_0, grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMappingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_4_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_41); 

            			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
            		
            // InternalSM2.g:1675:3: ( (lv_visibility_6_0= ruleVisibility ) )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( ((LA42_0>=65 && LA42_0<=66)||LA42_0==122) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalSM2.g:1676:4: (lv_visibility_6_0= ruleVisibility )
                    {
                    // InternalSM2.g:1676:4: (lv_visibility_6_0= ruleVisibility )
                    // InternalSM2.g:1677:5: lv_visibility_6_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0());
                    				
                    pushFollow(FOLLOW_15);
                    lv_visibility_6_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getMappingRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_6_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:1694:3: ( (lv_nameMapping_7_0= RULE_ID ) )
            // InternalSM2.g:1695:4: (lv_nameMapping_7_0= RULE_ID )
            {
            // InternalSM2.g:1695:4: (lv_nameMapping_7_0= RULE_ID )
            // InternalSM2.g:1696:5: lv_nameMapping_7_0= RULE_ID
            {
            lv_nameMapping_7_0=(Token)match(input,RULE_ID,FOLLOW_33); 

            					newLeafNode(lv_nameMapping_7_0, grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMappingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameMapping",
            						lv_nameMapping_7_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:1720:1: entryRuleStruct returns [EObject current=null] : iv_ruleStruct= ruleStruct EOF ;
    public final EObject entryRuleStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStruct = null;


        try {
            // InternalSM2.g:1720:47: (iv_ruleStruct= ruleStruct EOF )
            // InternalSM2.g:1721:2: iv_ruleStruct= ruleStruct EOF
            {
             newCompositeNode(grammarAccess.getStructRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStruct=ruleStruct();

            state._fsp--;

             current =iv_ruleStruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:1727:1: ruleStruct returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject ruleStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_CLOSEKEY_5=null;
        Token this_EOLINE_6=null;
        EObject lv_properties_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1733:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1734:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1734:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1735:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,90,FOLLOW_15); 

            			newLeafNode(otherlv_0, grammarAccess.getStructAccess().getStructKeyword_0());
            		
            // InternalSM2.g:1739:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1740:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1740:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1741:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_17); 

            					newLeafNode(lv_nameStruct_1_0, grammarAccess.getStructAccess().getNameStructIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getStructRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameStruct",
            						lv_nameStruct_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_42); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getStructAccess().getOPENKEYTerminalRuleCall_2());
            		
            // InternalSM2.g:1761:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==RULE_EOLINE) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalSM2.g:1762:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_43); 

                    				newLeafNode(this_EOLINE_3, grammarAccess.getStructAccess().getEOLINETerminalRuleCall_3());
                    			

                    }
                    break;

            }

            // InternalSM2.g:1767:3: ( (lv_properties_4_0= ruleProperty ) )
            // InternalSM2.g:1768:4: (lv_properties_4_0= ruleProperty )
            {
            // InternalSM2.g:1768:4: (lv_properties_4_0= ruleProperty )
            // InternalSM2.g:1769:5: lv_properties_4_0= ruleProperty
            {

            					newCompositeNode(grammarAccess.getStructAccess().getPropertiesPropertyParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_31);
            lv_properties_4_0=ruleProperty();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getStructRule());
            					}
            					add(
            						current,
            						"properties",
            						lv_properties_4_0,
            						"org.xtext.SM2.Property");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_34); 

            			newLeafNode(this_CLOSEKEY_5, grammarAccess.getStructAccess().getCLOSEKEYTerminalRuleCall_5());
            		
            // InternalSM2.g:1790:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==RULE_EOLINE) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:1791:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_6, grammarAccess.getStructAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:1800:1: entryRuleEnum returns [EObject current=null] : iv_ruleEnum= ruleEnum EOF ;
    public final EObject entryRuleEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnum = null;


        try {
            // InternalSM2.g:1800:45: (iv_ruleEnum= ruleEnum EOF )
            // InternalSM2.g:1801:2: iv_ruleEnum= ruleEnum EOF
            {
             newCompositeNode(grammarAccess.getEnumRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEnum=ruleEnum();

            state._fsp--;

             current =iv_ruleEnum; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:1807:1: ruleEnum returns [EObject current=null] : (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_ID_1=null;
        Token this_OPENKEY_2=null;
        Token this_STRING_3=null;
        Token this_COMMA_4=null;
        Token this_CLOSEKEY_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;


        	enterRule();

        try {
            // InternalSM2.g:1813:2: ( (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:1814:2: (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:1814:2: (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:1815:3: otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,91,FOLLOW_15); 

            			newLeafNode(otherlv_0, grammarAccess.getEnumAccess().getEnumKeyword_0());
            		
            this_ID_1=(Token)match(input,RULE_ID,FOLLOW_17); 

            			newLeafNode(this_ID_1, grammarAccess.getEnumAccess().getIDTerminalRuleCall_1());
            		
            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_32); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2());
            		
            this_STRING_3=(Token)match(input,RULE_STRING,FOLLOW_44); 

            			newLeafNode(this_STRING_3, grammarAccess.getEnumAccess().getSTRINGTerminalRuleCall_3());
            		
            // InternalSM2.g:1831:3: (this_COMMA_4= RULE_COMMA )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==RULE_COMMA) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalSM2.g:1832:4: this_COMMA_4= RULE_COMMA
                    {
                    this_COMMA_4=(Token)match(input,RULE_COMMA,FOLLOW_31); 

                    				newLeafNode(this_COMMA_4, grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_4());
                    			

                    }
                    break;

            }

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_33); 

            			newLeafNode(this_CLOSEKEY_5, grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_5());
            		
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_34); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:1845:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==RULE_EOLINE) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:1846:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleArray"
    // InternalSM2.g:1855:1: entryRuleArray returns [String current=null] : iv_ruleArray= ruleArray EOF ;
    public final String entryRuleArray() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleArray = null;


        try {
            // InternalSM2.g:1855:45: (iv_ruleArray= ruleArray EOF )
            // InternalSM2.g:1856:2: iv_ruleArray= ruleArray EOF
            {
             newCompositeNode(grammarAccess.getArrayRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleArray=ruleArray();

            state._fsp--;

             current =iv_ruleArray.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArray"


    // $ANTLR start "ruleArray"
    // InternalSM2.g:1862:1: ruleArray returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )* ) ;
    public final AntlrDatatypeRuleToken ruleArray() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_2=null;
        Token this_INT_6=null;


        	enterRule();

        try {
            // InternalSM2.g:1868:2: ( ( (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )* ) )
            // InternalSM2.g:1869:2: ( (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )* )
            {
            // InternalSM2.g:1869:2: ( (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )* )
            // InternalSM2.g:1870:3: (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )*
            {
            // InternalSM2.g:1870:3: (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) )
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==92) ) {
                alt47=1;
            }
            else if ( (LA47_0==93) ) {
                alt47=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 47, 0, input);

                throw nvae;
            }
            switch (alt47) {
                case 1 :
                    // InternalSM2.g:1871:4: kw= '[]'
                    {
                    kw=(Token)match(input,92,FOLLOW_45); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_0_0());
                    			

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1877:4: (kw= '[' this_INT_2= RULE_INT kw= ']' )
                    {
                    // InternalSM2.g:1877:4: (kw= '[' this_INT_2= RULE_INT kw= ']' )
                    // InternalSM2.g:1878:5: kw= '[' this_INT_2= RULE_INT kw= ']'
                    {
                    kw=(Token)match(input,93,FOLLOW_46); 

                    					current.merge(kw);
                    					newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_0_1_0());
                    				
                    this_INT_2=(Token)match(input,RULE_INT,FOLLOW_47); 

                    					current.merge(this_INT_2);
                    				

                    					newLeafNode(this_INT_2, grammarAccess.getArrayAccess().getINTTerminalRuleCall_0_1_1());
                    				
                    kw=(Token)match(input,94,FOLLOW_45); 

                    					current.merge(kw);
                    					newLeafNode(kw, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_0_1_2());
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:1897:3: (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )*
            loop48:
            do {
                int alt48=3;
                int LA48_0 = input.LA(1);

                if ( (LA48_0==92) ) {
                    alt48=1;
                }
                else if ( (LA48_0==93) ) {
                    alt48=2;
                }


                switch (alt48) {
            	case 1 :
            	    // InternalSM2.g:1898:4: kw= '[]'
            	    {
            	    kw=(Token)match(input,92,FOLLOW_45); 

            	    				current.merge(kw);
            	    				newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_1_0());
            	    			

            	    }
            	    break;
            	case 2 :
            	    // InternalSM2.g:1904:4: (kw= '[' this_INT_6= RULE_INT kw= ']' )
            	    {
            	    // InternalSM2.g:1904:4: (kw= '[' this_INT_6= RULE_INT kw= ']' )
            	    // InternalSM2.g:1905:5: kw= '[' this_INT_6= RULE_INT kw= ']'
            	    {
            	    kw=(Token)match(input,93,FOLLOW_46); 

            	    					current.merge(kw);
            	    					newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_1_1_0());
            	    				
            	    this_INT_6=(Token)match(input,RULE_INT,FOLLOW_47); 

            	    					current.merge(this_INT_6);
            	    				

            	    					newLeafNode(this_INT_6, grammarAccess.getArrayAccess().getINTTerminalRuleCall_1_1_1());
            	    				
            	    kw=(Token)match(input,94,FOLLOW_45); 

            	    					current.merge(kw);
            	    					newLeafNode(kw, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_1_1_2());
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop48;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArray"


    // $ANTLR start "entryRuleProperties"
    // InternalSM2.g:1928:1: entryRuleProperties returns [EObject current=null] : iv_ruleProperties= ruleProperties EOF ;
    public final EObject entryRuleProperties() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperties = null;


        try {
            // InternalSM2.g:1928:51: (iv_ruleProperties= ruleProperties EOF )
            // InternalSM2.g:1929:2: iv_ruleProperties= ruleProperties EOF
            {
             newCompositeNode(grammarAccess.getPropertiesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleProperties=ruleProperties();

            state._fsp--;

             current =iv_ruleProperties; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperties"


    // $ANTLR start "ruleProperties"
    // InternalSM2.g:1935:1: ruleProperties returns [EObject current=null] : this_Property_0= ruleProperty ;
    public final EObject ruleProperties() throws RecognitionException {
        EObject current = null;

        EObject this_Property_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1941:2: (this_Property_0= ruleProperty )
            // InternalSM2.g:1942:2: this_Property_0= ruleProperty
            {

            		newCompositeNode(grammarAccess.getPropertiesAccess().getPropertyParserRuleCall());
            	
            pushFollow(FOLLOW_2);
            this_Property_0=ruleProperty();

            state._fsp--;


            		current = this_Property_0;
            		afterParserOrEnumRuleCall();
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperties"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:1953:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // InternalSM2.g:1953:49: (iv_ruleProperty= ruleProperty EOF )
            // InternalSM2.g:1954:2: iv_ruleProperty= ruleProperty EOF
            {
             newCompositeNode(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleProperty=ruleProperty();

            state._fsp--;

             current =iv_ruleProperty; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:1960:1: ruleProperty returns [EObject current=null] : (this_PropertyString_0= rulePropertyString | this_PropertyBoolean_1= rulePropertyBoolean | this_PropertyInteger_2= rulePropertyInteger | this_PropertyFloat_3= rulePropertyFloat | this_PropertyAddress_4= rulePropertyAddress ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        EObject this_PropertyString_0 = null;

        EObject this_PropertyBoolean_1 = null;

        EObject this_PropertyInteger_2 = null;

        EObject this_PropertyFloat_3 = null;

        EObject this_PropertyAddress_4 = null;



        	enterRule();

        try {
            // InternalSM2.g:1966:2: ( (this_PropertyString_0= rulePropertyString | this_PropertyBoolean_1= rulePropertyBoolean | this_PropertyInteger_2= rulePropertyInteger | this_PropertyFloat_3= rulePropertyFloat | this_PropertyAddress_4= rulePropertyAddress ) )
            // InternalSM2.g:1967:2: (this_PropertyString_0= rulePropertyString | this_PropertyBoolean_1= rulePropertyBoolean | this_PropertyInteger_2= rulePropertyInteger | this_PropertyFloat_3= rulePropertyFloat | this_PropertyAddress_4= rulePropertyAddress )
            {
            // InternalSM2.g:1967:2: (this_PropertyString_0= rulePropertyString | this_PropertyBoolean_1= rulePropertyBoolean | this_PropertyInteger_2= rulePropertyInteger | this_PropertyFloat_3= rulePropertyFloat | this_PropertyAddress_4= rulePropertyAddress )
            int alt49=5;
            switch ( input.LA(1) ) {
            case 73:
                {
                alt49=1;
                }
                break;
            case 77:
                {
                alt49=2;
                }
                break;
            case 70:
            case 71:
            case 72:
            case 99:
            case 100:
            case 101:
            case 102:
            case 103:
            case 104:
            case 105:
            case 106:
            case 107:
                {
                alt49=3;
                }
                break;
            case 108:
                {
                alt49=4;
                }
                break;
            case 74:
            case 75:
                {
                alt49=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 49, 0, input);

                throw nvae;
            }

            switch (alt49) {
                case 1 :
                    // InternalSM2.g:1968:3: this_PropertyString_0= rulePropertyString
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyStringParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyString_0=rulePropertyString();

                    state._fsp--;


                    			current = this_PropertyString_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1977:3: this_PropertyBoolean_1= rulePropertyBoolean
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyBooleanParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyBoolean_1=rulePropertyBoolean();

                    state._fsp--;


                    			current = this_PropertyBoolean_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1986:3: this_PropertyInteger_2= rulePropertyInteger
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyIntegerParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyInteger_2=rulePropertyInteger();

                    state._fsp--;


                    			current = this_PropertyInteger_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:1995:3: this_PropertyFloat_3= rulePropertyFloat
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyFloatParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyFloat_3=rulePropertyFloat();

                    state._fsp--;


                    			current = this_PropertyFloat_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:2004:3: this_PropertyAddress_4= rulePropertyAddress
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyAddressParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyAddress_4=rulePropertyAddress();

                    state._fsp--;


                    			current = this_PropertyAddress_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRulePropertyString"
    // InternalSM2.g:2016:1: entryRulePropertyString returns [EObject current=null] : iv_rulePropertyString= rulePropertyString EOF ;
    public final EObject entryRulePropertyString() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyString = null;


        try {
            // InternalSM2.g:2016:55: (iv_rulePropertyString= rulePropertyString EOF )
            // InternalSM2.g:2017:2: iv_rulePropertyString= rulePropertyString EOF
            {
             newCompositeNode(grammarAccess.getPropertyStringRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyString=rulePropertyString();

            state._fsp--;

             current =iv_rulePropertyString; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyString"


    // $ANTLR start "rulePropertyString"
    // InternalSM2.g:2023:1: rulePropertyString returns [EObject current=null] : ( ( (lv_type_0_0= 'string' ) ) ( ruleArray )? ( ( (lv_storageData_2_0= 'memory' ) ) | otherlv_3= 'storage' )? ( (lv_nameProperty_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= 'newString' ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) ;
    public final EObject rulePropertyString() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token lv_storageData_2_0=null;
        Token otherlv_3=null;
        Token lv_nameProperty_4_0=null;
        Token otherlv_5=null;
        Token lv_defaultValue_6_0=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;


        	enterRule();

        try {
            // InternalSM2.g:2029:2: ( ( ( (lv_type_0_0= 'string' ) ) ( ruleArray )? ( ( (lv_storageData_2_0= 'memory' ) ) | otherlv_3= 'storage' )? ( (lv_nameProperty_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= 'newString' ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) )
            // InternalSM2.g:2030:2: ( ( (lv_type_0_0= 'string' ) ) ( ruleArray )? ( ( (lv_storageData_2_0= 'memory' ) ) | otherlv_3= 'storage' )? ( (lv_nameProperty_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= 'newString' ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            {
            // InternalSM2.g:2030:2: ( ( (lv_type_0_0= 'string' ) ) ( ruleArray )? ( ( (lv_storageData_2_0= 'memory' ) ) | otherlv_3= 'storage' )? ( (lv_nameProperty_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= 'newString' ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            // InternalSM2.g:2031:3: ( (lv_type_0_0= 'string' ) ) ( ruleArray )? ( ( (lv_storageData_2_0= 'memory' ) ) | otherlv_3= 'storage' )? ( (lv_nameProperty_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= 'newString' ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )?
            {
            // InternalSM2.g:2031:3: ( (lv_type_0_0= 'string' ) )
            // InternalSM2.g:2032:4: (lv_type_0_0= 'string' )
            {
            // InternalSM2.g:2032:4: (lv_type_0_0= 'string' )
            // InternalSM2.g:2033:5: lv_type_0_0= 'string'
            {
            lv_type_0_0=(Token)match(input,73,FOLLOW_48); 

            					newLeafNode(lv_type_0_0, grammarAccess.getPropertyStringAccess().getTypeStringKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyStringRule());
            					}
            					setWithLastConsumed(current, "type", lv_type_0_0, "string");
            				

            }


            }

            // InternalSM2.g:2045:3: ( ruleArray )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( ((LA50_0>=92 && LA50_0<=93)) ) {
                alt50=1;
            }
            switch (alt50) {
                case 1 :
                    // InternalSM2.g:2046:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyStringAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_49);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:2054:3: ( ( (lv_storageData_2_0= 'memory' ) ) | otherlv_3= 'storage' )?
            int alt51=3;
            int LA51_0 = input.LA(1);

            if ( (LA51_0==95) ) {
                alt51=1;
            }
            else if ( (LA51_0==96) ) {
                alt51=2;
            }
            switch (alt51) {
                case 1 :
                    // InternalSM2.g:2055:4: ( (lv_storageData_2_0= 'memory' ) )
                    {
                    // InternalSM2.g:2055:4: ( (lv_storageData_2_0= 'memory' ) )
                    // InternalSM2.g:2056:5: (lv_storageData_2_0= 'memory' )
                    {
                    // InternalSM2.g:2056:5: (lv_storageData_2_0= 'memory' )
                    // InternalSM2.g:2057:6: lv_storageData_2_0= 'memory'
                    {
                    lv_storageData_2_0=(Token)match(input,95,FOLLOW_15); 

                    						newLeafNode(lv_storageData_2_0, grammarAccess.getPropertyStringAccess().getStorageDataMemoryKeyword_2_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyStringRule());
                    						}
                    						setWithLastConsumed(current, "storageData", lv_storageData_2_0, "memory");
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2070:4: otherlv_3= 'storage'
                    {
                    otherlv_3=(Token)match(input,96,FOLLOW_15); 

                    				newLeafNode(otherlv_3, grammarAccess.getPropertyStringAccess().getStorageKeyword_2_1());
                    			

                    }
                    break;

            }

            // InternalSM2.g:2075:3: ( (lv_nameProperty_4_0= RULE_ID ) )
            // InternalSM2.g:2076:4: (lv_nameProperty_4_0= RULE_ID )
            {
            // InternalSM2.g:2076:4: (lv_nameProperty_4_0= RULE_ID )
            // InternalSM2.g:2077:5: lv_nameProperty_4_0= RULE_ID
            {
            lv_nameProperty_4_0=(Token)match(input,RULE_ID,FOLLOW_50); 

            					newLeafNode(lv_nameProperty_4_0, grammarAccess.getPropertyStringAccess().getNamePropertyIDTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyStringRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameProperty",
            						lv_nameProperty_4_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:2093:3: (otherlv_5= '=' ( (lv_defaultValue_6_0= 'newString' ) ) )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==97) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalSM2.g:2094:4: otherlv_5= '=' ( (lv_defaultValue_6_0= 'newString' ) )
                    {
                    otherlv_5=(Token)match(input,97,FOLLOW_51); 

                    				newLeafNode(otherlv_5, grammarAccess.getPropertyStringAccess().getEqualsSignKeyword_4_0());
                    			
                    // InternalSM2.g:2098:4: ( (lv_defaultValue_6_0= 'newString' ) )
                    // InternalSM2.g:2099:5: (lv_defaultValue_6_0= 'newString' )
                    {
                    // InternalSM2.g:2099:5: (lv_defaultValue_6_0= 'newString' )
                    // InternalSM2.g:2100:6: lv_defaultValue_6_0= 'newString'
                    {
                    lv_defaultValue_6_0=(Token)match(input,98,FOLLOW_33); 

                    						newLeafNode(lv_defaultValue_6_0, grammarAccess.getPropertyStringAccess().getDefaultValueNewStringKeyword_4_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyStringRule());
                    						}
                    						setWithLastConsumed(current, "defaultValue", lv_defaultValue_6_0, "newString");
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_34); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getPropertyStringAccess().getSEMICOLONTerminalRuleCall_5());
            		
            // InternalSM2.g:2117:3: (this_EOLINE_8= RULE_EOLINE )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==RULE_EOLINE) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // InternalSM2.g:2118:4: this_EOLINE_8= RULE_EOLINE
                    {
                    this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_8, grammarAccess.getPropertyStringAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyString"


    // $ANTLR start "entryRulePropertyInteger"
    // InternalSM2.g:2127:1: entryRulePropertyInteger returns [EObject current=null] : iv_rulePropertyInteger= rulePropertyInteger EOF ;
    public final EObject entryRulePropertyInteger() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyInteger = null;


        try {
            // InternalSM2.g:2127:56: (iv_rulePropertyInteger= rulePropertyInteger EOF )
            // InternalSM2.g:2128:2: iv_rulePropertyInteger= rulePropertyInteger EOF
            {
             newCompositeNode(grammarAccess.getPropertyIntegerRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyInteger=rulePropertyInteger();

            state._fsp--;

             current =iv_rulePropertyInteger; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyInteger"


    // $ANTLR start "rulePropertyInteger"
    // InternalSM2.g:2134:1: rulePropertyInteger returns [EObject current=null] : ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INT ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyInteger() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_1=null;
        Token lv_type_0_2=null;
        Token lv_type_0_3=null;
        Token lv_type_0_4=null;
        Token lv_type_0_5=null;
        Token lv_type_0_6=null;
        Token lv_type_0_7=null;
        Token lv_type_0_8=null;
        Token lv_type_0_9=null;
        Token lv_type_0_10=null;
        Token lv_type_0_11=null;
        Token lv_type_0_12=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token lv_inicialization_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2140:2: ( ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INT ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2141:2: ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INT ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2141:2: ( ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INT ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2142:3: ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INT ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:2142:3: ( ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) ) )
            // InternalSM2.g:2143:4: ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) )
            {
            // InternalSM2.g:2143:4: ( (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' ) )
            // InternalSM2.g:2144:5: (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' )
            {
            // InternalSM2.g:2144:5: (lv_type_0_1= 'int' | lv_type_0_2= 'uint' | lv_type_0_3= 'uint2' | lv_type_0_4= 'uint4' | lv_type_0_5= 'uint8' | lv_type_0_6= 'uint16' | lv_type_0_7= 'uint24' | lv_type_0_8= 'uint32' | lv_type_0_9= 'uint64' | lv_type_0_10= 'uint128' | lv_type_0_11= 'uint160' | lv_type_0_12= 'uint256' )
            int alt54=12;
            switch ( input.LA(1) ) {
            case 70:
                {
                alt54=1;
                }
                break;
            case 71:
                {
                alt54=2;
                }
                break;
            case 99:
                {
                alt54=3;
                }
                break;
            case 100:
                {
                alt54=4;
                }
                break;
            case 72:
                {
                alt54=5;
                }
                break;
            case 101:
                {
                alt54=6;
                }
                break;
            case 102:
                {
                alt54=7;
                }
                break;
            case 103:
                {
                alt54=8;
                }
                break;
            case 104:
                {
                alt54=9;
                }
                break;
            case 105:
                {
                alt54=10;
                }
                break;
            case 106:
                {
                alt54=11;
                }
                break;
            case 107:
                {
                alt54=12;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 54, 0, input);

                throw nvae;
            }

            switch (alt54) {
                case 1 :
                    // InternalSM2.g:2145:6: lv_type_0_1= 'int'
                    {
                    lv_type_0_1=(Token)match(input,70,FOLLOW_52); 

                    						newLeafNode(lv_type_0_1, grammarAccess.getPropertyIntegerAccess().getTypeIntKeyword_0_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2156:6: lv_type_0_2= 'uint'
                    {
                    lv_type_0_2=(Token)match(input,71,FOLLOW_52); 

                    						newLeafNode(lv_type_0_2, grammarAccess.getPropertyIntegerAccess().getTypeUintKeyword_0_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_2, null);
                    					

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2167:6: lv_type_0_3= 'uint2'
                    {
                    lv_type_0_3=(Token)match(input,99,FOLLOW_52); 

                    						newLeafNode(lv_type_0_3, grammarAccess.getPropertyIntegerAccess().getTypeUint2Keyword_0_0_2());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_3, null);
                    					

                    }
                    break;
                case 4 :
                    // InternalSM2.g:2178:6: lv_type_0_4= 'uint4'
                    {
                    lv_type_0_4=(Token)match(input,100,FOLLOW_52); 

                    						newLeafNode(lv_type_0_4, grammarAccess.getPropertyIntegerAccess().getTypeUint4Keyword_0_0_3());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_4, null);
                    					

                    }
                    break;
                case 5 :
                    // InternalSM2.g:2189:6: lv_type_0_5= 'uint8'
                    {
                    lv_type_0_5=(Token)match(input,72,FOLLOW_52); 

                    						newLeafNode(lv_type_0_5, grammarAccess.getPropertyIntegerAccess().getTypeUint8Keyword_0_0_4());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_5, null);
                    					

                    }
                    break;
                case 6 :
                    // InternalSM2.g:2200:6: lv_type_0_6= 'uint16'
                    {
                    lv_type_0_6=(Token)match(input,101,FOLLOW_52); 

                    						newLeafNode(lv_type_0_6, grammarAccess.getPropertyIntegerAccess().getTypeUint16Keyword_0_0_5());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_6, null);
                    					

                    }
                    break;
                case 7 :
                    // InternalSM2.g:2211:6: lv_type_0_7= 'uint24'
                    {
                    lv_type_0_7=(Token)match(input,102,FOLLOW_52); 

                    						newLeafNode(lv_type_0_7, grammarAccess.getPropertyIntegerAccess().getTypeUint24Keyword_0_0_6());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_7, null);
                    					

                    }
                    break;
                case 8 :
                    // InternalSM2.g:2222:6: lv_type_0_8= 'uint32'
                    {
                    lv_type_0_8=(Token)match(input,103,FOLLOW_52); 

                    						newLeafNode(lv_type_0_8, grammarAccess.getPropertyIntegerAccess().getTypeUint32Keyword_0_0_7());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_8, null);
                    					

                    }
                    break;
                case 9 :
                    // InternalSM2.g:2233:6: lv_type_0_9= 'uint64'
                    {
                    lv_type_0_9=(Token)match(input,104,FOLLOW_52); 

                    						newLeafNode(lv_type_0_9, grammarAccess.getPropertyIntegerAccess().getTypeUint64Keyword_0_0_8());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_9, null);
                    					

                    }
                    break;
                case 10 :
                    // InternalSM2.g:2244:6: lv_type_0_10= 'uint128'
                    {
                    lv_type_0_10=(Token)match(input,105,FOLLOW_52); 

                    						newLeafNode(lv_type_0_10, grammarAccess.getPropertyIntegerAccess().getTypeUint128Keyword_0_0_9());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_10, null);
                    					

                    }
                    break;
                case 11 :
                    // InternalSM2.g:2255:6: lv_type_0_11= 'uint160'
                    {
                    lv_type_0_11=(Token)match(input,106,FOLLOW_52); 

                    						newLeafNode(lv_type_0_11, grammarAccess.getPropertyIntegerAccess().getTypeUint160Keyword_0_0_10());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_11, null);
                    					

                    }
                    break;
                case 12 :
                    // InternalSM2.g:2266:6: lv_type_0_12= 'uint256'
                    {
                    lv_type_0_12=(Token)match(input,107,FOLLOW_52); 

                    						newLeafNode(lv_type_0_12, grammarAccess.getPropertyIntegerAccess().getTypeUint256Keyword_0_0_11());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_12, null);
                    					

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:2279:3: ( ruleArray )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( ((LA55_0>=92 && LA55_0<=93)) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // InternalSM2.g:2280:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyIntegerAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_41);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:2288:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( ((LA56_0>=65 && LA56_0<=66)||LA56_0==122) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalSM2.g:2289:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:2289:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:2290:5: lv_visibility_2_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyIntegerAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_15);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyIntegerRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_2_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:2307:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:2308:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:2308:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:2309:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_53); 

            					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyIntegerAccess().getNamePropertyIDTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyIntegerRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameProperty",
            						lv_nameProperty_3_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_4=(Token)match(input,97,FOLLOW_54); 

            			newLeafNode(otherlv_4, grammarAccess.getPropertyIntegerAccess().getEqualsSignKeyword_4());
            		
            // InternalSM2.g:2329:3: ( (lv_inicialization_5_0= RULE_INT ) )?
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==RULE_INT) ) {
                alt57=1;
            }
            switch (alt57) {
                case 1 :
                    // InternalSM2.g:2330:4: (lv_inicialization_5_0= RULE_INT )
                    {
                    // InternalSM2.g:2330:4: (lv_inicialization_5_0= RULE_INT )
                    // InternalSM2.g:2331:5: lv_inicialization_5_0= RULE_INT
                    {
                    lv_inicialization_5_0=(Token)match(input,RULE_INT,FOLLOW_33); 

                    					newLeafNode(lv_inicialization_5_0, grammarAccess.getPropertyIntegerAccess().getInicializationINTTerminalRuleCall_5_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"inicialization",
                    						lv_inicialization_5_0,
                    						"org.eclipse.xtext.common.Terminals.INT");
                    				

                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_34); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyIntegerAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:2351:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==RULE_EOLINE) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // InternalSM2.g:2352:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyIntegerAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyInteger"


    // $ANTLR start "entryRulePropertyFloat"
    // InternalSM2.g:2361:1: entryRulePropertyFloat returns [EObject current=null] : iv_rulePropertyFloat= rulePropertyFloat EOF ;
    public final EObject entryRulePropertyFloat() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyFloat = null;


        try {
            // InternalSM2.g:2361:54: (iv_rulePropertyFloat= rulePropertyFloat EOF )
            // InternalSM2.g:2362:2: iv_rulePropertyFloat= rulePropertyFloat EOF
            {
             newCompositeNode(grammarAccess.getPropertyFloatRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyFloat=rulePropertyFloat();

            state._fsp--;

             current =iv_rulePropertyFloat; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyFloat"


    // $ANTLR start "rulePropertyFloat"
    // InternalSM2.g:2368:1: rulePropertyFloat returns [EObject current=null] : ( ( (lv_type_0_0= 'float' ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= '0.0' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) ;
    public final EObject rulePropertyFloat() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token lv_storageData_3_0=null;
        Token otherlv_4=null;
        Token lv_nameProperty_5_0=null;
        Token otherlv_6=null;
        Token lv_defaultValueLiteral_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2374:2: ( ( ( (lv_type_0_0= 'float' ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= '0.0' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) )
            // InternalSM2.g:2375:2: ( ( (lv_type_0_0= 'float' ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= '0.0' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            {
            // InternalSM2.g:2375:2: ( ( (lv_type_0_0= 'float' ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= '0.0' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            // InternalSM2.g:2376:3: ( (lv_type_0_0= 'float' ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= '0.0' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )?
            {
            // InternalSM2.g:2376:3: ( (lv_type_0_0= 'float' ) )
            // InternalSM2.g:2377:4: (lv_type_0_0= 'float' )
            {
            // InternalSM2.g:2377:4: (lv_type_0_0= 'float' )
            // InternalSM2.g:2378:5: lv_type_0_0= 'float'
            {
            lv_type_0_0=(Token)match(input,108,FOLLOW_55); 

            					newLeafNode(lv_type_0_0, grammarAccess.getPropertyFloatAccess().getTypeFloatKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyFloatRule());
            					}
            					setWithLastConsumed(current, "type", lv_type_0_0, "float");
            				

            }


            }

            // InternalSM2.g:2390:3: ( ruleArray )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( ((LA59_0>=92 && LA59_0<=93)) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // InternalSM2.g:2391:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyFloatAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_56);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:2399:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( ((LA60_0>=65 && LA60_0<=66)||LA60_0==122) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // InternalSM2.g:2400:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:2400:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:2401:5: lv_visibility_2_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyFloatAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_49);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyFloatRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_2_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:2418:3: ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )?
            int alt61=3;
            int LA61_0 = input.LA(1);

            if ( (LA61_0==95) ) {
                alt61=1;
            }
            else if ( (LA61_0==96) ) {
                alt61=2;
            }
            switch (alt61) {
                case 1 :
                    // InternalSM2.g:2419:4: ( (lv_storageData_3_0= 'memory' ) )
                    {
                    // InternalSM2.g:2419:4: ( (lv_storageData_3_0= 'memory' ) )
                    // InternalSM2.g:2420:5: (lv_storageData_3_0= 'memory' )
                    {
                    // InternalSM2.g:2420:5: (lv_storageData_3_0= 'memory' )
                    // InternalSM2.g:2421:6: lv_storageData_3_0= 'memory'
                    {
                    lv_storageData_3_0=(Token)match(input,95,FOLLOW_15); 

                    						newLeafNode(lv_storageData_3_0, grammarAccess.getPropertyFloatAccess().getStorageDataMemoryKeyword_3_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyFloatRule());
                    						}
                    						setWithLastConsumed(current, "storageData", lv_storageData_3_0, "memory");
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2434:4: otherlv_4= 'storage'
                    {
                    otherlv_4=(Token)match(input,96,FOLLOW_15); 

                    				newLeafNode(otherlv_4, grammarAccess.getPropertyFloatAccess().getStorageKeyword_3_1());
                    			

                    }
                    break;

            }

            // InternalSM2.g:2439:3: ( (lv_nameProperty_5_0= RULE_ID ) )
            // InternalSM2.g:2440:4: (lv_nameProperty_5_0= RULE_ID )
            {
            // InternalSM2.g:2440:4: (lv_nameProperty_5_0= RULE_ID )
            // InternalSM2.g:2441:5: lv_nameProperty_5_0= RULE_ID
            {
            lv_nameProperty_5_0=(Token)match(input,RULE_ID,FOLLOW_50); 

            					newLeafNode(lv_nameProperty_5_0, grammarAccess.getPropertyFloatAccess().getNamePropertyIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyFloatRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameProperty",
            						lv_nameProperty_5_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:2457:3: (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= '0.0' ) ) )?
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==97) ) {
                alt62=1;
            }
            switch (alt62) {
                case 1 :
                    // InternalSM2.g:2458:4: otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= '0.0' ) )
                    {
                    otherlv_6=(Token)match(input,97,FOLLOW_57); 

                    				newLeafNode(otherlv_6, grammarAccess.getPropertyFloatAccess().getEqualsSignKeyword_5_0());
                    			
                    // InternalSM2.g:2462:4: ( (lv_defaultValueLiteral_7_0= '0.0' ) )
                    // InternalSM2.g:2463:5: (lv_defaultValueLiteral_7_0= '0.0' )
                    {
                    // InternalSM2.g:2463:5: (lv_defaultValueLiteral_7_0= '0.0' )
                    // InternalSM2.g:2464:6: lv_defaultValueLiteral_7_0= '0.0'
                    {
                    lv_defaultValueLiteral_7_0=(Token)match(input,109,FOLLOW_33); 

                    						newLeafNode(lv_defaultValueLiteral_7_0, grammarAccess.getPropertyFloatAccess().getDefaultValueLiteral00Keyword_5_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyFloatRule());
                    						}
                    						setWithLastConsumed(current, "defaultValueLiteral", lv_defaultValueLiteral_7_0, "0.0");
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_34); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getPropertyFloatAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:2481:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt63=2;
            int LA63_0 = input.LA(1);

            if ( (LA63_0==RULE_EOLINE) ) {
                alt63=1;
            }
            switch (alt63) {
                case 1 :
                    // InternalSM2.g:2482:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_9, grammarAccess.getPropertyFloatAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyFloat"


    // $ANTLR start "entryRulePropertyBoolean"
    // InternalSM2.g:2491:1: entryRulePropertyBoolean returns [EObject current=null] : iv_rulePropertyBoolean= rulePropertyBoolean EOF ;
    public final EObject entryRulePropertyBoolean() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyBoolean = null;


        try {
            // InternalSM2.g:2491:56: (iv_rulePropertyBoolean= rulePropertyBoolean EOF )
            // InternalSM2.g:2492:2: iv_rulePropertyBoolean= rulePropertyBoolean EOF
            {
             newCompositeNode(grammarAccess.getPropertyBooleanRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyBoolean=rulePropertyBoolean();

            state._fsp--;

             current =iv_rulePropertyBoolean; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyBoolean"


    // $ANTLR start "rulePropertyBoolean"
    // InternalSM2.g:2498:1: rulePropertyBoolean returns [EObject current=null] : ( ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= 'true' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) ;
    public final EObject rulePropertyBoolean() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token lv_storageData_3_0=null;
        Token otherlv_4=null;
        Token lv_nameProperty_5_0=null;
        Token otherlv_6=null;
        Token lv_defaultValueLiteral_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2504:2: ( ( ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= 'true' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) )
            // InternalSM2.g:2505:2: ( ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= 'true' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            {
            // InternalSM2.g:2505:2: ( ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= 'true' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            // InternalSM2.g:2506:3: ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )? ( (lv_nameProperty_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= 'true' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )?
            {
            // InternalSM2.g:2506:3: ( (lv_type_0_0= 'bool' ) )
            // InternalSM2.g:2507:4: (lv_type_0_0= 'bool' )
            {
            // InternalSM2.g:2507:4: (lv_type_0_0= 'bool' )
            // InternalSM2.g:2508:5: lv_type_0_0= 'bool'
            {
            lv_type_0_0=(Token)match(input,77,FOLLOW_55); 

            					newLeafNode(lv_type_0_0, grammarAccess.getPropertyBooleanAccess().getTypeBoolKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyBooleanRule());
            					}
            					setWithLastConsumed(current, "type", lv_type_0_0, "bool");
            				

            }


            }

            // InternalSM2.g:2520:3: ( ruleArray )?
            int alt64=2;
            int LA64_0 = input.LA(1);

            if ( ((LA64_0>=92 && LA64_0<=93)) ) {
                alt64=1;
            }
            switch (alt64) {
                case 1 :
                    // InternalSM2.g:2521:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyBooleanAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_56);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:2529:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt65=2;
            int LA65_0 = input.LA(1);

            if ( ((LA65_0>=65 && LA65_0<=66)||LA65_0==122) ) {
                alt65=1;
            }
            switch (alt65) {
                case 1 :
                    // InternalSM2.g:2530:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:2530:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:2531:5: lv_visibility_2_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyBooleanAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_49);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyBooleanRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_2_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:2548:3: ( ( (lv_storageData_3_0= 'memory' ) ) | otherlv_4= 'storage' )?
            int alt66=3;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==95) ) {
                alt66=1;
            }
            else if ( (LA66_0==96) ) {
                alt66=2;
            }
            switch (alt66) {
                case 1 :
                    // InternalSM2.g:2549:4: ( (lv_storageData_3_0= 'memory' ) )
                    {
                    // InternalSM2.g:2549:4: ( (lv_storageData_3_0= 'memory' ) )
                    // InternalSM2.g:2550:5: (lv_storageData_3_0= 'memory' )
                    {
                    // InternalSM2.g:2550:5: (lv_storageData_3_0= 'memory' )
                    // InternalSM2.g:2551:6: lv_storageData_3_0= 'memory'
                    {
                    lv_storageData_3_0=(Token)match(input,95,FOLLOW_15); 

                    						newLeafNode(lv_storageData_3_0, grammarAccess.getPropertyBooleanAccess().getStorageDataMemoryKeyword_3_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyBooleanRule());
                    						}
                    						setWithLastConsumed(current, "storageData", lv_storageData_3_0, "memory");
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2564:4: otherlv_4= 'storage'
                    {
                    otherlv_4=(Token)match(input,96,FOLLOW_15); 

                    				newLeafNode(otherlv_4, grammarAccess.getPropertyBooleanAccess().getStorageKeyword_3_1());
                    			

                    }
                    break;

            }

            // InternalSM2.g:2569:3: ( (lv_nameProperty_5_0= RULE_ID ) )
            // InternalSM2.g:2570:4: (lv_nameProperty_5_0= RULE_ID )
            {
            // InternalSM2.g:2570:4: (lv_nameProperty_5_0= RULE_ID )
            // InternalSM2.g:2571:5: lv_nameProperty_5_0= RULE_ID
            {
            lv_nameProperty_5_0=(Token)match(input,RULE_ID,FOLLOW_50); 

            					newLeafNode(lv_nameProperty_5_0, grammarAccess.getPropertyBooleanAccess().getNamePropertyIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyBooleanRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameProperty",
            						lv_nameProperty_5_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:2587:3: (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= 'true' ) ) )?
            int alt67=2;
            int LA67_0 = input.LA(1);

            if ( (LA67_0==97) ) {
                alt67=1;
            }
            switch (alt67) {
                case 1 :
                    // InternalSM2.g:2588:4: otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= 'true' ) )
                    {
                    otherlv_6=(Token)match(input,97,FOLLOW_58); 

                    				newLeafNode(otherlv_6, grammarAccess.getPropertyBooleanAccess().getEqualsSignKeyword_5_0());
                    			
                    // InternalSM2.g:2592:4: ( (lv_defaultValueLiteral_7_0= 'true' ) )
                    // InternalSM2.g:2593:5: (lv_defaultValueLiteral_7_0= 'true' )
                    {
                    // InternalSM2.g:2593:5: (lv_defaultValueLiteral_7_0= 'true' )
                    // InternalSM2.g:2594:6: lv_defaultValueLiteral_7_0= 'true'
                    {
                    lv_defaultValueLiteral_7_0=(Token)match(input,110,FOLLOW_33); 

                    						newLeafNode(lv_defaultValueLiteral_7_0, grammarAccess.getPropertyBooleanAccess().getDefaultValueLiteralTrueKeyword_5_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyBooleanRule());
                    						}
                    						setWithLastConsumed(current, "defaultValueLiteral", lv_defaultValueLiteral_7_0, "true");
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_34); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getPropertyBooleanAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:2611:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==RULE_EOLINE) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // InternalSM2.g:2612:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_9, grammarAccess.getPropertyBooleanAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyBoolean"


    // $ANTLR start "entryRulePropertyAddress"
    // InternalSM2.g:2621:1: entryRulePropertyAddress returns [EObject current=null] : iv_rulePropertyAddress= rulePropertyAddress EOF ;
    public final EObject entryRulePropertyAddress() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyAddress = null;


        try {
            // InternalSM2.g:2621:56: (iv_rulePropertyAddress= rulePropertyAddress EOF )
            // InternalSM2.g:2622:2: iv_rulePropertyAddress= rulePropertyAddress EOF
            {
             newCompositeNode(grammarAccess.getPropertyAddressRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyAddress=rulePropertyAddress();

            state._fsp--;

             current =iv_rulePropertyAddress; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyAddress"


    // $ANTLR start "rulePropertyAddress"
    // InternalSM2.g:2628:1: rulePropertyAddress returns [EObject current=null] : ( ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_defaultValue_5_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyAddress() throws RecognitionException {
        EObject current = null;

        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_type_0_0 = null;

        Enumerator lv_visibility_2_0 = null;

        AntlrDatatypeRuleToken lv_defaultValue_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2634:2: ( ( ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_defaultValue_5_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2635:2: ( ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_defaultValue_5_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2635:2: ( ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_defaultValue_5_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2636:3: ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_defaultValue_5_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:2636:3: ( (lv_type_0_0= ruleTypeAddress ) )
            // InternalSM2.g:2637:4: (lv_type_0_0= ruleTypeAddress )
            {
            // InternalSM2.g:2637:4: (lv_type_0_0= ruleTypeAddress )
            // InternalSM2.g:2638:5: lv_type_0_0= ruleTypeAddress
            {

            					newCompositeNode(grammarAccess.getPropertyAddressAccess().getTypeTypeAddressParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_52);
            lv_type_0_0=ruleTypeAddress();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_0_0,
            						"org.xtext.SM2.TypeAddress");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:2655:3: ( ruleArray )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( ((LA69_0>=92 && LA69_0<=93)) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // InternalSM2.g:2656:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyAddressAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_41);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:2664:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( ((LA70_0>=65 && LA70_0<=66)||LA70_0==122) ) {
                alt70=1;
            }
            switch (alt70) {
                case 1 :
                    // InternalSM2.g:2665:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:2665:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:2666:5: lv_visibility_2_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyAddressAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_15);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_2_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:2683:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:2684:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:2684:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:2685:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_50); 

            					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyAddressAccess().getNamePropertyIDTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyAddressRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameProperty",
            						lv_nameProperty_3_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:2701:3: (otherlv_4= '=' ( (lv_defaultValue_5_0= ruleHexadecimalExpression ) ) )?
            int alt71=2;
            int LA71_0 = input.LA(1);

            if ( (LA71_0==97) ) {
                alt71=1;
            }
            switch (alt71) {
                case 1 :
                    // InternalSM2.g:2702:4: otherlv_4= '=' ( (lv_defaultValue_5_0= ruleHexadecimalExpression ) )
                    {
                    otherlv_4=(Token)match(input,97,FOLLOW_59); 

                    				newLeafNode(otherlv_4, grammarAccess.getPropertyAddressAccess().getEqualsSignKeyword_4_0());
                    			
                    // InternalSM2.g:2706:4: ( (lv_defaultValue_5_0= ruleHexadecimalExpression ) )
                    // InternalSM2.g:2707:5: (lv_defaultValue_5_0= ruleHexadecimalExpression )
                    {
                    // InternalSM2.g:2707:5: (lv_defaultValue_5_0= ruleHexadecimalExpression )
                    // InternalSM2.g:2708:6: lv_defaultValue_5_0= ruleHexadecimalExpression
                    {

                    						newCompositeNode(grammarAccess.getPropertyAddressAccess().getDefaultValueHexadecimalExpressionParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_33);
                    lv_defaultValue_5_0=ruleHexadecimalExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                    						}
                    						set(
                    							current,
                    							"defaultValue",
                    							lv_defaultValue_5_0,
                    							"org.xtext.SM2.HexadecimalExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_34); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyAddressAccess().getSEMICOLONTerminalRuleCall_5());
            		
            // InternalSM2.g:2730:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==RULE_EOLINE) ) {
                alt72=1;
            }
            switch (alt72) {
                case 1 :
                    // InternalSM2.g:2731:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyAddressAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyAddress"


    // $ANTLR start "entryRuleHexadecimalExpression"
    // InternalSM2.g:2740:1: entryRuleHexadecimalExpression returns [String current=null] : iv_ruleHexadecimalExpression= ruleHexadecimalExpression EOF ;
    public final String entryRuleHexadecimalExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleHexadecimalExpression = null;


        try {
            // InternalSM2.g:2740:61: (iv_ruleHexadecimalExpression= ruleHexadecimalExpression EOF )
            // InternalSM2.g:2741:2: iv_ruleHexadecimalExpression= ruleHexadecimalExpression EOF
            {
             newCompositeNode(grammarAccess.getHexadecimalExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleHexadecimalExpression=ruleHexadecimalExpression();

            state._fsp--;

             current =iv_ruleHexadecimalExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleHexadecimalExpression"


    // $ANTLR start "ruleHexadecimalExpression"
    // InternalSM2.g:2747:1: ruleHexadecimalExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= '0x' this_STRING_1= RULE_STRING ) ;
    public final AntlrDatatypeRuleToken ruleHexadecimalExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_STRING_1=null;


        	enterRule();

        try {
            // InternalSM2.g:2753:2: ( (kw= '0x' this_STRING_1= RULE_STRING ) )
            // InternalSM2.g:2754:2: (kw= '0x' this_STRING_1= RULE_STRING )
            {
            // InternalSM2.g:2754:2: (kw= '0x' this_STRING_1= RULE_STRING )
            // InternalSM2.g:2755:3: kw= '0x' this_STRING_1= RULE_STRING
            {
            kw=(Token)match(input,111,FOLLOW_32); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getHexadecimalExpressionAccess().getXKeyword_0());
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_2); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getHexadecimalExpressionAccess().getSTRINGTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleHexadecimalExpression"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:2771:1: entryRuleInputParam returns [EObject current=null] : iv_ruleInputParam= ruleInputParam EOF ;
    public final EObject entryRuleInputParam() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputParam = null;


        try {
            // InternalSM2.g:2771:51: (iv_ruleInputParam= ruleInputParam EOF )
            // InternalSM2.g:2772:2: iv_ruleInputParam= ruleInputParam EOF
            {
             newCompositeNode(grammarAccess.getInputParamRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputParam=ruleInputParam();

            state._fsp--;

             current =iv_ruleInputParam; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:2778:1: ruleInputParam returns [EObject current=null] : (this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )? ) ;
    public final EObject ruleInputParam() throws RecognitionException {
        EObject current = null;

        Token this_ID_1=null;
        Token this_COMMA_2=null;
        EObject this_SingularType_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2784:2: ( (this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )? ) )
            // InternalSM2.g:2785:2: (this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )? )
            {
            // InternalSM2.g:2785:2: (this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )? )
            // InternalSM2.g:2786:3: this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )?
            {

            			newCompositeNode(grammarAccess.getInputParamAccess().getSingularTypeParserRuleCall_0());
            		
            pushFollow(FOLLOW_15);
            this_SingularType_0=ruleSingularType();

            state._fsp--;


            			current = this_SingularType_0;
            			afterParserOrEnumRuleCall();
            		
            this_ID_1=(Token)match(input,RULE_ID,FOLLOW_60); 

            			newLeafNode(this_ID_1, grammarAccess.getInputParamAccess().getIDTerminalRuleCall_1());
            		
            // InternalSM2.g:2798:3: (this_COMMA_2= RULE_COMMA )?
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==RULE_COMMA) ) {
                alt73=1;
            }
            switch (alt73) {
                case 1 :
                    // InternalSM2.g:2799:4: this_COMMA_2= RULE_COMMA
                    {
                    this_COMMA_2=(Token)match(input,RULE_COMMA,FOLLOW_2); 

                    				newLeafNode(this_COMMA_2, grammarAccess.getInputParamAccess().getCOMMATerminalRuleCall_2());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestrictionClause"
    // InternalSM2.g:2808:1: entryRuleRestrictionClause returns [EObject current=null] : iv_ruleRestrictionClause= ruleRestrictionClause EOF ;
    public final EObject entryRuleRestrictionClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionClause = null;


        try {
            // InternalSM2.g:2808:58: (iv_ruleRestrictionClause= ruleRestrictionClause EOF )
            // InternalSM2.g:2809:2: iv_ruleRestrictionClause= ruleRestrictionClause EOF
            {
             newCompositeNode(grammarAccess.getRestrictionClauseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionClause=ruleRestrictionClause();

            state._fsp--;

             current =iv_ruleRestrictionClause; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionClause"


    // $ANTLR start "ruleRestrictionClause"
    // InternalSM2.g:2815:1: ruleRestrictionClause returns [EObject current=null] : (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas ) ;
    public final EObject ruleRestrictionClause() throws RecognitionException {
        EObject current = null;

        EObject this_Restriction_0 = null;

        EObject this_RestrictionGas_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:2821:2: ( (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas ) )
            // InternalSM2.g:2822:2: (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas )
            {
            // InternalSM2.g:2822:2: (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas )
            int alt74=2;
            alt74 = dfa74.predict(input);
            switch (alt74) {
                case 1 :
                    // InternalSM2.g:2823:3: this_Restriction_0= ruleRestriction
                    {

                    			newCompositeNode(grammarAccess.getRestrictionClauseAccess().getRestrictionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Restriction_0=ruleRestriction();

                    state._fsp--;


                    			current = this_Restriction_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2832:3: this_RestrictionGas_1= ruleRestrictionGas
                    {

                    			newCompositeNode(grammarAccess.getRestrictionClauseAccess().getRestrictionGasParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_RestrictionGas_1=ruleRestrictionGas();

                    state._fsp--;


                    			current = this_RestrictionGas_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionClause"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:2844:1: entryRuleRestriction returns [EObject current=null] : iv_ruleRestriction= ruleRestriction EOF ;
    public final EObject entryRuleRestriction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestriction = null;


        try {
            // InternalSM2.g:2844:52: (iv_ruleRestriction= ruleRestriction EOF )
            // InternalSM2.g:2845:2: iv_ruleRestriction= ruleRestriction EOF
            {
             newCompositeNode(grammarAccess.getRestrictionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestriction=ruleRestriction();

            state._fsp--;

             current =iv_ruleRestriction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:2851:1: ruleRestriction returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) ;
    public final EObject ruleRestriction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        AntlrDatatypeRuleToken lv_expr_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2857:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) )
            // InternalSM2.g:2858:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            {
            // InternalSM2.g:2858:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            // InternalSM2.g:2859:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,112,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getRestrictionAccess().getRequireKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:2867:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:2868:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:2868:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2.g:2869:5: lv_expr_2_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_61);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_2_0,
            						"org.xtext.SM2.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:2886:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:2887:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:2887:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:2888:5: lv_operator_3_0= ruleComparationOperator
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_9);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"operator",
            						lv_operator_3_0,
            						"org.xtext.SM2.ComparationOperator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:2905:3: ( (lv_expr_4_0= ruleSyntaxExpression ) )
            // InternalSM2.g:2906:4: (lv_expr_4_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:2906:4: (lv_expr_4_0= ruleSyntaxExpression )
            // InternalSM2.g:2907:5: lv_expr_4_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_10);
            lv_expr_4_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_4_0,
            						"org.xtext.SM2.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_33); 

            			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
            		
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6());
            		
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_7, grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:2940:1: entryRuleRestrictionGas returns [EObject current=null] : iv_ruleRestrictionGas= ruleRestrictionGas EOF ;
    public final EObject entryRuleRestrictionGas() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionGas = null;


        try {
            // InternalSM2.g:2940:55: (iv_ruleRestrictionGas= ruleRestrictionGas EOF )
            // InternalSM2.g:2941:2: iv_ruleRestrictionGas= ruleRestrictionGas EOF
            {
             newCompositeNode(grammarAccess.getRestrictionGasRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionGas=ruleRestrictionGas();

            state._fsp--;

             current =iv_ruleRestrictionGas; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:2947:1: ruleRestrictionGas returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) ;
    public final EObject ruleRestrictionGas() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_amount_4_0=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        AntlrDatatypeRuleToken lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        Enumerator lv_typeCoin_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2953:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) )
            // InternalSM2.g:2954:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            {
            // InternalSM2.g:2954:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            // InternalSM2.g:2955:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,112,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getRestrictionGasAccess().getRequireKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:2963:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:2964:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:2964:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2.g:2965:5: lv_expr_2_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_61);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_2_0,
            						"org.xtext.SM2.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:2982:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:2983:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:2983:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:2984:5: lv_operator_3_0= ruleComparationOperator
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_46);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"operator",
            						lv_operator_3_0,
            						"org.xtext.SM2.ComparationOperator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:3001:3: ( (lv_amount_4_0= RULE_INT ) )
            // InternalSM2.g:3002:4: (lv_amount_4_0= RULE_INT )
            {
            // InternalSM2.g:3002:4: (lv_amount_4_0= RULE_INT )
            // InternalSM2.g:3003:5: lv_amount_4_0= RULE_INT
            {
            lv_amount_4_0=(Token)match(input,RULE_INT,FOLLOW_62); 

            					newLeafNode(lv_amount_4_0, grammarAccess.getRestrictionGasAccess().getAmountINTTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRestrictionGasRule());
            					}
            					setWithLastConsumed(
            						current,
            						"amount",
            						lv_amount_4_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalSM2.g:3019:3: ( (lv_typeCoin_5_0= ruleCoin ) )
            // InternalSM2.g:3020:4: (lv_typeCoin_5_0= ruleCoin )
            {
            // InternalSM2.g:3020:4: (lv_typeCoin_5_0= ruleCoin )
            // InternalSM2.g:3021:5: lv_typeCoin_5_0= ruleCoin
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0());
            				
            pushFollow(FOLLOW_10);
            lv_typeCoin_5_0=ruleCoin();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"typeCoin",
            						lv_typeCoin_5_0,
            						"org.xtext.SM2.Coin");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_33); 

            			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
            		
            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7());
            		
            this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_8, grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2.g:3054:1: entryRuleClause returns [EObject current=null] : iv_ruleClause= ruleClause EOF ;
    public final EObject entryRuleClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClause = null;


        try {
            // InternalSM2.g:3054:47: (iv_ruleClause= ruleClause EOF )
            // InternalSM2.g:3055:2: iv_ruleClause= ruleClause EOF
            {
             newCompositeNode(grammarAccess.getClauseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleClause=ruleClause();

            state._fsp--;

             current =iv_ruleClause; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2.g:3061:1: ruleClause returns [EObject current=null] : (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restriction_8_0= ruleRestrictionClause ) )? ( (lv_expression_9_0= ruleExpression ) )? (this_EOLINE_10= RULE_EOLINE )? this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE ) ;
    public final EObject ruleClause() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameFunction_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_OPENKEY_6=null;
        Token this_EOLINE_7=null;
        Token this_EOLINE_10=null;
        Token this_CLOSEKEY_11=null;
        Token this_EOLINE_12=null;
        EObject lv_inputParams_3_0 = null;

        Enumerator lv_visibilityAccess_4_0 = null;

        EObject lv_restriction_8_0 = null;

        AntlrDatatypeRuleToken lv_expression_9_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3067:2: ( (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restriction_8_0= ruleRestrictionClause ) )? ( (lv_expression_9_0= ruleExpression ) )? (this_EOLINE_10= RULE_EOLINE )? this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE ) )
            // InternalSM2.g:3068:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restriction_8_0= ruleRestrictionClause ) )? ( (lv_expression_9_0= ruleExpression ) )? (this_EOLINE_10= RULE_EOLINE )? this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE )
            {
            // InternalSM2.g:3068:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restriction_8_0= ruleRestrictionClause ) )? ( (lv_expression_9_0= ruleExpression ) )? (this_EOLINE_10= RULE_EOLINE )? this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE )
            // InternalSM2.g:3069:3: otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_OPENKEY_6= RULE_OPENKEY this_EOLINE_7= RULE_EOLINE ( (lv_restriction_8_0= ruleRestrictionClause ) )? ( (lv_expression_9_0= ruleExpression ) )? (this_EOLINE_10= RULE_EOLINE )? this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,113,FOLLOW_15); 

            			newLeafNode(otherlv_0, grammarAccess.getClauseAccess().getFunctionKeyword_0());
            		
            // InternalSM2.g:3073:3: ( (lv_nameFunction_1_0= RULE_ID ) )
            // InternalSM2.g:3074:4: (lv_nameFunction_1_0= RULE_ID )
            {
            // InternalSM2.g:3074:4: (lv_nameFunction_1_0= RULE_ID )
            // InternalSM2.g:3075:5: lv_nameFunction_1_0= RULE_ID
            {
            lv_nameFunction_1_0=(Token)match(input,RULE_ID,FOLLOW_8); 

            					newLeafNode(lv_nameFunction_1_0, grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getClauseRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameFunction",
            						lv_nameFunction_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_39); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		
            // InternalSM2.g:3095:3: ( (lv_inputParams_3_0= ruleInputParam ) )
            // InternalSM2.g:3096:4: (lv_inputParams_3_0= ruleInputParam )
            {
            // InternalSM2.g:3096:4: (lv_inputParams_3_0= ruleInputParam )
            // InternalSM2.g:3097:5: lv_inputParams_3_0= ruleInputParam
            {

            					newCompositeNode(grammarAccess.getClauseAccess().getInputParamsInputParamParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_63);
            lv_inputParams_3_0=ruleInputParam();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getClauseRule());
            					}
            					add(
            						current,
            						"inputParams",
            						lv_inputParams_3_0,
            						"org.xtext.SM2.InputParam");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:3114:3: ( (lv_visibilityAccess_4_0= ruleVisibility ) )
            // InternalSM2.g:3115:4: (lv_visibilityAccess_4_0= ruleVisibility )
            {
            // InternalSM2.g:3115:4: (lv_visibilityAccess_4_0= ruleVisibility )
            // InternalSM2.g:3116:5: lv_visibilityAccess_4_0= ruleVisibility
            {

            					newCompositeNode(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0());
            				
            pushFollow(FOLLOW_10);
            lv_visibilityAccess_4_0=ruleVisibility();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getClauseRule());
            					}
            					set(
            						current,
            						"visibilityAccess",
            						lv_visibilityAccess_4_0,
            						"org.xtext.SM2.Visibility");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_17); 

            			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
            		
            this_OPENKEY_6=(Token)match(input,RULE_OPENKEY,FOLLOW_12); 

            			newLeafNode(this_OPENKEY_6, grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_6());
            		
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_64); 

            			newLeafNode(this_EOLINE_7, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_7());
            		
            // InternalSM2.g:3145:3: ( (lv_restriction_8_0= ruleRestrictionClause ) )?
            int alt75=2;
            int LA75_0 = input.LA(1);

            if ( (LA75_0==112) ) {
                alt75=1;
            }
            switch (alt75) {
                case 1 :
                    // InternalSM2.g:3146:4: (lv_restriction_8_0= ruleRestrictionClause )
                    {
                    // InternalSM2.g:3146:4: (lv_restriction_8_0= ruleRestrictionClause )
                    // InternalSM2.g:3147:5: lv_restriction_8_0= ruleRestrictionClause
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getRestrictionRestrictionClauseParserRuleCall_8_0());
                    				
                    pushFollow(FOLLOW_65);
                    lv_restriction_8_0=ruleRestrictionClause();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"restriction",
                    						lv_restriction_8_0,
                    						"org.xtext.SM2.RestrictionClause");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:3164:3: ( (lv_expression_9_0= ruleExpression ) )?
            int alt76=2;
            int LA76_0 = input.LA(1);

            if ( (LA76_0==RULE_STRING||LA76_0==121) ) {
                alt76=1;
            }
            switch (alt76) {
                case 1 :
                    // InternalSM2.g:3165:4: (lv_expression_9_0= ruleExpression )
                    {
                    // InternalSM2.g:3165:4: (lv_expression_9_0= ruleExpression )
                    // InternalSM2.g:3166:5: lv_expression_9_0= ruleExpression
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_9_0());
                    				
                    pushFollow(FOLLOW_66);
                    lv_expression_9_0=ruleExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"expression",
                    						lv_expression_9_0,
                    						"org.xtext.SM2.Expression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:3183:3: (this_EOLINE_10= RULE_EOLINE )?
            int alt77=2;
            int LA77_0 = input.LA(1);

            if ( (LA77_0==RULE_EOLINE) ) {
                alt77=1;
            }
            switch (alt77) {
                case 1 :
                    // InternalSM2.g:3184:4: this_EOLINE_10= RULE_EOLINE
                    {
                    this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_31); 

                    				newLeafNode(this_EOLINE_10, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_10());
                    			

                    }
                    break;

            }

            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_12); 

            			newLeafNode(this_CLOSEKEY_11, grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_11());
            		
            this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_12, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRuleSelfdestruct"
    // InternalSM2.g:3201:1: entryRuleSelfdestruct returns [EObject current=null] : iv_ruleSelfdestruct= ruleSelfdestruct EOF ;
    public final EObject entryRuleSelfdestruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSelfdestruct = null;


        try {
            // InternalSM2.g:3201:53: (iv_ruleSelfdestruct= ruleSelfdestruct EOF )
            // InternalSM2.g:3202:2: iv_ruleSelfdestruct= ruleSelfdestruct EOF
            {
             newCompositeNode(grammarAccess.getSelfdestructRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSelfdestruct=ruleSelfdestruct();

            state._fsp--;

             current =iv_ruleSelfdestruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSelfdestruct"


    // $ANTLR start "ruleSelfdestruct"
    // InternalSM2.g:3208:1: ruleSelfdestruct returns [EObject current=null] : (otherlv_0= 'selfdesctruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) ;
    public final EObject ruleSelfdestruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;


        	enterRule();

        try {
            // InternalSM2.g:3214:2: ( (otherlv_0= 'selfdesctruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:3215:2: (otherlv_0= 'selfdesctruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:3215:2: (otherlv_0= 'selfdesctruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:3216:3: otherlv_0= 'selfdesctruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ruleSyntaxExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,114,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getSelfdestructAccess().getSelfdesctructKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getSelfdestructAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		

            			newCompositeNode(grammarAccess.getSelfdestructAccess().getSyntaxExpressionParserRuleCall_2());
            		
            pushFollow(FOLLOW_10);
            ruleSyntaxExpression();

            state._fsp--;


            			afterParserOrEnumRuleCall();
            		
            this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_33); 

            			newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getSelfdestructAccess().getCLOSEPARENTHESISTerminalRuleCall_3());
            		
            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_34); 

            			newLeafNode(this_SEMICOLON_4, grammarAccess.getSelfdestructAccess().getSEMICOLONTerminalRuleCall_4());
            		
            // InternalSM2.g:3239:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt78=2;
            int LA78_0 = input.LA(1);

            if ( (LA78_0==RULE_EOLINE) ) {
                alt78=1;
            }
            switch (alt78) {
                case 1 :
                    // InternalSM2.g:3240:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_5, grammarAccess.getSelfdestructAccess().getEOLINETerminalRuleCall_5());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSelfdestruct"


    // $ANTLR start "entryRuleCryptographycFunctions"
    // InternalSM2.g:3249:1: entryRuleCryptographycFunctions returns [EObject current=null] : iv_ruleCryptographycFunctions= ruleCryptographycFunctions EOF ;
    public final EObject entryRuleCryptographycFunctions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCryptographycFunctions = null;


        try {
            // InternalSM2.g:3249:63: (iv_ruleCryptographycFunctions= ruleCryptographycFunctions EOF )
            // InternalSM2.g:3250:2: iv_ruleCryptographycFunctions= ruleCryptographycFunctions EOF
            {
             newCompositeNode(grammarAccess.getCryptographycFunctionsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCryptographycFunctions=ruleCryptographycFunctions();

            state._fsp--;

             current =iv_ruleCryptographycFunctions; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCryptographycFunctions"


    // $ANTLR start "ruleCryptographycFunctions"
    // InternalSM2.g:3256:1: ruleCryptographycFunctions returns [EObject current=null] : ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? ) ) ;
    public final EObject ruleCryptographycFunctions() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_STRING_2=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token this_SEMICOLON_4=null;
        Token otherlv_5=null;
        Token this_OPENPARENTHESIS_6=null;
        Token this_STRING_7=null;
        Token this_CLOSEPARENTHESIS_8=null;
        Token this_SEMICOLON_9=null;
        Token otherlv_10=null;
        Token this_OPENPARENTHESIS_11=null;
        Token this_STRING_12=null;
        Token this_CLOSEPARENTHESIS_13=null;
        Token this_SEMICOLON_14=null;


        	enterRule();

        try {
            // InternalSM2.g:3262:2: ( ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? ) ) )
            // InternalSM2.g:3263:2: ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? ) )
            {
            // InternalSM2.g:3263:2: ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? ) )
            int alt82=3;
            switch ( input.LA(1) ) {
            case 115:
                {
                alt82=1;
                }
                break;
            case 116:
                {
                alt82=2;
                }
                break;
            case 117:
                {
                alt82=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 82, 0, input);

                throw nvae;
            }

            switch (alt82) {
                case 1 :
                    // InternalSM2.g:3264:3: (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:3264:3: (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? )
                    // InternalSM2.g:3265:4: otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )?
                    {
                    otherlv_0=(Token)match(input,115,FOLLOW_8); 

                    				newLeafNode(otherlv_0, grammarAccess.getCryptographycFunctionsAccess().getKeccack256Keyword_0_0());
                    			
                    this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_32); 

                    				newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_0_1());
                    			
                    this_STRING_2=(Token)match(input,RULE_STRING,FOLLOW_10); 

                    				newLeafNode(this_STRING_2, grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_0_2());
                    			
                    this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                    				newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_0_3());
                    			
                    // InternalSM2.g:3281:4: (this_SEMICOLON_4= RULE_SEMICOLON )?
                    int alt79=2;
                    int LA79_0 = input.LA(1);

                    if ( (LA79_0==RULE_SEMICOLON) ) {
                        alt79=1;
                    }
                    switch (alt79) {
                        case 1 :
                            // InternalSM2.g:3282:5: this_SEMICOLON_4= RULE_SEMICOLON
                            {
                            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_4, grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_0_4());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3289:3: (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:3289:3: (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? )
                    // InternalSM2.g:3290:4: otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )?
                    {
                    otherlv_5=(Token)match(input,116,FOLLOW_8); 

                    				newLeafNode(otherlv_5, grammarAccess.getCryptographycFunctionsAccess().getSha256Keyword_1_0());
                    			
                    this_OPENPARENTHESIS_6=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_32); 

                    				newLeafNode(this_OPENPARENTHESIS_6, grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_1_1());
                    			
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_10); 

                    				newLeafNode(this_STRING_7, grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_1_2());
                    			
                    this_CLOSEPARENTHESIS_8=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                    				newLeafNode(this_CLOSEPARENTHESIS_8, grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3());
                    			
                    // InternalSM2.g:3306:4: (this_SEMICOLON_9= RULE_SEMICOLON )?
                    int alt80=2;
                    int LA80_0 = input.LA(1);

                    if ( (LA80_0==RULE_SEMICOLON) ) {
                        alt80=1;
                    }
                    switch (alt80) {
                        case 1 :
                            // InternalSM2.g:3307:5: this_SEMICOLON_9= RULE_SEMICOLON
                            {
                            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_9, grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_1_4());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3314:3: (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:3314:3: (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )? )
                    // InternalSM2.g:3315:4: otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING this_CLOSEPARENTHESIS_13= RULE_CLOSEPARENTHESIS (this_SEMICOLON_14= RULE_SEMICOLON )?
                    {
                    otherlv_10=(Token)match(input,117,FOLLOW_8); 

                    				newLeafNode(otherlv_10, grammarAccess.getCryptographycFunctionsAccess().getSha3Keyword_2_0());
                    			
                    this_OPENPARENTHESIS_11=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_32); 

                    				newLeafNode(this_OPENPARENTHESIS_11, grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_2_1());
                    			
                    this_STRING_12=(Token)match(input,RULE_STRING,FOLLOW_10); 

                    				newLeafNode(this_STRING_12, grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_2_2());
                    			
                    this_CLOSEPARENTHESIS_13=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); 

                    				newLeafNode(this_CLOSEPARENTHESIS_13, grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_2_3());
                    			
                    // InternalSM2.g:3331:4: (this_SEMICOLON_14= RULE_SEMICOLON )?
                    int alt81=2;
                    int LA81_0 = input.LA(1);

                    if ( (LA81_0==RULE_SEMICOLON) ) {
                        alt81=1;
                    }
                    switch (alt81) {
                        case 1 :
                            // InternalSM2.g:3332:5: this_SEMICOLON_14= RULE_SEMICOLON
                            {
                            this_SEMICOLON_14=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_14, grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_2_4());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCryptographycFunctions"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:3342:1: entryRuleComment returns [EObject current=null] : iv_ruleComment= ruleComment EOF ;
    public final EObject entryRuleComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleComment = null;


        try {
            // InternalSM2.g:3342:48: (iv_ruleComment= ruleComment EOF )
            // InternalSM2.g:3343:2: iv_ruleComment= ruleComment EOF
            {
             newCompositeNode(grammarAccess.getCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleComment=ruleComment();

            state._fsp--;

             current =iv_ruleComment; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:3349:1: ruleComment returns [EObject current=null] : ( ruleShortComment | ruleLongComment ) ;
    public final EObject ruleComment() throws RecognitionException {
        EObject current = null;


        	enterRule();

        try {
            // InternalSM2.g:3355:2: ( ( ruleShortComment | ruleLongComment ) )
            // InternalSM2.g:3356:2: ( ruleShortComment | ruleLongComment )
            {
            // InternalSM2.g:3356:2: ( ruleShortComment | ruleLongComment )
            int alt83=2;
            int LA83_0 = input.LA(1);

            if ( (LA83_0==118) ) {
                alt83=1;
            }
            else if ( (LA83_0==119) ) {
                alt83=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 83, 0, input);

                throw nvae;
            }
            switch (alt83) {
                case 1 :
                    // InternalSM2.g:3357:3: ruleShortComment
                    {

                    			newCompositeNode(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    ruleShortComment();

                    state._fsp--;


                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3365:3: ruleLongComment
                    {

                    			newCompositeNode(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    ruleLongComment();

                    state._fsp--;


                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:3376:1: entryRuleShortComment returns [String current=null] : iv_ruleShortComment= ruleShortComment EOF ;
    public final String entryRuleShortComment() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleShortComment = null;


        try {
            // InternalSM2.g:3376:52: (iv_ruleShortComment= ruleShortComment EOF )
            // InternalSM2.g:3377:2: iv_ruleShortComment= ruleShortComment EOF
            {
             newCompositeNode(grammarAccess.getShortCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleShortComment=ruleShortComment();

            state._fsp--;

             current =iv_ruleShortComment.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:3383:1: ruleShortComment returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE ) ;
    public final AntlrDatatypeRuleToken ruleShortComment() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_STRING_1=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:3389:2: ( (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE ) )
            // InternalSM2.g:3390:2: (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE )
            {
            // InternalSM2.g:3390:2: (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE )
            // InternalSM2.g:3391:3: kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE
            {
            kw=(Token)match(input,118,FOLLOW_32); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0());
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_12); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getShortCommentAccess().getSTRINGTerminalRuleCall_1());
            		
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			current.merge(this_EOLINE_2);
            		

            			newLeafNode(this_EOLINE_2, grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:3414:1: entryRuleLongComment returns [String current=null] : iv_ruleLongComment= ruleLongComment EOF ;
    public final String entryRuleLongComment() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleLongComment = null;


        try {
            // InternalSM2.g:3414:51: (iv_ruleLongComment= ruleLongComment EOF )
            // InternalSM2.g:3415:2: iv_ruleLongComment= ruleLongComment EOF
            {
             newCompositeNode(grammarAccess.getLongCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLongComment=ruleLongComment();

            state._fsp--;

             current =iv_ruleLongComment.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:3421:1: ruleLongComment returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= '/*' this_STRING_1= RULE_STRING kw= '*/' ) ;
    public final AntlrDatatypeRuleToken ruleLongComment() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_STRING_1=null;


        	enterRule();

        try {
            // InternalSM2.g:3427:2: ( (kw= '/*' this_STRING_1= RULE_STRING kw= '*/' ) )
            // InternalSM2.g:3428:2: (kw= '/*' this_STRING_1= RULE_STRING kw= '*/' )
            {
            // InternalSM2.g:3428:2: (kw= '/*' this_STRING_1= RULE_STRING kw= '*/' )
            // InternalSM2.g:3429:3: kw= '/*' this_STRING_1= RULE_STRING kw= '*/'
            {
            kw=(Token)match(input,119,FOLLOW_32); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0());
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_67); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getLongCommentAccess().getSTRINGTerminalRuleCall_1());
            		
            kw=(Token)match(input,120,FOLLOW_2); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:3450:1: entryRuleExpression returns [String current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final String entryRuleExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleExpression = null;


        try {
            // InternalSM2.g:3450:50: (iv_ruleExpression= ruleExpression EOF )
            // InternalSM2.g:3451:2: iv_ruleExpression= ruleExpression EOF
            {
             newCompositeNode(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;

             current =iv_ruleExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:3457:1: ruleExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression ) ;
    public final AntlrDatatypeRuleToken ruleExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        AntlrDatatypeRuleToken this_NegationExpression_0 = null;

        AntlrDatatypeRuleToken this_SyntaxExpression_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:3463:2: ( (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression ) )
            // InternalSM2.g:3464:2: (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression )
            {
            // InternalSM2.g:3464:2: (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression )
            int alt84=2;
            int LA84_0 = input.LA(1);

            if ( (LA84_0==121) ) {
                alt84=1;
            }
            else if ( (LA84_0==RULE_STRING) ) {
                alt84=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 84, 0, input);

                throw nvae;
            }
            switch (alt84) {
                case 1 :
                    // InternalSM2.g:3465:3: this_NegationExpression_0= ruleNegationExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getNegationExpressionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_NegationExpression_0=ruleNegationExpression();

                    state._fsp--;


                    			current.merge(this_NegationExpression_0);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3476:3: this_SyntaxExpression_1= ruleSyntaxExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_SyntaxExpression_1=ruleSyntaxExpression();

                    state._fsp--;


                    			current.merge(this_SyntaxExpression_1);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleLogicalUnaryOperator"
    // InternalSM2.g:3490:1: entryRuleLogicalUnaryOperator returns [String current=null] : iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF ;
    public final String entryRuleLogicalUnaryOperator() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleLogicalUnaryOperator = null;


        try {
            // InternalSM2.g:3490:60: (iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF )
            // InternalSM2.g:3491:2: iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF
            {
             newCompositeNode(grammarAccess.getLogicalUnaryOperatorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLogicalUnaryOperator=ruleLogicalUnaryOperator();

            state._fsp--;

             current =iv_ruleLogicalUnaryOperator.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLogicalUnaryOperator"


    // $ANTLR start "ruleLogicalUnaryOperator"
    // InternalSM2.g:3497:1: ruleLogicalUnaryOperator returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '!' ;
    public final AntlrDatatypeRuleToken ruleLogicalUnaryOperator() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSM2.g:3503:2: (kw= '!' )
            // InternalSM2.g:3504:2: kw= '!'
            {
            kw=(Token)match(input,121,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getLogicalUnaryOperatorAccess().getExclamationMarkKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalUnaryOperator"


    // $ANTLR start "entryRuleNegationExpression"
    // InternalSM2.g:3512:1: entryRuleNegationExpression returns [String current=null] : iv_ruleNegationExpression= ruleNegationExpression EOF ;
    public final String entryRuleNegationExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleNegationExpression = null;


        try {
            // InternalSM2.g:3512:58: (iv_ruleNegationExpression= ruleNegationExpression EOF )
            // InternalSM2.g:3513:2: iv_ruleNegationExpression= ruleNegationExpression EOF
            {
             newCompositeNode(grammarAccess.getNegationExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNegationExpression=ruleNegationExpression();

            state._fsp--;

             current =iv_ruleNegationExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNegationExpression"


    // $ANTLR start "ruleNegationExpression"
    // InternalSM2.g:3519:1: ruleNegationExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING ) ;
    public final AntlrDatatypeRuleToken ruleNegationExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_1=null;
        AntlrDatatypeRuleToken this_LogicalUnaryOperator_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3525:2: ( (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING ) )
            // InternalSM2.g:3526:2: (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING )
            {
            // InternalSM2.g:3526:2: (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING )
            // InternalSM2.g:3527:3: this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING
            {

            			newCompositeNode(grammarAccess.getNegationExpressionAccess().getLogicalUnaryOperatorParserRuleCall_0());
            		
            pushFollow(FOLLOW_32);
            this_LogicalUnaryOperator_0=ruleLogicalUnaryOperator();

            state._fsp--;


            			current.merge(this_LogicalUnaryOperator_0);
            		

            			afterParserOrEnumRuleCall();
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_2); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getNegationExpressionAccess().getSTRINGTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNegationExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:3548:1: entryRuleSyntaxExpression returns [String current=null] : iv_ruleSyntaxExpression= ruleSyntaxExpression EOF ;
    public final String entryRuleSyntaxExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleSyntaxExpression = null;


        try {
            // InternalSM2.g:3548:56: (iv_ruleSyntaxExpression= ruleSyntaxExpression EOF )
            // InternalSM2.g:3549:2: iv_ruleSyntaxExpression= ruleSyntaxExpression EOF
            {
             newCompositeNode(grammarAccess.getSyntaxExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSyntaxExpression=ruleSyntaxExpression();

            state._fsp--;

             current =iv_ruleSyntaxExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:3555:1: ruleSyntaxExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? ) ;
    public final AntlrDatatypeRuleToken ruleSyntaxExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_SEMICOLON_1=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:3561:2: ( (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? ) )
            // InternalSM2.g:3562:2: (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? )
            {
            // InternalSM2.g:3562:2: (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? )
            // InternalSM2.g:3563:3: this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )?
            {
            this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

            			current.merge(this_STRING_0);
            		

            			newLeafNode(this_STRING_0, grammarAccess.getSyntaxExpressionAccess().getSTRINGTerminalRuleCall_0());
            		
            // InternalSM2.g:3570:3: (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )?
            int alt85=2;
            int LA85_0 = input.LA(1);

            if ( (LA85_0==RULE_SEMICOLON) ) {
                alt85=1;
            }
            switch (alt85) {
                case 1 :
                    // InternalSM2.g:3571:4: this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE
                    {
                    this_SEMICOLON_1=(Token)match(input,RULE_SEMICOLON,FOLLOW_12); 

                    				current.merge(this_SEMICOLON_1);
                    			

                    				newLeafNode(this_SEMICOLON_1, grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_0());
                    			
                    this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				current.merge(this_EOLINE_2);
                    			

                    				newLeafNode(this_EOLINE_2, grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:3590:1: ruleVisibility returns [Enumerator current=null] : ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) ) ;
    public final Enumerator ruleVisibility() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalSM2.g:3596:2: ( ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) ) )
            // InternalSM2.g:3597:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) )
            {
            // InternalSM2.g:3597:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) )
            int alt86=3;
            switch ( input.LA(1) ) {
            case 65:
                {
                alt86=1;
                }
                break;
            case 122:
                {
                alt86=2;
                }
                break;
            case 66:
                {
                alt86=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 86, 0, input);

                throw nvae;
            }

            switch (alt86) {
                case 1 :
                    // InternalSM2.g:3598:3: (enumLiteral_0= 'public' )
                    {
                    // InternalSM2.g:3598:3: (enumLiteral_0= 'public' )
                    // InternalSM2.g:3599:4: enumLiteral_0= 'public'
                    {
                    enumLiteral_0=(Token)match(input,65,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3606:3: (enumLiteral_1= 'private' )
                    {
                    // InternalSM2.g:3606:3: (enumLiteral_1= 'private' )
                    // InternalSM2.g:3607:4: enumLiteral_1= 'private'
                    {
                    enumLiteral_1=(Token)match(input,122,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3614:3: (enumLiteral_2= 'internal' )
                    {
                    // InternalSM2.g:3614:3: (enumLiteral_2= 'internal' )
                    // InternalSM2.g:3615:4: enumLiteral_2= 'internal'
                    {
                    enumLiteral_2=(Token)match(input,66,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:3625:1: ruleCoin returns [Enumerator current=null] : ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) ;
    public final Enumerator ruleCoin() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:3631:2: ( ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) )
            // InternalSM2.g:3632:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            {
            // InternalSM2.g:3632:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            int alt87=6;
            switch ( input.LA(1) ) {
            case 123:
                {
                alt87=1;
                }
                break;
            case 124:
                {
                alt87=2;
                }
                break;
            case 125:
                {
                alt87=3;
                }
                break;
            case 126:
                {
                alt87=4;
                }
                break;
            case 127:
                {
                alt87=5;
                }
                break;
            case 128:
                {
                alt87=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 87, 0, input);

                throw nvae;
            }

            switch (alt87) {
                case 1 :
                    // InternalSM2.g:3633:3: (enumLiteral_0= 'ether' )
                    {
                    // InternalSM2.g:3633:3: (enumLiteral_0= 'ether' )
                    // InternalSM2.g:3634:4: enumLiteral_0= 'ether'
                    {
                    enumLiteral_0=(Token)match(input,123,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3641:3: (enumLiteral_1= 'wei' )
                    {
                    // InternalSM2.g:3641:3: (enumLiteral_1= 'wei' )
                    // InternalSM2.g:3642:4: enumLiteral_1= 'wei'
                    {
                    enumLiteral_1=(Token)match(input,124,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3649:3: (enumLiteral_2= 'gwei' )
                    {
                    // InternalSM2.g:3649:3: (enumLiteral_2= 'gwei' )
                    // InternalSM2.g:3650:4: enumLiteral_2= 'gwei'
                    {
                    enumLiteral_2=(Token)match(input,125,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:3657:3: (enumLiteral_3= 'pwei' )
                    {
                    // InternalSM2.g:3657:3: (enumLiteral_3= 'pwei' )
                    // InternalSM2.g:3658:4: enumLiteral_3= 'pwei'
                    {
                    enumLiteral_3=(Token)match(input,126,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:3665:3: (enumLiteral_4= 'finney' )
                    {
                    // InternalSM2.g:3665:3: (enumLiteral_4= 'finney' )
                    // InternalSM2.g:3666:4: enumLiteral_4= 'finney'
                    {
                    enumLiteral_4=(Token)match(input,127,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:3673:3: (enumLiteral_5= 'szabo' )
                    {
                    // InternalSM2.g:3673:3: (enumLiteral_5= 'szabo' )
                    // InternalSM2.g:3674:4: enumLiteral_5= 'szabo'
                    {
                    enumLiteral_5=(Token)match(input,128,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:3684:1: ruleComparationOperator returns [Enumerator current=null] : ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) ;
    public final Enumerator ruleComparationOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:3690:2: ( ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) )
            // InternalSM2.g:3691:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            {
            // InternalSM2.g:3691:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            int alt88=6;
            switch ( input.LA(1) ) {
            case 62:
                {
                alt88=1;
                }
                break;
            case 129:
                {
                alt88=2;
                }
                break;
            case 63:
                {
                alt88=3;
                }
                break;
            case 130:
                {
                alt88=4;
                }
                break;
            case 131:
                {
                alt88=5;
                }
                break;
            case 132:
                {
                alt88=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 88, 0, input);

                throw nvae;
            }

            switch (alt88) {
                case 1 :
                    // InternalSM2.g:3692:3: (enumLiteral_0= '>' )
                    {
                    // InternalSM2.g:3692:3: (enumLiteral_0= '>' )
                    // InternalSM2.g:3693:4: enumLiteral_0= '>'
                    {
                    enumLiteral_0=(Token)match(input,62,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3700:3: (enumLiteral_1= '<' )
                    {
                    // InternalSM2.g:3700:3: (enumLiteral_1= '<' )
                    // InternalSM2.g:3701:4: enumLiteral_1= '<'
                    {
                    enumLiteral_1=(Token)match(input,129,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3708:3: (enumLiteral_2= '>=' )
                    {
                    // InternalSM2.g:3708:3: (enumLiteral_2= '>=' )
                    // InternalSM2.g:3709:4: enumLiteral_2= '>='
                    {
                    enumLiteral_2=(Token)match(input,63,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:3716:3: (enumLiteral_3= '<=' )
                    {
                    // InternalSM2.g:3716:3: (enumLiteral_3= '<=' )
                    // InternalSM2.g:3717:4: enumLiteral_3= '<='
                    {
                    enumLiteral_3=(Token)match(input,130,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:3724:3: (enumLiteral_4= '==' )
                    {
                    // InternalSM2.g:3724:3: (enumLiteral_4= '==' )
                    // InternalSM2.g:3725:4: enumLiteral_4= '=='
                    {
                    enumLiteral_4=(Token)match(input,131,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:3732:3: (enumLiteral_5= '!=' )
                    {
                    // InternalSM2.g:3732:3: (enumLiteral_5= '!=' )
                    // InternalSM2.g:3733:4: enumLiteral_5= '!='
                    {
                    enumLiteral_5=(Token)match(input,132,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:3743:1: ruleLogicalPairOperator returns [Enumerator current=null] : ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) ;
    public final Enumerator ruleLogicalPairOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSM2.g:3749:2: ( ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) )
            // InternalSM2.g:3750:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            {
            // InternalSM2.g:3750:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            int alt89=2;
            int LA89_0 = input.LA(1);

            if ( (LA89_0==133) ) {
                alt89=1;
            }
            else if ( (LA89_0==134) ) {
                alt89=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 89, 0, input);

                throw nvae;
            }
            switch (alt89) {
                case 1 :
                    // InternalSM2.g:3751:3: (enumLiteral_0= '&&' )
                    {
                    // InternalSM2.g:3751:3: (enumLiteral_0= '&&' )
                    // InternalSM2.g:3752:4: enumLiteral_0= '&&'
                    {
                    enumLiteral_0=(Token)match(input,133,FOLLOW_2); 

                    				current = grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3759:3: (enumLiteral_1= '||' )
                    {
                    // InternalSM2.g:3759:3: (enumLiteral_1= '||' )
                    // InternalSM2.g:3760:4: enumLiteral_1= '||'
                    {
                    enumLiteral_1=(Token)match(input,134,FOLLOW_2); 

                    				current = grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:3770:1: ruleArithmeticalOperator returns [Enumerator current=null] : ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) ;
    public final Enumerator ruleArithmeticalOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;


        	enterRule();

        try {
            // InternalSM2.g:3776:2: ( ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) )
            // InternalSM2.g:3777:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            {
            // InternalSM2.g:3777:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            int alt90=5;
            switch ( input.LA(1) ) {
            case 135:
                {
                alt90=1;
                }
                break;
            case 136:
                {
                alt90=2;
                }
                break;
            case 137:
                {
                alt90=3;
                }
                break;
            case 138:
                {
                alt90=4;
                }
                break;
            case 139:
                {
                alt90=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 90, 0, input);

                throw nvae;
            }

            switch (alt90) {
                case 1 :
                    // InternalSM2.g:3778:3: (enumLiteral_0= '+' )
                    {
                    // InternalSM2.g:3778:3: (enumLiteral_0= '+' )
                    // InternalSM2.g:3779:4: enumLiteral_0= '+'
                    {
                    enumLiteral_0=(Token)match(input,135,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3786:3: (enumLiteral_1= '-' )
                    {
                    // InternalSM2.g:3786:3: (enumLiteral_1= '-' )
                    // InternalSM2.g:3787:4: enumLiteral_1= '-'
                    {
                    enumLiteral_1=(Token)match(input,136,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3794:3: (enumLiteral_2= '*' )
                    {
                    // InternalSM2.g:3794:3: (enumLiteral_2= '*' )
                    // InternalSM2.g:3795:4: enumLiteral_2= '*'
                    {
                    enumLiteral_2=(Token)match(input,137,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:3802:3: (enumLiteral_3= '/' )
                    {
                    // InternalSM2.g:3802:3: (enumLiteral_3= '/' )
                    // InternalSM2.g:3803:4: enumLiteral_3= '/'
                    {
                    enumLiteral_3=(Token)match(input,138,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:3810:3: (enumLiteral_4= '%' )
                    {
                    // InternalSM2.g:3810:3: (enumLiteral_4= '%' )
                    // InternalSM2.g:3811:4: enumLiteral_4= '%'
                    {
                    enumLiteral_4=(Token)match(input,139,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmeticalOperator"

    // Delegated rules


    protected DFA74 dfa74 = new DFA74(this);
    static final String dfa_1s = "\16\uffff";
    static final String dfa_2s = "\1\160\1\5\1\17\1\7\1\10\6\17\1\76\2\uffff";
    static final String dfa_3s = "\1\160\1\5\1\17\1\u0084\1\10\6\21\1\u0084\2\uffff";
    static final String dfa_4s = "\14\uffff\1\1\1\2";
    static final String dfa_5s = "\16\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\4\66\uffff\1\5\1\7\101\uffff\1\6\1\10\1\11\1\12",
            "\1\13",
            "\1\14\1\uffff\1\15",
            "\1\14\1\uffff\1\15",
            "\1\14\1\uffff\1\15",
            "\1\14\1\uffff\1\15",
            "\1\14\1\uffff\1\15",
            "\1\14\1\uffff\1\15",
            "\1\5\1\7\101\uffff\1\6\1\10\1\11\1\12",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA74 extends DFA {

        public DFA74(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 74;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "2822:2: (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0200000000000000L,0x00001FF800002FC0L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000002L,0x00C0000000000000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x00003E0000000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000008000L,0x0200000000000000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000082L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x001F800000000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0180000000000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0400000000000400L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000000100L,0x0000000000000001L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000000A00L,0x00C21FF80DFFEFD0L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000000A00L,0x00021FF80DFFEFD0L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000000800L,0x0002000000000010L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000000800L,0x0002000000000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x1000000000000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0xE000000000000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000000000280L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000000000L,0x0000000000003FC6L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000000200L,0x00001FF80DFFEFC0L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000000000000102L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000000040L,0x0000000000003FC0L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000000000008100L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000000000100L,0x0000000000000020L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000000000000L,0x0000000000003FC0L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000000200L,0x0400000000000006L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000000000100L,0x00001FF800002FC0L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000000000000000L,0x00001FF800002FC0L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000000000010800L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000000002L,0x0000000030000000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000000000000000L,0x0000000040000000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000000200L,0x00000001B0000000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000000200L,0x0000000180000000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000000000080L,0x0000000200000000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0000000000000000L,0x0000000400000000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0000000000000200L,0x0400000030000006L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0000000000000000L,0x0000000200000000L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0000000000020080L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0000000000000200L,0x04000001B0000006L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0000000000000200L,0x0400000180000006L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0000000000000000L,0x0000200000000000L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0000000000000000L,0x0000400000000000L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0000000000000000L,0x0000800000000000L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0xC000000000000000L,0x0000000000000000L,0x000000000000001EL});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x0000000000000000L,0xF800000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x0000000000000000L,0x0400000000000006L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x0000000000008900L,0x0201000000000000L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0000000000008900L,0x0200000000000000L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0000000000000900L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0000000000000000L,0x0100000000000000L});

}