package org.xtext.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_ID", "RULE_OPENKEY", "RULE_CLOSEKEY", "RULE_NUMBER", "RULE_DOT", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_STRING", "RULE_EMAIL", "RULE_COMMA", "RULE_INT", "RULE_PARAMSLONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_NOTICELONGCOMENT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'pragma'", "'solidity'", "'contract'", "'is'", "'^'", "'>'", "'>='", "'<'", "'<='", "'import'", "'as'", "'event'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'address'", "'='", "'string'", "'uint'", "'enum'", "'require'", "'function'", "'//'", "'/*'", "'*/'", "'int'", "'uint8'", "'uint256'", "'address payable'", "'double'", "'bool'", "'public'", "'private'", "'internal'", "'external'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'=='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'"
    };
    public static final int T__50=50;
    public static final int RULE_OPENPARENTHESIS=11;
    public static final int RULE_EOLINE=5;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int RULE_CLOSEKEY=8;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_PARAMSLONGCOMENT=17;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=6;
    public static final int RULE_COMMA=15;
    public static final int RULE_RETURNSLONGCOMENT=19;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=16;
    public static final int T__29=29;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=22;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int RULE_SEMICOLON=4;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_TITLELONGCOMENT=20;
    public static final int RULE_STRING=13;
    public static final int RULE_EMAIL=14;
    public static final int RULE_NOTICELONGCOMENT=21;
    public static final int RULE_SL_COMMENT=23;
    public static final int T__37=37;
    public static final int RULE_OPENKEY=7;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int RULE_CLOSEPARENTHESIS=12;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__73=73;
    public static final int RULE_DOT=10;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__74=74;
    public static final int T__31=31;
    public static final int T__75=75;
    public static final int T__32=32;
    public static final int T__76=76;
    public static final int RULE_WS=24;
    public static final int RULE_ANY_OTHER=25;
    public static final int RULE_NUMBER=9;
    public static final int RULE_DEVLONGCOMENT=18;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }



     	private SM2GrammarAccess grammarAccess;

        public InternalSM2Parser(TokenStream input, SM2GrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "SmartContract";
       	}

       	@Override
       	protected SM2GrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleSmartContract"
    // InternalSM2.g:65:1: entryRuleSmartContract returns [EObject current=null] : iv_ruleSmartContract= ruleSmartContract EOF ;
    public final EObject entryRuleSmartContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSmartContract = null;


        try {
            // InternalSM2.g:65:54: (iv_ruleSmartContract= ruleSmartContract EOF )
            // InternalSM2.g:66:2: iv_ruleSmartContract= ruleSmartContract EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSmartContractRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSmartContract=ruleSmartContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSmartContract; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSmartContract"


    // $ANTLR start "ruleSmartContract"
    // InternalSM2.g:72:1: ruleSmartContract returns [EObject current=null] : ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_contract_6_0= 'contract' ) ) ( (lv_nameContract_7_0= RULE_ID ) ) (otherlv_8= 'is' ( (lv_nameContractFather_9_0= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY (this_EOLINE_11= RULE_EOLINE )? ( (lv_attributes_12_0= ruleAttributes ) )* ( (lv_events_13_0= ruleEvent ) )* ( (lv_modifier_14_0= ruleModifier ) )* ( (lv_clauses_15_0= ruleClause ) )* ( (lv_comments_16_0= ruleComment ) )* this_CLOSEKEY_17= RULE_CLOSEKEY ) ;
    public final EObject ruleSmartContract() throws RecognitionException {
        EObject current = null;

        Token lv_compiler_0_0=null;
        Token otherlv_1=null;
        Token this_SEMICOLON_3=null;
        Token this_EOLINE_4=null;
        Token lv_contract_6_0=null;
        Token lv_nameContract_7_0=null;
        Token otherlv_8=null;
        Token lv_nameContractFather_9_0=null;
        Token this_OPENKEY_10=null;
        Token this_EOLINE_11=null;
        Token this_CLOSEKEY_17=null;
        EObject lv_VersionCompiler_2_0 = null;

        EObject lv_imports_5_0 = null;

        EObject lv_attributes_12_0 = null;

        EObject lv_events_13_0 = null;

        EObject lv_modifier_14_0 = null;

        EObject lv_clauses_15_0 = null;

        EObject lv_comments_16_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:78:2: ( ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_contract_6_0= 'contract' ) ) ( (lv_nameContract_7_0= RULE_ID ) ) (otherlv_8= 'is' ( (lv_nameContractFather_9_0= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY (this_EOLINE_11= RULE_EOLINE )? ( (lv_attributes_12_0= ruleAttributes ) )* ( (lv_events_13_0= ruleEvent ) )* ( (lv_modifier_14_0= ruleModifier ) )* ( (lv_clauses_15_0= ruleClause ) )* ( (lv_comments_16_0= ruleComment ) )* this_CLOSEKEY_17= RULE_CLOSEKEY ) )
            // InternalSM2.g:79:2: ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_contract_6_0= 'contract' ) ) ( (lv_nameContract_7_0= RULE_ID ) ) (otherlv_8= 'is' ( (lv_nameContractFather_9_0= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY (this_EOLINE_11= RULE_EOLINE )? ( (lv_attributes_12_0= ruleAttributes ) )* ( (lv_events_13_0= ruleEvent ) )* ( (lv_modifier_14_0= ruleModifier ) )* ( (lv_clauses_15_0= ruleClause ) )* ( (lv_comments_16_0= ruleComment ) )* this_CLOSEKEY_17= RULE_CLOSEKEY )
            {
            // InternalSM2.g:79:2: ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_contract_6_0= 'contract' ) ) ( (lv_nameContract_7_0= RULE_ID ) ) (otherlv_8= 'is' ( (lv_nameContractFather_9_0= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY (this_EOLINE_11= RULE_EOLINE )? ( (lv_attributes_12_0= ruleAttributes ) )* ( (lv_events_13_0= ruleEvent ) )* ( (lv_modifier_14_0= ruleModifier ) )* ( (lv_clauses_15_0= ruleClause ) )* ( (lv_comments_16_0= ruleComment ) )* this_CLOSEKEY_17= RULE_CLOSEKEY )
            // InternalSM2.g:80:3: ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_contract_6_0= 'contract' ) ) ( (lv_nameContract_7_0= RULE_ID ) ) (otherlv_8= 'is' ( (lv_nameContractFather_9_0= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY (this_EOLINE_11= RULE_EOLINE )? ( (lv_attributes_12_0= ruleAttributes ) )* ( (lv_events_13_0= ruleEvent ) )* ( (lv_modifier_14_0= ruleModifier ) )* ( (lv_clauses_15_0= ruleClause ) )* ( (lv_comments_16_0= ruleComment ) )* this_CLOSEKEY_17= RULE_CLOSEKEY
            {
            // InternalSM2.g:80:3: ( (lv_compiler_0_0= 'pragma' ) )
            // InternalSM2.g:81:4: (lv_compiler_0_0= 'pragma' )
            {
            // InternalSM2.g:81:4: (lv_compiler_0_0= 'pragma' )
            // InternalSM2.g:82:5: lv_compiler_0_0= 'pragma'
            {
            lv_compiler_0_0=(Token)match(input,26,FOLLOW_3); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_compiler_0_0, grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getSmartContractRule());
              					}
              					setWithLastConsumed(current, "compiler", lv_compiler_0_0, "pragma");
              				
            }

            }


            }

            otherlv_1=(Token)match(input,27,FOLLOW_4); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getSmartContractAccess().getSolidityKeyword_1());
              		
            }
            // InternalSM2.g:98:3: ( (lv_VersionCompiler_2_0= ruleVersion ) )
            // InternalSM2.g:99:4: (lv_VersionCompiler_2_0= ruleVersion )
            {
            // InternalSM2.g:99:4: (lv_VersionCompiler_2_0= ruleVersion )
            // InternalSM2.g:100:5: lv_VersionCompiler_2_0= ruleVersion
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_5);
            lv_VersionCompiler_2_0=ruleVersion();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getSmartContractRule());
              					}
              					set(
              						current,
              						"VersionCompiler",
              						lv_VersionCompiler_2_0,
              						"org.xtext.SM2.Version");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_SEMICOLON_3=(Token)match(input,RULE_SEMICOLON,FOLLOW_6); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_3, grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:121:3: (this_EOLINE_4= RULE_EOLINE )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_EOLINE) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalSM2.g:122:4: this_EOLINE_4= RULE_EOLINE
                    {
                    this_EOLINE_4=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_4, grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:127:3: ( (lv_imports_5_0= ruleImport ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==35) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSM2.g:128:4: (lv_imports_5_0= ruleImport )
            	    {
            	    // InternalSM2.g:128:4: (lv_imports_5_0= ruleImport )
            	    // InternalSM2.g:129:5: lv_imports_5_0= ruleImport
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_5_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_7);
            	    lv_imports_5_0=ruleImport();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"imports",
            	      						lv_imports_5_0,
            	      						"org.xtext.SM2.Import");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalSM2.g:146:3: ( (lv_contract_6_0= 'contract' ) )
            // InternalSM2.g:147:4: (lv_contract_6_0= 'contract' )
            {
            // InternalSM2.g:147:4: (lv_contract_6_0= 'contract' )
            // InternalSM2.g:148:5: lv_contract_6_0= 'contract'
            {
            lv_contract_6_0=(Token)match(input,28,FOLLOW_8); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_contract_6_0, grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getSmartContractRule());
              					}
              					addWithLastConsumed(current, "contract", lv_contract_6_0, "contract");
              				
            }

            }


            }

            // InternalSM2.g:160:3: ( (lv_nameContract_7_0= RULE_ID ) )
            // InternalSM2.g:161:4: (lv_nameContract_7_0= RULE_ID )
            {
            // InternalSM2.g:161:4: (lv_nameContract_7_0= RULE_ID )
            // InternalSM2.g:162:5: lv_nameContract_7_0= RULE_ID
            {
            lv_nameContract_7_0=(Token)match(input,RULE_ID,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameContract_7_0, grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_7_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getSmartContractRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameContract",
              						lv_nameContract_7_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:178:3: (otherlv_8= 'is' ( (lv_nameContractFather_9_0= RULE_ID ) ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==29) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalSM2.g:179:4: otherlv_8= 'is' ( (lv_nameContractFather_9_0= RULE_ID ) )
                    {
                    otherlv_8=(Token)match(input,29,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_8, grammarAccess.getSmartContractAccess().getIsKeyword_8_0());
                      			
                    }
                    // InternalSM2.g:183:4: ( (lv_nameContractFather_9_0= RULE_ID ) )
                    // InternalSM2.g:184:5: (lv_nameContractFather_9_0= RULE_ID )
                    {
                    // InternalSM2.g:184:5: (lv_nameContractFather_9_0= RULE_ID )
                    // InternalSM2.g:185:6: lv_nameContractFather_9_0= RULE_ID
                    {
                    lv_nameContractFather_9_0=(Token)match(input,RULE_ID,FOLLOW_10); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_nameContractFather_9_0, grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_8_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getSmartContractRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"nameContractFather",
                      							lv_nameContractFather_9_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_OPENKEY_10=(Token)match(input,RULE_OPENKEY,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_10, grammarAccess.getSmartContractAccess().getOPENKEYTerminalRuleCall_9());
              		
            }
            // InternalSM2.g:206:3: (this_EOLINE_11= RULE_EOLINE )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==RULE_EOLINE) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalSM2.g:207:4: this_EOLINE_11= RULE_EOLINE
                    {
                    this_EOLINE_11=(Token)match(input,RULE_EOLINE,FOLLOW_12); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_11, grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_10());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:212:3: ( (lv_attributes_12_0= ruleAttributes ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==RULE_ID||LA5_0==40||(LA5_0>=42 && LA5_0<=43)||(LA5_0>=45 && LA5_0<=47)||(LA5_0>=53 && LA5_0<=58)) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalSM2.g:213:4: (lv_attributes_12_0= ruleAttributes )
            	    {
            	    // InternalSM2.g:213:4: (lv_attributes_12_0= ruleAttributes )
            	    // InternalSM2.g:214:5: lv_attributes_12_0= ruleAttributes
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_11_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_12);
            	    lv_attributes_12_0=ruleAttributes();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"attributes",
            	      						lv_attributes_12_0,
            	      						"org.xtext.SM2.Attributes");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            // InternalSM2.g:231:3: ( (lv_events_13_0= ruleEvent ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==37) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalSM2.g:232:4: (lv_events_13_0= ruleEvent )
            	    {
            	    // InternalSM2.g:232:4: (lv_events_13_0= ruleEvent )
            	    // InternalSM2.g:233:5: lv_events_13_0= ruleEvent
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getEventsEventParserRuleCall_12_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_13);
            	    lv_events_13_0=ruleEvent();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"events",
            	      						lv_events_13_0,
            	      						"org.xtext.SM2.Event");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            // InternalSM2.g:250:3: ( (lv_modifier_14_0= ruleModifier ) )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==38) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalSM2.g:251:4: (lv_modifier_14_0= ruleModifier )
            	    {
            	    // InternalSM2.g:251:4: (lv_modifier_14_0= ruleModifier )
            	    // InternalSM2.g:252:5: lv_modifier_14_0= ruleModifier
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_13_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_14);
            	    lv_modifier_14_0=ruleModifier();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"modifier",
            	      						lv_modifier_14_0,
            	      						"org.xtext.SM2.Modifier");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            // InternalSM2.g:269:3: ( (lv_clauses_15_0= ruleClause ) )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==49) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalSM2.g:270:4: (lv_clauses_15_0= ruleClause )
            	    {
            	    // InternalSM2.g:270:4: (lv_clauses_15_0= ruleClause )
            	    // InternalSM2.g:271:5: lv_clauses_15_0= ruleClause
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_14_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_15);
            	    lv_clauses_15_0=ruleClause();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"clauses",
            	      						lv_clauses_15_0,
            	      						"org.xtext.SM2.Clause");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            // InternalSM2.g:288:3: ( (lv_comments_16_0= ruleComment ) )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( ((LA9_0>=50 && LA9_0<=51)) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalSM2.g:289:4: (lv_comments_16_0= ruleComment )
            	    {
            	    // InternalSM2.g:289:4: (lv_comments_16_0= ruleComment )
            	    // InternalSM2.g:290:5: lv_comments_16_0= ruleComment
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_15_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_16);
            	    lv_comments_16_0=ruleComment();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"comments",
            	      						lv_comments_16_0,
            	      						"org.xtext.SM2.Comment");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

            this_CLOSEKEY_17=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_17, grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_16());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSmartContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:315:1: entryRuleVersion returns [EObject current=null] : iv_ruleVersion= ruleVersion EOF ;
    public final EObject entryRuleVersion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVersion = null;


        try {
            // InternalSM2.g:315:48: (iv_ruleVersion= ruleVersion EOF )
            // InternalSM2.g:316:2: iv_ruleVersion= ruleVersion EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getVersionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleVersion=ruleVersion();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleVersion; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:322:1: ruleVersion returns [EObject current=null] : ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? ) ) ;
    public final EObject ruleVersion() throws RecognitionException {
        EObject current = null;

        Token lv_symbol_0_0=null;
        Token lv_numberVersion_1_0=null;
        Token this_DOT_2=null;
        Token lv_numberVersion2_3_0=null;
        Token this_DOT_4=null;
        Token lv_numberVersion3_5_0=null;
        Token lv_symbol_6_1=null;
        Token lv_symbol_6_2=null;
        Token lv_numberVersion_7_0=null;
        Token this_DOT_8=null;
        Token lv_numberVersion2_9_0=null;
        Token this_DOT_10=null;
        Token lv_numberVersion3_11_0=null;
        Token lv_symbol2_12_1=null;
        Token lv_symbol2_12_2=null;
        Token lv_numberVersionOptional_13_0=null;
        Token this_DOT_14=null;
        Token lv_numberVersionOptional2_15_0=null;
        Token this_DOT_16=null;
        Token lv_numberVersionOptional3_17_0=null;


        	enterRule();

        try {
            // InternalSM2.g:328:2: ( ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? ) ) )
            // InternalSM2.g:329:2: ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? ) )
            {
            // InternalSM2.g:329:2: ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? ) )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==30) ) {
                alt13=1;
            }
            else if ( ((LA13_0>=31 && LA13_0<=32)) ) {
                alt13=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // InternalSM2.g:330:3: ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) )
                    {
                    // InternalSM2.g:330:3: ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) )
                    // InternalSM2.g:331:4: ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) )
                    {
                    // InternalSM2.g:331:4: ( (lv_symbol_0_0= '^' ) )
                    // InternalSM2.g:332:5: (lv_symbol_0_0= '^' )
                    {
                    // InternalSM2.g:332:5: (lv_symbol_0_0= '^' )
                    // InternalSM2.g:333:6: lv_symbol_0_0= '^'
                    {
                    lv_symbol_0_0=(Token)match(input,30,FOLLOW_17); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_symbol_0_0, grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(current, "symbol", lv_symbol_0_0, "^");
                      					
                    }

                    }


                    }

                    // InternalSM2.g:345:4: ( (lv_numberVersion_1_0= RULE_NUMBER ) )
                    // InternalSM2.g:346:5: (lv_numberVersion_1_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:346:5: (lv_numberVersion_1_0= RULE_NUMBER )
                    // InternalSM2.g:347:6: lv_numberVersion_1_0= RULE_NUMBER
                    {
                    lv_numberVersion_1_0=(Token)match(input,RULE_NUMBER,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion_1_0, grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_0_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion",
                      							lv_numberVersion_1_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_2=(Token)match(input,RULE_DOT,FOLLOW_17); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_2, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_2());
                      			
                    }
                    // InternalSM2.g:367:4: ( (lv_numberVersion2_3_0= RULE_NUMBER ) )
                    // InternalSM2.g:368:5: (lv_numberVersion2_3_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:368:5: (lv_numberVersion2_3_0= RULE_NUMBER )
                    // InternalSM2.g:369:6: lv_numberVersion2_3_0= RULE_NUMBER
                    {
                    lv_numberVersion2_3_0=(Token)match(input,RULE_NUMBER,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion2_3_0, grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_0_3_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion2",
                      							lv_numberVersion2_3_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_4=(Token)match(input,RULE_DOT,FOLLOW_17); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_4, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_4());
                      			
                    }
                    // InternalSM2.g:389:4: ( (lv_numberVersion3_5_0= RULE_NUMBER ) )
                    // InternalSM2.g:390:5: (lv_numberVersion3_5_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:390:5: (lv_numberVersion3_5_0= RULE_NUMBER )
                    // InternalSM2.g:391:6: lv_numberVersion3_5_0= RULE_NUMBER
                    {
                    lv_numberVersion3_5_0=(Token)match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion3_5_0, grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_0_5_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion3",
                      							lv_numberVersion3_5_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:409:3: ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? )
                    {
                    // InternalSM2.g:409:3: ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? )
                    // InternalSM2.g:410:4: ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )?
                    {
                    // InternalSM2.g:410:4: ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) )
                    // InternalSM2.g:411:5: ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) )
                    {
                    // InternalSM2.g:411:5: ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) )
                    // InternalSM2.g:412:6: (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' )
                    {
                    // InternalSM2.g:412:6: (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' )
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==31) ) {
                        alt10=1;
                    }
                    else if ( (LA10_0==32) ) {
                        alt10=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 10, 0, input);

                        throw nvae;
                    }
                    switch (alt10) {
                        case 1 :
                            // InternalSM2.g:413:7: lv_symbol_6_1= '>'
                            {
                            lv_symbol_6_1=(Token)match(input,31,FOLLOW_17); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_symbol_6_1, grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_1_0_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(current, "symbol", lv_symbol_6_1, null);
                              						
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:424:7: lv_symbol_6_2= '>='
                            {
                            lv_symbol_6_2=(Token)match(input,32,FOLLOW_17); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_symbol_6_2, grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_1_0_0_1());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(current, "symbol", lv_symbol_6_2, null);
                              						
                            }

                            }
                            break;

                    }


                    }


                    }

                    // InternalSM2.g:437:4: ( (lv_numberVersion_7_0= RULE_NUMBER ) )
                    // InternalSM2.g:438:5: (lv_numberVersion_7_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:438:5: (lv_numberVersion_7_0= RULE_NUMBER )
                    // InternalSM2.g:439:6: lv_numberVersion_7_0= RULE_NUMBER
                    {
                    lv_numberVersion_7_0=(Token)match(input,RULE_NUMBER,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion_7_0, grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_1_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion",
                      							lv_numberVersion_7_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_8=(Token)match(input,RULE_DOT,FOLLOW_17); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_8, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_2());
                      			
                    }
                    // InternalSM2.g:459:4: ( (lv_numberVersion2_9_0= RULE_NUMBER ) )
                    // InternalSM2.g:460:5: (lv_numberVersion2_9_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:460:5: (lv_numberVersion2_9_0= RULE_NUMBER )
                    // InternalSM2.g:461:6: lv_numberVersion2_9_0= RULE_NUMBER
                    {
                    lv_numberVersion2_9_0=(Token)match(input,RULE_NUMBER,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion2_9_0, grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_1_3_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion2",
                      							lv_numberVersion2_9_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_10=(Token)match(input,RULE_DOT,FOLLOW_17); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_10, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_4());
                      			
                    }
                    // InternalSM2.g:481:4: ( (lv_numberVersion3_11_0= RULE_NUMBER ) )
                    // InternalSM2.g:482:5: (lv_numberVersion3_11_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:482:5: (lv_numberVersion3_11_0= RULE_NUMBER )
                    // InternalSM2.g:483:6: lv_numberVersion3_11_0= RULE_NUMBER
                    {
                    lv_numberVersion3_11_0=(Token)match(input,RULE_NUMBER,FOLLOW_19); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion3_11_0, grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_1_5_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion3",
                      							lv_numberVersion3_11_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }

                    // InternalSM2.g:499:4: ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( ((LA12_0>=33 && LA12_0<=34)) ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // InternalSM2.g:500:5: ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) )
                            {
                            // InternalSM2.g:500:5: ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) )
                            // InternalSM2.g:501:6: ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) )
                            {
                            // InternalSM2.g:501:6: ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) )
                            // InternalSM2.g:502:7: (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' )
                            {
                            // InternalSM2.g:502:7: (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' )
                            int alt11=2;
                            int LA11_0 = input.LA(1);

                            if ( (LA11_0==33) ) {
                                alt11=1;
                            }
                            else if ( (LA11_0==34) ) {
                                alt11=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 11, 0, input);

                                throw nvae;
                            }
                            switch (alt11) {
                                case 1 :
                                    // InternalSM2.g:503:8: lv_symbol2_12_1= '<'
                                    {
                                    lv_symbol2_12_1=(Token)match(input,33,FOLLOW_17); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      								newLeafNode(lv_symbol2_12_1, grammarAccess.getVersionAccess().getSymbol2LessThanSignKeyword_1_6_0_0_0());
                                      							
                                    }
                                    if ( state.backtracking==0 ) {

                                      								if (current==null) {
                                      									current = createModelElement(grammarAccess.getVersionRule());
                                      								}
                                      								setWithLastConsumed(current, "symbol2", lv_symbol2_12_1, null);
                                      							
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:514:8: lv_symbol2_12_2= '<='
                                    {
                                    lv_symbol2_12_2=(Token)match(input,34,FOLLOW_17); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      								newLeafNode(lv_symbol2_12_2, grammarAccess.getVersionAccess().getSymbol2LessThanSignEqualsSignKeyword_1_6_0_0_1());
                                      							
                                    }
                                    if ( state.backtracking==0 ) {

                                      								if (current==null) {
                                      									current = createModelElement(grammarAccess.getVersionRule());
                                      								}
                                      								setWithLastConsumed(current, "symbol2", lv_symbol2_12_2, null);
                                      							
                                    }

                                    }
                                    break;

                            }


                            }


                            }

                            // InternalSM2.g:527:5: ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) )
                            // InternalSM2.g:528:6: (lv_numberVersionOptional_13_0= RULE_NUMBER )
                            {
                            // InternalSM2.g:528:6: (lv_numberVersionOptional_13_0= RULE_NUMBER )
                            // InternalSM2.g:529:7: lv_numberVersionOptional_13_0= RULE_NUMBER
                            {
                            lv_numberVersionOptional_13_0=(Token)match(input,RULE_NUMBER,FOLLOW_18); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_numberVersionOptional_13_0, grammarAccess.getVersionAccess().getNumberVersionOptionalNUMBERTerminalRuleCall_1_6_1_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"numberVersionOptional",
                              								lv_numberVersionOptional_13_0,
                              								"org.xtext.SM2.NUMBER");
                              						
                            }

                            }


                            }

                            this_DOT_14=(Token)match(input,RULE_DOT,FOLLOW_17); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_DOT_14, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_2());
                              				
                            }
                            // InternalSM2.g:549:5: ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) )
                            // InternalSM2.g:550:6: (lv_numberVersionOptional2_15_0= RULE_NUMBER )
                            {
                            // InternalSM2.g:550:6: (lv_numberVersionOptional2_15_0= RULE_NUMBER )
                            // InternalSM2.g:551:7: lv_numberVersionOptional2_15_0= RULE_NUMBER
                            {
                            lv_numberVersionOptional2_15_0=(Token)match(input,RULE_NUMBER,FOLLOW_18); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_numberVersionOptional2_15_0, grammarAccess.getVersionAccess().getNumberVersionOptional2NUMBERTerminalRuleCall_1_6_3_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"numberVersionOptional2",
                              								lv_numberVersionOptional2_15_0,
                              								"org.xtext.SM2.NUMBER");
                              						
                            }

                            }


                            }

                            this_DOT_16=(Token)match(input,RULE_DOT,FOLLOW_17); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_DOT_16, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_4());
                              				
                            }
                            // InternalSM2.g:571:5: ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) )
                            // InternalSM2.g:572:6: (lv_numberVersionOptional3_17_0= RULE_NUMBER )
                            {
                            // InternalSM2.g:572:6: (lv_numberVersionOptional3_17_0= RULE_NUMBER )
                            // InternalSM2.g:573:7: lv_numberVersionOptional3_17_0= RULE_NUMBER
                            {
                            lv_numberVersionOptional3_17_0=(Token)match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_numberVersionOptional3_17_0, grammarAccess.getVersionAccess().getNumberVersionOptional3NUMBERTerminalRuleCall_1_6_5_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"numberVersionOptional3",
                              								lv_numberVersionOptional3_17_0,
                              								"org.xtext.SM2.NUMBER");
                              						
                            }

                            }


                            }


                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleImport"
    // InternalSM2.g:595:1: entryRuleImport returns [EObject current=null] : iv_ruleImport= ruleImport EOF ;
    public final EObject entryRuleImport() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleImport = null;


        try {
            // InternalSM2.g:595:47: (iv_ruleImport= ruleImport EOF )
            // InternalSM2.g:596:2: iv_ruleImport= ruleImport EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getImportRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleImport=ruleImport();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleImport; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2.g:602:1: ruleImport returns [EObject current=null] : (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) ;
    public final EObject ruleImport() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameLibrary_1_0=null;
        Token otherlv_2=null;
        Token lv_alias_3_0=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;


        	enterRule();

        try {
            // InternalSM2.g:608:2: ( (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:609:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:609:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:610:3: otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,35,FOLLOW_8); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getImportAccess().getImportKeyword_0());
              		
            }
            // InternalSM2.g:614:3: ( (lv_nameLibrary_1_0= RULE_ID ) )
            // InternalSM2.g:615:4: (lv_nameLibrary_1_0= RULE_ID )
            {
            // InternalSM2.g:615:4: (lv_nameLibrary_1_0= RULE_ID )
            // InternalSM2.g:616:5: lv_nameLibrary_1_0= RULE_ID
            {
            lv_nameLibrary_1_0=(Token)match(input,RULE_ID,FOLLOW_20); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameLibrary_1_0, grammarAccess.getImportAccess().getNameLibraryIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getImportRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameLibrary",
              						lv_nameLibrary_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:632:3: (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==36) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalSM2.g:633:4: otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,36,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getImportAccess().getAsKeyword_2_0());
                      			
                    }
                    // InternalSM2.g:637:4: ( (lv_alias_3_0= RULE_ID ) )
                    // InternalSM2.g:638:5: (lv_alias_3_0= RULE_ID )
                    {
                    // InternalSM2.g:638:5: (lv_alias_3_0= RULE_ID )
                    // InternalSM2.g:639:6: lv_alias_3_0= RULE_ID
                    {
                    lv_alias_3_0=(Token)match(input,RULE_ID,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_alias_3_0, grammarAccess.getImportAccess().getAliasIDTerminalRuleCall_2_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getImportRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"alias",
                      							lv_alias_3_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_21); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_4, grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:660:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==RULE_EOLINE) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalSM2.g:661:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_5, grammarAccess.getImportAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:670:1: entryRuleAttributes returns [EObject current=null] : iv_ruleAttributes= ruleAttributes EOF ;
    public final EObject entryRuleAttributes() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttributes = null;


        try {
            // InternalSM2.g:670:51: (iv_ruleAttributes= ruleAttributes EOF )
            // InternalSM2.g:671:2: iv_ruleAttributes= ruleAttributes EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getAttributesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleAttributes=ruleAttributes();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleAttributes; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:677:1: ruleAttributes returns [EObject current=null] : (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) ;
    public final EObject ruleAttributes() throws RecognitionException {
        EObject current = null;

        EObject this_Property_0 = null;

        EObject this_DataType_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:683:2: ( (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) )
            // InternalSM2.g:684:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            {
            // InternalSM2.g:684:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==43||(LA16_0>=45 && LA16_0<=46)||(LA16_0>=53 && LA16_0<=58)) ) {
                alt16=1;
            }
            else if ( (LA16_0==RULE_ID||LA16_0==40||LA16_0==42||LA16_0==47) ) {
                alt16=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }
            switch (alt16) {
                case 1 :
                    // InternalSM2.g:685:3: this_Property_0= ruleProperty
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Property_0=ruleProperty();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Property_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:694:3: this_DataType_1= ruleDataType
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_DataType_1=ruleDataType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_DataType_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleEvent"
    // InternalSM2.g:706:1: entryRuleEvent returns [EObject current=null] : iv_ruleEvent= ruleEvent EOF ;
    public final EObject entryRuleEvent() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvent = null;


        try {
            // InternalSM2.g:706:46: (iv_ruleEvent= ruleEvent EOF )
            // InternalSM2.g:707:2: iv_ruleEvent= ruleEvent EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getEventRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleEvent=ruleEvent();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleEvent; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalSM2.g:713:1: ruleEvent returns [EObject current=null] : (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject ruleEvent() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEvent_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;
        EObject lv_inputParams_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:719:2: ( (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:720:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:720:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:721:3: otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,37,FOLLOW_8); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getEventAccess().getEventKeyword_0());
              		
            }
            // InternalSM2.g:725:3: ( (lv_nameEvent_1_0= RULE_ID ) )
            // InternalSM2.g:726:4: (lv_nameEvent_1_0= RULE_ID )
            {
            // InternalSM2.g:726:4: (lv_nameEvent_1_0= RULE_ID )
            // InternalSM2.g:727:5: lv_nameEvent_1_0= RULE_ID
            {
            lv_nameEvent_1_0=(Token)match(input,RULE_ID,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameEvent_1_0, grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEventRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameEvent",
              						lv_nameEvent_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:747:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( (LA17_0==43||(LA17_0>=45 && LA17_0<=46)||(LA17_0>=53 && LA17_0<=58)) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalSM2.g:748:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:748:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:749:5: lv_inputParams_3_0= ruleInputParam
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_23);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getEventRule());
            	      					}
            	      					add(
            	      						current,
            	      						"inputParams",
            	      						lv_inputParams_3_0,
            	      						"org.xtext.SM2.InputParam");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_21); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_5, grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:774:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==RULE_EOLINE) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalSM2.g:775:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:784:1: entryRuleModifier returns [EObject current=null] : iv_ruleModifier= ruleModifier EOF ;
    public final EObject entryRuleModifier() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModifier = null;


        try {
            // InternalSM2.g:784:49: (iv_ruleModifier= ruleModifier EOF )
            // InternalSM2.g:785:2: iv_ruleModifier= ruleModifier EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getModifierRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleModifier=ruleModifier();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleModifier; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:791:1: ruleModifier returns [EObject current=null] : (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? ) ;
    public final EObject ruleModifier() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameModifier_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_EOLINE_6=null;
        Token lv_expr_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Token otherlv_10=null;
        Token this_CLOSEKEY_11=null;
        Token this_EOLINE_12=null;
        EObject lv_inputParams_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:797:2: ( (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? ) )
            // InternalSM2.g:798:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? )
            {
            // InternalSM2.g:798:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? )
            // InternalSM2.g:799:3: otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,38,FOLLOW_8); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getModifierAccess().getModifierKeyword_0());
              		
            }
            // InternalSM2.g:803:3: ( (lv_nameModifier_1_0= RULE_ID ) )
            // InternalSM2.g:804:4: (lv_nameModifier_1_0= RULE_ID )
            {
            // InternalSM2.g:804:4: (lv_nameModifier_1_0= RULE_ID )
            // InternalSM2.g:805:5: lv_nameModifier_1_0= RULE_ID
            {
            lv_nameModifier_1_0=(Token)match(input,RULE_ID,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameModifier_1_0, grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getModifierRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameModifier",
              						lv_nameModifier_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:825:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==43||(LA19_0>=45 && LA19_0<=46)||(LA19_0>=53 && LA19_0<=58)) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalSM2.g:826:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:826:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:827:5: lv_inputParams_3_0= ruleInputParam
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_23);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getModifierRule());
            	      					}
            	      					add(
            	      						current,
            	      						"inputParams",
            	      						lv_inputParams_3_0,
            	      						"org.xtext.SM2.InputParam");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:852:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==RULE_EOLINE) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalSM2.g:853:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:858:3: ( (lv_expr_7_0= RULE_STRING ) )
            // InternalSM2.g:859:4: (lv_expr_7_0= RULE_STRING )
            {
            // InternalSM2.g:859:4: (lv_expr_7_0= RULE_STRING )
            // InternalSM2.g:860:5: lv_expr_7_0= RULE_STRING
            {
            lv_expr_7_0=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr_7_0, grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getModifierRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr",
              						lv_expr_7_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8());
              		
            }
            // InternalSM2.g:880:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==RULE_EOLINE) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalSM2.g:881:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_27); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9());
                      			
                    }

                    }
                    break;

            }

            otherlv_10=(Token)match(input,39,FOLLOW_28); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_10, grammarAccess.getModifierAccess().get_Keyword_10());
              		
            }
            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_21); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_11, grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11());
              		
            }
            // InternalSM2.g:894:3: (this_EOLINE_12= RULE_EOLINE )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==RULE_EOLINE) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalSM2.g:895:4: this_EOLINE_12= RULE_EOLINE
                    {
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_12, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:904:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalSM2.g:904:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalSM2.g:905:2: iv_ruleDataType= ruleDataType EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getDataTypeRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleDataType; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:911:1: ruleDataType returns [EObject current=null] : (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        Token this_ID_2=null;
        EObject this_CompositeType_0 = null;

        EObject this_Enum_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:917:2: ( (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID ) )
            // InternalSM2.g:918:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID )
            {
            // InternalSM2.g:918:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID )
            int alt23=3;
            switch ( input.LA(1) ) {
            case 40:
            case 42:
                {
                alt23=1;
                }
                break;
            case 47:
                {
                alt23=2;
                }
                break;
            case RULE_ID:
                {
                alt23=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }

            switch (alt23) {
                case 1 :
                    // InternalSM2.g:919:3: this_CompositeType_0= ruleCompositeType
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_CompositeType_0=ruleCompositeType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_CompositeType_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:928:3: this_Enum_1= ruleEnum
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Enum_1=ruleEnum();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Enum_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:937:3: this_ID_2= RULE_ID
                    {
                    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(this_ID_2, grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2());
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2.g:945:1: entryRuleCompositeType returns [EObject current=null] : iv_ruleCompositeType= ruleCompositeType EOF ;
    public final EObject entryRuleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompositeType = null;


        try {
            // InternalSM2.g:945:54: (iv_ruleCompositeType= ruleCompositeType EOF )
            // InternalSM2.g:946:2: iv_ruleCompositeType= ruleCompositeType EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCompositeTypeRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleCompositeType=ruleCompositeType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleCompositeType; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2.g:952:1: ruleCompositeType returns [EObject current=null] : (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) ;
    public final EObject ruleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject this_Mapping_0 = null;

        EObject this_Struct_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:958:2: ( (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) )
            // InternalSM2.g:959:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            {
            // InternalSM2.g:959:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==40) ) {
                alt24=1;
            }
            else if ( (LA24_0==42) ) {
                alt24=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }
            switch (alt24) {
                case 1 :
                    // InternalSM2.g:960:3: this_Mapping_0= ruleMapping
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Mapping_0=ruleMapping();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Mapping_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:969:3: this_Struct_1= ruleStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Struct_1=ruleStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Struct_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:981:1: entryRuleMapping returns [EObject current=null] : iv_ruleMapping= ruleMapping EOF ;
    public final EObject entryRuleMapping() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMapping = null;


        try {
            // InternalSM2.g:981:48: (iv_ruleMapping= ruleMapping EOF )
            // InternalSM2.g:982:2: iv_ruleMapping= ruleMapping EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMappingRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleMapping=ruleMapping();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleMapping; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:988:1: ruleMapping returns [EObject current=null] : (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON ) ;
    public final EObject ruleMapping() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_3=null;
        Token lv_expr_4_0=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token lv_nameMapping_7_0=null;
        Token this_SEMICOLON_8=null;
        Enumerator lv_type_2_0 = null;

        Enumerator lv_visibility_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:994:2: ( (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON ) )
            // InternalSM2.g:995:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON )
            {
            // InternalSM2.g:995:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON )
            // InternalSM2.g:996:3: otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON
            {
            otherlv_0=(Token)match(input,40,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getMappingAccess().getMappingKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_29); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1004:3: ( (lv_type_2_0= ruleSingularType ) )
            // InternalSM2.g:1005:4: (lv_type_2_0= ruleSingularType )
            {
            // InternalSM2.g:1005:4: (lv_type_2_0= ruleSingularType )
            // InternalSM2.g:1006:5: lv_type_2_0= ruleSingularType
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_30);
            lv_type_2_0=ruleSingularType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getMappingRule());
              					}
              					set(
              						current,
              						"type",
              						lv_type_2_0,
              						"org.xtext.SM2.SingularType");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,41,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3());
              		
            }
            // InternalSM2.g:1027:3: ( (lv_expr_4_0= RULE_STRING ) )
            // InternalSM2.g:1028:4: (lv_expr_4_0= RULE_STRING )
            {
            // InternalSM2.g:1028:4: (lv_expr_4_0= RULE_STRING )
            // InternalSM2.g:1029:5: lv_expr_4_0= RULE_STRING
            {
            lv_expr_4_0=(Token)match(input,RULE_STRING,FOLLOW_31); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr_4_0, grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getMappingRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr",
              						lv_expr_4_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_32); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1049:3: ( (lv_visibility_6_0= ruleVisibility ) )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( ((LA25_0>=59 && LA25_0<=62)) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalSM2.g:1050:4: (lv_visibility_6_0= ruleVisibility )
                    {
                    // InternalSM2.g:1050:4: (lv_visibility_6_0= ruleVisibility )
                    // InternalSM2.g:1051:5: lv_visibility_6_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_8);
                    lv_visibility_6_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getMappingRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_6_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1068:3: ( (lv_nameMapping_7_0= RULE_ID ) )
            // InternalSM2.g:1069:4: (lv_nameMapping_7_0= RULE_ID )
            {
            // InternalSM2.g:1069:4: (lv_nameMapping_7_0= RULE_ID )
            // InternalSM2.g:1070:5: lv_nameMapping_7_0= RULE_ID
            {
            lv_nameMapping_7_0=(Token)match(input,RULE_ID,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameMapping_7_0, grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getMappingRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameMapping",
              						lv_nameMapping_7_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:1094:1: entryRuleStruct returns [EObject current=null] : iv_ruleStruct= ruleStruct EOF ;
    public final EObject entryRuleStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStruct = null;


        try {
            // InternalSM2.g:1094:47: (iv_ruleStruct= ruleStruct EOF )
            // InternalSM2.g:1095:2: iv_ruleStruct= ruleStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleStruct=ruleStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:1101:1: ruleStruct returns [EObject current=null] : ( ( (lv_typeStruct_0_0= rulePersonalizedStruct ) ) | this_User_1= ruleUser ) ;
    public final EObject ruleStruct() throws RecognitionException {
        EObject current = null;

        EObject lv_typeStruct_0_0 = null;

        EObject this_User_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1107:2: ( ( ( (lv_typeStruct_0_0= rulePersonalizedStruct ) ) | this_User_1= ruleUser ) )
            // InternalSM2.g:1108:2: ( ( (lv_typeStruct_0_0= rulePersonalizedStruct ) ) | this_User_1= ruleUser )
            {
            // InternalSM2.g:1108:2: ( ( (lv_typeStruct_0_0= rulePersonalizedStruct ) ) | this_User_1= ruleUser )
            int alt26=2;
            alt26 = dfa26.predict(input);
            switch (alt26) {
                case 1 :
                    // InternalSM2.g:1109:3: ( (lv_typeStruct_0_0= rulePersonalizedStruct ) )
                    {
                    // InternalSM2.g:1109:3: ( (lv_typeStruct_0_0= rulePersonalizedStruct ) )
                    // InternalSM2.g:1110:4: (lv_typeStruct_0_0= rulePersonalizedStruct )
                    {
                    // InternalSM2.g:1110:4: (lv_typeStruct_0_0= rulePersonalizedStruct )
                    // InternalSM2.g:1111:5: lv_typeStruct_0_0= rulePersonalizedStruct
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getStructAccess().getTypeStructPersonalizedStructParserRuleCall_0_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_typeStruct_0_0=rulePersonalizedStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getStructRule());
                      					}
                      					set(
                      						current,
                      						"typeStruct",
                      						lv_typeStruct_0_0,
                      						"org.xtext.SM2.PersonalizedStruct");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1129:3: this_User_1= ruleUser
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructAccess().getUserParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_User_1=ruleUser();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_User_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRulePersonalizedStruct"
    // InternalSM2.g:1141:1: entryRulePersonalizedStruct returns [EObject current=null] : iv_rulePersonalizedStruct= rulePersonalizedStruct EOF ;
    public final EObject entryRulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonalizedStruct = null;


        try {
            // InternalSM2.g:1141:59: (iv_rulePersonalizedStruct= rulePersonalizedStruct EOF )
            // InternalSM2.g:1142:2: iv_rulePersonalizedStruct= rulePersonalizedStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPersonalizedStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePersonalizedStruct=rulePersonalizedStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePersonalizedStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonalizedStruct"


    // $ANTLR start "rulePersonalizedStruct"
    // InternalSM2.g:1148:1: rulePersonalizedStruct returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject rulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_CLOSEKEY_5=null;
        Token this_EOLINE_6=null;
        EObject lv_properties_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1154:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1155:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1155:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1156:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,42,FOLLOW_8); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getPersonalizedStructAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:1160:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1161:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1161:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1162:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getPersonalizedStructAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPersonalizedStructRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_33); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1182:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==RULE_EOLINE) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalSM2.g:1183:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:1188:3: ( (lv_properties_4_0= ruleProperty ) )+
            int cnt28=0;
            loop28:
            do {
                int alt28=2;
                int LA28_0 = input.LA(1);

                if ( (LA28_0==43||(LA28_0>=45 && LA28_0<=46)||(LA28_0>=53 && LA28_0<=58)) ) {
                    alt28=1;
                }


                switch (alt28) {
            	case 1 :
            	    // InternalSM2.g:1189:4: (lv_properties_4_0= ruleProperty )
            	    {
            	    // InternalSM2.g:1189:4: (lv_properties_4_0= ruleProperty )
            	    // InternalSM2.g:1190:5: lv_properties_4_0= ruleProperty
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_34);
            	    lv_properties_4_0=ruleProperty();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getPersonalizedStructRule());
            	      					}
            	      					add(
            	      						current,
            	      						"properties",
            	      						lv_properties_4_0,
            	      						"org.xtext.SM2.Property");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt28 >= 1 ) break loop28;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(28, input);
                        throw eee;
                }
                cnt28++;
            } while (true);

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_21); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_5, grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1211:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==RULE_EOLINE) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalSM2.g:1212:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonalizedStruct"


    // $ANTLR start "entryRuleUser"
    // InternalSM2.g:1221:1: entryRuleUser returns [EObject current=null] : iv_ruleUser= ruleUser EOF ;
    public final EObject entryRuleUser() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUser = null;


        try {
            // InternalSM2.g:1221:45: (iv_ruleUser= ruleUser EOF )
            // InternalSM2.g:1222:2: iv_ruleUser= ruleUser EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getUserRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleUser=ruleUser();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleUser; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUser"


    // $ANTLR start "ruleUser"
    // InternalSM2.g:1228:1: ruleUser returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' ( (lv_amountAccount_29_0= RULE_STRING ) ) (otherlv_30= '=' this_NUMBER_31= RULE_NUMBER )? this_SEMICOLON_32= RULE_SEMICOLON (this_EOLINE_33= RULE_EOLINE )? this_CLOSEKEY_34= RULE_CLOSEKEY (this_EOLINE_35= RULE_EOLINE )? ) ;
    public final EObject ruleUser() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_0=null;
        Token otherlv_6=null;
        Token this_STRING_7=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Token otherlv_10=null;
        Token lv_nameUser_11_0=null;
        Token otherlv_12=null;
        Token this_STRING_13=null;
        Token this_SEMICOLON_14=null;
        Token this_EOLINE_15=null;
        Token otherlv_16=null;
        Token lv_surname_17_0=null;
        Token otherlv_18=null;
        Token this_STRING_19=null;
        Token this_SEMICOLON_20=null;
        Token this_EOLINE_21=null;
        Token otherlv_22=null;
        Token lv_email_23_0=null;
        Token otherlv_24=null;
        Token this_EMAIL_25=null;
        Token this_SEMICOLON_26=null;
        Token this_EOLINE_27=null;
        Token otherlv_28=null;
        Token lv_amountAccount_29_0=null;
        Token otherlv_30=null;
        Token this_NUMBER_31=null;
        Token this_SEMICOLON_32=null;
        Token this_EOLINE_33=null;
        Token this_CLOSEKEY_34=null;
        Token this_EOLINE_35=null;


        	enterRule();

        try {
            // InternalSM2.g:1234:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' ( (lv_amountAccount_29_0= RULE_STRING ) ) (otherlv_30= '=' this_NUMBER_31= RULE_NUMBER )? this_SEMICOLON_32= RULE_SEMICOLON (this_EOLINE_33= RULE_EOLINE )? this_CLOSEKEY_34= RULE_CLOSEKEY (this_EOLINE_35= RULE_EOLINE )? ) )
            // InternalSM2.g:1235:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' ( (lv_amountAccount_29_0= RULE_STRING ) ) (otherlv_30= '=' this_NUMBER_31= RULE_NUMBER )? this_SEMICOLON_32= RULE_SEMICOLON (this_EOLINE_33= RULE_EOLINE )? this_CLOSEKEY_34= RULE_CLOSEKEY (this_EOLINE_35= RULE_EOLINE )? )
            {
            // InternalSM2.g:1235:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' ( (lv_amountAccount_29_0= RULE_STRING ) ) (otherlv_30= '=' this_NUMBER_31= RULE_NUMBER )? this_SEMICOLON_32= RULE_SEMICOLON (this_EOLINE_33= RULE_EOLINE )? this_CLOSEKEY_34= RULE_CLOSEKEY (this_EOLINE_35= RULE_EOLINE )? )
            // InternalSM2.g:1236:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' ( (lv_amountAccount_29_0= RULE_STRING ) ) (otherlv_30= '=' this_NUMBER_31= RULE_NUMBER )? this_SEMICOLON_32= RULE_SEMICOLON (this_EOLINE_33= RULE_EOLINE )? this_CLOSEKEY_34= RULE_CLOSEKEY (this_EOLINE_35= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,42,FOLLOW_8); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getUserAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:1240:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1241:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1241:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1242:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_35); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1262:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==RULE_EOLINE) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalSM2.g:1263:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_36); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            otherlv_4=(Token)match(input,43,FOLLOW_8); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getUserAccess().getAddressKeyword_4());
              		
            }
            // InternalSM2.g:1272:3: ( (lv_idAdress_5_0= RULE_ID ) )
            // InternalSM2.g:1273:4: (lv_idAdress_5_0= RULE_ID )
            {
            // InternalSM2.g:1273:4: (lv_idAdress_5_0= RULE_ID )
            // InternalSM2.g:1274:5: lv_idAdress_5_0= RULE_ID
            {
            lv_idAdress_5_0=(Token)match(input,RULE_ID,FOLLOW_37); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_idAdress_5_0, grammarAccess.getUserAccess().getIdAdressIDTerminalRuleCall_5_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"idAdress",
              						lv_idAdress_5_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:1290:3: (otherlv_6= '=' this_STRING_7= RULE_STRING )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==44) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalSM2.g:1291:4: otherlv_6= '=' this_STRING_7= RULE_STRING
                    {
                    otherlv_6=(Token)match(input,44,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_6, grammarAccess.getUserAccess().getEqualsSignKeyword_6_0());
                      			
                    }
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_7, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_6_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_38); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            // InternalSM2.g:1304:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==RULE_EOLINE) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalSM2.g:1305:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_39); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_8());
                      			
                    }

                    }
                    break;

            }

            otherlv_10=(Token)match(input,45,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_10, grammarAccess.getUserAccess().getStringKeyword_9());
              		
            }
            // InternalSM2.g:1314:3: ( (lv_nameUser_11_0= RULE_STRING ) )
            // InternalSM2.g:1315:4: (lv_nameUser_11_0= RULE_STRING )
            {
            // InternalSM2.g:1315:4: (lv_nameUser_11_0= RULE_STRING )
            // InternalSM2.g:1316:5: lv_nameUser_11_0= RULE_STRING
            {
            lv_nameUser_11_0=(Token)match(input,RULE_STRING,FOLLOW_37); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameUser_11_0, grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_10_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameUser",
              						lv_nameUser_11_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1332:3: (otherlv_12= '=' this_STRING_13= RULE_STRING )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==44) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // InternalSM2.g:1333:4: otherlv_12= '=' this_STRING_13= RULE_STRING
                    {
                    otherlv_12=(Token)match(input,44,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_12, grammarAccess.getUserAccess().getEqualsSignKeyword_11_0());
                      			
                    }
                    this_STRING_13=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_13, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_11_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_14=(Token)match(input,RULE_SEMICOLON,FOLLOW_38); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_14, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_12());
              		
            }
            // InternalSM2.g:1346:3: (this_EOLINE_15= RULE_EOLINE )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==RULE_EOLINE) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalSM2.g:1347:4: this_EOLINE_15= RULE_EOLINE
                    {
                    this_EOLINE_15=(Token)match(input,RULE_EOLINE,FOLLOW_39); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_15, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_13());
                      			
                    }

                    }
                    break;

            }

            otherlv_16=(Token)match(input,45,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_16, grammarAccess.getUserAccess().getStringKeyword_14());
              		
            }
            // InternalSM2.g:1356:3: ( (lv_surname_17_0= RULE_STRING ) )
            // InternalSM2.g:1357:4: (lv_surname_17_0= RULE_STRING )
            {
            // InternalSM2.g:1357:4: (lv_surname_17_0= RULE_STRING )
            // InternalSM2.g:1358:5: lv_surname_17_0= RULE_STRING
            {
            lv_surname_17_0=(Token)match(input,RULE_STRING,FOLLOW_37); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_surname_17_0, grammarAccess.getUserAccess().getSurnameSTRINGTerminalRuleCall_15_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"surname",
              						lv_surname_17_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1374:3: (otherlv_18= '=' this_STRING_19= RULE_STRING )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==44) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalSM2.g:1375:4: otherlv_18= '=' this_STRING_19= RULE_STRING
                    {
                    otherlv_18=(Token)match(input,44,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_18, grammarAccess.getUserAccess().getEqualsSignKeyword_16_0());
                      			
                    }
                    this_STRING_19=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_19, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_16_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_20=(Token)match(input,RULE_SEMICOLON,FOLLOW_38); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_20, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_17());
              		
            }
            // InternalSM2.g:1388:3: (this_EOLINE_21= RULE_EOLINE )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==RULE_EOLINE) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalSM2.g:1389:4: this_EOLINE_21= RULE_EOLINE
                    {
                    this_EOLINE_21=(Token)match(input,RULE_EOLINE,FOLLOW_39); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_21, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_18());
                      			
                    }

                    }
                    break;

            }

            otherlv_22=(Token)match(input,45,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_22, grammarAccess.getUserAccess().getStringKeyword_19());
              		
            }
            // InternalSM2.g:1398:3: ( (lv_email_23_0= RULE_STRING ) )
            // InternalSM2.g:1399:4: (lv_email_23_0= RULE_STRING )
            {
            // InternalSM2.g:1399:4: (lv_email_23_0= RULE_STRING )
            // InternalSM2.g:1400:5: lv_email_23_0= RULE_STRING
            {
            lv_email_23_0=(Token)match(input,RULE_STRING,FOLLOW_37); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_email_23_0, grammarAccess.getUserAccess().getEmailSTRINGTerminalRuleCall_20_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"email",
              						lv_email_23_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1416:3: (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==44) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalSM2.g:1417:4: otherlv_24= '=' this_EMAIL_25= RULE_EMAIL
                    {
                    otherlv_24=(Token)match(input,44,FOLLOW_40); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_24, grammarAccess.getUserAccess().getEqualsSignKeyword_21_0());
                      			
                    }
                    this_EMAIL_25=(Token)match(input,RULE_EMAIL,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EMAIL_25, grammarAccess.getUserAccess().getEMAILTerminalRuleCall_21_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_26=(Token)match(input,RULE_SEMICOLON,FOLLOW_41); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_26, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_22());
              		
            }
            // InternalSM2.g:1430:3: (this_EOLINE_27= RULE_EOLINE )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==RULE_EOLINE) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:1431:4: this_EOLINE_27= RULE_EOLINE
                    {
                    this_EOLINE_27=(Token)match(input,RULE_EOLINE,FOLLOW_42); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_27, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_23());
                      			
                    }

                    }
                    break;

            }

            otherlv_28=(Token)match(input,46,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_28, grammarAccess.getUserAccess().getUintKeyword_24());
              		
            }
            // InternalSM2.g:1440:3: ( (lv_amountAccount_29_0= RULE_STRING ) )
            // InternalSM2.g:1441:4: (lv_amountAccount_29_0= RULE_STRING )
            {
            // InternalSM2.g:1441:4: (lv_amountAccount_29_0= RULE_STRING )
            // InternalSM2.g:1442:5: lv_amountAccount_29_0= RULE_STRING
            {
            lv_amountAccount_29_0=(Token)match(input,RULE_STRING,FOLLOW_37); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_amountAccount_29_0, grammarAccess.getUserAccess().getAmountAccountSTRINGTerminalRuleCall_25_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"amountAccount",
              						lv_amountAccount_29_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1458:3: (otherlv_30= '=' this_NUMBER_31= RULE_NUMBER )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==44) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalSM2.g:1459:4: otherlv_30= '=' this_NUMBER_31= RULE_NUMBER
                    {
                    otherlv_30=(Token)match(input,44,FOLLOW_17); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_30, grammarAccess.getUserAccess().getEqualsSignKeyword_26_0());
                      			
                    }
                    this_NUMBER_31=(Token)match(input,RULE_NUMBER,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_NUMBER_31, grammarAccess.getUserAccess().getNUMBERTerminalRuleCall_26_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_32=(Token)match(input,RULE_SEMICOLON,FOLLOW_43); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_32, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_27());
              		
            }
            // InternalSM2.g:1472:3: (this_EOLINE_33= RULE_EOLINE )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==RULE_EOLINE) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalSM2.g:1473:4: this_EOLINE_33= RULE_EOLINE
                    {
                    this_EOLINE_33=(Token)match(input,RULE_EOLINE,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_33, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_28());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_34=(Token)match(input,RULE_CLOSEKEY,FOLLOW_21); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_34, grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_29());
              		
            }
            // InternalSM2.g:1482:3: (this_EOLINE_35= RULE_EOLINE )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==RULE_EOLINE) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalSM2.g:1483:4: this_EOLINE_35= RULE_EOLINE
                    {
                    this_EOLINE_35=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_35, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_30());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUser"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:1492:1: entryRuleEnum returns [EObject current=null] : iv_ruleEnum= ruleEnum EOF ;
    public final EObject entryRuleEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnum = null;


        try {
            // InternalSM2.g:1492:45: (iv_ruleEnum= ruleEnum EOF )
            // InternalSM2.g:1493:2: iv_ruleEnum= ruleEnum EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getEnumRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleEnum=ruleEnum();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleEnum; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:1499:1: ruleEnum returns [EObject current=null] : (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEnum_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_STRING_3=null;
        Token this_COMMA_4=null;
        Token this_CLOSEKEY_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;


        	enterRule();

        try {
            // InternalSM2.g:1505:2: ( (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:1506:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:1506:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:1507:3: otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,47,FOLLOW_8); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getEnumAccess().getEnumKeyword_0());
              		
            }
            // InternalSM2.g:1511:3: ( (lv_nameEnum_1_0= RULE_ID ) )
            // InternalSM2.g:1512:4: (lv_nameEnum_1_0= RULE_ID )
            {
            // InternalSM2.g:1512:4: (lv_nameEnum_1_0= RULE_ID )
            // InternalSM2.g:1513:5: lv_nameEnum_1_0= RULE_ID
            {
            lv_nameEnum_1_0=(Token)match(input,RULE_ID,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameEnum_1_0, grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEnumRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameEnum",
              						lv_nameEnum_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1533:3: (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+
            int cnt43=0;
            loop43:
            do {
                int alt43=2;
                int LA43_0 = input.LA(1);

                if ( (LA43_0==RULE_STRING) ) {
                    alt43=1;
                }


                switch (alt43) {
            	case 1 :
            	    // InternalSM2.g:1534:4: this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )?
            	    {
            	    this_STRING_3=(Token)match(input,RULE_STRING,FOLLOW_44); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      				newLeafNode(this_STRING_3, grammarAccess.getEnumAccess().getSTRINGTerminalRuleCall_3_0());
            	      			
            	    }
            	    // InternalSM2.g:1538:4: (this_COMMA_4= RULE_COMMA )?
            	    int alt42=2;
            	    int LA42_0 = input.LA(1);

            	    if ( (LA42_0==RULE_COMMA) ) {
            	        alt42=1;
            	    }
            	    switch (alt42) {
            	        case 1 :
            	            // InternalSM2.g:1539:5: this_COMMA_4= RULE_COMMA
            	            {
            	            this_COMMA_4=(Token)match(input,RULE_COMMA,FOLLOW_45); if (state.failed) return current;
            	            if ( state.backtracking==0 ) {

            	              					newLeafNode(this_COMMA_4, grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_3_1());
            	              				
            	            }

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt43 >= 1 ) break loop43;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(43, input);
                        throw eee;
                }
                cnt43++;
            } while (true);

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_5, grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_4());
              		
            }
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_21); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1553:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==RULE_EOLINE) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:1554:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:1563:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // InternalSM2.g:1563:49: (iv_ruleProperty= ruleProperty EOF )
            // InternalSM2.g:1564:2: iv_ruleProperty= ruleProperty EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleProperty=ruleProperty();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleProperty; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:1570:1: ruleProperty returns [EObject current=null] : ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        Token lv_nameProperty_2_0=null;
        Token otherlv_3=null;
        Token lv_inicialization_4_0=null;
        Token this_INT_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        Enumerator lv_type_0_0 = null;

        Enumerator lv_visibility_1_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1576:2: ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:1577:2: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:1577:2: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:1578:3: ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:1578:3: ( (lv_type_0_0= ruleSingularType ) )
            // InternalSM2.g:1579:4: (lv_type_0_0= ruleSingularType )
            {
            // InternalSM2.g:1579:4: (lv_type_0_0= ruleSingularType )
            // InternalSM2.g:1580:5: lv_type_0_0= ruleSingularType
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_32);
            lv_type_0_0=ruleSingularType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getPropertyRule());
              					}
              					set(
              						current,
              						"type",
              						lv_type_0_0,
              						"org.xtext.SM2.SingularType");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:1597:3: ( (lv_visibility_1_0= ruleVisibility ) )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( ((LA45_0>=59 && LA45_0<=62)) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalSM2.g:1598:4: (lv_visibility_1_0= ruleVisibility )
                    {
                    // InternalSM2.g:1598:4: (lv_visibility_1_0= ruleVisibility )
                    // InternalSM2.g:1599:5: lv_visibility_1_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_8);
                    lv_visibility_1_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_1_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1616:3: ( (lv_nameProperty_2_0= RULE_ID ) )
            // InternalSM2.g:1617:4: (lv_nameProperty_2_0= RULE_ID )
            {
            // InternalSM2.g:1617:4: (lv_nameProperty_2_0= RULE_ID )
            // InternalSM2.g:1618:5: lv_nameProperty_2_0= RULE_ID
            {
            lv_nameProperty_2_0=(Token)match(input,RULE_ID,FOLLOW_46); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_2_0, grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_2_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            otherlv_3=(Token)match(input,44,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getPropertyAccess().getEqualsSignKeyword_3());
              		
            }
            // InternalSM2.g:1638:3: ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )?
            int alt46=3;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==RULE_STRING) ) {
                alt46=1;
            }
            else if ( (LA46_0==RULE_INT) ) {
                alt46=2;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:1639:4: ( (lv_inicialization_4_0= RULE_STRING ) )
                    {
                    // InternalSM2.g:1639:4: ( (lv_inicialization_4_0= RULE_STRING ) )
                    // InternalSM2.g:1640:5: (lv_inicialization_4_0= RULE_STRING )
                    {
                    // InternalSM2.g:1640:5: (lv_inicialization_4_0= RULE_STRING )
                    // InternalSM2.g:1641:6: lv_inicialization_4_0= RULE_STRING
                    {
                    lv_inicialization_4_0=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_inicialization_4_0, grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"inicialization",
                      							lv_inicialization_4_0,
                      							"org.eclipse.xtext.common.Terminals.STRING");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1658:4: this_INT_5= RULE_INT
                    {
                    this_INT_5=(Token)match(input,RULE_INT,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_INT_5, grammarAccess.getPropertyAccess().getINTTerminalRuleCall_4_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_21); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1667:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==RULE_EOLINE) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalSM2.g:1668:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:1677:1: entryRuleInputParam returns [EObject current=null] : iv_ruleInputParam= ruleInputParam EOF ;
    public final EObject entryRuleInputParam() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputParam = null;


        try {
            // InternalSM2.g:1677:51: (iv_ruleInputParam= ruleInputParam EOF )
            // InternalSM2.g:1678:2: iv_ruleInputParam= ruleInputParam EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getInputParamRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleInputParam=ruleInputParam();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleInputParam; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:1684:1: ruleInputParam returns [EObject current=null] : ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_nameParam_1_0= RULE_ID ) ) ) ( (lv_comma_2_0= RULE_COMMA ) )? ) ;
    public final EObject ruleInputParam() throws RecognitionException {
        EObject current = null;

        Token lv_nameParam_1_0=null;
        Token lv_comma_2_0=null;
        Enumerator lv_type_0_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1690:2: ( ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_nameParam_1_0= RULE_ID ) ) ) ( (lv_comma_2_0= RULE_COMMA ) )? ) )
            // InternalSM2.g:1691:2: ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_nameParam_1_0= RULE_ID ) ) ) ( (lv_comma_2_0= RULE_COMMA ) )? )
            {
            // InternalSM2.g:1691:2: ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_nameParam_1_0= RULE_ID ) ) ) ( (lv_comma_2_0= RULE_COMMA ) )? )
            // InternalSM2.g:1692:3: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_nameParam_1_0= RULE_ID ) ) ) ( (lv_comma_2_0= RULE_COMMA ) )?
            {
            // InternalSM2.g:1692:3: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_nameParam_1_0= RULE_ID ) ) )
            // InternalSM2.g:1693:4: ( (lv_type_0_0= ruleSingularType ) ) ( (lv_nameParam_1_0= RULE_ID ) )
            {
            // InternalSM2.g:1693:4: ( (lv_type_0_0= ruleSingularType ) )
            // InternalSM2.g:1694:5: (lv_type_0_0= ruleSingularType )
            {
            // InternalSM2.g:1694:5: (lv_type_0_0= ruleSingularType )
            // InternalSM2.g:1695:6: lv_type_0_0= ruleSingularType
            {
            if ( state.backtracking==0 ) {

              						newCompositeNode(grammarAccess.getInputParamAccess().getTypeSingularTypeEnumRuleCall_0_0_0());
              					
            }
            pushFollow(FOLLOW_8);
            lv_type_0_0=ruleSingularType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElementForParent(grammarAccess.getInputParamRule());
              						}
              						set(
              							current,
              							"type",
              							lv_type_0_0,
              							"org.xtext.SM2.SingularType");
              						afterParserOrEnumRuleCall();
              					
            }

            }


            }

            // InternalSM2.g:1712:4: ( (lv_nameParam_1_0= RULE_ID ) )
            // InternalSM2.g:1713:5: (lv_nameParam_1_0= RULE_ID )
            {
            // InternalSM2.g:1713:5: (lv_nameParam_1_0= RULE_ID )
            // InternalSM2.g:1714:6: lv_nameParam_1_0= RULE_ID
            {
            lv_nameParam_1_0=(Token)match(input,RULE_ID,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						newLeafNode(lv_nameParam_1_0, grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_1_0());
              					
            }
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElement(grammarAccess.getInputParamRule());
              						}
              						setWithLastConsumed(
              							current,
              							"nameParam",
              							lv_nameParam_1_0,
              							"org.eclipse.xtext.common.Terminals.ID");
              					
            }

            }


            }


            }

            // InternalSM2.g:1731:3: ( (lv_comma_2_0= RULE_COMMA ) )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==RULE_COMMA) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalSM2.g:1732:4: (lv_comma_2_0= RULE_COMMA )
                    {
                    // InternalSM2.g:1732:4: (lv_comma_2_0= RULE_COMMA )
                    // InternalSM2.g:1733:5: lv_comma_2_0= RULE_COMMA
                    {
                    lv_comma_2_0=(Token)match(input,RULE_COMMA,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_comma_2_0, grammarAccess.getInputParamAccess().getCommaCOMMATerminalRuleCall_1_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getInputParamRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"comma",
                      						lv_comma_2_0,
                      						"org.xtext.SM2.COMMA");
                      				
                    }

                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:1753:1: entryRuleRestriction returns [EObject current=null] : iv_ruleRestriction= ruleRestriction EOF ;
    public final EObject entryRuleRestriction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestriction = null;


        try {
            // InternalSM2.g:1753:52: (iv_ruleRestriction= ruleRestriction EOF )
            // InternalSM2.g:1754:2: iv_ruleRestriction= ruleRestriction EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRestrictionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRestriction=ruleRestriction();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRestriction; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:1760:1: ruleRestriction returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) ;
    public final EObject ruleRestriction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        EObject lv_expr1_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        EObject lv_expr2_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1766:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) )
            // InternalSM2.g:1767:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            {
            // InternalSM2.g:1767:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            // InternalSM2.g:1768:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,48,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getRestrictionAccess().getRequireKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1776:3: ( (lv_expr1_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:1777:4: (lv_expr1_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:1777:4: (lv_expr1_2_0= ruleSyntaxExpression )
            // InternalSM2.g:1778:5: lv_expr1_2_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr1SyntaxExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_50);
            lv_expr1_2_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"expr1",
              						lv_expr1_2_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:1795:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:1796:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:1796:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:1797:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_49);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:1814:3: ( (lv_expr2_4_0= ruleSyntaxExpression ) )
            // InternalSM2.g:1815:4: (lv_expr2_4_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:1815:4: (lv_expr2_4_0= ruleSyntaxExpression )
            // InternalSM2.g:1816:5: lv_expr2_4_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr2SyntaxExpressionParserRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_31);
            lv_expr2_4_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"expr2",
              						lv_expr2_4_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_7, grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:1849:1: entryRuleRestrictionGas returns [EObject current=null] : iv_ruleRestrictionGas= ruleRestrictionGas EOF ;
    public final EObject entryRuleRestrictionGas() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionGas = null;


        try {
            // InternalSM2.g:1849:55: (iv_ruleRestrictionGas= ruleRestrictionGas EOF )
            // InternalSM2.g:1850:2: iv_ruleRestrictionGas= ruleRestrictionGas EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRestrictionGasRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionGas=ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRestrictionGas; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:1856:1: ruleRestrictionGas returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_NUMBER ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) ;
    public final EObject ruleRestrictionGas() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_amount_4_0=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        EObject lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        Enumerator lv_typeCoin_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1862:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_NUMBER ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) )
            // InternalSM2.g:1863:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_NUMBER ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            {
            // InternalSM2.g:1863:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_NUMBER ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            // InternalSM2.g:1864:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_NUMBER ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,48,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getRestrictionGasAccess().getRequireKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1872:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:1873:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:1873:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2.g:1874:5: lv_expr_2_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_50);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_2_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:1891:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:1892:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:1892:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:1893:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_17);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:1910:3: ( (lv_amount_4_0= RULE_NUMBER ) )
            // InternalSM2.g:1911:4: (lv_amount_4_0= RULE_NUMBER )
            {
            // InternalSM2.g:1911:4: (lv_amount_4_0= RULE_NUMBER )
            // InternalSM2.g:1912:5: lv_amount_4_0= RULE_NUMBER
            {
            lv_amount_4_0=(Token)match(input,RULE_NUMBER,FOLLOW_52); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_amount_4_0, grammarAccess.getRestrictionGasAccess().getAmountNUMBERTerminalRuleCall_4_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getRestrictionGasRule());
              					}
              					setWithLastConsumed(
              						current,
              						"amount",
              						lv_amount_4_0,
              						"org.xtext.SM2.NUMBER");
              				
            }

            }


            }

            // InternalSM2.g:1928:3: ( (lv_typeCoin_5_0= ruleCoin ) )
            // InternalSM2.g:1929:4: (lv_typeCoin_5_0= ruleCoin )
            {
            // InternalSM2.g:1929:4: (lv_typeCoin_5_0= ruleCoin )
            // InternalSM2.g:1930:5: lv_typeCoin_5_0= ruleCoin
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0());
              				
            }
            pushFollow(FOLLOW_31);
            lv_typeCoin_5_0=ruleCoin();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"typeCoin",
              						lv_typeCoin_5_0,
              						"org.xtext.SM2.Coin");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }
            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_7, grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_8, grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2.g:1963:1: entryRuleClause returns [EObject current=null] : iv_ruleClause= ruleClause EOF ;
    public final EObject entryRuleClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClause = null;


        try {
            // InternalSM2.g:1963:47: (iv_ruleClause= ruleClause EOF )
            // InternalSM2.g:1964:2: iv_ruleClause= ruleClause EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getClauseRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleClause=ruleClause();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleClause; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2.g:1970:1: ruleClause returns [EObject current=null] : (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY this_EOLINE_8= RULE_EOLINE ( (lv_restriction_9_0= ruleRestriction ) )? ( (lv_restrictionGas_10_0= ruleRestrictionGas ) )? ( (lv_expression_11_0= ruleExpression ) )+ (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE ) ;
    public final EObject ruleClause() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameFunction_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token this_OPENKEY_7=null;
        Token this_EOLINE_8=null;
        Token this_EOLINE_12=null;
        Token this_CLOSEKEY_13=null;
        Token this_EOLINE_14=null;
        Enumerator lv_visibilityAccess_4_0 = null;

        EObject lv_restriction_9_0 = null;

        EObject lv_restrictionGas_10_0 = null;

        EObject lv_expression_11_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1976:2: ( (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY this_EOLINE_8= RULE_EOLINE ( (lv_restriction_9_0= ruleRestriction ) )? ( (lv_restrictionGas_10_0= ruleRestrictionGas ) )? ( (lv_expression_11_0= ruleExpression ) )+ (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE ) )
            // InternalSM2.g:1977:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY this_EOLINE_8= RULE_EOLINE ( (lv_restriction_9_0= ruleRestriction ) )? ( (lv_restrictionGas_10_0= ruleRestrictionGas ) )? ( (lv_expression_11_0= ruleExpression ) )+ (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE )
            {
            // InternalSM2.g:1977:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY this_EOLINE_8= RULE_EOLINE ( (lv_restriction_9_0= ruleRestriction ) )? ( (lv_restrictionGas_10_0= ruleRestrictionGas ) )? ( (lv_expression_11_0= ruleExpression ) )+ (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE )
            // InternalSM2.g:1978:3: otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY this_EOLINE_8= RULE_EOLINE ( (lv_restriction_9_0= ruleRestriction ) )? ( (lv_restrictionGas_10_0= ruleRestrictionGas ) )? ( (lv_expression_11_0= ruleExpression ) )+ (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,49,FOLLOW_8); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getClauseAccess().getFunctionKeyword_0());
              		
            }
            // InternalSM2.g:1982:3: ( (lv_nameFunction_1_0= RULE_ID ) )
            // InternalSM2.g:1983:4: (lv_nameFunction_1_0= RULE_ID )
            {
            // InternalSM2.g:1983:4: (lv_nameFunction_1_0= RULE_ID )
            // InternalSM2.g:1984:5: lv_nameFunction_1_0= RULE_ID
            {
            lv_nameFunction_1_0=(Token)match(input,RULE_ID,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameFunction_1_0, grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getClauseRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameFunction",
              						lv_nameFunction_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_32); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2004:3: ( (otherlv_3= RULE_ID ) )*
            loop49:
            do {
                int alt49=2;
                int LA49_0 = input.LA(1);

                if ( (LA49_0==RULE_ID) ) {
                    alt49=1;
                }


                switch (alt49) {
            	case 1 :
            	    // InternalSM2.g:2005:4: (otherlv_3= RULE_ID )
            	    {
            	    // InternalSM2.g:2005:4: (otherlv_3= RULE_ID )
            	    // InternalSM2.g:2006:5: otherlv_3= RULE_ID
            	    {
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElement(grammarAccess.getClauseRule());
            	      					}
            	      				
            	    }
            	    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_32); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_3, grammarAccess.getClauseAccess().getInputParamsInputParamCrossReference_3_0());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop49;
                }
            } while (true);

            // InternalSM2.g:2017:3: ( (lv_visibilityAccess_4_0= ruleVisibility ) )
            // InternalSM2.g:2018:4: (lv_visibilityAccess_4_0= ruleVisibility )
            {
            // InternalSM2.g:2018:4: (lv_visibilityAccess_4_0= ruleVisibility )
            // InternalSM2.g:2019:5: lv_visibilityAccess_4_0= ruleVisibility
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_53);
            lv_visibilityAccess_4_0=ruleVisibility();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getClauseRule());
              					}
              					set(
              						current,
              						"visibilityAccess",
              						lv_visibilityAccess_4_0,
              						"org.xtext.SM2.Visibility");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2036:3: ( (otherlv_5= RULE_ID ) )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==RULE_ID) ) {
                alt50=1;
            }
            switch (alt50) {
                case 1 :
                    // InternalSM2.g:2037:4: (otherlv_5= RULE_ID )
                    {
                    // InternalSM2.g:2037:4: (otherlv_5= RULE_ID )
                    // InternalSM2.g:2038:5: otherlv_5= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getClauseRule());
                      					}
                      				
                    }
                    otherlv_5=(Token)match(input,RULE_ID,FOLLOW_31); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_5, grammarAccess.getClauseAccess().getModifierModifierCrossReference_5_0());
                      				
                    }

                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }
            this_OPENKEY_7=(Token)match(input,RULE_OPENKEY,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_7, grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_7());
              		
            }
            this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_54); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_8, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_8());
              		
            }
            // InternalSM2.g:2061:3: ( (lv_restriction_9_0= ruleRestriction ) )?
            int alt51=2;
            alt51 = dfa51.predict(input);
            switch (alt51) {
                case 1 :
                    // InternalSM2.g:2062:4: (lv_restriction_9_0= ruleRestriction )
                    {
                    // InternalSM2.g:2062:4: (lv_restriction_9_0= ruleRestriction )
                    // InternalSM2.g:2063:5: lv_restriction_9_0= ruleRestriction
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_9_0());
                      				
                    }
                    pushFollow(FOLLOW_54);
                    lv_restriction_9_0=ruleRestriction();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getClauseRule());
                      					}
                      					add(
                      						current,
                      						"restriction",
                      						lv_restriction_9_0,
                      						"org.xtext.SM2.Restriction");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2080:3: ( (lv_restrictionGas_10_0= ruleRestrictionGas ) )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==48) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalSM2.g:2081:4: (lv_restrictionGas_10_0= ruleRestrictionGas )
                    {
                    // InternalSM2.g:2081:4: (lv_restrictionGas_10_0= ruleRestrictionGas )
                    // InternalSM2.g:2082:5: lv_restrictionGas_10_0= ruleRestrictionGas
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_10_0());
                      				
                    }
                    pushFollow(FOLLOW_54);
                    lv_restrictionGas_10_0=ruleRestrictionGas();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getClauseRule());
                      					}
                      					add(
                      						current,
                      						"restrictionGas",
                      						lv_restrictionGas_10_0,
                      						"org.xtext.SM2.RestrictionGas");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2099:3: ( (lv_expression_11_0= ruleExpression ) )+
            int cnt53=0;
            loop53:
            do {
                int alt53=2;
                int LA53_0 = input.LA(1);

                if ( (LA53_0==RULE_NUMBER||LA53_0==RULE_OPENPARENTHESIS||LA53_0==RULE_STRING) ) {
                    alt53=1;
                }


                switch (alt53) {
            	case 1 :
            	    // InternalSM2.g:2100:4: (lv_expression_11_0= ruleExpression )
            	    {
            	    // InternalSM2.g:2100:4: (lv_expression_11_0= ruleExpression )
            	    // InternalSM2.g:2101:5: lv_expression_11_0= ruleExpression
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_11_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_55);
            	    lv_expression_11_0=ruleExpression();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getClauseRule());
            	      					}
            	      					add(
            	      						current,
            	      						"expression",
            	      						lv_expression_11_0,
            	      						"org.xtext.SM2.Expression");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt53 >= 1 ) break loop53;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(53, input);
                        throw eee;
                }
                cnt53++;
            } while (true);

            // InternalSM2.g:2118:3: (this_EOLINE_12= RULE_EOLINE )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==RULE_EOLINE) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalSM2.g:2119:4: this_EOLINE_12= RULE_EOLINE
                    {
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_12, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_12());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_13=(Token)match(input,RULE_CLOSEKEY,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_13, grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_13());
              		
            }
            this_EOLINE_14=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_14, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_14());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:2136:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // InternalSM2.g:2136:51: (iv_ruleExpression= ruleExpression EOF )
            // InternalSM2.g:2137:2: iv_ruleExpression= ruleExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:2143:1: ruleExpression returns [EObject current=null] : (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_SyntaxExpression_1= ruleSyntaxExpression ) ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_ArithmethicalExpression_0 = null;

        EObject this_SyntaxExpression_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:2149:2: ( (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_SyntaxExpression_1= ruleSyntaxExpression ) )
            // InternalSM2.g:2150:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_SyntaxExpression_1= ruleSyntaxExpression )
            {
            // InternalSM2.g:2150:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_SyntaxExpression_1= ruleSyntaxExpression )
            int alt55=2;
            switch ( input.LA(1) ) {
            case RULE_OPENPARENTHESIS:
                {
                alt55=1;
                }
                break;
            case RULE_NUMBER:
                {
                int LA55_2 = input.LA(2);

                if ( ((LA55_2>=73 && LA55_2<=76)) ) {
                    alt55=1;
                }
                else if ( (LA55_2==EOF||(LA55_2>=RULE_SEMICOLON && LA55_2<=RULE_EOLINE)||(LA55_2>=RULE_CLOSEKEY && LA55_2<=RULE_NUMBER)||LA55_2==RULE_OPENPARENTHESIS||LA55_2==RULE_STRING) ) {
                    alt55=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 55, 2, input);

                    throw nvae;
                }
                }
                break;
            case RULE_STRING:
                {
                alt55=2;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 55, 0, input);

                throw nvae;
            }

            switch (alt55) {
                case 1 :
                    // InternalSM2.g:2151:3: this_ArithmethicalExpression_0= ruleArithmethicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalExpression_0=ruleArithmethicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ArithmethicalExpression_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2160:3: this_SyntaxExpression_1= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_SyntaxExpression_1=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_SyntaxExpression_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleArithmethicalExpression"
    // InternalSM2.g:2172:1: entryRuleArithmethicalExpression returns [EObject current=null] : iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF ;
    public final EObject entryRuleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalExpression = null;


        try {
            // InternalSM2.g:2172:64: (iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF )
            // InternalSM2.g:2173:2: iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmethicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalExpression=ruleArithmethicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArithmethicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalExpression"


    // $ANTLR start "ruleArithmethicalExpression"
    // InternalSM2.g:2179:1: ruleArithmethicalExpression returns [EObject current=null] : ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_NUMBER ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_NUMBER ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= RULE_NUMBER ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_NUMBER ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) ) ;
    public final EObject ruleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token lv_op1_1_0=null;
        Token lv_op2_3_0=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token lv_op1_5_0=null;
        Token lv_op2_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Enumerator lv_operator_2_0 = null;

        Enumerator lv_operator_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2185:2: ( ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_NUMBER ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_NUMBER ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= RULE_NUMBER ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_NUMBER ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) ) )
            // InternalSM2.g:2186:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_NUMBER ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_NUMBER ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= RULE_NUMBER ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_NUMBER ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:2186:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_NUMBER ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_NUMBER ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= RULE_NUMBER ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_NUMBER ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) )
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==RULE_OPENPARENTHESIS) ) {
                alt57=1;
            }
            else if ( (LA57_0==RULE_NUMBER) ) {
                alt57=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 57, 0, input);

                throw nvae;
            }
            switch (alt57) {
                case 1 :
                    // InternalSM2.g:2187:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_NUMBER ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_NUMBER ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:2187:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_NUMBER ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_NUMBER ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:2188:4: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_NUMBER ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_NUMBER ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                    {
                    this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_17); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0());
                      			
                    }
                    // InternalSM2.g:2192:4: ( (lv_op1_1_0= RULE_NUMBER ) )
                    // InternalSM2.g:2193:5: (lv_op1_1_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:2193:5: (lv_op1_1_0= RULE_NUMBER )
                    // InternalSM2.g:2194:6: lv_op1_1_0= RULE_NUMBER
                    {
                    lv_op1_1_0=(Token)match(input,RULE_NUMBER,FOLLOW_56); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op1_1_0, grammarAccess.getArithmethicalExpressionAccess().getOp1NUMBERTerminalRuleCall_0_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op1",
                      							lv_op1_1_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2210:4: ( (lv_operator_2_0= ruleArithmeticalOperator ) )
                    // InternalSM2.g:2211:5: (lv_operator_2_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2.g:2211:5: (lv_operator_2_0= ruleArithmeticalOperator )
                    // InternalSM2.g:2212:6: lv_operator_2_0= ruleArithmeticalOperator
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0());
                      					
                    }
                    pushFollow(FOLLOW_17);
                    lv_operator_2_0=ruleArithmeticalOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"operator",
                      							lv_operator_2_0,
                      							"org.xtext.SM2.ArithmeticalOperator");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2229:4: ( (lv_op2_3_0= RULE_NUMBER ) )
                    // InternalSM2.g:2230:5: (lv_op2_3_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:2230:5: (lv_op2_3_0= RULE_NUMBER )
                    // InternalSM2.g:2231:6: lv_op2_3_0= RULE_NUMBER
                    {
                    lv_op2_3_0=(Token)match(input,RULE_NUMBER,FOLLOW_31); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op2_3_0, grammarAccess.getArithmethicalExpressionAccess().getOp2NUMBERTerminalRuleCall_0_3_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op2",
                      							lv_op2_3_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }

                    this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2253:3: ( ( (lv_op1_5_0= RULE_NUMBER ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_NUMBER ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:2253:3: ( ( (lv_op1_5_0= RULE_NUMBER ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_NUMBER ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? )
                    // InternalSM2.g:2254:4: ( (lv_op1_5_0= RULE_NUMBER ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_NUMBER ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )?
                    {
                    // InternalSM2.g:2254:4: ( (lv_op1_5_0= RULE_NUMBER ) )
                    // InternalSM2.g:2255:5: (lv_op1_5_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:2255:5: (lv_op1_5_0= RULE_NUMBER )
                    // InternalSM2.g:2256:6: lv_op1_5_0= RULE_NUMBER
                    {
                    lv_op1_5_0=(Token)match(input,RULE_NUMBER,FOLLOW_56); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op1_5_0, grammarAccess.getArithmethicalExpressionAccess().getOp1NUMBERTerminalRuleCall_1_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op1",
                      							lv_op1_5_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2272:4: ( (lv_operator_6_0= ruleArithmeticalOperator ) )
                    // InternalSM2.g:2273:5: (lv_operator_6_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2.g:2273:5: (lv_operator_6_0= ruleArithmeticalOperator )
                    // InternalSM2.g:2274:6: lv_operator_6_0= ruleArithmeticalOperator
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_17);
                    lv_operator_6_0=ruleArithmeticalOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"operator",
                      							lv_operator_6_0,
                      							"org.xtext.SM2.ArithmeticalOperator");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2291:4: ( (lv_op2_7_0= RULE_NUMBER ) )
                    // InternalSM2.g:2292:5: (lv_op2_7_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:2292:5: (lv_op2_7_0= RULE_NUMBER )
                    // InternalSM2.g:2293:6: lv_op2_7_0= RULE_NUMBER
                    {
                    lv_op2_7_0=(Token)match(input,RULE_NUMBER,FOLLOW_57); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op2_7_0, grammarAccess.getArithmethicalExpressionAccess().getOp2NUMBERTerminalRuleCall_1_2_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op2",
                      							lv_op2_7_0,
                      							"org.xtext.SM2.NUMBER");
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2309:4: (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )?
                    int alt56=2;
                    int LA56_0 = input.LA(1);

                    if ( (LA56_0==RULE_SEMICOLON) ) {
                        alt56=1;
                    }
                    switch (alt56) {
                        case 1 :
                            // InternalSM2.g:2310:5: this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE
                            {
                            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_51); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_8, grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0());
                              				
                            }
                            this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_9, grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:2324:1: entryRuleSyntaxExpression returns [EObject current=null] : iv_ruleSyntaxExpression= ruleSyntaxExpression EOF ;
    public final EObject entryRuleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSyntaxExpression = null;


        try {
            // InternalSM2.g:2324:57: (iv_ruleSyntaxExpression= ruleSyntaxExpression EOF )
            // InternalSM2.g:2325:2: iv_ruleSyntaxExpression= ruleSyntaxExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSyntaxExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSyntaxExpression=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSyntaxExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:2331:1: ruleSyntaxExpression returns [EObject current=null] : ( ( (lv_text_0_0= RULE_STRING ) ) | (this_NUMBER_1= RULE_NUMBER (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) ) ;
    public final EObject ruleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        Token lv_text_0_0=null;
        Token this_NUMBER_1=null;
        Token this_SEMICOLON_2=null;
        Token this_EOLINE_3=null;


        	enterRule();

        try {
            // InternalSM2.g:2337:2: ( ( ( (lv_text_0_0= RULE_STRING ) ) | (this_NUMBER_1= RULE_NUMBER (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) ) )
            // InternalSM2.g:2338:2: ( ( (lv_text_0_0= RULE_STRING ) ) | (this_NUMBER_1= RULE_NUMBER (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:2338:2: ( ( (lv_text_0_0= RULE_STRING ) ) | (this_NUMBER_1= RULE_NUMBER (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) )
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==RULE_STRING) ) {
                alt59=1;
            }
            else if ( (LA59_0==RULE_NUMBER) ) {
                alt59=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 59, 0, input);

                throw nvae;
            }
            switch (alt59) {
                case 1 :
                    // InternalSM2.g:2339:3: ( (lv_text_0_0= RULE_STRING ) )
                    {
                    // InternalSM2.g:2339:3: ( (lv_text_0_0= RULE_STRING ) )
                    // InternalSM2.g:2340:4: (lv_text_0_0= RULE_STRING )
                    {
                    // InternalSM2.g:2340:4: (lv_text_0_0= RULE_STRING )
                    // InternalSM2.g:2341:5: lv_text_0_0= RULE_STRING
                    {
                    lv_text_0_0=(Token)match(input,RULE_STRING,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_text_0_0, grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getSyntaxExpressionRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"text",
                      						lv_text_0_0,
                      						"org.eclipse.xtext.common.Terminals.STRING");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2358:3: (this_NUMBER_1= RULE_NUMBER (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:2358:3: (this_NUMBER_1= RULE_NUMBER (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
                    // InternalSM2.g:2359:4: this_NUMBER_1= RULE_NUMBER (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
                    {
                    this_NUMBER_1=(Token)match(input,RULE_NUMBER,FOLLOW_57); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_NUMBER_1, grammarAccess.getSyntaxExpressionAccess().getNUMBERTerminalRuleCall_1_0());
                      			
                    }
                    // InternalSM2.g:2363:4: (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
                    int alt58=2;
                    int LA58_0 = input.LA(1);

                    if ( (LA58_0==RULE_SEMICOLON) ) {
                        alt58=1;
                    }
                    switch (alt58) {
                        case 1 :
                            // InternalSM2.g:2364:5: this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE
                            {
                            this_SEMICOLON_2=(Token)match(input,RULE_SEMICOLON,FOLLOW_51); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_2, grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0());
                              				
                            }
                            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_3, grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:2378:1: entryRuleComment returns [EObject current=null] : iv_ruleComment= ruleComment EOF ;
    public final EObject entryRuleComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleComment = null;


        try {
            // InternalSM2.g:2378:48: (iv_ruleComment= ruleComment EOF )
            // InternalSM2.g:2379:2: iv_ruleComment= ruleComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleComment=ruleComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:2385:1: ruleComment returns [EObject current=null] : (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) ;
    public final EObject ruleComment() throws RecognitionException {
        EObject current = null;

        EObject this_ShortComment_0 = null;

        EObject this_LongComment_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:2391:2: ( (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) )
            // InternalSM2.g:2392:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            {
            // InternalSM2.g:2392:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==50) ) {
                alt60=1;
            }
            else if ( (LA60_0==51) ) {
                alt60=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 60, 0, input);

                throw nvae;
            }
            switch (alt60) {
                case 1 :
                    // InternalSM2.g:2393:3: this_ShortComment_0= ruleShortComment
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ShortComment_0=ruleShortComment();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ShortComment_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2402:3: this_LongComment_1= ruleLongComment
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_LongComment_1=ruleLongComment();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_LongComment_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:2414:1: entryRuleShortComment returns [EObject current=null] : iv_ruleShortComment= ruleShortComment EOF ;
    public final EObject entryRuleShortComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleShortComment = null;


        try {
            // InternalSM2.g:2414:53: (iv_ruleShortComment= ruleShortComment EOF )
            // InternalSM2.g:2415:2: iv_ruleShortComment= ruleShortComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getShortCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleShortComment=ruleShortComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleShortComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:2421:1: ruleShortComment returns [EObject current=null] : (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) ) ;
    public final EObject ruleShortComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expr_1_0=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:2427:2: ( (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) ) )
            // InternalSM2.g:2428:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) )
            {
            // InternalSM2.g:2428:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) )
            // InternalSM2.g:2429:3: otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE )
            {
            otherlv_0=(Token)match(input,50,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0());
              		
            }
            // InternalSM2.g:2433:3: ( (lv_expr_1_0= RULE_STRING ) )
            // InternalSM2.g:2434:4: (lv_expr_1_0= RULE_STRING )
            {
            // InternalSM2.g:2434:4: (lv_expr_1_0= RULE_STRING )
            // InternalSM2.g:2435:5: lv_expr_1_0= RULE_STRING
            {
            lv_expr_1_0=(Token)match(input,RULE_STRING,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr_1_0, grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getShortCommentRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr",
              						lv_expr_1_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2451:3: ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE )
            // InternalSM2.g:2452:4: ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE
            {
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(this_EOLINE_2, grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:2462:1: entryRuleLongComment returns [EObject current=null] : iv_ruleLongComment= ruleLongComment EOF ;
    public final EObject entryRuleLongComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLongComment = null;


        try {
            // InternalSM2.g:2462:52: (iv_ruleLongComment= ruleLongComment EOF )
            // InternalSM2.g:2463:2: iv_ruleLongComment= ruleLongComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLongCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLongComment=ruleLongComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLongComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:2469:1: ruleLongComment returns [EObject current=null] : (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' ) ) ;
    public final EObject ruleLongComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expression_1_1=null;
        Token lv_expression_1_2=null;
        Token lv_expression_1_3=null;
        Token lv_expression_1_4=null;
        Token lv_expression_1_5=null;
        Token lv_expression_1_6=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSM2.g:2475:2: ( (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' ) ) )
            // InternalSM2.g:2476:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' ) )
            {
            // InternalSM2.g:2476:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' ) )
            // InternalSM2.g:2477:3: otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' )
            {
            otherlv_0=(Token)match(input,51,FOLLOW_58); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0());
              		
            }
            // InternalSM2.g:2481:3: ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )
            // InternalSM2.g:2482:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
            {
            // InternalSM2.g:2482:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
            // InternalSM2.g:2483:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
            {
            // InternalSM2.g:2483:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
            int alt61=6;
            switch ( input.LA(1) ) {
            case RULE_STRING:
                {
                alt61=1;
                }
                break;
            case RULE_PARAMSLONGCOMENT:
                {
                alt61=2;
                }
                break;
            case RULE_DEVLONGCOMENT:
                {
                alt61=3;
                }
                break;
            case RULE_RETURNSLONGCOMENT:
                {
                alt61=4;
                }
                break;
            case RULE_TITLELONGCOMENT:
                {
                alt61=5;
                }
                break;
            case RULE_NOTICELONGCOMENT:
                {
                alt61=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 61, 0, input);

                throw nvae;
            }

            switch (alt61) {
                case 1 :
                    // InternalSM2.g:2484:6: lv_expression_1_1= RULE_STRING
                    {
                    lv_expression_1_1=(Token)match(input,RULE_STRING,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_1, grammarAccess.getLongCommentAccess().getExpressionSTRINGTerminalRuleCall_1_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_1,
                      							"org.eclipse.xtext.common.Terminals.STRING");
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2499:6: lv_expression_1_2= RULE_PARAMSLONGCOMENT
                    {
                    lv_expression_1_2=(Token)match(input,RULE_PARAMSLONGCOMENT,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_2, grammarAccess.getLongCommentAccess().getExpressionPARAMSLONGCOMENTTerminalRuleCall_1_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_2,
                      							"org.xtext.SM2.PARAMSLONGCOMENT");
                      					
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2514:6: lv_expression_1_3= RULE_DEVLONGCOMENT
                    {
                    lv_expression_1_3=(Token)match(input,RULE_DEVLONGCOMENT,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_3, grammarAccess.getLongCommentAccess().getExpressionDEVLONGCOMENTTerminalRuleCall_1_0_2());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_3,
                      							"org.xtext.SM2.DEVLONGCOMENT");
                      					
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:2529:6: lv_expression_1_4= RULE_RETURNSLONGCOMENT
                    {
                    lv_expression_1_4=(Token)match(input,RULE_RETURNSLONGCOMENT,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_4, grammarAccess.getLongCommentAccess().getExpressionRETURNSLONGCOMENTTerminalRuleCall_1_0_3());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_4,
                      							"org.xtext.SM2.RETURNSLONGCOMENT");
                      					
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:2544:6: lv_expression_1_5= RULE_TITLELONGCOMENT
                    {
                    lv_expression_1_5=(Token)match(input,RULE_TITLELONGCOMENT,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_5, grammarAccess.getLongCommentAccess().getExpressionTITLELONGCOMENTTerminalRuleCall_1_0_4());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_5,
                      							"org.xtext.SM2.TITLELONGCOMENT");
                      					
                    }

                    }
                    break;
                case 6 :
                    // InternalSM2.g:2559:6: lv_expression_1_6= RULE_NOTICELONGCOMENT
                    {
                    lv_expression_1_6=(Token)match(input,RULE_NOTICELONGCOMENT,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_6, grammarAccess.getLongCommentAccess().getExpressionNOTICELONGCOMENTTerminalRuleCall_1_0_5());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_6,
                      							"org.xtext.SM2.NOTICELONGCOMENT");
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:2576:3: ( ( '*/' )=>otherlv_2= '*/' )
            // InternalSM2.g:2577:4: ( '*/' )=>otherlv_2= '*/'
            {
            otherlv_2=(Token)match(input,52,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_2, grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "ruleSingularType"
    // InternalSM2.g:2587:1: ruleSingularType returns [Enumerator current=null] : ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) ) ;
    public final Enumerator ruleSingularType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;
        Token enumLiteral_8=null;


        	enterRule();

        try {
            // InternalSM2.g:2593:2: ( ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) ) )
            // InternalSM2.g:2594:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) )
            {
            // InternalSM2.g:2594:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) )
            int alt62=9;
            switch ( input.LA(1) ) {
            case 53:
                {
                alt62=1;
                }
                break;
            case 46:
                {
                alt62=2;
                }
                break;
            case 54:
                {
                alt62=3;
                }
                break;
            case 55:
                {
                alt62=4;
                }
                break;
            case 45:
                {
                alt62=5;
                }
                break;
            case 43:
                {
                alt62=6;
                }
                break;
            case 56:
                {
                alt62=7;
                }
                break;
            case 57:
                {
                alt62=8;
                }
                break;
            case 58:
                {
                alt62=9;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 62, 0, input);

                throw nvae;
            }

            switch (alt62) {
                case 1 :
                    // InternalSM2.g:2595:3: (enumLiteral_0= 'int' )
                    {
                    // InternalSM2.g:2595:3: (enumLiteral_0= 'int' )
                    // InternalSM2.g:2596:4: enumLiteral_0= 'int'
                    {
                    enumLiteral_0=(Token)match(input,53,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2603:3: (enumLiteral_1= 'uint' )
                    {
                    // InternalSM2.g:2603:3: (enumLiteral_1= 'uint' )
                    // InternalSM2.g:2604:4: enumLiteral_1= 'uint'
                    {
                    enumLiteral_1=(Token)match(input,46,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2611:3: (enumLiteral_2= 'uint8' )
                    {
                    // InternalSM2.g:2611:3: (enumLiteral_2= 'uint8' )
                    // InternalSM2.g:2612:4: enumLiteral_2= 'uint8'
                    {
                    enumLiteral_2=(Token)match(input,54,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:2619:3: (enumLiteral_3= 'uint256' )
                    {
                    // InternalSM2.g:2619:3: (enumLiteral_3= 'uint256' )
                    // InternalSM2.g:2620:4: enumLiteral_3= 'uint256'
                    {
                    enumLiteral_3=(Token)match(input,55,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:2627:3: (enumLiteral_4= 'string' )
                    {
                    // InternalSM2.g:2627:3: (enumLiteral_4= 'string' )
                    // InternalSM2.g:2628:4: enumLiteral_4= 'string'
                    {
                    enumLiteral_4=(Token)match(input,45,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:2635:3: (enumLiteral_5= 'address' )
                    {
                    // InternalSM2.g:2635:3: (enumLiteral_5= 'address' )
                    // InternalSM2.g:2636:4: enumLiteral_5= 'address'
                    {
                    enumLiteral_5=(Token)match(input,43,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:2643:3: (enumLiteral_6= 'address payable' )
                    {
                    // InternalSM2.g:2643:3: (enumLiteral_6= 'address payable' )
                    // InternalSM2.g:2644:4: enumLiteral_6= 'address payable'
                    {
                    enumLiteral_6=(Token)match(input,56,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_6, grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6());
                      			
                    }

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:2651:3: (enumLiteral_7= 'double' )
                    {
                    // InternalSM2.g:2651:3: (enumLiteral_7= 'double' )
                    // InternalSM2.g:2652:4: enumLiteral_7= 'double'
                    {
                    enumLiteral_7=(Token)match(input,57,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_7, grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7());
                      			
                    }

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:2659:3: (enumLiteral_8= 'bool' )
                    {
                    // InternalSM2.g:2659:3: (enumLiteral_8= 'bool' )
                    // InternalSM2.g:2660:4: enumLiteral_8= 'bool'
                    {
                    enumLiteral_8=(Token)match(input,58,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_8, grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:2670:1: ruleVisibility returns [Enumerator current=null] : ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) ;
    public final Enumerator ruleVisibility() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalSM2.g:2676:2: ( ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) )
            // InternalSM2.g:2677:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            {
            // InternalSM2.g:2677:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            int alt63=4;
            switch ( input.LA(1) ) {
            case 59:
                {
                alt63=1;
                }
                break;
            case 60:
                {
                alt63=2;
                }
                break;
            case 61:
                {
                alt63=3;
                }
                break;
            case 62:
                {
                alt63=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 63, 0, input);

                throw nvae;
            }

            switch (alt63) {
                case 1 :
                    // InternalSM2.g:2678:3: (enumLiteral_0= 'public' )
                    {
                    // InternalSM2.g:2678:3: (enumLiteral_0= 'public' )
                    // InternalSM2.g:2679:4: enumLiteral_0= 'public'
                    {
                    enumLiteral_0=(Token)match(input,59,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2686:3: (enumLiteral_1= 'private' )
                    {
                    // InternalSM2.g:2686:3: (enumLiteral_1= 'private' )
                    // InternalSM2.g:2687:4: enumLiteral_1= 'private'
                    {
                    enumLiteral_1=(Token)match(input,60,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2694:3: (enumLiteral_2= 'internal' )
                    {
                    // InternalSM2.g:2694:3: (enumLiteral_2= 'internal' )
                    // InternalSM2.g:2695:4: enumLiteral_2= 'internal'
                    {
                    enumLiteral_2=(Token)match(input,61,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:2702:3: (enumLiteral_3= 'external' )
                    {
                    // InternalSM2.g:2702:3: (enumLiteral_3= 'external' )
                    // InternalSM2.g:2703:4: enumLiteral_3= 'external'
                    {
                    enumLiteral_3=(Token)match(input,62,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:2713:1: ruleCoin returns [Enumerator current=null] : ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) ;
    public final Enumerator ruleCoin() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:2719:2: ( ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) )
            // InternalSM2.g:2720:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            {
            // InternalSM2.g:2720:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            int alt64=6;
            switch ( input.LA(1) ) {
            case 63:
                {
                alt64=1;
                }
                break;
            case 64:
                {
                alt64=2;
                }
                break;
            case 65:
                {
                alt64=3;
                }
                break;
            case 66:
                {
                alt64=4;
                }
                break;
            case 67:
                {
                alt64=5;
                }
                break;
            case 68:
                {
                alt64=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 64, 0, input);

                throw nvae;
            }

            switch (alt64) {
                case 1 :
                    // InternalSM2.g:2721:3: (enumLiteral_0= 'ether' )
                    {
                    // InternalSM2.g:2721:3: (enumLiteral_0= 'ether' )
                    // InternalSM2.g:2722:4: enumLiteral_0= 'ether'
                    {
                    enumLiteral_0=(Token)match(input,63,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2729:3: (enumLiteral_1= 'wei' )
                    {
                    // InternalSM2.g:2729:3: (enumLiteral_1= 'wei' )
                    // InternalSM2.g:2730:4: enumLiteral_1= 'wei'
                    {
                    enumLiteral_1=(Token)match(input,64,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2737:3: (enumLiteral_2= 'gwei' )
                    {
                    // InternalSM2.g:2737:3: (enumLiteral_2= 'gwei' )
                    // InternalSM2.g:2738:4: enumLiteral_2= 'gwei'
                    {
                    enumLiteral_2=(Token)match(input,65,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:2745:3: (enumLiteral_3= 'pwei' )
                    {
                    // InternalSM2.g:2745:3: (enumLiteral_3= 'pwei' )
                    // InternalSM2.g:2746:4: enumLiteral_3= 'pwei'
                    {
                    enumLiteral_3=(Token)match(input,66,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:2753:3: (enumLiteral_4= 'finney' )
                    {
                    // InternalSM2.g:2753:3: (enumLiteral_4= 'finney' )
                    // InternalSM2.g:2754:4: enumLiteral_4= 'finney'
                    {
                    enumLiteral_4=(Token)match(input,67,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:2761:3: (enumLiteral_5= 'szabo' )
                    {
                    // InternalSM2.g:2761:3: (enumLiteral_5= 'szabo' )
                    // InternalSM2.g:2762:4: enumLiteral_5= 'szabo'
                    {
                    enumLiteral_5=(Token)match(input,68,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:2772:1: ruleComparationOperator returns [Enumerator current=null] : ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) ;
    public final Enumerator ruleComparationOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:2778:2: ( ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) )
            // InternalSM2.g:2779:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            {
            // InternalSM2.g:2779:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            int alt65=6;
            switch ( input.LA(1) ) {
            case 31:
                {
                alt65=1;
                }
                break;
            case 33:
                {
                alt65=2;
                }
                break;
            case 32:
                {
                alt65=3;
                }
                break;
            case 34:
                {
                alt65=4;
                }
                break;
            case 69:
                {
                alt65=5;
                }
                break;
            case 70:
                {
                alt65=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 65, 0, input);

                throw nvae;
            }

            switch (alt65) {
                case 1 :
                    // InternalSM2.g:2780:3: (enumLiteral_0= '>' )
                    {
                    // InternalSM2.g:2780:3: (enumLiteral_0= '>' )
                    // InternalSM2.g:2781:4: enumLiteral_0= '>'
                    {
                    enumLiteral_0=(Token)match(input,31,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2788:3: (enumLiteral_1= '<' )
                    {
                    // InternalSM2.g:2788:3: (enumLiteral_1= '<' )
                    // InternalSM2.g:2789:4: enumLiteral_1= '<'
                    {
                    enumLiteral_1=(Token)match(input,33,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2796:3: (enumLiteral_2= '>=' )
                    {
                    // InternalSM2.g:2796:3: (enumLiteral_2= '>=' )
                    // InternalSM2.g:2797:4: enumLiteral_2= '>='
                    {
                    enumLiteral_2=(Token)match(input,32,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:2804:3: (enumLiteral_3= '<=' )
                    {
                    // InternalSM2.g:2804:3: (enumLiteral_3= '<=' )
                    // InternalSM2.g:2805:4: enumLiteral_3= '<='
                    {
                    enumLiteral_3=(Token)match(input,34,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:2812:3: (enumLiteral_4= '==' )
                    {
                    // InternalSM2.g:2812:3: (enumLiteral_4= '==' )
                    // InternalSM2.g:2813:4: enumLiteral_4= '=='
                    {
                    enumLiteral_4=(Token)match(input,69,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:2820:3: (enumLiteral_5= '!=' )
                    {
                    // InternalSM2.g:2820:3: (enumLiteral_5= '!=' )
                    // InternalSM2.g:2821:4: enumLiteral_5= '!='
                    {
                    enumLiteral_5=(Token)match(input,70,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:2831:1: ruleLogicalPairOperator returns [Enumerator current=null] : ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) ;
    public final Enumerator ruleLogicalPairOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSM2.g:2837:2: ( ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) )
            // InternalSM2.g:2838:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            {
            // InternalSM2.g:2838:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==71) ) {
                alt66=1;
            }
            else if ( (LA66_0==72) ) {
                alt66=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 66, 0, input);

                throw nvae;
            }
            switch (alt66) {
                case 1 :
                    // InternalSM2.g:2839:3: (enumLiteral_0= '&&' )
                    {
                    // InternalSM2.g:2839:3: (enumLiteral_0= '&&' )
                    // InternalSM2.g:2840:4: enumLiteral_0= '&&'
                    {
                    enumLiteral_0=(Token)match(input,71,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2847:3: (enumLiteral_1= '||' )
                    {
                    // InternalSM2.g:2847:3: (enumLiteral_1= '||' )
                    // InternalSM2.g:2848:4: enumLiteral_1= '||'
                    {
                    enumLiteral_1=(Token)match(input,72,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:2858:1: ruleArithmeticalOperator returns [Enumerator current=null] : ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) ) ;
    public final Enumerator ruleArithmeticalOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalSM2.g:2864:2: ( ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) ) )
            // InternalSM2.g:2865:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) )
            {
            // InternalSM2.g:2865:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) )
            int alt67=4;
            switch ( input.LA(1) ) {
            case 73:
                {
                alt67=1;
                }
                break;
            case 74:
                {
                alt67=2;
                }
                break;
            case 75:
                {
                alt67=3;
                }
                break;
            case 76:
                {
                alt67=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 67, 0, input);

                throw nvae;
            }

            switch (alt67) {
                case 1 :
                    // InternalSM2.g:2866:3: (enumLiteral_0= '+' )
                    {
                    // InternalSM2.g:2866:3: (enumLiteral_0= '+' )
                    // InternalSM2.g:2867:4: enumLiteral_0= '+'
                    {
                    enumLiteral_0=(Token)match(input,73,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2874:3: (enumLiteral_1= '-' )
                    {
                    // InternalSM2.g:2874:3: (enumLiteral_1= '-' )
                    // InternalSM2.g:2875:4: enumLiteral_1= '-'
                    {
                    enumLiteral_1=(Token)match(input,74,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2882:3: (enumLiteral_2= '*' )
                    {
                    // InternalSM2.g:2882:3: (enumLiteral_2= '*' )
                    // InternalSM2.g:2883:4: enumLiteral_2= '*'
                    {
                    enumLiteral_2=(Token)match(input,75,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:2890:3: (enumLiteral_3= '/' )
                    {
                    // InternalSM2.g:2890:3: (enumLiteral_3= '/' )
                    // InternalSM2.g:2891:4: enumLiteral_3= '/'
                    {
                    enumLiteral_3=(Token)match(input,76,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmeticalOperator"

    // Delegated rules


    protected DFA26 dfa26 = new DFA26(this);
    protected DFA51 dfa51 = new DFA51(this);
    static final String dfa_1s = "\16\uffff";
    static final String dfa_2s = "\1\52\1\6\1\7\1\5\1\53\1\uffff\1\6\2\4\1\uffff\1\4\1\5\1\10\1\6";
    static final String dfa_3s = "\1\52\1\6\1\7\2\72\1\uffff\1\76\1\54\1\20\1\uffff\1\4\2\72\1\76";
    static final String dfa_4s = "\5\uffff\1\1\3\uffff\1\2\4\uffff";
    static final String dfa_5s = "\16\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\4\45\uffff\1\6\1\uffff\2\5\6\uffff\6\5",
            "\1\6\1\uffff\2\5\6\uffff\6\5",
            "",
            "\1\7\64\uffff\4\5",
            "\1\11\47\uffff\1\10",
            "\1\5\10\uffff\1\12\2\uffff\1\5",
            "",
            "\1\13",
            "\1\14\2\uffff\1\5\42\uffff\1\5\1\uffff\1\15\1\5\6\uffff\6\5",
            "\1\5\42\uffff\1\5\1\uffff\1\15\1\5\6\uffff\6\5",
            "\1\5\6\uffff\1\11\55\uffff\4\5"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA26 extends DFA {

        public DFA26(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 26;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "1108:2: ( ( (lv_typeStruct_0_0= rulePersonalizedStruct ) ) | this_User_1= ruleUser )";
        }
    }
    static final String dfa_7s = "\20\uffff";
    static final String dfa_8s = "\1\11\1\13\1\uffff\1\11\1\37\1\4\6\11\1\5\1\4\1\uffff\1\37";
    static final String dfa_9s = "\1\60\1\13\1\uffff\1\15\2\106\6\15\1\5\1\104\1\uffff\1\106";
    static final String dfa_10s = "\2\uffff\1\2\13\uffff\1\1\1\uffff";
    static final String dfa_11s = "\20\uffff}>";
    static final String[] dfa_12s = {
            "\1\2\1\uffff\1\2\1\uffff\1\2\42\uffff\1\1",
            "\1\3",
            "",
            "\1\5\3\uffff\1\4",
            "\1\6\1\10\1\7\1\11\42\uffff\1\12\1\13",
            "\1\14\32\uffff\1\6\1\10\1\7\1\11\42\uffff\1\12\1\13",
            "\1\15\3\uffff\1\16",
            "\1\15\3\uffff\1\16",
            "\1\15\3\uffff\1\16",
            "\1\15\3\uffff\1\16",
            "\1\15\3\uffff\1\16",
            "\1\15\3\uffff\1\16",
            "\1\17",
            "\1\16\7\uffff\1\16\62\uffff\6\2",
            "",
            "\1\6\1\10\1\7\1\11\42\uffff\1\12\1\13"
    };

    static final short[] dfa_7 = DFA.unpackEncodedString(dfa_7s);
    static final char[] dfa_8 = DFA.unpackEncodedStringToUnsignedChars(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final short[] dfa_10 = DFA.unpackEncodedString(dfa_10s);
    static final short[] dfa_11 = DFA.unpackEncodedString(dfa_11s);
    static final short[][] dfa_12 = unpackEncodedStringArray(dfa_12s);

    class DFA51 extends DFA {

        public DFA51(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 51;
            this.eot = dfa_7;
            this.eof = dfa_7;
            this.min = dfa_8;
            this.max = dfa_9;
            this.accept = dfa_10;
            this.special = dfa_11;
            this.transition = dfa_12;
        }
        public String getDescription() {
            return "2061:3: ( (lv_restriction_9_0= ruleRestriction ) )?";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x00000001C0000000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000810000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000810000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000020000080L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x07EEED6000000160L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x07EEED6000000140L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x000E006000000100L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x000E004000000100L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x000E000000000100L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x000C000000000100L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000600000002L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000001000000010L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x07E0680000001000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000002020L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000008000000020L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x07E0680000000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x7800000000000040L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x07E0680000000020L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x07E0680000000100L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000080000000020L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000100000000010L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000200000000020L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000400000000020L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000000000000120L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x000000000000A100L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000002100L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000000000012010L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000008002L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000002200L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000780000000L,0x0000000000000060L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x8000000000000000L,0x000000000000001FL});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0000000000001040L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0001000000002A00L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0001000000002B20L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001E00L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x00000000003E2000L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0010000000000000L});

}