package org.xtext.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_STRING", "RULE_ID", "RULE_OPENKEY", "RULE_CLOSEKEY", "RULE_DOT", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_EMAIL", "RULE_COMMA", "RULE_INT", "RULE_CONSTANT", "RULE_FLOAT", "RULE_BOOLVALUE", "RULE_HEXEXPRESSION", "RULE_NEW", "RULE_RETURNS", "RULE_PARAMSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_DELETE", "RULE_EMIT", "RULE_RETURN", "RULE_IF", "RULE_ELSE", "RULE_CHAR", "RULE_BREAK", "RULE_NUMVERSION1", "RULE_NUMVERSION2", "RULE_NUMVERSION3", "RULE_CONTINUE", "RULE_NOTICELONGCOMENT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'pragma'", "'solidity'", "'^'", "'>'", "'>='", "'0.5.24'", "'import'", "'as'", "'from'", "'interface'", "'msg'", "'data'", "'value'", "'gas'", "'sender'", "'sig'", "'block'", "'difficulty'", "'number'", "'timestamp'", "'coinbase'", "'gaslimit'", "'blockhash'", "'now'", "'tx'", "'gasprice'", "'origin'", "'this'", "'balance'", "'contract'", "'is'", "'constructor'", "'public'", "'internal'", "'event'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'User'", "'address'", "'msg.sender'", "'string'", "'='", "'Company'", "'enum'", "'uint'", "'uint2'", "'uint4'", "'uint8'", "'uint16'", "'uint24'", "'uint32'", "'uint40'", "'uint48'", "'uint56'", "'uint64'", "'uint80'", "'uint88'", "'uint96'", "'uint104'", "'uint128'", "'uint160'", "'uint200'", "'uint256'", "'int'", "'int2'", "'int4'", "'int8'", "'int16'", "'int24'", "'int32'", "'int40'", "'int48'", "'int56'", "'int64'", "'int80'", "'int88'", "'int96'", "'int104'", "'int128'", "'int160'", "'int200'", "'int256'", "'bytes'", "'bytes2'", "'bytes3'", "'bytes4'", "'bytes5'", "'bytes6'", "'bytes7'", "'bytes8'", "'bytes10'", "'bytes12'", "'bytes14'", "'bytes16'", "'bytes18'", "'bytes20'", "'bytes24'", "'bytes28'", "'bytes30'", "'bytes32'", "'address payable'", "'double'", "'bool'", "'[]'", "'['", "']'", "'Insert text here'", "'float'", "'0x'", "'indexed'", "'require'", "'function'", "'selfdestruct'", "'keccack256'", "'sha256'", "'sha3'", "'//'", "'/*'", "'*/'", "'!'", "'seconds'", "'minutes'", "'hours'", "'days'", "'weeks'", "'years'", "'=='", "'!='", "'<'", "'<='", "'+'", "'-'", "'*'", "'/'", "'%'", "'&&'", "'||'", "'++'", "'--'", "'while'", "'for'", "'char'", "'do'", "'view'", "'pure'", "'payable'", "'memory'", "'storage'", "'private'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'"
    };
    public static final int T__144=144;
    public static final int T__143=143;
    public static final int T__146=146;
    public static final int T__50=50;
    public static final int T__145=145;
    public static final int T__140=140;
    public static final int T__142=142;
    public static final int T__141=141;
    public static final int RULE_OPENPARENTHESIS=11;
    public static final int T__59=59;
    public static final int RULE_EMIT=27;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__137=137;
    public static final int T__52=52;
    public static final int T__136=136;
    public static final int T__53=53;
    public static final int T__139=139;
    public static final int T__54=54;
    public static final int T__138=138;
    public static final int T__133=133;
    public static final int T__132=132;
    public static final int RULE_PARAMSLONGCOMENT=22;
    public static final int T__60=60;
    public static final int T__135=135;
    public static final int T__61=61;
    public static final int T__134=134;
    public static final int RULE_ID=7;
    public static final int T__131=131;
    public static final int T__130=130;
    public static final int RULE_INT=15;
    public static final int T__66=66;
    public static final int T__67=67;
    public static final int T__129=129;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__126=126;
    public static final int T__63=63;
    public static final int T__125=125;
    public static final int T__64=64;
    public static final int T__128=128;
    public static final int T__65=65;
    public static final int T__127=127;
    public static final int T__166=166;
    public static final int T__165=165;
    public static final int T__168=168;
    public static final int T__167=167;
    public static final int T__162=162;
    public static final int T__161=161;
    public static final int T__164=164;
    public static final int T__163=163;
    public static final int T__160=160;
    public static final int RULE_NOTICELONGCOMENT=37;
    public static final int RULE_CONSTANT=16;
    public static final int RULE_OPENKEY=8;
    public static final int RULE_IF=29;
    public static final int T__159=159;
    public static final int T__158=158;
    public static final int T__155=155;
    public static final int T__154=154;
    public static final int T__157=157;
    public static final int T__156=156;
    public static final int T__151=151;
    public static final int T__150=150;
    public static final int T__153=153;
    public static final int T__152=152;
    public static final int RULE_DEVLONGCOMENT=24;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int RULE_FLOAT=17;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__148=148;
    public static final int T__147=147;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__149=149;
    public static final int T__100=100;
    public static final int T__102=102;
    public static final int T__101=101;
    public static final int RULE_COMMA=14;
    public static final int RULE_RETURNSLONGCOMENT=25;
    public static final int RULE_SEMICOLON=4;
    public static final int RULE_NUMVERSION3=35;
    public static final int RULE_NUMVERSION2=34;
    public static final int RULE_NUMVERSION1=33;
    public static final int T__122=122;
    public static final int T__121=121;
    public static final int T__124=124;
    public static final int RULE_BOOLVALUE=18;
    public static final int T__123=123;
    public static final int T__120=120;
    public static final int RULE_SL_COMMENT=39;
    public static final int RULE_BREAK=32;
    public static final int T__119=119;
    public static final int T__118=118;
    public static final int T__115=115;
    public static final int EOF=-1;
    public static final int T__114=114;
    public static final int T__117=117;
    public static final int T__116=116;
    public static final int T__111=111;
    public static final int T__110=110;
    public static final int T__113=113;
    public static final int T__112=112;
    public static final int T__108=108;
    public static final int T__107=107;
    public static final int T__109=109;
    public static final int T__104=104;
    public static final int T__103=103;
    public static final int T__106=106;
    public static final int T__105=105;
    public static final int RULE_RETURNS=21;
    public static final int RULE_EOLINE=5;
    public static final int RULE_RETURN=28;
    public static final int RULE_ML_COMMENT=38;
    public static final int RULE_DELETE=26;
    public static final int RULE_TITLELONGCOMENT=23;
    public static final int RULE_EMAIL=13;
    public static final int RULE_CLOSEPARENTHESIS=12;
    public static final int RULE_DOT=10;
    public static final int RULE_CONTINUE=36;
    public static final int T__91=91;
    public static final int T__188=188;
    public static final int T__92=92;
    public static final int T__187=187;
    public static final int T__93=93;
    public static final int T__94=94;
    public static final int T__189=189;
    public static final int T__184=184;
    public static final int T__183=183;
    public static final int T__186=186;
    public static final int RULE_NEW=20;
    public static final int T__90=90;
    public static final int T__185=185;
    public static final int T__180=180;
    public static final int T__182=182;
    public static final int T__181=181;
    public static final int T__99=99;
    public static final int RULE_CHAR=31;
    public static final int RULE_CLOSEKEY=9;
    public static final int T__95=95;
    public static final int T__96=96;
    public static final int T__97=97;
    public static final int T__98=98;
    public static final int T__177=177;
    public static final int T__176=176;
    public static final int T__179=179;
    public static final int T__178=178;
    public static final int T__173=173;
    public static final int T__172=172;
    public static final int T__175=175;
    public static final int T__174=174;
    public static final int T__171=171;
    public static final int T__170=170;
    public static final int T__169=169;
    public static final int RULE_ELSE=30;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_STRING=6;
    public static final int RULE_HEXEXPRESSION=19;
    public static final int T__77=77;
    public static final int T__78=78;
    public static final int T__79=79;
    public static final int T__73=73;
    public static final int T__74=74;
    public static final int T__75=75;
    public static final int T__76=76;
    public static final int T__80=80;
    public static final int T__199=199;
    public static final int T__81=81;
    public static final int T__198=198;
    public static final int T__82=82;
    public static final int T__83=83;
    public static final int T__195=195;
    public static final int T__194=194;
    public static final int RULE_WS=40;
    public static final int T__197=197;
    public static final int T__196=196;
    public static final int T__191=191;
    public static final int T__190=190;
    public static final int T__193=193;
    public static final int T__192=192;
    public static final int RULE_ANY_OTHER=41;
    public static final int T__88=88;
    public static final int T__89=89;
    public static final int T__84=84;
    public static final int T__85=85;
    public static final int T__86=86;
    public static final int T__87=87;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }



     	private SM2GrammarAccess grammarAccess;

        public InternalSM2Parser(TokenStream input, SM2GrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "File";
       	}

       	@Override
       	protected SM2GrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleFile"
    // InternalSM2.g:65:1: entryRuleFile returns [EObject current=null] : iv_ruleFile= ruleFile EOF ;
    public final EObject entryRuleFile() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFile = null;


        try {
            // InternalSM2.g:65:45: (iv_ruleFile= ruleFile EOF )
            // InternalSM2.g:66:2: iv_ruleFile= ruleFile EOF
            {
             newCompositeNode(grammarAccess.getFileRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFile=ruleFile();

            state._fsp--;

             current =iv_ruleFile; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFile"


    // $ANTLR start "ruleFile"
    // InternalSM2.g:72:1: ruleFile returns [EObject current=null] : ( ( (lv_version_0_0= ruleVersion ) ) ( (lv_imports_1_0= ruleImport ) )* ( (lv_interfaces_2_0= ruleInterface ) )* ( (lv_properties_3_0= ruleProperties ) )* ( (lv_events_4_0= ruleEvent ) )* ( (lv_contract_5_0= ruleContract ) ) ( (lv_comments_6_0= ruleComment ) )* ) ;
    public final EObject ruleFile() throws RecognitionException {
        EObject current = null;

        EObject lv_version_0_0 = null;

        EObject lv_imports_1_0 = null;

        EObject lv_interfaces_2_0 = null;

        EObject lv_properties_3_0 = null;

        EObject lv_events_4_0 = null;

        EObject lv_contract_5_0 = null;

        EObject lv_comments_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:78:2: ( ( ( (lv_version_0_0= ruleVersion ) ) ( (lv_imports_1_0= ruleImport ) )* ( (lv_interfaces_2_0= ruleInterface ) )* ( (lv_properties_3_0= ruleProperties ) )* ( (lv_events_4_0= ruleEvent ) )* ( (lv_contract_5_0= ruleContract ) ) ( (lv_comments_6_0= ruleComment ) )* ) )
            // InternalSM2.g:79:2: ( ( (lv_version_0_0= ruleVersion ) ) ( (lv_imports_1_0= ruleImport ) )* ( (lv_interfaces_2_0= ruleInterface ) )* ( (lv_properties_3_0= ruleProperties ) )* ( (lv_events_4_0= ruleEvent ) )* ( (lv_contract_5_0= ruleContract ) ) ( (lv_comments_6_0= ruleComment ) )* )
            {
            // InternalSM2.g:79:2: ( ( (lv_version_0_0= ruleVersion ) ) ( (lv_imports_1_0= ruleImport ) )* ( (lv_interfaces_2_0= ruleInterface ) )* ( (lv_properties_3_0= ruleProperties ) )* ( (lv_events_4_0= ruleEvent ) )* ( (lv_contract_5_0= ruleContract ) ) ( (lv_comments_6_0= ruleComment ) )* )
            // InternalSM2.g:80:3: ( (lv_version_0_0= ruleVersion ) ) ( (lv_imports_1_0= ruleImport ) )* ( (lv_interfaces_2_0= ruleInterface ) )* ( (lv_properties_3_0= ruleProperties ) )* ( (lv_events_4_0= ruleEvent ) )* ( (lv_contract_5_0= ruleContract ) ) ( (lv_comments_6_0= ruleComment ) )*
            {
            // InternalSM2.g:80:3: ( (lv_version_0_0= ruleVersion ) )
            // InternalSM2.g:81:4: (lv_version_0_0= ruleVersion )
            {
            // InternalSM2.g:81:4: (lv_version_0_0= ruleVersion )
            // InternalSM2.g:82:5: lv_version_0_0= ruleVersion
            {

            					newCompositeNode(grammarAccess.getFileAccess().getVersionVersionParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_3);
            lv_version_0_0=ruleVersion();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFileRule());
            					}
            					set(
            						current,
            						"version",
            						lv_version_0_0,
            						"org.xtext.SM2.Version");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:99:3: ( (lv_imports_1_0= ruleImport ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==48) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalSM2.g:100:4: (lv_imports_1_0= ruleImport )
            	    {
            	    // InternalSM2.g:100:4: (lv_imports_1_0= ruleImport )
            	    // InternalSM2.g:101:5: lv_imports_1_0= ruleImport
            	    {

            	    					newCompositeNode(grammarAccess.getFileAccess().getImportsImportParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_3);
            	    lv_imports_1_0=ruleImport();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFileRule());
            	    					}
            	    					add(
            	    						current,
            	    						"imports",
            	    						lv_imports_1_0,
            	    						"org.xtext.SM2.Import");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            // InternalSM2.g:118:3: ( (lv_interfaces_2_0= ruleInterface ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==51) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSM2.g:119:4: (lv_interfaces_2_0= ruleInterface )
            	    {
            	    // InternalSM2.g:119:4: (lv_interfaces_2_0= ruleInterface )
            	    // InternalSM2.g:120:5: lv_interfaces_2_0= ruleInterface
            	    {

            	    					newCompositeNode(grammarAccess.getFileAccess().getInterfacesInterfaceParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_3);
            	    lv_interfaces_2_0=ruleInterface();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFileRule());
            	    					}
            	    					add(
            	    						current,
            	    						"interfaces",
            	    						lv_interfaces_2_0,
            	    						"org.xtext.SM2.Interface");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalSM2.g:137:3: ( (lv_properties_3_0= ruleProperties ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==81||LA3_0==83||LA3_0==85||(LA3_0>=89 && LA3_0<=145)||LA3_0==147||LA3_0==152) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalSM2.g:138:4: (lv_properties_3_0= ruleProperties )
            	    {
            	    // InternalSM2.g:138:4: (lv_properties_3_0= ruleProperties )
            	    // InternalSM2.g:139:5: lv_properties_3_0= ruleProperties
            	    {

            	    					newCompositeNode(grammarAccess.getFileAccess().getPropertiesPropertiesParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_3);
            	    lv_properties_3_0=ruleProperties();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFileRule());
            	    					}
            	    					add(
            	    						current,
            	    						"properties",
            	    						lv_properties_3_0,
            	    						"org.xtext.SM2.Properties");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            // InternalSM2.g:156:3: ( (lv_events_4_0= ruleEvent ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==76) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalSM2.g:157:4: (lv_events_4_0= ruleEvent )
            	    {
            	    // InternalSM2.g:157:4: (lv_events_4_0= ruleEvent )
            	    // InternalSM2.g:158:5: lv_events_4_0= ruleEvent
            	    {

            	    					newCompositeNode(grammarAccess.getFileAccess().getEventsEventParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_3);
            	    lv_events_4_0=ruleEvent();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFileRule());
            	    					}
            	    					add(
            	    						current,
            	    						"events",
            	    						lv_events_4_0,
            	    						"org.xtext.SM2.Event");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            // InternalSM2.g:175:3: ( (lv_contract_5_0= ruleContract ) )
            // InternalSM2.g:176:4: (lv_contract_5_0= ruleContract )
            {
            // InternalSM2.g:176:4: (lv_contract_5_0= ruleContract )
            // InternalSM2.g:177:5: lv_contract_5_0= ruleContract
            {

            					newCompositeNode(grammarAccess.getFileAccess().getContractContractParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_4);
            lv_contract_5_0=ruleContract();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFileRule());
            					}
            					set(
            						current,
            						"contract",
            						lv_contract_5_0,
            						"org.xtext.SM2.Contract");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:194:3: ( (lv_comments_6_0= ruleComment ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( ((LA5_0>=161 && LA5_0<=162)) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalSM2.g:195:4: (lv_comments_6_0= ruleComment )
            	    {
            	    // InternalSM2.g:195:4: (lv_comments_6_0= ruleComment )
            	    // InternalSM2.g:196:5: lv_comments_6_0= ruleComment
            	    {

            	    					newCompositeNode(grammarAccess.getFileAccess().getCommentsCommentParserRuleCall_6_0());
            	    				
            	    pushFollow(FOLLOW_4);
            	    lv_comments_6_0=ruleComment();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFileRule());
            	    					}
            	    					add(
            	    						current,
            	    						"comments",
            	    						lv_comments_6_0,
            	    						"org.xtext.SM2.Comment");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFile"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:217:1: entryRuleVersion returns [EObject current=null] : iv_ruleVersion= ruleVersion EOF ;
    public final EObject entryRuleVersion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVersion = null;


        try {
            // InternalSM2.g:217:48: (iv_ruleVersion= ruleVersion EOF )
            // InternalSM2.g:218:2: iv_ruleVersion= ruleVersion EOF
            {
             newCompositeNode(grammarAccess.getVersionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVersion=ruleVersion();

            state._fsp--;

             current =iv_ruleVersion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:224:1: ruleVersion returns [EObject current=null] : (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= '0.5.24' ) ) this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) ;
    public final EObject ruleVersion() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_symbol_2_1=null;
        Token lv_symbol_2_2=null;
        Token lv_symbol_2_3=null;
        Token lv_numberVersion_3_0=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;


        	enterRule();

        try {
            // InternalSM2.g:230:2: ( (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= '0.5.24' ) ) this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:231:2: (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= '0.5.24' ) ) this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:231:2: (otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= '0.5.24' ) ) this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:232:3: otherlv_0= 'pragma' otherlv_1= 'solidity' ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) ) ( (lv_numberVersion_3_0= '0.5.24' ) ) this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,42,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getVersionAccess().getPragmaKeyword_0());
            		
            otherlv_1=(Token)match(input,43,FOLLOW_6); 

            			newLeafNode(otherlv_1, grammarAccess.getVersionAccess().getSolidityKeyword_1());
            		
            // InternalSM2.g:240:3: ( ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) ) )
            // InternalSM2.g:241:4: ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) )
            {
            // InternalSM2.g:241:4: ( (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' ) )
            // InternalSM2.g:242:5: (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' )
            {
            // InternalSM2.g:242:5: (lv_symbol_2_1= '^' | lv_symbol_2_2= '>' | lv_symbol_2_3= '>=' )
            int alt6=3;
            switch ( input.LA(1) ) {
            case 44:
                {
                alt6=1;
                }
                break;
            case 45:
                {
                alt6=2;
                }
                break;
            case 46:
                {
                alt6=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // InternalSM2.g:243:6: lv_symbol_2_1= '^'
                    {
                    lv_symbol_2_1=(Token)match(input,44,FOLLOW_7); 

                    						newLeafNode(lv_symbol_2_1, grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_2_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_2_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:254:6: lv_symbol_2_2= '>'
                    {
                    lv_symbol_2_2=(Token)match(input,45,FOLLOW_7); 

                    						newLeafNode(lv_symbol_2_2, grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_2_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_2_2, null);
                    					

                    }
                    break;
                case 3 :
                    // InternalSM2.g:265:6: lv_symbol_2_3= '>='
                    {
                    lv_symbol_2_3=(Token)match(input,46,FOLLOW_7); 

                    						newLeafNode(lv_symbol_2_3, grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_2_0_2());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_2_3, null);
                    					

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:278:3: ( (lv_numberVersion_3_0= '0.5.24' ) )
            // InternalSM2.g:279:4: (lv_numberVersion_3_0= '0.5.24' )
            {
            // InternalSM2.g:279:4: (lv_numberVersion_3_0= '0.5.24' )
            // InternalSM2.g:280:5: lv_numberVersion_3_0= '0.5.24'
            {
            lv_numberVersion_3_0=(Token)match(input,47,FOLLOW_8); 

            					newLeafNode(lv_numberVersion_3_0, grammarAccess.getVersionAccess().getNumberVersion0524Keyword_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVersionRule());
            					}
            					setWithLastConsumed(current, "numberVersion", lv_numberVersion_3_0, "0.5.24");
            				

            }


            }

            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

            			newLeafNode(this_SEMICOLON_4, grammarAccess.getVersionAccess().getSEMICOLONTerminalRuleCall_4());
            		
            // InternalSM2.g:296:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==RULE_EOLINE) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalSM2.g:297:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_5, grammarAccess.getVersionAccess().getEOLINETerminalRuleCall_5());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleImport"
    // InternalSM2.g:306:1: entryRuleImport returns [EObject current=null] : iv_ruleImport= ruleImport EOF ;
    public final EObject entryRuleImport() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleImport = null;


        try {
            // InternalSM2.g:306:47: (iv_ruleImport= ruleImport EOF )
            // InternalSM2.g:307:2: iv_ruleImport= ruleImport EOF
            {
             newCompositeNode(grammarAccess.getImportRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleImport=ruleImport();

            state._fsp--;

             current =iv_ruleImport; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2.g:313:1: ruleImport returns [EObject current=null] : ( (otherlv_0= 'import' ( (lv_name_1_0= RULE_STRING ) ) this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? ) | (otherlv_4= 'import' ( (lv_name_5_0= RULE_STRING ) ) otherlv_6= 'as' this_STRING_7= RULE_STRING otherlv_8= 'from' ( (lv_alias_9_0= RULE_STRING ) ) this_SEMICOLON_10= RULE_SEMICOLON (this_EOLINE_11= RULE_EOLINE )? ) | (otherlv_12= 'import' ( (lv_name_13_0= RULE_STRING ) ) otherlv_14= 'as' ( (lv_alias_15_0= RULE_STRING ) ) this_SEMICOLON_16= RULE_SEMICOLON (this_EOLINE_17= RULE_EOLINE )? ) ) ;
    public final EObject ruleImport() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token this_SEMICOLON_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_name_5_0=null;
        Token otherlv_6=null;
        Token this_STRING_7=null;
        Token otherlv_8=null;
        Token lv_alias_9_0=null;
        Token this_SEMICOLON_10=null;
        Token this_EOLINE_11=null;
        Token otherlv_12=null;
        Token lv_name_13_0=null;
        Token otherlv_14=null;
        Token lv_alias_15_0=null;
        Token this_SEMICOLON_16=null;
        Token this_EOLINE_17=null;


        	enterRule();

        try {
            // InternalSM2.g:319:2: ( ( (otherlv_0= 'import' ( (lv_name_1_0= RULE_STRING ) ) this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? ) | (otherlv_4= 'import' ( (lv_name_5_0= RULE_STRING ) ) otherlv_6= 'as' this_STRING_7= RULE_STRING otherlv_8= 'from' ( (lv_alias_9_0= RULE_STRING ) ) this_SEMICOLON_10= RULE_SEMICOLON (this_EOLINE_11= RULE_EOLINE )? ) | (otherlv_12= 'import' ( (lv_name_13_0= RULE_STRING ) ) otherlv_14= 'as' ( (lv_alias_15_0= RULE_STRING ) ) this_SEMICOLON_16= RULE_SEMICOLON (this_EOLINE_17= RULE_EOLINE )? ) ) )
            // InternalSM2.g:320:2: ( (otherlv_0= 'import' ( (lv_name_1_0= RULE_STRING ) ) this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? ) | (otherlv_4= 'import' ( (lv_name_5_0= RULE_STRING ) ) otherlv_6= 'as' this_STRING_7= RULE_STRING otherlv_8= 'from' ( (lv_alias_9_0= RULE_STRING ) ) this_SEMICOLON_10= RULE_SEMICOLON (this_EOLINE_11= RULE_EOLINE )? ) | (otherlv_12= 'import' ( (lv_name_13_0= RULE_STRING ) ) otherlv_14= 'as' ( (lv_alias_15_0= RULE_STRING ) ) this_SEMICOLON_16= RULE_SEMICOLON (this_EOLINE_17= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:320:2: ( (otherlv_0= 'import' ( (lv_name_1_0= RULE_STRING ) ) this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? ) | (otherlv_4= 'import' ( (lv_name_5_0= RULE_STRING ) ) otherlv_6= 'as' this_STRING_7= RULE_STRING otherlv_8= 'from' ( (lv_alias_9_0= RULE_STRING ) ) this_SEMICOLON_10= RULE_SEMICOLON (this_EOLINE_11= RULE_EOLINE )? ) | (otherlv_12= 'import' ( (lv_name_13_0= RULE_STRING ) ) otherlv_14= 'as' ( (lv_alias_15_0= RULE_STRING ) ) this_SEMICOLON_16= RULE_SEMICOLON (this_EOLINE_17= RULE_EOLINE )? ) )
            int alt11=3;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==48) ) {
                int LA11_1 = input.LA(2);

                if ( (LA11_1==RULE_STRING) ) {
                    int LA11_2 = input.LA(3);

                    if ( (LA11_2==RULE_SEMICOLON) ) {
                        alt11=1;
                    }
                    else if ( (LA11_2==49) ) {
                        int LA11_4 = input.LA(4);

                        if ( (LA11_4==RULE_STRING) ) {
                            int LA11_5 = input.LA(5);

                            if ( (LA11_5==RULE_SEMICOLON) ) {
                                alt11=3;
                            }
                            else if ( (LA11_5==50) ) {
                                alt11=2;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 11, 5, input);

                                throw nvae;
                            }
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 11, 4, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 11, 2, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 11, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalSM2.g:321:3: (otherlv_0= 'import' ( (lv_name_1_0= RULE_STRING ) ) this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:321:3: (otherlv_0= 'import' ( (lv_name_1_0= RULE_STRING ) ) this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? )
                    // InternalSM2.g:322:4: otherlv_0= 'import' ( (lv_name_1_0= RULE_STRING ) ) this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )?
                    {
                    otherlv_0=(Token)match(input,48,FOLLOW_10); 

                    				newLeafNode(otherlv_0, grammarAccess.getImportAccess().getImportKeyword_0_0());
                    			
                    // InternalSM2.g:326:4: ( (lv_name_1_0= RULE_STRING ) )
                    // InternalSM2.g:327:5: (lv_name_1_0= RULE_STRING )
                    {
                    // InternalSM2.g:327:5: (lv_name_1_0= RULE_STRING )
                    // InternalSM2.g:328:6: lv_name_1_0= RULE_STRING
                    {
                    lv_name_1_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

                    						newLeafNode(lv_name_1_0, grammarAccess.getImportAccess().getNameSTRINGTerminalRuleCall_0_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getImportRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"name",
                    							lv_name_1_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }

                    this_SEMICOLON_2=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

                    				newLeafNode(this_SEMICOLON_2, grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_0_2());
                    			
                    // InternalSM2.g:348:4: (this_EOLINE_3= RULE_EOLINE )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==RULE_EOLINE) ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // InternalSM2.g:349:5: this_EOLINE_3= RULE_EOLINE
                            {
                            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                            					newLeafNode(this_EOLINE_3, grammarAccess.getImportAccess().getEOLINETerminalRuleCall_0_3());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:356:3: (otherlv_4= 'import' ( (lv_name_5_0= RULE_STRING ) ) otherlv_6= 'as' this_STRING_7= RULE_STRING otherlv_8= 'from' ( (lv_alias_9_0= RULE_STRING ) ) this_SEMICOLON_10= RULE_SEMICOLON (this_EOLINE_11= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:356:3: (otherlv_4= 'import' ( (lv_name_5_0= RULE_STRING ) ) otherlv_6= 'as' this_STRING_7= RULE_STRING otherlv_8= 'from' ( (lv_alias_9_0= RULE_STRING ) ) this_SEMICOLON_10= RULE_SEMICOLON (this_EOLINE_11= RULE_EOLINE )? )
                    // InternalSM2.g:357:4: otherlv_4= 'import' ( (lv_name_5_0= RULE_STRING ) ) otherlv_6= 'as' this_STRING_7= RULE_STRING otherlv_8= 'from' ( (lv_alias_9_0= RULE_STRING ) ) this_SEMICOLON_10= RULE_SEMICOLON (this_EOLINE_11= RULE_EOLINE )?
                    {
                    otherlv_4=(Token)match(input,48,FOLLOW_10); 

                    				newLeafNode(otherlv_4, grammarAccess.getImportAccess().getImportKeyword_1_0());
                    			
                    // InternalSM2.g:361:4: ( (lv_name_5_0= RULE_STRING ) )
                    // InternalSM2.g:362:5: (lv_name_5_0= RULE_STRING )
                    {
                    // InternalSM2.g:362:5: (lv_name_5_0= RULE_STRING )
                    // InternalSM2.g:363:6: lv_name_5_0= RULE_STRING
                    {
                    lv_name_5_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                    						newLeafNode(lv_name_5_0, grammarAccess.getImportAccess().getNameSTRINGTerminalRuleCall_1_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getImportRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"name",
                    							lv_name_5_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }

                    otherlv_6=(Token)match(input,49,FOLLOW_10); 

                    				newLeafNode(otherlv_6, grammarAccess.getImportAccess().getAsKeyword_1_2());
                    			
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_12); 

                    				newLeafNode(this_STRING_7, grammarAccess.getImportAccess().getSTRINGTerminalRuleCall_1_3());
                    			
                    otherlv_8=(Token)match(input,50,FOLLOW_10); 

                    				newLeafNode(otherlv_8, grammarAccess.getImportAccess().getFromKeyword_1_4());
                    			
                    // InternalSM2.g:391:4: ( (lv_alias_9_0= RULE_STRING ) )
                    // InternalSM2.g:392:5: (lv_alias_9_0= RULE_STRING )
                    {
                    // InternalSM2.g:392:5: (lv_alias_9_0= RULE_STRING )
                    // InternalSM2.g:393:6: lv_alias_9_0= RULE_STRING
                    {
                    lv_alias_9_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

                    						newLeafNode(lv_alias_9_0, grammarAccess.getImportAccess().getAliasSTRINGTerminalRuleCall_1_5_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getImportRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"alias",
                    							lv_alias_9_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }

                    this_SEMICOLON_10=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

                    				newLeafNode(this_SEMICOLON_10, grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_1_6());
                    			
                    // InternalSM2.g:413:4: (this_EOLINE_11= RULE_EOLINE )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==RULE_EOLINE) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // InternalSM2.g:414:5: this_EOLINE_11= RULE_EOLINE
                            {
                            this_EOLINE_11=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                            					newLeafNode(this_EOLINE_11, grammarAccess.getImportAccess().getEOLINETerminalRuleCall_1_7());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:421:3: (otherlv_12= 'import' ( (lv_name_13_0= RULE_STRING ) ) otherlv_14= 'as' ( (lv_alias_15_0= RULE_STRING ) ) this_SEMICOLON_16= RULE_SEMICOLON (this_EOLINE_17= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:421:3: (otherlv_12= 'import' ( (lv_name_13_0= RULE_STRING ) ) otherlv_14= 'as' ( (lv_alias_15_0= RULE_STRING ) ) this_SEMICOLON_16= RULE_SEMICOLON (this_EOLINE_17= RULE_EOLINE )? )
                    // InternalSM2.g:422:4: otherlv_12= 'import' ( (lv_name_13_0= RULE_STRING ) ) otherlv_14= 'as' ( (lv_alias_15_0= RULE_STRING ) ) this_SEMICOLON_16= RULE_SEMICOLON (this_EOLINE_17= RULE_EOLINE )?
                    {
                    otherlv_12=(Token)match(input,48,FOLLOW_10); 

                    				newLeafNode(otherlv_12, grammarAccess.getImportAccess().getImportKeyword_2_0());
                    			
                    // InternalSM2.g:426:4: ( (lv_name_13_0= RULE_STRING ) )
                    // InternalSM2.g:427:5: (lv_name_13_0= RULE_STRING )
                    {
                    // InternalSM2.g:427:5: (lv_name_13_0= RULE_STRING )
                    // InternalSM2.g:428:6: lv_name_13_0= RULE_STRING
                    {
                    lv_name_13_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                    						newLeafNode(lv_name_13_0, grammarAccess.getImportAccess().getNameSTRINGTerminalRuleCall_2_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getImportRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"name",
                    							lv_name_13_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }

                    otherlv_14=(Token)match(input,49,FOLLOW_10); 

                    				newLeafNode(otherlv_14, grammarAccess.getImportAccess().getAsKeyword_2_2());
                    			
                    // InternalSM2.g:448:4: ( (lv_alias_15_0= RULE_STRING ) )
                    // InternalSM2.g:449:5: (lv_alias_15_0= RULE_STRING )
                    {
                    // InternalSM2.g:449:5: (lv_alias_15_0= RULE_STRING )
                    // InternalSM2.g:450:6: lv_alias_15_0= RULE_STRING
                    {
                    lv_alias_15_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

                    						newLeafNode(lv_alias_15_0, grammarAccess.getImportAccess().getAliasSTRINGTerminalRuleCall_2_3_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getImportRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"alias",
                    							lv_alias_15_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }

                    this_SEMICOLON_16=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

                    				newLeafNode(this_SEMICOLON_16, grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_2_4());
                    			
                    // InternalSM2.g:470:4: (this_EOLINE_17= RULE_EOLINE )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==RULE_EOLINE) ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // InternalSM2.g:471:5: this_EOLINE_17= RULE_EOLINE
                            {
                            this_EOLINE_17=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                            					newLeafNode(this_EOLINE_17, grammarAccess.getImportAccess().getEOLINETerminalRuleCall_2_5());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleInterface"
    // InternalSM2.g:481:1: entryRuleInterface returns [EObject current=null] : iv_ruleInterface= ruleInterface EOF ;
    public final EObject entryRuleInterface() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInterface = null;


        try {
            // InternalSM2.g:481:50: (iv_ruleInterface= ruleInterface EOF )
            // InternalSM2.g:482:2: iv_ruleInterface= ruleInterface EOF
            {
             newCompositeNode(grammarAccess.getInterfaceRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInterface=ruleInterface();

            state._fsp--;

             current =iv_ruleInterface; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInterface"


    // $ANTLR start "ruleInterface"
    // InternalSM2.g:488:1: ruleInterface returns [EObject current=null] : (otherlv_0= 'interface' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (otherlv_4= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON this_CLOSEKEY_6= RULE_CLOSEKEY (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleInterface() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_5=null;
        Token this_CLOSEKEY_6=null;
        Token this_EOLINE_7=null;


        	enterRule();

        try {
            // InternalSM2.g:494:2: ( (otherlv_0= 'interface' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (otherlv_4= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON this_CLOSEKEY_6= RULE_CLOSEKEY (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:495:2: (otherlv_0= 'interface' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (otherlv_4= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON this_CLOSEKEY_6= RULE_CLOSEKEY (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:495:2: (otherlv_0= 'interface' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (otherlv_4= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON this_CLOSEKEY_6= RULE_CLOSEKEY (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:496:3: otherlv_0= 'interface' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (otherlv_4= RULE_ID ) ) this_SEMICOLON_5= RULE_SEMICOLON this_CLOSEKEY_6= RULE_CLOSEKEY (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,51,FOLLOW_13); 

            			newLeafNode(otherlv_0, grammarAccess.getInterfaceAccess().getInterfaceKeyword_0());
            		
            // InternalSM2.g:500:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSM2.g:501:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSM2.g:501:4: (lv_name_1_0= RULE_ID )
            // InternalSM2.g:502:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_14); 

            					newLeafNode(lv_name_1_0, grammarAccess.getInterfaceAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInterfaceRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_15); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getInterfaceAccess().getOPENKEYTerminalRuleCall_2());
            		
            // InternalSM2.g:522:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==RULE_EOLINE) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalSM2.g:523:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_13); 

                    				newLeafNode(this_EOLINE_3, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_3());
                    			

                    }
                    break;

            }

            // InternalSM2.g:528:3: ( (otherlv_4= RULE_ID ) )
            // InternalSM2.g:529:4: (otherlv_4= RULE_ID )
            {
            // InternalSM2.g:529:4: (otherlv_4= RULE_ID )
            // InternalSM2.g:530:5: otherlv_4= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getInterfaceRule());
            					}
            				
            otherlv_4=(Token)match(input,RULE_ID,FOLLOW_8); 

            					newLeafNode(otherlv_4, grammarAccess.getInterfaceAccess().getFunctionsClauseCrossReference_4_0());
            				

            }


            }

            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); 

            			newLeafNode(this_SEMICOLON_5, grammarAccess.getInterfaceAccess().getSEMICOLONTerminalRuleCall_5());
            		
            this_CLOSEKEY_6=(Token)match(input,RULE_CLOSEKEY,FOLLOW_9); 

            			newLeafNode(this_CLOSEKEY_6, grammarAccess.getInterfaceAccess().getCLOSEKEYTerminalRuleCall_6());
            		
            // InternalSM2.g:549:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==RULE_EOLINE) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalSM2.g:550:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInterface"


    // $ANTLR start "entryRuleMSGVariables"
    // InternalSM2.g:559:1: entryRuleMSGVariables returns [EObject current=null] : iv_ruleMSGVariables= ruleMSGVariables EOF ;
    public final EObject entryRuleMSGVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMSGVariables = null;


        try {
            // InternalSM2.g:559:53: (iv_ruleMSGVariables= ruleMSGVariables EOF )
            // InternalSM2.g:560:2: iv_ruleMSGVariables= ruleMSGVariables EOF
            {
             newCompositeNode(grammarAccess.getMSGVariablesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMSGVariables=ruleMSGVariables();

            state._fsp--;

             current =iv_ruleMSGVariables; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMSGVariables"


    // $ANTLR start "ruleMSGVariables"
    // InternalSM2.g:566:1: ruleMSGVariables returns [EObject current=null] : (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation ) ;
    public final EObject ruleMSGVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_MSGOperation_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:572:2: ( (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation ) )
            // InternalSM2.g:573:2: (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation )
            {
            // InternalSM2.g:573:2: (otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation )
            // InternalSM2.g:574:3: otherlv_0= 'msg' this_MSGOperation_1= ruleMSGOperation
            {
            otherlv_0=(Token)match(input,52,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getMSGVariablesAccess().getMsgKeyword_0());
            		

            			newCompositeNode(grammarAccess.getMSGVariablesAccess().getMSGOperationParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_MSGOperation_1=ruleMSGOperation();

            state._fsp--;


            			current = this_MSGOperation_1;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMSGVariables"


    // $ANTLR start "entryRuleMSGOperation"
    // InternalSM2.g:590:1: entryRuleMSGOperation returns [EObject current=null] : iv_ruleMSGOperation= ruleMSGOperation EOF ;
    public final EObject entryRuleMSGOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMSGOperation = null;


        try {
            // InternalSM2.g:590:53: (iv_ruleMSGOperation= ruleMSGOperation EOF )
            // InternalSM2.g:591:2: iv_ruleMSGOperation= ruleMSGOperation EOF
            {
             newCompositeNode(grammarAccess.getMSGOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMSGOperation=ruleMSGOperation();

            state._fsp--;

             current =iv_ruleMSGOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMSGOperation"


    // $ANTLR start "ruleMSGOperation"
    // InternalSM2.g:597:1: ruleMSGOperation returns [EObject current=null] : (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? ) ;
    public final EObject ruleMSGOperation() throws RecognitionException {
        EObject current = null;

        Token this_DOT_0=null;
        Token otherlv_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token this_OPENPARENTHESIS_7=null;
        Token this_CLOSEPARENTHESIS_9=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token this_OPENPARENTHESIS_12=null;
        Token this_CLOSEPARENTHESIS_14=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token this_OPENPARENTHESIS_17=null;
        Token this_CLOSEPARENTHESIS_19=null;
        Token otherlv_20=null;
        Token otherlv_21=null;
        Token this_OPENPARENTHESIS_22=null;
        Token this_CLOSEPARENTHESIS_24=null;
        Token otherlv_25=null;
        Token this_SEMICOLON_26=null;
        Token this_EOLINE_27=null;


        	enterRule();

        try {
            // InternalSM2.g:603:2: ( (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? ) )
            // InternalSM2.g:604:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? )
            {
            // InternalSM2.g:604:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )? )
            // InternalSM2.g:605:3: this_DOT_0= RULE_DOT ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) ) (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )?
            {
            this_DOT_0=(Token)match(input,RULE_DOT,FOLLOW_18); 

            			newLeafNode(this_DOT_0, grammarAccess.getMSGOperationAccess().getDOTTerminalRuleCall_0());
            		
            // InternalSM2.g:609:3: ( ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' ) | ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' ) | ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' ) | ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' ) | ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' ) )
            int alt19=5;
            switch ( input.LA(1) ) {
            case 53:
                {
                alt19=1;
                }
                break;
            case 54:
                {
                alt19=2;
                }
                break;
            case 55:
                {
                alt19=3;
                }
                break;
            case 56:
                {
                alt19=4;
                }
                break;
            case 57:
                {
                alt19=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }

            switch (alt19) {
                case 1 :
                    // InternalSM2.g:610:4: ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' )
                    {
                    // InternalSM2.g:610:4: ( (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'data' )
                    int alt14=2;
                    int LA14_0 = input.LA(1);

                    if ( (LA14_0==53) ) {
                        int LA14_1 = input.LA(2);

                        if ( (LA14_1==RULE_OPENPARENTHESIS) ) {
                            alt14=1;
                        }
                        else if ( (LA14_1==EOF||LA14_1==RULE_SEMICOLON) ) {
                            alt14=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 14, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 14, 0, input);

                        throw nvae;
                    }
                    switch (alt14) {
                        case 1 :
                            // InternalSM2.g:611:5: (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:611:5: (otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:612:6: otherlv_1= 'data' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_1=(Token)match(input,53,FOLLOW_19); 

                            						newLeafNode(otherlv_1, grammarAccess.getMSGOperationAccess().getDataKeyword_1_0_0_0());
                            					
                            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

                            						newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_0_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_0_0_2());
                            					
                            pushFollow(FOLLOW_21);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_22); 

                            						newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:633:5: otherlv_5= 'data'
                            {
                            otherlv_5=(Token)match(input,53,FOLLOW_22); 

                            					newLeafNode(otherlv_5, grammarAccess.getMSGOperationAccess().getDataKeyword_1_0_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:639:4: ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' )
                    {
                    // InternalSM2.g:639:4: ( (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'value' )
                    int alt15=2;
                    int LA15_0 = input.LA(1);

                    if ( (LA15_0==54) ) {
                        int LA15_1 = input.LA(2);

                        if ( (LA15_1==RULE_OPENPARENTHESIS) ) {
                            alt15=1;
                        }
                        else if ( (LA15_1==EOF||LA15_1==RULE_SEMICOLON) ) {
                            alt15=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 15, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 15, 0, input);

                        throw nvae;
                    }
                    switch (alt15) {
                        case 1 :
                            // InternalSM2.g:640:5: (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:640:5: (otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:641:6: otherlv_6= 'value' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_6=(Token)match(input,54,FOLLOW_19); 

                            						newLeafNode(otherlv_6, grammarAccess.getMSGOperationAccess().getValueKeyword_1_1_0_0());
                            					
                            this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

                            						newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_1_0_2());
                            					
                            pushFollow(FOLLOW_21);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_9=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_22); 

                            						newLeafNode(this_CLOSEPARENTHESIS_9, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:662:5: otherlv_10= 'value'
                            {
                            otherlv_10=(Token)match(input,54,FOLLOW_22); 

                            					newLeafNode(otherlv_10, grammarAccess.getMSGOperationAccess().getValueKeyword_1_1_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:668:4: ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' )
                    {
                    // InternalSM2.g:668:4: ( (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS ) | otherlv_15= 'gas' )
                    int alt16=2;
                    int LA16_0 = input.LA(1);

                    if ( (LA16_0==55) ) {
                        int LA16_1 = input.LA(2);

                        if ( (LA16_1==EOF||LA16_1==RULE_SEMICOLON) ) {
                            alt16=2;
                        }
                        else if ( (LA16_1==RULE_OPENPARENTHESIS) ) {
                            alt16=1;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 16, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 16, 0, input);

                        throw nvae;
                    }
                    switch (alt16) {
                        case 1 :
                            // InternalSM2.g:669:5: (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:669:5: (otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:670:6: otherlv_11= 'gas' this_OPENPARENTHESIS_12= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_14= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_11=(Token)match(input,55,FOLLOW_19); 

                            						newLeafNode(otherlv_11, grammarAccess.getMSGOperationAccess().getGasKeyword_1_2_0_0());
                            					
                            this_OPENPARENTHESIS_12=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

                            						newLeafNode(this_OPENPARENTHESIS_12, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_2_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_2_0_2());
                            					
                            pushFollow(FOLLOW_21);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_14=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_22); 

                            						newLeafNode(this_CLOSEPARENTHESIS_14, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_2_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:691:5: otherlv_15= 'gas'
                            {
                            otherlv_15=(Token)match(input,55,FOLLOW_22); 

                            					newLeafNode(otherlv_15, grammarAccess.getMSGOperationAccess().getGasKeyword_1_2_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:697:4: ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' )
                    {
                    // InternalSM2.g:697:4: ( (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS ) | otherlv_20= 'sender' )
                    int alt17=2;
                    int LA17_0 = input.LA(1);

                    if ( (LA17_0==56) ) {
                        int LA17_1 = input.LA(2);

                        if ( (LA17_1==RULE_OPENPARENTHESIS) ) {
                            alt17=1;
                        }
                        else if ( (LA17_1==EOF||LA17_1==RULE_SEMICOLON) ) {
                            alt17=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 17, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 17, 0, input);

                        throw nvae;
                    }
                    switch (alt17) {
                        case 1 :
                            // InternalSM2.g:698:5: (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:698:5: (otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:699:6: otherlv_16= 'sender' this_OPENPARENTHESIS_17= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_19= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_16=(Token)match(input,56,FOLLOW_19); 

                            						newLeafNode(otherlv_16, grammarAccess.getMSGOperationAccess().getSenderKeyword_1_3_0_0());
                            					
                            this_OPENPARENTHESIS_17=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

                            						newLeafNode(this_OPENPARENTHESIS_17, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_3_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_3_0_2());
                            					
                            pushFollow(FOLLOW_21);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_19=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_22); 

                            						newLeafNode(this_CLOSEPARENTHESIS_19, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:720:5: otherlv_20= 'sender'
                            {
                            otherlv_20=(Token)match(input,56,FOLLOW_22); 

                            					newLeafNode(otherlv_20, grammarAccess.getMSGOperationAccess().getSenderKeyword_1_3_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:726:4: ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' )
                    {
                    // InternalSM2.g:726:4: ( (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS ) | otherlv_25= 'sig' )
                    int alt18=2;
                    int LA18_0 = input.LA(1);

                    if ( (LA18_0==57) ) {
                        int LA18_1 = input.LA(2);

                        if ( (LA18_1==RULE_OPENPARENTHESIS) ) {
                            alt18=1;
                        }
                        else if ( (LA18_1==EOF||LA18_1==RULE_SEMICOLON) ) {
                            alt18=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 18, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 18, 0, input);

                        throw nvae;
                    }
                    switch (alt18) {
                        case 1 :
                            // InternalSM2.g:727:5: (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:727:5: (otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:728:6: otherlv_21= 'sig' this_OPENPARENTHESIS_22= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_24= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_21=(Token)match(input,57,FOLLOW_19); 

                            						newLeafNode(otherlv_21, grammarAccess.getMSGOperationAccess().getSigKeyword_1_4_0_0());
                            					
                            this_OPENPARENTHESIS_22=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

                            						newLeafNode(this_OPENPARENTHESIS_22, grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_4_0_1());
                            					

                            						newCompositeNode(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_4_0_2());
                            					
                            pushFollow(FOLLOW_21);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_24=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_22); 

                            						newLeafNode(this_CLOSEPARENTHESIS_24, grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_4_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:749:5: otherlv_25= 'sig'
                            {
                            otherlv_25=(Token)match(input,57,FOLLOW_22); 

                            					newLeafNode(otherlv_25, grammarAccess.getMSGOperationAccess().getSigKeyword_1_4_1());
                            				

                            }
                            break;

                    }


                    }
                    break;

            }

            // InternalSM2.g:755:3: (this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==RULE_SEMICOLON) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalSM2.g:756:4: this_SEMICOLON_26= RULE_SEMICOLON this_EOLINE_27= RULE_EOLINE
                    {
                    this_SEMICOLON_26=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); 

                    				newLeafNode(this_SEMICOLON_26, grammarAccess.getMSGOperationAccess().getSEMICOLONTerminalRuleCall_2_0());
                    			
                    this_EOLINE_27=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_27, grammarAccess.getMSGOperationAccess().getEOLINETerminalRuleCall_2_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMSGOperation"


    // $ANTLR start "entryRuleBlockVariables"
    // InternalSM2.g:769:1: entryRuleBlockVariables returns [EObject current=null] : iv_ruleBlockVariables= ruleBlockVariables EOF ;
    public final EObject entryRuleBlockVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBlockVariables = null;


        try {
            // InternalSM2.g:769:55: (iv_ruleBlockVariables= ruleBlockVariables EOF )
            // InternalSM2.g:770:2: iv_ruleBlockVariables= ruleBlockVariables EOF
            {
             newCompositeNode(grammarAccess.getBlockVariablesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBlockVariables=ruleBlockVariables();

            state._fsp--;

             current =iv_ruleBlockVariables; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBlockVariables"


    // $ANTLR start "ruleBlockVariables"
    // InternalSM2.g:776:1: ruleBlockVariables returns [EObject current=null] : (otherlv_0= 'block' this_BlockOperation_1= ruleBlockOperation ) ;
    public final EObject ruleBlockVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_BlockOperation_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:782:2: ( (otherlv_0= 'block' this_BlockOperation_1= ruleBlockOperation ) )
            // InternalSM2.g:783:2: (otherlv_0= 'block' this_BlockOperation_1= ruleBlockOperation )
            {
            // InternalSM2.g:783:2: (otherlv_0= 'block' this_BlockOperation_1= ruleBlockOperation )
            // InternalSM2.g:784:3: otherlv_0= 'block' this_BlockOperation_1= ruleBlockOperation
            {
            otherlv_0=(Token)match(input,58,FOLLOW_24); 

            			newLeafNode(otherlv_0, grammarAccess.getBlockVariablesAccess().getBlockKeyword_0());
            		

            			newCompositeNode(grammarAccess.getBlockVariablesAccess().getBlockOperationParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_BlockOperation_1=ruleBlockOperation();

            state._fsp--;


            			current = this_BlockOperation_1;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBlockVariables"


    // $ANTLR start "entryRuleBlockOperation"
    // InternalSM2.g:800:1: entryRuleBlockOperation returns [EObject current=null] : iv_ruleBlockOperation= ruleBlockOperation EOF ;
    public final EObject entryRuleBlockOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBlockOperation = null;


        try {
            // InternalSM2.g:800:55: (iv_ruleBlockOperation= ruleBlockOperation EOF )
            // InternalSM2.g:801:2: iv_ruleBlockOperation= ruleBlockOperation EOF
            {
             newCompositeNode(grammarAccess.getBlockOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBlockOperation=ruleBlockOperation();

            state._fsp--;

             current =iv_ruleBlockOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBlockOperation"


    // $ANTLR start "ruleBlockOperation"
    // InternalSM2.g:807:1: ruleBlockOperation returns [EObject current=null] : ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? ) ) ;
    public final EObject ruleBlockOperation() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_DOT_1=null;
        Token otherlv_2=null;
        Token this_OPENPARENTHESIS_3=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token this_OPENPARENTHESIS_8=null;
        Token this_CLOSEPARENTHESIS_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token this_OPENPARENTHESIS_13=null;
        Token this_CLOSEPARENTHESIS_15=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token this_OPENPARENTHESIS_18=null;
        Token this_CLOSEPARENTHESIS_20=null;
        Token otherlv_21=null;
        Token otherlv_22=null;
        Token this_OPENPARENTHESIS_23=null;
        Token this_CLOSEPARENTHESIS_25=null;
        Token otherlv_26=null;
        Token otherlv_27=null;
        Token this_OPENPARENTHESIS_28=null;
        Token this_CLOSEPARENTHESIS_30=null;
        Token otherlv_31=null;
        Token otherlv_32=null;
        Token this_OPENPARENTHESIS_33=null;
        Token this_CLOSEPARENTHESIS_35=null;
        Token this_SEMICOLON_36=null;


        	enterRule();

        try {
            // InternalSM2.g:813:2: ( ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? ) ) )
            // InternalSM2.g:814:2: ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? ) )
            {
            // InternalSM2.g:814:2: ( (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) ) | (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? ) )
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==58) ) {
                alt29=1;
            }
            else if ( (LA29_0==65) ) {
                alt29=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 29, 0, input);

                throw nvae;
            }
            switch (alt29) {
                case 1 :
                    // InternalSM2.g:815:3: (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) )
                    {
                    // InternalSM2.g:815:3: (otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) ) )
                    // InternalSM2.g:816:4: otherlv_0= 'block' this_DOT_1= RULE_DOT ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) )
                    {
                    otherlv_0=(Token)match(input,58,FOLLOW_17); 

                    				newLeafNode(otherlv_0, grammarAccess.getBlockOperationAccess().getBlockKeyword_0_0());
                    			
                    this_DOT_1=(Token)match(input,RULE_DOT,FOLLOW_25); 

                    				newLeafNode(this_DOT_1, grammarAccess.getBlockOperationAccess().getDOTTerminalRuleCall_0_1());
                    			
                    // InternalSM2.g:824:4: ( ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' ) | ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' ) | ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' ) | ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' ) | ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' ) | ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' ) )
                    int alt27=6;
                    switch ( input.LA(1) ) {
                    case 59:
                        {
                        alt27=1;
                        }
                        break;
                    case 60:
                        {
                        alt27=2;
                        }
                        break;
                    case 61:
                        {
                        alt27=3;
                        }
                        break;
                    case 62:
                        {
                        alt27=4;
                        }
                        break;
                    case 63:
                        {
                        alt27=5;
                        }
                        break;
                    case 64:
                        {
                        alt27=6;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 27, 0, input);

                        throw nvae;
                    }

                    switch (alt27) {
                        case 1 :
                            // InternalSM2.g:825:5: ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' )
                            {
                            // InternalSM2.g:825:5: ( (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ) | otherlv_6= 'difficulty' )
                            int alt21=2;
                            int LA21_0 = input.LA(1);

                            if ( (LA21_0==59) ) {
                                int LA21_1 = input.LA(2);

                                if ( (LA21_1==RULE_OPENPARENTHESIS) ) {
                                    alt21=1;
                                }
                                else if ( (LA21_1==EOF) ) {
                                    alt21=2;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 21, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 21, 0, input);

                                throw nvae;
                            }
                            switch (alt21) {
                                case 1 :
                                    // InternalSM2.g:826:6: (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:826:6: (otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:827:7: otherlv_2= 'difficulty' this_OPENPARENTHESIS_3= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_2=(Token)match(input,59,FOLLOW_19); 

                                    							newLeafNode(otherlv_2, grammarAccess.getBlockOperationAccess().getDifficultyKeyword_0_2_0_0_0());
                                    						
                                    this_OPENPARENTHESIS_3=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

                                    							newLeafNode(this_OPENPARENTHESIS_3, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_0_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_0_0_2());
                                    						
                                    pushFollow(FOLLOW_21);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_0_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:848:6: otherlv_6= 'difficulty'
                                    {
                                    otherlv_6=(Token)match(input,59,FOLLOW_2); 

                                    						newLeafNode(otherlv_6, grammarAccess.getBlockOperationAccess().getDifficultyKeyword_0_2_0_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:854:5: ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' )
                            {
                            // InternalSM2.g:854:5: ( (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) | otherlv_11= 'number' )
                            int alt22=2;
                            int LA22_0 = input.LA(1);

                            if ( (LA22_0==60) ) {
                                int LA22_1 = input.LA(2);

                                if ( (LA22_1==RULE_OPENPARENTHESIS) ) {
                                    alt22=1;
                                }
                                else if ( (LA22_1==EOF) ) {
                                    alt22=2;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 22, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 22, 0, input);

                                throw nvae;
                            }
                            switch (alt22) {
                                case 1 :
                                    // InternalSM2.g:855:6: (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:855:6: (otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:856:7: otherlv_7= 'number' this_OPENPARENTHESIS_8= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_7=(Token)match(input,60,FOLLOW_19); 

                                    							newLeafNode(otherlv_7, grammarAccess.getBlockOperationAccess().getNumberKeyword_0_2_1_0_0());
                                    						
                                    this_OPENPARENTHESIS_8=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

                                    							newLeafNode(this_OPENPARENTHESIS_8, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_1_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_1_0_2());
                                    						
                                    pushFollow(FOLLOW_21);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_10=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_10, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_1_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:877:6: otherlv_11= 'number'
                                    {
                                    otherlv_11=(Token)match(input,60,FOLLOW_2); 

                                    						newLeafNode(otherlv_11, grammarAccess.getBlockOperationAccess().getNumberKeyword_0_2_1_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 3 :
                            // InternalSM2.g:883:5: ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' )
                            {
                            // InternalSM2.g:883:5: ( (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS ) | otherlv_16= 'timestamp' )
                            int alt23=2;
                            int LA23_0 = input.LA(1);

                            if ( (LA23_0==61) ) {
                                int LA23_1 = input.LA(2);

                                if ( (LA23_1==EOF) ) {
                                    alt23=2;
                                }
                                else if ( (LA23_1==RULE_OPENPARENTHESIS) ) {
                                    alt23=1;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 23, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 23, 0, input);

                                throw nvae;
                            }
                            switch (alt23) {
                                case 1 :
                                    // InternalSM2.g:884:6: (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:884:6: (otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:885:7: otherlv_12= 'timestamp' this_OPENPARENTHESIS_13= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_12=(Token)match(input,61,FOLLOW_19); 

                                    							newLeafNode(otherlv_12, grammarAccess.getBlockOperationAccess().getTimestampKeyword_0_2_2_0_0());
                                    						
                                    this_OPENPARENTHESIS_13=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

                                    							newLeafNode(this_OPENPARENTHESIS_13, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_2_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_2_0_2());
                                    						
                                    pushFollow(FOLLOW_21);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_15=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_15, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_2_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:906:6: otherlv_16= 'timestamp'
                                    {
                                    otherlv_16=(Token)match(input,61,FOLLOW_2); 

                                    						newLeafNode(otherlv_16, grammarAccess.getBlockOperationAccess().getTimestampKeyword_0_2_2_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 4 :
                            // InternalSM2.g:912:5: ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' )
                            {
                            // InternalSM2.g:912:5: ( (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS ) | otherlv_21= 'coinbase' )
                            int alt24=2;
                            int LA24_0 = input.LA(1);

                            if ( (LA24_0==62) ) {
                                int LA24_1 = input.LA(2);

                                if ( (LA24_1==RULE_OPENPARENTHESIS) ) {
                                    alt24=1;
                                }
                                else if ( (LA24_1==EOF) ) {
                                    alt24=2;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 24, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 24, 0, input);

                                throw nvae;
                            }
                            switch (alt24) {
                                case 1 :
                                    // InternalSM2.g:913:6: (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:913:6: (otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:914:7: otherlv_17= 'coinbase' this_OPENPARENTHESIS_18= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_20= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_17=(Token)match(input,62,FOLLOW_19); 

                                    							newLeafNode(otherlv_17, grammarAccess.getBlockOperationAccess().getCoinbaseKeyword_0_2_3_0_0());
                                    						
                                    this_OPENPARENTHESIS_18=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

                                    							newLeafNode(this_OPENPARENTHESIS_18, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_3_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_3_0_2());
                                    						
                                    pushFollow(FOLLOW_21);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_20=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_20, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_3_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:935:6: otherlv_21= 'coinbase'
                                    {
                                    otherlv_21=(Token)match(input,62,FOLLOW_2); 

                                    						newLeafNode(otherlv_21, grammarAccess.getBlockOperationAccess().getCoinbaseKeyword_0_2_3_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 5 :
                            // InternalSM2.g:941:5: ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' )
                            {
                            // InternalSM2.g:941:5: ( (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS ) | otherlv_26= 'gaslimit' )
                            int alt25=2;
                            int LA25_0 = input.LA(1);

                            if ( (LA25_0==63) ) {
                                int LA25_1 = input.LA(2);

                                if ( (LA25_1==RULE_OPENPARENTHESIS) ) {
                                    alt25=1;
                                }
                                else if ( (LA25_1==EOF) ) {
                                    alt25=2;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 25, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 25, 0, input);

                                throw nvae;
                            }
                            switch (alt25) {
                                case 1 :
                                    // InternalSM2.g:942:6: (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:942:6: (otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:943:7: otherlv_22= 'gaslimit' this_OPENPARENTHESIS_23= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_25= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_22=(Token)match(input,63,FOLLOW_19); 

                                    							newLeafNode(otherlv_22, grammarAccess.getBlockOperationAccess().getGaslimitKeyword_0_2_4_0_0());
                                    						
                                    this_OPENPARENTHESIS_23=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

                                    							newLeafNode(this_OPENPARENTHESIS_23, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_4_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_4_0_2());
                                    						
                                    pushFollow(FOLLOW_21);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_25=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_25, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_4_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:964:6: otherlv_26= 'gaslimit'
                                    {
                                    otherlv_26=(Token)match(input,63,FOLLOW_2); 

                                    						newLeafNode(otherlv_26, grammarAccess.getBlockOperationAccess().getGaslimitKeyword_0_2_4_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;
                        case 6 :
                            // InternalSM2.g:970:5: ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' )
                            {
                            // InternalSM2.g:970:5: ( (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS ) | otherlv_31= 'blockhash' )
                            int alt26=2;
                            int LA26_0 = input.LA(1);

                            if ( (LA26_0==64) ) {
                                int LA26_1 = input.LA(2);

                                if ( (LA26_1==EOF) ) {
                                    alt26=2;
                                }
                                else if ( (LA26_1==RULE_OPENPARENTHESIS) ) {
                                    alt26=1;
                                }
                                else {
                                    NoViableAltException nvae =
                                        new NoViableAltException("", 26, 1, input);

                                    throw nvae;
                                }
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 26, 0, input);

                                throw nvae;
                            }
                            switch (alt26) {
                                case 1 :
                                    // InternalSM2.g:971:6: (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS )
                                    {
                                    // InternalSM2.g:971:6: (otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS )
                                    // InternalSM2.g:972:7: otherlv_27= 'blockhash' this_OPENPARENTHESIS_28= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_30= RULE_CLOSEPARENTHESIS
                                    {
                                    otherlv_27=(Token)match(input,64,FOLLOW_19); 

                                    							newLeafNode(otherlv_27, grammarAccess.getBlockOperationAccess().getBlockhashKeyword_0_2_5_0_0());
                                    						
                                    this_OPENPARENTHESIS_28=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

                                    							newLeafNode(this_OPENPARENTHESIS_28, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_0_2_5_0_1());
                                    						

                                    							newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_0_2_5_0_2());
                                    						
                                    pushFollow(FOLLOW_21);
                                    ruleExpression();

                                    state._fsp--;


                                    							afterParserOrEnumRuleCall();
                                    						
                                    this_CLOSEPARENTHESIS_30=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                                    							newLeafNode(this_CLOSEPARENTHESIS_30, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_0_2_5_0_3());
                                    						

                                    }


                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:993:6: otherlv_31= 'blockhash'
                                    {
                                    otherlv_31=(Token)match(input,64,FOLLOW_2); 

                                    						newLeafNode(otherlv_31, grammarAccess.getBlockOperationAccess().getBlockhashKeyword_0_2_5_1());
                                    					

                                    }
                                    break;

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1001:3: (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:1001:3: (otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )? )
                    // InternalSM2.g:1002:4: otherlv_32= 'now' this_OPENPARENTHESIS_33= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_35= RULE_CLOSEPARENTHESIS (this_SEMICOLON_36= RULE_SEMICOLON )?
                    {
                    otherlv_32=(Token)match(input,65,FOLLOW_19); 

                    				newLeafNode(otherlv_32, grammarAccess.getBlockOperationAccess().getNowKeyword_1_0());
                    			
                    this_OPENPARENTHESIS_33=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

                    				newLeafNode(this_OPENPARENTHESIS_33, grammarAccess.getBlockOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1());
                    			

                    				newCompositeNode(grammarAccess.getBlockOperationAccess().getExpressionParserRuleCall_1_2());
                    			
                    pushFollow(FOLLOW_21);
                    ruleExpression();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			
                    this_CLOSEPARENTHESIS_35=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_22); 

                    				newLeafNode(this_CLOSEPARENTHESIS_35, grammarAccess.getBlockOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3());
                    			
                    // InternalSM2.g:1021:4: (this_SEMICOLON_36= RULE_SEMICOLON )?
                    int alt28=2;
                    int LA28_0 = input.LA(1);

                    if ( (LA28_0==RULE_SEMICOLON) ) {
                        alt28=1;
                    }
                    switch (alt28) {
                        case 1 :
                            // InternalSM2.g:1022:5: this_SEMICOLON_36= RULE_SEMICOLON
                            {
                            this_SEMICOLON_36=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_36, grammarAccess.getBlockOperationAccess().getSEMICOLONTerminalRuleCall_1_4());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBlockOperation"


    // $ANTLR start "entryRuleTxVariables"
    // InternalSM2.g:1032:1: entryRuleTxVariables returns [EObject current=null] : iv_ruleTxVariables= ruleTxVariables EOF ;
    public final EObject entryRuleTxVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTxVariables = null;


        try {
            // InternalSM2.g:1032:52: (iv_ruleTxVariables= ruleTxVariables EOF )
            // InternalSM2.g:1033:2: iv_ruleTxVariables= ruleTxVariables EOF
            {
             newCompositeNode(grammarAccess.getTxVariablesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTxVariables=ruleTxVariables();

            state._fsp--;

             current =iv_ruleTxVariables; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTxVariables"


    // $ANTLR start "ruleTxVariables"
    // InternalSM2.g:1039:1: ruleTxVariables returns [EObject current=null] : (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation ) ;
    public final EObject ruleTxVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_TxOperation_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1045:2: ( (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation ) )
            // InternalSM2.g:1046:2: (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation )
            {
            // InternalSM2.g:1046:2: (otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation )
            // InternalSM2.g:1047:3: otherlv_0= 'tx' this_TxOperation_1= ruleTxOperation
            {
            otherlv_0=(Token)match(input,66,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getTxVariablesAccess().getTxKeyword_0());
            		

            			newCompositeNode(grammarAccess.getTxVariablesAccess().getTxOperationParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_TxOperation_1=ruleTxOperation();

            state._fsp--;


            			current = this_TxOperation_1;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTxVariables"


    // $ANTLR start "entryRuleTxOperation"
    // InternalSM2.g:1063:1: entryRuleTxOperation returns [EObject current=null] : iv_ruleTxOperation= ruleTxOperation EOF ;
    public final EObject entryRuleTxOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTxOperation = null;


        try {
            // InternalSM2.g:1063:52: (iv_ruleTxOperation= ruleTxOperation EOF )
            // InternalSM2.g:1064:2: iv_ruleTxOperation= ruleTxOperation EOF
            {
             newCompositeNode(grammarAccess.getTxOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTxOperation=ruleTxOperation();

            state._fsp--;

             current =iv_ruleTxOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTxOperation"


    // $ANTLR start "ruleTxOperation"
    // InternalSM2.g:1070:1: ruleTxOperation returns [EObject current=null] : (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? ) ;
    public final EObject ruleTxOperation() throws RecognitionException {
        EObject current = null;

        Token this_DOT_0=null;
        Token otherlv_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token this_OPENPARENTHESIS_7=null;
        Token this_CLOSEPARENTHESIS_9=null;
        Token otherlv_10=null;
        Token this_SEMICOLON_11=null;
        Token this_EOLINE_12=null;


        	enterRule();

        try {
            // InternalSM2.g:1076:2: ( (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? ) )
            // InternalSM2.g:1077:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? )
            {
            // InternalSM2.g:1077:2: (this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )? )
            // InternalSM2.g:1078:3: this_DOT_0= RULE_DOT ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' ) (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )?
            {
            this_DOT_0=(Token)match(input,RULE_DOT,FOLLOW_26); 

            			newLeafNode(this_DOT_0, grammarAccess.getTxOperationAccess().getDOTTerminalRuleCall_0());
            		
            // InternalSM2.g:1082:3: ( ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' ) | ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) | otherlv_10= 'origin' )
            int alt31=3;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==67) ) {
                alt31=1;
            }
            else if ( (LA31_0==68) ) {
                int LA31_2 = input.LA(2);

                if ( (LA31_2==EOF||LA31_2==RULE_SEMICOLON) ) {
                    alt31=3;
                }
                else if ( (LA31_2==RULE_OPENPARENTHESIS) ) {
                    alt31=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 31, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 31, 0, input);

                throw nvae;
            }
            switch (alt31) {
                case 1 :
                    // InternalSM2.g:1083:4: ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' )
                    {
                    // InternalSM2.g:1083:4: ( (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | otherlv_5= 'gasprice' )
                    int alt30=2;
                    int LA30_0 = input.LA(1);

                    if ( (LA30_0==67) ) {
                        int LA30_1 = input.LA(2);

                        if ( (LA30_1==RULE_OPENPARENTHESIS) ) {
                            alt30=1;
                        }
                        else if ( (LA30_1==EOF||LA30_1==RULE_SEMICOLON) ) {
                            alt30=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 30, 1, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 30, 0, input);

                        throw nvae;
                    }
                    switch (alt30) {
                        case 1 :
                            // InternalSM2.g:1084:5: (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            {
                            // InternalSM2.g:1084:5: (otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                            // InternalSM2.g:1085:6: otherlv_1= 'gasprice' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                            {
                            otherlv_1=(Token)match(input,67,FOLLOW_19); 

                            						newLeafNode(otherlv_1, grammarAccess.getTxOperationAccess().getGaspriceKeyword_1_0_0_0());
                            					
                            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

                            						newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getTxOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_0_0_1());
                            					

                            						newCompositeNode(grammarAccess.getTxOperationAccess().getExpressionParserRuleCall_1_0_0_2());
                            					
                            pushFollow(FOLLOW_21);
                            ruleExpression();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_22); 

                            						newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getTxOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_0_3());
                            					

                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:1106:5: otherlv_5= 'gasprice'
                            {
                            otherlv_5=(Token)match(input,67,FOLLOW_22); 

                            					newLeafNode(otherlv_5, grammarAccess.getTxOperationAccess().getGaspriceKeyword_1_0_1());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1112:4: ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:1112:4: ( (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:1113:5: (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression ) this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS
                    {
                    // InternalSM2.g:1113:5: (otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression )
                    // InternalSM2.g:1114:6: otherlv_6= 'origin' this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS ruleExpression
                    {
                    otherlv_6=(Token)match(input,68,FOLLOW_19); 

                    						newLeafNode(otherlv_6, grammarAccess.getTxOperationAccess().getOriginKeyword_1_1_0_0());
                    					
                    this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

                    						newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getTxOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1_0_1());
                    					

                    						newCompositeNode(grammarAccess.getTxOperationAccess().getExpressionParserRuleCall_1_1_0_2());
                    					
                    pushFollow(FOLLOW_21);
                    ruleExpression();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }

                    this_CLOSEPARENTHESIS_9=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_22); 

                    					newLeafNode(this_CLOSEPARENTHESIS_9, grammarAccess.getTxOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_1());
                    				

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1136:4: otherlv_10= 'origin'
                    {
                    otherlv_10=(Token)match(input,68,FOLLOW_22); 

                    				newLeafNode(otherlv_10, grammarAccess.getTxOperationAccess().getOriginKeyword_1_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:1141:3: (this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==RULE_SEMICOLON) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalSM2.g:1142:4: this_SEMICOLON_11= RULE_SEMICOLON this_EOLINE_12= RULE_EOLINE
                    {
                    this_SEMICOLON_11=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); 

                    				newLeafNode(this_SEMICOLON_11, grammarAccess.getTxOperationAccess().getSEMICOLONTerminalRuleCall_2_0());
                    			
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_12, grammarAccess.getTxOperationAccess().getEOLINETerminalRuleCall_2_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTxOperation"


    // $ANTLR start "entryRuleThisVariables"
    // InternalSM2.g:1155:1: entryRuleThisVariables returns [EObject current=null] : iv_ruleThisVariables= ruleThisVariables EOF ;
    public final EObject entryRuleThisVariables() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleThisVariables = null;


        try {
            // InternalSM2.g:1155:54: (iv_ruleThisVariables= ruleThisVariables EOF )
            // InternalSM2.g:1156:2: iv_ruleThisVariables= ruleThisVariables EOF
            {
             newCompositeNode(grammarAccess.getThisVariablesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleThisVariables=ruleThisVariables();

            state._fsp--;

             current =iv_ruleThisVariables; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleThisVariables"


    // $ANTLR start "ruleThisVariables"
    // InternalSM2.g:1162:1: ruleThisVariables returns [EObject current=null] : (otherlv_0= 'this' this_ThisOperation_1= ruleThisOperation ) ;
    public final EObject ruleThisVariables() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject this_ThisOperation_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1168:2: ( (otherlv_0= 'this' this_ThisOperation_1= ruleThisOperation ) )
            // InternalSM2.g:1169:2: (otherlv_0= 'this' this_ThisOperation_1= ruleThisOperation )
            {
            // InternalSM2.g:1169:2: (otherlv_0= 'this' this_ThisOperation_1= ruleThisOperation )
            // InternalSM2.g:1170:3: otherlv_0= 'this' this_ThisOperation_1= ruleThisOperation
            {
            otherlv_0=(Token)match(input,69,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getThisVariablesAccess().getThisKeyword_0());
            		

            			newCompositeNode(grammarAccess.getThisVariablesAccess().getThisOperationParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_ThisOperation_1=ruleThisOperation();

            state._fsp--;


            			current = this_ThisOperation_1;
            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleThisVariables"


    // $ANTLR start "entryRuleThisOperation"
    // InternalSM2.g:1186:1: entryRuleThisOperation returns [EObject current=null] : iv_ruleThisOperation= ruleThisOperation EOF ;
    public final EObject entryRuleThisOperation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleThisOperation = null;


        try {
            // InternalSM2.g:1186:54: (iv_ruleThisOperation= ruleThisOperation EOF )
            // InternalSM2.g:1187:2: iv_ruleThisOperation= ruleThisOperation EOF
            {
             newCompositeNode(grammarAccess.getThisOperationRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleThisOperation=ruleThisOperation();

            state._fsp--;

             current =iv_ruleThisOperation; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleThisOperation"


    // $ANTLR start "ruleThisOperation"
    // InternalSM2.g:1193:1: ruleThisOperation returns [EObject current=null] : (this_DOT_0= RULE_DOT otherlv_1= 'balance' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject ruleThisOperation() throws RecognitionException {
        EObject current = null;

        Token this_DOT_0=null;
        Token otherlv_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;


        	enterRule();

        try {
            // InternalSM2.g:1199:2: ( (this_DOT_0= RULE_DOT otherlv_1= 'balance' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1200:2: (this_DOT_0= RULE_DOT otherlv_1= 'balance' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1200:2: (this_DOT_0= RULE_DOT otherlv_1= 'balance' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1201:3: this_DOT_0= RULE_DOT otherlv_1= 'balance' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ruleExpression this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE )?
            {
            this_DOT_0=(Token)match(input,RULE_DOT,FOLLOW_27); 

            			newLeafNode(this_DOT_0, grammarAccess.getThisOperationAccess().getDOTTerminalRuleCall_0());
            		
            otherlv_1=(Token)match(input,70,FOLLOW_19); 

            			newLeafNode(otherlv_1, grammarAccess.getThisOperationAccess().getBalanceKeyword_1());
            		
            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getThisOperationAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		

            			newCompositeNode(grammarAccess.getThisOperationAccess().getExpressionParserRuleCall_3());
            		
            pushFollow(FOLLOW_21);
            ruleExpression();

            state._fsp--;


            			afterParserOrEnumRuleCall();
            		
            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_22); 

            			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getThisOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
            		
            // InternalSM2.g:1224:3: (this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==RULE_SEMICOLON) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // InternalSM2.g:1225:4: this_SEMICOLON_5= RULE_SEMICOLON this_EOLINE_6= RULE_EOLINE
                    {
                    this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); 

                    				newLeafNode(this_SEMICOLON_5, grammarAccess.getThisOperationAccess().getSEMICOLONTerminalRuleCall_5_0());
                    			
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_6, grammarAccess.getThisOperationAccess().getEOLINETerminalRuleCall_5_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleThisOperation"


    // $ANTLR start "entryRuleContract"
    // InternalSM2.g:1238:1: entryRuleContract returns [EObject current=null] : iv_ruleContract= ruleContract EOF ;
    public final EObject entryRuleContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleContract = null;


        try {
            // InternalSM2.g:1238:49: (iv_ruleContract= ruleContract EOF )
            // InternalSM2.g:1239:2: iv_ruleContract= ruleContract EOF
            {
             newCompositeNode(grammarAccess.getContractRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleContract=ruleContract();

            state._fsp--;

             current =iv_ruleContract; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleContract"


    // $ANTLR start "ruleContract"
    // InternalSM2.g:1245:1: ruleContract returns [EObject current=null] : (otherlv_0= 'contract' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) )* ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE ) ;
    public final EObject ruleContract() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token this_OPENKEY_4=null;
        Token this_EOLINE_5=null;
        Token this_CLOSEKEY_11=null;
        Token this_EOLINE_12=null;
        EObject lv_constructor_6_0 = null;

        EObject lv_comments_7_0 = null;

        EObject lv_attributes_8_0 = null;

        EObject lv_modifier_9_0 = null;

        EObject lv_clauses_10_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1251:2: ( (otherlv_0= 'contract' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) )* ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE ) )
            // InternalSM2.g:1252:2: (otherlv_0= 'contract' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) )* ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE )
            {
            // InternalSM2.g:1252:2: (otherlv_0= 'contract' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) )* ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE )
            // InternalSM2.g:1253:3: otherlv_0= 'contract' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_constructor_6_0= ruleConstructor ) )* ( (lv_comments_7_0= ruleComment ) )* ( (lv_attributes_8_0= ruleAttributes ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_clauses_10_0= ruleClause ) )* this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,71,FOLLOW_13); 

            			newLeafNode(otherlv_0, grammarAccess.getContractAccess().getContractKeyword_0());
            		
            // InternalSM2.g:1257:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSM2.g:1258:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSM2.g:1258:4: (lv_name_1_0= RULE_ID )
            // InternalSM2.g:1259:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_28); 

            					newLeafNode(lv_name_1_0, grammarAccess.getContractAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getContractRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:1275:3: (otherlv_2= 'is' ( (otherlv_3= RULE_ID ) ) )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==72) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalSM2.g:1276:4: otherlv_2= 'is' ( (otherlv_3= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,72,FOLLOW_13); 

                    				newLeafNode(otherlv_2, grammarAccess.getContractAccess().getIsKeyword_2_0());
                    			
                    // InternalSM2.g:1280:4: ( (otherlv_3= RULE_ID ) )
                    // InternalSM2.g:1281:5: (otherlv_3= RULE_ID )
                    {
                    // InternalSM2.g:1281:5: (otherlv_3= RULE_ID )
                    // InternalSM2.g:1282:6: otherlv_3= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getContractRule());
                    						}
                    					
                    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_14); 

                    						newLeafNode(otherlv_3, grammarAccess.getContractAccess().getSuperTypeContractCrossReference_2_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            this_OPENKEY_4=(Token)match(input,RULE_OPENKEY,FOLLOW_29); 

            			newLeafNode(this_OPENKEY_4, grammarAccess.getContractAccess().getOPENKEYTerminalRuleCall_3());
            		
            // InternalSM2.g:1298:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==RULE_EOLINE) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalSM2.g:1299:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_30); 

                    				newLeafNode(this_EOLINE_5, grammarAccess.getContractAccess().getEOLINETerminalRuleCall_4());
                    			

                    }
                    break;

            }

            // InternalSM2.g:1304:3: ( (lv_constructor_6_0= ruleConstructor ) )*
            loop36:
            do {
                int alt36=2;
                int LA36_0 = input.LA(1);

                if ( (LA36_0==73) ) {
                    alt36=1;
                }


                switch (alt36) {
            	case 1 :
            	    // InternalSM2.g:1305:4: (lv_constructor_6_0= ruleConstructor )
            	    {
            	    // InternalSM2.g:1305:4: (lv_constructor_6_0= ruleConstructor )
            	    // InternalSM2.g:1306:5: lv_constructor_6_0= ruleConstructor
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getConstructorConstructorParserRuleCall_5_0());
            	    				
            	    pushFollow(FOLLOW_30);
            	    lv_constructor_6_0=ruleConstructor();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"constructor",
            	    						lv_constructor_6_0,
            	    						"org.xtext.SM2.Constructor");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop36;
                }
            } while (true);

            // InternalSM2.g:1323:3: ( (lv_comments_7_0= ruleComment ) )*
            loop37:
            do {
                int alt37=2;
                int LA37_0 = input.LA(1);

                if ( ((LA37_0>=161 && LA37_0<=162)) ) {
                    alt37=1;
                }


                switch (alt37) {
            	case 1 :
            	    // InternalSM2.g:1324:4: (lv_comments_7_0= ruleComment )
            	    {
            	    // InternalSM2.g:1324:4: (lv_comments_7_0= ruleComment )
            	    // InternalSM2.g:1325:5: lv_comments_7_0= ruleComment
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getCommentsCommentParserRuleCall_6_0());
            	    				
            	    pushFollow(FOLLOW_31);
            	    lv_comments_7_0=ruleComment();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"comments",
            	    						lv_comments_7_0,
            	    						"org.xtext.SM2.Comment");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop37;
                }
            } while (true);

            // InternalSM2.g:1342:3: ( (lv_attributes_8_0= ruleAttributes ) )*
            loop38:
            do {
                int alt38=2;
                int LA38_0 = input.LA(1);

                if ( (LA38_0==RULE_ID||LA38_0==79||LA38_0==81||LA38_0==83||(LA38_0>=88 && LA38_0<=145)) ) {
                    alt38=1;
                }


                switch (alt38) {
            	case 1 :
            	    // InternalSM2.g:1343:4: (lv_attributes_8_0= ruleAttributes )
            	    {
            	    // InternalSM2.g:1343:4: (lv_attributes_8_0= ruleAttributes )
            	    // InternalSM2.g:1344:5: lv_attributes_8_0= ruleAttributes
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getAttributesAttributesParserRuleCall_7_0());
            	    				
            	    pushFollow(FOLLOW_32);
            	    lv_attributes_8_0=ruleAttributes();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"attributes",
            	    						lv_attributes_8_0,
            	    						"org.xtext.SM2.Attributes");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop38;
                }
            } while (true);

            // InternalSM2.g:1361:3: ( (lv_modifier_9_0= ruleModifier ) )*
            loop39:
            do {
                int alt39=2;
                int LA39_0 = input.LA(1);

                if ( (LA39_0==77) ) {
                    alt39=1;
                }


                switch (alt39) {
            	case 1 :
            	    // InternalSM2.g:1362:4: (lv_modifier_9_0= ruleModifier )
            	    {
            	    // InternalSM2.g:1362:4: (lv_modifier_9_0= ruleModifier )
            	    // InternalSM2.g:1363:5: lv_modifier_9_0= ruleModifier
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getModifierModifierParserRuleCall_8_0());
            	    				
            	    pushFollow(FOLLOW_33);
            	    lv_modifier_9_0=ruleModifier();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"modifier",
            	    						lv_modifier_9_0,
            	    						"org.xtext.SM2.Modifier");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop39;
                }
            } while (true);

            // InternalSM2.g:1380:3: ( (lv_clauses_10_0= ruleClause ) )*
            loop40:
            do {
                int alt40=2;
                int LA40_0 = input.LA(1);

                if ( (LA40_0==156) ) {
                    alt40=1;
                }


                switch (alt40) {
            	case 1 :
            	    // InternalSM2.g:1381:4: (lv_clauses_10_0= ruleClause )
            	    {
            	    // InternalSM2.g:1381:4: (lv_clauses_10_0= ruleClause )
            	    // InternalSM2.g:1382:5: lv_clauses_10_0= ruleClause
            	    {

            	    					newCompositeNode(grammarAccess.getContractAccess().getClausesClauseParserRuleCall_9_0());
            	    				
            	    pushFollow(FOLLOW_34);
            	    lv_clauses_10_0=ruleClause();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"clauses",
            	    						lv_clauses_10_0,
            	    						"org.xtext.SM2.Clause");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop40;
                }
            } while (true);

            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_23); 

            			newLeafNode(this_CLOSEKEY_11, grammarAccess.getContractAccess().getCLOSEKEYTerminalRuleCall_10());
            		
            this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_12, grammarAccess.getContractAccess().getEOLINETerminalRuleCall_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleContract"


    // $ANTLR start "entryRuleConstructor"
    // InternalSM2.g:1411:1: entryRuleConstructor returns [EObject current=null] : iv_ruleConstructor= ruleConstructor EOF ;
    public final EObject entryRuleConstructor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConstructor = null;


        try {
            // InternalSM2.g:1411:52: (iv_ruleConstructor= ruleConstructor EOF )
            // InternalSM2.g:1412:2: iv_ruleConstructor= ruleConstructor EOF
            {
             newCompositeNode(grammarAccess.getConstructorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConstructor=ruleConstructor();

            state._fsp--;

             current =iv_ruleConstructor; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConstructor"


    // $ANTLR start "ruleConstructor"
    // InternalSM2.g:1418:1: ruleConstructor returns [EObject current=null] : (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS ( ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) ) ) this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY ) ;
    public final EObject ruleConstructor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token lv_type_4_1=null;
        Token lv_type_4_2=null;
        Token this_OPENKEY_5=null;
        Token this_CLOSEKEY_7=null;
        EObject lv_inputParams_2_0 = null;

        EObject lv_Attributes_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1424:2: ( (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS ( ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) ) ) this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY ) )
            // InternalSM2.g:1425:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS ( ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) ) ) this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY )
            {
            // InternalSM2.g:1425:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS ( ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) ) ) this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY )
            // InternalSM2.g:1426:3: otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_inputParams_2_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS ( ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) ) ) this_OPENKEY_5= RULE_OPENKEY ( (lv_Attributes_6_0= ruleAttributes ) ) this_CLOSEKEY_7= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,73,FOLLOW_19); 

            			newLeafNode(otherlv_0, grammarAccess.getConstructorAccess().getConstructorKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_35); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConstructorAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:1434:3: ( (lv_inputParams_2_0= ruleInputParam ) )*
            loop41:
            do {
                int alt41=2;
                int LA41_0 = input.LA(1);

                if ( (LA41_0==83||(LA41_0>=89 && LA41_0<=129)||(LA41_0>=131 && LA41_0<=147)) ) {
                    alt41=1;
                }


                switch (alt41) {
            	case 1 :
            	    // InternalSM2.g:1435:4: (lv_inputParams_2_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1435:4: (lv_inputParams_2_0= ruleInputParam )
            	    // InternalSM2.g:1436:5: lv_inputParams_2_0= ruleInputParam
            	    {

            	    					newCompositeNode(grammarAccess.getConstructorAccess().getInputParamsInputParamParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_35);
            	    lv_inputParams_2_0=ruleInputParam();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getConstructorRule());
            	    					}
            	    					add(
            	    						current,
            	    						"inputParams",
            	    						lv_inputParams_2_0,
            	    						"org.xtext.SM2.InputParam");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop41;
                }
            } while (true);

            this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_36); 

            			newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getConstructorAccess().getCLOSEPARENTHESISTerminalRuleCall_3());
            		
            // InternalSM2.g:1457:3: ( ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) ) )
            // InternalSM2.g:1458:4: ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) )
            {
            // InternalSM2.g:1458:4: ( (lv_type_4_1= 'public' | lv_type_4_2= 'internal' ) )
            // InternalSM2.g:1459:5: (lv_type_4_1= 'public' | lv_type_4_2= 'internal' )
            {
            // InternalSM2.g:1459:5: (lv_type_4_1= 'public' | lv_type_4_2= 'internal' )
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==74) ) {
                alt42=1;
            }
            else if ( (LA42_0==75) ) {
                alt42=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 42, 0, input);

                throw nvae;
            }
            switch (alt42) {
                case 1 :
                    // InternalSM2.g:1460:6: lv_type_4_1= 'public'
                    {
                    lv_type_4_1=(Token)match(input,74,FOLLOW_14); 

                    						newLeafNode(lv_type_4_1, grammarAccess.getConstructorAccess().getTypePublicKeyword_4_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getConstructorRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_4_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1471:6: lv_type_4_2= 'internal'
                    {
                    lv_type_4_2=(Token)match(input,75,FOLLOW_14); 

                    						newLeafNode(lv_type_4_2, grammarAccess.getConstructorAccess().getTypeInternalKeyword_4_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getConstructorRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_4_2, null);
                    					

                    }
                    break;

            }


            }


            }

            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_37); 

            			newLeafNode(this_OPENKEY_5, grammarAccess.getConstructorAccess().getOPENKEYTerminalRuleCall_5());
            		
            // InternalSM2.g:1488:3: ( (lv_Attributes_6_0= ruleAttributes ) )
            // InternalSM2.g:1489:4: (lv_Attributes_6_0= ruleAttributes )
            {
            // InternalSM2.g:1489:4: (lv_Attributes_6_0= ruleAttributes )
            // InternalSM2.g:1490:5: lv_Attributes_6_0= ruleAttributes
            {

            					newCompositeNode(grammarAccess.getConstructorAccess().getAttributesAttributesParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_16);
            lv_Attributes_6_0=ruleAttributes();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getConstructorRule());
            					}
            					add(
            						current,
            						"Attributes",
            						lv_Attributes_6_0,
            						"org.xtext.SM2.Attributes");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); 

            			newLeafNode(this_CLOSEKEY_7, grammarAccess.getConstructorAccess().getCLOSEKEYTerminalRuleCall_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConstructor"


    // $ANTLR start "entryRuleEvent"
    // InternalSM2.g:1515:1: entryRuleEvent returns [EObject current=null] : iv_ruleEvent= ruleEvent EOF ;
    public final EObject entryRuleEvent() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvent = null;


        try {
            // InternalSM2.g:1515:46: (iv_ruleEvent= ruleEvent EOF )
            // InternalSM2.g:1516:2: iv_ruleEvent= ruleEvent EOF
            {
             newCompositeNode(grammarAccess.getEventRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEvent=ruleEvent();

            state._fsp--;

             current =iv_ruleEvent; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalSM2.g:1522:1: ruleEvent returns [EObject current=null] : (otherlv_0= 'event' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputparam_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject ruleEvent() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;
        EObject lv_inputparam_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1528:2: ( (otherlv_0= 'event' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputparam_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1529:2: (otherlv_0= 'event' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputparam_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1529:2: (otherlv_0= 'event' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputparam_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1530:3: otherlv_0= 'event' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputparam_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,76,FOLLOW_13); 

            			newLeafNode(otherlv_0, grammarAccess.getEventAccess().getEventKeyword_0());
            		
            // InternalSM2.g:1534:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSM2.g:1535:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSM2.g:1535:4: (lv_name_1_0= RULE_ID )
            // InternalSM2.g:1536:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_19); 

            					newLeafNode(lv_name_1_0, grammarAccess.getEventAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEventRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_35); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		
            // InternalSM2.g:1556:3: ( (lv_inputparam_3_0= ruleInputParam ) )*
            loop43:
            do {
                int alt43=2;
                int LA43_0 = input.LA(1);

                if ( (LA43_0==83||(LA43_0>=89 && LA43_0<=129)||(LA43_0>=131 && LA43_0<=147)) ) {
                    alt43=1;
                }


                switch (alt43) {
            	case 1 :
            	    // InternalSM2.g:1557:4: (lv_inputparam_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1557:4: (lv_inputparam_3_0= ruleInputParam )
            	    // InternalSM2.g:1558:5: lv_inputparam_3_0= ruleInputParam
            	    {

            	    					newCompositeNode(grammarAccess.getEventAccess().getInputparamInputParamParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_35);
            	    lv_inputparam_3_0=ruleInputParam();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getEventRule());
            	    					}
            	    					add(
            	    						current,
            	    						"inputparam",
            	    						lv_inputparam_3_0,
            	    						"org.xtext.SM2.InputParam");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop43;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_8); 

            			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
            		
            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

            			newLeafNode(this_SEMICOLON_5, grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5());
            		
            // InternalSM2.g:1583:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==RULE_EOLINE) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:1584:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_6, grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:1593:1: entryRuleAttributes returns [EObject current=null] : iv_ruleAttributes= ruleAttributes EOF ;
    public final EObject entryRuleAttributes() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttributes = null;


        try {
            // InternalSM2.g:1593:51: (iv_ruleAttributes= ruleAttributes EOF )
            // InternalSM2.g:1594:2: iv_ruleAttributes= ruleAttributes EOF
            {
             newCompositeNode(grammarAccess.getAttributesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAttributes=ruleAttributes();

            state._fsp--;

             current =iv_ruleAttributes; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:1600:1: ruleAttributes returns [EObject current=null] : this_DataType_0= ruleDataType ;
    public final EObject ruleAttributes() throws RecognitionException {
        EObject current = null;

        EObject this_DataType_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1606:2: (this_DataType_0= ruleDataType )
            // InternalSM2.g:1607:2: this_DataType_0= ruleDataType
            {

            		newCompositeNode(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall());
            	
            pushFollow(FOLLOW_2);
            this_DataType_0=ruleDataType();

            state._fsp--;


            		current = this_DataType_0;
            		afterParserOrEnumRuleCall();
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:1618:1: entryRuleModifier returns [EObject current=null] : iv_ruleModifier= ruleModifier EOF ;
    public final EObject entryRuleModifier() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModifier = null;


        try {
            // InternalSM2.g:1618:49: (iv_ruleModifier= ruleModifier EOF )
            // InternalSM2.g:1619:2: iv_ruleModifier= ruleModifier EOF
            {
             newCompositeNode(grammarAccess.getModifierRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModifier=ruleModifier();

            state._fsp--;

             current =iv_ruleModifier; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:1625:1: ruleModifier returns [EObject current=null] : (otherlv_0= 'modifier' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= ruleSyntaxExpression ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? ) ;
    public final EObject ruleModifier() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_EOLINE_6=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Token otherlv_10=null;
        Token this_CLOSEKEY_11=null;
        Token this_EOLINE_12=null;
        EObject lv_inputParams_3_0 = null;

        AntlrDatatypeRuleToken lv_expr_7_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1631:2: ( (otherlv_0= 'modifier' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= ruleSyntaxExpression ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? ) )
            // InternalSM2.g:1632:2: (otherlv_0= 'modifier' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= ruleSyntaxExpression ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? )
            {
            // InternalSM2.g:1632:2: (otherlv_0= 'modifier' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= ruleSyntaxExpression ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? )
            // InternalSM2.g:1633:3: otherlv_0= 'modifier' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= ruleSyntaxExpression ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,77,FOLLOW_13); 

            			newLeafNode(otherlv_0, grammarAccess.getModifierAccess().getModifierKeyword_0());
            		
            // InternalSM2.g:1637:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSM2.g:1638:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSM2.g:1638:4: (lv_name_1_0= RULE_ID )
            // InternalSM2.g:1639:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_19); 

            					newLeafNode(lv_name_1_0, grammarAccess.getModifierAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getModifierRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_35); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		
            // InternalSM2.g:1659:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop45:
            do {
                int alt45=2;
                int LA45_0 = input.LA(1);

                if ( (LA45_0==83||(LA45_0>=89 && LA45_0<=129)||(LA45_0>=131 && LA45_0<=147)) ) {
                    alt45=1;
                }


                switch (alt45) {
            	case 1 :
            	    // InternalSM2.g:1660:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1660:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:1661:5: lv_inputParams_3_0= ruleInputParam
            	    {

            	    					newCompositeNode(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_35);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModifierRule());
            	    					}
            	    					add(
            	    						current,
            	    						"inputParams",
            	    						lv_inputParams_3_0,
            	    						"org.xtext.SM2.InputParam");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop45;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_14); 

            			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
            		
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_38); 

            			newLeafNode(this_OPENKEY_5, grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5());
            		
            // InternalSM2.g:1686:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==RULE_EOLINE) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:1687:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_10); 

                    				newLeafNode(this_EOLINE_6, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }

            // InternalSM2.g:1692:3: ( (lv_expr_7_0= ruleSyntaxExpression ) )
            // InternalSM2.g:1693:4: (lv_expr_7_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:1693:4: (lv_expr_7_0= ruleSyntaxExpression )
            // InternalSM2.g:1694:5: lv_expr_7_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getModifierAccess().getExprSyntaxExpressionParserRuleCall_7_0());
            				
            pushFollow(FOLLOW_8);
            lv_expr_7_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getModifierRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_7_0,
            						"org.xtext.SM2.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_39); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8());
            		
            // InternalSM2.g:1715:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==RULE_EOLINE) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalSM2.g:1716:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_40); 

                    				newLeafNode(this_EOLINE_9, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9());
                    			

                    }
                    break;

            }

            otherlv_10=(Token)match(input,78,FOLLOW_16); 

            			newLeafNode(otherlv_10, grammarAccess.getModifierAccess().get_Keyword_10());
            		
            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_9); 

            			newLeafNode(this_CLOSEKEY_11, grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11());
            		
            // InternalSM2.g:1729:3: (this_EOLINE_12= RULE_EOLINE )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==RULE_EOLINE) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalSM2.g:1730:4: this_EOLINE_12= RULE_EOLINE
                    {
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_12, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:1739:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalSM2.g:1739:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalSM2.g:1740:2: iv_ruleDataType= ruleDataType EOF
            {
             newCompositeNode(grammarAccess.getDataTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;

             current =iv_ruleDataType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:1746:1: ruleDataType returns [EObject current=null] : (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID | rulePrimitiveTypes ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        Token this_ID_2=null;
        EObject this_CompositeType_0 = null;

        EObject this_Enum_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1752:2: ( (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID | rulePrimitiveTypes ) )
            // InternalSM2.g:1753:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID | rulePrimitiveTypes )
            {
            // InternalSM2.g:1753:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID | rulePrimitiveTypes )
            int alt49=4;
            switch ( input.LA(1) ) {
            case 79:
            case 81:
                {
                alt49=1;
                }
                break;
            case 88:
                {
                alt49=2;
                }
                break;
            case RULE_ID:
                {
                alt49=3;
                }
                break;
            case 83:
            case 89:
            case 90:
            case 91:
            case 92:
            case 93:
            case 94:
            case 95:
            case 96:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:
            case 103:
            case 104:
            case 105:
            case 106:
            case 107:
            case 108:
            case 109:
            case 110:
            case 111:
            case 112:
            case 113:
            case 114:
            case 115:
            case 116:
            case 117:
            case 118:
            case 119:
            case 120:
            case 121:
            case 122:
            case 123:
            case 124:
            case 125:
            case 126:
            case 127:
            case 128:
            case 129:
            case 130:
            case 131:
            case 132:
            case 133:
            case 134:
            case 135:
            case 136:
            case 137:
            case 138:
            case 139:
            case 140:
            case 141:
            case 142:
            case 143:
            case 144:
            case 145:
                {
                alt49=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 49, 0, input);

                throw nvae;
            }

            switch (alt49) {
                case 1 :
                    // InternalSM2.g:1754:3: this_CompositeType_0= ruleCompositeType
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_CompositeType_0=ruleCompositeType();

                    state._fsp--;


                    			current = this_CompositeType_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1763:3: this_Enum_1= ruleEnum
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Enum_1=ruleEnum();

                    state._fsp--;


                    			current = this_Enum_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1772:3: this_ID_2= RULE_ID
                    {
                    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			newLeafNode(this_ID_2, grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:1777:3: rulePrimitiveTypes
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getPrimitiveTypesParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    rulePrimitiveTypes();

                    state._fsp--;


                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2.g:1788:1: entryRuleCompositeType returns [EObject current=null] : iv_ruleCompositeType= ruleCompositeType EOF ;
    public final EObject entryRuleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompositeType = null;


        try {
            // InternalSM2.g:1788:54: (iv_ruleCompositeType= ruleCompositeType EOF )
            // InternalSM2.g:1789:2: iv_ruleCompositeType= ruleCompositeType EOF
            {
             newCompositeNode(grammarAccess.getCompositeTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCompositeType=ruleCompositeType();

            state._fsp--;

             current =iv_ruleCompositeType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2.g:1795:1: ruleCompositeType returns [EObject current=null] : (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) ;
    public final EObject ruleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject this_Mapping_0 = null;

        EObject this_Struct_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1801:2: ( (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) )
            // InternalSM2.g:1802:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            {
            // InternalSM2.g:1802:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==79) ) {
                alt50=1;
            }
            else if ( (LA50_0==81) ) {
                alt50=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 50, 0, input);

                throw nvae;
            }
            switch (alt50) {
                case 1 :
                    // InternalSM2.g:1803:3: this_Mapping_0= ruleMapping
                    {

                    			newCompositeNode(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Mapping_0=ruleMapping();

                    state._fsp--;


                    			current = this_Mapping_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1812:3: this_Struct_1= ruleStruct
                    {

                    			newCompositeNode(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Struct_1=ruleStruct();

                    state._fsp--;


                    			current = this_Struct_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:1824:1: entryRuleMapping returns [EObject current=null] : iv_ruleMapping= ruleMapping EOF ;
    public final EObject entryRuleMapping() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMapping = null;


        try {
            // InternalSM2.g:1824:48: (iv_ruleMapping= ruleMapping EOF )
            // InternalSM2.g:1825:2: iv_ruleMapping= ruleMapping EOF
            {
             newCompositeNode(grammarAccess.getMappingRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMapping=ruleMapping();

            state._fsp--;

             current =iv_ruleMapping; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:1831:1: ruleMapping returns [EObject current=null] : (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_value_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_name_7_0= RULE_ID ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) ;
    public final EObject ruleMapping() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_3=null;
        Token lv_value_4_0=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token lv_name_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        EObject lv_key_2_0 = null;

        Enumerator lv_visibility_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1837:2: ( (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_value_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_name_7_0= RULE_ID ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) )
            // InternalSM2.g:1838:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_value_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_name_7_0= RULE_ID ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? )
            {
            // InternalSM2.g:1838:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_value_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_name_7_0= RULE_ID ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? )
            // InternalSM2.g:1839:3: otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_value_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_name_7_0= RULE_ID ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,79,FOLLOW_19); 

            			newLeafNode(otherlv_0, grammarAccess.getMappingAccess().getMappingKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_41); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:1847:3: ( (lv_key_2_0= ruleSingularType ) )
            // InternalSM2.g:1848:4: (lv_key_2_0= ruleSingularType )
            {
            // InternalSM2.g:1848:4: (lv_key_2_0= ruleSingularType )
            // InternalSM2.g:1849:5: lv_key_2_0= ruleSingularType
            {

            					newCompositeNode(grammarAccess.getMappingAccess().getKeySingularTypeParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_42);
            lv_key_2_0=ruleSingularType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMappingRule());
            					}
            					set(
            						current,
            						"key",
            						lv_key_2_0,
            						"org.xtext.SM2.SingularType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,80,FOLLOW_10); 

            			newLeafNode(otherlv_3, grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3());
            		
            // InternalSM2.g:1870:3: ( (lv_value_4_0= RULE_STRING ) )
            // InternalSM2.g:1871:4: (lv_value_4_0= RULE_STRING )
            {
            // InternalSM2.g:1871:4: (lv_value_4_0= RULE_STRING )
            // InternalSM2.g:1872:5: lv_value_4_0= RULE_STRING
            {
            lv_value_4_0=(Token)match(input,RULE_STRING,FOLLOW_21); 

            					newLeafNode(lv_value_4_0, grammarAccess.getMappingAccess().getValueSTRINGTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMappingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"value",
            						lv_value_4_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_43); 

            			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
            		
            // InternalSM2.g:1892:3: ( (lv_visibility_6_0= ruleVisibility ) )?
            int alt51=2;
            int LA51_0 = input.LA(1);

            if ( ((LA51_0>=74 && LA51_0<=75)||LA51_0==193) ) {
                alt51=1;
            }
            switch (alt51) {
                case 1 :
                    // InternalSM2.g:1893:4: (lv_visibility_6_0= ruleVisibility )
                    {
                    // InternalSM2.g:1893:4: (lv_visibility_6_0= ruleVisibility )
                    // InternalSM2.g:1894:5: lv_visibility_6_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0());
                    				
                    pushFollow(FOLLOW_13);
                    lv_visibility_6_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getMappingRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_6_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:1911:3: ( (lv_name_7_0= RULE_ID ) )
            // InternalSM2.g:1912:4: (lv_name_7_0= RULE_ID )
            {
            // InternalSM2.g:1912:4: (lv_name_7_0= RULE_ID )
            // InternalSM2.g:1913:5: lv_name_7_0= RULE_ID
            {
            lv_name_7_0=(Token)match(input,RULE_ID,FOLLOW_22); 

            					newLeafNode(lv_name_7_0, grammarAccess.getMappingAccess().getNameIDTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMappingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_7_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:1929:3: (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==RULE_SEMICOLON) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalSM2.g:1930:4: this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE
                    {
                    this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); 

                    				newLeafNode(this_SEMICOLON_8, grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8_0());
                    			
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_9, grammarAccess.getMappingAccess().getEOLINETerminalRuleCall_8_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:1943:1: entryRuleStruct returns [EObject current=null] : iv_ruleStruct= ruleStruct EOF ;
    public final EObject entryRuleStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStruct = null;


        try {
            // InternalSM2.g:1943:47: (iv_ruleStruct= ruleStruct EOF )
            // InternalSM2.g:1944:2: iv_ruleStruct= ruleStruct EOF
            {
             newCompositeNode(grammarAccess.getStructRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStruct=ruleStruct();

            state._fsp--;

             current =iv_ruleStruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:1950:1: ruleStruct returns [EObject current=null] : (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany ) ;
    public final EObject ruleStruct() throws RecognitionException {
        EObject current = null;

        EObject this_PersonalizedStruct_0 = null;

        EObject this_User_1 = null;

        EObject this_Company_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:1956:2: ( (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany ) )
            // InternalSM2.g:1957:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )
            {
            // InternalSM2.g:1957:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )
            int alt53=3;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==81) ) {
                switch ( input.LA(2) ) {
                case 87:
                    {
                    alt53=3;
                    }
                    break;
                case 82:
                    {
                    alt53=2;
                    }
                    break;
                case RULE_ID:
                    {
                    alt53=1;
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 53, 1, input);

                    throw nvae;
                }

            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 53, 0, input);

                throw nvae;
            }
            switch (alt53) {
                case 1 :
                    // InternalSM2.g:1958:3: this_PersonalizedStruct_0= rulePersonalizedStruct
                    {

                    			newCompositeNode(grammarAccess.getStructAccess().getPersonalizedStructParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_PersonalizedStruct_0=rulePersonalizedStruct();

                    state._fsp--;


                    			current = this_PersonalizedStruct_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1967:3: this_User_1= ruleUser
                    {

                    			newCompositeNode(grammarAccess.getStructAccess().getUserParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_User_1=ruleUser();

                    state._fsp--;


                    			current = this_User_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1976:3: this_Company_2= ruleCompany
                    {

                    			newCompositeNode(grammarAccess.getStructAccess().getCompanyParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_Company_2=ruleCompany();

                    state._fsp--;


                    			current = this_Company_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRulePersonalizedStruct"
    // InternalSM2.g:1988:1: entryRulePersonalizedStruct returns [EObject current=null] : iv_rulePersonalizedStruct= rulePersonalizedStruct EOF ;
    public final EObject entryRulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonalizedStruct = null;


        try {
            // InternalSM2.g:1988:59: (iv_rulePersonalizedStruct= rulePersonalizedStruct EOF )
            // InternalSM2.g:1989:2: iv_rulePersonalizedStruct= rulePersonalizedStruct EOF
            {
             newCompositeNode(grammarAccess.getPersonalizedStructRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePersonalizedStruct=rulePersonalizedStruct();

            state._fsp--;

             current =iv_rulePersonalizedStruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonalizedStruct"


    // $ANTLR start "rulePersonalizedStruct"
    // InternalSM2.g:1995:1: rulePersonalizedStruct returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject rulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_CLOSEKEY_5=null;
        Token this_EOLINE_6=null;
        EObject lv_properties_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2001:2: ( (otherlv_0= 'struct' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:2002:2: (otherlv_0= 'struct' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:2002:2: (otherlv_0= 'struct' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:2003:3: otherlv_0= 'struct' ( (lv_name_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,81,FOLLOW_13); 

            			newLeafNode(otherlv_0, grammarAccess.getPersonalizedStructAccess().getStructKeyword_0());
            		
            // InternalSM2.g:2007:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSM2.g:2008:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSM2.g:2008:4: (lv_name_1_0= RULE_ID )
            // InternalSM2.g:2009:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_14); 

            					newLeafNode(lv_name_1_0, grammarAccess.getPersonalizedStructAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPersonalizedStructRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_44); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2());
            		
            // InternalSM2.g:2029:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==RULE_EOLINE) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalSM2.g:2030:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_45); 

                    				newLeafNode(this_EOLINE_3, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3());
                    			

                    }
                    break;

            }

            // InternalSM2.g:2035:3: ( (lv_properties_4_0= ruleProperty ) )
            // InternalSM2.g:2036:4: (lv_properties_4_0= ruleProperty )
            {
            // InternalSM2.g:2036:4: (lv_properties_4_0= ruleProperty )
            // InternalSM2.g:2037:5: lv_properties_4_0= ruleProperty
            {

            					newCompositeNode(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_16);
            lv_properties_4_0=ruleProperty();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPersonalizedStructRule());
            					}
            					add(
            						current,
            						"properties",
            						lv_properties_4_0,
            						"org.xtext.SM2.Property");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_9); 

            			newLeafNode(this_CLOSEKEY_5, grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5());
            		
            // InternalSM2.g:2058:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==RULE_EOLINE) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // InternalSM2.g:2059:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_6, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonalizedStruct"


    // $ANTLR start "entryRuleUser"
    // InternalSM2.g:2068:1: entryRuleUser returns [EObject current=null] : iv_ruleUser= ruleUser EOF ;
    public final EObject entryRuleUser() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUser = null;


        try {
            // InternalSM2.g:2068:45: (iv_ruleUser= ruleUser EOF )
            // InternalSM2.g:2069:2: iv_ruleUser= ruleUser EOF
            {
             newCompositeNode(grammarAccess.getUserRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleUser=ruleUser();

            state._fsp--;

             current =iv_ruleUser; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUser"


    // $ANTLR start "ruleUser"
    // InternalSM2.g:2075:1: ruleUser returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_name_1_0= 'User' ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )? ) ;
    public final EObject ruleUser() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_1=null;
        Token lv_idAdress_5_2=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        Token otherlv_8=null;
        Token lv_nameUser_9_0=null;
        Token otherlv_10=null;
        Token this_STRING_11=null;
        Token this_SEMICOLON_12=null;
        Token this_EOLINE_13=null;
        Token otherlv_14=null;
        Token lv_surnameUser_15_0=null;
        Token otherlv_16=null;
        Token this_STRING_17=null;
        Token this_SEMICOLON_18=null;
        Token this_EOLINE_19=null;
        Token otherlv_20=null;
        Token lv_email_21_0=null;
        Token otherlv_22=null;
        Token this_EMAIL_23=null;
        Token this_SEMICOLON_24=null;
        Token this_EOLINE_25=null;
        Token this_CLOSEKEY_26=null;
        Token this_EOLINE_27=null;


        	enterRule();

        try {
            // InternalSM2.g:2081:2: ( (otherlv_0= 'struct' ( (lv_name_1_0= 'User' ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )? ) )
            // InternalSM2.g:2082:2: (otherlv_0= 'struct' ( (lv_name_1_0= 'User' ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )? )
            {
            // InternalSM2.g:2082:2: (otherlv_0= 'struct' ( (lv_name_1_0= 'User' ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )? )
            // InternalSM2.g:2083:3: otherlv_0= 'struct' ( (lv_name_1_0= 'User' ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameUser_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_surnameUser_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? this_CLOSEKEY_26= RULE_CLOSEKEY (this_EOLINE_27= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,81,FOLLOW_46); 

            			newLeafNode(otherlv_0, grammarAccess.getUserAccess().getStructKeyword_0());
            		
            // InternalSM2.g:2087:3: ( (lv_name_1_0= 'User' ) )
            // InternalSM2.g:2088:4: (lv_name_1_0= 'User' )
            {
            // InternalSM2.g:2088:4: (lv_name_1_0= 'User' )
            // InternalSM2.g:2089:5: lv_name_1_0= 'User'
            {
            lv_name_1_0=(Token)match(input,82,FOLLOW_14); 

            					newLeafNode(lv_name_1_0, grammarAccess.getUserAccess().getNameUserKeyword_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(current, "name", lv_name_1_0, "User");
            				

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_47); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2());
            		
            // InternalSM2.g:2105:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==RULE_EOLINE) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalSM2.g:2106:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_48); 

                    				newLeafNode(this_EOLINE_3, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3());
                    			

                    }
                    break;

            }

            otherlv_4=(Token)match(input,83,FOLLOW_49); 

            			newLeafNode(otherlv_4, grammarAccess.getUserAccess().getAddressKeyword_4());
            		
            // InternalSM2.g:2115:3: ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) )
            // InternalSM2.g:2116:4: ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) )
            {
            // InternalSM2.g:2116:4: ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) )
            // InternalSM2.g:2117:5: (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' )
            {
            // InternalSM2.g:2117:5: (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' )
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==RULE_ID) ) {
                alt57=1;
            }
            else if ( (LA57_0==84) ) {
                alt57=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 57, 0, input);

                throw nvae;
            }
            switch (alt57) {
                case 1 :
                    // InternalSM2.g:2118:6: lv_idAdress_5_1= RULE_ID
                    {
                    lv_idAdress_5_1=(Token)match(input,RULE_ID,FOLLOW_8); 

                    						newLeafNode(lv_idAdress_5_1, grammarAccess.getUserAccess().getIdAdressIDTerminalRuleCall_5_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getUserRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"idAdress",
                    							lv_idAdress_5_1,
                    							"org.eclipse.xtext.common.Terminals.ID");
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2133:6: lv_idAdress_5_2= 'msg.sender'
                    {
                    lv_idAdress_5_2=(Token)match(input,84,FOLLOW_8); 

                    						newLeafNode(lv_idAdress_5_2, grammarAccess.getUserAccess().getIdAdressMsgSenderKeyword_5_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getUserRule());
                    						}
                    						setWithLastConsumed(current, "idAdress", lv_idAdress_5_2, null);
                    					

                    }
                    break;

            }


            }


            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_50); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:2150:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==RULE_EOLINE) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // InternalSM2.g:2151:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_51); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }

            otherlv_8=(Token)match(input,85,FOLLOW_10); 

            			newLeafNode(otherlv_8, grammarAccess.getUserAccess().getStringKeyword_8());
            		
            // InternalSM2.g:2160:3: ( (lv_nameUser_9_0= RULE_STRING ) )
            // InternalSM2.g:2161:4: (lv_nameUser_9_0= RULE_STRING )
            {
            // InternalSM2.g:2161:4: (lv_nameUser_9_0= RULE_STRING )
            // InternalSM2.g:2162:5: lv_nameUser_9_0= RULE_STRING
            {
            lv_nameUser_9_0=(Token)match(input,RULE_STRING,FOLLOW_52); 

            					newLeafNode(lv_nameUser_9_0, grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameUser",
            						lv_nameUser_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:2178:3: (otherlv_10= '=' this_STRING_11= RULE_STRING )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==86) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // InternalSM2.g:2179:4: otherlv_10= '=' this_STRING_11= RULE_STRING
                    {
                    otherlv_10=(Token)match(input,86,FOLLOW_10); 

                    				newLeafNode(otherlv_10, grammarAccess.getUserAccess().getEqualsSignKeyword_10_0());
                    			
                    this_STRING_11=(Token)match(input,RULE_STRING,FOLLOW_8); 

                    				newLeafNode(this_STRING_11, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_10_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_12=(Token)match(input,RULE_SEMICOLON,FOLLOW_50); 

            			newLeafNode(this_SEMICOLON_12, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_11());
            		
            // InternalSM2.g:2192:3: (this_EOLINE_13= RULE_EOLINE )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==RULE_EOLINE) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // InternalSM2.g:2193:4: this_EOLINE_13= RULE_EOLINE
                    {
                    this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_51); 

                    				newLeafNode(this_EOLINE_13, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_12());
                    			

                    }
                    break;

            }

            otherlv_14=(Token)match(input,85,FOLLOW_10); 

            			newLeafNode(otherlv_14, grammarAccess.getUserAccess().getStringKeyword_13());
            		
            // InternalSM2.g:2202:3: ( (lv_surnameUser_15_0= RULE_STRING ) )
            // InternalSM2.g:2203:4: (lv_surnameUser_15_0= RULE_STRING )
            {
            // InternalSM2.g:2203:4: (lv_surnameUser_15_0= RULE_STRING )
            // InternalSM2.g:2204:5: lv_surnameUser_15_0= RULE_STRING
            {
            lv_surnameUser_15_0=(Token)match(input,RULE_STRING,FOLLOW_52); 

            					newLeafNode(lv_surnameUser_15_0, grammarAccess.getUserAccess().getSurnameUserSTRINGTerminalRuleCall_14_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"surnameUser",
            						lv_surnameUser_15_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:2220:3: (otherlv_16= '=' this_STRING_17= RULE_STRING )?
            int alt61=2;
            int LA61_0 = input.LA(1);

            if ( (LA61_0==86) ) {
                alt61=1;
            }
            switch (alt61) {
                case 1 :
                    // InternalSM2.g:2221:4: otherlv_16= '=' this_STRING_17= RULE_STRING
                    {
                    otherlv_16=(Token)match(input,86,FOLLOW_10); 

                    				newLeafNode(otherlv_16, grammarAccess.getUserAccess().getEqualsSignKeyword_15_0());
                    			
                    this_STRING_17=(Token)match(input,RULE_STRING,FOLLOW_8); 

                    				newLeafNode(this_STRING_17, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_15_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_18=(Token)match(input,RULE_SEMICOLON,FOLLOW_50); 

            			newLeafNode(this_SEMICOLON_18, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_16());
            		
            // InternalSM2.g:2234:3: (this_EOLINE_19= RULE_EOLINE )?
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==RULE_EOLINE) ) {
                alt62=1;
            }
            switch (alt62) {
                case 1 :
                    // InternalSM2.g:2235:4: this_EOLINE_19= RULE_EOLINE
                    {
                    this_EOLINE_19=(Token)match(input,RULE_EOLINE,FOLLOW_51); 

                    				newLeafNode(this_EOLINE_19, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_17());
                    			

                    }
                    break;

            }

            otherlv_20=(Token)match(input,85,FOLLOW_10); 

            			newLeafNode(otherlv_20, grammarAccess.getUserAccess().getStringKeyword_18());
            		
            // InternalSM2.g:2244:3: ( (lv_email_21_0= RULE_STRING ) )
            // InternalSM2.g:2245:4: (lv_email_21_0= RULE_STRING )
            {
            // InternalSM2.g:2245:4: (lv_email_21_0= RULE_STRING )
            // InternalSM2.g:2246:5: lv_email_21_0= RULE_STRING
            {
            lv_email_21_0=(Token)match(input,RULE_STRING,FOLLOW_52); 

            					newLeafNode(lv_email_21_0, grammarAccess.getUserAccess().getEmailSTRINGTerminalRuleCall_19_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"email",
            						lv_email_21_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:2262:3: (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )?
            int alt63=2;
            int LA63_0 = input.LA(1);

            if ( (LA63_0==86) ) {
                alt63=1;
            }
            switch (alt63) {
                case 1 :
                    // InternalSM2.g:2263:4: otherlv_22= '=' this_EMAIL_23= RULE_EMAIL
                    {
                    otherlv_22=(Token)match(input,86,FOLLOW_53); 

                    				newLeafNode(otherlv_22, grammarAccess.getUserAccess().getEqualsSignKeyword_20_0());
                    			
                    this_EMAIL_23=(Token)match(input,RULE_EMAIL,FOLLOW_8); 

                    				newLeafNode(this_EMAIL_23, grammarAccess.getUserAccess().getEMAILTerminalRuleCall_20_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_24=(Token)match(input,RULE_SEMICOLON,FOLLOW_54); 

            			newLeafNode(this_SEMICOLON_24, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_21());
            		
            // InternalSM2.g:2276:3: (this_EOLINE_25= RULE_EOLINE )?
            int alt64=2;
            int LA64_0 = input.LA(1);

            if ( (LA64_0==RULE_EOLINE) ) {
                alt64=1;
            }
            switch (alt64) {
                case 1 :
                    // InternalSM2.g:2277:4: this_EOLINE_25= RULE_EOLINE
                    {
                    this_EOLINE_25=(Token)match(input,RULE_EOLINE,FOLLOW_16); 

                    				newLeafNode(this_EOLINE_25, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_22());
                    			

                    }
                    break;

            }

            this_CLOSEKEY_26=(Token)match(input,RULE_CLOSEKEY,FOLLOW_9); 

            			newLeafNode(this_CLOSEKEY_26, grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_23());
            		
            // InternalSM2.g:2286:3: (this_EOLINE_27= RULE_EOLINE )?
            int alt65=2;
            int LA65_0 = input.LA(1);

            if ( (LA65_0==RULE_EOLINE) ) {
                alt65=1;
            }
            switch (alt65) {
                case 1 :
                    // InternalSM2.g:2287:4: this_EOLINE_27= RULE_EOLINE
                    {
                    this_EOLINE_27=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_27, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_24());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUser"


    // $ANTLR start "entryRuleCompany"
    // InternalSM2.g:2296:1: entryRuleCompany returns [EObject current=null] : iv_ruleCompany= ruleCompany EOF ;
    public final EObject entryRuleCompany() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompany = null;


        try {
            // InternalSM2.g:2296:48: (iv_ruleCompany= ruleCompany EOF )
            // InternalSM2.g:2297:2: iv_ruleCompany= ruleCompany EOF
            {
             newCompositeNode(grammarAccess.getCompanyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCompany=ruleCompany();

            state._fsp--;

             current =iv_ruleCompany; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompany"


    // $ANTLR start "ruleCompany"
    // InternalSM2.g:2303:1: ruleCompany returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_name_1_0= 'Company' ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? ( (otherlv_32= RULE_ID ) ) ( (otherlv_33= RULE_ID ) ) this_CLOSEKEY_34= RULE_CLOSEKEY (this_EOLINE_35= RULE_EOLINE )? ) ;
    public final EObject ruleCompany() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_1=null;
        Token lv_idAdress_5_2=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        Token otherlv_8=null;
        Token lv_nameCompany_9_0=null;
        Token otherlv_10=null;
        Token this_STRING_11=null;
        Token this_SEMICOLON_12=null;
        Token this_EOLINE_13=null;
        Token otherlv_14=null;
        Token lv_city_15_0=null;
        Token otherlv_16=null;
        Token this_STRING_17=null;
        Token this_SEMICOLON_18=null;
        Token this_EOLINE_19=null;
        Token otherlv_20=null;
        Token lv_email_21_0=null;
        Token otherlv_22=null;
        Token this_EMAIL_23=null;
        Token this_SEMICOLON_24=null;
        Token this_EOLINE_25=null;
        Token otherlv_26=null;
        Token lv_telf_27_0=null;
        Token otherlv_28=null;
        Token this_STRING_29=null;
        Token this_SEMICOLON_30=null;
        Token this_EOLINE_31=null;
        Token otherlv_32=null;
        Token otherlv_33=null;
        Token this_CLOSEKEY_34=null;
        Token this_EOLINE_35=null;


        	enterRule();

        try {
            // InternalSM2.g:2309:2: ( (otherlv_0= 'struct' ( (lv_name_1_0= 'Company' ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? ( (otherlv_32= RULE_ID ) ) ( (otherlv_33= RULE_ID ) ) this_CLOSEKEY_34= RULE_CLOSEKEY (this_EOLINE_35= RULE_EOLINE )? ) )
            // InternalSM2.g:2310:2: (otherlv_0= 'struct' ( (lv_name_1_0= 'Company' ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? ( (otherlv_32= RULE_ID ) ) ( (otherlv_33= RULE_ID ) ) this_CLOSEKEY_34= RULE_CLOSEKEY (this_EOLINE_35= RULE_EOLINE )? )
            {
            // InternalSM2.g:2310:2: (otherlv_0= 'struct' ( (lv_name_1_0= 'Company' ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? ( (otherlv_32= RULE_ID ) ) ( (otherlv_33= RULE_ID ) ) this_CLOSEKEY_34= RULE_CLOSEKEY (this_EOLINE_35= RULE_EOLINE )? )
            // InternalSM2.g:2311:3: otherlv_0= 'struct' ( (lv_name_1_0= 'Company' ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) ) this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? otherlv_8= 'string' ( (lv_nameCompany_9_0= RULE_STRING ) ) (otherlv_10= '=' this_STRING_11= RULE_STRING )? this_SEMICOLON_12= RULE_SEMICOLON (this_EOLINE_13= RULE_EOLINE )? otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON (this_EOLINE_19= RULE_EOLINE )? otherlv_20= 'string' ( (lv_email_21_0= RULE_STRING ) ) (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )? this_SEMICOLON_24= RULE_SEMICOLON (this_EOLINE_25= RULE_EOLINE )? otherlv_26= 'string' ( (lv_telf_27_0= RULE_STRING ) ) (otherlv_28= '=' this_STRING_29= RULE_STRING )? this_SEMICOLON_30= RULE_SEMICOLON (this_EOLINE_31= RULE_EOLINE )? ( (otherlv_32= RULE_ID ) ) ( (otherlv_33= RULE_ID ) ) this_CLOSEKEY_34= RULE_CLOSEKEY (this_EOLINE_35= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,81,FOLLOW_55); 

            			newLeafNode(otherlv_0, grammarAccess.getCompanyAccess().getStructKeyword_0());
            		
            // InternalSM2.g:2315:3: ( (lv_name_1_0= 'Company' ) )
            // InternalSM2.g:2316:4: (lv_name_1_0= 'Company' )
            {
            // InternalSM2.g:2316:4: (lv_name_1_0= 'Company' )
            // InternalSM2.g:2317:5: lv_name_1_0= 'Company'
            {
            lv_name_1_0=(Token)match(input,87,FOLLOW_14); 

            					newLeafNode(lv_name_1_0, grammarAccess.getCompanyAccess().getNameCompanyKeyword_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCompanyRule());
            					}
            					setWithLastConsumed(current, "name", lv_name_1_0, "Company");
            				

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_47); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getCompanyAccess().getOPENKEYTerminalRuleCall_2());
            		
            // InternalSM2.g:2333:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==RULE_EOLINE) ) {
                alt66=1;
            }
            switch (alt66) {
                case 1 :
                    // InternalSM2.g:2334:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_48); 

                    				newLeafNode(this_EOLINE_3, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_3());
                    			

                    }
                    break;

            }

            otherlv_4=(Token)match(input,83,FOLLOW_49); 

            			newLeafNode(otherlv_4, grammarAccess.getCompanyAccess().getAddressKeyword_4());
            		
            // InternalSM2.g:2343:3: ( ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) ) )
            // InternalSM2.g:2344:4: ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) )
            {
            // InternalSM2.g:2344:4: ( (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' ) )
            // InternalSM2.g:2345:5: (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' )
            {
            // InternalSM2.g:2345:5: (lv_idAdress_5_1= RULE_ID | lv_idAdress_5_2= 'msg.sender' )
            int alt67=2;
            int LA67_0 = input.LA(1);

            if ( (LA67_0==RULE_ID) ) {
                alt67=1;
            }
            else if ( (LA67_0==84) ) {
                alt67=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 67, 0, input);

                throw nvae;
            }
            switch (alt67) {
                case 1 :
                    // InternalSM2.g:2346:6: lv_idAdress_5_1= RULE_ID
                    {
                    lv_idAdress_5_1=(Token)match(input,RULE_ID,FOLLOW_8); 

                    						newLeafNode(lv_idAdress_5_1, grammarAccess.getCompanyAccess().getIdAdressIDTerminalRuleCall_5_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCompanyRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"idAdress",
                    							lv_idAdress_5_1,
                    							"org.eclipse.xtext.common.Terminals.ID");
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2361:6: lv_idAdress_5_2= 'msg.sender'
                    {
                    lv_idAdress_5_2=(Token)match(input,84,FOLLOW_8); 

                    						newLeafNode(lv_idAdress_5_2, grammarAccess.getCompanyAccess().getIdAdressMsgSenderKeyword_5_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCompanyRule());
                    						}
                    						setWithLastConsumed(current, "idAdress", lv_idAdress_5_2, null);
                    					

                    }
                    break;

            }


            }


            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_50); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:2378:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==RULE_EOLINE) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // InternalSM2.g:2379:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_51); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }

            otherlv_8=(Token)match(input,85,FOLLOW_10); 

            			newLeafNode(otherlv_8, grammarAccess.getCompanyAccess().getStringKeyword_8());
            		
            // InternalSM2.g:2388:3: ( (lv_nameCompany_9_0= RULE_STRING ) )
            // InternalSM2.g:2389:4: (lv_nameCompany_9_0= RULE_STRING )
            {
            // InternalSM2.g:2389:4: (lv_nameCompany_9_0= RULE_STRING )
            // InternalSM2.g:2390:5: lv_nameCompany_9_0= RULE_STRING
            {
            lv_nameCompany_9_0=(Token)match(input,RULE_STRING,FOLLOW_52); 

            					newLeafNode(lv_nameCompany_9_0, grammarAccess.getCompanyAccess().getNameCompanySTRINGTerminalRuleCall_9_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCompanyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameCompany",
            						lv_nameCompany_9_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:2406:3: (otherlv_10= '=' this_STRING_11= RULE_STRING )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==86) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // InternalSM2.g:2407:4: otherlv_10= '=' this_STRING_11= RULE_STRING
                    {
                    otherlv_10=(Token)match(input,86,FOLLOW_10); 

                    				newLeafNode(otherlv_10, grammarAccess.getCompanyAccess().getEqualsSignKeyword_10_0());
                    			
                    this_STRING_11=(Token)match(input,RULE_STRING,FOLLOW_8); 

                    				newLeafNode(this_STRING_11, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_10_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_12=(Token)match(input,RULE_SEMICOLON,FOLLOW_50); 

            			newLeafNode(this_SEMICOLON_12, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_11());
            		
            // InternalSM2.g:2420:3: (this_EOLINE_13= RULE_EOLINE )?
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( (LA70_0==RULE_EOLINE) ) {
                alt70=1;
            }
            switch (alt70) {
                case 1 :
                    // InternalSM2.g:2421:4: this_EOLINE_13= RULE_EOLINE
                    {
                    this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_51); 

                    				newLeafNode(this_EOLINE_13, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_12());
                    			

                    }
                    break;

            }

            otherlv_14=(Token)match(input,85,FOLLOW_10); 

            			newLeafNode(otherlv_14, grammarAccess.getCompanyAccess().getStringKeyword_13());
            		
            // InternalSM2.g:2430:3: ( (lv_city_15_0= RULE_STRING ) )
            // InternalSM2.g:2431:4: (lv_city_15_0= RULE_STRING )
            {
            // InternalSM2.g:2431:4: (lv_city_15_0= RULE_STRING )
            // InternalSM2.g:2432:5: lv_city_15_0= RULE_STRING
            {
            lv_city_15_0=(Token)match(input,RULE_STRING,FOLLOW_52); 

            					newLeafNode(lv_city_15_0, grammarAccess.getCompanyAccess().getCitySTRINGTerminalRuleCall_14_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCompanyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"city",
            						lv_city_15_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:2448:3: (otherlv_16= '=' this_STRING_17= RULE_STRING )?
            int alt71=2;
            int LA71_0 = input.LA(1);

            if ( (LA71_0==86) ) {
                alt71=1;
            }
            switch (alt71) {
                case 1 :
                    // InternalSM2.g:2449:4: otherlv_16= '=' this_STRING_17= RULE_STRING
                    {
                    otherlv_16=(Token)match(input,86,FOLLOW_10); 

                    				newLeafNode(otherlv_16, grammarAccess.getCompanyAccess().getEqualsSignKeyword_15_0());
                    			
                    this_STRING_17=(Token)match(input,RULE_STRING,FOLLOW_8); 

                    				newLeafNode(this_STRING_17, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_15_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_18=(Token)match(input,RULE_SEMICOLON,FOLLOW_50); 

            			newLeafNode(this_SEMICOLON_18, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_16());
            		
            // InternalSM2.g:2462:3: (this_EOLINE_19= RULE_EOLINE )?
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==RULE_EOLINE) ) {
                alt72=1;
            }
            switch (alt72) {
                case 1 :
                    // InternalSM2.g:2463:4: this_EOLINE_19= RULE_EOLINE
                    {
                    this_EOLINE_19=(Token)match(input,RULE_EOLINE,FOLLOW_51); 

                    				newLeafNode(this_EOLINE_19, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_17());
                    			

                    }
                    break;

            }

            otherlv_20=(Token)match(input,85,FOLLOW_10); 

            			newLeafNode(otherlv_20, grammarAccess.getCompanyAccess().getStringKeyword_18());
            		
            // InternalSM2.g:2472:3: ( (lv_email_21_0= RULE_STRING ) )
            // InternalSM2.g:2473:4: (lv_email_21_0= RULE_STRING )
            {
            // InternalSM2.g:2473:4: (lv_email_21_0= RULE_STRING )
            // InternalSM2.g:2474:5: lv_email_21_0= RULE_STRING
            {
            lv_email_21_0=(Token)match(input,RULE_STRING,FOLLOW_52); 

            					newLeafNode(lv_email_21_0, grammarAccess.getCompanyAccess().getEmailSTRINGTerminalRuleCall_19_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCompanyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"email",
            						lv_email_21_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:2490:3: (otherlv_22= '=' this_EMAIL_23= RULE_EMAIL )?
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==86) ) {
                alt73=1;
            }
            switch (alt73) {
                case 1 :
                    // InternalSM2.g:2491:4: otherlv_22= '=' this_EMAIL_23= RULE_EMAIL
                    {
                    otherlv_22=(Token)match(input,86,FOLLOW_53); 

                    				newLeafNode(otherlv_22, grammarAccess.getCompanyAccess().getEqualsSignKeyword_20_0());
                    			
                    this_EMAIL_23=(Token)match(input,RULE_EMAIL,FOLLOW_8); 

                    				newLeafNode(this_EMAIL_23, grammarAccess.getCompanyAccess().getEMAILTerminalRuleCall_20_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_24=(Token)match(input,RULE_SEMICOLON,FOLLOW_50); 

            			newLeafNode(this_SEMICOLON_24, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_21());
            		
            // InternalSM2.g:2504:3: (this_EOLINE_25= RULE_EOLINE )?
            int alt74=2;
            int LA74_0 = input.LA(1);

            if ( (LA74_0==RULE_EOLINE) ) {
                alt74=1;
            }
            switch (alt74) {
                case 1 :
                    // InternalSM2.g:2505:4: this_EOLINE_25= RULE_EOLINE
                    {
                    this_EOLINE_25=(Token)match(input,RULE_EOLINE,FOLLOW_51); 

                    				newLeafNode(this_EOLINE_25, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_22());
                    			

                    }
                    break;

            }

            otherlv_26=(Token)match(input,85,FOLLOW_10); 

            			newLeafNode(otherlv_26, grammarAccess.getCompanyAccess().getStringKeyword_23());
            		
            // InternalSM2.g:2514:3: ( (lv_telf_27_0= RULE_STRING ) )
            // InternalSM2.g:2515:4: (lv_telf_27_0= RULE_STRING )
            {
            // InternalSM2.g:2515:4: (lv_telf_27_0= RULE_STRING )
            // InternalSM2.g:2516:5: lv_telf_27_0= RULE_STRING
            {
            lv_telf_27_0=(Token)match(input,RULE_STRING,FOLLOW_52); 

            					newLeafNode(lv_telf_27_0, grammarAccess.getCompanyAccess().getTelfSTRINGTerminalRuleCall_24_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCompanyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"telf",
            						lv_telf_27_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:2532:3: (otherlv_28= '=' this_STRING_29= RULE_STRING )?
            int alt75=2;
            int LA75_0 = input.LA(1);

            if ( (LA75_0==86) ) {
                alt75=1;
            }
            switch (alt75) {
                case 1 :
                    // InternalSM2.g:2533:4: otherlv_28= '=' this_STRING_29= RULE_STRING
                    {
                    otherlv_28=(Token)match(input,86,FOLLOW_10); 

                    				newLeafNode(otherlv_28, grammarAccess.getCompanyAccess().getEqualsSignKeyword_25_0());
                    			
                    this_STRING_29=(Token)match(input,RULE_STRING,FOLLOW_8); 

                    				newLeafNode(this_STRING_29, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_25_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_30=(Token)match(input,RULE_SEMICOLON,FOLLOW_15); 

            			newLeafNode(this_SEMICOLON_30, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_26());
            		
            // InternalSM2.g:2546:3: (this_EOLINE_31= RULE_EOLINE )?
            int alt76=2;
            int LA76_0 = input.LA(1);

            if ( (LA76_0==RULE_EOLINE) ) {
                alt76=1;
            }
            switch (alt76) {
                case 1 :
                    // InternalSM2.g:2547:4: this_EOLINE_31= RULE_EOLINE
                    {
                    this_EOLINE_31=(Token)match(input,RULE_EOLINE,FOLLOW_13); 

                    				newLeafNode(this_EOLINE_31, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_27());
                    			

                    }
                    break;

            }

            // InternalSM2.g:2552:3: ( (otherlv_32= RULE_ID ) )
            // InternalSM2.g:2553:4: (otherlv_32= RULE_ID )
            {
            // InternalSM2.g:2553:4: (otherlv_32= RULE_ID )
            // InternalSM2.g:2554:5: otherlv_32= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCompanyRule());
            					}
            				
            otherlv_32=(Token)match(input,RULE_ID,FOLLOW_13); 

            					newLeafNode(otherlv_32, grammarAccess.getCompanyAccess().getCompaniesCompanyCrossReference_28_0());
            				

            }


            }

            // InternalSM2.g:2565:3: ( (otherlv_33= RULE_ID ) )
            // InternalSM2.g:2566:4: (otherlv_33= RULE_ID )
            {
            // InternalSM2.g:2566:4: (otherlv_33= RULE_ID )
            // InternalSM2.g:2567:5: otherlv_33= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getCompanyRule());
            					}
            				
            otherlv_33=(Token)match(input,RULE_ID,FOLLOW_16); 

            					newLeafNode(otherlv_33, grammarAccess.getCompanyAccess().getUsersUserCrossReference_29_0());
            				

            }


            }

            this_CLOSEKEY_34=(Token)match(input,RULE_CLOSEKEY,FOLLOW_9); 

            			newLeafNode(this_CLOSEKEY_34, grammarAccess.getCompanyAccess().getCLOSEKEYTerminalRuleCall_30());
            		
            // InternalSM2.g:2582:3: (this_EOLINE_35= RULE_EOLINE )?
            int alt77=2;
            int LA77_0 = input.LA(1);

            if ( (LA77_0==RULE_EOLINE) ) {
                alt77=1;
            }
            switch (alt77) {
                case 1 :
                    // InternalSM2.g:2583:4: this_EOLINE_35= RULE_EOLINE
                    {
                    this_EOLINE_35=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_35, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_31());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompany"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:2592:1: entryRuleEnum returns [EObject current=null] : iv_ruleEnum= ruleEnum EOF ;
    public final EObject entryRuleEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnum = null;


        try {
            // InternalSM2.g:2592:45: (iv_ruleEnum= ruleEnum EOF )
            // InternalSM2.g:2593:2: iv_ruleEnum= ruleEnum EOF
            {
             newCompositeNode(grammarAccess.getEnumRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEnum=ruleEnum();

            state._fsp--;

             current =iv_ruleEnum; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:2599:1: ruleEnum returns [EObject current=null] : (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_ID_1=null;
        Token this_OPENKEY_2=null;
        Token this_STRING_3=null;
        Token this_COMMA_4=null;
        Token this_CLOSEKEY_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;


        	enterRule();

        try {
            // InternalSM2.g:2605:2: ( (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2606:2: (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2606:2: (otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2607:3: otherlv_0= 'enum' this_ID_1= RULE_ID this_OPENKEY_2= RULE_OPENKEY this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,88,FOLLOW_13); 

            			newLeafNode(otherlv_0, grammarAccess.getEnumAccess().getEnumKeyword_0());
            		
            this_ID_1=(Token)match(input,RULE_ID,FOLLOW_14); 

            			newLeafNode(this_ID_1, grammarAccess.getEnumAccess().getIDTerminalRuleCall_1());
            		
            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_10); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2());
            		
            this_STRING_3=(Token)match(input,RULE_STRING,FOLLOW_56); 

            			newLeafNode(this_STRING_3, grammarAccess.getEnumAccess().getSTRINGTerminalRuleCall_3());
            		
            // InternalSM2.g:2623:3: (this_COMMA_4= RULE_COMMA )?
            int alt78=2;
            int LA78_0 = input.LA(1);

            if ( (LA78_0==RULE_COMMA) ) {
                alt78=1;
            }
            switch (alt78) {
                case 1 :
                    // InternalSM2.g:2624:4: this_COMMA_4= RULE_COMMA
                    {
                    this_COMMA_4=(Token)match(input,RULE_COMMA,FOLLOW_16); 

                    				newLeafNode(this_COMMA_4, grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_4());
                    			

                    }
                    break;

            }

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_8); 

            			newLeafNode(this_CLOSEKEY_5, grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_5());
            		
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:2637:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt79=2;
            int LA79_0 = input.LA(1);

            if ( (LA79_0==RULE_EOLINE) ) {
                alt79=1;
            }
            switch (alt79) {
                case 1 :
                    // InternalSM2.g:2638:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleSingularType"
    // InternalSM2.g:2647:1: entryRuleSingularType returns [EObject current=null] : iv_ruleSingularType= ruleSingularType EOF ;
    public final EObject entryRuleSingularType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSingularType = null;


        try {
            // InternalSM2.g:2647:53: (iv_ruleSingularType= ruleSingularType EOF )
            // InternalSM2.g:2648:2: iv_ruleSingularType= ruleSingularType EOF
            {
             newCompositeNode(grammarAccess.getSingularTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSingularType=ruleSingularType();

            state._fsp--;

             current =iv_ruleSingularType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSingularType"


    // $ANTLR start "ruleSingularType"
    // InternalSM2.g:2654:1: ruleSingularType returns [EObject current=null] : (otherlv_0= 'uint' | otherlv_1= 'uint2' | otherlv_2= 'uint4' | otherlv_3= 'uint8' | otherlv_4= 'uint16' | otherlv_5= 'uint24' | otherlv_6= 'uint32' | otherlv_7= 'uint40' | otherlv_8= 'uint48' | otherlv_9= 'uint56' | otherlv_10= 'uint64' | otherlv_11= 'uint80' | otherlv_12= 'uint88' | otherlv_13= 'uint96' | otherlv_14= 'uint104' | otherlv_15= 'uint128' | otherlv_16= 'uint160' | otherlv_17= 'uint200' | otherlv_18= 'uint256' | otherlv_19= 'int' | otherlv_20= 'int2' | otherlv_21= 'int4' | otherlv_22= 'int8' | otherlv_23= 'int16' | otherlv_24= 'int24' | otherlv_25= 'int32' | otherlv_26= 'int40' | otherlv_27= 'int48' | otherlv_28= 'int56' | otherlv_29= 'int64' | otherlv_30= 'int80' | otherlv_31= 'int88' | otherlv_32= 'int96' | otherlv_33= 'int104' | otherlv_34= 'int128' | otherlv_35= 'int160' | otherlv_36= 'int200' | otherlv_37= 'int256' | otherlv_38= 'bytes' | otherlv_39= 'bytes2' | (otherlv_40= 'bytes3' otherlv_41= 'bytes4' ) | otherlv_42= 'bytes5' | otherlv_43= 'bytes6' | otherlv_44= 'bytes7' | otherlv_45= 'bytes8' | otherlv_46= 'bytes10' | otherlv_47= 'bytes12' | otherlv_48= 'bytes14' | otherlv_49= 'bytes16' | otherlv_50= 'bytes18' | otherlv_51= 'bytes20' | otherlv_52= 'bytes24' | otherlv_53= 'bytes28' | otherlv_54= 'bytes30' | (otherlv_55= 'bytes32' otherlv_56= 'string' ) | otherlv_57= 'address' | otherlv_58= 'address payable' | otherlv_59= 'double' | otherlv_60= 'bool' ) ;
    public final EObject ruleSingularType() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        Token otherlv_14=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token otherlv_18=null;
        Token otherlv_19=null;
        Token otherlv_20=null;
        Token otherlv_21=null;
        Token otherlv_22=null;
        Token otherlv_23=null;
        Token otherlv_24=null;
        Token otherlv_25=null;
        Token otherlv_26=null;
        Token otherlv_27=null;
        Token otherlv_28=null;
        Token otherlv_29=null;
        Token otherlv_30=null;
        Token otherlv_31=null;
        Token otherlv_32=null;
        Token otherlv_33=null;
        Token otherlv_34=null;
        Token otherlv_35=null;
        Token otherlv_36=null;
        Token otherlv_37=null;
        Token otherlv_38=null;
        Token otherlv_39=null;
        Token otherlv_40=null;
        Token otherlv_41=null;
        Token otherlv_42=null;
        Token otherlv_43=null;
        Token otherlv_44=null;
        Token otherlv_45=null;
        Token otherlv_46=null;
        Token otherlv_47=null;
        Token otherlv_48=null;
        Token otherlv_49=null;
        Token otherlv_50=null;
        Token otherlv_51=null;
        Token otherlv_52=null;
        Token otherlv_53=null;
        Token otherlv_54=null;
        Token otherlv_55=null;
        Token otherlv_56=null;
        Token otherlv_57=null;
        Token otherlv_58=null;
        Token otherlv_59=null;
        Token otherlv_60=null;


        	enterRule();

        try {
            // InternalSM2.g:2660:2: ( (otherlv_0= 'uint' | otherlv_1= 'uint2' | otherlv_2= 'uint4' | otherlv_3= 'uint8' | otherlv_4= 'uint16' | otherlv_5= 'uint24' | otherlv_6= 'uint32' | otherlv_7= 'uint40' | otherlv_8= 'uint48' | otherlv_9= 'uint56' | otherlv_10= 'uint64' | otherlv_11= 'uint80' | otherlv_12= 'uint88' | otherlv_13= 'uint96' | otherlv_14= 'uint104' | otherlv_15= 'uint128' | otherlv_16= 'uint160' | otherlv_17= 'uint200' | otherlv_18= 'uint256' | otherlv_19= 'int' | otherlv_20= 'int2' | otherlv_21= 'int4' | otherlv_22= 'int8' | otherlv_23= 'int16' | otherlv_24= 'int24' | otherlv_25= 'int32' | otherlv_26= 'int40' | otherlv_27= 'int48' | otherlv_28= 'int56' | otherlv_29= 'int64' | otherlv_30= 'int80' | otherlv_31= 'int88' | otherlv_32= 'int96' | otherlv_33= 'int104' | otherlv_34= 'int128' | otherlv_35= 'int160' | otherlv_36= 'int200' | otherlv_37= 'int256' | otherlv_38= 'bytes' | otherlv_39= 'bytes2' | (otherlv_40= 'bytes3' otherlv_41= 'bytes4' ) | otherlv_42= 'bytes5' | otherlv_43= 'bytes6' | otherlv_44= 'bytes7' | otherlv_45= 'bytes8' | otherlv_46= 'bytes10' | otherlv_47= 'bytes12' | otherlv_48= 'bytes14' | otherlv_49= 'bytes16' | otherlv_50= 'bytes18' | otherlv_51= 'bytes20' | otherlv_52= 'bytes24' | otherlv_53= 'bytes28' | otherlv_54= 'bytes30' | (otherlv_55= 'bytes32' otherlv_56= 'string' ) | otherlv_57= 'address' | otherlv_58= 'address payable' | otherlv_59= 'double' | otherlv_60= 'bool' ) )
            // InternalSM2.g:2661:2: (otherlv_0= 'uint' | otherlv_1= 'uint2' | otherlv_2= 'uint4' | otherlv_3= 'uint8' | otherlv_4= 'uint16' | otherlv_5= 'uint24' | otherlv_6= 'uint32' | otherlv_7= 'uint40' | otherlv_8= 'uint48' | otherlv_9= 'uint56' | otherlv_10= 'uint64' | otherlv_11= 'uint80' | otherlv_12= 'uint88' | otherlv_13= 'uint96' | otherlv_14= 'uint104' | otherlv_15= 'uint128' | otherlv_16= 'uint160' | otherlv_17= 'uint200' | otherlv_18= 'uint256' | otherlv_19= 'int' | otherlv_20= 'int2' | otherlv_21= 'int4' | otherlv_22= 'int8' | otherlv_23= 'int16' | otherlv_24= 'int24' | otherlv_25= 'int32' | otherlv_26= 'int40' | otherlv_27= 'int48' | otherlv_28= 'int56' | otherlv_29= 'int64' | otherlv_30= 'int80' | otherlv_31= 'int88' | otherlv_32= 'int96' | otherlv_33= 'int104' | otherlv_34= 'int128' | otherlv_35= 'int160' | otherlv_36= 'int200' | otherlv_37= 'int256' | otherlv_38= 'bytes' | otherlv_39= 'bytes2' | (otherlv_40= 'bytes3' otherlv_41= 'bytes4' ) | otherlv_42= 'bytes5' | otherlv_43= 'bytes6' | otherlv_44= 'bytes7' | otherlv_45= 'bytes8' | otherlv_46= 'bytes10' | otherlv_47= 'bytes12' | otherlv_48= 'bytes14' | otherlv_49= 'bytes16' | otherlv_50= 'bytes18' | otherlv_51= 'bytes20' | otherlv_52= 'bytes24' | otherlv_53= 'bytes28' | otherlv_54= 'bytes30' | (otherlv_55= 'bytes32' otherlv_56= 'string' ) | otherlv_57= 'address' | otherlv_58= 'address payable' | otherlv_59= 'double' | otherlv_60= 'bool' )
            {
            // InternalSM2.g:2661:2: (otherlv_0= 'uint' | otherlv_1= 'uint2' | otherlv_2= 'uint4' | otherlv_3= 'uint8' | otherlv_4= 'uint16' | otherlv_5= 'uint24' | otherlv_6= 'uint32' | otherlv_7= 'uint40' | otherlv_8= 'uint48' | otherlv_9= 'uint56' | otherlv_10= 'uint64' | otherlv_11= 'uint80' | otherlv_12= 'uint88' | otherlv_13= 'uint96' | otherlv_14= 'uint104' | otherlv_15= 'uint128' | otherlv_16= 'uint160' | otherlv_17= 'uint200' | otherlv_18= 'uint256' | otherlv_19= 'int' | otherlv_20= 'int2' | otherlv_21= 'int4' | otherlv_22= 'int8' | otherlv_23= 'int16' | otherlv_24= 'int24' | otherlv_25= 'int32' | otherlv_26= 'int40' | otherlv_27= 'int48' | otherlv_28= 'int56' | otherlv_29= 'int64' | otherlv_30= 'int80' | otherlv_31= 'int88' | otherlv_32= 'int96' | otherlv_33= 'int104' | otherlv_34= 'int128' | otherlv_35= 'int160' | otherlv_36= 'int200' | otherlv_37= 'int256' | otherlv_38= 'bytes' | otherlv_39= 'bytes2' | (otherlv_40= 'bytes3' otherlv_41= 'bytes4' ) | otherlv_42= 'bytes5' | otherlv_43= 'bytes6' | otherlv_44= 'bytes7' | otherlv_45= 'bytes8' | otherlv_46= 'bytes10' | otherlv_47= 'bytes12' | otherlv_48= 'bytes14' | otherlv_49= 'bytes16' | otherlv_50= 'bytes18' | otherlv_51= 'bytes20' | otherlv_52= 'bytes24' | otherlv_53= 'bytes28' | otherlv_54= 'bytes30' | (otherlv_55= 'bytes32' otherlv_56= 'string' ) | otherlv_57= 'address' | otherlv_58= 'address payable' | otherlv_59= 'double' | otherlv_60= 'bool' )
            int alt80=59;
            switch ( input.LA(1) ) {
            case 89:
                {
                alt80=1;
                }
                break;
            case 90:
                {
                alt80=2;
                }
                break;
            case 91:
                {
                alt80=3;
                }
                break;
            case 92:
                {
                alt80=4;
                }
                break;
            case 93:
                {
                alt80=5;
                }
                break;
            case 94:
                {
                alt80=6;
                }
                break;
            case 95:
                {
                alt80=7;
                }
                break;
            case 96:
                {
                alt80=8;
                }
                break;
            case 97:
                {
                alt80=9;
                }
                break;
            case 98:
                {
                alt80=10;
                }
                break;
            case 99:
                {
                alt80=11;
                }
                break;
            case 100:
                {
                alt80=12;
                }
                break;
            case 101:
                {
                alt80=13;
                }
                break;
            case 102:
                {
                alt80=14;
                }
                break;
            case 103:
                {
                alt80=15;
                }
                break;
            case 104:
                {
                alt80=16;
                }
                break;
            case 105:
                {
                alt80=17;
                }
                break;
            case 106:
                {
                alt80=18;
                }
                break;
            case 107:
                {
                alt80=19;
                }
                break;
            case 108:
                {
                alt80=20;
                }
                break;
            case 109:
                {
                alt80=21;
                }
                break;
            case 110:
                {
                alt80=22;
                }
                break;
            case 111:
                {
                alt80=23;
                }
                break;
            case 112:
                {
                alt80=24;
                }
                break;
            case 113:
                {
                alt80=25;
                }
                break;
            case 114:
                {
                alt80=26;
                }
                break;
            case 115:
                {
                alt80=27;
                }
                break;
            case 116:
                {
                alt80=28;
                }
                break;
            case 117:
                {
                alt80=29;
                }
                break;
            case 118:
                {
                alt80=30;
                }
                break;
            case 119:
                {
                alt80=31;
                }
                break;
            case 120:
                {
                alt80=32;
                }
                break;
            case 121:
                {
                alt80=33;
                }
                break;
            case 122:
                {
                alt80=34;
                }
                break;
            case 123:
                {
                alt80=35;
                }
                break;
            case 124:
                {
                alt80=36;
                }
                break;
            case 125:
                {
                alt80=37;
                }
                break;
            case 126:
                {
                alt80=38;
                }
                break;
            case 127:
                {
                alt80=39;
                }
                break;
            case 128:
                {
                alt80=40;
                }
                break;
            case 129:
                {
                alt80=41;
                }
                break;
            case 131:
                {
                alt80=42;
                }
                break;
            case 132:
                {
                alt80=43;
                }
                break;
            case 133:
                {
                alt80=44;
                }
                break;
            case 134:
                {
                alt80=45;
                }
                break;
            case 135:
                {
                alt80=46;
                }
                break;
            case 136:
                {
                alt80=47;
                }
                break;
            case 137:
                {
                alt80=48;
                }
                break;
            case 138:
                {
                alt80=49;
                }
                break;
            case 139:
                {
                alt80=50;
                }
                break;
            case 140:
                {
                alt80=51;
                }
                break;
            case 141:
                {
                alt80=52;
                }
                break;
            case 142:
                {
                alt80=53;
                }
                break;
            case 143:
                {
                alt80=54;
                }
                break;
            case 144:
                {
                alt80=55;
                }
                break;
            case 83:
                {
                alt80=56;
                }
                break;
            case 145:
                {
                alt80=57;
                }
                break;
            case 146:
                {
                alt80=58;
                }
                break;
            case 147:
                {
                alt80=59;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 80, 0, input);

                throw nvae;
            }

            switch (alt80) {
                case 1 :
                    // InternalSM2.g:2662:3: otherlv_0= 'uint'
                    {
                    otherlv_0=(Token)match(input,89,FOLLOW_2); 

                    			newLeafNode(otherlv_0, grammarAccess.getSingularTypeAccess().getUintKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2667:3: otherlv_1= 'uint2'
                    {
                    otherlv_1=(Token)match(input,90,FOLLOW_2); 

                    			newLeafNode(otherlv_1, grammarAccess.getSingularTypeAccess().getUint2Keyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2672:3: otherlv_2= 'uint4'
                    {
                    otherlv_2=(Token)match(input,91,FOLLOW_2); 

                    			newLeafNode(otherlv_2, grammarAccess.getSingularTypeAccess().getUint4Keyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:2677:3: otherlv_3= 'uint8'
                    {
                    otherlv_3=(Token)match(input,92,FOLLOW_2); 

                    			newLeafNode(otherlv_3, grammarAccess.getSingularTypeAccess().getUint8Keyword_3());
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:2682:3: otherlv_4= 'uint16'
                    {
                    otherlv_4=(Token)match(input,93,FOLLOW_2); 

                    			newLeafNode(otherlv_4, grammarAccess.getSingularTypeAccess().getUint16Keyword_4());
                    		

                    }
                    break;
                case 6 :
                    // InternalSM2.g:2687:3: otherlv_5= 'uint24'
                    {
                    otherlv_5=(Token)match(input,94,FOLLOW_2); 

                    			newLeafNode(otherlv_5, grammarAccess.getSingularTypeAccess().getUint24Keyword_5());
                    		

                    }
                    break;
                case 7 :
                    // InternalSM2.g:2692:3: otherlv_6= 'uint32'
                    {
                    otherlv_6=(Token)match(input,95,FOLLOW_2); 

                    			newLeafNode(otherlv_6, grammarAccess.getSingularTypeAccess().getUint32Keyword_6());
                    		

                    }
                    break;
                case 8 :
                    // InternalSM2.g:2697:3: otherlv_7= 'uint40'
                    {
                    otherlv_7=(Token)match(input,96,FOLLOW_2); 

                    			newLeafNode(otherlv_7, grammarAccess.getSingularTypeAccess().getUint40Keyword_7());
                    		

                    }
                    break;
                case 9 :
                    // InternalSM2.g:2702:3: otherlv_8= 'uint48'
                    {
                    otherlv_8=(Token)match(input,97,FOLLOW_2); 

                    			newLeafNode(otherlv_8, grammarAccess.getSingularTypeAccess().getUint48Keyword_8());
                    		

                    }
                    break;
                case 10 :
                    // InternalSM2.g:2707:3: otherlv_9= 'uint56'
                    {
                    otherlv_9=(Token)match(input,98,FOLLOW_2); 

                    			newLeafNode(otherlv_9, grammarAccess.getSingularTypeAccess().getUint56Keyword_9());
                    		

                    }
                    break;
                case 11 :
                    // InternalSM2.g:2712:3: otherlv_10= 'uint64'
                    {
                    otherlv_10=(Token)match(input,99,FOLLOW_2); 

                    			newLeafNode(otherlv_10, grammarAccess.getSingularTypeAccess().getUint64Keyword_10());
                    		

                    }
                    break;
                case 12 :
                    // InternalSM2.g:2717:3: otherlv_11= 'uint80'
                    {
                    otherlv_11=(Token)match(input,100,FOLLOW_2); 

                    			newLeafNode(otherlv_11, grammarAccess.getSingularTypeAccess().getUint80Keyword_11());
                    		

                    }
                    break;
                case 13 :
                    // InternalSM2.g:2722:3: otherlv_12= 'uint88'
                    {
                    otherlv_12=(Token)match(input,101,FOLLOW_2); 

                    			newLeafNode(otherlv_12, grammarAccess.getSingularTypeAccess().getUint88Keyword_12());
                    		

                    }
                    break;
                case 14 :
                    // InternalSM2.g:2727:3: otherlv_13= 'uint96'
                    {
                    otherlv_13=(Token)match(input,102,FOLLOW_2); 

                    			newLeafNode(otherlv_13, grammarAccess.getSingularTypeAccess().getUint96Keyword_13());
                    		

                    }
                    break;
                case 15 :
                    // InternalSM2.g:2732:3: otherlv_14= 'uint104'
                    {
                    otherlv_14=(Token)match(input,103,FOLLOW_2); 

                    			newLeafNode(otherlv_14, grammarAccess.getSingularTypeAccess().getUint104Keyword_14());
                    		

                    }
                    break;
                case 16 :
                    // InternalSM2.g:2737:3: otherlv_15= 'uint128'
                    {
                    otherlv_15=(Token)match(input,104,FOLLOW_2); 

                    			newLeafNode(otherlv_15, grammarAccess.getSingularTypeAccess().getUint128Keyword_15());
                    		

                    }
                    break;
                case 17 :
                    // InternalSM2.g:2742:3: otherlv_16= 'uint160'
                    {
                    otherlv_16=(Token)match(input,105,FOLLOW_2); 

                    			newLeafNode(otherlv_16, grammarAccess.getSingularTypeAccess().getUint160Keyword_16());
                    		

                    }
                    break;
                case 18 :
                    // InternalSM2.g:2747:3: otherlv_17= 'uint200'
                    {
                    otherlv_17=(Token)match(input,106,FOLLOW_2); 

                    			newLeafNode(otherlv_17, grammarAccess.getSingularTypeAccess().getUint200Keyword_17());
                    		

                    }
                    break;
                case 19 :
                    // InternalSM2.g:2752:3: otherlv_18= 'uint256'
                    {
                    otherlv_18=(Token)match(input,107,FOLLOW_2); 

                    			newLeafNode(otherlv_18, grammarAccess.getSingularTypeAccess().getUint256Keyword_18());
                    		

                    }
                    break;
                case 20 :
                    // InternalSM2.g:2757:3: otherlv_19= 'int'
                    {
                    otherlv_19=(Token)match(input,108,FOLLOW_2); 

                    			newLeafNode(otherlv_19, grammarAccess.getSingularTypeAccess().getIntKeyword_19());
                    		

                    }
                    break;
                case 21 :
                    // InternalSM2.g:2762:3: otherlv_20= 'int2'
                    {
                    otherlv_20=(Token)match(input,109,FOLLOW_2); 

                    			newLeafNode(otherlv_20, grammarAccess.getSingularTypeAccess().getInt2Keyword_20());
                    		

                    }
                    break;
                case 22 :
                    // InternalSM2.g:2767:3: otherlv_21= 'int4'
                    {
                    otherlv_21=(Token)match(input,110,FOLLOW_2); 

                    			newLeafNode(otherlv_21, grammarAccess.getSingularTypeAccess().getInt4Keyword_21());
                    		

                    }
                    break;
                case 23 :
                    // InternalSM2.g:2772:3: otherlv_22= 'int8'
                    {
                    otherlv_22=(Token)match(input,111,FOLLOW_2); 

                    			newLeafNode(otherlv_22, grammarAccess.getSingularTypeAccess().getInt8Keyword_22());
                    		

                    }
                    break;
                case 24 :
                    // InternalSM2.g:2777:3: otherlv_23= 'int16'
                    {
                    otherlv_23=(Token)match(input,112,FOLLOW_2); 

                    			newLeafNode(otherlv_23, grammarAccess.getSingularTypeAccess().getInt16Keyword_23());
                    		

                    }
                    break;
                case 25 :
                    // InternalSM2.g:2782:3: otherlv_24= 'int24'
                    {
                    otherlv_24=(Token)match(input,113,FOLLOW_2); 

                    			newLeafNode(otherlv_24, grammarAccess.getSingularTypeAccess().getInt24Keyword_24());
                    		

                    }
                    break;
                case 26 :
                    // InternalSM2.g:2787:3: otherlv_25= 'int32'
                    {
                    otherlv_25=(Token)match(input,114,FOLLOW_2); 

                    			newLeafNode(otherlv_25, grammarAccess.getSingularTypeAccess().getInt32Keyword_25());
                    		

                    }
                    break;
                case 27 :
                    // InternalSM2.g:2792:3: otherlv_26= 'int40'
                    {
                    otherlv_26=(Token)match(input,115,FOLLOW_2); 

                    			newLeafNode(otherlv_26, grammarAccess.getSingularTypeAccess().getInt40Keyword_26());
                    		

                    }
                    break;
                case 28 :
                    // InternalSM2.g:2797:3: otherlv_27= 'int48'
                    {
                    otherlv_27=(Token)match(input,116,FOLLOW_2); 

                    			newLeafNode(otherlv_27, grammarAccess.getSingularTypeAccess().getInt48Keyword_27());
                    		

                    }
                    break;
                case 29 :
                    // InternalSM2.g:2802:3: otherlv_28= 'int56'
                    {
                    otherlv_28=(Token)match(input,117,FOLLOW_2); 

                    			newLeafNode(otherlv_28, grammarAccess.getSingularTypeAccess().getInt56Keyword_28());
                    		

                    }
                    break;
                case 30 :
                    // InternalSM2.g:2807:3: otherlv_29= 'int64'
                    {
                    otherlv_29=(Token)match(input,118,FOLLOW_2); 

                    			newLeafNode(otherlv_29, grammarAccess.getSingularTypeAccess().getInt64Keyword_29());
                    		

                    }
                    break;
                case 31 :
                    // InternalSM2.g:2812:3: otherlv_30= 'int80'
                    {
                    otherlv_30=(Token)match(input,119,FOLLOW_2); 

                    			newLeafNode(otherlv_30, grammarAccess.getSingularTypeAccess().getInt80Keyword_30());
                    		

                    }
                    break;
                case 32 :
                    // InternalSM2.g:2817:3: otherlv_31= 'int88'
                    {
                    otherlv_31=(Token)match(input,120,FOLLOW_2); 

                    			newLeafNode(otherlv_31, grammarAccess.getSingularTypeAccess().getInt88Keyword_31());
                    		

                    }
                    break;
                case 33 :
                    // InternalSM2.g:2822:3: otherlv_32= 'int96'
                    {
                    otherlv_32=(Token)match(input,121,FOLLOW_2); 

                    			newLeafNode(otherlv_32, grammarAccess.getSingularTypeAccess().getInt96Keyword_32());
                    		

                    }
                    break;
                case 34 :
                    // InternalSM2.g:2827:3: otherlv_33= 'int104'
                    {
                    otherlv_33=(Token)match(input,122,FOLLOW_2); 

                    			newLeafNode(otherlv_33, grammarAccess.getSingularTypeAccess().getInt104Keyword_33());
                    		

                    }
                    break;
                case 35 :
                    // InternalSM2.g:2832:3: otherlv_34= 'int128'
                    {
                    otherlv_34=(Token)match(input,123,FOLLOW_2); 

                    			newLeafNode(otherlv_34, grammarAccess.getSingularTypeAccess().getInt128Keyword_34());
                    		

                    }
                    break;
                case 36 :
                    // InternalSM2.g:2837:3: otherlv_35= 'int160'
                    {
                    otherlv_35=(Token)match(input,124,FOLLOW_2); 

                    			newLeafNode(otherlv_35, grammarAccess.getSingularTypeAccess().getInt160Keyword_35());
                    		

                    }
                    break;
                case 37 :
                    // InternalSM2.g:2842:3: otherlv_36= 'int200'
                    {
                    otherlv_36=(Token)match(input,125,FOLLOW_2); 

                    			newLeafNode(otherlv_36, grammarAccess.getSingularTypeAccess().getInt200Keyword_36());
                    		

                    }
                    break;
                case 38 :
                    // InternalSM2.g:2847:3: otherlv_37= 'int256'
                    {
                    otherlv_37=(Token)match(input,126,FOLLOW_2); 

                    			newLeafNode(otherlv_37, grammarAccess.getSingularTypeAccess().getInt256Keyword_37());
                    		

                    }
                    break;
                case 39 :
                    // InternalSM2.g:2852:3: otherlv_38= 'bytes'
                    {
                    otherlv_38=(Token)match(input,127,FOLLOW_2); 

                    			newLeafNode(otherlv_38, grammarAccess.getSingularTypeAccess().getBytesKeyword_38());
                    		

                    }
                    break;
                case 40 :
                    // InternalSM2.g:2857:3: otherlv_39= 'bytes2'
                    {
                    otherlv_39=(Token)match(input,128,FOLLOW_2); 

                    			newLeafNode(otherlv_39, grammarAccess.getSingularTypeAccess().getBytes2Keyword_39());
                    		

                    }
                    break;
                case 41 :
                    // InternalSM2.g:2862:3: (otherlv_40= 'bytes3' otherlv_41= 'bytes4' )
                    {
                    // InternalSM2.g:2862:3: (otherlv_40= 'bytes3' otherlv_41= 'bytes4' )
                    // InternalSM2.g:2863:4: otherlv_40= 'bytes3' otherlv_41= 'bytes4'
                    {
                    otherlv_40=(Token)match(input,129,FOLLOW_57); 

                    				newLeafNode(otherlv_40, grammarAccess.getSingularTypeAccess().getBytes3Keyword_40_0());
                    			
                    otherlv_41=(Token)match(input,130,FOLLOW_2); 

                    				newLeafNode(otherlv_41, grammarAccess.getSingularTypeAccess().getBytes4Keyword_40_1());
                    			

                    }


                    }
                    break;
                case 42 :
                    // InternalSM2.g:2873:3: otherlv_42= 'bytes5'
                    {
                    otherlv_42=(Token)match(input,131,FOLLOW_2); 

                    			newLeafNode(otherlv_42, grammarAccess.getSingularTypeAccess().getBytes5Keyword_41());
                    		

                    }
                    break;
                case 43 :
                    // InternalSM2.g:2878:3: otherlv_43= 'bytes6'
                    {
                    otherlv_43=(Token)match(input,132,FOLLOW_2); 

                    			newLeafNode(otherlv_43, grammarAccess.getSingularTypeAccess().getBytes6Keyword_42());
                    		

                    }
                    break;
                case 44 :
                    // InternalSM2.g:2883:3: otherlv_44= 'bytes7'
                    {
                    otherlv_44=(Token)match(input,133,FOLLOW_2); 

                    			newLeafNode(otherlv_44, grammarAccess.getSingularTypeAccess().getBytes7Keyword_43());
                    		

                    }
                    break;
                case 45 :
                    // InternalSM2.g:2888:3: otherlv_45= 'bytes8'
                    {
                    otherlv_45=(Token)match(input,134,FOLLOW_2); 

                    			newLeafNode(otherlv_45, grammarAccess.getSingularTypeAccess().getBytes8Keyword_44());
                    		

                    }
                    break;
                case 46 :
                    // InternalSM2.g:2893:3: otherlv_46= 'bytes10'
                    {
                    otherlv_46=(Token)match(input,135,FOLLOW_2); 

                    			newLeafNode(otherlv_46, grammarAccess.getSingularTypeAccess().getBytes10Keyword_45());
                    		

                    }
                    break;
                case 47 :
                    // InternalSM2.g:2898:3: otherlv_47= 'bytes12'
                    {
                    otherlv_47=(Token)match(input,136,FOLLOW_2); 

                    			newLeafNode(otherlv_47, grammarAccess.getSingularTypeAccess().getBytes12Keyword_46());
                    		

                    }
                    break;
                case 48 :
                    // InternalSM2.g:2903:3: otherlv_48= 'bytes14'
                    {
                    otherlv_48=(Token)match(input,137,FOLLOW_2); 

                    			newLeafNode(otherlv_48, grammarAccess.getSingularTypeAccess().getBytes14Keyword_47());
                    		

                    }
                    break;
                case 49 :
                    // InternalSM2.g:2908:3: otherlv_49= 'bytes16'
                    {
                    otherlv_49=(Token)match(input,138,FOLLOW_2); 

                    			newLeafNode(otherlv_49, grammarAccess.getSingularTypeAccess().getBytes16Keyword_48());
                    		

                    }
                    break;
                case 50 :
                    // InternalSM2.g:2913:3: otherlv_50= 'bytes18'
                    {
                    otherlv_50=(Token)match(input,139,FOLLOW_2); 

                    			newLeafNode(otherlv_50, grammarAccess.getSingularTypeAccess().getBytes18Keyword_49());
                    		

                    }
                    break;
                case 51 :
                    // InternalSM2.g:2918:3: otherlv_51= 'bytes20'
                    {
                    otherlv_51=(Token)match(input,140,FOLLOW_2); 

                    			newLeafNode(otherlv_51, grammarAccess.getSingularTypeAccess().getBytes20Keyword_50());
                    		

                    }
                    break;
                case 52 :
                    // InternalSM2.g:2923:3: otherlv_52= 'bytes24'
                    {
                    otherlv_52=(Token)match(input,141,FOLLOW_2); 

                    			newLeafNode(otherlv_52, grammarAccess.getSingularTypeAccess().getBytes24Keyword_51());
                    		

                    }
                    break;
                case 53 :
                    // InternalSM2.g:2928:3: otherlv_53= 'bytes28'
                    {
                    otherlv_53=(Token)match(input,142,FOLLOW_2); 

                    			newLeafNode(otherlv_53, grammarAccess.getSingularTypeAccess().getBytes28Keyword_52());
                    		

                    }
                    break;
                case 54 :
                    // InternalSM2.g:2933:3: otherlv_54= 'bytes30'
                    {
                    otherlv_54=(Token)match(input,143,FOLLOW_2); 

                    			newLeafNode(otherlv_54, grammarAccess.getSingularTypeAccess().getBytes30Keyword_53());
                    		

                    }
                    break;
                case 55 :
                    // InternalSM2.g:2938:3: (otherlv_55= 'bytes32' otherlv_56= 'string' )
                    {
                    // InternalSM2.g:2938:3: (otherlv_55= 'bytes32' otherlv_56= 'string' )
                    // InternalSM2.g:2939:4: otherlv_55= 'bytes32' otherlv_56= 'string'
                    {
                    otherlv_55=(Token)match(input,144,FOLLOW_51); 

                    				newLeafNode(otherlv_55, grammarAccess.getSingularTypeAccess().getBytes32Keyword_54_0());
                    			
                    otherlv_56=(Token)match(input,85,FOLLOW_2); 

                    				newLeafNode(otherlv_56, grammarAccess.getSingularTypeAccess().getStringKeyword_54_1());
                    			

                    }


                    }
                    break;
                case 56 :
                    // InternalSM2.g:2949:3: otherlv_57= 'address'
                    {
                    otherlv_57=(Token)match(input,83,FOLLOW_2); 

                    			newLeafNode(otherlv_57, grammarAccess.getSingularTypeAccess().getAddressKeyword_55());
                    		

                    }
                    break;
                case 57 :
                    // InternalSM2.g:2954:3: otherlv_58= 'address payable'
                    {
                    otherlv_58=(Token)match(input,145,FOLLOW_2); 

                    			newLeafNode(otherlv_58, grammarAccess.getSingularTypeAccess().getAddressPayableKeyword_56());
                    		

                    }
                    break;
                case 58 :
                    // InternalSM2.g:2959:3: otherlv_59= 'double'
                    {
                    otherlv_59=(Token)match(input,146,FOLLOW_2); 

                    			newLeafNode(otherlv_59, grammarAccess.getSingularTypeAccess().getDoubleKeyword_57());
                    		

                    }
                    break;
                case 59 :
                    // InternalSM2.g:2964:3: otherlv_60= 'bool'
                    {
                    otherlv_60=(Token)match(input,147,FOLLOW_2); 

                    			newLeafNode(otherlv_60, grammarAccess.getSingularTypeAccess().getBoolKeyword_58());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "entryRulePrimitiveTypes"
    // InternalSM2.g:2972:1: entryRulePrimitiveTypes returns [String current=null] : iv_rulePrimitiveTypes= rulePrimitiveTypes EOF ;
    public final String entryRulePrimitiveTypes() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_rulePrimitiveTypes = null;


        try {
            // InternalSM2.g:2972:54: (iv_rulePrimitiveTypes= rulePrimitiveTypes EOF )
            // InternalSM2.g:2973:2: iv_rulePrimitiveTypes= rulePrimitiveTypes EOF
            {
             newCompositeNode(grammarAccess.getPrimitiveTypesRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePrimitiveTypes=rulePrimitiveTypes();

            state._fsp--;

             current =iv_rulePrimitiveTypes.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePrimitiveTypes"


    // $ANTLR start "rulePrimitiveTypes"
    // InternalSM2.g:2979:1: rulePrimitiveTypes returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_TypeAddress_0= ruleTypeAddress | this_TypeBytes_1= ruleTypeBytes | this_TypeInt_2= ruleTypeInt | this_TypeUint_3= ruleTypeUint ) ;
    public final AntlrDatatypeRuleToken rulePrimitiveTypes() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        AntlrDatatypeRuleToken this_TypeAddress_0 = null;

        AntlrDatatypeRuleToken this_TypeBytes_1 = null;

        AntlrDatatypeRuleToken this_TypeInt_2 = null;

        AntlrDatatypeRuleToken this_TypeUint_3 = null;



        	enterRule();

        try {
            // InternalSM2.g:2985:2: ( (this_TypeAddress_0= ruleTypeAddress | this_TypeBytes_1= ruleTypeBytes | this_TypeInt_2= ruleTypeInt | this_TypeUint_3= ruleTypeUint ) )
            // InternalSM2.g:2986:2: (this_TypeAddress_0= ruleTypeAddress | this_TypeBytes_1= ruleTypeBytes | this_TypeInt_2= ruleTypeInt | this_TypeUint_3= ruleTypeUint )
            {
            // InternalSM2.g:2986:2: (this_TypeAddress_0= ruleTypeAddress | this_TypeBytes_1= ruleTypeBytes | this_TypeInt_2= ruleTypeInt | this_TypeUint_3= ruleTypeUint )
            int alt81=4;
            switch ( input.LA(1) ) {
            case 83:
            case 145:
                {
                alt81=1;
                }
                break;
            case 127:
            case 128:
            case 129:
            case 130:
            case 131:
            case 132:
            case 133:
            case 134:
            case 135:
            case 136:
            case 137:
            case 138:
            case 139:
            case 140:
            case 141:
            case 142:
            case 143:
            case 144:
                {
                alt81=2;
                }
                break;
            case 108:
            case 109:
            case 110:
            case 111:
            case 112:
            case 113:
            case 114:
            case 115:
            case 116:
            case 117:
            case 118:
            case 119:
            case 120:
            case 121:
            case 122:
            case 123:
            case 124:
            case 125:
            case 126:
                {
                alt81=3;
                }
                break;
            case 89:
            case 90:
            case 91:
            case 92:
            case 93:
            case 94:
            case 95:
            case 96:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:
            case 103:
            case 104:
            case 105:
            case 106:
            case 107:
                {
                alt81=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 81, 0, input);

                throw nvae;
            }

            switch (alt81) {
                case 1 :
                    // InternalSM2.g:2987:3: this_TypeAddress_0= ruleTypeAddress
                    {

                    			newCompositeNode(grammarAccess.getPrimitiveTypesAccess().getTypeAddressParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_TypeAddress_0=ruleTypeAddress();

                    state._fsp--;


                    			current.merge(this_TypeAddress_0);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2998:3: this_TypeBytes_1= ruleTypeBytes
                    {

                    			newCompositeNode(grammarAccess.getPrimitiveTypesAccess().getTypeBytesParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_TypeBytes_1=ruleTypeBytes();

                    state._fsp--;


                    			current.merge(this_TypeBytes_1);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:3009:3: this_TypeInt_2= ruleTypeInt
                    {

                    			newCompositeNode(grammarAccess.getPrimitiveTypesAccess().getTypeIntParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_TypeInt_2=ruleTypeInt();

                    state._fsp--;


                    			current.merge(this_TypeInt_2);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:3020:3: this_TypeUint_3= ruleTypeUint
                    {

                    			newCompositeNode(grammarAccess.getPrimitiveTypesAccess().getTypeUintParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_TypeUint_3=ruleTypeUint();

                    state._fsp--;


                    			current.merge(this_TypeUint_3);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePrimitiveTypes"


    // $ANTLR start "entryRuleTypeAddress"
    // InternalSM2.g:3034:1: entryRuleTypeAddress returns [String current=null] : iv_ruleTypeAddress= ruleTypeAddress EOF ;
    public final String entryRuleTypeAddress() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeAddress = null;


        try {
            // InternalSM2.g:3034:51: (iv_ruleTypeAddress= ruleTypeAddress EOF )
            // InternalSM2.g:3035:2: iv_ruleTypeAddress= ruleTypeAddress EOF
            {
             newCompositeNode(grammarAccess.getTypeAddressRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeAddress=ruleTypeAddress();

            state._fsp--;

             current =iv_ruleTypeAddress.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeAddress"


    // $ANTLR start "ruleTypeAddress"
    // InternalSM2.g:3041:1: ruleTypeAddress returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'address' | kw= 'address payable' ) ;
    public final AntlrDatatypeRuleToken ruleTypeAddress() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSM2.g:3047:2: ( (kw= 'address' | kw= 'address payable' ) )
            // InternalSM2.g:3048:2: (kw= 'address' | kw= 'address payable' )
            {
            // InternalSM2.g:3048:2: (kw= 'address' | kw= 'address payable' )
            int alt82=2;
            int LA82_0 = input.LA(1);

            if ( (LA82_0==83) ) {
                alt82=1;
            }
            else if ( (LA82_0==145) ) {
                alt82=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 82, 0, input);

                throw nvae;
            }
            switch (alt82) {
                case 1 :
                    // InternalSM2.g:3049:3: kw= 'address'
                    {
                    kw=(Token)match(input,83,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAddressAccess().getAddressKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3055:3: kw= 'address payable'
                    {
                    kw=(Token)match(input,145,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeAddressAccess().getAddressPayableKeyword_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeAddress"


    // $ANTLR start "entryRuleTypeBytes"
    // InternalSM2.g:3064:1: entryRuleTypeBytes returns [String current=null] : iv_ruleTypeBytes= ruleTypeBytes EOF ;
    public final String entryRuleTypeBytes() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeBytes = null;


        try {
            // InternalSM2.g:3064:49: (iv_ruleTypeBytes= ruleTypeBytes EOF )
            // InternalSM2.g:3065:2: iv_ruleTypeBytes= ruleTypeBytes EOF
            {
             newCompositeNode(grammarAccess.getTypeBytesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeBytes=ruleTypeBytes();

            state._fsp--;

             current =iv_ruleTypeBytes.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeBytes"


    // $ANTLR start "ruleTypeBytes"
    // InternalSM2.g:3071:1: ruleTypeBytes returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'bytes' | kw= 'bytes2' | kw= 'bytes3' | kw= 'bytes4' | kw= 'bytes5' | kw= 'bytes6' | kw= 'bytes7' | kw= 'bytes8' | kw= 'bytes10' | kw= 'bytes12' | kw= 'bytes14' | kw= 'bytes16' | kw= 'bytes18' | kw= 'bytes20' | kw= 'bytes24' | kw= 'bytes28' | kw= 'bytes30' | kw= 'bytes32' ) ;
    public final AntlrDatatypeRuleToken ruleTypeBytes() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSM2.g:3077:2: ( (kw= 'bytes' | kw= 'bytes2' | kw= 'bytes3' | kw= 'bytes4' | kw= 'bytes5' | kw= 'bytes6' | kw= 'bytes7' | kw= 'bytes8' | kw= 'bytes10' | kw= 'bytes12' | kw= 'bytes14' | kw= 'bytes16' | kw= 'bytes18' | kw= 'bytes20' | kw= 'bytes24' | kw= 'bytes28' | kw= 'bytes30' | kw= 'bytes32' ) )
            // InternalSM2.g:3078:2: (kw= 'bytes' | kw= 'bytes2' | kw= 'bytes3' | kw= 'bytes4' | kw= 'bytes5' | kw= 'bytes6' | kw= 'bytes7' | kw= 'bytes8' | kw= 'bytes10' | kw= 'bytes12' | kw= 'bytes14' | kw= 'bytes16' | kw= 'bytes18' | kw= 'bytes20' | kw= 'bytes24' | kw= 'bytes28' | kw= 'bytes30' | kw= 'bytes32' )
            {
            // InternalSM2.g:3078:2: (kw= 'bytes' | kw= 'bytes2' | kw= 'bytes3' | kw= 'bytes4' | kw= 'bytes5' | kw= 'bytes6' | kw= 'bytes7' | kw= 'bytes8' | kw= 'bytes10' | kw= 'bytes12' | kw= 'bytes14' | kw= 'bytes16' | kw= 'bytes18' | kw= 'bytes20' | kw= 'bytes24' | kw= 'bytes28' | kw= 'bytes30' | kw= 'bytes32' )
            int alt83=18;
            switch ( input.LA(1) ) {
            case 127:
                {
                alt83=1;
                }
                break;
            case 128:
                {
                alt83=2;
                }
                break;
            case 129:
                {
                alt83=3;
                }
                break;
            case 130:
                {
                alt83=4;
                }
                break;
            case 131:
                {
                alt83=5;
                }
                break;
            case 132:
                {
                alt83=6;
                }
                break;
            case 133:
                {
                alt83=7;
                }
                break;
            case 134:
                {
                alt83=8;
                }
                break;
            case 135:
                {
                alt83=9;
                }
                break;
            case 136:
                {
                alt83=10;
                }
                break;
            case 137:
                {
                alt83=11;
                }
                break;
            case 138:
                {
                alt83=12;
                }
                break;
            case 139:
                {
                alt83=13;
                }
                break;
            case 140:
                {
                alt83=14;
                }
                break;
            case 141:
                {
                alt83=15;
                }
                break;
            case 142:
                {
                alt83=16;
                }
                break;
            case 143:
                {
                alt83=17;
                }
                break;
            case 144:
                {
                alt83=18;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 83, 0, input);

                throw nvae;
            }

            switch (alt83) {
                case 1 :
                    // InternalSM2.g:3079:3: kw= 'bytes'
                    {
                    kw=(Token)match(input,127,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytesKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3085:3: kw= 'bytes2'
                    {
                    kw=(Token)match(input,128,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes2Keyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:3091:3: kw= 'bytes3'
                    {
                    kw=(Token)match(input,129,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes3Keyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:3097:3: kw= 'bytes4'
                    {
                    kw=(Token)match(input,130,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes4Keyword_3());
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:3103:3: kw= 'bytes5'
                    {
                    kw=(Token)match(input,131,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes5Keyword_4());
                    		

                    }
                    break;
                case 6 :
                    // InternalSM2.g:3109:3: kw= 'bytes6'
                    {
                    kw=(Token)match(input,132,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes6Keyword_5());
                    		

                    }
                    break;
                case 7 :
                    // InternalSM2.g:3115:3: kw= 'bytes7'
                    {
                    kw=(Token)match(input,133,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes7Keyword_6());
                    		

                    }
                    break;
                case 8 :
                    // InternalSM2.g:3121:3: kw= 'bytes8'
                    {
                    kw=(Token)match(input,134,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes8Keyword_7());
                    		

                    }
                    break;
                case 9 :
                    // InternalSM2.g:3127:3: kw= 'bytes10'
                    {
                    kw=(Token)match(input,135,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes10Keyword_8());
                    		

                    }
                    break;
                case 10 :
                    // InternalSM2.g:3133:3: kw= 'bytes12'
                    {
                    kw=(Token)match(input,136,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes12Keyword_9());
                    		

                    }
                    break;
                case 11 :
                    // InternalSM2.g:3139:3: kw= 'bytes14'
                    {
                    kw=(Token)match(input,137,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes14Keyword_10());
                    		

                    }
                    break;
                case 12 :
                    // InternalSM2.g:3145:3: kw= 'bytes16'
                    {
                    kw=(Token)match(input,138,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes16Keyword_11());
                    		

                    }
                    break;
                case 13 :
                    // InternalSM2.g:3151:3: kw= 'bytes18'
                    {
                    kw=(Token)match(input,139,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes18Keyword_12());
                    		

                    }
                    break;
                case 14 :
                    // InternalSM2.g:3157:3: kw= 'bytes20'
                    {
                    kw=(Token)match(input,140,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes20Keyword_13());
                    		

                    }
                    break;
                case 15 :
                    // InternalSM2.g:3163:3: kw= 'bytes24'
                    {
                    kw=(Token)match(input,141,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes24Keyword_14());
                    		

                    }
                    break;
                case 16 :
                    // InternalSM2.g:3169:3: kw= 'bytes28'
                    {
                    kw=(Token)match(input,142,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes28Keyword_15());
                    		

                    }
                    break;
                case 17 :
                    // InternalSM2.g:3175:3: kw= 'bytes30'
                    {
                    kw=(Token)match(input,143,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes30Keyword_16());
                    		

                    }
                    break;
                case 18 :
                    // InternalSM2.g:3181:3: kw= 'bytes32'
                    {
                    kw=(Token)match(input,144,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeBytesAccess().getBytes32Keyword_17());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeBytes"


    // $ANTLR start "entryRuleTypeInt"
    // InternalSM2.g:3190:1: entryRuleTypeInt returns [String current=null] : iv_ruleTypeInt= ruleTypeInt EOF ;
    public final String entryRuleTypeInt() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeInt = null;


        try {
            // InternalSM2.g:3190:47: (iv_ruleTypeInt= ruleTypeInt EOF )
            // InternalSM2.g:3191:2: iv_ruleTypeInt= ruleTypeInt EOF
            {
             newCompositeNode(grammarAccess.getTypeIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeInt=ruleTypeInt();

            state._fsp--;

             current =iv_ruleTypeInt.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeInt"


    // $ANTLR start "ruleTypeInt"
    // InternalSM2.g:3197:1: ruleTypeInt returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'int' | kw= 'int2' | kw= 'int4' | kw= 'int8' | kw= 'int16' | kw= 'int24' | kw= 'int32' | kw= 'int40' | kw= 'int48' | kw= 'int56' | kw= 'int64' | kw= 'int80' | kw= 'int88' | kw= 'int96' | kw= 'int104' | kw= 'int128' | kw= 'int160' | kw= 'int200' | kw= 'int256' ) ;
    public final AntlrDatatypeRuleToken ruleTypeInt() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSM2.g:3203:2: ( (kw= 'int' | kw= 'int2' | kw= 'int4' | kw= 'int8' | kw= 'int16' | kw= 'int24' | kw= 'int32' | kw= 'int40' | kw= 'int48' | kw= 'int56' | kw= 'int64' | kw= 'int80' | kw= 'int88' | kw= 'int96' | kw= 'int104' | kw= 'int128' | kw= 'int160' | kw= 'int200' | kw= 'int256' ) )
            // InternalSM2.g:3204:2: (kw= 'int' | kw= 'int2' | kw= 'int4' | kw= 'int8' | kw= 'int16' | kw= 'int24' | kw= 'int32' | kw= 'int40' | kw= 'int48' | kw= 'int56' | kw= 'int64' | kw= 'int80' | kw= 'int88' | kw= 'int96' | kw= 'int104' | kw= 'int128' | kw= 'int160' | kw= 'int200' | kw= 'int256' )
            {
            // InternalSM2.g:3204:2: (kw= 'int' | kw= 'int2' | kw= 'int4' | kw= 'int8' | kw= 'int16' | kw= 'int24' | kw= 'int32' | kw= 'int40' | kw= 'int48' | kw= 'int56' | kw= 'int64' | kw= 'int80' | kw= 'int88' | kw= 'int96' | kw= 'int104' | kw= 'int128' | kw= 'int160' | kw= 'int200' | kw= 'int256' )
            int alt84=19;
            switch ( input.LA(1) ) {
            case 108:
                {
                alt84=1;
                }
                break;
            case 109:
                {
                alt84=2;
                }
                break;
            case 110:
                {
                alt84=3;
                }
                break;
            case 111:
                {
                alt84=4;
                }
                break;
            case 112:
                {
                alt84=5;
                }
                break;
            case 113:
                {
                alt84=6;
                }
                break;
            case 114:
                {
                alt84=7;
                }
                break;
            case 115:
                {
                alt84=8;
                }
                break;
            case 116:
                {
                alt84=9;
                }
                break;
            case 117:
                {
                alt84=10;
                }
                break;
            case 118:
                {
                alt84=11;
                }
                break;
            case 119:
                {
                alt84=12;
                }
                break;
            case 120:
                {
                alt84=13;
                }
                break;
            case 121:
                {
                alt84=14;
                }
                break;
            case 122:
                {
                alt84=15;
                }
                break;
            case 123:
                {
                alt84=16;
                }
                break;
            case 124:
                {
                alt84=17;
                }
                break;
            case 125:
                {
                alt84=18;
                }
                break;
            case 126:
                {
                alt84=19;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 84, 0, input);

                throw nvae;
            }

            switch (alt84) {
                case 1 :
                    // InternalSM2.g:3205:3: kw= 'int'
                    {
                    kw=(Token)match(input,108,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getIntKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3211:3: kw= 'int2'
                    {
                    kw=(Token)match(input,109,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt2Keyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:3217:3: kw= 'int4'
                    {
                    kw=(Token)match(input,110,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt4Keyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:3223:3: kw= 'int8'
                    {
                    kw=(Token)match(input,111,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt8Keyword_3());
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:3229:3: kw= 'int16'
                    {
                    kw=(Token)match(input,112,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt16Keyword_4());
                    		

                    }
                    break;
                case 6 :
                    // InternalSM2.g:3235:3: kw= 'int24'
                    {
                    kw=(Token)match(input,113,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt24Keyword_5());
                    		

                    }
                    break;
                case 7 :
                    // InternalSM2.g:3241:3: kw= 'int32'
                    {
                    kw=(Token)match(input,114,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt32Keyword_6());
                    		

                    }
                    break;
                case 8 :
                    // InternalSM2.g:3247:3: kw= 'int40'
                    {
                    kw=(Token)match(input,115,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt40Keyword_7());
                    		

                    }
                    break;
                case 9 :
                    // InternalSM2.g:3253:3: kw= 'int48'
                    {
                    kw=(Token)match(input,116,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt48Keyword_8());
                    		

                    }
                    break;
                case 10 :
                    // InternalSM2.g:3259:3: kw= 'int56'
                    {
                    kw=(Token)match(input,117,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt56Keyword_9());
                    		

                    }
                    break;
                case 11 :
                    // InternalSM2.g:3265:3: kw= 'int64'
                    {
                    kw=(Token)match(input,118,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt64Keyword_10());
                    		

                    }
                    break;
                case 12 :
                    // InternalSM2.g:3271:3: kw= 'int80'
                    {
                    kw=(Token)match(input,119,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt80Keyword_11());
                    		

                    }
                    break;
                case 13 :
                    // InternalSM2.g:3277:3: kw= 'int88'
                    {
                    kw=(Token)match(input,120,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt88Keyword_12());
                    		

                    }
                    break;
                case 14 :
                    // InternalSM2.g:3283:3: kw= 'int96'
                    {
                    kw=(Token)match(input,121,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt96Keyword_13());
                    		

                    }
                    break;
                case 15 :
                    // InternalSM2.g:3289:3: kw= 'int104'
                    {
                    kw=(Token)match(input,122,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt104Keyword_14());
                    		

                    }
                    break;
                case 16 :
                    // InternalSM2.g:3295:3: kw= 'int128'
                    {
                    kw=(Token)match(input,123,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt128Keyword_15());
                    		

                    }
                    break;
                case 17 :
                    // InternalSM2.g:3301:3: kw= 'int160'
                    {
                    kw=(Token)match(input,124,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt160Keyword_16());
                    		

                    }
                    break;
                case 18 :
                    // InternalSM2.g:3307:3: kw= 'int200'
                    {
                    kw=(Token)match(input,125,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt200Keyword_17());
                    		

                    }
                    break;
                case 19 :
                    // InternalSM2.g:3313:3: kw= 'int256'
                    {
                    kw=(Token)match(input,126,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeIntAccess().getInt256Keyword_18());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeInt"


    // $ANTLR start "entryRuleTypeUint"
    // InternalSM2.g:3322:1: entryRuleTypeUint returns [String current=null] : iv_ruleTypeUint= ruleTypeUint EOF ;
    public final String entryRuleTypeUint() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeUint = null;


        try {
            // InternalSM2.g:3322:48: (iv_ruleTypeUint= ruleTypeUint EOF )
            // InternalSM2.g:3323:2: iv_ruleTypeUint= ruleTypeUint EOF
            {
             newCompositeNode(grammarAccess.getTypeUintRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeUint=ruleTypeUint();

            state._fsp--;

             current =iv_ruleTypeUint.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeUint"


    // $ANTLR start "ruleTypeUint"
    // InternalSM2.g:3329:1: ruleTypeUint returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'uint' | kw= 'uint2' | kw= 'uint4' | kw= 'uint8' | kw= 'uint16' | kw= 'uint24' | kw= 'uint32' | kw= 'uint40' | kw= 'uint48' | kw= 'uint56' | kw= 'uint64' | kw= 'uint80' | kw= 'uint88' | kw= 'uint96' | kw= 'uint104' | kw= 'uint128' | kw= 'uint160' | kw= 'uint200' | kw= 'uint256' ) ;
    public final AntlrDatatypeRuleToken ruleTypeUint() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSM2.g:3335:2: ( (kw= 'uint' | kw= 'uint2' | kw= 'uint4' | kw= 'uint8' | kw= 'uint16' | kw= 'uint24' | kw= 'uint32' | kw= 'uint40' | kw= 'uint48' | kw= 'uint56' | kw= 'uint64' | kw= 'uint80' | kw= 'uint88' | kw= 'uint96' | kw= 'uint104' | kw= 'uint128' | kw= 'uint160' | kw= 'uint200' | kw= 'uint256' ) )
            // InternalSM2.g:3336:2: (kw= 'uint' | kw= 'uint2' | kw= 'uint4' | kw= 'uint8' | kw= 'uint16' | kw= 'uint24' | kw= 'uint32' | kw= 'uint40' | kw= 'uint48' | kw= 'uint56' | kw= 'uint64' | kw= 'uint80' | kw= 'uint88' | kw= 'uint96' | kw= 'uint104' | kw= 'uint128' | kw= 'uint160' | kw= 'uint200' | kw= 'uint256' )
            {
            // InternalSM2.g:3336:2: (kw= 'uint' | kw= 'uint2' | kw= 'uint4' | kw= 'uint8' | kw= 'uint16' | kw= 'uint24' | kw= 'uint32' | kw= 'uint40' | kw= 'uint48' | kw= 'uint56' | kw= 'uint64' | kw= 'uint80' | kw= 'uint88' | kw= 'uint96' | kw= 'uint104' | kw= 'uint128' | kw= 'uint160' | kw= 'uint200' | kw= 'uint256' )
            int alt85=19;
            switch ( input.LA(1) ) {
            case 89:
                {
                alt85=1;
                }
                break;
            case 90:
                {
                alt85=2;
                }
                break;
            case 91:
                {
                alt85=3;
                }
                break;
            case 92:
                {
                alt85=4;
                }
                break;
            case 93:
                {
                alt85=5;
                }
                break;
            case 94:
                {
                alt85=6;
                }
                break;
            case 95:
                {
                alt85=7;
                }
                break;
            case 96:
                {
                alt85=8;
                }
                break;
            case 97:
                {
                alt85=9;
                }
                break;
            case 98:
                {
                alt85=10;
                }
                break;
            case 99:
                {
                alt85=11;
                }
                break;
            case 100:
                {
                alt85=12;
                }
                break;
            case 101:
                {
                alt85=13;
                }
                break;
            case 102:
                {
                alt85=14;
                }
                break;
            case 103:
                {
                alt85=15;
                }
                break;
            case 104:
                {
                alt85=16;
                }
                break;
            case 105:
                {
                alt85=17;
                }
                break;
            case 106:
                {
                alt85=18;
                }
                break;
            case 107:
                {
                alt85=19;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 85, 0, input);

                throw nvae;
            }

            switch (alt85) {
                case 1 :
                    // InternalSM2.g:3337:3: kw= 'uint'
                    {
                    kw=(Token)match(input,89,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUintKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3343:3: kw= 'uint2'
                    {
                    kw=(Token)match(input,90,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint2Keyword_1());
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:3349:3: kw= 'uint4'
                    {
                    kw=(Token)match(input,91,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint4Keyword_2());
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:3355:3: kw= 'uint8'
                    {
                    kw=(Token)match(input,92,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint8Keyword_3());
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:3361:3: kw= 'uint16'
                    {
                    kw=(Token)match(input,93,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint16Keyword_4());
                    		

                    }
                    break;
                case 6 :
                    // InternalSM2.g:3367:3: kw= 'uint24'
                    {
                    kw=(Token)match(input,94,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint24Keyword_5());
                    		

                    }
                    break;
                case 7 :
                    // InternalSM2.g:3373:3: kw= 'uint32'
                    {
                    kw=(Token)match(input,95,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint32Keyword_6());
                    		

                    }
                    break;
                case 8 :
                    // InternalSM2.g:3379:3: kw= 'uint40'
                    {
                    kw=(Token)match(input,96,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint40Keyword_7());
                    		

                    }
                    break;
                case 9 :
                    // InternalSM2.g:3385:3: kw= 'uint48'
                    {
                    kw=(Token)match(input,97,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint48Keyword_8());
                    		

                    }
                    break;
                case 10 :
                    // InternalSM2.g:3391:3: kw= 'uint56'
                    {
                    kw=(Token)match(input,98,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint56Keyword_9());
                    		

                    }
                    break;
                case 11 :
                    // InternalSM2.g:3397:3: kw= 'uint64'
                    {
                    kw=(Token)match(input,99,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint64Keyword_10());
                    		

                    }
                    break;
                case 12 :
                    // InternalSM2.g:3403:3: kw= 'uint80'
                    {
                    kw=(Token)match(input,100,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint80Keyword_11());
                    		

                    }
                    break;
                case 13 :
                    // InternalSM2.g:3409:3: kw= 'uint88'
                    {
                    kw=(Token)match(input,101,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint88Keyword_12());
                    		

                    }
                    break;
                case 14 :
                    // InternalSM2.g:3415:3: kw= 'uint96'
                    {
                    kw=(Token)match(input,102,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint96Keyword_13());
                    		

                    }
                    break;
                case 15 :
                    // InternalSM2.g:3421:3: kw= 'uint104'
                    {
                    kw=(Token)match(input,103,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint104Keyword_14());
                    		

                    }
                    break;
                case 16 :
                    // InternalSM2.g:3427:3: kw= 'uint128'
                    {
                    kw=(Token)match(input,104,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint128Keyword_15());
                    		

                    }
                    break;
                case 17 :
                    // InternalSM2.g:3433:3: kw= 'uint160'
                    {
                    kw=(Token)match(input,105,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint160Keyword_16());
                    		

                    }
                    break;
                case 18 :
                    // InternalSM2.g:3439:3: kw= 'uint200'
                    {
                    kw=(Token)match(input,106,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint200Keyword_17());
                    		

                    }
                    break;
                case 19 :
                    // InternalSM2.g:3445:3: kw= 'uint256'
                    {
                    kw=(Token)match(input,107,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getTypeUintAccess().getUint256Keyword_18());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeUint"


    // $ANTLR start "entryRuleArray"
    // InternalSM2.g:3454:1: entryRuleArray returns [String current=null] : iv_ruleArray= ruleArray EOF ;
    public final String entryRuleArray() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleArray = null;


        try {
            // InternalSM2.g:3454:45: (iv_ruleArray= ruleArray EOF )
            // InternalSM2.g:3455:2: iv_ruleArray= ruleArray EOF
            {
             newCompositeNode(grammarAccess.getArrayRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleArray=ruleArray();

            state._fsp--;

             current =iv_ruleArray.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArray"


    // $ANTLR start "ruleArray"
    // InternalSM2.g:3461:1: ruleArray returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )* ) ;
    public final AntlrDatatypeRuleToken ruleArray() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_2=null;
        Token this_INT_6=null;


        	enterRule();

        try {
            // InternalSM2.g:3467:2: ( ( (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )* ) )
            // InternalSM2.g:3468:2: ( (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )* )
            {
            // InternalSM2.g:3468:2: ( (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )* )
            // InternalSM2.g:3469:3: (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) ) (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )*
            {
            // InternalSM2.g:3469:3: (kw= '[]' | (kw= '[' this_INT_2= RULE_INT kw= ']' ) )
            int alt86=2;
            int LA86_0 = input.LA(1);

            if ( (LA86_0==148) ) {
                alt86=1;
            }
            else if ( (LA86_0==149) ) {
                alt86=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 86, 0, input);

                throw nvae;
            }
            switch (alt86) {
                case 1 :
                    // InternalSM2.g:3470:4: kw= '[]'
                    {
                    kw=(Token)match(input,148,FOLLOW_58); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_0_0());
                    			

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3476:4: (kw= '[' this_INT_2= RULE_INT kw= ']' )
                    {
                    // InternalSM2.g:3476:4: (kw= '[' this_INT_2= RULE_INT kw= ']' )
                    // InternalSM2.g:3477:5: kw= '[' this_INT_2= RULE_INT kw= ']'
                    {
                    kw=(Token)match(input,149,FOLLOW_59); 

                    					current.merge(kw);
                    					newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_0_1_0());
                    				
                    this_INT_2=(Token)match(input,RULE_INT,FOLLOW_60); 

                    					current.merge(this_INT_2);
                    				

                    					newLeafNode(this_INT_2, grammarAccess.getArrayAccess().getINTTerminalRuleCall_0_1_1());
                    				
                    kw=(Token)match(input,150,FOLLOW_58); 

                    					current.merge(kw);
                    					newLeafNode(kw, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_0_1_2());
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:3496:3: (kw= '[]' | (kw= '[' this_INT_6= RULE_INT kw= ']' ) )*
            loop87:
            do {
                int alt87=3;
                int LA87_0 = input.LA(1);

                if ( (LA87_0==148) ) {
                    alt87=1;
                }
                else if ( (LA87_0==149) ) {
                    alt87=2;
                }


                switch (alt87) {
            	case 1 :
            	    // InternalSM2.g:3497:4: kw= '[]'
            	    {
            	    kw=(Token)match(input,148,FOLLOW_58); 

            	    				current.merge(kw);
            	    				newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_1_0());
            	    			

            	    }
            	    break;
            	case 2 :
            	    // InternalSM2.g:3503:4: (kw= '[' this_INT_6= RULE_INT kw= ']' )
            	    {
            	    // InternalSM2.g:3503:4: (kw= '[' this_INT_6= RULE_INT kw= ']' )
            	    // InternalSM2.g:3504:5: kw= '[' this_INT_6= RULE_INT kw= ']'
            	    {
            	    kw=(Token)match(input,149,FOLLOW_59); 

            	    					current.merge(kw);
            	    					newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_1_1_0());
            	    				
            	    this_INT_6=(Token)match(input,RULE_INT,FOLLOW_60); 

            	    					current.merge(this_INT_6);
            	    				

            	    					newLeafNode(this_INT_6, grammarAccess.getArrayAccess().getINTTerminalRuleCall_1_1_1());
            	    				
            	    kw=(Token)match(input,150,FOLLOW_58); 

            	    					current.merge(kw);
            	    					newLeafNode(kw, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_1_1_2());
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop87;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArray"


    // $ANTLR start "entryRuleProperties"
    // InternalSM2.g:3527:1: entryRuleProperties returns [EObject current=null] : iv_ruleProperties= ruleProperties EOF ;
    public final EObject entryRuleProperties() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperties = null;


        try {
            // InternalSM2.g:3527:51: (iv_ruleProperties= ruleProperties EOF )
            // InternalSM2.g:3528:2: iv_ruleProperties= ruleProperties EOF
            {
             newCompositeNode(grammarAccess.getPropertiesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleProperties=ruleProperties();

            state._fsp--;

             current =iv_ruleProperties; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperties"


    // $ANTLR start "ruleProperties"
    // InternalSM2.g:3534:1: ruleProperties returns [EObject current=null] : this_Property_0= ruleProperty ;
    public final EObject ruleProperties() throws RecognitionException {
        EObject current = null;

        EObject this_Property_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3540:2: (this_Property_0= ruleProperty )
            // InternalSM2.g:3541:2: this_Property_0= ruleProperty
            {

            		newCompositeNode(grammarAccess.getPropertiesAccess().getPropertyParserRuleCall());
            	
            pushFollow(FOLLOW_2);
            this_Property_0=ruleProperty();

            state._fsp--;


            		current = this_Property_0;
            		afterParserOrEnumRuleCall();
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperties"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:3552:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // InternalSM2.g:3552:49: (iv_ruleProperty= ruleProperty EOF )
            // InternalSM2.g:3553:2: iv_ruleProperty= ruleProperty EOF
            {
             newCompositeNode(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleProperty=ruleProperty();

            state._fsp--;

             current =iv_ruleProperty; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:3559:1: ruleProperty returns [EObject current=null] : (this_PropertyString_0= rulePropertyString | this_PropertyBoolean_1= rulePropertyBoolean | this_PropertyInteger_2= rulePropertyInteger | this_PropertyUInteger_3= rulePropertyUInteger | this_PropertyFloat_4= rulePropertyFloat | this_PropertyAddress_5= rulePropertyAddress | this_PropertyBytes_6= rulePropertyBytes | this_PropertyStruct_7= rulePropertyStruct ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        EObject this_PropertyString_0 = null;

        EObject this_PropertyBoolean_1 = null;

        EObject this_PropertyInteger_2 = null;

        EObject this_PropertyUInteger_3 = null;

        EObject this_PropertyFloat_4 = null;

        EObject this_PropertyAddress_5 = null;

        EObject this_PropertyBytes_6 = null;

        EObject this_PropertyStruct_7 = null;



        	enterRule();

        try {
            // InternalSM2.g:3565:2: ( (this_PropertyString_0= rulePropertyString | this_PropertyBoolean_1= rulePropertyBoolean | this_PropertyInteger_2= rulePropertyInteger | this_PropertyUInteger_3= rulePropertyUInteger | this_PropertyFloat_4= rulePropertyFloat | this_PropertyAddress_5= rulePropertyAddress | this_PropertyBytes_6= rulePropertyBytes | this_PropertyStruct_7= rulePropertyStruct ) )
            // InternalSM2.g:3566:2: (this_PropertyString_0= rulePropertyString | this_PropertyBoolean_1= rulePropertyBoolean | this_PropertyInteger_2= rulePropertyInteger | this_PropertyUInteger_3= rulePropertyUInteger | this_PropertyFloat_4= rulePropertyFloat | this_PropertyAddress_5= rulePropertyAddress | this_PropertyBytes_6= rulePropertyBytes | this_PropertyStruct_7= rulePropertyStruct )
            {
            // InternalSM2.g:3566:2: (this_PropertyString_0= rulePropertyString | this_PropertyBoolean_1= rulePropertyBoolean | this_PropertyInteger_2= rulePropertyInteger | this_PropertyUInteger_3= rulePropertyUInteger | this_PropertyFloat_4= rulePropertyFloat | this_PropertyAddress_5= rulePropertyAddress | this_PropertyBytes_6= rulePropertyBytes | this_PropertyStruct_7= rulePropertyStruct )
            int alt88=8;
            switch ( input.LA(1) ) {
            case 85:
                {
                alt88=1;
                }
                break;
            case 147:
                {
                alt88=2;
                }
                break;
            case 108:
            case 109:
            case 110:
            case 111:
            case 112:
            case 113:
            case 114:
            case 115:
            case 116:
            case 117:
            case 118:
            case 119:
            case 120:
            case 121:
            case 122:
            case 123:
            case 124:
            case 125:
            case 126:
                {
                alt88=3;
                }
                break;
            case 89:
            case 90:
            case 91:
            case 92:
            case 93:
            case 94:
            case 95:
            case 96:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:
            case 103:
            case 104:
            case 105:
            case 106:
            case 107:
                {
                alt88=4;
                }
                break;
            case 152:
                {
                alt88=5;
                }
                break;
            case 83:
            case 145:
                {
                alt88=6;
                }
                break;
            case 127:
            case 128:
            case 129:
            case 130:
            case 131:
            case 132:
            case 133:
            case 134:
            case 135:
            case 136:
            case 137:
            case 138:
            case 139:
            case 140:
            case 141:
            case 142:
            case 143:
            case 144:
                {
                alt88=7;
                }
                break;
            case 81:
                {
                alt88=8;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 88, 0, input);

                throw nvae;
            }

            switch (alt88) {
                case 1 :
                    // InternalSM2.g:3567:3: this_PropertyString_0= rulePropertyString
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyStringParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyString_0=rulePropertyString();

                    state._fsp--;


                    			current = this_PropertyString_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3576:3: this_PropertyBoolean_1= rulePropertyBoolean
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyBooleanParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyBoolean_1=rulePropertyBoolean();

                    state._fsp--;


                    			current = this_PropertyBoolean_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:3585:3: this_PropertyInteger_2= rulePropertyInteger
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyIntegerParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyInteger_2=rulePropertyInteger();

                    state._fsp--;


                    			current = this_PropertyInteger_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:3594:3: this_PropertyUInteger_3= rulePropertyUInteger
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyUIntegerParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyUInteger_3=rulePropertyUInteger();

                    state._fsp--;


                    			current = this_PropertyUInteger_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:3603:3: this_PropertyFloat_4= rulePropertyFloat
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyFloatParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyFloat_4=rulePropertyFloat();

                    state._fsp--;


                    			current = this_PropertyFloat_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalSM2.g:3612:3: this_PropertyAddress_5= rulePropertyAddress
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyAddressParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyAddress_5=rulePropertyAddress();

                    state._fsp--;


                    			current = this_PropertyAddress_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 7 :
                    // InternalSM2.g:3621:3: this_PropertyBytes_6= rulePropertyBytes
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyBytesParserRuleCall_6());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyBytes_6=rulePropertyBytes();

                    state._fsp--;


                    			current = this_PropertyBytes_6;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 8 :
                    // InternalSM2.g:3630:3: this_PropertyStruct_7= rulePropertyStruct
                    {

                    			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyStructParserRuleCall_7());
                    		
                    pushFollow(FOLLOW_2);
                    this_PropertyStruct_7=rulePropertyStruct();

                    state._fsp--;


                    			current = this_PropertyStruct_7;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRulePropertyString"
    // InternalSM2.g:3642:1: entryRulePropertyString returns [EObject current=null] : iv_rulePropertyString= rulePropertyString EOF ;
    public final EObject entryRulePropertyString() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyString = null;


        try {
            // InternalSM2.g:3642:55: (iv_rulePropertyString= rulePropertyString EOF )
            // InternalSM2.g:3643:2: iv_rulePropertyString= rulePropertyString EOF
            {
             newCompositeNode(grammarAccess.getPropertyStringRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyString=rulePropertyString();

            state._fsp--;

             current =iv_rulePropertyString; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyString"


    // $ANTLR start "rulePropertyString"
    // InternalSM2.g:3649:1: rulePropertyString returns [EObject current=null] : ( ( (lv_type_0_0= 'string' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_storageData_3_0= ruleStorageData ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_inicialization_6_0= RULE_STRING ) ) ( (lv_defaultValue_7_0= 'Insert text here' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) ;
    public final EObject rulePropertyString() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token this_CONSTANT_2=null;
        Token lv_name_4_0=null;
        Token otherlv_5=null;
        Token lv_inicialization_6_0=null;
        Token lv_defaultValue_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Enumerator lv_storageData_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3655:2: ( ( ( (lv_type_0_0= 'string' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_storageData_3_0= ruleStorageData ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_inicialization_6_0= RULE_STRING ) ) ( (lv_defaultValue_7_0= 'Insert text here' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) )
            // InternalSM2.g:3656:2: ( ( (lv_type_0_0= 'string' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_storageData_3_0= ruleStorageData ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_inicialization_6_0= RULE_STRING ) ) ( (lv_defaultValue_7_0= 'Insert text here' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            {
            // InternalSM2.g:3656:2: ( ( (lv_type_0_0= 'string' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_storageData_3_0= ruleStorageData ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_inicialization_6_0= RULE_STRING ) ) ( (lv_defaultValue_7_0= 'Insert text here' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            // InternalSM2.g:3657:3: ( (lv_type_0_0= 'string' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_storageData_3_0= ruleStorageData ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_inicialization_6_0= RULE_STRING ) ) ( (lv_defaultValue_7_0= 'Insert text here' ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )?
            {
            // InternalSM2.g:3657:3: ( (lv_type_0_0= 'string' ) )
            // InternalSM2.g:3658:4: (lv_type_0_0= 'string' )
            {
            // InternalSM2.g:3658:4: (lv_type_0_0= 'string' )
            // InternalSM2.g:3659:5: lv_type_0_0= 'string'
            {
            lv_type_0_0=(Token)match(input,85,FOLLOW_61); 

            					newLeafNode(lv_type_0_0, grammarAccess.getPropertyStringAccess().getTypeStringKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyStringRule());
            					}
            					setWithLastConsumed(current, "type", lv_type_0_0, "string");
            				

            }


            }

            // InternalSM2.g:3671:3: ( ruleArray )?
            int alt89=2;
            int LA89_0 = input.LA(1);

            if ( ((LA89_0>=148 && LA89_0<=149)) ) {
                alt89=1;
            }
            switch (alt89) {
                case 1 :
                    // InternalSM2.g:3672:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyStringAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_62);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:3680:3: (this_CONSTANT_2= RULE_CONSTANT )?
            int alt90=2;
            int LA90_0 = input.LA(1);

            if ( (LA90_0==RULE_CONSTANT) ) {
                alt90=1;
            }
            switch (alt90) {
                case 1 :
                    // InternalSM2.g:3681:4: this_CONSTANT_2= RULE_CONSTANT
                    {
                    this_CONSTANT_2=(Token)match(input,RULE_CONSTANT,FOLLOW_63); 

                    				newLeafNode(this_CONSTANT_2, grammarAccess.getPropertyStringAccess().getCONSTANTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:3686:3: ( (lv_storageData_3_0= ruleStorageData ) )?
            int alt91=2;
            int LA91_0 = input.LA(1);

            if ( ((LA91_0>=191 && LA91_0<=192)) ) {
                alt91=1;
            }
            switch (alt91) {
                case 1 :
                    // InternalSM2.g:3687:4: (lv_storageData_3_0= ruleStorageData )
                    {
                    // InternalSM2.g:3687:4: (lv_storageData_3_0= ruleStorageData )
                    // InternalSM2.g:3688:5: lv_storageData_3_0= ruleStorageData
                    {

                    					newCompositeNode(grammarAccess.getPropertyStringAccess().getStorageDataStorageDataEnumRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_13);
                    lv_storageData_3_0=ruleStorageData();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyStringRule());
                    					}
                    					set(
                    						current,
                    						"storageData",
                    						lv_storageData_3_0,
                    						"org.xtext.SM2.StorageData");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:3705:3: ( (lv_name_4_0= RULE_ID ) )
            // InternalSM2.g:3706:4: (lv_name_4_0= RULE_ID )
            {
            // InternalSM2.g:3706:4: (lv_name_4_0= RULE_ID )
            // InternalSM2.g:3707:5: lv_name_4_0= RULE_ID
            {
            lv_name_4_0=(Token)match(input,RULE_ID,FOLLOW_52); 

            					newLeafNode(lv_name_4_0, grammarAccess.getPropertyStringAccess().getNameIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyStringRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_4_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:3723:3: (otherlv_5= '=' ( (lv_inicialization_6_0= RULE_STRING ) ) ( (lv_defaultValue_7_0= 'Insert text here' ) ) )?
            int alt92=2;
            int LA92_0 = input.LA(1);

            if ( (LA92_0==86) ) {
                alt92=1;
            }
            switch (alt92) {
                case 1 :
                    // InternalSM2.g:3724:4: otherlv_5= '=' ( (lv_inicialization_6_0= RULE_STRING ) ) ( (lv_defaultValue_7_0= 'Insert text here' ) )
                    {
                    otherlv_5=(Token)match(input,86,FOLLOW_10); 

                    				newLeafNode(otherlv_5, grammarAccess.getPropertyStringAccess().getEqualsSignKeyword_5_0());
                    			
                    // InternalSM2.g:3728:4: ( (lv_inicialization_6_0= RULE_STRING ) )
                    // InternalSM2.g:3729:5: (lv_inicialization_6_0= RULE_STRING )
                    {
                    // InternalSM2.g:3729:5: (lv_inicialization_6_0= RULE_STRING )
                    // InternalSM2.g:3730:6: lv_inicialization_6_0= RULE_STRING
                    {
                    lv_inicialization_6_0=(Token)match(input,RULE_STRING,FOLLOW_64); 

                    						newLeafNode(lv_inicialization_6_0, grammarAccess.getPropertyStringAccess().getInicializationSTRINGTerminalRuleCall_5_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyStringRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"inicialization",
                    							lv_inicialization_6_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }

                    // InternalSM2.g:3746:4: ( (lv_defaultValue_7_0= 'Insert text here' ) )
                    // InternalSM2.g:3747:5: (lv_defaultValue_7_0= 'Insert text here' )
                    {
                    // InternalSM2.g:3747:5: (lv_defaultValue_7_0= 'Insert text here' )
                    // InternalSM2.g:3748:6: lv_defaultValue_7_0= 'Insert text here'
                    {
                    lv_defaultValue_7_0=(Token)match(input,151,FOLLOW_8); 

                    						newLeafNode(lv_defaultValue_7_0, grammarAccess.getPropertyStringAccess().getDefaultValueInsertTextHereKeyword_5_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyStringRule());
                    						}
                    						setWithLastConsumed(current, "defaultValue", lv_defaultValue_7_0, "Insert text here");
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getPropertyStringAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:3765:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt93=2;
            int LA93_0 = input.LA(1);

            if ( (LA93_0==RULE_EOLINE) ) {
                alt93=1;
            }
            switch (alt93) {
                case 1 :
                    // InternalSM2.g:3766:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_9, grammarAccess.getPropertyStringAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyString"


    // $ANTLR start "entryRulePropertyInteger"
    // InternalSM2.g:3775:1: entryRulePropertyInteger returns [EObject current=null] : iv_rulePropertyInteger= rulePropertyInteger EOF ;
    public final EObject entryRulePropertyInteger() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyInteger = null;


        try {
            // InternalSM2.g:3775:56: (iv_rulePropertyInteger= rulePropertyInteger EOF )
            // InternalSM2.g:3776:2: iv_rulePropertyInteger= rulePropertyInteger EOF
            {
             newCompositeNode(grammarAccess.getPropertyIntegerRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyInteger=rulePropertyInteger();

            state._fsp--;

             current =iv_rulePropertyInteger; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyInteger"


    // $ANTLR start "rulePropertyInteger"
    // InternalSM2.g:3782:1: rulePropertyInteger returns [EObject current=null] : ( ( (lv_type_0_0= ruleINTEGER ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) ;
    public final EObject rulePropertyInteger() throws RecognitionException {
        EObject current = null;

        Token this_CONSTANT_2=null;
        Token lv_name_4_0=null;
        Token otherlv_5=null;
        Token lv_inicialization_6_0=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        Enumerator lv_type_0_0 = null;

        Enumerator lv_visibility_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3788:2: ( ( ( (lv_type_0_0= ruleINTEGER ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) )
            // InternalSM2.g:3789:2: ( ( (lv_type_0_0= ruleINTEGER ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            {
            // InternalSM2.g:3789:2: ( ( (lv_type_0_0= ruleINTEGER ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            // InternalSM2.g:3790:3: ( (lv_type_0_0= ruleINTEGER ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )?
            {
            // InternalSM2.g:3790:3: ( (lv_type_0_0= ruleINTEGER ) )
            // InternalSM2.g:3791:4: (lv_type_0_0= ruleINTEGER )
            {
            // InternalSM2.g:3791:4: (lv_type_0_0= ruleINTEGER )
            // InternalSM2.g:3792:5: lv_type_0_0= ruleINTEGER
            {

            					newCompositeNode(grammarAccess.getPropertyIntegerAccess().getTypeINTEGEREnumRuleCall_0_0());
            				
            pushFollow(FOLLOW_65);
            lv_type_0_0=ruleINTEGER();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPropertyIntegerRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_0_0,
            						"org.xtext.SM2.INTEGER");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:3809:3: ( ruleArray )?
            int alt94=2;
            int LA94_0 = input.LA(1);

            if ( ((LA94_0>=148 && LA94_0<=149)) ) {
                alt94=1;
            }
            switch (alt94) {
                case 1 :
                    // InternalSM2.g:3810:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyIntegerAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_66);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:3818:3: (this_CONSTANT_2= RULE_CONSTANT )?
            int alt95=2;
            int LA95_0 = input.LA(1);

            if ( (LA95_0==RULE_CONSTANT) ) {
                alt95=1;
            }
            switch (alt95) {
                case 1 :
                    // InternalSM2.g:3819:4: this_CONSTANT_2= RULE_CONSTANT
                    {
                    this_CONSTANT_2=(Token)match(input,RULE_CONSTANT,FOLLOW_43); 

                    				newLeafNode(this_CONSTANT_2, grammarAccess.getPropertyIntegerAccess().getCONSTANTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:3824:3: ( (lv_visibility_3_0= ruleVisibility ) )?
            int alt96=2;
            int LA96_0 = input.LA(1);

            if ( ((LA96_0>=74 && LA96_0<=75)||LA96_0==193) ) {
                alt96=1;
            }
            switch (alt96) {
                case 1 :
                    // InternalSM2.g:3825:4: (lv_visibility_3_0= ruleVisibility )
                    {
                    // InternalSM2.g:3825:4: (lv_visibility_3_0= ruleVisibility )
                    // InternalSM2.g:3826:5: lv_visibility_3_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyIntegerAccess().getVisibilityVisibilityEnumRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_13);
                    lv_visibility_3_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyIntegerRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_3_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:3843:3: ( (lv_name_4_0= RULE_ID ) )
            // InternalSM2.g:3844:4: (lv_name_4_0= RULE_ID )
            {
            // InternalSM2.g:3844:4: (lv_name_4_0= RULE_ID )
            // InternalSM2.g:3845:5: lv_name_4_0= RULE_ID
            {
            lv_name_4_0=(Token)match(input,RULE_ID,FOLLOW_67); 

            					newLeafNode(lv_name_4_0, grammarAccess.getPropertyIntegerAccess().getNameIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyIntegerRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_4_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_5=(Token)match(input,86,FOLLOW_68); 

            			newLeafNode(otherlv_5, grammarAccess.getPropertyIntegerAccess().getEqualsSignKeyword_5());
            		
            // InternalSM2.g:3865:3: ( (lv_inicialization_6_0= RULE_INT ) )?
            int alt97=2;
            int LA97_0 = input.LA(1);

            if ( (LA97_0==RULE_INT) ) {
                alt97=1;
            }
            switch (alt97) {
                case 1 :
                    // InternalSM2.g:3866:4: (lv_inicialization_6_0= RULE_INT )
                    {
                    // InternalSM2.g:3866:4: (lv_inicialization_6_0= RULE_INT )
                    // InternalSM2.g:3867:5: lv_inicialization_6_0= RULE_INT
                    {
                    lv_inicialization_6_0=(Token)match(input,RULE_INT,FOLLOW_8); 

                    					newLeafNode(lv_inicialization_6_0, grammarAccess.getPropertyIntegerAccess().getInicializationINTTerminalRuleCall_6_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getPropertyIntegerRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"inicialization",
                    						lv_inicialization_6_0,
                    						"org.eclipse.xtext.common.Terminals.INT");
                    				

                    }


                    }
                    break;

            }

            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getPropertyIntegerAccess().getSEMICOLONTerminalRuleCall_7());
            		
            // InternalSM2.g:3887:3: (this_EOLINE_8= RULE_EOLINE )?
            int alt98=2;
            int LA98_0 = input.LA(1);

            if ( (LA98_0==RULE_EOLINE) ) {
                alt98=1;
            }
            switch (alt98) {
                case 1 :
                    // InternalSM2.g:3888:4: this_EOLINE_8= RULE_EOLINE
                    {
                    this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_8, grammarAccess.getPropertyIntegerAccess().getEOLINETerminalRuleCall_8());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyInteger"


    // $ANTLR start "entryRulePropertyUInteger"
    // InternalSM2.g:3897:1: entryRulePropertyUInteger returns [EObject current=null] : iv_rulePropertyUInteger= rulePropertyUInteger EOF ;
    public final EObject entryRulePropertyUInteger() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyUInteger = null;


        try {
            // InternalSM2.g:3897:57: (iv_rulePropertyUInteger= rulePropertyUInteger EOF )
            // InternalSM2.g:3898:2: iv_rulePropertyUInteger= rulePropertyUInteger EOF
            {
             newCompositeNode(grammarAccess.getPropertyUIntegerRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyUInteger=rulePropertyUInteger();

            state._fsp--;

             current =iv_rulePropertyUInteger; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyUInteger"


    // $ANTLR start "rulePropertyUInteger"
    // InternalSM2.g:3904:1: rulePropertyUInteger returns [EObject current=null] : ( ( (lv_type_0_0= ruleUINTEGER ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) ;
    public final EObject rulePropertyUInteger() throws RecognitionException {
        EObject current = null;

        Token this_CONSTANT_2=null;
        Token lv_name_4_0=null;
        Token otherlv_5=null;
        Token lv_inicialization_6_0=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        Enumerator lv_type_0_0 = null;

        Enumerator lv_visibility_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3910:2: ( ( ( (lv_type_0_0= ruleUINTEGER ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) )
            // InternalSM2.g:3911:2: ( ( (lv_type_0_0= ruleUINTEGER ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            {
            // InternalSM2.g:3911:2: ( ( (lv_type_0_0= ruleUINTEGER ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            // InternalSM2.g:3912:3: ( (lv_type_0_0= ruleUINTEGER ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) otherlv_5= '=' ( (lv_inicialization_6_0= RULE_INT ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )?
            {
            // InternalSM2.g:3912:3: ( (lv_type_0_0= ruleUINTEGER ) )
            // InternalSM2.g:3913:4: (lv_type_0_0= ruleUINTEGER )
            {
            // InternalSM2.g:3913:4: (lv_type_0_0= ruleUINTEGER )
            // InternalSM2.g:3914:5: lv_type_0_0= ruleUINTEGER
            {

            					newCompositeNode(grammarAccess.getPropertyUIntegerAccess().getTypeUINTEGEREnumRuleCall_0_0());
            				
            pushFollow(FOLLOW_65);
            lv_type_0_0=ruleUINTEGER();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPropertyUIntegerRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_0_0,
            						"org.xtext.SM2.UINTEGER");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:3931:3: ( ruleArray )?
            int alt99=2;
            int LA99_0 = input.LA(1);

            if ( ((LA99_0>=148 && LA99_0<=149)) ) {
                alt99=1;
            }
            switch (alt99) {
                case 1 :
                    // InternalSM2.g:3932:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyUIntegerAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_66);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:3940:3: (this_CONSTANT_2= RULE_CONSTANT )?
            int alt100=2;
            int LA100_0 = input.LA(1);

            if ( (LA100_0==RULE_CONSTANT) ) {
                alt100=1;
            }
            switch (alt100) {
                case 1 :
                    // InternalSM2.g:3941:4: this_CONSTANT_2= RULE_CONSTANT
                    {
                    this_CONSTANT_2=(Token)match(input,RULE_CONSTANT,FOLLOW_43); 

                    				newLeafNode(this_CONSTANT_2, grammarAccess.getPropertyUIntegerAccess().getCONSTANTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:3946:3: ( (lv_visibility_3_0= ruleVisibility ) )?
            int alt101=2;
            int LA101_0 = input.LA(1);

            if ( ((LA101_0>=74 && LA101_0<=75)||LA101_0==193) ) {
                alt101=1;
            }
            switch (alt101) {
                case 1 :
                    // InternalSM2.g:3947:4: (lv_visibility_3_0= ruleVisibility )
                    {
                    // InternalSM2.g:3947:4: (lv_visibility_3_0= ruleVisibility )
                    // InternalSM2.g:3948:5: lv_visibility_3_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyUIntegerAccess().getVisibilityVisibilityEnumRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_13);
                    lv_visibility_3_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyUIntegerRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_3_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:3965:3: ( (lv_name_4_0= RULE_ID ) )
            // InternalSM2.g:3966:4: (lv_name_4_0= RULE_ID )
            {
            // InternalSM2.g:3966:4: (lv_name_4_0= RULE_ID )
            // InternalSM2.g:3967:5: lv_name_4_0= RULE_ID
            {
            lv_name_4_0=(Token)match(input,RULE_ID,FOLLOW_67); 

            					newLeafNode(lv_name_4_0, grammarAccess.getPropertyUIntegerAccess().getNameIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyUIntegerRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_4_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_5=(Token)match(input,86,FOLLOW_68); 

            			newLeafNode(otherlv_5, grammarAccess.getPropertyUIntegerAccess().getEqualsSignKeyword_5());
            		
            // InternalSM2.g:3987:3: ( (lv_inicialization_6_0= RULE_INT ) )?
            int alt102=2;
            int LA102_0 = input.LA(1);

            if ( (LA102_0==RULE_INT) ) {
                alt102=1;
            }
            switch (alt102) {
                case 1 :
                    // InternalSM2.g:3988:4: (lv_inicialization_6_0= RULE_INT )
                    {
                    // InternalSM2.g:3988:4: (lv_inicialization_6_0= RULE_INT )
                    // InternalSM2.g:3989:5: lv_inicialization_6_0= RULE_INT
                    {
                    lv_inicialization_6_0=(Token)match(input,RULE_INT,FOLLOW_8); 

                    					newLeafNode(lv_inicialization_6_0, grammarAccess.getPropertyUIntegerAccess().getInicializationINTTerminalRuleCall_6_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getPropertyUIntegerRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"inicialization",
                    						lv_inicialization_6_0,
                    						"org.eclipse.xtext.common.Terminals.INT");
                    				

                    }


                    }
                    break;

            }

            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getPropertyUIntegerAccess().getSEMICOLONTerminalRuleCall_7());
            		
            // InternalSM2.g:4009:3: (this_EOLINE_8= RULE_EOLINE )?
            int alt103=2;
            int LA103_0 = input.LA(1);

            if ( (LA103_0==RULE_EOLINE) ) {
                alt103=1;
            }
            switch (alt103) {
                case 1 :
                    // InternalSM2.g:4010:4: this_EOLINE_8= RULE_EOLINE
                    {
                    this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_8, grammarAccess.getPropertyUIntegerAccess().getEOLINETerminalRuleCall_8());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyUInteger"


    // $ANTLR start "entryRulePropertyFloat"
    // InternalSM2.g:4019:1: entryRulePropertyFloat returns [EObject current=null] : iv_rulePropertyFloat= rulePropertyFloat EOF ;
    public final EObject entryRulePropertyFloat() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyFloat = null;


        try {
            // InternalSM2.g:4019:54: (iv_rulePropertyFloat= rulePropertyFloat EOF )
            // InternalSM2.g:4020:2: iv_rulePropertyFloat= rulePropertyFloat EOF
            {
             newCompositeNode(grammarAccess.getPropertyFloatRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyFloat=rulePropertyFloat();

            state._fsp--;

             current =iv_rulePropertyFloat; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyFloat"


    // $ANTLR start "rulePropertyFloat"
    // InternalSM2.g:4026:1: rulePropertyFloat returns [EObject current=null] : ( ( (lv_type_0_0= 'float' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_FLOAT ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) ;
    public final EObject rulePropertyFloat() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token this_CONSTANT_2=null;
        Token lv_name_5_0=null;
        Token otherlv_6=null;
        Token lv_inicialization_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Enumerator lv_visibility_3_0 = null;

        Enumerator lv_storageData_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4032:2: ( ( ( (lv_type_0_0= 'float' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_FLOAT ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) )
            // InternalSM2.g:4033:2: ( ( (lv_type_0_0= 'float' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_FLOAT ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            {
            // InternalSM2.g:4033:2: ( ( (lv_type_0_0= 'float' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_FLOAT ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            // InternalSM2.g:4034:3: ( (lv_type_0_0= 'float' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_FLOAT ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )?
            {
            // InternalSM2.g:4034:3: ( (lv_type_0_0= 'float' ) )
            // InternalSM2.g:4035:4: (lv_type_0_0= 'float' )
            {
            // InternalSM2.g:4035:4: (lv_type_0_0= 'float' )
            // InternalSM2.g:4036:5: lv_type_0_0= 'float'
            {
            lv_type_0_0=(Token)match(input,152,FOLLOW_69); 

            					newLeafNode(lv_type_0_0, grammarAccess.getPropertyFloatAccess().getTypeFloatKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyFloatRule());
            					}
            					setWithLastConsumed(current, "type", lv_type_0_0, "float");
            				

            }


            }

            // InternalSM2.g:4048:3: ( ruleArray )?
            int alt104=2;
            int LA104_0 = input.LA(1);

            if ( ((LA104_0>=148 && LA104_0<=149)) ) {
                alt104=1;
            }
            switch (alt104) {
                case 1 :
                    // InternalSM2.g:4049:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyFloatAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_70);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:4057:3: (this_CONSTANT_2= RULE_CONSTANT )?
            int alt105=2;
            int LA105_0 = input.LA(1);

            if ( (LA105_0==RULE_CONSTANT) ) {
                alt105=1;
            }
            switch (alt105) {
                case 1 :
                    // InternalSM2.g:4058:4: this_CONSTANT_2= RULE_CONSTANT
                    {
                    this_CONSTANT_2=(Token)match(input,RULE_CONSTANT,FOLLOW_71); 

                    				newLeafNode(this_CONSTANT_2, grammarAccess.getPropertyFloatAccess().getCONSTANTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:4063:3: ( (lv_visibility_3_0= ruleVisibility ) )?
            int alt106=2;
            int LA106_0 = input.LA(1);

            if ( ((LA106_0>=74 && LA106_0<=75)||LA106_0==193) ) {
                alt106=1;
            }
            switch (alt106) {
                case 1 :
                    // InternalSM2.g:4064:4: (lv_visibility_3_0= ruleVisibility )
                    {
                    // InternalSM2.g:4064:4: (lv_visibility_3_0= ruleVisibility )
                    // InternalSM2.g:4065:5: lv_visibility_3_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyFloatAccess().getVisibilityVisibilityEnumRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_63);
                    lv_visibility_3_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyFloatRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_3_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:4082:3: ( (lv_storageData_4_0= ruleStorageData ) )?
            int alt107=2;
            int LA107_0 = input.LA(1);

            if ( ((LA107_0>=191 && LA107_0<=192)) ) {
                alt107=1;
            }
            switch (alt107) {
                case 1 :
                    // InternalSM2.g:4083:4: (lv_storageData_4_0= ruleStorageData )
                    {
                    // InternalSM2.g:4083:4: (lv_storageData_4_0= ruleStorageData )
                    // InternalSM2.g:4084:5: lv_storageData_4_0= ruleStorageData
                    {

                    					newCompositeNode(grammarAccess.getPropertyFloatAccess().getStorageDataStorageDataEnumRuleCall_4_0());
                    				
                    pushFollow(FOLLOW_13);
                    lv_storageData_4_0=ruleStorageData();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyFloatRule());
                    					}
                    					set(
                    						current,
                    						"storageData",
                    						lv_storageData_4_0,
                    						"org.xtext.SM2.StorageData");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:4101:3: ( (lv_name_5_0= RULE_ID ) )
            // InternalSM2.g:4102:4: (lv_name_5_0= RULE_ID )
            {
            // InternalSM2.g:4102:4: (lv_name_5_0= RULE_ID )
            // InternalSM2.g:4103:5: lv_name_5_0= RULE_ID
            {
            lv_name_5_0=(Token)match(input,RULE_ID,FOLLOW_52); 

            					newLeafNode(lv_name_5_0, grammarAccess.getPropertyFloatAccess().getNameIDTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyFloatRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_5_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:4119:3: (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_FLOAT ) ) )?
            int alt108=2;
            int LA108_0 = input.LA(1);

            if ( (LA108_0==86) ) {
                alt108=1;
            }
            switch (alt108) {
                case 1 :
                    // InternalSM2.g:4120:4: otherlv_6= '=' ( (lv_inicialization_7_0= RULE_FLOAT ) )
                    {
                    otherlv_6=(Token)match(input,86,FOLLOW_72); 

                    				newLeafNode(otherlv_6, grammarAccess.getPropertyFloatAccess().getEqualsSignKeyword_6_0());
                    			
                    // InternalSM2.g:4124:4: ( (lv_inicialization_7_0= RULE_FLOAT ) )
                    // InternalSM2.g:4125:5: (lv_inicialization_7_0= RULE_FLOAT )
                    {
                    // InternalSM2.g:4125:5: (lv_inicialization_7_0= RULE_FLOAT )
                    // InternalSM2.g:4126:6: lv_inicialization_7_0= RULE_FLOAT
                    {
                    lv_inicialization_7_0=(Token)match(input,RULE_FLOAT,FOLLOW_8); 

                    						newLeafNode(lv_inicialization_7_0, grammarAccess.getPropertyFloatAccess().getInicializationFLOATTerminalRuleCall_6_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyFloatRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"inicialization",
                    							lv_inicialization_7_0,
                    							"org.xtext.SM2.FLOAT");
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getPropertyFloatAccess().getSEMICOLONTerminalRuleCall_7());
            		
            // InternalSM2.g:4147:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt109=2;
            int LA109_0 = input.LA(1);

            if ( (LA109_0==RULE_EOLINE) ) {
                alt109=1;
            }
            switch (alt109) {
                case 1 :
                    // InternalSM2.g:4148:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_9, grammarAccess.getPropertyFloatAccess().getEOLINETerminalRuleCall_8());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyFloat"


    // $ANTLR start "entryRulePropertyBoolean"
    // InternalSM2.g:4157:1: entryRulePropertyBoolean returns [EObject current=null] : iv_rulePropertyBoolean= rulePropertyBoolean EOF ;
    public final EObject entryRulePropertyBoolean() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyBoolean = null;


        try {
            // InternalSM2.g:4157:56: (iv_rulePropertyBoolean= rulePropertyBoolean EOF )
            // InternalSM2.g:4158:2: iv_rulePropertyBoolean= rulePropertyBoolean EOF
            {
             newCompositeNode(grammarAccess.getPropertyBooleanRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyBoolean=rulePropertyBoolean();

            state._fsp--;

             current =iv_rulePropertyBoolean; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyBoolean"


    // $ANTLR start "rulePropertyBoolean"
    // InternalSM2.g:4164:1: rulePropertyBoolean returns [EObject current=null] : ( ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) ;
    public final EObject rulePropertyBoolean() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_0=null;
        Token this_CONSTANT_2=null;
        Token lv_name_5_0=null;
        Token otherlv_6=null;
        Token lv_inicialization_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Enumerator lv_visibility_3_0 = null;

        Enumerator lv_storageData_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4170:2: ( ( ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) )
            // InternalSM2.g:4171:2: ( ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            {
            // InternalSM2.g:4171:2: ( ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            // InternalSM2.g:4172:3: ( (lv_type_0_0= 'bool' ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_BOOLVALUE ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )?
            {
            // InternalSM2.g:4172:3: ( (lv_type_0_0= 'bool' ) )
            // InternalSM2.g:4173:4: (lv_type_0_0= 'bool' )
            {
            // InternalSM2.g:4173:4: (lv_type_0_0= 'bool' )
            // InternalSM2.g:4174:5: lv_type_0_0= 'bool'
            {
            lv_type_0_0=(Token)match(input,147,FOLLOW_69); 

            					newLeafNode(lv_type_0_0, grammarAccess.getPropertyBooleanAccess().getTypeBoolKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyBooleanRule());
            					}
            					setWithLastConsumed(current, "type", lv_type_0_0, "bool");
            				

            }


            }

            // InternalSM2.g:4186:3: ( ruleArray )?
            int alt110=2;
            int LA110_0 = input.LA(1);

            if ( ((LA110_0>=148 && LA110_0<=149)) ) {
                alt110=1;
            }
            switch (alt110) {
                case 1 :
                    // InternalSM2.g:4187:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyBooleanAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_70);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:4195:3: (this_CONSTANT_2= RULE_CONSTANT )?
            int alt111=2;
            int LA111_0 = input.LA(1);

            if ( (LA111_0==RULE_CONSTANT) ) {
                alt111=1;
            }
            switch (alt111) {
                case 1 :
                    // InternalSM2.g:4196:4: this_CONSTANT_2= RULE_CONSTANT
                    {
                    this_CONSTANT_2=(Token)match(input,RULE_CONSTANT,FOLLOW_71); 

                    				newLeafNode(this_CONSTANT_2, grammarAccess.getPropertyBooleanAccess().getCONSTANTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:4201:3: ( (lv_visibility_3_0= ruleVisibility ) )?
            int alt112=2;
            int LA112_0 = input.LA(1);

            if ( ((LA112_0>=74 && LA112_0<=75)||LA112_0==193) ) {
                alt112=1;
            }
            switch (alt112) {
                case 1 :
                    // InternalSM2.g:4202:4: (lv_visibility_3_0= ruleVisibility )
                    {
                    // InternalSM2.g:4202:4: (lv_visibility_3_0= ruleVisibility )
                    // InternalSM2.g:4203:5: lv_visibility_3_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyBooleanAccess().getVisibilityVisibilityEnumRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_63);
                    lv_visibility_3_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyBooleanRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_3_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:4220:3: ( (lv_storageData_4_0= ruleStorageData ) )?
            int alt113=2;
            int LA113_0 = input.LA(1);

            if ( ((LA113_0>=191 && LA113_0<=192)) ) {
                alt113=1;
            }
            switch (alt113) {
                case 1 :
                    // InternalSM2.g:4221:4: (lv_storageData_4_0= ruleStorageData )
                    {
                    // InternalSM2.g:4221:4: (lv_storageData_4_0= ruleStorageData )
                    // InternalSM2.g:4222:5: lv_storageData_4_0= ruleStorageData
                    {

                    					newCompositeNode(grammarAccess.getPropertyBooleanAccess().getStorageDataStorageDataEnumRuleCall_4_0());
                    				
                    pushFollow(FOLLOW_13);
                    lv_storageData_4_0=ruleStorageData();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyBooleanRule());
                    					}
                    					set(
                    						current,
                    						"storageData",
                    						lv_storageData_4_0,
                    						"org.xtext.SM2.StorageData");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:4239:3: ( (lv_name_5_0= RULE_ID ) )
            // InternalSM2.g:4240:4: (lv_name_5_0= RULE_ID )
            {
            // InternalSM2.g:4240:4: (lv_name_5_0= RULE_ID )
            // InternalSM2.g:4241:5: lv_name_5_0= RULE_ID
            {
            lv_name_5_0=(Token)match(input,RULE_ID,FOLLOW_52); 

            					newLeafNode(lv_name_5_0, grammarAccess.getPropertyBooleanAccess().getNameIDTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyBooleanRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_5_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:4257:3: (otherlv_6= '=' ( (lv_inicialization_7_0= RULE_BOOLVALUE ) ) )?
            int alt114=2;
            int LA114_0 = input.LA(1);

            if ( (LA114_0==86) ) {
                alt114=1;
            }
            switch (alt114) {
                case 1 :
                    // InternalSM2.g:4258:4: otherlv_6= '=' ( (lv_inicialization_7_0= RULE_BOOLVALUE ) )
                    {
                    otherlv_6=(Token)match(input,86,FOLLOW_73); 

                    				newLeafNode(otherlv_6, grammarAccess.getPropertyBooleanAccess().getEqualsSignKeyword_6_0());
                    			
                    // InternalSM2.g:4262:4: ( (lv_inicialization_7_0= RULE_BOOLVALUE ) )
                    // InternalSM2.g:4263:5: (lv_inicialization_7_0= RULE_BOOLVALUE )
                    {
                    // InternalSM2.g:4263:5: (lv_inicialization_7_0= RULE_BOOLVALUE )
                    // InternalSM2.g:4264:6: lv_inicialization_7_0= RULE_BOOLVALUE
                    {
                    lv_inicialization_7_0=(Token)match(input,RULE_BOOLVALUE,FOLLOW_8); 

                    						newLeafNode(lv_inicialization_7_0, grammarAccess.getPropertyBooleanAccess().getInicializationBOOLVALUETerminalRuleCall_6_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyBooleanRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"inicialization",
                    							lv_inicialization_7_0,
                    							"org.xtext.SM2.BOOLVALUE");
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getPropertyBooleanAccess().getSEMICOLONTerminalRuleCall_7());
            		
            // InternalSM2.g:4285:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt115=2;
            int LA115_0 = input.LA(1);

            if ( (LA115_0==RULE_EOLINE) ) {
                alt115=1;
            }
            switch (alt115) {
                case 1 :
                    // InternalSM2.g:4286:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_9, grammarAccess.getPropertyBooleanAccess().getEOLINETerminalRuleCall_8());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyBoolean"


    // $ANTLR start "entryRulePropertyAddress"
    // InternalSM2.g:4295:1: entryRulePropertyAddress returns [EObject current=null] : iv_rulePropertyAddress= rulePropertyAddress EOF ;
    public final EObject entryRulePropertyAddress() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyAddress = null;


        try {
            // InternalSM2.g:4295:56: (iv_rulePropertyAddress= rulePropertyAddress EOF )
            // InternalSM2.g:4296:2: iv_rulePropertyAddress= rulePropertyAddress EOF
            {
             newCompositeNode(grammarAccess.getPropertyAddressRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyAddress=rulePropertyAddress();

            state._fsp--;

             current =iv_rulePropertyAddress; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyAddress"


    // $ANTLR start "rulePropertyAddress"
    // InternalSM2.g:4302:1: rulePropertyAddress returns [EObject current=null] : ( ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) ;
    public final EObject rulePropertyAddress() throws RecognitionException {
        EObject current = null;

        Token this_CONSTANT_2=null;
        Token lv_name_4_0=null;
        Token otherlv_5=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        AntlrDatatypeRuleToken lv_type_0_0 = null;

        Enumerator lv_visibility_3_0 = null;

        AntlrDatatypeRuleToken lv_defaultValue_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4308:2: ( ( ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) )
            // InternalSM2.g:4309:2: ( ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            {
            // InternalSM2.g:4309:2: ( ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            // InternalSM2.g:4310:3: ( (lv_type_0_0= ruleTypeAddress ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_name_4_0= RULE_ID ) ) (otherlv_5= '=' ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) ) )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )?
            {
            // InternalSM2.g:4310:3: ( (lv_type_0_0= ruleTypeAddress ) )
            // InternalSM2.g:4311:4: (lv_type_0_0= ruleTypeAddress )
            {
            // InternalSM2.g:4311:4: (lv_type_0_0= ruleTypeAddress )
            // InternalSM2.g:4312:5: lv_type_0_0= ruleTypeAddress
            {

            					newCompositeNode(grammarAccess.getPropertyAddressAccess().getTypeTypeAddressParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_65);
            lv_type_0_0=ruleTypeAddress();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_0_0,
            						"org.xtext.SM2.TypeAddress");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:4329:3: ( ruleArray )?
            int alt116=2;
            int LA116_0 = input.LA(1);

            if ( ((LA116_0>=148 && LA116_0<=149)) ) {
                alt116=1;
            }
            switch (alt116) {
                case 1 :
                    // InternalSM2.g:4330:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyAddressAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_66);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:4338:3: (this_CONSTANT_2= RULE_CONSTANT )?
            int alt117=2;
            int LA117_0 = input.LA(1);

            if ( (LA117_0==RULE_CONSTANT) ) {
                alt117=1;
            }
            switch (alt117) {
                case 1 :
                    // InternalSM2.g:4339:4: this_CONSTANT_2= RULE_CONSTANT
                    {
                    this_CONSTANT_2=(Token)match(input,RULE_CONSTANT,FOLLOW_43); 

                    				newLeafNode(this_CONSTANT_2, grammarAccess.getPropertyAddressAccess().getCONSTANTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:4344:3: ( (lv_visibility_3_0= ruleVisibility ) )?
            int alt118=2;
            int LA118_0 = input.LA(1);

            if ( ((LA118_0>=74 && LA118_0<=75)||LA118_0==193) ) {
                alt118=1;
            }
            switch (alt118) {
                case 1 :
                    // InternalSM2.g:4345:4: (lv_visibility_3_0= ruleVisibility )
                    {
                    // InternalSM2.g:4345:4: (lv_visibility_3_0= ruleVisibility )
                    // InternalSM2.g:4346:5: lv_visibility_3_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyAddressAccess().getVisibilityVisibilityEnumRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_13);
                    lv_visibility_3_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_3_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:4363:3: ( (lv_name_4_0= RULE_ID ) )
            // InternalSM2.g:4364:4: (lv_name_4_0= RULE_ID )
            {
            // InternalSM2.g:4364:4: (lv_name_4_0= RULE_ID )
            // InternalSM2.g:4365:5: lv_name_4_0= RULE_ID
            {
            lv_name_4_0=(Token)match(input,RULE_ID,FOLLOW_52); 

            					newLeafNode(lv_name_4_0, grammarAccess.getPropertyAddressAccess().getNameIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyAddressRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_4_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:4381:3: (otherlv_5= '=' ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) ) )?
            int alt119=2;
            int LA119_0 = input.LA(1);

            if ( (LA119_0==86) ) {
                alt119=1;
            }
            switch (alt119) {
                case 1 :
                    // InternalSM2.g:4382:4: otherlv_5= '=' ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) )
                    {
                    otherlv_5=(Token)match(input,86,FOLLOW_74); 

                    				newLeafNode(otherlv_5, grammarAccess.getPropertyAddressAccess().getEqualsSignKeyword_5_0());
                    			
                    // InternalSM2.g:4386:4: ( (lv_defaultValue_6_0= ruleHexadecimalExpression ) )
                    // InternalSM2.g:4387:5: (lv_defaultValue_6_0= ruleHexadecimalExpression )
                    {
                    // InternalSM2.g:4387:5: (lv_defaultValue_6_0= ruleHexadecimalExpression )
                    // InternalSM2.g:4388:6: lv_defaultValue_6_0= ruleHexadecimalExpression
                    {

                    						newCompositeNode(grammarAccess.getPropertyAddressAccess().getDefaultValueHexadecimalExpressionParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_8);
                    lv_defaultValue_6_0=ruleHexadecimalExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                    						}
                    						set(
                    							current,
                    							"defaultValue",
                    							lv_defaultValue_6_0,
                    							"org.xtext.SM2.HexadecimalExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getPropertyAddressAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:4410:3: (this_EOLINE_8= RULE_EOLINE )?
            int alt120=2;
            int LA120_0 = input.LA(1);

            if ( (LA120_0==RULE_EOLINE) ) {
                alt120=1;
            }
            switch (alt120) {
                case 1 :
                    // InternalSM2.g:4411:4: this_EOLINE_8= RULE_EOLINE
                    {
                    this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_8, grammarAccess.getPropertyAddressAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyAddress"


    // $ANTLR start "entryRuleHexadecimalExpression"
    // InternalSM2.g:4420:1: entryRuleHexadecimalExpression returns [String current=null] : iv_ruleHexadecimalExpression= ruleHexadecimalExpression EOF ;
    public final String entryRuleHexadecimalExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleHexadecimalExpression = null;


        try {
            // InternalSM2.g:4420:61: (iv_ruleHexadecimalExpression= ruleHexadecimalExpression EOF )
            // InternalSM2.g:4421:2: iv_ruleHexadecimalExpression= ruleHexadecimalExpression EOF
            {
             newCompositeNode(grammarAccess.getHexadecimalExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleHexadecimalExpression=ruleHexadecimalExpression();

            state._fsp--;

             current =iv_ruleHexadecimalExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleHexadecimalExpression"


    // $ANTLR start "ruleHexadecimalExpression"
    // InternalSM2.g:4427:1: ruleHexadecimalExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= '0x' this_HEXEXPRESSION_1= RULE_HEXEXPRESSION ) ;
    public final AntlrDatatypeRuleToken ruleHexadecimalExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_HEXEXPRESSION_1=null;


        	enterRule();

        try {
            // InternalSM2.g:4433:2: ( (kw= '0x' this_HEXEXPRESSION_1= RULE_HEXEXPRESSION ) )
            // InternalSM2.g:4434:2: (kw= '0x' this_HEXEXPRESSION_1= RULE_HEXEXPRESSION )
            {
            // InternalSM2.g:4434:2: (kw= '0x' this_HEXEXPRESSION_1= RULE_HEXEXPRESSION )
            // InternalSM2.g:4435:3: kw= '0x' this_HEXEXPRESSION_1= RULE_HEXEXPRESSION
            {
            kw=(Token)match(input,153,FOLLOW_75); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getHexadecimalExpressionAccess().getXKeyword_0());
            		
            this_HEXEXPRESSION_1=(Token)match(input,RULE_HEXEXPRESSION,FOLLOW_2); 

            			current.merge(this_HEXEXPRESSION_1);
            		

            			newLeafNode(this_HEXEXPRESSION_1, grammarAccess.getHexadecimalExpressionAccess().getHEXEXPRESSIONTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleHexadecimalExpression"


    // $ANTLR start "entryRulePropertyBytes"
    // InternalSM2.g:4451:1: entryRulePropertyBytes returns [EObject current=null] : iv_rulePropertyBytes= rulePropertyBytes EOF ;
    public final EObject entryRulePropertyBytes() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyBytes = null;


        try {
            // InternalSM2.g:4451:54: (iv_rulePropertyBytes= rulePropertyBytes EOF )
            // InternalSM2.g:4452:2: iv_rulePropertyBytes= rulePropertyBytes EOF
            {
             newCompositeNode(grammarAccess.getPropertyBytesRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyBytes=rulePropertyBytes();

            state._fsp--;

             current =iv_rulePropertyBytes; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyBytes"


    // $ANTLR start "rulePropertyBytes"
    // InternalSM2.g:4458:1: rulePropertyBytes returns [EObject current=null] : ( ( (lv_type_0_0= ruleBYTES ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= RULE_STRING ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) ;
    public final EObject rulePropertyBytes() throws RecognitionException {
        EObject current = null;

        Token this_CONSTANT_2=null;
        Token lv_name_5_0=null;
        Token otherlv_6=null;
        Token lv_defaultValueLiteral_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Enumerator lv_type_0_0 = null;

        Enumerator lv_visibility_3_0 = null;

        Enumerator lv_storageData_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4464:2: ( ( ( (lv_type_0_0= ruleBYTES ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= RULE_STRING ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? ) )
            // InternalSM2.g:4465:2: ( ( (lv_type_0_0= ruleBYTES ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= RULE_STRING ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            {
            // InternalSM2.g:4465:2: ( ( (lv_type_0_0= ruleBYTES ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= RULE_STRING ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? )
            // InternalSM2.g:4466:3: ( (lv_type_0_0= ruleBYTES ) ) ( ruleArray )? (this_CONSTANT_2= RULE_CONSTANT )? ( (lv_visibility_3_0= ruleVisibility ) )? ( (lv_storageData_4_0= ruleStorageData ) )? ( (lv_name_5_0= RULE_ID ) ) (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= RULE_STRING ) ) )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )?
            {
            // InternalSM2.g:4466:3: ( (lv_type_0_0= ruleBYTES ) )
            // InternalSM2.g:4467:4: (lv_type_0_0= ruleBYTES )
            {
            // InternalSM2.g:4467:4: (lv_type_0_0= ruleBYTES )
            // InternalSM2.g:4468:5: lv_type_0_0= ruleBYTES
            {

            					newCompositeNode(grammarAccess.getPropertyBytesAccess().getTypeBYTESEnumRuleCall_0_0());
            				
            pushFollow(FOLLOW_69);
            lv_type_0_0=ruleBYTES();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_0_0,
            						"org.xtext.SM2.BYTES");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:4485:3: ( ruleArray )?
            int alt121=2;
            int LA121_0 = input.LA(1);

            if ( ((LA121_0>=148 && LA121_0<=149)) ) {
                alt121=1;
            }
            switch (alt121) {
                case 1 :
                    // InternalSM2.g:4486:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyBytesAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_70);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:4494:3: (this_CONSTANT_2= RULE_CONSTANT )?
            int alt122=2;
            int LA122_0 = input.LA(1);

            if ( (LA122_0==RULE_CONSTANT) ) {
                alt122=1;
            }
            switch (alt122) {
                case 1 :
                    // InternalSM2.g:4495:4: this_CONSTANT_2= RULE_CONSTANT
                    {
                    this_CONSTANT_2=(Token)match(input,RULE_CONSTANT,FOLLOW_71); 

                    				newLeafNode(this_CONSTANT_2, grammarAccess.getPropertyBytesAccess().getCONSTANTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:4500:3: ( (lv_visibility_3_0= ruleVisibility ) )?
            int alt123=2;
            int LA123_0 = input.LA(1);

            if ( ((LA123_0>=74 && LA123_0<=75)||LA123_0==193) ) {
                alt123=1;
            }
            switch (alt123) {
                case 1 :
                    // InternalSM2.g:4501:4: (lv_visibility_3_0= ruleVisibility )
                    {
                    // InternalSM2.g:4501:4: (lv_visibility_3_0= ruleVisibility )
                    // InternalSM2.g:4502:5: lv_visibility_3_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyBytesAccess().getVisibilityVisibilityEnumRuleCall_3_0());
                    				
                    pushFollow(FOLLOW_63);
                    lv_visibility_3_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_3_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:4519:3: ( (lv_storageData_4_0= ruleStorageData ) )?
            int alt124=2;
            int LA124_0 = input.LA(1);

            if ( ((LA124_0>=191 && LA124_0<=192)) ) {
                alt124=1;
            }
            switch (alt124) {
                case 1 :
                    // InternalSM2.g:4520:4: (lv_storageData_4_0= ruleStorageData )
                    {
                    // InternalSM2.g:4520:4: (lv_storageData_4_0= ruleStorageData )
                    // InternalSM2.g:4521:5: lv_storageData_4_0= ruleStorageData
                    {

                    					newCompositeNode(grammarAccess.getPropertyBytesAccess().getStorageDataStorageDataEnumRuleCall_4_0());
                    				
                    pushFollow(FOLLOW_13);
                    lv_storageData_4_0=ruleStorageData();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                    					}
                    					set(
                    						current,
                    						"storageData",
                    						lv_storageData_4_0,
                    						"org.xtext.SM2.StorageData");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:4538:3: ( (lv_name_5_0= RULE_ID ) )
            // InternalSM2.g:4539:4: (lv_name_5_0= RULE_ID )
            {
            // InternalSM2.g:4539:4: (lv_name_5_0= RULE_ID )
            // InternalSM2.g:4540:5: lv_name_5_0= RULE_ID
            {
            lv_name_5_0=(Token)match(input,RULE_ID,FOLLOW_52); 

            					newLeafNode(lv_name_5_0, grammarAccess.getPropertyBytesAccess().getNameIDTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyBytesRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_5_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:4556:3: (otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= RULE_STRING ) ) )?
            int alt125=2;
            int LA125_0 = input.LA(1);

            if ( (LA125_0==86) ) {
                alt125=1;
            }
            switch (alt125) {
                case 1 :
                    // InternalSM2.g:4557:4: otherlv_6= '=' ( (lv_defaultValueLiteral_7_0= RULE_STRING ) )
                    {
                    otherlv_6=(Token)match(input,86,FOLLOW_10); 

                    				newLeafNode(otherlv_6, grammarAccess.getPropertyBytesAccess().getEqualsSignKeyword_6_0());
                    			
                    // InternalSM2.g:4561:4: ( (lv_defaultValueLiteral_7_0= RULE_STRING ) )
                    // InternalSM2.g:4562:5: (lv_defaultValueLiteral_7_0= RULE_STRING )
                    {
                    // InternalSM2.g:4562:5: (lv_defaultValueLiteral_7_0= RULE_STRING )
                    // InternalSM2.g:4563:6: lv_defaultValueLiteral_7_0= RULE_STRING
                    {
                    lv_defaultValueLiteral_7_0=(Token)match(input,RULE_STRING,FOLLOW_8); 

                    						newLeafNode(lv_defaultValueLiteral_7_0, grammarAccess.getPropertyBytesAccess().getDefaultValueLiteralSTRINGTerminalRuleCall_6_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyBytesRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"defaultValueLiteral",
                    							lv_defaultValueLiteral_7_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getPropertyBytesAccess().getSEMICOLONTerminalRuleCall_7());
            		
            // InternalSM2.g:4584:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt126=2;
            int LA126_0 = input.LA(1);

            if ( (LA126_0==RULE_EOLINE) ) {
                alt126=1;
            }
            switch (alt126) {
                case 1 :
                    // InternalSM2.g:4585:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_9, grammarAccess.getPropertyBytesAccess().getEOLINETerminalRuleCall_8());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyBytes"


    // $ANTLR start "entryRulePropertyStruct"
    // InternalSM2.g:4594:1: entryRulePropertyStruct returns [EObject current=null] : iv_rulePropertyStruct= rulePropertyStruct EOF ;
    public final EObject entryRulePropertyStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyStruct = null;


        try {
            // InternalSM2.g:4594:55: (iv_rulePropertyStruct= rulePropertyStruct EOF )
            // InternalSM2.g:4595:2: iv_rulePropertyStruct= rulePropertyStruct EOF
            {
             newCompositeNode(grammarAccess.getPropertyStructRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePropertyStruct=rulePropertyStruct();

            state._fsp--;

             current =iv_rulePropertyStruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyStruct"


    // $ANTLR start "rulePropertyStruct"
    // InternalSM2.g:4601:1: rulePropertyStruct returns [EObject current=null] : ( ( (lv_assignedStruct_0_0= ruleStruct ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_NEW ) ) this_STRING_6= RULE_STRING )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) ;
    public final EObject rulePropertyStruct() throws RecognitionException {
        EObject current = null;

        Token lv_name_3_0=null;
        Token otherlv_4=null;
        Token lv_inicialization_5_0=null;
        Token this_STRING_6=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        EObject lv_assignedStruct_0_0 = null;

        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4607:2: ( ( ( (lv_assignedStruct_0_0= ruleStruct ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_NEW ) ) this_STRING_6= RULE_STRING )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) )
            // InternalSM2.g:4608:2: ( ( (lv_assignedStruct_0_0= ruleStruct ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_NEW ) ) this_STRING_6= RULE_STRING )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            {
            // InternalSM2.g:4608:2: ( ( (lv_assignedStruct_0_0= ruleStruct ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_NEW ) ) this_STRING_6= RULE_STRING )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            // InternalSM2.g:4609:3: ( (lv_assignedStruct_0_0= ruleStruct ) ) ( ruleArray )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_name_3_0= RULE_ID ) ) (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_NEW ) ) this_STRING_6= RULE_STRING )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )?
            {
            // InternalSM2.g:4609:3: ( (lv_assignedStruct_0_0= ruleStruct ) )
            // InternalSM2.g:4610:4: (lv_assignedStruct_0_0= ruleStruct )
            {
            // InternalSM2.g:4610:4: (lv_assignedStruct_0_0= ruleStruct )
            // InternalSM2.g:4611:5: lv_assignedStruct_0_0= ruleStruct
            {

            					newCompositeNode(grammarAccess.getPropertyStructAccess().getAssignedStructStructParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_76);
            lv_assignedStruct_0_0=ruleStruct();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPropertyStructRule());
            					}
            					set(
            						current,
            						"assignedStruct",
            						lv_assignedStruct_0_0,
            						"org.xtext.SM2.Struct");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:4628:3: ( ruleArray )?
            int alt127=2;
            int LA127_0 = input.LA(1);

            if ( ((LA127_0>=148 && LA127_0<=149)) ) {
                alt127=1;
            }
            switch (alt127) {
                case 1 :
                    // InternalSM2.g:4629:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getPropertyStructAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_43);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:4637:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt128=2;
            int LA128_0 = input.LA(1);

            if ( ((LA128_0>=74 && LA128_0<=75)||LA128_0==193) ) {
                alt128=1;
            }
            switch (alt128) {
                case 1 :
                    // InternalSM2.g:4638:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:4638:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:4639:5: lv_visibility_2_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyStructAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_13);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyStructRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_2_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:4656:3: ( (lv_name_3_0= RULE_ID ) )
            // InternalSM2.g:4657:4: (lv_name_3_0= RULE_ID )
            {
            // InternalSM2.g:4657:4: (lv_name_3_0= RULE_ID )
            // InternalSM2.g:4658:5: lv_name_3_0= RULE_ID
            {
            lv_name_3_0=(Token)match(input,RULE_ID,FOLLOW_52); 

            					newLeafNode(lv_name_3_0, grammarAccess.getPropertyStructAccess().getNameIDTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyStructRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_3_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:4674:3: (otherlv_4= '=' ( (lv_inicialization_5_0= RULE_NEW ) ) this_STRING_6= RULE_STRING )?
            int alt129=2;
            int LA129_0 = input.LA(1);

            if ( (LA129_0==86) ) {
                alt129=1;
            }
            switch (alt129) {
                case 1 :
                    // InternalSM2.g:4675:4: otherlv_4= '=' ( (lv_inicialization_5_0= RULE_NEW ) ) this_STRING_6= RULE_STRING
                    {
                    otherlv_4=(Token)match(input,86,FOLLOW_77); 

                    				newLeafNode(otherlv_4, grammarAccess.getPropertyStructAccess().getEqualsSignKeyword_4_0());
                    			
                    // InternalSM2.g:4679:4: ( (lv_inicialization_5_0= RULE_NEW ) )
                    // InternalSM2.g:4680:5: (lv_inicialization_5_0= RULE_NEW )
                    {
                    // InternalSM2.g:4680:5: (lv_inicialization_5_0= RULE_NEW )
                    // InternalSM2.g:4681:6: lv_inicialization_5_0= RULE_NEW
                    {
                    lv_inicialization_5_0=(Token)match(input,RULE_NEW,FOLLOW_10); 

                    						newLeafNode(lv_inicialization_5_0, grammarAccess.getPropertyStructAccess().getInicializationNEWTerminalRuleCall_4_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyStructRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"inicialization",
                    							lv_inicialization_5_0,
                    							"org.xtext.SM2.NEW");
                    					

                    }


                    }

                    this_STRING_6=(Token)match(input,RULE_STRING,FOLLOW_8); 

                    				newLeafNode(this_STRING_6, grammarAccess.getPropertyStructAccess().getSTRINGTerminalRuleCall_4_2());
                    			

                    }
                    break;

            }

            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getPropertyStructAccess().getSEMICOLONTerminalRuleCall_5());
            		
            // InternalSM2.g:4706:3: (this_EOLINE_8= RULE_EOLINE )?
            int alt130=2;
            int LA130_0 = input.LA(1);

            if ( (LA130_0==RULE_EOLINE) ) {
                alt130=1;
            }
            switch (alt130) {
                case 1 :
                    // InternalSM2.g:4707:4: this_EOLINE_8= RULE_EOLINE
                    {
                    this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_8, grammarAccess.getPropertyStructAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyStruct"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:4716:1: entryRuleInputParam returns [EObject current=null] : iv_ruleInputParam= ruleInputParam EOF ;
    public final EObject entryRuleInputParam() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputParam = null;


        try {
            // InternalSM2.g:4716:51: (iv_ruleInputParam= ruleInputParam EOF )
            // InternalSM2.g:4717:2: iv_ruleInputParam= ruleInputParam EOF
            {
             newCompositeNode(grammarAccess.getInputParamRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputParam=ruleInputParam();

            state._fsp--;

             current =iv_ruleInputParam; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:4723:1: ruleInputParam returns [EObject current=null] : (this_SingularType_0= ruleSingularType ( ruleArray )? (otherlv_2= 'indexed' )? this_ID_3= RULE_ID (this_COMMA_4= RULE_COMMA )? ) ;
    public final EObject ruleInputParam() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        Token this_ID_3=null;
        Token this_COMMA_4=null;
        EObject this_SingularType_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4729:2: ( (this_SingularType_0= ruleSingularType ( ruleArray )? (otherlv_2= 'indexed' )? this_ID_3= RULE_ID (this_COMMA_4= RULE_COMMA )? ) )
            // InternalSM2.g:4730:2: (this_SingularType_0= ruleSingularType ( ruleArray )? (otherlv_2= 'indexed' )? this_ID_3= RULE_ID (this_COMMA_4= RULE_COMMA )? )
            {
            // InternalSM2.g:4730:2: (this_SingularType_0= ruleSingularType ( ruleArray )? (otherlv_2= 'indexed' )? this_ID_3= RULE_ID (this_COMMA_4= RULE_COMMA )? )
            // InternalSM2.g:4731:3: this_SingularType_0= ruleSingularType ( ruleArray )? (otherlv_2= 'indexed' )? this_ID_3= RULE_ID (this_COMMA_4= RULE_COMMA )?
            {

            			newCompositeNode(grammarAccess.getInputParamAccess().getSingularTypeParserRuleCall_0());
            		
            pushFollow(FOLLOW_78);
            this_SingularType_0=ruleSingularType();

            state._fsp--;


            			current = this_SingularType_0;
            			afterParserOrEnumRuleCall();
            		
            // InternalSM2.g:4739:3: ( ruleArray )?
            int alt131=2;
            int LA131_0 = input.LA(1);

            if ( ((LA131_0>=148 && LA131_0<=149)) ) {
                alt131=1;
            }
            switch (alt131) {
                case 1 :
                    // InternalSM2.g:4740:4: ruleArray
                    {

                    				newCompositeNode(grammarAccess.getInputParamAccess().getArrayParserRuleCall_1());
                    			
                    pushFollow(FOLLOW_79);
                    ruleArray();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            // InternalSM2.g:4748:3: (otherlv_2= 'indexed' )?
            int alt132=2;
            int LA132_0 = input.LA(1);

            if ( (LA132_0==154) ) {
                alt132=1;
            }
            switch (alt132) {
                case 1 :
                    // InternalSM2.g:4749:4: otherlv_2= 'indexed'
                    {
                    otherlv_2=(Token)match(input,154,FOLLOW_13); 

                    				newLeafNode(otherlv_2, grammarAccess.getInputParamAccess().getIndexedKeyword_2());
                    			

                    }
                    break;

            }

            this_ID_3=(Token)match(input,RULE_ID,FOLLOW_80); 

            			newLeafNode(this_ID_3, grammarAccess.getInputParamAccess().getIDTerminalRuleCall_3());
            		
            // InternalSM2.g:4758:3: (this_COMMA_4= RULE_COMMA )?
            int alt133=2;
            int LA133_0 = input.LA(1);

            if ( (LA133_0==RULE_COMMA) ) {
                alt133=1;
            }
            switch (alt133) {
                case 1 :
                    // InternalSM2.g:4759:4: this_COMMA_4= RULE_COMMA
                    {
                    this_COMMA_4=(Token)match(input,RULE_COMMA,FOLLOW_2); 

                    				newLeafNode(this_COMMA_4, grammarAccess.getInputParamAccess().getCOMMATerminalRuleCall_4());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleOutputParam"
    // InternalSM2.g:4768:1: entryRuleOutputParam returns [EObject current=null] : iv_ruleOutputParam= ruleOutputParam EOF ;
    public final EObject entryRuleOutputParam() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOutputParam = null;


        try {
            // InternalSM2.g:4768:52: (iv_ruleOutputParam= ruleOutputParam EOF )
            // InternalSM2.g:4769:2: iv_ruleOutputParam= ruleOutputParam EOF
            {
             newCompositeNode(grammarAccess.getOutputParamRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOutputParam=ruleOutputParam();

            state._fsp--;

             current =iv_ruleOutputParam; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOutputParam"


    // $ANTLR start "ruleOutputParam"
    // InternalSM2.g:4775:1: ruleOutputParam returns [EObject current=null] : (this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )? ) ;
    public final EObject ruleOutputParam() throws RecognitionException {
        EObject current = null;

        Token this_ID_1=null;
        Token this_COMMA_2=null;
        EObject this_SingularType_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4781:2: ( (this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )? ) )
            // InternalSM2.g:4782:2: (this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )? )
            {
            // InternalSM2.g:4782:2: (this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )? )
            // InternalSM2.g:4783:3: this_SingularType_0= ruleSingularType this_ID_1= RULE_ID (this_COMMA_2= RULE_COMMA )?
            {

            			newCompositeNode(grammarAccess.getOutputParamAccess().getSingularTypeParserRuleCall_0());
            		
            pushFollow(FOLLOW_13);
            this_SingularType_0=ruleSingularType();

            state._fsp--;


            			current = this_SingularType_0;
            			afterParserOrEnumRuleCall();
            		
            this_ID_1=(Token)match(input,RULE_ID,FOLLOW_80); 

            			newLeafNode(this_ID_1, grammarAccess.getOutputParamAccess().getIDTerminalRuleCall_1());
            		
            // InternalSM2.g:4795:3: (this_COMMA_2= RULE_COMMA )?
            int alt134=2;
            int LA134_0 = input.LA(1);

            if ( (LA134_0==RULE_COMMA) ) {
                alt134=1;
            }
            switch (alt134) {
                case 1 :
                    // InternalSM2.g:4796:4: this_COMMA_2= RULE_COMMA
                    {
                    this_COMMA_2=(Token)match(input,RULE_COMMA,FOLLOW_2); 

                    				newLeafNode(this_COMMA_2, grammarAccess.getOutputParamAccess().getCOMMATerminalRuleCall_2());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOutputParam"


    // $ANTLR start "entryRuleRestrictionClause"
    // InternalSM2.g:4805:1: entryRuleRestrictionClause returns [EObject current=null] : iv_ruleRestrictionClause= ruleRestrictionClause EOF ;
    public final EObject entryRuleRestrictionClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionClause = null;


        try {
            // InternalSM2.g:4805:58: (iv_ruleRestrictionClause= ruleRestrictionClause EOF )
            // InternalSM2.g:4806:2: iv_ruleRestrictionClause= ruleRestrictionClause EOF
            {
             newCompositeNode(grammarAccess.getRestrictionClauseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionClause=ruleRestrictionClause();

            state._fsp--;

             current =iv_ruleRestrictionClause; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionClause"


    // $ANTLR start "ruleRestrictionClause"
    // InternalSM2.g:4812:1: ruleRestrictionClause returns [EObject current=null] : (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas ) ;
    public final EObject ruleRestrictionClause() throws RecognitionException {
        EObject current = null;

        EObject this_Restriction_0 = null;

        EObject this_RestrictionGas_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:4818:2: ( (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas ) )
            // InternalSM2.g:4819:2: (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas )
            {
            // InternalSM2.g:4819:2: (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas )
            int alt135=2;
            alt135 = dfa135.predict(input);
            switch (alt135) {
                case 1 :
                    // InternalSM2.g:4820:3: this_Restriction_0= ruleRestriction
                    {

                    			newCompositeNode(grammarAccess.getRestrictionClauseAccess().getRestrictionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Restriction_0=ruleRestriction();

                    state._fsp--;


                    			current = this_Restriction_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4829:3: this_RestrictionGas_1= ruleRestrictionGas
                    {

                    			newCompositeNode(grammarAccess.getRestrictionClauseAccess().getRestrictionGasParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_RestrictionGas_1=ruleRestrictionGas();

                    state._fsp--;


                    			current = this_RestrictionGas_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionClause"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:4841:1: entryRuleRestriction returns [EObject current=null] : iv_ruleRestriction= ruleRestriction EOF ;
    public final EObject entryRuleRestriction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestriction = null;


        try {
            // InternalSM2.g:4841:52: (iv_ruleRestriction= ruleRestriction EOF )
            // InternalSM2.g:4842:2: iv_ruleRestriction= ruleRestriction EOF
            {
             newCompositeNode(grammarAccess.getRestrictionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestriction=ruleRestriction();

            state._fsp--;

             current =iv_ruleRestriction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:4848:1: ruleRestriction returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( (lv_expr_2_1= RULE_STRING | lv_expr_2_2= ruleNumberExpression ) ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_expr_4_1= RULE_STRING | lv_expr_4_2= ruleNumberExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) ;
    public final EObject ruleRestriction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_expr_2_1=null;
        Token lv_expr_4_1=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_expr_2_2 = null;

        Enumerator lv_operator_3_0 = null;

        AntlrDatatypeRuleToken lv_expr_4_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:4854:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( (lv_expr_2_1= RULE_STRING | lv_expr_2_2= ruleNumberExpression ) ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_expr_4_1= RULE_STRING | lv_expr_4_2= ruleNumberExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) )
            // InternalSM2.g:4855:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( (lv_expr_2_1= RULE_STRING | lv_expr_2_2= ruleNumberExpression ) ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_expr_4_1= RULE_STRING | lv_expr_4_2= ruleNumberExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            {
            // InternalSM2.g:4855:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( (lv_expr_2_1= RULE_STRING | lv_expr_2_2= ruleNumberExpression ) ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_expr_4_1= RULE_STRING | lv_expr_4_2= ruleNumberExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            // InternalSM2.g:4856:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( (lv_expr_2_1= RULE_STRING | lv_expr_2_2= ruleNumberExpression ) ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_expr_4_1= RULE_STRING | lv_expr_4_2= ruleNumberExpression ) ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,155,FOLLOW_19); 

            			newLeafNode(otherlv_0, grammarAccess.getRestrictionAccess().getRequireKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_81); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:4864:3: ( ( (lv_expr_2_1= RULE_STRING | lv_expr_2_2= ruleNumberExpression ) ) )
            // InternalSM2.g:4865:4: ( (lv_expr_2_1= RULE_STRING | lv_expr_2_2= ruleNumberExpression ) )
            {
            // InternalSM2.g:4865:4: ( (lv_expr_2_1= RULE_STRING | lv_expr_2_2= ruleNumberExpression ) )
            // InternalSM2.g:4866:5: (lv_expr_2_1= RULE_STRING | lv_expr_2_2= ruleNumberExpression )
            {
            // InternalSM2.g:4866:5: (lv_expr_2_1= RULE_STRING | lv_expr_2_2= ruleNumberExpression )
            int alt136=2;
            int LA136_0 = input.LA(1);

            if ( (LA136_0==RULE_STRING) ) {
                alt136=1;
            }
            else if ( (LA136_0==RULE_INT||LA136_0==RULE_FLOAT) ) {
                alt136=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 136, 0, input);

                throw nvae;
            }
            switch (alt136) {
                case 1 :
                    // InternalSM2.g:4867:6: lv_expr_2_1= RULE_STRING
                    {
                    lv_expr_2_1=(Token)match(input,RULE_STRING,FOLLOW_82); 

                    						newLeafNode(lv_expr_2_1, grammarAccess.getRestrictionAccess().getExprSTRINGTerminalRuleCall_2_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getRestrictionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"expr",
                    							lv_expr_2_1,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4882:6: lv_expr_2_2= ruleNumberExpression
                    {

                    						newCompositeNode(grammarAccess.getRestrictionAccess().getExprNumberExpressionParserRuleCall_2_0_1());
                    					
                    pushFollow(FOLLOW_82);
                    lv_expr_2_2=ruleNumberExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getRestrictionRule());
                    						}
                    						set(
                    							current,
                    							"expr",
                    							lv_expr_2_2,
                    							"org.xtext.SM2.NumberExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:4900:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:4901:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:4901:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:4902:5: lv_operator_3_0= ruleComparationOperator
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_81);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"operator",
            						lv_operator_3_0,
            						"org.xtext.SM2.ComparationOperator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:4919:3: ( ( (lv_expr_4_1= RULE_STRING | lv_expr_4_2= ruleNumberExpression ) ) )
            // InternalSM2.g:4920:4: ( (lv_expr_4_1= RULE_STRING | lv_expr_4_2= ruleNumberExpression ) )
            {
            // InternalSM2.g:4920:4: ( (lv_expr_4_1= RULE_STRING | lv_expr_4_2= ruleNumberExpression ) )
            // InternalSM2.g:4921:5: (lv_expr_4_1= RULE_STRING | lv_expr_4_2= ruleNumberExpression )
            {
            // InternalSM2.g:4921:5: (lv_expr_4_1= RULE_STRING | lv_expr_4_2= ruleNumberExpression )
            int alt137=2;
            int LA137_0 = input.LA(1);

            if ( (LA137_0==RULE_STRING) ) {
                alt137=1;
            }
            else if ( (LA137_0==RULE_INT||LA137_0==RULE_FLOAT) ) {
                alt137=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 137, 0, input);

                throw nvae;
            }
            switch (alt137) {
                case 1 :
                    // InternalSM2.g:4922:6: lv_expr_4_1= RULE_STRING
                    {
                    lv_expr_4_1=(Token)match(input,RULE_STRING,FOLLOW_21); 

                    						newLeafNode(lv_expr_4_1, grammarAccess.getRestrictionAccess().getExprSTRINGTerminalRuleCall_4_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getRestrictionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"expr",
                    							lv_expr_4_1,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4937:6: lv_expr_4_2= ruleNumberExpression
                    {

                    						newCompositeNode(grammarAccess.getRestrictionAccess().getExprNumberExpressionParserRuleCall_4_0_1());
                    					
                    pushFollow(FOLLOW_21);
                    lv_expr_4_2=ruleNumberExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getRestrictionRule());
                    						}
                    						set(
                    							current,
                    							"expr",
                    							lv_expr_4_2,
                    							"org.xtext.SM2.NumberExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;

            }


            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_8); 

            			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
            		
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6());
            		
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_7, grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:4971:1: entryRuleRestrictionGas returns [EObject current=null] : iv_ruleRestrictionGas= ruleRestrictionGas EOF ;
    public final EObject entryRuleRestrictionGas() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionGas = null;


        try {
            // InternalSM2.g:4971:55: (iv_ruleRestrictionGas= ruleRestrictionGas EOF )
            // InternalSM2.g:4972:2: iv_ruleRestrictionGas= ruleRestrictionGas EOF
            {
             newCompositeNode(grammarAccess.getRestrictionGasRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionGas=ruleRestrictionGas();

            state._fsp--;

             current =iv_ruleRestrictionGas; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:4978:1: ruleRestrictionGas returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= RULE_STRING ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) ;
    public final EObject ruleRestrictionGas() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_expr_2_0=null;
        Token lv_amount_4_0=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        Enumerator lv_operator_3_0 = null;

        Enumerator lv_typeCoin_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4984:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= RULE_STRING ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) )
            // InternalSM2.g:4985:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= RULE_STRING ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            {
            // InternalSM2.g:4985:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= RULE_STRING ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            // InternalSM2.g:4986:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= RULE_STRING ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,155,FOLLOW_19); 

            			newLeafNode(otherlv_0, grammarAccess.getRestrictionGasAccess().getRequireKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_10); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:4994:3: ( (lv_expr_2_0= RULE_STRING ) )
            // InternalSM2.g:4995:4: (lv_expr_2_0= RULE_STRING )
            {
            // InternalSM2.g:4995:4: (lv_expr_2_0= RULE_STRING )
            // InternalSM2.g:4996:5: lv_expr_2_0= RULE_STRING
            {
            lv_expr_2_0=(Token)match(input,RULE_STRING,FOLLOW_82); 

            					newLeafNode(lv_expr_2_0, grammarAccess.getRestrictionGasAccess().getExprSTRINGTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRestrictionGasRule());
            					}
            					setWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_2_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:5012:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:5013:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:5013:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:5014:5: lv_operator_3_0= ruleComparationOperator
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_59);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"operator",
            						lv_operator_3_0,
            						"org.xtext.SM2.ComparationOperator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:5031:3: ( (lv_amount_4_0= RULE_INT ) )
            // InternalSM2.g:5032:4: (lv_amount_4_0= RULE_INT )
            {
            // InternalSM2.g:5032:4: (lv_amount_4_0= RULE_INT )
            // InternalSM2.g:5033:5: lv_amount_4_0= RULE_INT
            {
            lv_amount_4_0=(Token)match(input,RULE_INT,FOLLOW_83); 

            					newLeafNode(lv_amount_4_0, grammarAccess.getRestrictionGasAccess().getAmountINTTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRestrictionGasRule());
            					}
            					setWithLastConsumed(
            						current,
            						"amount",
            						lv_amount_4_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalSM2.g:5049:3: ( (lv_typeCoin_5_0= ruleCoin ) )
            // InternalSM2.g:5050:4: (lv_typeCoin_5_0= ruleCoin )
            {
            // InternalSM2.g:5050:4: (lv_typeCoin_5_0= ruleCoin )
            // InternalSM2.g:5051:5: lv_typeCoin_5_0= ruleCoin
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0());
            				
            pushFollow(FOLLOW_21);
            lv_typeCoin_5_0=ruleCoin();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"typeCoin",
            						lv_typeCoin_5_0,
            						"org.xtext.SM2.Coin");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_8); 

            			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
            		
            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7());
            		
            this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_8, grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2.g:5084:1: entryRuleClause returns [EObject current=null] : iv_ruleClause= ruleClause EOF ;
    public final EObject entryRuleClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClause = null;


        try {
            // InternalSM2.g:5084:47: (iv_ruleClause= ruleClause EOF )
            // InternalSM2.g:5085:2: iv_ruleClause= ruleClause EOF
            {
             newCompositeNode(grammarAccess.getClauseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleClause=ruleClause();

            state._fsp--;

             current =iv_ruleClause; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2.g:5091:1: ruleClause returns [EObject current=null] : (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_RETURNS_5= RULE_RETURNS ( (lv_outputparam_6_0= ruleOutputParam ) ) )? ( (lv_visibilityAccess_7_0= ruleVisibility ) ) ( ( (lv_predefinedModifier_8_0= ruleInputModifier ) ) | ( (otherlv_9= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY this_EOLINE_11= RULE_EOLINE ( (lv_restriction_12_0= ruleRestrictionClause ) )? ( (lv_loops_13_0= ruleLoops ) )? ( (lv_expression_14_0= ruleExpression ) )? ( (lv_functions_15_0= rulePredefinedFunctions ) )? this_CLOSEKEY_16= RULE_CLOSEKEY this_EOLINE_17= RULE_EOLINE ) ;
    public final EObject ruleClause() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_RETURNS_5=null;
        Token otherlv_9=null;
        Token this_OPENKEY_10=null;
        Token this_EOLINE_11=null;
        Token this_CLOSEKEY_16=null;
        Token this_EOLINE_17=null;
        EObject lv_inputParams_3_0 = null;

        EObject lv_outputparam_6_0 = null;

        Enumerator lv_visibilityAccess_7_0 = null;

        Enumerator lv_predefinedModifier_8_0 = null;

        EObject lv_restriction_12_0 = null;

        EObject lv_loops_13_0 = null;

        AntlrDatatypeRuleToken lv_expression_14_0 = null;

        EObject lv_functions_15_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:5097:2: ( (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_RETURNS_5= RULE_RETURNS ( (lv_outputparam_6_0= ruleOutputParam ) ) )? ( (lv_visibilityAccess_7_0= ruleVisibility ) ) ( ( (lv_predefinedModifier_8_0= ruleInputModifier ) ) | ( (otherlv_9= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY this_EOLINE_11= RULE_EOLINE ( (lv_restriction_12_0= ruleRestrictionClause ) )? ( (lv_loops_13_0= ruleLoops ) )? ( (lv_expression_14_0= ruleExpression ) )? ( (lv_functions_15_0= rulePredefinedFunctions ) )? this_CLOSEKEY_16= RULE_CLOSEKEY this_EOLINE_17= RULE_EOLINE ) )
            // InternalSM2.g:5098:2: (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_RETURNS_5= RULE_RETURNS ( (lv_outputparam_6_0= ruleOutputParam ) ) )? ( (lv_visibilityAccess_7_0= ruleVisibility ) ) ( ( (lv_predefinedModifier_8_0= ruleInputModifier ) ) | ( (otherlv_9= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY this_EOLINE_11= RULE_EOLINE ( (lv_restriction_12_0= ruleRestrictionClause ) )? ( (lv_loops_13_0= ruleLoops ) )? ( (lv_expression_14_0= ruleExpression ) )? ( (lv_functions_15_0= rulePredefinedFunctions ) )? this_CLOSEKEY_16= RULE_CLOSEKEY this_EOLINE_17= RULE_EOLINE )
            {
            // InternalSM2.g:5098:2: (otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_RETURNS_5= RULE_RETURNS ( (lv_outputparam_6_0= ruleOutputParam ) ) )? ( (lv_visibilityAccess_7_0= ruleVisibility ) ) ( ( (lv_predefinedModifier_8_0= ruleInputModifier ) ) | ( (otherlv_9= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY this_EOLINE_11= RULE_EOLINE ( (lv_restriction_12_0= ruleRestrictionClause ) )? ( (lv_loops_13_0= ruleLoops ) )? ( (lv_expression_14_0= ruleExpression ) )? ( (lv_functions_15_0= rulePredefinedFunctions ) )? this_CLOSEKEY_16= RULE_CLOSEKEY this_EOLINE_17= RULE_EOLINE )
            // InternalSM2.g:5099:3: otherlv_0= 'function' ( (lv_name_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS (this_RETURNS_5= RULE_RETURNS ( (lv_outputparam_6_0= ruleOutputParam ) ) )? ( (lv_visibilityAccess_7_0= ruleVisibility ) ) ( ( (lv_predefinedModifier_8_0= ruleInputModifier ) ) | ( (otherlv_9= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY this_EOLINE_11= RULE_EOLINE ( (lv_restriction_12_0= ruleRestrictionClause ) )? ( (lv_loops_13_0= ruleLoops ) )? ( (lv_expression_14_0= ruleExpression ) )? ( (lv_functions_15_0= rulePredefinedFunctions ) )? this_CLOSEKEY_16= RULE_CLOSEKEY this_EOLINE_17= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,156,FOLLOW_13); 

            			newLeafNode(otherlv_0, grammarAccess.getClauseAccess().getFunctionKeyword_0());
            		
            // InternalSM2.g:5103:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSM2.g:5104:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSM2.g:5104:4: (lv_name_1_0= RULE_ID )
            // InternalSM2.g:5105:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_19); 

            					newLeafNode(lv_name_1_0, grammarAccess.getClauseAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getClauseRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_41); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		
            // InternalSM2.g:5125:3: ( (lv_inputParams_3_0= ruleInputParam ) )
            // InternalSM2.g:5126:4: (lv_inputParams_3_0= ruleInputParam )
            {
            // InternalSM2.g:5126:4: (lv_inputParams_3_0= ruleInputParam )
            // InternalSM2.g:5127:5: lv_inputParams_3_0= ruleInputParam
            {

            					newCompositeNode(grammarAccess.getClauseAccess().getInputParamsInputParamParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_21);
            lv_inputParams_3_0=ruleInputParam();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getClauseRule());
            					}
            					add(
            						current,
            						"inputParams",
            						lv_inputParams_3_0,
            						"org.xtext.SM2.InputParam");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_84); 

            			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
            		
            // InternalSM2.g:5148:3: (this_RETURNS_5= RULE_RETURNS ( (lv_outputparam_6_0= ruleOutputParam ) ) )?
            int alt138=2;
            int LA138_0 = input.LA(1);

            if ( (LA138_0==RULE_RETURNS) ) {
                alt138=1;
            }
            switch (alt138) {
                case 1 :
                    // InternalSM2.g:5149:4: this_RETURNS_5= RULE_RETURNS ( (lv_outputparam_6_0= ruleOutputParam ) )
                    {
                    this_RETURNS_5=(Token)match(input,RULE_RETURNS,FOLLOW_41); 

                    				newLeafNode(this_RETURNS_5, grammarAccess.getClauseAccess().getRETURNSTerminalRuleCall_5_0());
                    			
                    // InternalSM2.g:5153:4: ( (lv_outputparam_6_0= ruleOutputParam ) )
                    // InternalSM2.g:5154:5: (lv_outputparam_6_0= ruleOutputParam )
                    {
                    // InternalSM2.g:5154:5: (lv_outputparam_6_0= ruleOutputParam )
                    // InternalSM2.g:5155:6: lv_outputparam_6_0= ruleOutputParam
                    {

                    						newCompositeNode(grammarAccess.getClauseAccess().getOutputparamOutputParamParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_85);
                    lv_outputparam_6_0=ruleOutputParam();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getClauseRule());
                    						}
                    						add(
                    							current,
                    							"outputparam",
                    							lv_outputparam_6_0,
                    							"org.xtext.SM2.OutputParam");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalSM2.g:5173:3: ( (lv_visibilityAccess_7_0= ruleVisibility ) )
            // InternalSM2.g:5174:4: (lv_visibilityAccess_7_0= ruleVisibility )
            {
            // InternalSM2.g:5174:4: (lv_visibilityAccess_7_0= ruleVisibility )
            // InternalSM2.g:5175:5: lv_visibilityAccess_7_0= ruleVisibility
            {

            					newCompositeNode(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_6_0());
            				
            pushFollow(FOLLOW_86);
            lv_visibilityAccess_7_0=ruleVisibility();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getClauseRule());
            					}
            					set(
            						current,
            						"visibilityAccess",
            						lv_visibilityAccess_7_0,
            						"org.xtext.SM2.Visibility");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:5192:3: ( ( (lv_predefinedModifier_8_0= ruleInputModifier ) ) | ( (otherlv_9= RULE_ID ) ) )?
            int alt139=3;
            int LA139_0 = input.LA(1);

            if ( ((LA139_0>=188 && LA139_0<=190)) ) {
                alt139=1;
            }
            else if ( (LA139_0==RULE_ID) ) {
                alt139=2;
            }
            switch (alt139) {
                case 1 :
                    // InternalSM2.g:5193:4: ( (lv_predefinedModifier_8_0= ruleInputModifier ) )
                    {
                    // InternalSM2.g:5193:4: ( (lv_predefinedModifier_8_0= ruleInputModifier ) )
                    // InternalSM2.g:5194:5: (lv_predefinedModifier_8_0= ruleInputModifier )
                    {
                    // InternalSM2.g:5194:5: (lv_predefinedModifier_8_0= ruleInputModifier )
                    // InternalSM2.g:5195:6: lv_predefinedModifier_8_0= ruleInputModifier
                    {

                    						newCompositeNode(grammarAccess.getClauseAccess().getPredefinedModifierInputModifierEnumRuleCall_7_0_0());
                    					
                    pushFollow(FOLLOW_14);
                    lv_predefinedModifier_8_0=ruleInputModifier();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getClauseRule());
                    						}
                    						set(
                    							current,
                    							"predefinedModifier",
                    							lv_predefinedModifier_8_0,
                    							"org.xtext.SM2.InputModifier");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5213:4: ( (otherlv_9= RULE_ID ) )
                    {
                    // InternalSM2.g:5213:4: ( (otherlv_9= RULE_ID ) )
                    // InternalSM2.g:5214:5: (otherlv_9= RULE_ID )
                    {
                    // InternalSM2.g:5214:5: (otherlv_9= RULE_ID )
                    // InternalSM2.g:5215:6: otherlv_9= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getClauseRule());
                    						}
                    					
                    otherlv_9=(Token)match(input,RULE_ID,FOLLOW_14); 

                    						newLeafNode(otherlv_9, grammarAccess.getClauseAccess().getPersonalizedModifierModifierCrossReference_7_1_0());
                    					

                    }


                    }


                    }
                    break;

            }

            this_OPENKEY_10=(Token)match(input,RULE_OPENKEY,FOLLOW_23); 

            			newLeafNode(this_OPENKEY_10, grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_8());
            		
            this_EOLINE_11=(Token)match(input,RULE_EOLINE,FOLLOW_87); 

            			newLeafNode(this_EOLINE_11, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_9());
            		
            // InternalSM2.g:5235:3: ( (lv_restriction_12_0= ruleRestrictionClause ) )?
            int alt140=2;
            int LA140_0 = input.LA(1);

            if ( (LA140_0==155) ) {
                alt140=1;
            }
            switch (alt140) {
                case 1 :
                    // InternalSM2.g:5236:4: (lv_restriction_12_0= ruleRestrictionClause )
                    {
                    // InternalSM2.g:5236:4: (lv_restriction_12_0= ruleRestrictionClause )
                    // InternalSM2.g:5237:5: lv_restriction_12_0= ruleRestrictionClause
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getRestrictionRestrictionClauseParserRuleCall_10_0());
                    				
                    pushFollow(FOLLOW_88);
                    lv_restriction_12_0=ruleRestrictionClause();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"restriction",
                    						lv_restriction_12_0,
                    						"org.xtext.SM2.RestrictionClause");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:5254:3: ( (lv_loops_13_0= ruleLoops ) )?
            int alt141=2;
            int LA141_0 = input.LA(1);

            if ( ((LA141_0>=184 && LA141_0<=185)||LA141_0==187) ) {
                alt141=1;
            }
            switch (alt141) {
                case 1 :
                    // InternalSM2.g:5255:4: (lv_loops_13_0= ruleLoops )
                    {
                    // InternalSM2.g:5255:4: (lv_loops_13_0= ruleLoops )
                    // InternalSM2.g:5256:5: lv_loops_13_0= ruleLoops
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getLoopsLoopsParserRuleCall_11_0());
                    				
                    pushFollow(FOLLOW_89);
                    lv_loops_13_0=ruleLoops();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"loops",
                    						lv_loops_13_0,
                    						"org.xtext.SM2.Loops");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:5273:3: ( (lv_expression_14_0= ruleExpression ) )?
            int alt142=2;
            int LA142_0 = input.LA(1);

            if ( (LA142_0==RULE_STRING||LA142_0==RULE_OPENPARENTHESIS||LA142_0==RULE_INT||(LA142_0>=RULE_FLOAT && LA142_0<=RULE_BOOLVALUE)||LA142_0==RULE_NEW||(LA142_0>=RULE_DELETE && LA142_0<=RULE_IF)||LA142_0==83||(LA142_0>=89 && LA142_0<=145)||LA142_0==164) ) {
                alt142=1;
            }
            switch (alt142) {
                case 1 :
                    // InternalSM2.g:5274:4: (lv_expression_14_0= ruleExpression )
                    {
                    // InternalSM2.g:5274:4: (lv_expression_14_0= ruleExpression )
                    // InternalSM2.g:5275:5: lv_expression_14_0= ruleExpression
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_12_0());
                    				
                    pushFollow(FOLLOW_90);
                    lv_expression_14_0=ruleExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"expression",
                    						lv_expression_14_0,
                    						"org.xtext.SM2.Expression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:5292:3: ( (lv_functions_15_0= rulePredefinedFunctions ) )?
            int alt143=2;
            int LA143_0 = input.LA(1);

            if ( ((LA143_0>=157 && LA143_0<=160)) ) {
                alt143=1;
            }
            switch (alt143) {
                case 1 :
                    // InternalSM2.g:5293:4: (lv_functions_15_0= rulePredefinedFunctions )
                    {
                    // InternalSM2.g:5293:4: (lv_functions_15_0= rulePredefinedFunctions )
                    // InternalSM2.g:5294:5: lv_functions_15_0= rulePredefinedFunctions
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getFunctionsPredefinedFunctionsParserRuleCall_13_0());
                    				
                    pushFollow(FOLLOW_16);
                    lv_functions_15_0=rulePredefinedFunctions();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"functions",
                    						lv_functions_15_0,
                    						"org.xtext.SM2.PredefinedFunctions");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            this_CLOSEKEY_16=(Token)match(input,RULE_CLOSEKEY,FOLLOW_23); 

            			newLeafNode(this_CLOSEKEY_16, grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_14());
            		
            this_EOLINE_17=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_17, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRulePredefinedFunctions"
    // InternalSM2.g:5323:1: entryRulePredefinedFunctions returns [EObject current=null] : iv_rulePredefinedFunctions= rulePredefinedFunctions EOF ;
    public final EObject entryRulePredefinedFunctions() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePredefinedFunctions = null;


        try {
            // InternalSM2.g:5323:60: (iv_rulePredefinedFunctions= rulePredefinedFunctions EOF )
            // InternalSM2.g:5324:2: iv_rulePredefinedFunctions= rulePredefinedFunctions EOF
            {
             newCompositeNode(grammarAccess.getPredefinedFunctionsRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePredefinedFunctions=rulePredefinedFunctions();

            state._fsp--;

             current =iv_rulePredefinedFunctions; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePredefinedFunctions"


    // $ANTLR start "rulePredefinedFunctions"
    // InternalSM2.g:5330:1: rulePredefinedFunctions returns [EObject current=null] : (this_CryptographycFunctions_0= ruleCryptographycFunctions | this_Selfdestruct_1= ruleSelfdestruct ) ;
    public final EObject rulePredefinedFunctions() throws RecognitionException {
        EObject current = null;

        EObject this_CryptographycFunctions_0 = null;

        EObject this_Selfdestruct_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:5336:2: ( (this_CryptographycFunctions_0= ruleCryptographycFunctions | this_Selfdestruct_1= ruleSelfdestruct ) )
            // InternalSM2.g:5337:2: (this_CryptographycFunctions_0= ruleCryptographycFunctions | this_Selfdestruct_1= ruleSelfdestruct )
            {
            // InternalSM2.g:5337:2: (this_CryptographycFunctions_0= ruleCryptographycFunctions | this_Selfdestruct_1= ruleSelfdestruct )
            int alt144=2;
            int LA144_0 = input.LA(1);

            if ( ((LA144_0>=158 && LA144_0<=160)) ) {
                alt144=1;
            }
            else if ( (LA144_0==157) ) {
                alt144=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 144, 0, input);

                throw nvae;
            }
            switch (alt144) {
                case 1 :
                    // InternalSM2.g:5338:3: this_CryptographycFunctions_0= ruleCryptographycFunctions
                    {

                    			newCompositeNode(grammarAccess.getPredefinedFunctionsAccess().getCryptographycFunctionsParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_CryptographycFunctions_0=ruleCryptographycFunctions();

                    state._fsp--;


                    			current = this_CryptographycFunctions_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:5347:3: this_Selfdestruct_1= ruleSelfdestruct
                    {

                    			newCompositeNode(grammarAccess.getPredefinedFunctionsAccess().getSelfdestructParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Selfdestruct_1=ruleSelfdestruct();

                    state._fsp--;


                    			current = this_Selfdestruct_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePredefinedFunctions"


    // $ANTLR start "entryRuleSelfdestruct"
    // InternalSM2.g:5359:1: entryRuleSelfdestruct returns [EObject current=null] : iv_ruleSelfdestruct= ruleSelfdestruct EOF ;
    public final EObject entryRuleSelfdestruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSelfdestruct = null;


        try {
            // InternalSM2.g:5359:53: (iv_ruleSelfdestruct= ruleSelfdestruct EOF )
            // InternalSM2.g:5360:2: iv_ruleSelfdestruct= ruleSelfdestruct EOF
            {
             newCompositeNode(grammarAccess.getSelfdestructRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSelfdestruct=ruleSelfdestruct();

            state._fsp--;

             current =iv_ruleSelfdestruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSelfdestruct"


    // $ANTLR start "ruleSelfdestruct"
    // InternalSM2.g:5366:1: ruleSelfdestruct returns [EObject current=null] : (otherlv_0= 'selfdestruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) ;
    public final EObject ruleSelfdestruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_STRING_2=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;


        	enterRule();

        try {
            // InternalSM2.g:5372:2: ( (otherlv_0= 'selfdestruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:5373:2: (otherlv_0= 'selfdestruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:5373:2: (otherlv_0= 'selfdestruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:5374:3: otherlv_0= 'selfdestruct' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,157,FOLLOW_19); 

            			newLeafNode(otherlv_0, grammarAccess.getSelfdestructAccess().getSelfdestructKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_10); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getSelfdestructAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            this_STRING_2=(Token)match(input,RULE_STRING,FOLLOW_21); 

            			newLeafNode(this_STRING_2, grammarAccess.getSelfdestructAccess().getSTRINGTerminalRuleCall_2());
            		
            this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_8); 

            			newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getSelfdestructAccess().getCLOSEPARENTHESISTerminalRuleCall_3());
            		
            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_9); 

            			newLeafNode(this_SEMICOLON_4, grammarAccess.getSelfdestructAccess().getSEMICOLONTerminalRuleCall_4());
            		
            // InternalSM2.g:5394:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt145=2;
            int LA145_0 = input.LA(1);

            if ( (LA145_0==RULE_EOLINE) ) {
                alt145=1;
            }
            switch (alt145) {
                case 1 :
                    // InternalSM2.g:5395:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_5, grammarAccess.getSelfdestructAccess().getEOLINETerminalRuleCall_5());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSelfdestruct"


    // $ANTLR start "entryRuleCryptographycFunctions"
    // InternalSM2.g:5404:1: entryRuleCryptographycFunctions returns [EObject current=null] : iv_ruleCryptographycFunctions= ruleCryptographycFunctions EOF ;
    public final EObject entryRuleCryptographycFunctions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCryptographycFunctions = null;


        try {
            // InternalSM2.g:5404:63: (iv_ruleCryptographycFunctions= ruleCryptographycFunctions EOF )
            // InternalSM2.g:5405:2: iv_ruleCryptographycFunctions= ruleCryptographycFunctions EOF
            {
             newCompositeNode(grammarAccess.getCryptographycFunctionsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCryptographycFunctions=ruleCryptographycFunctions();

            state._fsp--;

             current =iv_ruleCryptographycFunctions; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCryptographycFunctions"


    // $ANTLR start "ruleCryptographycFunctions"
    // InternalSM2.g:5411:1: ruleCryptographycFunctions returns [EObject current=null] : ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING (this_COMMA_13= RULE_COMMA this_STRING_14= RULE_STRING )? this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS (this_SEMICOLON_16= RULE_SEMICOLON )? ) ) ;
    public final EObject ruleCryptographycFunctions() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_STRING_2=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token this_SEMICOLON_4=null;
        Token otherlv_5=null;
        Token this_OPENPARENTHESIS_6=null;
        Token this_STRING_7=null;
        Token this_CLOSEPARENTHESIS_8=null;
        Token this_SEMICOLON_9=null;
        Token otherlv_10=null;
        Token this_OPENPARENTHESIS_11=null;
        Token this_STRING_12=null;
        Token this_COMMA_13=null;
        Token this_STRING_14=null;
        Token this_CLOSEPARENTHESIS_15=null;
        Token this_SEMICOLON_16=null;


        	enterRule();

        try {
            // InternalSM2.g:5417:2: ( ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING (this_COMMA_13= RULE_COMMA this_STRING_14= RULE_STRING )? this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS (this_SEMICOLON_16= RULE_SEMICOLON )? ) ) )
            // InternalSM2.g:5418:2: ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING (this_COMMA_13= RULE_COMMA this_STRING_14= RULE_STRING )? this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS (this_SEMICOLON_16= RULE_SEMICOLON )? ) )
            {
            // InternalSM2.g:5418:2: ( (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? ) | (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? ) | (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING (this_COMMA_13= RULE_COMMA this_STRING_14= RULE_STRING )? this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS (this_SEMICOLON_16= RULE_SEMICOLON )? ) )
            int alt150=3;
            switch ( input.LA(1) ) {
            case 158:
                {
                alt150=1;
                }
                break;
            case 159:
                {
                alt150=2;
                }
                break;
            case 160:
                {
                alt150=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 150, 0, input);

                throw nvae;
            }

            switch (alt150) {
                case 1 :
                    // InternalSM2.g:5419:3: (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:5419:3: (otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )? )
                    // InternalSM2.g:5420:4: otherlv_0= 'keccack256' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON )?
                    {
                    otherlv_0=(Token)match(input,158,FOLLOW_19); 

                    				newLeafNode(otherlv_0, grammarAccess.getCryptographycFunctionsAccess().getKeccack256Keyword_0_0());
                    			
                    this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_10); 

                    				newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_0_1());
                    			
                    this_STRING_2=(Token)match(input,RULE_STRING,FOLLOW_21); 

                    				newLeafNode(this_STRING_2, grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_0_2());
                    			
                    this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_22); 

                    				newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_0_3());
                    			
                    // InternalSM2.g:5436:4: (this_SEMICOLON_4= RULE_SEMICOLON )?
                    int alt146=2;
                    int LA146_0 = input.LA(1);

                    if ( (LA146_0==RULE_SEMICOLON) ) {
                        alt146=1;
                    }
                    switch (alt146) {
                        case 1 :
                            // InternalSM2.g:5437:5: this_SEMICOLON_4= RULE_SEMICOLON
                            {
                            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_4, grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_0_4());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5444:3: (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:5444:3: (otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )? )
                    // InternalSM2.g:5445:4: otherlv_5= 'sha256' this_OPENPARENTHESIS_6= RULE_OPENPARENTHESIS this_STRING_7= RULE_STRING this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON )?
                    {
                    otherlv_5=(Token)match(input,159,FOLLOW_19); 

                    				newLeafNode(otherlv_5, grammarAccess.getCryptographycFunctionsAccess().getSha256Keyword_1_0());
                    			
                    this_OPENPARENTHESIS_6=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_10); 

                    				newLeafNode(this_OPENPARENTHESIS_6, grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_1_1());
                    			
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_21); 

                    				newLeafNode(this_STRING_7, grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_1_2());
                    			
                    this_CLOSEPARENTHESIS_8=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_22); 

                    				newLeafNode(this_CLOSEPARENTHESIS_8, grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3());
                    			
                    // InternalSM2.g:5461:4: (this_SEMICOLON_9= RULE_SEMICOLON )?
                    int alt147=2;
                    int LA147_0 = input.LA(1);

                    if ( (LA147_0==RULE_SEMICOLON) ) {
                        alt147=1;
                    }
                    switch (alt147) {
                        case 1 :
                            // InternalSM2.g:5462:5: this_SEMICOLON_9= RULE_SEMICOLON
                            {
                            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_9, grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_1_4());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5469:3: (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING (this_COMMA_13= RULE_COMMA this_STRING_14= RULE_STRING )? this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS (this_SEMICOLON_16= RULE_SEMICOLON )? )
                    {
                    // InternalSM2.g:5469:3: (otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING (this_COMMA_13= RULE_COMMA this_STRING_14= RULE_STRING )? this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS (this_SEMICOLON_16= RULE_SEMICOLON )? )
                    // InternalSM2.g:5470:4: otherlv_10= 'sha3' this_OPENPARENTHESIS_11= RULE_OPENPARENTHESIS this_STRING_12= RULE_STRING (this_COMMA_13= RULE_COMMA this_STRING_14= RULE_STRING )? this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS (this_SEMICOLON_16= RULE_SEMICOLON )?
                    {
                    otherlv_10=(Token)match(input,160,FOLLOW_19); 

                    				newLeafNode(otherlv_10, grammarAccess.getCryptographycFunctionsAccess().getSha3Keyword_2_0());
                    			
                    this_OPENPARENTHESIS_11=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_10); 

                    				newLeafNode(this_OPENPARENTHESIS_11, grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_2_1());
                    			
                    this_STRING_12=(Token)match(input,RULE_STRING,FOLLOW_91); 

                    				newLeafNode(this_STRING_12, grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_2_2());
                    			
                    // InternalSM2.g:5482:4: (this_COMMA_13= RULE_COMMA this_STRING_14= RULE_STRING )?
                    int alt148=2;
                    int LA148_0 = input.LA(1);

                    if ( (LA148_0==RULE_COMMA) ) {
                        alt148=1;
                    }
                    switch (alt148) {
                        case 1 :
                            // InternalSM2.g:5483:5: this_COMMA_13= RULE_COMMA this_STRING_14= RULE_STRING
                            {
                            this_COMMA_13=(Token)match(input,RULE_COMMA,FOLLOW_10); 

                            					newLeafNode(this_COMMA_13, grammarAccess.getCryptographycFunctionsAccess().getCOMMATerminalRuleCall_2_3_0());
                            				
                            this_STRING_14=(Token)match(input,RULE_STRING,FOLLOW_21); 

                            					newLeafNode(this_STRING_14, grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_2_3_1());
                            				

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_15=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_22); 

                    				newLeafNode(this_CLOSEPARENTHESIS_15, grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_2_4());
                    			
                    // InternalSM2.g:5496:4: (this_SEMICOLON_16= RULE_SEMICOLON )?
                    int alt149=2;
                    int LA149_0 = input.LA(1);

                    if ( (LA149_0==RULE_SEMICOLON) ) {
                        alt149=1;
                    }
                    switch (alt149) {
                        case 1 :
                            // InternalSM2.g:5497:5: this_SEMICOLON_16= RULE_SEMICOLON
                            {
                            this_SEMICOLON_16=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

                            					newLeafNode(this_SEMICOLON_16, grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_2_5());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCryptographycFunctions"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:5507:1: entryRuleComment returns [EObject current=null] : iv_ruleComment= ruleComment EOF ;
    public final EObject entryRuleComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleComment = null;


        try {
            // InternalSM2.g:5507:48: (iv_ruleComment= ruleComment EOF )
            // InternalSM2.g:5508:2: iv_ruleComment= ruleComment EOF
            {
             newCompositeNode(grammarAccess.getCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleComment=ruleComment();

            state._fsp--;

             current =iv_ruleComment; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:5514:1: ruleComment returns [EObject current=null] : ( ruleShortComment | ruleLongComment ) ;
    public final EObject ruleComment() throws RecognitionException {
        EObject current = null;


        	enterRule();

        try {
            // InternalSM2.g:5520:2: ( ( ruleShortComment | ruleLongComment ) )
            // InternalSM2.g:5521:2: ( ruleShortComment | ruleLongComment )
            {
            // InternalSM2.g:5521:2: ( ruleShortComment | ruleLongComment )
            int alt151=2;
            int LA151_0 = input.LA(1);

            if ( (LA151_0==161) ) {
                alt151=1;
            }
            else if ( (LA151_0==162) ) {
                alt151=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 151, 0, input);

                throw nvae;
            }
            switch (alt151) {
                case 1 :
                    // InternalSM2.g:5522:3: ruleShortComment
                    {

                    			newCompositeNode(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    ruleShortComment();

                    state._fsp--;


                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:5530:3: ruleLongComment
                    {

                    			newCompositeNode(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    ruleLongComment();

                    state._fsp--;


                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:5541:1: entryRuleShortComment returns [String current=null] : iv_ruleShortComment= ruleShortComment EOF ;
    public final String entryRuleShortComment() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleShortComment = null;


        try {
            // InternalSM2.g:5541:52: (iv_ruleShortComment= ruleShortComment EOF )
            // InternalSM2.g:5542:2: iv_ruleShortComment= ruleShortComment EOF
            {
             newCompositeNode(grammarAccess.getShortCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleShortComment=ruleShortComment();

            state._fsp--;

             current =iv_ruleShortComment.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:5548:1: ruleShortComment returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE ) ;
    public final AntlrDatatypeRuleToken ruleShortComment() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_STRING_1=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:5554:2: ( (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE ) )
            // InternalSM2.g:5555:2: (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE )
            {
            // InternalSM2.g:5555:2: (kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE )
            // InternalSM2.g:5556:3: kw= '//' this_STRING_1= RULE_STRING this_EOLINE_2= RULE_EOLINE
            {
            kw=(Token)match(input,161,FOLLOW_10); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0());
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_23); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getShortCommentAccess().getSTRINGTerminalRuleCall_1());
            		
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			current.merge(this_EOLINE_2);
            		

            			newLeafNode(this_EOLINE_2, grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:5579:1: entryRuleLongComment returns [String current=null] : iv_ruleLongComment= ruleLongComment EOF ;
    public final String entryRuleLongComment() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleLongComment = null;


        try {
            // InternalSM2.g:5579:51: (iv_ruleLongComment= ruleLongComment EOF )
            // InternalSM2.g:5580:2: iv_ruleLongComment= ruleLongComment EOF
            {
             newCompositeNode(grammarAccess.getLongCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLongComment=ruleLongComment();

            state._fsp--;

             current =iv_ruleLongComment.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:5586:1: ruleLongComment returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= '/*' this_EOLINE_1= RULE_EOLINE (this_PARAMSLONGCOMENT_2= RULE_PARAMSLONGCOMENT )? (this_TITLELONGCOMENT_3= RULE_TITLELONGCOMENT )? (this_DEVLONGCOMENT_4= RULE_DEVLONGCOMENT )? (this_RETURNSLONGCOMENT_5= RULE_RETURNSLONGCOMENT )? kw= '*/' this_EOLINE_7= RULE_EOLINE ) ;
    public final AntlrDatatypeRuleToken ruleLongComment() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_EOLINE_1=null;
        Token this_PARAMSLONGCOMENT_2=null;
        Token this_TITLELONGCOMENT_3=null;
        Token this_DEVLONGCOMENT_4=null;
        Token this_RETURNSLONGCOMENT_5=null;
        Token this_EOLINE_7=null;


        	enterRule();

        try {
            // InternalSM2.g:5592:2: ( (kw= '/*' this_EOLINE_1= RULE_EOLINE (this_PARAMSLONGCOMENT_2= RULE_PARAMSLONGCOMENT )? (this_TITLELONGCOMENT_3= RULE_TITLELONGCOMENT )? (this_DEVLONGCOMENT_4= RULE_DEVLONGCOMENT )? (this_RETURNSLONGCOMENT_5= RULE_RETURNSLONGCOMENT )? kw= '*/' this_EOLINE_7= RULE_EOLINE ) )
            // InternalSM2.g:5593:2: (kw= '/*' this_EOLINE_1= RULE_EOLINE (this_PARAMSLONGCOMENT_2= RULE_PARAMSLONGCOMENT )? (this_TITLELONGCOMENT_3= RULE_TITLELONGCOMENT )? (this_DEVLONGCOMENT_4= RULE_DEVLONGCOMENT )? (this_RETURNSLONGCOMENT_5= RULE_RETURNSLONGCOMENT )? kw= '*/' this_EOLINE_7= RULE_EOLINE )
            {
            // InternalSM2.g:5593:2: (kw= '/*' this_EOLINE_1= RULE_EOLINE (this_PARAMSLONGCOMENT_2= RULE_PARAMSLONGCOMENT )? (this_TITLELONGCOMENT_3= RULE_TITLELONGCOMENT )? (this_DEVLONGCOMENT_4= RULE_DEVLONGCOMENT )? (this_RETURNSLONGCOMENT_5= RULE_RETURNSLONGCOMENT )? kw= '*/' this_EOLINE_7= RULE_EOLINE )
            // InternalSM2.g:5594:3: kw= '/*' this_EOLINE_1= RULE_EOLINE (this_PARAMSLONGCOMENT_2= RULE_PARAMSLONGCOMENT )? (this_TITLELONGCOMENT_3= RULE_TITLELONGCOMENT )? (this_DEVLONGCOMENT_4= RULE_DEVLONGCOMENT )? (this_RETURNSLONGCOMENT_5= RULE_RETURNSLONGCOMENT )? kw= '*/' this_EOLINE_7= RULE_EOLINE
            {
            kw=(Token)match(input,162,FOLLOW_23); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0());
            		
            this_EOLINE_1=(Token)match(input,RULE_EOLINE,FOLLOW_92); 

            			current.merge(this_EOLINE_1);
            		

            			newLeafNode(this_EOLINE_1, grammarAccess.getLongCommentAccess().getEOLINETerminalRuleCall_1());
            		
            // InternalSM2.g:5606:3: (this_PARAMSLONGCOMENT_2= RULE_PARAMSLONGCOMENT )?
            int alt152=2;
            int LA152_0 = input.LA(1);

            if ( (LA152_0==RULE_PARAMSLONGCOMENT) ) {
                alt152=1;
            }
            switch (alt152) {
                case 1 :
                    // InternalSM2.g:5607:4: this_PARAMSLONGCOMENT_2= RULE_PARAMSLONGCOMENT
                    {
                    this_PARAMSLONGCOMENT_2=(Token)match(input,RULE_PARAMSLONGCOMENT,FOLLOW_93); 

                    				current.merge(this_PARAMSLONGCOMENT_2);
                    			

                    				newLeafNode(this_PARAMSLONGCOMENT_2, grammarAccess.getLongCommentAccess().getPARAMSLONGCOMENTTerminalRuleCall_2());
                    			

                    }
                    break;

            }

            // InternalSM2.g:5615:3: (this_TITLELONGCOMENT_3= RULE_TITLELONGCOMENT )?
            int alt153=2;
            int LA153_0 = input.LA(1);

            if ( (LA153_0==RULE_TITLELONGCOMENT) ) {
                alt153=1;
            }
            switch (alt153) {
                case 1 :
                    // InternalSM2.g:5616:4: this_TITLELONGCOMENT_3= RULE_TITLELONGCOMENT
                    {
                    this_TITLELONGCOMENT_3=(Token)match(input,RULE_TITLELONGCOMENT,FOLLOW_94); 

                    				current.merge(this_TITLELONGCOMENT_3);
                    			

                    				newLeafNode(this_TITLELONGCOMENT_3, grammarAccess.getLongCommentAccess().getTITLELONGCOMENTTerminalRuleCall_3());
                    			

                    }
                    break;

            }

            // InternalSM2.g:5624:3: (this_DEVLONGCOMENT_4= RULE_DEVLONGCOMENT )?
            int alt154=2;
            int LA154_0 = input.LA(1);

            if ( (LA154_0==RULE_DEVLONGCOMENT) ) {
                alt154=1;
            }
            switch (alt154) {
                case 1 :
                    // InternalSM2.g:5625:4: this_DEVLONGCOMENT_4= RULE_DEVLONGCOMENT
                    {
                    this_DEVLONGCOMENT_4=(Token)match(input,RULE_DEVLONGCOMENT,FOLLOW_95); 

                    				current.merge(this_DEVLONGCOMENT_4);
                    			

                    				newLeafNode(this_DEVLONGCOMENT_4, grammarAccess.getLongCommentAccess().getDEVLONGCOMENTTerminalRuleCall_4());
                    			

                    }
                    break;

            }

            // InternalSM2.g:5633:3: (this_RETURNSLONGCOMENT_5= RULE_RETURNSLONGCOMENT )?
            int alt155=2;
            int LA155_0 = input.LA(1);

            if ( (LA155_0==RULE_RETURNSLONGCOMENT) ) {
                alt155=1;
            }
            switch (alt155) {
                case 1 :
                    // InternalSM2.g:5634:4: this_RETURNSLONGCOMENT_5= RULE_RETURNSLONGCOMENT
                    {
                    this_RETURNSLONGCOMENT_5=(Token)match(input,RULE_RETURNSLONGCOMENT,FOLLOW_96); 

                    				current.merge(this_RETURNSLONGCOMENT_5);
                    			

                    				newLeafNode(this_RETURNSLONGCOMENT_5, grammarAccess.getLongCommentAccess().getRETURNSLONGCOMENTTerminalRuleCall_5());
                    			

                    }
                    break;

            }

            kw=(Token)match(input,163,FOLLOW_23); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_6());
            		
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			current.merge(this_EOLINE_7);
            		

            			newLeafNode(this_EOLINE_7, grammarAccess.getLongCommentAccess().getEOLINETerminalRuleCall_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:5658:1: entryRuleExpression returns [String current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final String entryRuleExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleExpression = null;


        try {
            // InternalSM2.g:5658:50: (iv_ruleExpression= ruleExpression EOF )
            // InternalSM2.g:5659:2: iv_ruleExpression= ruleExpression EOF
            {
             newCompositeNode(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;

             current =iv_ruleExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:5665:1: ruleExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression | this_TypeCastingExpression_2= ruleTypeCastingExpression | this_CreateObjectExpression_3= ruleCreateObjectExpression | this_TupleExpression_4= ruleTupleExpression | this_DeleteExpression_5= ruleDeleteExpression | this_EmitEventExpression_6= ruleEmitEventExpression | this_ReturnExpression_7= ruleReturnExpression | this_ComparationExpression_8= ruleComparationExpression | this_ArithmeticalComparationExpression_9= ruleArithmeticalComparationExpression | this_ArithmeticalExpression_10= ruleArithmeticalExpression | this_AndExpression_11= ruleAndExpression | this_OrExpression_12= ruleOrExpression | this_IncrementLoopExpression_13= ruleIncrementLoopExpression | this_DecrementLoopExpression_14= ruleDecrementLoopExpression | this_ConditionalExpression_15= ruleConditionalExpression | this_TimeExpression_16= ruleTimeExpression ) ;
    public final AntlrDatatypeRuleToken ruleExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        AntlrDatatypeRuleToken this_NegationExpression_0 = null;

        AntlrDatatypeRuleToken this_SyntaxExpression_1 = null;

        AntlrDatatypeRuleToken this_TypeCastingExpression_2 = null;

        AntlrDatatypeRuleToken this_CreateObjectExpression_3 = null;

        AntlrDatatypeRuleToken this_TupleExpression_4 = null;

        AntlrDatatypeRuleToken this_DeleteExpression_5 = null;

        AntlrDatatypeRuleToken this_EmitEventExpression_6 = null;

        AntlrDatatypeRuleToken this_ReturnExpression_7 = null;

        AntlrDatatypeRuleToken this_ComparationExpression_8 = null;

        AntlrDatatypeRuleToken this_ArithmeticalComparationExpression_9 = null;

        AntlrDatatypeRuleToken this_ArithmeticalExpression_10 = null;

        AntlrDatatypeRuleToken this_AndExpression_11 = null;

        AntlrDatatypeRuleToken this_OrExpression_12 = null;

        AntlrDatatypeRuleToken this_IncrementLoopExpression_13 = null;

        AntlrDatatypeRuleToken this_DecrementLoopExpression_14 = null;

        AntlrDatatypeRuleToken this_ConditionalExpression_15 = null;

        AntlrDatatypeRuleToken this_TimeExpression_16 = null;



        	enterRule();

        try {
            // InternalSM2.g:5671:2: ( (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression | this_TypeCastingExpression_2= ruleTypeCastingExpression | this_CreateObjectExpression_3= ruleCreateObjectExpression | this_TupleExpression_4= ruleTupleExpression | this_DeleteExpression_5= ruleDeleteExpression | this_EmitEventExpression_6= ruleEmitEventExpression | this_ReturnExpression_7= ruleReturnExpression | this_ComparationExpression_8= ruleComparationExpression | this_ArithmeticalComparationExpression_9= ruleArithmeticalComparationExpression | this_ArithmeticalExpression_10= ruleArithmeticalExpression | this_AndExpression_11= ruleAndExpression | this_OrExpression_12= ruleOrExpression | this_IncrementLoopExpression_13= ruleIncrementLoopExpression | this_DecrementLoopExpression_14= ruleDecrementLoopExpression | this_ConditionalExpression_15= ruleConditionalExpression | this_TimeExpression_16= ruleTimeExpression ) )
            // InternalSM2.g:5672:2: (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression | this_TypeCastingExpression_2= ruleTypeCastingExpression | this_CreateObjectExpression_3= ruleCreateObjectExpression | this_TupleExpression_4= ruleTupleExpression | this_DeleteExpression_5= ruleDeleteExpression | this_EmitEventExpression_6= ruleEmitEventExpression | this_ReturnExpression_7= ruleReturnExpression | this_ComparationExpression_8= ruleComparationExpression | this_ArithmeticalComparationExpression_9= ruleArithmeticalComparationExpression | this_ArithmeticalExpression_10= ruleArithmeticalExpression | this_AndExpression_11= ruleAndExpression | this_OrExpression_12= ruleOrExpression | this_IncrementLoopExpression_13= ruleIncrementLoopExpression | this_DecrementLoopExpression_14= ruleDecrementLoopExpression | this_ConditionalExpression_15= ruleConditionalExpression | this_TimeExpression_16= ruleTimeExpression )
            {
            // InternalSM2.g:5672:2: (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression | this_TypeCastingExpression_2= ruleTypeCastingExpression | this_CreateObjectExpression_3= ruleCreateObjectExpression | this_TupleExpression_4= ruleTupleExpression | this_DeleteExpression_5= ruleDeleteExpression | this_EmitEventExpression_6= ruleEmitEventExpression | this_ReturnExpression_7= ruleReturnExpression | this_ComparationExpression_8= ruleComparationExpression | this_ArithmeticalComparationExpression_9= ruleArithmeticalComparationExpression | this_ArithmeticalExpression_10= ruleArithmeticalExpression | this_AndExpression_11= ruleAndExpression | this_OrExpression_12= ruleOrExpression | this_IncrementLoopExpression_13= ruleIncrementLoopExpression | this_DecrementLoopExpression_14= ruleDecrementLoopExpression | this_ConditionalExpression_15= ruleConditionalExpression | this_TimeExpression_16= ruleTimeExpression )
            int alt156=17;
            alt156 = dfa156.predict(input);
            switch (alt156) {
                case 1 :
                    // InternalSM2.g:5673:3: this_NegationExpression_0= ruleNegationExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getNegationExpressionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_NegationExpression_0=ruleNegationExpression();

                    state._fsp--;


                    			current.merge(this_NegationExpression_0);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:5684:3: this_SyntaxExpression_1= ruleSyntaxExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_SyntaxExpression_1=ruleSyntaxExpression();

                    state._fsp--;


                    			current.merge(this_SyntaxExpression_1);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:5695:3: this_TypeCastingExpression_2= ruleTypeCastingExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getTypeCastingExpressionParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_TypeCastingExpression_2=ruleTypeCastingExpression();

                    state._fsp--;


                    			current.merge(this_TypeCastingExpression_2);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalSM2.g:5706:3: this_CreateObjectExpression_3= ruleCreateObjectExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getCreateObjectExpressionParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_CreateObjectExpression_3=ruleCreateObjectExpression();

                    state._fsp--;


                    			current.merge(this_CreateObjectExpression_3);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalSM2.g:5717:3: this_TupleExpression_4= ruleTupleExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getTupleExpressionParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_TupleExpression_4=ruleTupleExpression();

                    state._fsp--;


                    			current.merge(this_TupleExpression_4);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalSM2.g:5728:3: this_DeleteExpression_5= ruleDeleteExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getDeleteExpressionParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_DeleteExpression_5=ruleDeleteExpression();

                    state._fsp--;


                    			current.merge(this_DeleteExpression_5);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 7 :
                    // InternalSM2.g:5739:3: this_EmitEventExpression_6= ruleEmitEventExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getEmitEventExpressionParserRuleCall_6());
                    		
                    pushFollow(FOLLOW_2);
                    this_EmitEventExpression_6=ruleEmitEventExpression();

                    state._fsp--;


                    			current.merge(this_EmitEventExpression_6);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 8 :
                    // InternalSM2.g:5750:3: this_ReturnExpression_7= ruleReturnExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getReturnExpressionParserRuleCall_7());
                    		
                    pushFollow(FOLLOW_2);
                    this_ReturnExpression_7=ruleReturnExpression();

                    state._fsp--;


                    			current.merge(this_ReturnExpression_7);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 9 :
                    // InternalSM2.g:5761:3: this_ComparationExpression_8= ruleComparationExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getComparationExpressionParserRuleCall_8());
                    		
                    pushFollow(FOLLOW_2);
                    this_ComparationExpression_8=ruleComparationExpression();

                    state._fsp--;


                    			current.merge(this_ComparationExpression_8);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 10 :
                    // InternalSM2.g:5772:3: this_ArithmeticalComparationExpression_9= ruleArithmeticalComparationExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getArithmeticalComparationExpressionParserRuleCall_9());
                    		
                    pushFollow(FOLLOW_2);
                    this_ArithmeticalComparationExpression_9=ruleArithmeticalComparationExpression();

                    state._fsp--;


                    			current.merge(this_ArithmeticalComparationExpression_9);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 11 :
                    // InternalSM2.g:5783:3: this_ArithmeticalExpression_10= ruleArithmeticalExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getArithmeticalExpressionParserRuleCall_10());
                    		
                    pushFollow(FOLLOW_2);
                    this_ArithmeticalExpression_10=ruleArithmeticalExpression();

                    state._fsp--;


                    			current.merge(this_ArithmeticalExpression_10);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 12 :
                    // InternalSM2.g:5794:3: this_AndExpression_11= ruleAndExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getAndExpressionParserRuleCall_11());
                    		
                    pushFollow(FOLLOW_2);
                    this_AndExpression_11=ruleAndExpression();

                    state._fsp--;


                    			current.merge(this_AndExpression_11);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 13 :
                    // InternalSM2.g:5805:3: this_OrExpression_12= ruleOrExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getOrExpressionParserRuleCall_12());
                    		
                    pushFollow(FOLLOW_2);
                    this_OrExpression_12=ruleOrExpression();

                    state._fsp--;


                    			current.merge(this_OrExpression_12);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 14 :
                    // InternalSM2.g:5816:3: this_IncrementLoopExpression_13= ruleIncrementLoopExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getIncrementLoopExpressionParserRuleCall_13());
                    		
                    pushFollow(FOLLOW_2);
                    this_IncrementLoopExpression_13=ruleIncrementLoopExpression();

                    state._fsp--;


                    			current.merge(this_IncrementLoopExpression_13);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 15 :
                    // InternalSM2.g:5827:3: this_DecrementLoopExpression_14= ruleDecrementLoopExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getDecrementLoopExpressionParserRuleCall_14());
                    		
                    pushFollow(FOLLOW_2);
                    this_DecrementLoopExpression_14=ruleDecrementLoopExpression();

                    state._fsp--;


                    			current.merge(this_DecrementLoopExpression_14);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 16 :
                    // InternalSM2.g:5838:3: this_ConditionalExpression_15= ruleConditionalExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getConditionalExpressionParserRuleCall_15());
                    		
                    pushFollow(FOLLOW_2);
                    this_ConditionalExpression_15=ruleConditionalExpression();

                    state._fsp--;


                    			current.merge(this_ConditionalExpression_15);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 17 :
                    // InternalSM2.g:5849:3: this_TimeExpression_16= ruleTimeExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getTimeExpressionParserRuleCall_16());
                    		
                    pushFollow(FOLLOW_2);
                    this_TimeExpression_16=ruleTimeExpression();

                    state._fsp--;


                    			current.merge(this_TimeExpression_16);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleLogicalUnaryOperator"
    // InternalSM2.g:5863:1: entryRuleLogicalUnaryOperator returns [String current=null] : iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF ;
    public final String entryRuleLogicalUnaryOperator() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleLogicalUnaryOperator = null;


        try {
            // InternalSM2.g:5863:60: (iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF )
            // InternalSM2.g:5864:2: iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF
            {
             newCompositeNode(grammarAccess.getLogicalUnaryOperatorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLogicalUnaryOperator=ruleLogicalUnaryOperator();

            state._fsp--;

             current =iv_ruleLogicalUnaryOperator.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLogicalUnaryOperator"


    // $ANTLR start "ruleLogicalUnaryOperator"
    // InternalSM2.g:5870:1: ruleLogicalUnaryOperator returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= '!' ;
    public final AntlrDatatypeRuleToken ruleLogicalUnaryOperator() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSM2.g:5876:2: (kw= '!' )
            // InternalSM2.g:5877:2: kw= '!'
            {
            kw=(Token)match(input,164,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getLogicalUnaryOperatorAccess().getExclamationMarkKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalUnaryOperator"


    // $ANTLR start "entryRuleNegationExpression"
    // InternalSM2.g:5885:1: entryRuleNegationExpression returns [String current=null] : iv_ruleNegationExpression= ruleNegationExpression EOF ;
    public final String entryRuleNegationExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleNegationExpression = null;


        try {
            // InternalSM2.g:5885:58: (iv_ruleNegationExpression= ruleNegationExpression EOF )
            // InternalSM2.g:5886:2: iv_ruleNegationExpression= ruleNegationExpression EOF
            {
             newCompositeNode(grammarAccess.getNegationExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNegationExpression=ruleNegationExpression();

            state._fsp--;

             current =iv_ruleNegationExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNegationExpression"


    // $ANTLR start "ruleNegationExpression"
    // InternalSM2.g:5892:1: ruleNegationExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING ) ;
    public final AntlrDatatypeRuleToken ruleNegationExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_1=null;
        AntlrDatatypeRuleToken this_LogicalUnaryOperator_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:5898:2: ( (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING ) )
            // InternalSM2.g:5899:2: (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING )
            {
            // InternalSM2.g:5899:2: (this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING )
            // InternalSM2.g:5900:3: this_LogicalUnaryOperator_0= ruleLogicalUnaryOperator this_STRING_1= RULE_STRING
            {

            			newCompositeNode(grammarAccess.getNegationExpressionAccess().getLogicalUnaryOperatorParserRuleCall_0());
            		
            pushFollow(FOLLOW_10);
            this_LogicalUnaryOperator_0=ruleLogicalUnaryOperator();

            state._fsp--;


            			current.merge(this_LogicalUnaryOperator_0);
            		

            			afterParserOrEnumRuleCall();
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_2); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getNegationExpressionAccess().getSTRINGTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNegationExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:5921:1: entryRuleSyntaxExpression returns [String current=null] : iv_ruleSyntaxExpression= ruleSyntaxExpression EOF ;
    public final String entryRuleSyntaxExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleSyntaxExpression = null;


        try {
            // InternalSM2.g:5921:56: (iv_ruleSyntaxExpression= ruleSyntaxExpression EOF )
            // InternalSM2.g:5922:2: iv_ruleSyntaxExpression= ruleSyntaxExpression EOF
            {
             newCompositeNode(grammarAccess.getSyntaxExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSyntaxExpression=ruleSyntaxExpression();

            state._fsp--;

             current =iv_ruleSyntaxExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:5928:1: ruleSyntaxExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? ) ;
    public final AntlrDatatypeRuleToken ruleSyntaxExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_SEMICOLON_1=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:5934:2: ( (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? ) )
            // InternalSM2.g:5935:2: (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? )
            {
            // InternalSM2.g:5935:2: (this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )? )
            // InternalSM2.g:5936:3: this_STRING_0= RULE_STRING (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )?
            {
            this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_22); 

            			current.merge(this_STRING_0);
            		

            			newLeafNode(this_STRING_0, grammarAccess.getSyntaxExpressionAccess().getSTRINGTerminalRuleCall_0());
            		
            // InternalSM2.g:5943:3: (this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE )?
            int alt157=2;
            int LA157_0 = input.LA(1);

            if ( (LA157_0==RULE_SEMICOLON) ) {
                int LA157_1 = input.LA(2);

                if ( (LA157_1==RULE_EOLINE) ) {
                    int LA157_3 = input.LA(3);

                    if ( (LA157_3==EOF||(LA157_3>=RULE_SEMICOLON && LA157_3<=RULE_STRING)||LA157_3==RULE_CLOSEKEY||(LA157_3>=RULE_OPENPARENTHESIS && LA157_3<=RULE_CLOSEPARENTHESIS)||(LA157_3>=RULE_COMMA && LA157_3<=RULE_INT)||(LA157_3>=RULE_FLOAT && LA157_3<=RULE_BOOLVALUE)||LA157_3==RULE_NEW||(LA157_3>=RULE_DELETE && LA157_3<=RULE_IF)||LA157_3==RULE_BREAK||LA157_3==83||(LA157_3>=89 && LA157_3<=145)||(LA157_3>=148 && LA157_3<=149)||(LA157_3>=157 && LA157_3<=160)||LA157_3==164) ) {
                        alt157=1;
                    }
                }
            }
            switch (alt157) {
                case 1 :
                    // InternalSM2.g:5944:4: this_SEMICOLON_1= RULE_SEMICOLON this_EOLINE_2= RULE_EOLINE
                    {
                    this_SEMICOLON_1=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); 

                    				current.merge(this_SEMICOLON_1);
                    			

                    				newLeafNode(this_SEMICOLON_1, grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_0());
                    			
                    this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				current.merge(this_EOLINE_2);
                    			

                    				newLeafNode(this_EOLINE_2, grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleTypeCastingExpression"
    // InternalSM2.g:5963:1: entryRuleTypeCastingExpression returns [String current=null] : iv_ruleTypeCastingExpression= ruleTypeCastingExpression EOF ;
    public final String entryRuleTypeCastingExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTypeCastingExpression = null;


        try {
            // InternalSM2.g:5963:61: (iv_ruleTypeCastingExpression= ruleTypeCastingExpression EOF )
            // InternalSM2.g:5964:2: iv_ruleTypeCastingExpression= ruleTypeCastingExpression EOF
            {
             newCompositeNode(grammarAccess.getTypeCastingExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTypeCastingExpression=ruleTypeCastingExpression();

            state._fsp--;

             current =iv_ruleTypeCastingExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTypeCastingExpression"


    // $ANTLR start "ruleTypeCastingExpression"
    // InternalSM2.g:5970:1: ruleTypeCastingExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_PrimitiveTypes_0= rulePrimitiveTypes this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? ) ;
    public final AntlrDatatypeRuleToken ruleTypeCastingExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_OPENPARENTHESIS_1=null;
        Token this_STRING_2=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;
        AntlrDatatypeRuleToken this_PrimitiveTypes_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:5976:2: ( (this_PrimitiveTypes_0= rulePrimitiveTypes this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:5977:2: (this_PrimitiveTypes_0= rulePrimitiveTypes this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:5977:2: (this_PrimitiveTypes_0= rulePrimitiveTypes this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:5978:3: this_PrimitiveTypes_0= rulePrimitiveTypes this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_STRING_2= RULE_STRING this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )?
            {

            			newCompositeNode(grammarAccess.getTypeCastingExpressionAccess().getPrimitiveTypesParserRuleCall_0());
            		
            pushFollow(FOLLOW_19);
            this_PrimitiveTypes_0=rulePrimitiveTypes();

            state._fsp--;


            			current.merge(this_PrimitiveTypes_0);
            		

            			afterParserOrEnumRuleCall();
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_10); 

            			current.merge(this_OPENPARENTHESIS_1);
            		

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getTypeCastingExpressionAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            this_STRING_2=(Token)match(input,RULE_STRING,FOLLOW_21); 

            			current.merge(this_STRING_2);
            		

            			newLeafNode(this_STRING_2, grammarAccess.getTypeCastingExpressionAccess().getSTRINGTerminalRuleCall_2());
            		
            this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_22); 

            			current.merge(this_CLOSEPARENTHESIS_3);
            		

            			newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getTypeCastingExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_3());
            		
            // InternalSM2.g:6009:3: (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )?
            int alt158=2;
            int LA158_0 = input.LA(1);

            if ( (LA158_0==RULE_SEMICOLON) ) {
                alt158=1;
            }
            switch (alt158) {
                case 1 :
                    // InternalSM2.g:6010:4: this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE
                    {
                    this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); 

                    				current.merge(this_SEMICOLON_4);
                    			

                    				newLeafNode(this_SEMICOLON_4, grammarAccess.getTypeCastingExpressionAccess().getSEMICOLONTerminalRuleCall_4_0());
                    			
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				current.merge(this_EOLINE_5);
                    			

                    				newLeafNode(this_EOLINE_5, grammarAccess.getTypeCastingExpressionAccess().getEOLINETerminalRuleCall_4_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTypeCastingExpression"


    // $ANTLR start "entryRuleTimeExpression"
    // InternalSM2.g:6029:1: entryRuleTimeExpression returns [String current=null] : iv_ruleTimeExpression= ruleTimeExpression EOF ;
    public final String entryRuleTimeExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTimeExpression = null;


        try {
            // InternalSM2.g:6029:54: (iv_ruleTimeExpression= ruleTimeExpression EOF )
            // InternalSM2.g:6030:2: iv_ruleTimeExpression= ruleTimeExpression EOF
            {
             newCompositeNode(grammarAccess.getTimeExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTimeExpression=ruleTimeExpression();

            state._fsp--;

             current =iv_ruleTimeExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTimeExpression"


    // $ANTLR start "ruleTimeExpression"
    // InternalSM2.g:6036:1: ruleTimeExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_INT_0= RULE_INT (kw= 'seconds' | kw= 'minutes' | kw= 'hours' | kw= 'days' | kw= 'weeks' | kw= 'years' ) (this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )? ) ;
    public final AntlrDatatypeRuleToken ruleTimeExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_INT_0=null;
        Token kw=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;


        	enterRule();

        try {
            // InternalSM2.g:6042:2: ( (this_INT_0= RULE_INT (kw= 'seconds' | kw= 'minutes' | kw= 'hours' | kw= 'days' | kw= 'weeks' | kw= 'years' ) (this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )? ) )
            // InternalSM2.g:6043:2: (this_INT_0= RULE_INT (kw= 'seconds' | kw= 'minutes' | kw= 'hours' | kw= 'days' | kw= 'weeks' | kw= 'years' ) (this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )? )
            {
            // InternalSM2.g:6043:2: (this_INT_0= RULE_INT (kw= 'seconds' | kw= 'minutes' | kw= 'hours' | kw= 'days' | kw= 'weeks' | kw= 'years' ) (this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )? )
            // InternalSM2.g:6044:3: this_INT_0= RULE_INT (kw= 'seconds' | kw= 'minutes' | kw= 'hours' | kw= 'days' | kw= 'weeks' | kw= 'years' ) (this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )?
            {
            this_INT_0=(Token)match(input,RULE_INT,FOLLOW_97); 

            			current.merge(this_INT_0);
            		

            			newLeafNode(this_INT_0, grammarAccess.getTimeExpressionAccess().getINTTerminalRuleCall_0());
            		
            // InternalSM2.g:6051:3: (kw= 'seconds' | kw= 'minutes' | kw= 'hours' | kw= 'days' | kw= 'weeks' | kw= 'years' )
            int alt159=6;
            switch ( input.LA(1) ) {
            case 165:
                {
                alt159=1;
                }
                break;
            case 166:
                {
                alt159=2;
                }
                break;
            case 167:
                {
                alt159=3;
                }
                break;
            case 168:
                {
                alt159=4;
                }
                break;
            case 169:
                {
                alt159=5;
                }
                break;
            case 170:
                {
                alt159=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 159, 0, input);

                throw nvae;
            }

            switch (alt159) {
                case 1 :
                    // InternalSM2.g:6052:4: kw= 'seconds'
                    {
                    kw=(Token)match(input,165,FOLLOW_22); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getTimeExpressionAccess().getSecondsKeyword_1_0());
                    			

                    }
                    break;
                case 2 :
                    // InternalSM2.g:6058:4: kw= 'minutes'
                    {
                    kw=(Token)match(input,166,FOLLOW_22); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getTimeExpressionAccess().getMinutesKeyword_1_1());
                    			

                    }
                    break;
                case 3 :
                    // InternalSM2.g:6064:4: kw= 'hours'
                    {
                    kw=(Token)match(input,167,FOLLOW_22); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getTimeExpressionAccess().getHoursKeyword_1_2());
                    			

                    }
                    break;
                case 4 :
                    // InternalSM2.g:6070:4: kw= 'days'
                    {
                    kw=(Token)match(input,168,FOLLOW_22); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getTimeExpressionAccess().getDaysKeyword_1_3());
                    			

                    }
                    break;
                case 5 :
                    // InternalSM2.g:6076:4: kw= 'weeks'
                    {
                    kw=(Token)match(input,169,FOLLOW_22); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getTimeExpressionAccess().getWeeksKeyword_1_4());
                    			

                    }
                    break;
                case 6 :
                    // InternalSM2.g:6082:4: kw= 'years'
                    {
                    kw=(Token)match(input,170,FOLLOW_22); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getTimeExpressionAccess().getYearsKeyword_1_5());
                    			

                    }
                    break;

            }

            // InternalSM2.g:6088:3: (this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )?
            int alt160=2;
            int LA160_0 = input.LA(1);

            if ( (LA160_0==RULE_SEMICOLON) ) {
                alt160=1;
            }
            switch (alt160) {
                case 1 :
                    // InternalSM2.g:6089:4: this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE
                    {
                    this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); 

                    				current.merge(this_SEMICOLON_7);
                    			

                    				newLeafNode(this_SEMICOLON_7, grammarAccess.getTimeExpressionAccess().getSEMICOLONTerminalRuleCall_2_0());
                    			
                    this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				current.merge(this_EOLINE_8);
                    			

                    				newLeafNode(this_EOLINE_8, grammarAccess.getTimeExpressionAccess().getEOLINETerminalRuleCall_2_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeExpression"


    // $ANTLR start "entryRuleCreateObjectExpression"
    // InternalSM2.g:6108:1: entryRuleCreateObjectExpression returns [String current=null] : iv_ruleCreateObjectExpression= ruleCreateObjectExpression EOF ;
    public final String entryRuleCreateObjectExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleCreateObjectExpression = null;


        try {
            // InternalSM2.g:6108:62: (iv_ruleCreateObjectExpression= ruleCreateObjectExpression EOF )
            // InternalSM2.g:6109:2: iv_ruleCreateObjectExpression= ruleCreateObjectExpression EOF
            {
             newCompositeNode(grammarAccess.getCreateObjectExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCreateObjectExpression=ruleCreateObjectExpression();

            state._fsp--;

             current =iv_ruleCreateObjectExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCreateObjectExpression"


    // $ANTLR start "ruleCreateObjectExpression"
    // InternalSM2.g:6115:1: ruleCreateObjectExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_NEW_0= RULE_NEW ( (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) ) ) ;
    public final AntlrDatatypeRuleToken ruleCreateObjectExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_NEW_0=null;
        Token this_ID_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENPARENTHESIS_7=null;
        Token this_CLOSEPARENTHESIS_9=null;
        AntlrDatatypeRuleToken this_Expression_3 = null;

        AntlrDatatypeRuleToken this_SyntaxExpression_5 = null;

        AntlrDatatypeRuleToken this_Array_6 = null;

        AntlrDatatypeRuleToken this_Expression_8 = null;



        	enterRule();

        try {
            // InternalSM2.g:6121:2: ( (this_NEW_0= RULE_NEW ( (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) ) ) )
            // InternalSM2.g:6122:2: (this_NEW_0= RULE_NEW ( (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) ) )
            {
            // InternalSM2.g:6122:2: (this_NEW_0= RULE_NEW ( (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) ) )
            // InternalSM2.g:6123:3: this_NEW_0= RULE_NEW ( (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) )
            {
            this_NEW_0=(Token)match(input,RULE_NEW,FOLLOW_98); 

            			current.merge(this_NEW_0);
            		

            			newLeafNode(this_NEW_0, grammarAccess.getCreateObjectExpressionAccess().getNEWTerminalRuleCall_0());
            		
            // InternalSM2.g:6130:3: ( (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS ) )
            int alt164=2;
            int LA164_0 = input.LA(1);

            if ( (LA164_0==RULE_ID) ) {
                alt164=1;
            }
            else if ( (LA164_0==RULE_STRING) ) {
                alt164=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 164, 0, input);

                throw nvae;
            }
            switch (alt164) {
                case 1 :
                    // InternalSM2.g:6131:4: (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:6131:4: (this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:6132:5: this_ID_1= RULE_ID this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS (this_Expression_3= ruleExpression )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_19); 

                    					current.merge(this_ID_1);
                    				

                    					newLeafNode(this_ID_1, grammarAccess.getCreateObjectExpressionAccess().getIDTerminalRuleCall_1_0_0());
                    				
                    this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_99); 

                    					current.merge(this_OPENPARENTHESIS_2);
                    				

                    					newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getCreateObjectExpressionAccess().getOPENPARENTHESISTerminalRuleCall_1_0_1());
                    				
                    // InternalSM2.g:6146:5: (this_Expression_3= ruleExpression )?
                    int alt161=2;
                    int LA161_0 = input.LA(1);

                    if ( (LA161_0==RULE_STRING||LA161_0==RULE_OPENPARENTHESIS||LA161_0==RULE_INT||(LA161_0>=RULE_FLOAT && LA161_0<=RULE_BOOLVALUE)||LA161_0==RULE_NEW||(LA161_0>=RULE_DELETE && LA161_0<=RULE_IF)||LA161_0==83||(LA161_0>=89 && LA161_0<=145)||LA161_0==164) ) {
                        alt161=1;
                    }
                    switch (alt161) {
                        case 1 :
                            // InternalSM2.g:6147:6: this_Expression_3= ruleExpression
                            {

                            						newCompositeNode(grammarAccess.getCreateObjectExpressionAccess().getExpressionParserRuleCall_1_0_2());
                            					
                            pushFollow(FOLLOW_21);
                            this_Expression_3=ruleExpression();

                            state._fsp--;


                            						current.merge(this_Expression_3);
                            					

                            						afterParserOrEnumRuleCall();
                            					

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                    					current.merge(this_CLOSEPARENTHESIS_4);
                    				

                    					newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getCreateObjectExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_3());
                    				

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6167:4: ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:6167:4: ( (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:6168:5: (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? ) this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS (this_Expression_8= ruleExpression )? this_CLOSEPARENTHESIS_9= RULE_CLOSEPARENTHESIS
                    {
                    // InternalSM2.g:6168:5: (this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )? )
                    // InternalSM2.g:6169:6: this_SyntaxExpression_5= ruleSyntaxExpression (this_Array_6= ruleArray )?
                    {

                    						newCompositeNode(grammarAccess.getCreateObjectExpressionAccess().getSyntaxExpressionParserRuleCall_1_1_0_0());
                    					
                    pushFollow(FOLLOW_100);
                    this_SyntaxExpression_5=ruleSyntaxExpression();

                    state._fsp--;


                    						current.merge(this_SyntaxExpression_5);
                    					

                    						afterParserOrEnumRuleCall();
                    					
                    // InternalSM2.g:6179:6: (this_Array_6= ruleArray )?
                    int alt162=2;
                    int LA162_0 = input.LA(1);

                    if ( ((LA162_0>=148 && LA162_0<=149)) ) {
                        alt162=1;
                    }
                    switch (alt162) {
                        case 1 :
                            // InternalSM2.g:6180:7: this_Array_6= ruleArray
                            {

                            							newCompositeNode(grammarAccess.getCreateObjectExpressionAccess().getArrayParserRuleCall_1_1_0_1());
                            						
                            pushFollow(FOLLOW_19);
                            this_Array_6=ruleArray();

                            state._fsp--;


                            							current.merge(this_Array_6);
                            						

                            							afterParserOrEnumRuleCall();
                            						

                            }
                            break;

                    }


                    }

                    this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_99); 

                    					current.merge(this_OPENPARENTHESIS_7);
                    				

                    					newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getCreateObjectExpressionAccess().getOPENPARENTHESISTerminalRuleCall_1_1_1());
                    				
                    // InternalSM2.g:6199:5: (this_Expression_8= ruleExpression )?
                    int alt163=2;
                    int LA163_0 = input.LA(1);

                    if ( (LA163_0==RULE_STRING||LA163_0==RULE_OPENPARENTHESIS||LA163_0==RULE_INT||(LA163_0>=RULE_FLOAT && LA163_0<=RULE_BOOLVALUE)||LA163_0==RULE_NEW||(LA163_0>=RULE_DELETE && LA163_0<=RULE_IF)||LA163_0==83||(LA163_0>=89 && LA163_0<=145)||LA163_0==164) ) {
                        alt163=1;
                    }
                    switch (alt163) {
                        case 1 :
                            // InternalSM2.g:6200:6: this_Expression_8= ruleExpression
                            {

                            						newCompositeNode(grammarAccess.getCreateObjectExpressionAccess().getExpressionParserRuleCall_1_1_2());
                            					
                            pushFollow(FOLLOW_21);
                            this_Expression_8=ruleExpression();

                            state._fsp--;


                            						current.merge(this_Expression_8);
                            					

                            						afterParserOrEnumRuleCall();
                            					

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_9=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                    					current.merge(this_CLOSEPARENTHESIS_9);
                    				

                    					newLeafNode(this_CLOSEPARENTHESIS_9, grammarAccess.getCreateObjectExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_3());
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCreateObjectExpression"


    // $ANTLR start "entryRuleDeleteExpression"
    // InternalSM2.g:6224:1: entryRuleDeleteExpression returns [String current=null] : iv_ruleDeleteExpression= ruleDeleteExpression EOF ;
    public final String entryRuleDeleteExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleDeleteExpression = null;


        try {
            // InternalSM2.g:6224:56: (iv_ruleDeleteExpression= ruleDeleteExpression EOF )
            // InternalSM2.g:6225:2: iv_ruleDeleteExpression= ruleDeleteExpression EOF
            {
             newCompositeNode(grammarAccess.getDeleteExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDeleteExpression=ruleDeleteExpression();

            state._fsp--;

             current =iv_ruleDeleteExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDeleteExpression"


    // $ANTLR start "ruleDeleteExpression"
    // InternalSM2.g:6231:1: ruleDeleteExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_DELETE_0= RULE_DELETE this_SyntaxExpression_1= ruleSyntaxExpression ) ;
    public final AntlrDatatypeRuleToken ruleDeleteExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_DELETE_0=null;
        AntlrDatatypeRuleToken this_SyntaxExpression_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:6237:2: ( (this_DELETE_0= RULE_DELETE this_SyntaxExpression_1= ruleSyntaxExpression ) )
            // InternalSM2.g:6238:2: (this_DELETE_0= RULE_DELETE this_SyntaxExpression_1= ruleSyntaxExpression )
            {
            // InternalSM2.g:6238:2: (this_DELETE_0= RULE_DELETE this_SyntaxExpression_1= ruleSyntaxExpression )
            // InternalSM2.g:6239:3: this_DELETE_0= RULE_DELETE this_SyntaxExpression_1= ruleSyntaxExpression
            {
            this_DELETE_0=(Token)match(input,RULE_DELETE,FOLLOW_10); 

            			current.merge(this_DELETE_0);
            		

            			newLeafNode(this_DELETE_0, grammarAccess.getDeleteExpressionAccess().getDELETETerminalRuleCall_0());
            		

            			newCompositeNode(grammarAccess.getDeleteExpressionAccess().getSyntaxExpressionParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_SyntaxExpression_1=ruleSyntaxExpression();

            state._fsp--;


            			current.merge(this_SyntaxExpression_1);
            		

            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDeleteExpression"


    // $ANTLR start "entryRuleTupleExpression"
    // InternalSM2.g:6260:1: entryRuleTupleExpression returns [String current=null] : iv_ruleTupleExpression= ruleTupleExpression EOF ;
    public final String entryRuleTupleExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleTupleExpression = null;


        try {
            // InternalSM2.g:6260:55: (iv_ruleTupleExpression= ruleTupleExpression EOF )
            // InternalSM2.g:6261:2: iv_ruleTupleExpression= ruleTupleExpression EOF
            {
             newCompositeNode(grammarAccess.getTupleExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTupleExpression=ruleTupleExpression();

            state._fsp--;

             current =iv_ruleTupleExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTupleExpression"


    // $ANTLR start "ruleTupleExpression"
    // InternalSM2.g:6267:1: ruleTupleExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS (this_Expression_1= ruleExpression (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? ) ;
    public final AntlrDatatypeRuleToken ruleTupleExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_OPENPARENTHESIS_0=null;
        Token this_COMMA_2=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;
        AntlrDatatypeRuleToken this_Expression_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:6273:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS (this_Expression_1= ruleExpression (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:6274:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS (this_Expression_1= ruleExpression (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:6274:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS (this_Expression_1= ruleExpression (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:6275:3: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS (this_Expression_1= ruleExpression (this_COMMA_2= RULE_COMMA )? )+ this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )?
            {
            this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_20); 

            			current.merge(this_OPENPARENTHESIS_0);
            		

            			newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getTupleExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0());
            		
            // InternalSM2.g:6282:3: (this_Expression_1= ruleExpression (this_COMMA_2= RULE_COMMA )? )+
            int cnt166=0;
            loop166:
            do {
                int alt166=2;
                int LA166_0 = input.LA(1);

                if ( (LA166_0==RULE_STRING||LA166_0==RULE_OPENPARENTHESIS||LA166_0==RULE_INT||(LA166_0>=RULE_FLOAT && LA166_0<=RULE_BOOLVALUE)||LA166_0==RULE_NEW||(LA166_0>=RULE_DELETE && LA166_0<=RULE_IF)||LA166_0==83||(LA166_0>=89 && LA166_0<=145)||LA166_0==164) ) {
                    alt166=1;
                }


                switch (alt166) {
            	case 1 :
            	    // InternalSM2.g:6283:4: this_Expression_1= ruleExpression (this_COMMA_2= RULE_COMMA )?
            	    {

            	    				newCompositeNode(grammarAccess.getTupleExpressionAccess().getExpressionParserRuleCall_1_0());
            	    			
            	    pushFollow(FOLLOW_101);
            	    this_Expression_1=ruleExpression();

            	    state._fsp--;


            	    				current.merge(this_Expression_1);
            	    			

            	    				afterParserOrEnumRuleCall();
            	    			
            	    // InternalSM2.g:6293:4: (this_COMMA_2= RULE_COMMA )?
            	    int alt165=2;
            	    int LA165_0 = input.LA(1);

            	    if ( (LA165_0==RULE_COMMA) ) {
            	        alt165=1;
            	    }
            	    switch (alt165) {
            	        case 1 :
            	            // InternalSM2.g:6294:5: this_COMMA_2= RULE_COMMA
            	            {
            	            this_COMMA_2=(Token)match(input,RULE_COMMA,FOLLOW_99); 

            	            					current.merge(this_COMMA_2);
            	            				

            	            					newLeafNode(this_COMMA_2, grammarAccess.getTupleExpressionAccess().getCOMMATerminalRuleCall_1_1());
            	            				

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt166 >= 1 ) break loop166;
                        EarlyExitException eee =
                            new EarlyExitException(166, input);
                        throw eee;
                }
                cnt166++;
            } while (true);

            this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_22); 

            			current.merge(this_CLOSEPARENTHESIS_3);
            		

            			newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getTupleExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_2());
            		
            // InternalSM2.g:6310:3: (this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE )?
            int alt167=2;
            int LA167_0 = input.LA(1);

            if ( (LA167_0==RULE_SEMICOLON) ) {
                alt167=1;
            }
            switch (alt167) {
                case 1 :
                    // InternalSM2.g:6311:4: this_SEMICOLON_4= RULE_SEMICOLON this_EOLINE_5= RULE_EOLINE
                    {
                    this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); 

                    				current.merge(this_SEMICOLON_4);
                    			

                    				newLeafNode(this_SEMICOLON_4, grammarAccess.getTupleExpressionAccess().getSEMICOLONTerminalRuleCall_3_0());
                    			
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				current.merge(this_EOLINE_5);
                    			

                    				newLeafNode(this_EOLINE_5, grammarAccess.getTupleExpressionAccess().getEOLINETerminalRuleCall_3_1());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTupleExpression"


    // $ANTLR start "entryRuleEmitEventExpression"
    // InternalSM2.g:6330:1: entryRuleEmitEventExpression returns [String current=null] : iv_ruleEmitEventExpression= ruleEmitEventExpression EOF ;
    public final String entryRuleEmitEventExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEmitEventExpression = null;


        try {
            // InternalSM2.g:6330:59: (iv_ruleEmitEventExpression= ruleEmitEventExpression EOF )
            // InternalSM2.g:6331:2: iv_ruleEmitEventExpression= ruleEmitEventExpression EOF
            {
             newCompositeNode(grammarAccess.getEmitEventExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEmitEventExpression=ruleEmitEventExpression();

            state._fsp--;

             current =iv_ruleEmitEventExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEmitEventExpression"


    // $ANTLR start "ruleEmitEventExpression"
    // InternalSM2.g:6337:1: ruleEmitEventExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_EMIT_0= RULE_EMIT this_SyntaxExpression_1= ruleSyntaxExpression ) ;
    public final AntlrDatatypeRuleToken ruleEmitEventExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_EMIT_0=null;
        AntlrDatatypeRuleToken this_SyntaxExpression_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:6343:2: ( (this_EMIT_0= RULE_EMIT this_SyntaxExpression_1= ruleSyntaxExpression ) )
            // InternalSM2.g:6344:2: (this_EMIT_0= RULE_EMIT this_SyntaxExpression_1= ruleSyntaxExpression )
            {
            // InternalSM2.g:6344:2: (this_EMIT_0= RULE_EMIT this_SyntaxExpression_1= ruleSyntaxExpression )
            // InternalSM2.g:6345:3: this_EMIT_0= RULE_EMIT this_SyntaxExpression_1= ruleSyntaxExpression
            {
            this_EMIT_0=(Token)match(input,RULE_EMIT,FOLLOW_10); 

            			current.merge(this_EMIT_0);
            		

            			newLeafNode(this_EMIT_0, grammarAccess.getEmitEventExpressionAccess().getEMITTerminalRuleCall_0());
            		

            			newCompositeNode(grammarAccess.getEmitEventExpressionAccess().getSyntaxExpressionParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_SyntaxExpression_1=ruleSyntaxExpression();

            state._fsp--;


            			current.merge(this_SyntaxExpression_1);
            		

            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEmitEventExpression"


    // $ANTLR start "entryRuleReturnExpression"
    // InternalSM2.g:6366:1: entryRuleReturnExpression returns [String current=null] : iv_ruleReturnExpression= ruleReturnExpression EOF ;
    public final String entryRuleReturnExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleReturnExpression = null;


        try {
            // InternalSM2.g:6366:56: (iv_ruleReturnExpression= ruleReturnExpression EOF )
            // InternalSM2.g:6367:2: iv_ruleReturnExpression= ruleReturnExpression EOF
            {
             newCompositeNode(grammarAccess.getReturnExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleReturnExpression=ruleReturnExpression();

            state._fsp--;

             current =iv_ruleReturnExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleReturnExpression"


    // $ANTLR start "ruleReturnExpression"
    // InternalSM2.g:6373:1: ruleReturnExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_RETURN_0= RULE_RETURN this_SyntaxExpression_1= ruleSyntaxExpression ) ;
    public final AntlrDatatypeRuleToken ruleReturnExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_RETURN_0=null;
        AntlrDatatypeRuleToken this_SyntaxExpression_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:6379:2: ( (this_RETURN_0= RULE_RETURN this_SyntaxExpression_1= ruleSyntaxExpression ) )
            // InternalSM2.g:6380:2: (this_RETURN_0= RULE_RETURN this_SyntaxExpression_1= ruleSyntaxExpression )
            {
            // InternalSM2.g:6380:2: (this_RETURN_0= RULE_RETURN this_SyntaxExpression_1= ruleSyntaxExpression )
            // InternalSM2.g:6381:3: this_RETURN_0= RULE_RETURN this_SyntaxExpression_1= ruleSyntaxExpression
            {
            this_RETURN_0=(Token)match(input,RULE_RETURN,FOLLOW_10); 

            			current.merge(this_RETURN_0);
            		

            			newLeafNode(this_RETURN_0, grammarAccess.getReturnExpressionAccess().getRETURNTerminalRuleCall_0());
            		

            			newCompositeNode(grammarAccess.getReturnExpressionAccess().getSyntaxExpressionParserRuleCall_1());
            		
            pushFollow(FOLLOW_2);
            this_SyntaxExpression_1=ruleSyntaxExpression();

            state._fsp--;


            			current.merge(this_SyntaxExpression_1);
            		

            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleReturnExpression"


    // $ANTLR start "entryRuleComparationExpression"
    // InternalSM2.g:6402:1: entryRuleComparationExpression returns [String current=null] : iv_ruleComparationExpression= ruleComparationExpression EOF ;
    public final String entryRuleComparationExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleComparationExpression = null;


        try {
            // InternalSM2.g:6402:61: (iv_ruleComparationExpression= ruleComparationExpression EOF )
            // InternalSM2.g:6403:2: iv_ruleComparationExpression= ruleComparationExpression EOF
            {
             newCompositeNode(grammarAccess.getComparationExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleComparationExpression=ruleComparationExpression();

            state._fsp--;

             current =iv_ruleComparationExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComparationExpression"


    // $ANTLR start "ruleComparationExpression"
    // InternalSM2.g:6409:1: ruleComparationExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (this_STRING_0= RULE_STRING (kw= '==' | kw= '!=' ) this_STRING_3= RULE_STRING ) | this_NumberExpression_4= ruleNumberExpression | (this_BOOLVALUE_5= RULE_BOOLVALUE (this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )? ) ) ;
    public final AntlrDatatypeRuleToken ruleComparationExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token kw=null;
        Token this_STRING_3=null;
        Token this_BOOLVALUE_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken this_NumberExpression_4 = null;



        	enterRule();

        try {
            // InternalSM2.g:6415:2: ( ( (this_STRING_0= RULE_STRING (kw= '==' | kw= '!=' ) this_STRING_3= RULE_STRING ) | this_NumberExpression_4= ruleNumberExpression | (this_BOOLVALUE_5= RULE_BOOLVALUE (this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )? ) ) )
            // InternalSM2.g:6416:2: ( (this_STRING_0= RULE_STRING (kw= '==' | kw= '!=' ) this_STRING_3= RULE_STRING ) | this_NumberExpression_4= ruleNumberExpression | (this_BOOLVALUE_5= RULE_BOOLVALUE (this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:6416:2: ( (this_STRING_0= RULE_STRING (kw= '==' | kw= '!=' ) this_STRING_3= RULE_STRING ) | this_NumberExpression_4= ruleNumberExpression | (this_BOOLVALUE_5= RULE_BOOLVALUE (this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )? ) )
            int alt170=3;
            switch ( input.LA(1) ) {
            case RULE_STRING:
                {
                alt170=1;
                }
                break;
            case RULE_INT:
            case RULE_FLOAT:
                {
                alt170=2;
                }
                break;
            case RULE_BOOLVALUE:
                {
                alt170=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 170, 0, input);

                throw nvae;
            }

            switch (alt170) {
                case 1 :
                    // InternalSM2.g:6417:3: (this_STRING_0= RULE_STRING (kw= '==' | kw= '!=' ) this_STRING_3= RULE_STRING )
                    {
                    // InternalSM2.g:6417:3: (this_STRING_0= RULE_STRING (kw= '==' | kw= '!=' ) this_STRING_3= RULE_STRING )
                    // InternalSM2.g:6418:4: this_STRING_0= RULE_STRING (kw= '==' | kw= '!=' ) this_STRING_3= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_102); 

                    				current.merge(this_STRING_0);
                    			

                    				newLeafNode(this_STRING_0, grammarAccess.getComparationExpressionAccess().getSTRINGTerminalRuleCall_0_0());
                    			
                    // InternalSM2.g:6425:4: (kw= '==' | kw= '!=' )
                    int alt168=2;
                    int LA168_0 = input.LA(1);

                    if ( (LA168_0==171) ) {
                        alt168=1;
                    }
                    else if ( (LA168_0==172) ) {
                        alt168=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 168, 0, input);

                        throw nvae;
                    }
                    switch (alt168) {
                        case 1 :
                            // InternalSM2.g:6426:5: kw= '=='
                            {
                            kw=(Token)match(input,171,FOLLOW_10); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getComparationExpressionAccess().getEqualsSignEqualsSignKeyword_0_1_0());
                            				

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:6432:5: kw= '!='
                            {
                            kw=(Token)match(input,172,FOLLOW_10); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getComparationExpressionAccess().getExclamationMarkEqualsSignKeyword_0_1_1());
                            				

                            }
                            break;

                    }

                    this_STRING_3=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    				current.merge(this_STRING_3);
                    			

                    				newLeafNode(this_STRING_3, grammarAccess.getComparationExpressionAccess().getSTRINGTerminalRuleCall_0_2());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6447:3: this_NumberExpression_4= ruleNumberExpression
                    {

                    			newCompositeNode(grammarAccess.getComparationExpressionAccess().getNumberExpressionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_NumberExpression_4=ruleNumberExpression();

                    state._fsp--;


                    			current.merge(this_NumberExpression_4);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:6458:3: (this_BOOLVALUE_5= RULE_BOOLVALUE (this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:6458:3: (this_BOOLVALUE_5= RULE_BOOLVALUE (this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )? )
                    // InternalSM2.g:6459:4: this_BOOLVALUE_5= RULE_BOOLVALUE (this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )?
                    {
                    this_BOOLVALUE_5=(Token)match(input,RULE_BOOLVALUE,FOLLOW_22); 

                    				current.merge(this_BOOLVALUE_5);
                    			

                    				newLeafNode(this_BOOLVALUE_5, grammarAccess.getComparationExpressionAccess().getBOOLVALUETerminalRuleCall_2_0());
                    			
                    // InternalSM2.g:6466:4: (this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )?
                    int alt169=2;
                    int LA169_0 = input.LA(1);

                    if ( (LA169_0==RULE_SEMICOLON) ) {
                        alt169=1;
                    }
                    switch (alt169) {
                        case 1 :
                            // InternalSM2.g:6467:5: this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE
                            {
                            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); 

                            					current.merge(this_SEMICOLON_6);
                            				

                            					newLeafNode(this_SEMICOLON_6, grammarAccess.getComparationExpressionAccess().getSEMICOLONTerminalRuleCall_2_1_0());
                            				
                            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                            					current.merge(this_EOLINE_7);
                            				

                            					newLeafNode(this_EOLINE_7, grammarAccess.getComparationExpressionAccess().getEOLINETerminalRuleCall_2_1_1());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparationExpression"


    // $ANTLR start "entryRuleArithmeticalComparationExpression"
    // InternalSM2.g:6487:1: entryRuleArithmeticalComparationExpression returns [String current=null] : iv_ruleArithmeticalComparationExpression= ruleArithmeticalComparationExpression EOF ;
    public final String entryRuleArithmeticalComparationExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleArithmeticalComparationExpression = null;


        try {
            // InternalSM2.g:6487:73: (iv_ruleArithmeticalComparationExpression= ruleArithmeticalComparationExpression EOF )
            // InternalSM2.g:6488:2: iv_ruleArithmeticalComparationExpression= ruleArithmeticalComparationExpression EOF
            {
             newCompositeNode(grammarAccess.getArithmeticalComparationExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleArithmeticalComparationExpression=ruleArithmeticalComparationExpression();

            state._fsp--;

             current =iv_ruleArithmeticalComparationExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmeticalComparationExpression"


    // $ANTLR start "ruleArithmeticalComparationExpression"
    // InternalSM2.g:6494:1: ruleArithmeticalComparationExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( ( (this_NumberExpression_0= ruleNumberExpression | this_IncrementLoopExpression_1= ruleIncrementLoopExpression | this_DecrementLoopExpression_2= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_9= ruleNumberExpression | this_IncrementLoopExpression_10= ruleIncrementLoopExpression | this_DecrementLoopExpression_11= ruleDecrementLoopExpression ) ) | (this_STRING_12= RULE_STRING (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_19= ruleNumberExpression | this_IncrementLoopExpression_20= ruleIncrementLoopExpression | this_DecrementLoopExpression_21= ruleDecrementLoopExpression ) ) | ( (this_NumberExpression_22= ruleNumberExpression | this_IncrementLoopExpression_23= ruleIncrementLoopExpression | this_DecrementLoopExpression_24= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) this_STRING_31= RULE_STRING ) ) ;
    public final AntlrDatatypeRuleToken ruleArithmeticalComparationExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_STRING_12=null;
        Token this_STRING_31=null;
        AntlrDatatypeRuleToken this_NumberExpression_0 = null;

        AntlrDatatypeRuleToken this_IncrementLoopExpression_1 = null;

        AntlrDatatypeRuleToken this_DecrementLoopExpression_2 = null;

        AntlrDatatypeRuleToken this_NumberExpression_9 = null;

        AntlrDatatypeRuleToken this_IncrementLoopExpression_10 = null;

        AntlrDatatypeRuleToken this_DecrementLoopExpression_11 = null;

        AntlrDatatypeRuleToken this_NumberExpression_19 = null;

        AntlrDatatypeRuleToken this_IncrementLoopExpression_20 = null;

        AntlrDatatypeRuleToken this_DecrementLoopExpression_21 = null;

        AntlrDatatypeRuleToken this_NumberExpression_22 = null;

        AntlrDatatypeRuleToken this_IncrementLoopExpression_23 = null;

        AntlrDatatypeRuleToken this_DecrementLoopExpression_24 = null;



        	enterRule();

        try {
            // InternalSM2.g:6500:2: ( ( ( (this_NumberExpression_0= ruleNumberExpression | this_IncrementLoopExpression_1= ruleIncrementLoopExpression | this_DecrementLoopExpression_2= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_9= ruleNumberExpression | this_IncrementLoopExpression_10= ruleIncrementLoopExpression | this_DecrementLoopExpression_11= ruleDecrementLoopExpression ) ) | (this_STRING_12= RULE_STRING (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_19= ruleNumberExpression | this_IncrementLoopExpression_20= ruleIncrementLoopExpression | this_DecrementLoopExpression_21= ruleDecrementLoopExpression ) ) | ( (this_NumberExpression_22= ruleNumberExpression | this_IncrementLoopExpression_23= ruleIncrementLoopExpression | this_DecrementLoopExpression_24= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) this_STRING_31= RULE_STRING ) ) )
            // InternalSM2.g:6501:2: ( ( (this_NumberExpression_0= ruleNumberExpression | this_IncrementLoopExpression_1= ruleIncrementLoopExpression | this_DecrementLoopExpression_2= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_9= ruleNumberExpression | this_IncrementLoopExpression_10= ruleIncrementLoopExpression | this_DecrementLoopExpression_11= ruleDecrementLoopExpression ) ) | (this_STRING_12= RULE_STRING (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_19= ruleNumberExpression | this_IncrementLoopExpression_20= ruleIncrementLoopExpression | this_DecrementLoopExpression_21= ruleDecrementLoopExpression ) ) | ( (this_NumberExpression_22= ruleNumberExpression | this_IncrementLoopExpression_23= ruleIncrementLoopExpression | this_DecrementLoopExpression_24= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) this_STRING_31= RULE_STRING ) )
            {
            // InternalSM2.g:6501:2: ( ( (this_NumberExpression_0= ruleNumberExpression | this_IncrementLoopExpression_1= ruleIncrementLoopExpression | this_DecrementLoopExpression_2= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_9= ruleNumberExpression | this_IncrementLoopExpression_10= ruleIncrementLoopExpression | this_DecrementLoopExpression_11= ruleDecrementLoopExpression ) ) | (this_STRING_12= RULE_STRING (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_19= ruleNumberExpression | this_IncrementLoopExpression_20= ruleIncrementLoopExpression | this_DecrementLoopExpression_21= ruleDecrementLoopExpression ) ) | ( (this_NumberExpression_22= ruleNumberExpression | this_IncrementLoopExpression_23= ruleIncrementLoopExpression | this_DecrementLoopExpression_24= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) this_STRING_31= RULE_STRING ) )
            int alt178=3;
            alt178 = dfa178.predict(input);
            switch (alt178) {
                case 1 :
                    // InternalSM2.g:6502:3: ( (this_NumberExpression_0= ruleNumberExpression | this_IncrementLoopExpression_1= ruleIncrementLoopExpression | this_DecrementLoopExpression_2= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_9= ruleNumberExpression | this_IncrementLoopExpression_10= ruleIncrementLoopExpression | this_DecrementLoopExpression_11= ruleDecrementLoopExpression ) )
                    {
                    // InternalSM2.g:6502:3: ( (this_NumberExpression_0= ruleNumberExpression | this_IncrementLoopExpression_1= ruleIncrementLoopExpression | this_DecrementLoopExpression_2= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_9= ruleNumberExpression | this_IncrementLoopExpression_10= ruleIncrementLoopExpression | this_DecrementLoopExpression_11= ruleDecrementLoopExpression ) )
                    // InternalSM2.g:6503:4: (this_NumberExpression_0= ruleNumberExpression | this_IncrementLoopExpression_1= ruleIncrementLoopExpression | this_DecrementLoopExpression_2= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_9= ruleNumberExpression | this_IncrementLoopExpression_10= ruleIncrementLoopExpression | this_DecrementLoopExpression_11= ruleDecrementLoopExpression )
                    {
                    // InternalSM2.g:6503:4: (this_NumberExpression_0= ruleNumberExpression | this_IncrementLoopExpression_1= ruleIncrementLoopExpression | this_DecrementLoopExpression_2= ruleDecrementLoopExpression )
                    int alt171=3;
                    switch ( input.LA(1) ) {
                    case RULE_INT:
                        {
                        switch ( input.LA(2) ) {
                        case 45:
                        case 46:
                        case 171:
                        case 172:
                        case 173:
                        case 174:
                            {
                            alt171=1;
                            }
                            break;
                        case 183:
                            {
                            alt171=3;
                            }
                            break;
                        case 182:
                            {
                            alt171=2;
                            }
                            break;
                        default:
                            NoViableAltException nvae =
                                new NoViableAltException("", 171, 1, input);

                            throw nvae;
                        }

                        }
                        break;
                    case RULE_FLOAT:
                        {
                        alt171=1;
                        }
                        break;
                    case RULE_STRING:
                        {
                        int LA171_3 = input.LA(2);

                        if ( (LA171_3==183) ) {
                            alt171=3;
                        }
                        else if ( (LA171_3==182) ) {
                            alt171=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 171, 3, input);

                            throw nvae;
                        }
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 171, 0, input);

                        throw nvae;
                    }

                    switch (alt171) {
                        case 1 :
                            // InternalSM2.g:6504:5: this_NumberExpression_0= ruleNumberExpression
                            {

                            					newCompositeNode(grammarAccess.getArithmeticalComparationExpressionAccess().getNumberExpressionParserRuleCall_0_0_0());
                            				
                            pushFollow(FOLLOW_82);
                            this_NumberExpression_0=ruleNumberExpression();

                            state._fsp--;


                            					current.merge(this_NumberExpression_0);
                            				

                            					afterParserOrEnumRuleCall();
                            				

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:6515:5: this_IncrementLoopExpression_1= ruleIncrementLoopExpression
                            {

                            					newCompositeNode(grammarAccess.getArithmeticalComparationExpressionAccess().getIncrementLoopExpressionParserRuleCall_0_0_1());
                            				
                            pushFollow(FOLLOW_82);
                            this_IncrementLoopExpression_1=ruleIncrementLoopExpression();

                            state._fsp--;


                            					current.merge(this_IncrementLoopExpression_1);
                            				

                            					afterParserOrEnumRuleCall();
                            				

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:6526:5: this_DecrementLoopExpression_2= ruleDecrementLoopExpression
                            {

                            					newCompositeNode(grammarAccess.getArithmeticalComparationExpressionAccess().getDecrementLoopExpressionParserRuleCall_0_0_2());
                            				
                            pushFollow(FOLLOW_82);
                            this_DecrementLoopExpression_2=ruleDecrementLoopExpression();

                            state._fsp--;


                            					current.merge(this_DecrementLoopExpression_2);
                            				

                            					afterParserOrEnumRuleCall();
                            				

                            }
                            break;

                    }

                    // InternalSM2.g:6537:4: (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' )
                    int alt172=6;
                    switch ( input.LA(1) ) {
                    case 171:
                        {
                        alt172=1;
                        }
                        break;
                    case 172:
                        {
                        alt172=2;
                        }
                        break;
                    case 45:
                        {
                        alt172=3;
                        }
                        break;
                    case 46:
                        {
                        alt172=4;
                        }
                        break;
                    case 173:
                        {
                        alt172=5;
                        }
                        break;
                    case 174:
                        {
                        alt172=6;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 172, 0, input);

                        throw nvae;
                    }

                    switch (alt172) {
                        case 1 :
                            // InternalSM2.g:6538:5: kw= '=='
                            {
                            kw=(Token)match(input,171,FOLLOW_81); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getEqualsSignEqualsSignKeyword_0_1_0());
                            				

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:6544:5: kw= '!='
                            {
                            kw=(Token)match(input,172,FOLLOW_81); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getExclamationMarkEqualsSignKeyword_0_1_1());
                            				

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:6550:5: kw= '>'
                            {
                            kw=(Token)match(input,45,FOLLOW_81); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getGreaterThanSignKeyword_0_1_2());
                            				

                            }
                            break;
                        case 4 :
                            // InternalSM2.g:6556:5: kw= '>='
                            {
                            kw=(Token)match(input,46,FOLLOW_81); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getGreaterThanSignEqualsSignKeyword_0_1_3());
                            				

                            }
                            break;
                        case 5 :
                            // InternalSM2.g:6562:5: kw= '<'
                            {
                            kw=(Token)match(input,173,FOLLOW_81); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getLessThanSignKeyword_0_1_4());
                            				

                            }
                            break;
                        case 6 :
                            // InternalSM2.g:6568:5: kw= '<='
                            {
                            kw=(Token)match(input,174,FOLLOW_81); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getLessThanSignEqualsSignKeyword_0_1_5());
                            				

                            }
                            break;

                    }

                    // InternalSM2.g:6574:4: (this_NumberExpression_9= ruleNumberExpression | this_IncrementLoopExpression_10= ruleIncrementLoopExpression | this_DecrementLoopExpression_11= ruleDecrementLoopExpression )
                    int alt173=3;
                    switch ( input.LA(1) ) {
                    case RULE_INT:
                        {
                        switch ( input.LA(2) ) {
                        case EOF:
                        case RULE_SEMICOLON:
                        case RULE_EOLINE:
                        case RULE_STRING:
                        case RULE_CLOSEKEY:
                        case RULE_OPENPARENTHESIS:
                        case RULE_CLOSEPARENTHESIS:
                        case RULE_COMMA:
                        case RULE_INT:
                        case RULE_FLOAT:
                        case RULE_BOOLVALUE:
                        case RULE_NEW:
                        case RULE_DELETE:
                        case RULE_EMIT:
                        case RULE_RETURN:
                        case RULE_IF:
                        case RULE_BREAK:
                        case 83:
                        case 89:
                        case 90:
                        case 91:
                        case 92:
                        case 93:
                        case 94:
                        case 95:
                        case 96:
                        case 97:
                        case 98:
                        case 99:
                        case 100:
                        case 101:
                        case 102:
                        case 103:
                        case 104:
                        case 105:
                        case 106:
                        case 107:
                        case 108:
                        case 109:
                        case 110:
                        case 111:
                        case 112:
                        case 113:
                        case 114:
                        case 115:
                        case 116:
                        case 117:
                        case 118:
                        case 119:
                        case 120:
                        case 121:
                        case 122:
                        case 123:
                        case 124:
                        case 125:
                        case 126:
                        case 127:
                        case 128:
                        case 129:
                        case 130:
                        case 131:
                        case 132:
                        case 133:
                        case 134:
                        case 135:
                        case 136:
                        case 137:
                        case 138:
                        case 139:
                        case 140:
                        case 141:
                        case 142:
                        case 143:
                        case 144:
                        case 145:
                        case 157:
                        case 158:
                        case 159:
                        case 160:
                        case 164:
                        case 180:
                        case 181:
                            {
                            alt173=1;
                            }
                            break;
                        case 183:
                            {
                            alt173=3;
                            }
                            break;
                        case 182:
                            {
                            alt173=2;
                            }
                            break;
                        default:
                            NoViableAltException nvae =
                                new NoViableAltException("", 173, 1, input);

                            throw nvae;
                        }

                        }
                        break;
                    case RULE_FLOAT:
                        {
                        alt173=1;
                        }
                        break;
                    case RULE_STRING:
                        {
                        int LA173_3 = input.LA(2);

                        if ( (LA173_3==182) ) {
                            alt173=2;
                        }
                        else if ( (LA173_3==183) ) {
                            alt173=3;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 173, 3, input);

                            throw nvae;
                        }
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 173, 0, input);

                        throw nvae;
                    }

                    switch (alt173) {
                        case 1 :
                            // InternalSM2.g:6575:5: this_NumberExpression_9= ruleNumberExpression
                            {

                            					newCompositeNode(grammarAccess.getArithmeticalComparationExpressionAccess().getNumberExpressionParserRuleCall_0_2_0());
                            				
                            pushFollow(FOLLOW_2);
                            this_NumberExpression_9=ruleNumberExpression();

                            state._fsp--;


                            					current.merge(this_NumberExpression_9);
                            				

                            					afterParserOrEnumRuleCall();
                            				

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:6586:5: this_IncrementLoopExpression_10= ruleIncrementLoopExpression
                            {

                            					newCompositeNode(grammarAccess.getArithmeticalComparationExpressionAccess().getIncrementLoopExpressionParserRuleCall_0_2_1());
                            				
                            pushFollow(FOLLOW_2);
                            this_IncrementLoopExpression_10=ruleIncrementLoopExpression();

                            state._fsp--;


                            					current.merge(this_IncrementLoopExpression_10);
                            				

                            					afterParserOrEnumRuleCall();
                            				

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:6597:5: this_DecrementLoopExpression_11= ruleDecrementLoopExpression
                            {

                            					newCompositeNode(grammarAccess.getArithmeticalComparationExpressionAccess().getDecrementLoopExpressionParserRuleCall_0_2_2());
                            				
                            pushFollow(FOLLOW_2);
                            this_DecrementLoopExpression_11=ruleDecrementLoopExpression();

                            state._fsp--;


                            					current.merge(this_DecrementLoopExpression_11);
                            				

                            					afterParserOrEnumRuleCall();
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:6610:3: (this_STRING_12= RULE_STRING (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_19= ruleNumberExpression | this_IncrementLoopExpression_20= ruleIncrementLoopExpression | this_DecrementLoopExpression_21= ruleDecrementLoopExpression ) )
                    {
                    // InternalSM2.g:6610:3: (this_STRING_12= RULE_STRING (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_19= ruleNumberExpression | this_IncrementLoopExpression_20= ruleIncrementLoopExpression | this_DecrementLoopExpression_21= ruleDecrementLoopExpression ) )
                    // InternalSM2.g:6611:4: this_STRING_12= RULE_STRING (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_19= ruleNumberExpression | this_IncrementLoopExpression_20= ruleIncrementLoopExpression | this_DecrementLoopExpression_21= ruleDecrementLoopExpression )
                    {
                    this_STRING_12=(Token)match(input,RULE_STRING,FOLLOW_82); 

                    				current.merge(this_STRING_12);
                    			

                    				newLeafNode(this_STRING_12, grammarAccess.getArithmeticalComparationExpressionAccess().getSTRINGTerminalRuleCall_1_0());
                    			
                    // InternalSM2.g:6618:4: (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' )
                    int alt174=6;
                    switch ( input.LA(1) ) {
                    case 171:
                        {
                        alt174=1;
                        }
                        break;
                    case 172:
                        {
                        alt174=2;
                        }
                        break;
                    case 45:
                        {
                        alt174=3;
                        }
                        break;
                    case 46:
                        {
                        alt174=4;
                        }
                        break;
                    case 173:
                        {
                        alt174=5;
                        }
                        break;
                    case 174:
                        {
                        alt174=6;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 174, 0, input);

                        throw nvae;
                    }

                    switch (alt174) {
                        case 1 :
                            // InternalSM2.g:6619:5: kw= '=='
                            {
                            kw=(Token)match(input,171,FOLLOW_81); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getEqualsSignEqualsSignKeyword_1_1_0());
                            				

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:6625:5: kw= '!='
                            {
                            kw=(Token)match(input,172,FOLLOW_81); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getExclamationMarkEqualsSignKeyword_1_1_1());
                            				

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:6631:5: kw= '>'
                            {
                            kw=(Token)match(input,45,FOLLOW_81); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getGreaterThanSignKeyword_1_1_2());
                            				

                            }
                            break;
                        case 4 :
                            // InternalSM2.g:6637:5: kw= '>='
                            {
                            kw=(Token)match(input,46,FOLLOW_81); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getGreaterThanSignEqualsSignKeyword_1_1_3());
                            				

                            }
                            break;
                        case 5 :
                            // InternalSM2.g:6643:5: kw= '<'
                            {
                            kw=(Token)match(input,173,FOLLOW_81); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getLessThanSignKeyword_1_1_4());
                            				

                            }
                            break;
                        case 6 :
                            // InternalSM2.g:6649:5: kw= '<='
                            {
                            kw=(Token)match(input,174,FOLLOW_81); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getLessThanSignEqualsSignKeyword_1_1_5());
                            				

                            }
                            break;

                    }

                    // InternalSM2.g:6655:4: (this_NumberExpression_19= ruleNumberExpression | this_IncrementLoopExpression_20= ruleIncrementLoopExpression | this_DecrementLoopExpression_21= ruleDecrementLoopExpression )
                    int alt175=3;
                    switch ( input.LA(1) ) {
                    case RULE_INT:
                        {
                        switch ( input.LA(2) ) {
                        case EOF:
                        case RULE_SEMICOLON:
                        case RULE_EOLINE:
                        case RULE_STRING:
                        case RULE_CLOSEKEY:
                        case RULE_OPENPARENTHESIS:
                        case RULE_CLOSEPARENTHESIS:
                        case RULE_COMMA:
                        case RULE_INT:
                        case RULE_FLOAT:
                        case RULE_BOOLVALUE:
                        case RULE_NEW:
                        case RULE_DELETE:
                        case RULE_EMIT:
                        case RULE_RETURN:
                        case RULE_IF:
                        case RULE_BREAK:
                        case 83:
                        case 89:
                        case 90:
                        case 91:
                        case 92:
                        case 93:
                        case 94:
                        case 95:
                        case 96:
                        case 97:
                        case 98:
                        case 99:
                        case 100:
                        case 101:
                        case 102:
                        case 103:
                        case 104:
                        case 105:
                        case 106:
                        case 107:
                        case 108:
                        case 109:
                        case 110:
                        case 111:
                        case 112:
                        case 113:
                        case 114:
                        case 115:
                        case 116:
                        case 117:
                        case 118:
                        case 119:
                        case 120:
                        case 121:
                        case 122:
                        case 123:
                        case 124:
                        case 125:
                        case 126:
                        case 127:
                        case 128:
                        case 129:
                        case 130:
                        case 131:
                        case 132:
                        case 133:
                        case 134:
                        case 135:
                        case 136:
                        case 137:
                        case 138:
                        case 139:
                        case 140:
                        case 141:
                        case 142:
                        case 143:
                        case 144:
                        case 145:
                        case 157:
                        case 158:
                        case 159:
                        case 160:
                        case 164:
                        case 180:
                        case 181:
                            {
                            alt175=1;
                            }
                            break;
                        case 183:
                            {
                            alt175=3;
                            }
                            break;
                        case 182:
                            {
                            alt175=2;
                            }
                            break;
                        default:
                            NoViableAltException nvae =
                                new NoViableAltException("", 175, 1, input);

                            throw nvae;
                        }

                        }
                        break;
                    case RULE_FLOAT:
                        {
                        alt175=1;
                        }
                        break;
                    case RULE_STRING:
                        {
                        int LA175_3 = input.LA(2);

                        if ( (LA175_3==183) ) {
                            alt175=3;
                        }
                        else if ( (LA175_3==182) ) {
                            alt175=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 175, 3, input);

                            throw nvae;
                        }
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 175, 0, input);

                        throw nvae;
                    }

                    switch (alt175) {
                        case 1 :
                            // InternalSM2.g:6656:5: this_NumberExpression_19= ruleNumberExpression
                            {

                            					newCompositeNode(grammarAccess.getArithmeticalComparationExpressionAccess().getNumberExpressionParserRuleCall_1_2_0());
                            				
                            pushFollow(FOLLOW_2);
                            this_NumberExpression_19=ruleNumberExpression();

                            state._fsp--;


                            					current.merge(this_NumberExpression_19);
                            				

                            					afterParserOrEnumRuleCall();
                            				

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:6667:5: this_IncrementLoopExpression_20= ruleIncrementLoopExpression
                            {

                            					newCompositeNode(grammarAccess.getArithmeticalComparationExpressionAccess().getIncrementLoopExpressionParserRuleCall_1_2_1());
                            				
                            pushFollow(FOLLOW_2);
                            this_IncrementLoopExpression_20=ruleIncrementLoopExpression();

                            state._fsp--;


                            					current.merge(this_IncrementLoopExpression_20);
                            				

                            					afterParserOrEnumRuleCall();
                            				

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:6678:5: this_DecrementLoopExpression_21= ruleDecrementLoopExpression
                            {

                            					newCompositeNode(grammarAccess.getArithmeticalComparationExpressionAccess().getDecrementLoopExpressionParserRuleCall_1_2_2());
                            				
                            pushFollow(FOLLOW_2);
                            this_DecrementLoopExpression_21=ruleDecrementLoopExpression();

                            state._fsp--;


                            					current.merge(this_DecrementLoopExpression_21);
                            				

                            					afterParserOrEnumRuleCall();
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:6691:3: ( (this_NumberExpression_22= ruleNumberExpression | this_IncrementLoopExpression_23= ruleIncrementLoopExpression | this_DecrementLoopExpression_24= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) this_STRING_31= RULE_STRING )
                    {
                    // InternalSM2.g:6691:3: ( (this_NumberExpression_22= ruleNumberExpression | this_IncrementLoopExpression_23= ruleIncrementLoopExpression | this_DecrementLoopExpression_24= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) this_STRING_31= RULE_STRING )
                    // InternalSM2.g:6692:4: (this_NumberExpression_22= ruleNumberExpression | this_IncrementLoopExpression_23= ruleIncrementLoopExpression | this_DecrementLoopExpression_24= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) this_STRING_31= RULE_STRING
                    {
                    // InternalSM2.g:6692:4: (this_NumberExpression_22= ruleNumberExpression | this_IncrementLoopExpression_23= ruleIncrementLoopExpression | this_DecrementLoopExpression_24= ruleDecrementLoopExpression )
                    int alt176=3;
                    switch ( input.LA(1) ) {
                    case RULE_INT:
                        {
                        switch ( input.LA(2) ) {
                        case 45:
                        case 46:
                        case 171:
                        case 172:
                        case 173:
                        case 174:
                            {
                            alt176=1;
                            }
                            break;
                        case 183:
                            {
                            alt176=3;
                            }
                            break;
                        case 182:
                            {
                            alt176=2;
                            }
                            break;
                        default:
                            NoViableAltException nvae =
                                new NoViableAltException("", 176, 1, input);

                            throw nvae;
                        }

                        }
                        break;
                    case RULE_FLOAT:
                        {
                        alt176=1;
                        }
                        break;
                    case RULE_STRING:
                        {
                        int LA176_3 = input.LA(2);

                        if ( (LA176_3==183) ) {
                            alt176=3;
                        }
                        else if ( (LA176_3==182) ) {
                            alt176=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 176, 3, input);

                            throw nvae;
                        }
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 176, 0, input);

                        throw nvae;
                    }

                    switch (alt176) {
                        case 1 :
                            // InternalSM2.g:6693:5: this_NumberExpression_22= ruleNumberExpression
                            {

                            					newCompositeNode(grammarAccess.getArithmeticalComparationExpressionAccess().getNumberExpressionParserRuleCall_2_0_0());
                            				
                            pushFollow(FOLLOW_82);
                            this_NumberExpression_22=ruleNumberExpression();

                            state._fsp--;


                            					current.merge(this_NumberExpression_22);
                            				

                            					afterParserOrEnumRuleCall();
                            				

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:6704:5: this_IncrementLoopExpression_23= ruleIncrementLoopExpression
                            {

                            					newCompositeNode(grammarAccess.getArithmeticalComparationExpressionAccess().getIncrementLoopExpressionParserRuleCall_2_0_1());
                            				
                            pushFollow(FOLLOW_82);
                            this_IncrementLoopExpression_23=ruleIncrementLoopExpression();

                            state._fsp--;


                            					current.merge(this_IncrementLoopExpression_23);
                            				

                            					afterParserOrEnumRuleCall();
                            				

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:6715:5: this_DecrementLoopExpression_24= ruleDecrementLoopExpression
                            {

                            					newCompositeNode(grammarAccess.getArithmeticalComparationExpressionAccess().getDecrementLoopExpressionParserRuleCall_2_0_2());
                            				
                            pushFollow(FOLLOW_82);
                            this_DecrementLoopExpression_24=ruleDecrementLoopExpression();

                            state._fsp--;


                            					current.merge(this_DecrementLoopExpression_24);
                            				

                            					afterParserOrEnumRuleCall();
                            				

                            }
                            break;

                    }

                    // InternalSM2.g:6726:4: (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' )
                    int alt177=6;
                    switch ( input.LA(1) ) {
                    case 171:
                        {
                        alt177=1;
                        }
                        break;
                    case 172:
                        {
                        alt177=2;
                        }
                        break;
                    case 45:
                        {
                        alt177=3;
                        }
                        break;
                    case 46:
                        {
                        alt177=4;
                        }
                        break;
                    case 173:
                        {
                        alt177=5;
                        }
                        break;
                    case 174:
                        {
                        alt177=6;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 177, 0, input);

                        throw nvae;
                    }

                    switch (alt177) {
                        case 1 :
                            // InternalSM2.g:6727:5: kw= '=='
                            {
                            kw=(Token)match(input,171,FOLLOW_10); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getEqualsSignEqualsSignKeyword_2_1_0());
                            				

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:6733:5: kw= '!='
                            {
                            kw=(Token)match(input,172,FOLLOW_10); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getExclamationMarkEqualsSignKeyword_2_1_1());
                            				

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:6739:5: kw= '>'
                            {
                            kw=(Token)match(input,45,FOLLOW_10); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getGreaterThanSignKeyword_2_1_2());
                            				

                            }
                            break;
                        case 4 :
                            // InternalSM2.g:6745:5: kw= '>='
                            {
                            kw=(Token)match(input,46,FOLLOW_10); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getGreaterThanSignEqualsSignKeyword_2_1_3());
                            				

                            }
                            break;
                        case 5 :
                            // InternalSM2.g:6751:5: kw= '<'
                            {
                            kw=(Token)match(input,173,FOLLOW_10); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getLessThanSignKeyword_2_1_4());
                            				

                            }
                            break;
                        case 6 :
                            // InternalSM2.g:6757:5: kw= '<='
                            {
                            kw=(Token)match(input,174,FOLLOW_10); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getArithmeticalComparationExpressionAccess().getLessThanSignEqualsSignKeyword_2_1_5());
                            				

                            }
                            break;

                    }

                    this_STRING_31=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    				current.merge(this_STRING_31);
                    			

                    				newLeafNode(this_STRING_31, grammarAccess.getArithmeticalComparationExpressionAccess().getSTRINGTerminalRuleCall_2_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmeticalComparationExpression"


    // $ANTLR start "entryRuleNumberExpression"
    // InternalSM2.g:6775:1: entryRuleNumberExpression returns [String current=null] : iv_ruleNumberExpression= ruleNumberExpression EOF ;
    public final String entryRuleNumberExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleNumberExpression = null;


        try {
            // InternalSM2.g:6775:56: (iv_ruleNumberExpression= ruleNumberExpression EOF )
            // InternalSM2.g:6776:2: iv_ruleNumberExpression= ruleNumberExpression EOF
            {
             newCompositeNode(grammarAccess.getNumberExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNumberExpression=ruleNumberExpression();

            state._fsp--;

             current =iv_ruleNumberExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNumberExpression"


    // $ANTLR start "ruleNumberExpression"
    // InternalSM2.g:6782:1: ruleNumberExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_INT_0= RULE_INT | this_FLOAT_1= RULE_FLOAT ) ;
    public final AntlrDatatypeRuleToken ruleNumberExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_INT_0=null;
        Token this_FLOAT_1=null;


        	enterRule();

        try {
            // InternalSM2.g:6788:2: ( (this_INT_0= RULE_INT | this_FLOAT_1= RULE_FLOAT ) )
            // InternalSM2.g:6789:2: (this_INT_0= RULE_INT | this_FLOAT_1= RULE_FLOAT )
            {
            // InternalSM2.g:6789:2: (this_INT_0= RULE_INT | this_FLOAT_1= RULE_FLOAT )
            int alt179=2;
            int LA179_0 = input.LA(1);

            if ( (LA179_0==RULE_INT) ) {
                alt179=1;
            }
            else if ( (LA179_0==RULE_FLOAT) ) {
                alt179=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 179, 0, input);

                throw nvae;
            }
            switch (alt179) {
                case 1 :
                    // InternalSM2.g:6790:3: this_INT_0= RULE_INT
                    {
                    this_INT_0=(Token)match(input,RULE_INT,FOLLOW_2); 

                    			current.merge(this_INT_0);
                    		

                    			newLeafNode(this_INT_0, grammarAccess.getNumberExpressionAccess().getINTTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:6798:3: this_FLOAT_1= RULE_FLOAT
                    {
                    this_FLOAT_1=(Token)match(input,RULE_FLOAT,FOLLOW_2); 

                    			current.merge(this_FLOAT_1);
                    		

                    			newLeafNode(this_FLOAT_1, grammarAccess.getNumberExpressionAccess().getFLOATTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNumberExpression"


    // $ANTLR start "entryRuleArithmeticalExpression"
    // InternalSM2.g:6809:1: entryRuleArithmeticalExpression returns [String current=null] : iv_ruleArithmeticalExpression= ruleArithmeticalExpression EOF ;
    public final String entryRuleArithmeticalExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleArithmeticalExpression = null;


        try {
            // InternalSM2.g:6809:62: (iv_ruleArithmeticalExpression= ruleArithmeticalExpression EOF )
            // InternalSM2.g:6810:2: iv_ruleArithmeticalExpression= ruleArithmeticalExpression EOF
            {
             newCompositeNode(grammarAccess.getArithmeticalExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleArithmeticalExpression=ruleArithmeticalExpression();

            state._fsp--;

             current =iv_ruleArithmeticalExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmeticalExpression"


    // $ANTLR start "ruleArithmeticalExpression"
    // InternalSM2.g:6816:1: ruleArithmeticalExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (this_NumberExpression_0= ruleNumberExpression | this_STRING_1= RULE_STRING ) (kw= '+' | kw= '-' | kw= '*' | kw= '/' | kw= '%' ) (this_NumberExpression_7= ruleNumberExpression | this_STRING_8= RULE_STRING | this_ArithmeticalExpression_9= ruleArithmeticalExpression ) ) ;
    public final AntlrDatatypeRuleToken ruleArithmeticalExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_1=null;
        Token kw=null;
        Token this_STRING_8=null;
        AntlrDatatypeRuleToken this_NumberExpression_0 = null;

        AntlrDatatypeRuleToken this_NumberExpression_7 = null;

        AntlrDatatypeRuleToken this_ArithmeticalExpression_9 = null;



        	enterRule();

        try {
            // InternalSM2.g:6822:2: ( ( (this_NumberExpression_0= ruleNumberExpression | this_STRING_1= RULE_STRING ) (kw= '+' | kw= '-' | kw= '*' | kw= '/' | kw= '%' ) (this_NumberExpression_7= ruleNumberExpression | this_STRING_8= RULE_STRING | this_ArithmeticalExpression_9= ruleArithmeticalExpression ) ) )
            // InternalSM2.g:6823:2: ( (this_NumberExpression_0= ruleNumberExpression | this_STRING_1= RULE_STRING ) (kw= '+' | kw= '-' | kw= '*' | kw= '/' | kw= '%' ) (this_NumberExpression_7= ruleNumberExpression | this_STRING_8= RULE_STRING | this_ArithmeticalExpression_9= ruleArithmeticalExpression ) )
            {
            // InternalSM2.g:6823:2: ( (this_NumberExpression_0= ruleNumberExpression | this_STRING_1= RULE_STRING ) (kw= '+' | kw= '-' | kw= '*' | kw= '/' | kw= '%' ) (this_NumberExpression_7= ruleNumberExpression | this_STRING_8= RULE_STRING | this_ArithmeticalExpression_9= ruleArithmeticalExpression ) )
            // InternalSM2.g:6824:3: (this_NumberExpression_0= ruleNumberExpression | this_STRING_1= RULE_STRING ) (kw= '+' | kw= '-' | kw= '*' | kw= '/' | kw= '%' ) (this_NumberExpression_7= ruleNumberExpression | this_STRING_8= RULE_STRING | this_ArithmeticalExpression_9= ruleArithmeticalExpression )
            {
            // InternalSM2.g:6824:3: (this_NumberExpression_0= ruleNumberExpression | this_STRING_1= RULE_STRING )
            int alt180=2;
            int LA180_0 = input.LA(1);

            if ( (LA180_0==RULE_INT||LA180_0==RULE_FLOAT) ) {
                alt180=1;
            }
            else if ( (LA180_0==RULE_STRING) ) {
                alt180=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 180, 0, input);

                throw nvae;
            }
            switch (alt180) {
                case 1 :
                    // InternalSM2.g:6825:4: this_NumberExpression_0= ruleNumberExpression
                    {

                    				newCompositeNode(grammarAccess.getArithmeticalExpressionAccess().getNumberExpressionParserRuleCall_0_0());
                    			
                    pushFollow(FOLLOW_103);
                    this_NumberExpression_0=ruleNumberExpression();

                    state._fsp--;


                    				current.merge(this_NumberExpression_0);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;
                case 2 :
                    // InternalSM2.g:6836:4: this_STRING_1= RULE_STRING
                    {
                    this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_103); 

                    				current.merge(this_STRING_1);
                    			

                    				newLeafNode(this_STRING_1, grammarAccess.getArithmeticalExpressionAccess().getSTRINGTerminalRuleCall_0_1());
                    			

                    }
                    break;

            }

            // InternalSM2.g:6844:3: (kw= '+' | kw= '-' | kw= '*' | kw= '/' | kw= '%' )
            int alt181=5;
            switch ( input.LA(1) ) {
            case 175:
                {
                alt181=1;
                }
                break;
            case 176:
                {
                alt181=2;
                }
                break;
            case 177:
                {
                alt181=3;
                }
                break;
            case 178:
                {
                alt181=4;
                }
                break;
            case 179:
                {
                alt181=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 181, 0, input);

                throw nvae;
            }

            switch (alt181) {
                case 1 :
                    // InternalSM2.g:6845:4: kw= '+'
                    {
                    kw=(Token)match(input,175,FOLLOW_81); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getArithmeticalExpressionAccess().getPlusSignKeyword_1_0());
                    			

                    }
                    break;
                case 2 :
                    // InternalSM2.g:6851:4: kw= '-'
                    {
                    kw=(Token)match(input,176,FOLLOW_81); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getArithmeticalExpressionAccess().getHyphenMinusKeyword_1_1());
                    			

                    }
                    break;
                case 3 :
                    // InternalSM2.g:6857:4: kw= '*'
                    {
                    kw=(Token)match(input,177,FOLLOW_81); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getArithmeticalExpressionAccess().getAsteriskKeyword_1_2());
                    			

                    }
                    break;
                case 4 :
                    // InternalSM2.g:6863:4: kw= '/'
                    {
                    kw=(Token)match(input,178,FOLLOW_81); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getArithmeticalExpressionAccess().getSolidusKeyword_1_3());
                    			

                    }
                    break;
                case 5 :
                    // InternalSM2.g:6869:4: kw= '%'
                    {
                    kw=(Token)match(input,179,FOLLOW_81); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getArithmeticalExpressionAccess().getPercentSignKeyword_1_4());
                    			

                    }
                    break;

            }

            // InternalSM2.g:6875:3: (this_NumberExpression_7= ruleNumberExpression | this_STRING_8= RULE_STRING | this_ArithmeticalExpression_9= ruleArithmeticalExpression )
            int alt182=3;
            switch ( input.LA(1) ) {
            case RULE_INT:
                {
                int LA182_1 = input.LA(2);

                if ( ((LA182_1>=175 && LA182_1<=179)) ) {
                    alt182=3;
                }
                else if ( (LA182_1==EOF||(LA182_1>=RULE_EOLINE && LA182_1<=RULE_STRING)||LA182_1==RULE_CLOSEKEY||(LA182_1>=RULE_OPENPARENTHESIS && LA182_1<=RULE_CLOSEPARENTHESIS)||(LA182_1>=RULE_COMMA && LA182_1<=RULE_INT)||(LA182_1>=RULE_FLOAT && LA182_1<=RULE_BOOLVALUE)||LA182_1==RULE_NEW||(LA182_1>=RULE_DELETE && LA182_1<=RULE_IF)||LA182_1==RULE_BREAK||LA182_1==83||(LA182_1>=89 && LA182_1<=145)||(LA182_1>=157 && LA182_1<=160)||LA182_1==164) ) {
                    alt182=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 182, 1, input);

                    throw nvae;
                }
                }
                break;
            case RULE_FLOAT:
                {
                int LA182_2 = input.LA(2);

                if ( ((LA182_2>=175 && LA182_2<=179)) ) {
                    alt182=3;
                }
                else if ( (LA182_2==EOF||(LA182_2>=RULE_EOLINE && LA182_2<=RULE_STRING)||LA182_2==RULE_CLOSEKEY||(LA182_2>=RULE_OPENPARENTHESIS && LA182_2<=RULE_CLOSEPARENTHESIS)||(LA182_2>=RULE_COMMA && LA182_2<=RULE_INT)||(LA182_2>=RULE_FLOAT && LA182_2<=RULE_BOOLVALUE)||LA182_2==RULE_NEW||(LA182_2>=RULE_DELETE && LA182_2<=RULE_IF)||LA182_2==RULE_BREAK||LA182_2==83||(LA182_2>=89 && LA182_2<=145)||(LA182_2>=157 && LA182_2<=160)||LA182_2==164) ) {
                    alt182=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 182, 2, input);

                    throw nvae;
                }
                }
                break;
            case RULE_STRING:
                {
                int LA182_3 = input.LA(2);

                if ( ((LA182_3>=175 && LA182_3<=179)) ) {
                    alt182=3;
                }
                else if ( (LA182_3==EOF||(LA182_3>=RULE_EOLINE && LA182_3<=RULE_STRING)||LA182_3==RULE_CLOSEKEY||(LA182_3>=RULE_OPENPARENTHESIS && LA182_3<=RULE_CLOSEPARENTHESIS)||(LA182_3>=RULE_COMMA && LA182_3<=RULE_INT)||(LA182_3>=RULE_FLOAT && LA182_3<=RULE_BOOLVALUE)||LA182_3==RULE_NEW||(LA182_3>=RULE_DELETE && LA182_3<=RULE_IF)||LA182_3==RULE_BREAK||LA182_3==83||(LA182_3>=89 && LA182_3<=145)||(LA182_3>=157 && LA182_3<=160)||LA182_3==164) ) {
                    alt182=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 182, 3, input);

                    throw nvae;
                }
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 182, 0, input);

                throw nvae;
            }

            switch (alt182) {
                case 1 :
                    // InternalSM2.g:6876:4: this_NumberExpression_7= ruleNumberExpression
                    {

                    				newCompositeNode(grammarAccess.getArithmeticalExpressionAccess().getNumberExpressionParserRuleCall_2_0());
                    			
                    pushFollow(FOLLOW_2);
                    this_NumberExpression_7=ruleNumberExpression();

                    state._fsp--;


                    				current.merge(this_NumberExpression_7);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;
                case 2 :
                    // InternalSM2.g:6887:4: this_STRING_8= RULE_STRING
                    {
                    this_STRING_8=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    				current.merge(this_STRING_8);
                    			

                    				newLeafNode(this_STRING_8, grammarAccess.getArithmeticalExpressionAccess().getSTRINGTerminalRuleCall_2_1());
                    			

                    }
                    break;
                case 3 :
                    // InternalSM2.g:6895:4: this_ArithmeticalExpression_9= ruleArithmeticalExpression
                    {

                    				newCompositeNode(grammarAccess.getArithmeticalExpressionAccess().getArithmeticalExpressionParserRuleCall_2_2());
                    			
                    pushFollow(FOLLOW_2);
                    this_ArithmeticalExpression_9=ruleArithmeticalExpression();

                    state._fsp--;


                    				current.merge(this_ArithmeticalExpression_9);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmeticalExpression"


    // $ANTLR start "entryRuleAndExpression"
    // InternalSM2.g:6910:1: entryRuleAndExpression returns [String current=null] : iv_ruleAndExpression= ruleAndExpression EOF ;
    public final String entryRuleAndExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleAndExpression = null;


        try {
            // InternalSM2.g:6910:53: (iv_ruleAndExpression= ruleAndExpression EOF )
            // InternalSM2.g:6911:2: iv_ruleAndExpression= ruleAndExpression EOF
            {
             newCompositeNode(grammarAccess.getAndExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAndExpression=ruleAndExpression();

            state._fsp--;

             current =iv_ruleAndExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAndExpression"


    // $ANTLR start "ruleAndExpression"
    // InternalSM2.g:6917:1: ruleAndExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (this_NegationExpression_0= ruleNegationExpression | this_STRING_1= RULE_STRING | this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression | this_ComparationExpression_3= ruleComparationExpression ) kw= '&&' this_Expression_5= ruleExpression ) ;
    public final AntlrDatatypeRuleToken ruleAndExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_1=null;
        Token kw=null;
        AntlrDatatypeRuleToken this_NegationExpression_0 = null;

        AntlrDatatypeRuleToken this_ArithmeticalComparationExpression_2 = null;

        AntlrDatatypeRuleToken this_ComparationExpression_3 = null;

        AntlrDatatypeRuleToken this_Expression_5 = null;



        	enterRule();

        try {
            // InternalSM2.g:6923:2: ( ( (this_NegationExpression_0= ruleNegationExpression | this_STRING_1= RULE_STRING | this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression | this_ComparationExpression_3= ruleComparationExpression ) kw= '&&' this_Expression_5= ruleExpression ) )
            // InternalSM2.g:6924:2: ( (this_NegationExpression_0= ruleNegationExpression | this_STRING_1= RULE_STRING | this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression | this_ComparationExpression_3= ruleComparationExpression ) kw= '&&' this_Expression_5= ruleExpression )
            {
            // InternalSM2.g:6924:2: ( (this_NegationExpression_0= ruleNegationExpression | this_STRING_1= RULE_STRING | this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression | this_ComparationExpression_3= ruleComparationExpression ) kw= '&&' this_Expression_5= ruleExpression )
            // InternalSM2.g:6925:3: (this_NegationExpression_0= ruleNegationExpression | this_STRING_1= RULE_STRING | this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression | this_ComparationExpression_3= ruleComparationExpression ) kw= '&&' this_Expression_5= ruleExpression
            {
            // InternalSM2.g:6925:3: (this_NegationExpression_0= ruleNegationExpression | this_STRING_1= RULE_STRING | this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression | this_ComparationExpression_3= ruleComparationExpression )
            int alt183=4;
            alt183 = dfa183.predict(input);
            switch (alt183) {
                case 1 :
                    // InternalSM2.g:6926:4: this_NegationExpression_0= ruleNegationExpression
                    {

                    				newCompositeNode(grammarAccess.getAndExpressionAccess().getNegationExpressionParserRuleCall_0_0());
                    			
                    pushFollow(FOLLOW_104);
                    this_NegationExpression_0=ruleNegationExpression();

                    state._fsp--;


                    				current.merge(this_NegationExpression_0);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;
                case 2 :
                    // InternalSM2.g:6937:4: this_STRING_1= RULE_STRING
                    {
                    this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_104); 

                    				current.merge(this_STRING_1);
                    			

                    				newLeafNode(this_STRING_1, grammarAccess.getAndExpressionAccess().getSTRINGTerminalRuleCall_0_1());
                    			

                    }
                    break;
                case 3 :
                    // InternalSM2.g:6945:4: this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression
                    {

                    				newCompositeNode(grammarAccess.getAndExpressionAccess().getArithmeticalComparationExpressionParserRuleCall_0_2());
                    			
                    pushFollow(FOLLOW_104);
                    this_ArithmeticalComparationExpression_2=ruleArithmeticalComparationExpression();

                    state._fsp--;


                    				current.merge(this_ArithmeticalComparationExpression_2);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;
                case 4 :
                    // InternalSM2.g:6956:4: this_ComparationExpression_3= ruleComparationExpression
                    {

                    				newCompositeNode(grammarAccess.getAndExpressionAccess().getComparationExpressionParserRuleCall_0_3());
                    			
                    pushFollow(FOLLOW_104);
                    this_ComparationExpression_3=ruleComparationExpression();

                    state._fsp--;


                    				current.merge(this_ComparationExpression_3);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            kw=(Token)match(input,180,FOLLOW_20); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getAndExpressionAccess().getAmpersandAmpersandKeyword_1());
            		

            			newCompositeNode(grammarAccess.getAndExpressionAccess().getExpressionParserRuleCall_2());
            		
            pushFollow(FOLLOW_2);
            this_Expression_5=ruleExpression();

            state._fsp--;


            			current.merge(this_Expression_5);
            		

            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAndExpression"


    // $ANTLR start "entryRuleOrExpression"
    // InternalSM2.g:6986:1: entryRuleOrExpression returns [String current=null] : iv_ruleOrExpression= ruleOrExpression EOF ;
    public final String entryRuleOrExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleOrExpression = null;


        try {
            // InternalSM2.g:6986:52: (iv_ruleOrExpression= ruleOrExpression EOF )
            // InternalSM2.g:6987:2: iv_ruleOrExpression= ruleOrExpression EOF
            {
             newCompositeNode(grammarAccess.getOrExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOrExpression=ruleOrExpression();

            state._fsp--;

             current =iv_ruleOrExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOrExpression"


    // $ANTLR start "ruleOrExpression"
    // InternalSM2.g:6993:1: ruleOrExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (this_NegationExpression_0= ruleNegationExpression | this_STRING_1= RULE_STRING | this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression | this_ComparationExpression_3= ruleComparationExpression ) kw= '||' this_Expression_5= ruleExpression ) ;
    public final AntlrDatatypeRuleToken ruleOrExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_1=null;
        Token kw=null;
        AntlrDatatypeRuleToken this_NegationExpression_0 = null;

        AntlrDatatypeRuleToken this_ArithmeticalComparationExpression_2 = null;

        AntlrDatatypeRuleToken this_ComparationExpression_3 = null;

        AntlrDatatypeRuleToken this_Expression_5 = null;



        	enterRule();

        try {
            // InternalSM2.g:6999:2: ( ( (this_NegationExpression_0= ruleNegationExpression | this_STRING_1= RULE_STRING | this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression | this_ComparationExpression_3= ruleComparationExpression ) kw= '||' this_Expression_5= ruleExpression ) )
            // InternalSM2.g:7000:2: ( (this_NegationExpression_0= ruleNegationExpression | this_STRING_1= RULE_STRING | this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression | this_ComparationExpression_3= ruleComparationExpression ) kw= '||' this_Expression_5= ruleExpression )
            {
            // InternalSM2.g:7000:2: ( (this_NegationExpression_0= ruleNegationExpression | this_STRING_1= RULE_STRING | this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression | this_ComparationExpression_3= ruleComparationExpression ) kw= '||' this_Expression_5= ruleExpression )
            // InternalSM2.g:7001:3: (this_NegationExpression_0= ruleNegationExpression | this_STRING_1= RULE_STRING | this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression | this_ComparationExpression_3= ruleComparationExpression ) kw= '||' this_Expression_5= ruleExpression
            {
            // InternalSM2.g:7001:3: (this_NegationExpression_0= ruleNegationExpression | this_STRING_1= RULE_STRING | this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression | this_ComparationExpression_3= ruleComparationExpression )
            int alt184=4;
            alt184 = dfa184.predict(input);
            switch (alt184) {
                case 1 :
                    // InternalSM2.g:7002:4: this_NegationExpression_0= ruleNegationExpression
                    {

                    				newCompositeNode(grammarAccess.getOrExpressionAccess().getNegationExpressionParserRuleCall_0_0());
                    			
                    pushFollow(FOLLOW_105);
                    this_NegationExpression_0=ruleNegationExpression();

                    state._fsp--;


                    				current.merge(this_NegationExpression_0);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;
                case 2 :
                    // InternalSM2.g:7013:4: this_STRING_1= RULE_STRING
                    {
                    this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_105); 

                    				current.merge(this_STRING_1);
                    			

                    				newLeafNode(this_STRING_1, grammarAccess.getOrExpressionAccess().getSTRINGTerminalRuleCall_0_1());
                    			

                    }
                    break;
                case 3 :
                    // InternalSM2.g:7021:4: this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression
                    {

                    				newCompositeNode(grammarAccess.getOrExpressionAccess().getArithmeticalComparationExpressionParserRuleCall_0_2());
                    			
                    pushFollow(FOLLOW_105);
                    this_ArithmeticalComparationExpression_2=ruleArithmeticalComparationExpression();

                    state._fsp--;


                    				current.merge(this_ArithmeticalComparationExpression_2);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;
                case 4 :
                    // InternalSM2.g:7032:4: this_ComparationExpression_3= ruleComparationExpression
                    {

                    				newCompositeNode(grammarAccess.getOrExpressionAccess().getComparationExpressionParserRuleCall_0_3());
                    			
                    pushFollow(FOLLOW_105);
                    this_ComparationExpression_3=ruleComparationExpression();

                    state._fsp--;


                    				current.merge(this_ComparationExpression_3);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            kw=(Token)match(input,181,FOLLOW_20); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getOrExpressionAccess().getVerticalLineVerticalLineKeyword_1());
            		

            			newCompositeNode(grammarAccess.getOrExpressionAccess().getExpressionParserRuleCall_2());
            		
            pushFollow(FOLLOW_2);
            this_Expression_5=ruleExpression();

            state._fsp--;


            			current.merge(this_Expression_5);
            		

            			afterParserOrEnumRuleCall();
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOrExpression"


    // $ANTLR start "entryRuleIncrementLoopExpression"
    // InternalSM2.g:7062:1: entryRuleIncrementLoopExpression returns [String current=null] : iv_ruleIncrementLoopExpression= ruleIncrementLoopExpression EOF ;
    public final String entryRuleIncrementLoopExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleIncrementLoopExpression = null;


        try {
            // InternalSM2.g:7062:63: (iv_ruleIncrementLoopExpression= ruleIncrementLoopExpression EOF )
            // InternalSM2.g:7063:2: iv_ruleIncrementLoopExpression= ruleIncrementLoopExpression EOF
            {
             newCompositeNode(grammarAccess.getIncrementLoopExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIncrementLoopExpression=ruleIncrementLoopExpression();

            state._fsp--;

             current =iv_ruleIncrementLoopExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIncrementLoopExpression"


    // $ANTLR start "ruleIncrementLoopExpression"
    // InternalSM2.g:7069:1: ruleIncrementLoopExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (this_INT_0= RULE_INT kw= '++' ) | (this_STRING_2= RULE_STRING kw= '++' ) ) ;
    public final AntlrDatatypeRuleToken ruleIncrementLoopExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_INT_0=null;
        Token kw=null;
        Token this_STRING_2=null;


        	enterRule();

        try {
            // InternalSM2.g:7075:2: ( ( (this_INT_0= RULE_INT kw= '++' ) | (this_STRING_2= RULE_STRING kw= '++' ) ) )
            // InternalSM2.g:7076:2: ( (this_INT_0= RULE_INT kw= '++' ) | (this_STRING_2= RULE_STRING kw= '++' ) )
            {
            // InternalSM2.g:7076:2: ( (this_INT_0= RULE_INT kw= '++' ) | (this_STRING_2= RULE_STRING kw= '++' ) )
            int alt185=2;
            int LA185_0 = input.LA(1);

            if ( (LA185_0==RULE_INT) ) {
                alt185=1;
            }
            else if ( (LA185_0==RULE_STRING) ) {
                alt185=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 185, 0, input);

                throw nvae;
            }
            switch (alt185) {
                case 1 :
                    // InternalSM2.g:7077:3: (this_INT_0= RULE_INT kw= '++' )
                    {
                    // InternalSM2.g:7077:3: (this_INT_0= RULE_INT kw= '++' )
                    // InternalSM2.g:7078:4: this_INT_0= RULE_INT kw= '++'
                    {
                    this_INT_0=(Token)match(input,RULE_INT,FOLLOW_106); 

                    				current.merge(this_INT_0);
                    			

                    				newLeafNode(this_INT_0, grammarAccess.getIncrementLoopExpressionAccess().getINTTerminalRuleCall_0_0());
                    			
                    kw=(Token)match(input,182,FOLLOW_2); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getIncrementLoopExpressionAccess().getPlusSignPlusSignKeyword_0_1());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:7092:3: (this_STRING_2= RULE_STRING kw= '++' )
                    {
                    // InternalSM2.g:7092:3: (this_STRING_2= RULE_STRING kw= '++' )
                    // InternalSM2.g:7093:4: this_STRING_2= RULE_STRING kw= '++'
                    {
                    this_STRING_2=(Token)match(input,RULE_STRING,FOLLOW_106); 

                    				current.merge(this_STRING_2);
                    			

                    				newLeafNode(this_STRING_2, grammarAccess.getIncrementLoopExpressionAccess().getSTRINGTerminalRuleCall_1_0());
                    			
                    kw=(Token)match(input,182,FOLLOW_2); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getIncrementLoopExpressionAccess().getPlusSignPlusSignKeyword_1_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIncrementLoopExpression"


    // $ANTLR start "entryRuleDecrementLoopExpression"
    // InternalSM2.g:7110:1: entryRuleDecrementLoopExpression returns [String current=null] : iv_ruleDecrementLoopExpression= ruleDecrementLoopExpression EOF ;
    public final String entryRuleDecrementLoopExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleDecrementLoopExpression = null;


        try {
            // InternalSM2.g:7110:63: (iv_ruleDecrementLoopExpression= ruleDecrementLoopExpression EOF )
            // InternalSM2.g:7111:2: iv_ruleDecrementLoopExpression= ruleDecrementLoopExpression EOF
            {
             newCompositeNode(grammarAccess.getDecrementLoopExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDecrementLoopExpression=ruleDecrementLoopExpression();

            state._fsp--;

             current =iv_ruleDecrementLoopExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDecrementLoopExpression"


    // $ANTLR start "ruleDecrementLoopExpression"
    // InternalSM2.g:7117:1: ruleDecrementLoopExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (this_INT_0= RULE_INT kw= '--' ) | (this_STRING_2= RULE_STRING kw= '--' ) ) ;
    public final AntlrDatatypeRuleToken ruleDecrementLoopExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_INT_0=null;
        Token kw=null;
        Token this_STRING_2=null;


        	enterRule();

        try {
            // InternalSM2.g:7123:2: ( ( (this_INT_0= RULE_INT kw= '--' ) | (this_STRING_2= RULE_STRING kw= '--' ) ) )
            // InternalSM2.g:7124:2: ( (this_INT_0= RULE_INT kw= '--' ) | (this_STRING_2= RULE_STRING kw= '--' ) )
            {
            // InternalSM2.g:7124:2: ( (this_INT_0= RULE_INT kw= '--' ) | (this_STRING_2= RULE_STRING kw= '--' ) )
            int alt186=2;
            int LA186_0 = input.LA(1);

            if ( (LA186_0==RULE_INT) ) {
                alt186=1;
            }
            else if ( (LA186_0==RULE_STRING) ) {
                alt186=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 186, 0, input);

                throw nvae;
            }
            switch (alt186) {
                case 1 :
                    // InternalSM2.g:7125:3: (this_INT_0= RULE_INT kw= '--' )
                    {
                    // InternalSM2.g:7125:3: (this_INT_0= RULE_INT kw= '--' )
                    // InternalSM2.g:7126:4: this_INT_0= RULE_INT kw= '--'
                    {
                    this_INT_0=(Token)match(input,RULE_INT,FOLLOW_107); 

                    				current.merge(this_INT_0);
                    			

                    				newLeafNode(this_INT_0, grammarAccess.getDecrementLoopExpressionAccess().getINTTerminalRuleCall_0_0());
                    			
                    kw=(Token)match(input,183,FOLLOW_2); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getDecrementLoopExpressionAccess().getHyphenMinusHyphenMinusKeyword_0_1());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:7140:3: (this_STRING_2= RULE_STRING kw= '--' )
                    {
                    // InternalSM2.g:7140:3: (this_STRING_2= RULE_STRING kw= '--' )
                    // InternalSM2.g:7141:4: this_STRING_2= RULE_STRING kw= '--'
                    {
                    this_STRING_2=(Token)match(input,RULE_STRING,FOLLOW_107); 

                    				current.merge(this_STRING_2);
                    			

                    				newLeafNode(this_STRING_2, grammarAccess.getDecrementLoopExpressionAccess().getSTRINGTerminalRuleCall_1_0());
                    			
                    kw=(Token)match(input,183,FOLLOW_2); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getDecrementLoopExpressionAccess().getHyphenMinusHyphenMinusKeyword_1_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDecrementLoopExpression"


    // $ANTLR start "entryRuleConditionalExpression"
    // InternalSM2.g:7158:1: entryRuleConditionalExpression returns [String current=null] : iv_ruleConditionalExpression= ruleConditionalExpression EOF ;
    public final String entryRuleConditionalExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleConditionalExpression = null;


        try {
            // InternalSM2.g:7158:61: (iv_ruleConditionalExpression= ruleConditionalExpression EOF )
            // InternalSM2.g:7159:2: iv_ruleConditionalExpression= ruleConditionalExpression EOF
            {
             newCompositeNode(grammarAccess.getConditionalExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConditionalExpression=ruleConditionalExpression();

            state._fsp--;

             current =iv_ruleConditionalExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConditionalExpression"


    // $ANTLR start "ruleConditionalExpression"
    // InternalSM2.g:7165:1: ruleConditionalExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_AndExpression_2= ruleAndExpression | this_OrExpression_3= ruleOrExpression | this_ArithmeticalComparationExpression_4= ruleArithmeticalComparationExpression | this_ComparationExpression_5= ruleComparationExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY (this_Expression_8= ruleExpression )? this_CLOSEKEY_9= RULE_CLOSEKEY this_EOLINE_10= RULE_EOLINE (this_ElseExpression_11= ruleElseExpression )? ) ;
    public final AntlrDatatypeRuleToken ruleConditionalExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_IF_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token this_OPENKEY_7=null;
        Token this_CLOSEKEY_9=null;
        Token this_EOLINE_10=null;
        AntlrDatatypeRuleToken this_AndExpression_2 = null;

        AntlrDatatypeRuleToken this_OrExpression_3 = null;

        AntlrDatatypeRuleToken this_ArithmeticalComparationExpression_4 = null;

        AntlrDatatypeRuleToken this_ComparationExpression_5 = null;

        AntlrDatatypeRuleToken this_Expression_8 = null;

        AntlrDatatypeRuleToken this_ElseExpression_11 = null;



        	enterRule();

        try {
            // InternalSM2.g:7171:2: ( (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_AndExpression_2= ruleAndExpression | this_OrExpression_3= ruleOrExpression | this_ArithmeticalComparationExpression_4= ruleArithmeticalComparationExpression | this_ComparationExpression_5= ruleComparationExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY (this_Expression_8= ruleExpression )? this_CLOSEKEY_9= RULE_CLOSEKEY this_EOLINE_10= RULE_EOLINE (this_ElseExpression_11= ruleElseExpression )? ) )
            // InternalSM2.g:7172:2: (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_AndExpression_2= ruleAndExpression | this_OrExpression_3= ruleOrExpression | this_ArithmeticalComparationExpression_4= ruleArithmeticalComparationExpression | this_ComparationExpression_5= ruleComparationExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY (this_Expression_8= ruleExpression )? this_CLOSEKEY_9= RULE_CLOSEKEY this_EOLINE_10= RULE_EOLINE (this_ElseExpression_11= ruleElseExpression )? )
            {
            // InternalSM2.g:7172:2: (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_AndExpression_2= ruleAndExpression | this_OrExpression_3= ruleOrExpression | this_ArithmeticalComparationExpression_4= ruleArithmeticalComparationExpression | this_ComparationExpression_5= ruleComparationExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY (this_Expression_8= ruleExpression )? this_CLOSEKEY_9= RULE_CLOSEKEY this_EOLINE_10= RULE_EOLINE (this_ElseExpression_11= ruleElseExpression )? )
            // InternalSM2.g:7173:3: this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_AndExpression_2= ruleAndExpression | this_OrExpression_3= ruleOrExpression | this_ArithmeticalComparationExpression_4= ruleArithmeticalComparationExpression | this_ComparationExpression_5= ruleComparationExpression ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY (this_Expression_8= ruleExpression )? this_CLOSEKEY_9= RULE_CLOSEKEY this_EOLINE_10= RULE_EOLINE (this_ElseExpression_11= ruleElseExpression )?
            {
            this_IF_0=(Token)match(input,RULE_IF,FOLLOW_19); 

            			current.merge(this_IF_0);
            		

            			newLeafNode(this_IF_0, grammarAccess.getConditionalExpressionAccess().getIFTerminalRuleCall_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_108); 

            			current.merge(this_OPENPARENTHESIS_1);
            		

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConditionalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:7187:3: (this_AndExpression_2= ruleAndExpression | this_OrExpression_3= ruleOrExpression | this_ArithmeticalComparationExpression_4= ruleArithmeticalComparationExpression | this_ComparationExpression_5= ruleComparationExpression )
            int alt187=4;
            alt187 = dfa187.predict(input);
            switch (alt187) {
                case 1 :
                    // InternalSM2.g:7188:4: this_AndExpression_2= ruleAndExpression
                    {

                    				newCompositeNode(grammarAccess.getConditionalExpressionAccess().getAndExpressionParserRuleCall_2_0());
                    			
                    pushFollow(FOLLOW_21);
                    this_AndExpression_2=ruleAndExpression();

                    state._fsp--;


                    				current.merge(this_AndExpression_2);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;
                case 2 :
                    // InternalSM2.g:7199:4: this_OrExpression_3= ruleOrExpression
                    {

                    				newCompositeNode(grammarAccess.getConditionalExpressionAccess().getOrExpressionParserRuleCall_2_1());
                    			
                    pushFollow(FOLLOW_21);
                    this_OrExpression_3=ruleOrExpression();

                    state._fsp--;


                    				current.merge(this_OrExpression_3);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;
                case 3 :
                    // InternalSM2.g:7210:4: this_ArithmeticalComparationExpression_4= ruleArithmeticalComparationExpression
                    {

                    				newCompositeNode(grammarAccess.getConditionalExpressionAccess().getArithmeticalComparationExpressionParserRuleCall_2_2());
                    			
                    pushFollow(FOLLOW_21);
                    this_ArithmeticalComparationExpression_4=ruleArithmeticalComparationExpression();

                    state._fsp--;


                    				current.merge(this_ArithmeticalComparationExpression_4);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;
                case 4 :
                    // InternalSM2.g:7221:4: this_ComparationExpression_5= ruleComparationExpression
                    {

                    				newCompositeNode(grammarAccess.getConditionalExpressionAccess().getComparationExpressionParserRuleCall_2_3());
                    			
                    pushFollow(FOLLOW_21);
                    this_ComparationExpression_5=ruleComparationExpression();

                    state._fsp--;


                    				current.merge(this_ComparationExpression_5);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_14); 

            			current.merge(this_CLOSEPARENTHESIS_6);
            		

            			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getConditionalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_3());
            		
            this_OPENKEY_7=(Token)match(input,RULE_OPENKEY,FOLLOW_109); 

            			current.merge(this_OPENKEY_7);
            		

            			newLeafNode(this_OPENKEY_7, grammarAccess.getConditionalExpressionAccess().getOPENKEYTerminalRuleCall_4());
            		
            // InternalSM2.g:7246:3: (this_Expression_8= ruleExpression )?
            int alt188=2;
            int LA188_0 = input.LA(1);

            if ( (LA188_0==RULE_STRING||LA188_0==RULE_OPENPARENTHESIS||LA188_0==RULE_INT||(LA188_0>=RULE_FLOAT && LA188_0<=RULE_BOOLVALUE)||LA188_0==RULE_NEW||(LA188_0>=RULE_DELETE && LA188_0<=RULE_IF)||LA188_0==83||(LA188_0>=89 && LA188_0<=145)||LA188_0==164) ) {
                alt188=1;
            }
            switch (alt188) {
                case 1 :
                    // InternalSM2.g:7247:4: this_Expression_8= ruleExpression
                    {

                    				newCompositeNode(grammarAccess.getConditionalExpressionAccess().getExpressionParserRuleCall_5());
                    			
                    pushFollow(FOLLOW_16);
                    this_Expression_8=ruleExpression();

                    state._fsp--;


                    				current.merge(this_Expression_8);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            this_CLOSEKEY_9=(Token)match(input,RULE_CLOSEKEY,FOLLOW_23); 

            			current.merge(this_CLOSEKEY_9);
            		

            			newLeafNode(this_CLOSEKEY_9, grammarAccess.getConditionalExpressionAccess().getCLOSEKEYTerminalRuleCall_6());
            		
            this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_110); 

            			current.merge(this_EOLINE_10);
            		

            			newLeafNode(this_EOLINE_10, grammarAccess.getConditionalExpressionAccess().getEOLINETerminalRuleCall_7());
            		
            // InternalSM2.g:7272:3: (this_ElseExpression_11= ruleElseExpression )?
            int alt189=2;
            int LA189_0 = input.LA(1);

            if ( (LA189_0==RULE_ELSE) ) {
                alt189=1;
            }
            switch (alt189) {
                case 1 :
                    // InternalSM2.g:7273:4: this_ElseExpression_11= ruleElseExpression
                    {

                    				newCompositeNode(grammarAccess.getConditionalExpressionAccess().getElseExpressionParserRuleCall_8());
                    			
                    pushFollow(FOLLOW_2);
                    this_ElseExpression_11=ruleElseExpression();

                    state._fsp--;


                    				current.merge(this_ElseExpression_11);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConditionalExpression"


    // $ANTLR start "entryRuleElseExpression"
    // InternalSM2.g:7288:1: entryRuleElseExpression returns [String current=null] : iv_ruleElseExpression= ruleElseExpression EOF ;
    public final String entryRuleElseExpression() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleElseExpression = null;


        try {
            // InternalSM2.g:7288:54: (iv_ruleElseExpression= ruleElseExpression EOF )
            // InternalSM2.g:7289:2: iv_ruleElseExpression= ruleElseExpression EOF
            {
             newCompositeNode(grammarAccess.getElseExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleElseExpression=ruleElseExpression();

            state._fsp--;

             current =iv_ruleElseExpression.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElseExpression"


    // $ANTLR start "ruleElseExpression"
    // InternalSM2.g:7295:1: ruleElseExpression returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_ELSE_0= RULE_ELSE this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE (this_Expression_3= ruleExpression )? this_EOLINE_4= RULE_EOLINE this_CLOSEKEY_5= RULE_CLOSEKEY this_EOLINE_6= RULE_EOLINE ) ;
    public final AntlrDatatypeRuleToken ruleElseExpression() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_ELSE_0=null;
        Token this_OPENKEY_1=null;
        Token this_EOLINE_2=null;
        Token this_EOLINE_4=null;
        Token this_CLOSEKEY_5=null;
        Token this_EOLINE_6=null;
        AntlrDatatypeRuleToken this_Expression_3 = null;



        	enterRule();

        try {
            // InternalSM2.g:7301:2: ( (this_ELSE_0= RULE_ELSE this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE (this_Expression_3= ruleExpression )? this_EOLINE_4= RULE_EOLINE this_CLOSEKEY_5= RULE_CLOSEKEY this_EOLINE_6= RULE_EOLINE ) )
            // InternalSM2.g:7302:2: (this_ELSE_0= RULE_ELSE this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE (this_Expression_3= ruleExpression )? this_EOLINE_4= RULE_EOLINE this_CLOSEKEY_5= RULE_CLOSEKEY this_EOLINE_6= RULE_EOLINE )
            {
            // InternalSM2.g:7302:2: (this_ELSE_0= RULE_ELSE this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE (this_Expression_3= ruleExpression )? this_EOLINE_4= RULE_EOLINE this_CLOSEKEY_5= RULE_CLOSEKEY this_EOLINE_6= RULE_EOLINE )
            // InternalSM2.g:7303:3: this_ELSE_0= RULE_ELSE this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE (this_Expression_3= ruleExpression )? this_EOLINE_4= RULE_EOLINE this_CLOSEKEY_5= RULE_CLOSEKEY this_EOLINE_6= RULE_EOLINE
            {
            this_ELSE_0=(Token)match(input,RULE_ELSE,FOLLOW_14); 

            			current.merge(this_ELSE_0);
            		

            			newLeafNode(this_ELSE_0, grammarAccess.getElseExpressionAccess().getELSETerminalRuleCall_0());
            		
            this_OPENKEY_1=(Token)match(input,RULE_OPENKEY,FOLLOW_23); 

            			current.merge(this_OPENKEY_1);
            		

            			newLeafNode(this_OPENKEY_1, grammarAccess.getElseExpressionAccess().getOPENKEYTerminalRuleCall_1());
            		
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_111); 

            			current.merge(this_EOLINE_2);
            		

            			newLeafNode(this_EOLINE_2, grammarAccess.getElseExpressionAccess().getEOLINETerminalRuleCall_2());
            		
            // InternalSM2.g:7324:3: (this_Expression_3= ruleExpression )?
            int alt190=2;
            int LA190_0 = input.LA(1);

            if ( (LA190_0==RULE_STRING||LA190_0==RULE_OPENPARENTHESIS||LA190_0==RULE_INT||(LA190_0>=RULE_FLOAT && LA190_0<=RULE_BOOLVALUE)||LA190_0==RULE_NEW||(LA190_0>=RULE_DELETE && LA190_0<=RULE_IF)||LA190_0==83||(LA190_0>=89 && LA190_0<=145)||LA190_0==164) ) {
                alt190=1;
            }
            switch (alt190) {
                case 1 :
                    // InternalSM2.g:7325:4: this_Expression_3= ruleExpression
                    {

                    				newCompositeNode(grammarAccess.getElseExpressionAccess().getExpressionParserRuleCall_3());
                    			
                    pushFollow(FOLLOW_23);
                    this_Expression_3=ruleExpression();

                    state._fsp--;


                    				current.merge(this_Expression_3);
                    			

                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            this_EOLINE_4=(Token)match(input,RULE_EOLINE,FOLLOW_16); 

            			current.merge(this_EOLINE_4);
            		

            			newLeafNode(this_EOLINE_4, grammarAccess.getElseExpressionAccess().getEOLINETerminalRuleCall_4());
            		
            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_23); 

            			current.merge(this_CLOSEKEY_5);
            		

            			newLeafNode(this_CLOSEKEY_5, grammarAccess.getElseExpressionAccess().getCLOSEKEYTerminalRuleCall_5());
            		
            this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			current.merge(this_EOLINE_6);
            		

            			newLeafNode(this_EOLINE_6, grammarAccess.getElseExpressionAccess().getEOLINETerminalRuleCall_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElseExpression"


    // $ANTLR start "entryRuleLoops"
    // InternalSM2.g:7361:1: entryRuleLoops returns [EObject current=null] : iv_ruleLoops= ruleLoops EOF ;
    public final EObject entryRuleLoops() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLoops = null;


        try {
            // InternalSM2.g:7361:46: (iv_ruleLoops= ruleLoops EOF )
            // InternalSM2.g:7362:2: iv_ruleLoops= ruleLoops EOF
            {
             newCompositeNode(grammarAccess.getLoopsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLoops=ruleLoops();

            state._fsp--;

             current =iv_ruleLoops; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLoops"


    // $ANTLR start "ruleLoops"
    // InternalSM2.g:7368:1: ruleLoops returns [EObject current=null] : (this_WhileLoop_0= ruleWhileLoop | this_DoWhileLoop_1= ruleDoWhileLoop | this_ForLoop_2= ruleForLoop ) ;
    public final EObject ruleLoops() throws RecognitionException {
        EObject current = null;

        EObject this_WhileLoop_0 = null;

        EObject this_DoWhileLoop_1 = null;

        EObject this_ForLoop_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:7374:2: ( (this_WhileLoop_0= ruleWhileLoop | this_DoWhileLoop_1= ruleDoWhileLoop | this_ForLoop_2= ruleForLoop ) )
            // InternalSM2.g:7375:2: (this_WhileLoop_0= ruleWhileLoop | this_DoWhileLoop_1= ruleDoWhileLoop | this_ForLoop_2= ruleForLoop )
            {
            // InternalSM2.g:7375:2: (this_WhileLoop_0= ruleWhileLoop | this_DoWhileLoop_1= ruleDoWhileLoop | this_ForLoop_2= ruleForLoop )
            int alt191=3;
            switch ( input.LA(1) ) {
            case 184:
                {
                alt191=1;
                }
                break;
            case 187:
                {
                alt191=2;
                }
                break;
            case 185:
                {
                alt191=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 191, 0, input);

                throw nvae;
            }

            switch (alt191) {
                case 1 :
                    // InternalSM2.g:7376:3: this_WhileLoop_0= ruleWhileLoop
                    {

                    			newCompositeNode(grammarAccess.getLoopsAccess().getWhileLoopParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_WhileLoop_0=ruleWhileLoop();

                    state._fsp--;


                    			current = this_WhileLoop_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:7385:3: this_DoWhileLoop_1= ruleDoWhileLoop
                    {

                    			newCompositeNode(grammarAccess.getLoopsAccess().getDoWhileLoopParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_DoWhileLoop_1=ruleDoWhileLoop();

                    state._fsp--;


                    			current = this_DoWhileLoop_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:7394:3: this_ForLoop_2= ruleForLoop
                    {

                    			newCompositeNode(grammarAccess.getLoopsAccess().getForLoopParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_ForLoop_2=ruleForLoop();

                    state._fsp--;


                    			current = this_ForLoop_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLoops"


    // $ANTLR start "entryRuleWhileLoop"
    // InternalSM2.g:7406:1: entryRuleWhileLoop returns [EObject current=null] : iv_ruleWhileLoop= ruleWhileLoop EOF ;
    public final EObject entryRuleWhileLoop() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleWhileLoop = null;


        try {
            // InternalSM2.g:7406:50: (iv_ruleWhileLoop= ruleWhileLoop EOF )
            // InternalSM2.g:7407:2: iv_ruleWhileLoop= ruleWhileLoop EOF
            {
             newCompositeNode(grammarAccess.getWhileLoopRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleWhileLoop=ruleWhileLoop();

            state._fsp--;

             current =iv_ruleWhileLoop; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleWhileLoop"


    // $ANTLR start "ruleWhileLoop"
    // InternalSM2.g:7413:1: ruleWhileLoop returns [EObject current=null] : (otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( (lv_condition_2_1= ruleAndExpression | lv_condition_2_2= ruleOrExpression | lv_condition_2_3= ruleArithmeticalComparationExpression | lv_condition_2_4= ruleComparationExpression ) ) ) this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_OPENKEY_4= RULE_OPENKEY this_EOLINE_5= RULE_EOLINE ( (lv_gasrestriction_6_0= ruleRestrictionGas ) ) ( (lv_loop_7_0= ruleWhileLoop ) ) ( (lv_expression_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY ) ;
    public final EObject ruleWhileLoop() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token this_OPENKEY_4=null;
        Token this_EOLINE_5=null;
        Token this_CLOSEKEY_9=null;
        AntlrDatatypeRuleToken lv_condition_2_1 = null;

        AntlrDatatypeRuleToken lv_condition_2_2 = null;

        AntlrDatatypeRuleToken lv_condition_2_3 = null;

        AntlrDatatypeRuleToken lv_condition_2_4 = null;

        EObject lv_gasrestriction_6_0 = null;

        EObject lv_loop_7_0 = null;

        AntlrDatatypeRuleToken lv_expression_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:7419:2: ( (otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( (lv_condition_2_1= ruleAndExpression | lv_condition_2_2= ruleOrExpression | lv_condition_2_3= ruleArithmeticalComparationExpression | lv_condition_2_4= ruleComparationExpression ) ) ) this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_OPENKEY_4= RULE_OPENKEY this_EOLINE_5= RULE_EOLINE ( (lv_gasrestriction_6_0= ruleRestrictionGas ) ) ( (lv_loop_7_0= ruleWhileLoop ) ) ( (lv_expression_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY ) )
            // InternalSM2.g:7420:2: (otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( (lv_condition_2_1= ruleAndExpression | lv_condition_2_2= ruleOrExpression | lv_condition_2_3= ruleArithmeticalComparationExpression | lv_condition_2_4= ruleComparationExpression ) ) ) this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_OPENKEY_4= RULE_OPENKEY this_EOLINE_5= RULE_EOLINE ( (lv_gasrestriction_6_0= ruleRestrictionGas ) ) ( (lv_loop_7_0= ruleWhileLoop ) ) ( (lv_expression_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY )
            {
            // InternalSM2.g:7420:2: (otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( (lv_condition_2_1= ruleAndExpression | lv_condition_2_2= ruleOrExpression | lv_condition_2_3= ruleArithmeticalComparationExpression | lv_condition_2_4= ruleComparationExpression ) ) ) this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_OPENKEY_4= RULE_OPENKEY this_EOLINE_5= RULE_EOLINE ( (lv_gasrestriction_6_0= ruleRestrictionGas ) ) ( (lv_loop_7_0= ruleWhileLoop ) ) ( (lv_expression_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY )
            // InternalSM2.g:7421:3: otherlv_0= 'while' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( (lv_condition_2_1= ruleAndExpression | lv_condition_2_2= ruleOrExpression | lv_condition_2_3= ruleArithmeticalComparationExpression | lv_condition_2_4= ruleComparationExpression ) ) ) this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_OPENKEY_4= RULE_OPENKEY this_EOLINE_5= RULE_EOLINE ( (lv_gasrestriction_6_0= ruleRestrictionGas ) ) ( (lv_loop_7_0= ruleWhileLoop ) ) ( (lv_expression_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,184,FOLLOW_19); 

            			newLeafNode(otherlv_0, grammarAccess.getWhileLoopAccess().getWhileKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_108); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getWhileLoopAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:7429:3: ( ( (lv_condition_2_1= ruleAndExpression | lv_condition_2_2= ruleOrExpression | lv_condition_2_3= ruleArithmeticalComparationExpression | lv_condition_2_4= ruleComparationExpression ) ) )
            // InternalSM2.g:7430:4: ( (lv_condition_2_1= ruleAndExpression | lv_condition_2_2= ruleOrExpression | lv_condition_2_3= ruleArithmeticalComparationExpression | lv_condition_2_4= ruleComparationExpression ) )
            {
            // InternalSM2.g:7430:4: ( (lv_condition_2_1= ruleAndExpression | lv_condition_2_2= ruleOrExpression | lv_condition_2_3= ruleArithmeticalComparationExpression | lv_condition_2_4= ruleComparationExpression ) )
            // InternalSM2.g:7431:5: (lv_condition_2_1= ruleAndExpression | lv_condition_2_2= ruleOrExpression | lv_condition_2_3= ruleArithmeticalComparationExpression | lv_condition_2_4= ruleComparationExpression )
            {
            // InternalSM2.g:7431:5: (lv_condition_2_1= ruleAndExpression | lv_condition_2_2= ruleOrExpression | lv_condition_2_3= ruleArithmeticalComparationExpression | lv_condition_2_4= ruleComparationExpression )
            int alt192=4;
            alt192 = dfa192.predict(input);
            switch (alt192) {
                case 1 :
                    // InternalSM2.g:7432:6: lv_condition_2_1= ruleAndExpression
                    {

                    						newCompositeNode(grammarAccess.getWhileLoopAccess().getConditionAndExpressionParserRuleCall_2_0_0());
                    					
                    pushFollow(FOLLOW_21);
                    lv_condition_2_1=ruleAndExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getWhileLoopRule());
                    						}
                    						set(
                    							current,
                    							"condition",
                    							lv_condition_2_1,
                    							"org.xtext.SM2.AndExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:7448:6: lv_condition_2_2= ruleOrExpression
                    {

                    						newCompositeNode(grammarAccess.getWhileLoopAccess().getConditionOrExpressionParserRuleCall_2_0_1());
                    					
                    pushFollow(FOLLOW_21);
                    lv_condition_2_2=ruleOrExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getWhileLoopRule());
                    						}
                    						set(
                    							current,
                    							"condition",
                    							lv_condition_2_2,
                    							"org.xtext.SM2.OrExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;
                case 3 :
                    // InternalSM2.g:7464:6: lv_condition_2_3= ruleArithmeticalComparationExpression
                    {

                    						newCompositeNode(grammarAccess.getWhileLoopAccess().getConditionArithmeticalComparationExpressionParserRuleCall_2_0_2());
                    					
                    pushFollow(FOLLOW_21);
                    lv_condition_2_3=ruleArithmeticalComparationExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getWhileLoopRule());
                    						}
                    						set(
                    							current,
                    							"condition",
                    							lv_condition_2_3,
                    							"org.xtext.SM2.ArithmeticalComparationExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;
                case 4 :
                    // InternalSM2.g:7480:6: lv_condition_2_4= ruleComparationExpression
                    {

                    						newCompositeNode(grammarAccess.getWhileLoopAccess().getConditionComparationExpressionParserRuleCall_2_0_3());
                    					
                    pushFollow(FOLLOW_21);
                    lv_condition_2_4=ruleComparationExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getWhileLoopRule());
                    						}
                    						set(
                    							current,
                    							"condition",
                    							lv_condition_2_4,
                    							"org.xtext.SM2.ComparationExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;

            }


            }


            }

            this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_14); 

            			newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getWhileLoopAccess().getCLOSEPARENTHESISTerminalRuleCall_3());
            		
            this_OPENKEY_4=(Token)match(input,RULE_OPENKEY,FOLLOW_23); 

            			newLeafNode(this_OPENKEY_4, grammarAccess.getWhileLoopAccess().getOPENKEYTerminalRuleCall_4());
            		
            this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_112); 

            			newLeafNode(this_EOLINE_5, grammarAccess.getWhileLoopAccess().getEOLINETerminalRuleCall_5());
            		
            // InternalSM2.g:7510:3: ( (lv_gasrestriction_6_0= ruleRestrictionGas ) )
            // InternalSM2.g:7511:4: (lv_gasrestriction_6_0= ruleRestrictionGas )
            {
            // InternalSM2.g:7511:4: (lv_gasrestriction_6_0= ruleRestrictionGas )
            // InternalSM2.g:7512:5: lv_gasrestriction_6_0= ruleRestrictionGas
            {

            					newCompositeNode(grammarAccess.getWhileLoopAccess().getGasrestrictionRestrictionGasParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_113);
            lv_gasrestriction_6_0=ruleRestrictionGas();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
            					}
            					set(
            						current,
            						"gasrestriction",
            						lv_gasrestriction_6_0,
            						"org.xtext.SM2.RestrictionGas");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:7529:3: ( (lv_loop_7_0= ruleWhileLoop ) )
            // InternalSM2.g:7530:4: (lv_loop_7_0= ruleWhileLoop )
            {
            // InternalSM2.g:7530:4: (lv_loop_7_0= ruleWhileLoop )
            // InternalSM2.g:7531:5: lv_loop_7_0= ruleWhileLoop
            {

            					newCompositeNode(grammarAccess.getWhileLoopAccess().getLoopWhileLoopParserRuleCall_7_0());
            				
            pushFollow(FOLLOW_20);
            lv_loop_7_0=ruleWhileLoop();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
            					}
            					add(
            						current,
            						"loop",
            						lv_loop_7_0,
            						"org.xtext.SM2.WhileLoop");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:7548:3: ( (lv_expression_8_0= ruleExpression ) )
            // InternalSM2.g:7549:4: (lv_expression_8_0= ruleExpression )
            {
            // InternalSM2.g:7549:4: (lv_expression_8_0= ruleExpression )
            // InternalSM2.g:7550:5: lv_expression_8_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getWhileLoopAccess().getExpressionExpressionParserRuleCall_8_0());
            				
            pushFollow(FOLLOW_16);
            lv_expression_8_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getWhileLoopRule());
            					}
            					add(
            						current,
            						"expression",
            						lv_expression_8_0,
            						"org.xtext.SM2.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEKEY_9=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); 

            			newLeafNode(this_CLOSEKEY_9, grammarAccess.getWhileLoopAccess().getCLOSEKEYTerminalRuleCall_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleWhileLoop"


    // $ANTLR start "entryRuleForLoop"
    // InternalSM2.g:7575:1: entryRuleForLoop returns [EObject current=null] : iv_ruleForLoop= ruleForLoop EOF ;
    public final EObject entryRuleForLoop() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleForLoop = null;


        try {
            // InternalSM2.g:7575:48: (iv_ruleForLoop= ruleForLoop EOF )
            // InternalSM2.g:7576:2: iv_ruleForLoop= ruleForLoop EOF
            {
             newCompositeNode(grammarAccess.getForLoopRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleForLoop=ruleForLoop();

            state._fsp--;

             current =iv_ruleForLoop; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleForLoop"


    // $ANTLR start "ruleForLoop"
    // InternalSM2.g:7582:1: ruleForLoop returns [EObject current=null] : (otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INT ) ) ) | ( ( (lv_typeCounter_6_0= 'char' ) ) ( (lv_nameCounter_7_0= RULE_ID ) ) otherlv_8= '=' ( (lv_valueCounter_9_0= RULE_CHAR ) ) ) ) this_SEMICOLON_10= RULE_SEMICOLON ( (lv_condition_11_0= ruleArithmeticalComparationExpression ) ) this_SEMICOLON_12= RULE_SEMICOLON ( ruleIncrementLoopExpression | ruleDecrementLoopExpression ) this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS this_OPENKEY_16= RULE_OPENKEY this_EOLINE_17= RULE_EOLINE ( (lv_restrictionGas_18_0= ruleRestrictionGas ) ) ( (lv_loops_19_0= ruleLoops ) )? ( (lv_expressions_20_0= ruleExpression ) ) (this_BREAK_21= RULE_BREAK this_SEMICOLON_22= RULE_SEMICOLON )? this_CLOSEKEY_23= RULE_CLOSEKEY ) ;
    public final EObject ruleForLoop() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_typeCounter_2_1=null;
        Token lv_typeCounter_2_2=null;
        Token lv_nameCounter_3_0=null;
        Token otherlv_4=null;
        Token lv_value_5_0=null;
        Token lv_typeCounter_6_0=null;
        Token lv_nameCounter_7_0=null;
        Token otherlv_8=null;
        Token lv_valueCounter_9_0=null;
        Token this_SEMICOLON_10=null;
        Token this_SEMICOLON_12=null;
        Token this_CLOSEPARENTHESIS_15=null;
        Token this_OPENKEY_16=null;
        Token this_EOLINE_17=null;
        Token this_BREAK_21=null;
        Token this_SEMICOLON_22=null;
        Token this_CLOSEKEY_23=null;
        AntlrDatatypeRuleToken lv_condition_11_0 = null;

        EObject lv_restrictionGas_18_0 = null;

        EObject lv_loops_19_0 = null;

        AntlrDatatypeRuleToken lv_expressions_20_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:7588:2: ( (otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INT ) ) ) | ( ( (lv_typeCounter_6_0= 'char' ) ) ( (lv_nameCounter_7_0= RULE_ID ) ) otherlv_8= '=' ( (lv_valueCounter_9_0= RULE_CHAR ) ) ) ) this_SEMICOLON_10= RULE_SEMICOLON ( (lv_condition_11_0= ruleArithmeticalComparationExpression ) ) this_SEMICOLON_12= RULE_SEMICOLON ( ruleIncrementLoopExpression | ruleDecrementLoopExpression ) this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS this_OPENKEY_16= RULE_OPENKEY this_EOLINE_17= RULE_EOLINE ( (lv_restrictionGas_18_0= ruleRestrictionGas ) ) ( (lv_loops_19_0= ruleLoops ) )? ( (lv_expressions_20_0= ruleExpression ) ) (this_BREAK_21= RULE_BREAK this_SEMICOLON_22= RULE_SEMICOLON )? this_CLOSEKEY_23= RULE_CLOSEKEY ) )
            // InternalSM2.g:7589:2: (otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INT ) ) ) | ( ( (lv_typeCounter_6_0= 'char' ) ) ( (lv_nameCounter_7_0= RULE_ID ) ) otherlv_8= '=' ( (lv_valueCounter_9_0= RULE_CHAR ) ) ) ) this_SEMICOLON_10= RULE_SEMICOLON ( (lv_condition_11_0= ruleArithmeticalComparationExpression ) ) this_SEMICOLON_12= RULE_SEMICOLON ( ruleIncrementLoopExpression | ruleDecrementLoopExpression ) this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS this_OPENKEY_16= RULE_OPENKEY this_EOLINE_17= RULE_EOLINE ( (lv_restrictionGas_18_0= ruleRestrictionGas ) ) ( (lv_loops_19_0= ruleLoops ) )? ( (lv_expressions_20_0= ruleExpression ) ) (this_BREAK_21= RULE_BREAK this_SEMICOLON_22= RULE_SEMICOLON )? this_CLOSEKEY_23= RULE_CLOSEKEY )
            {
            // InternalSM2.g:7589:2: (otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INT ) ) ) | ( ( (lv_typeCounter_6_0= 'char' ) ) ( (lv_nameCounter_7_0= RULE_ID ) ) otherlv_8= '=' ( (lv_valueCounter_9_0= RULE_CHAR ) ) ) ) this_SEMICOLON_10= RULE_SEMICOLON ( (lv_condition_11_0= ruleArithmeticalComparationExpression ) ) this_SEMICOLON_12= RULE_SEMICOLON ( ruleIncrementLoopExpression | ruleDecrementLoopExpression ) this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS this_OPENKEY_16= RULE_OPENKEY this_EOLINE_17= RULE_EOLINE ( (lv_restrictionGas_18_0= ruleRestrictionGas ) ) ( (lv_loops_19_0= ruleLoops ) )? ( (lv_expressions_20_0= ruleExpression ) ) (this_BREAK_21= RULE_BREAK this_SEMICOLON_22= RULE_SEMICOLON )? this_CLOSEKEY_23= RULE_CLOSEKEY )
            // InternalSM2.g:7590:3: otherlv_0= 'for' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INT ) ) ) | ( ( (lv_typeCounter_6_0= 'char' ) ) ( (lv_nameCounter_7_0= RULE_ID ) ) otherlv_8= '=' ( (lv_valueCounter_9_0= RULE_CHAR ) ) ) ) this_SEMICOLON_10= RULE_SEMICOLON ( (lv_condition_11_0= ruleArithmeticalComparationExpression ) ) this_SEMICOLON_12= RULE_SEMICOLON ( ruleIncrementLoopExpression | ruleDecrementLoopExpression ) this_CLOSEPARENTHESIS_15= RULE_CLOSEPARENTHESIS this_OPENKEY_16= RULE_OPENKEY this_EOLINE_17= RULE_EOLINE ( (lv_restrictionGas_18_0= ruleRestrictionGas ) ) ( (lv_loops_19_0= ruleLoops ) )? ( (lv_expressions_20_0= ruleExpression ) ) (this_BREAK_21= RULE_BREAK this_SEMICOLON_22= RULE_SEMICOLON )? this_CLOSEKEY_23= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,185,FOLLOW_19); 

            			newLeafNode(otherlv_0, grammarAccess.getForLoopAccess().getForKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_114); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getForLoopAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:7598:3: ( ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INT ) ) ) | ( ( (lv_typeCounter_6_0= 'char' ) ) ( (lv_nameCounter_7_0= RULE_ID ) ) otherlv_8= '=' ( (lv_valueCounter_9_0= RULE_CHAR ) ) ) )
            int alt194=2;
            int LA194_0 = input.LA(1);

            if ( (LA194_0==89||LA194_0==108) ) {
                alt194=1;
            }
            else if ( (LA194_0==186) ) {
                alt194=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 194, 0, input);

                throw nvae;
            }
            switch (alt194) {
                case 1 :
                    // InternalSM2.g:7599:4: ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INT ) ) )
                    {
                    // InternalSM2.g:7599:4: ( ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INT ) ) )
                    // InternalSM2.g:7600:5: ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) ) ( (lv_nameCounter_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_value_5_0= RULE_INT ) )
                    {
                    // InternalSM2.g:7600:5: ( ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) ) )
                    // InternalSM2.g:7601:6: ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) )
                    {
                    // InternalSM2.g:7601:6: ( (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' ) )
                    // InternalSM2.g:7602:7: (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' )
                    {
                    // InternalSM2.g:7602:7: (lv_typeCounter_2_1= 'uint' | lv_typeCounter_2_2= 'int' )
                    int alt193=2;
                    int LA193_0 = input.LA(1);

                    if ( (LA193_0==89) ) {
                        alt193=1;
                    }
                    else if ( (LA193_0==108) ) {
                        alt193=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 193, 0, input);

                        throw nvae;
                    }
                    switch (alt193) {
                        case 1 :
                            // InternalSM2.g:7603:8: lv_typeCounter_2_1= 'uint'
                            {
                            lv_typeCounter_2_1=(Token)match(input,89,FOLLOW_13); 

                            								newLeafNode(lv_typeCounter_2_1, grammarAccess.getForLoopAccess().getTypeCounterUintKeyword_2_0_0_0_0());
                            							

                            								if (current==null) {
                            									current = createModelElement(grammarAccess.getForLoopRule());
                            								}
                            								setWithLastConsumed(current, "typeCounter", lv_typeCounter_2_1, null);
                            							

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:7614:8: lv_typeCounter_2_2= 'int'
                            {
                            lv_typeCounter_2_2=(Token)match(input,108,FOLLOW_13); 

                            								newLeafNode(lv_typeCounter_2_2, grammarAccess.getForLoopAccess().getTypeCounterIntKeyword_2_0_0_0_1());
                            							

                            								if (current==null) {
                            									current = createModelElement(grammarAccess.getForLoopRule());
                            								}
                            								setWithLastConsumed(current, "typeCounter", lv_typeCounter_2_2, null);
                            							

                            }
                            break;

                    }


                    }


                    }

                    // InternalSM2.g:7627:5: ( (lv_nameCounter_3_0= RULE_ID ) )
                    // InternalSM2.g:7628:6: (lv_nameCounter_3_0= RULE_ID )
                    {
                    // InternalSM2.g:7628:6: (lv_nameCounter_3_0= RULE_ID )
                    // InternalSM2.g:7629:7: lv_nameCounter_3_0= RULE_ID
                    {
                    lv_nameCounter_3_0=(Token)match(input,RULE_ID,FOLLOW_67); 

                    							newLeafNode(lv_nameCounter_3_0, grammarAccess.getForLoopAccess().getNameCounterIDTerminalRuleCall_2_0_1_0());
                    						

                    							if (current==null) {
                    								current = createModelElement(grammarAccess.getForLoopRule());
                    							}
                    							setWithLastConsumed(
                    								current,
                    								"nameCounter",
                    								lv_nameCounter_3_0,
                    								"org.eclipse.xtext.common.Terminals.ID");
                    						

                    }


                    }

                    otherlv_4=(Token)match(input,86,FOLLOW_59); 

                    					newLeafNode(otherlv_4, grammarAccess.getForLoopAccess().getEqualsSignKeyword_2_0_2());
                    				
                    // InternalSM2.g:7649:5: ( (lv_value_5_0= RULE_INT ) )
                    // InternalSM2.g:7650:6: (lv_value_5_0= RULE_INT )
                    {
                    // InternalSM2.g:7650:6: (lv_value_5_0= RULE_INT )
                    // InternalSM2.g:7651:7: lv_value_5_0= RULE_INT
                    {
                    lv_value_5_0=(Token)match(input,RULE_INT,FOLLOW_8); 

                    							newLeafNode(lv_value_5_0, grammarAccess.getForLoopAccess().getValueINTTerminalRuleCall_2_0_3_0());
                    						

                    							if (current==null) {
                    								current = createModelElement(grammarAccess.getForLoopRule());
                    							}
                    							setWithLastConsumed(
                    								current,
                    								"value",
                    								lv_value_5_0,
                    								"org.eclipse.xtext.common.Terminals.INT");
                    						

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:7669:4: ( ( (lv_typeCounter_6_0= 'char' ) ) ( (lv_nameCounter_7_0= RULE_ID ) ) otherlv_8= '=' ( (lv_valueCounter_9_0= RULE_CHAR ) ) )
                    {
                    // InternalSM2.g:7669:4: ( ( (lv_typeCounter_6_0= 'char' ) ) ( (lv_nameCounter_7_0= RULE_ID ) ) otherlv_8= '=' ( (lv_valueCounter_9_0= RULE_CHAR ) ) )
                    // InternalSM2.g:7670:5: ( (lv_typeCounter_6_0= 'char' ) ) ( (lv_nameCounter_7_0= RULE_ID ) ) otherlv_8= '=' ( (lv_valueCounter_9_0= RULE_CHAR ) )
                    {
                    // InternalSM2.g:7670:5: ( (lv_typeCounter_6_0= 'char' ) )
                    // InternalSM2.g:7671:6: (lv_typeCounter_6_0= 'char' )
                    {
                    // InternalSM2.g:7671:6: (lv_typeCounter_6_0= 'char' )
                    // InternalSM2.g:7672:7: lv_typeCounter_6_0= 'char'
                    {
                    lv_typeCounter_6_0=(Token)match(input,186,FOLLOW_13); 

                    							newLeafNode(lv_typeCounter_6_0, grammarAccess.getForLoopAccess().getTypeCounterCharKeyword_2_1_0_0());
                    						

                    							if (current==null) {
                    								current = createModelElement(grammarAccess.getForLoopRule());
                    							}
                    							setWithLastConsumed(current, "typeCounter", lv_typeCounter_6_0, "char");
                    						

                    }


                    }

                    // InternalSM2.g:7684:5: ( (lv_nameCounter_7_0= RULE_ID ) )
                    // InternalSM2.g:7685:6: (lv_nameCounter_7_0= RULE_ID )
                    {
                    // InternalSM2.g:7685:6: (lv_nameCounter_7_0= RULE_ID )
                    // InternalSM2.g:7686:7: lv_nameCounter_7_0= RULE_ID
                    {
                    lv_nameCounter_7_0=(Token)match(input,RULE_ID,FOLLOW_67); 

                    							newLeafNode(lv_nameCounter_7_0, grammarAccess.getForLoopAccess().getNameCounterIDTerminalRuleCall_2_1_1_0());
                    						

                    							if (current==null) {
                    								current = createModelElement(grammarAccess.getForLoopRule());
                    							}
                    							setWithLastConsumed(
                    								current,
                    								"nameCounter",
                    								lv_nameCounter_7_0,
                    								"org.eclipse.xtext.common.Terminals.ID");
                    						

                    }


                    }

                    otherlv_8=(Token)match(input,86,FOLLOW_115); 

                    					newLeafNode(otherlv_8, grammarAccess.getForLoopAccess().getEqualsSignKeyword_2_1_2());
                    				
                    // InternalSM2.g:7706:5: ( (lv_valueCounter_9_0= RULE_CHAR ) )
                    // InternalSM2.g:7707:6: (lv_valueCounter_9_0= RULE_CHAR )
                    {
                    // InternalSM2.g:7707:6: (lv_valueCounter_9_0= RULE_CHAR )
                    // InternalSM2.g:7708:7: lv_valueCounter_9_0= RULE_CHAR
                    {
                    lv_valueCounter_9_0=(Token)match(input,RULE_CHAR,FOLLOW_8); 

                    							newLeafNode(lv_valueCounter_9_0, grammarAccess.getForLoopAccess().getValueCounterCHARTerminalRuleCall_2_1_3_0());
                    						

                    							if (current==null) {
                    								current = createModelElement(grammarAccess.getForLoopRule());
                    							}
                    							setWithLastConsumed(
                    								current,
                    								"valueCounter",
                    								lv_valueCounter_9_0,
                    								"org.xtext.SM2.CHAR");
                    						

                    }


                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_10=(Token)match(input,RULE_SEMICOLON,FOLLOW_81); 

            			newLeafNode(this_SEMICOLON_10, grammarAccess.getForLoopAccess().getSEMICOLONTerminalRuleCall_3());
            		
            // InternalSM2.g:7730:3: ( (lv_condition_11_0= ruleArithmeticalComparationExpression ) )
            // InternalSM2.g:7731:4: (lv_condition_11_0= ruleArithmeticalComparationExpression )
            {
            // InternalSM2.g:7731:4: (lv_condition_11_0= ruleArithmeticalComparationExpression )
            // InternalSM2.g:7732:5: lv_condition_11_0= ruleArithmeticalComparationExpression
            {

            					newCompositeNode(grammarAccess.getForLoopAccess().getConditionArithmeticalComparationExpressionParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_8);
            lv_condition_11_0=ruleArithmeticalComparationExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getForLoopRule());
            					}
            					set(
            						current,
            						"condition",
            						lv_condition_11_0,
            						"org.xtext.SM2.ArithmeticalComparationExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_12=(Token)match(input,RULE_SEMICOLON,FOLLOW_81); 

            			newLeafNode(this_SEMICOLON_12, grammarAccess.getForLoopAccess().getSEMICOLONTerminalRuleCall_5());
            		
            // InternalSM2.g:7753:3: ( ruleIncrementLoopExpression | ruleDecrementLoopExpression )
            int alt195=2;
            int LA195_0 = input.LA(1);

            if ( (LA195_0==RULE_INT) ) {
                int LA195_1 = input.LA(2);

                if ( (LA195_1==183) ) {
                    alt195=2;
                }
                else if ( (LA195_1==182) ) {
                    alt195=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 195, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA195_0==RULE_STRING) ) {
                int LA195_2 = input.LA(2);

                if ( (LA195_2==182) ) {
                    alt195=1;
                }
                else if ( (LA195_2==183) ) {
                    alt195=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 195, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 195, 0, input);

                throw nvae;
            }
            switch (alt195) {
                case 1 :
                    // InternalSM2.g:7754:4: ruleIncrementLoopExpression
                    {

                    				newCompositeNode(grammarAccess.getForLoopAccess().getIncrementLoopExpressionParserRuleCall_6_0());
                    			
                    pushFollow(FOLLOW_21);
                    ruleIncrementLoopExpression();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;
                case 2 :
                    // InternalSM2.g:7762:4: ruleDecrementLoopExpression
                    {

                    				newCompositeNode(grammarAccess.getForLoopAccess().getDecrementLoopExpressionParserRuleCall_6_1());
                    			
                    pushFollow(FOLLOW_21);
                    ruleDecrementLoopExpression();

                    state._fsp--;


                    				afterParserOrEnumRuleCall();
                    			

                    }
                    break;

            }

            this_CLOSEPARENTHESIS_15=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_14); 

            			newLeafNode(this_CLOSEPARENTHESIS_15, grammarAccess.getForLoopAccess().getCLOSEPARENTHESISTerminalRuleCall_7());
            		
            this_OPENKEY_16=(Token)match(input,RULE_OPENKEY,FOLLOW_23); 

            			newLeafNode(this_OPENKEY_16, grammarAccess.getForLoopAccess().getOPENKEYTerminalRuleCall_8());
            		
            this_EOLINE_17=(Token)match(input,RULE_EOLINE,FOLLOW_112); 

            			newLeafNode(this_EOLINE_17, grammarAccess.getForLoopAccess().getEOLINETerminalRuleCall_9());
            		
            // InternalSM2.g:7782:3: ( (lv_restrictionGas_18_0= ruleRestrictionGas ) )
            // InternalSM2.g:7783:4: (lv_restrictionGas_18_0= ruleRestrictionGas )
            {
            // InternalSM2.g:7783:4: (lv_restrictionGas_18_0= ruleRestrictionGas )
            // InternalSM2.g:7784:5: lv_restrictionGas_18_0= ruleRestrictionGas
            {

            					newCompositeNode(grammarAccess.getForLoopAccess().getRestrictionGasRestrictionGasParserRuleCall_10_0());
            				
            pushFollow(FOLLOW_116);
            lv_restrictionGas_18_0=ruleRestrictionGas();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getForLoopRule());
            					}
            					set(
            						current,
            						"restrictionGas",
            						lv_restrictionGas_18_0,
            						"org.xtext.SM2.RestrictionGas");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:7801:3: ( (lv_loops_19_0= ruleLoops ) )?
            int alt196=2;
            int LA196_0 = input.LA(1);

            if ( ((LA196_0>=184 && LA196_0<=185)||LA196_0==187) ) {
                alt196=1;
            }
            switch (alt196) {
                case 1 :
                    // InternalSM2.g:7802:4: (lv_loops_19_0= ruleLoops )
                    {
                    // InternalSM2.g:7802:4: (lv_loops_19_0= ruleLoops )
                    // InternalSM2.g:7803:5: lv_loops_19_0= ruleLoops
                    {

                    					newCompositeNode(grammarAccess.getForLoopAccess().getLoopsLoopsParserRuleCall_11_0());
                    				
                    pushFollow(FOLLOW_20);
                    lv_loops_19_0=ruleLoops();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getForLoopRule());
                    					}
                    					add(
                    						current,
                    						"loops",
                    						lv_loops_19_0,
                    						"org.xtext.SM2.Loops");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:7820:3: ( (lv_expressions_20_0= ruleExpression ) )
            // InternalSM2.g:7821:4: (lv_expressions_20_0= ruleExpression )
            {
            // InternalSM2.g:7821:4: (lv_expressions_20_0= ruleExpression )
            // InternalSM2.g:7822:5: lv_expressions_20_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getForLoopAccess().getExpressionsExpressionParserRuleCall_12_0());
            				
            pushFollow(FOLLOW_117);
            lv_expressions_20_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getForLoopRule());
            					}
            					add(
            						current,
            						"expressions",
            						lv_expressions_20_0,
            						"org.xtext.SM2.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:7839:3: (this_BREAK_21= RULE_BREAK this_SEMICOLON_22= RULE_SEMICOLON )?
            int alt197=2;
            int LA197_0 = input.LA(1);

            if ( (LA197_0==RULE_BREAK) ) {
                alt197=1;
            }
            switch (alt197) {
                case 1 :
                    // InternalSM2.g:7840:4: this_BREAK_21= RULE_BREAK this_SEMICOLON_22= RULE_SEMICOLON
                    {
                    this_BREAK_21=(Token)match(input,RULE_BREAK,FOLLOW_8); 

                    				newLeafNode(this_BREAK_21, grammarAccess.getForLoopAccess().getBREAKTerminalRuleCall_13_0());
                    			
                    this_SEMICOLON_22=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); 

                    				newLeafNode(this_SEMICOLON_22, grammarAccess.getForLoopAccess().getSEMICOLONTerminalRuleCall_13_1());
                    			

                    }
                    break;

            }

            this_CLOSEKEY_23=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); 

            			newLeafNode(this_CLOSEKEY_23, grammarAccess.getForLoopAccess().getCLOSEKEYTerminalRuleCall_14());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleForLoop"


    // $ANTLR start "entryRuleDoWhileLoop"
    // InternalSM2.g:7857:1: entryRuleDoWhileLoop returns [EObject current=null] : iv_ruleDoWhileLoop= ruleDoWhileLoop EOF ;
    public final EObject entryRuleDoWhileLoop() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDoWhileLoop = null;


        try {
            // InternalSM2.g:7857:52: (iv_ruleDoWhileLoop= ruleDoWhileLoop EOF )
            // InternalSM2.g:7858:2: iv_ruleDoWhileLoop= ruleDoWhileLoop EOF
            {
             newCompositeNode(grammarAccess.getDoWhileLoopRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDoWhileLoop=ruleDoWhileLoop();

            state._fsp--;

             current =iv_ruleDoWhileLoop; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDoWhileLoop"


    // $ANTLR start "ruleDoWhileLoop"
    // InternalSM2.g:7864:1: ruleDoWhileLoop returns [EObject current=null] : (otherlv_0= 'do' this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restrictionGas_3_0= ruleRestrictionGas ) ) ( (lv_loops_4_0= ruleLoops ) )? ( (lv_expressions_5_0= ruleExpression ) ) this_CLOSEKEY_6= RULE_CLOSEKEY this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'while' ( ( (lv_condition_9_1= ruleAndExpression | lv_condition_9_2= ruleOrExpression | lv_condition_9_3= ruleArithmeticalComparationExpression | lv_condition_9_4= ruleComparationExpression ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) ;
    public final EObject ruleDoWhileLoop() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENKEY_1=null;
        Token this_EOLINE_2=null;
        Token this_CLOSEKEY_6=null;
        Token this_OPENPARENTHESIS_7=null;
        Token otherlv_8=null;
        Token this_CLOSEPARENTHESIS_10=null;
        EObject lv_restrictionGas_3_0 = null;

        EObject lv_loops_4_0 = null;

        AntlrDatatypeRuleToken lv_expressions_5_0 = null;

        AntlrDatatypeRuleToken lv_condition_9_1 = null;

        AntlrDatatypeRuleToken lv_condition_9_2 = null;

        AntlrDatatypeRuleToken lv_condition_9_3 = null;

        AntlrDatatypeRuleToken lv_condition_9_4 = null;



        	enterRule();

        try {
            // InternalSM2.g:7870:2: ( (otherlv_0= 'do' this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restrictionGas_3_0= ruleRestrictionGas ) ) ( (lv_loops_4_0= ruleLoops ) )? ( (lv_expressions_5_0= ruleExpression ) ) this_CLOSEKEY_6= RULE_CLOSEKEY this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'while' ( ( (lv_condition_9_1= ruleAndExpression | lv_condition_9_2= ruleOrExpression | lv_condition_9_3= ruleArithmeticalComparationExpression | lv_condition_9_4= ruleComparationExpression ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:7871:2: (otherlv_0= 'do' this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restrictionGas_3_0= ruleRestrictionGas ) ) ( (lv_loops_4_0= ruleLoops ) )? ( (lv_expressions_5_0= ruleExpression ) ) this_CLOSEKEY_6= RULE_CLOSEKEY this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'while' ( ( (lv_condition_9_1= ruleAndExpression | lv_condition_9_2= ruleOrExpression | lv_condition_9_3= ruleArithmeticalComparationExpression | lv_condition_9_4= ruleComparationExpression ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:7871:2: (otherlv_0= 'do' this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restrictionGas_3_0= ruleRestrictionGas ) ) ( (lv_loops_4_0= ruleLoops ) )? ( (lv_expressions_5_0= ruleExpression ) ) this_CLOSEKEY_6= RULE_CLOSEKEY this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'while' ( ( (lv_condition_9_1= ruleAndExpression | lv_condition_9_2= ruleOrExpression | lv_condition_9_3= ruleArithmeticalComparationExpression | lv_condition_9_4= ruleComparationExpression ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:7872:3: otherlv_0= 'do' this_OPENKEY_1= RULE_OPENKEY this_EOLINE_2= RULE_EOLINE ( (lv_restrictionGas_3_0= ruleRestrictionGas ) ) ( (lv_loops_4_0= ruleLoops ) )? ( (lv_expressions_5_0= ruleExpression ) ) this_CLOSEKEY_6= RULE_CLOSEKEY this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'while' ( ( (lv_condition_9_1= ruleAndExpression | lv_condition_9_2= ruleOrExpression | lv_condition_9_3= ruleArithmeticalComparationExpression | lv_condition_9_4= ruleComparationExpression ) ) ) this_CLOSEPARENTHESIS_10= RULE_CLOSEPARENTHESIS
            {
            otherlv_0=(Token)match(input,187,FOLLOW_14); 

            			newLeafNode(otherlv_0, grammarAccess.getDoWhileLoopAccess().getDoKeyword_0());
            		
            this_OPENKEY_1=(Token)match(input,RULE_OPENKEY,FOLLOW_23); 

            			newLeafNode(this_OPENKEY_1, grammarAccess.getDoWhileLoopAccess().getOPENKEYTerminalRuleCall_1());
            		
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_112); 

            			newLeafNode(this_EOLINE_2, grammarAccess.getDoWhileLoopAccess().getEOLINETerminalRuleCall_2());
            		
            // InternalSM2.g:7884:3: ( (lv_restrictionGas_3_0= ruleRestrictionGas ) )
            // InternalSM2.g:7885:4: (lv_restrictionGas_3_0= ruleRestrictionGas )
            {
            // InternalSM2.g:7885:4: (lv_restrictionGas_3_0= ruleRestrictionGas )
            // InternalSM2.g:7886:5: lv_restrictionGas_3_0= ruleRestrictionGas
            {

            					newCompositeNode(grammarAccess.getDoWhileLoopAccess().getRestrictionGasRestrictionGasParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_116);
            lv_restrictionGas_3_0=ruleRestrictionGas();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDoWhileLoopRule());
            					}
            					set(
            						current,
            						"restrictionGas",
            						lv_restrictionGas_3_0,
            						"org.xtext.SM2.RestrictionGas");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:7903:3: ( (lv_loops_4_0= ruleLoops ) )?
            int alt198=2;
            int LA198_0 = input.LA(1);

            if ( ((LA198_0>=184 && LA198_0<=185)||LA198_0==187) ) {
                alt198=1;
            }
            switch (alt198) {
                case 1 :
                    // InternalSM2.g:7904:4: (lv_loops_4_0= ruleLoops )
                    {
                    // InternalSM2.g:7904:4: (lv_loops_4_0= ruleLoops )
                    // InternalSM2.g:7905:5: lv_loops_4_0= ruleLoops
                    {

                    					newCompositeNode(grammarAccess.getDoWhileLoopAccess().getLoopsLoopsParserRuleCall_4_0());
                    				
                    pushFollow(FOLLOW_20);
                    lv_loops_4_0=ruleLoops();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getDoWhileLoopRule());
                    					}
                    					add(
                    						current,
                    						"loops",
                    						lv_loops_4_0,
                    						"org.xtext.SM2.Loops");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:7922:3: ( (lv_expressions_5_0= ruleExpression ) )
            // InternalSM2.g:7923:4: (lv_expressions_5_0= ruleExpression )
            {
            // InternalSM2.g:7923:4: (lv_expressions_5_0= ruleExpression )
            // InternalSM2.g:7924:5: lv_expressions_5_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getDoWhileLoopAccess().getExpressionsExpressionParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_16);
            lv_expressions_5_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDoWhileLoopRule());
            					}
            					add(
            						current,
            						"expressions",
            						lv_expressions_5_0,
            						"org.xtext.SM2.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEKEY_6=(Token)match(input,RULE_CLOSEKEY,FOLLOW_19); 

            			newLeafNode(this_CLOSEKEY_6, grammarAccess.getDoWhileLoopAccess().getCLOSEKEYTerminalRuleCall_6());
            		
            this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_113); 

            			newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getDoWhileLoopAccess().getOPENPARENTHESISTerminalRuleCall_7());
            		
            otherlv_8=(Token)match(input,184,FOLLOW_108); 

            			newLeafNode(otherlv_8, grammarAccess.getDoWhileLoopAccess().getWhileKeyword_8());
            		
            // InternalSM2.g:7953:3: ( ( (lv_condition_9_1= ruleAndExpression | lv_condition_9_2= ruleOrExpression | lv_condition_9_3= ruleArithmeticalComparationExpression | lv_condition_9_4= ruleComparationExpression ) ) )
            // InternalSM2.g:7954:4: ( (lv_condition_9_1= ruleAndExpression | lv_condition_9_2= ruleOrExpression | lv_condition_9_3= ruleArithmeticalComparationExpression | lv_condition_9_4= ruleComparationExpression ) )
            {
            // InternalSM2.g:7954:4: ( (lv_condition_9_1= ruleAndExpression | lv_condition_9_2= ruleOrExpression | lv_condition_9_3= ruleArithmeticalComparationExpression | lv_condition_9_4= ruleComparationExpression ) )
            // InternalSM2.g:7955:5: (lv_condition_9_1= ruleAndExpression | lv_condition_9_2= ruleOrExpression | lv_condition_9_3= ruleArithmeticalComparationExpression | lv_condition_9_4= ruleComparationExpression )
            {
            // InternalSM2.g:7955:5: (lv_condition_9_1= ruleAndExpression | lv_condition_9_2= ruleOrExpression | lv_condition_9_3= ruleArithmeticalComparationExpression | lv_condition_9_4= ruleComparationExpression )
            int alt199=4;
            alt199 = dfa199.predict(input);
            switch (alt199) {
                case 1 :
                    // InternalSM2.g:7956:6: lv_condition_9_1= ruleAndExpression
                    {

                    						newCompositeNode(grammarAccess.getDoWhileLoopAccess().getConditionAndExpressionParserRuleCall_9_0_0());
                    					
                    pushFollow(FOLLOW_21);
                    lv_condition_9_1=ruleAndExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDoWhileLoopRule());
                    						}
                    						set(
                    							current,
                    							"condition",
                    							lv_condition_9_1,
                    							"org.xtext.SM2.AndExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:7972:6: lv_condition_9_2= ruleOrExpression
                    {

                    						newCompositeNode(grammarAccess.getDoWhileLoopAccess().getConditionOrExpressionParserRuleCall_9_0_1());
                    					
                    pushFollow(FOLLOW_21);
                    lv_condition_9_2=ruleOrExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDoWhileLoopRule());
                    						}
                    						set(
                    							current,
                    							"condition",
                    							lv_condition_9_2,
                    							"org.xtext.SM2.OrExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;
                case 3 :
                    // InternalSM2.g:7988:6: lv_condition_9_3= ruleArithmeticalComparationExpression
                    {

                    						newCompositeNode(grammarAccess.getDoWhileLoopAccess().getConditionArithmeticalComparationExpressionParserRuleCall_9_0_2());
                    					
                    pushFollow(FOLLOW_21);
                    lv_condition_9_3=ruleArithmeticalComparationExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDoWhileLoopRule());
                    						}
                    						set(
                    							current,
                    							"condition",
                    							lv_condition_9_3,
                    							"org.xtext.SM2.ArithmeticalComparationExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;
                case 4 :
                    // InternalSM2.g:8004:6: lv_condition_9_4= ruleComparationExpression
                    {

                    						newCompositeNode(grammarAccess.getDoWhileLoopAccess().getConditionComparationExpressionParserRuleCall_9_0_3());
                    					
                    pushFollow(FOLLOW_21);
                    lv_condition_9_4=ruleComparationExpression();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDoWhileLoopRule());
                    						}
                    						set(
                    							current,
                    							"condition",
                    							lv_condition_9_4,
                    							"org.xtext.SM2.ComparationExpression");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;

            }


            }


            }

            this_CLOSEPARENTHESIS_10=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

            			newLeafNode(this_CLOSEPARENTHESIS_10, grammarAccess.getDoWhileLoopAccess().getCLOSEPARENTHESISTerminalRuleCall_10());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDoWhileLoop"


    // $ANTLR start "ruleUINTEGER"
    // InternalSM2.g:8030:1: ruleUINTEGER returns [Enumerator current=null] : ( (enumLiteral_0= 'uint' ) | (enumLiteral_1= 'uint2' ) | (enumLiteral_2= 'uint4' ) | (enumLiteral_3= 'uint8' ) | (enumLiteral_4= 'uint16' ) | (enumLiteral_5= 'uint24' ) | (enumLiteral_6= 'uint32' ) | (enumLiteral_7= 'uint40' ) | (enumLiteral_8= 'uint48' ) | (enumLiteral_9= 'uint56' ) | (enumLiteral_10= 'uint64' ) | (enumLiteral_11= 'uint80' ) | (enumLiteral_12= 'uint88' ) | (enumLiteral_13= 'uint96' ) | (enumLiteral_14= 'uint104' ) | (enumLiteral_15= 'uint128' ) | (enumLiteral_16= 'uint160' ) | (enumLiteral_17= 'uint200' ) | (enumLiteral_18= 'uint256' ) ) ;
    public final Enumerator ruleUINTEGER() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;
        Token enumLiteral_8=null;
        Token enumLiteral_9=null;
        Token enumLiteral_10=null;
        Token enumLiteral_11=null;
        Token enumLiteral_12=null;
        Token enumLiteral_13=null;
        Token enumLiteral_14=null;
        Token enumLiteral_15=null;
        Token enumLiteral_16=null;
        Token enumLiteral_17=null;
        Token enumLiteral_18=null;


        	enterRule();

        try {
            // InternalSM2.g:8036:2: ( ( (enumLiteral_0= 'uint' ) | (enumLiteral_1= 'uint2' ) | (enumLiteral_2= 'uint4' ) | (enumLiteral_3= 'uint8' ) | (enumLiteral_4= 'uint16' ) | (enumLiteral_5= 'uint24' ) | (enumLiteral_6= 'uint32' ) | (enumLiteral_7= 'uint40' ) | (enumLiteral_8= 'uint48' ) | (enumLiteral_9= 'uint56' ) | (enumLiteral_10= 'uint64' ) | (enumLiteral_11= 'uint80' ) | (enumLiteral_12= 'uint88' ) | (enumLiteral_13= 'uint96' ) | (enumLiteral_14= 'uint104' ) | (enumLiteral_15= 'uint128' ) | (enumLiteral_16= 'uint160' ) | (enumLiteral_17= 'uint200' ) | (enumLiteral_18= 'uint256' ) ) )
            // InternalSM2.g:8037:2: ( (enumLiteral_0= 'uint' ) | (enumLiteral_1= 'uint2' ) | (enumLiteral_2= 'uint4' ) | (enumLiteral_3= 'uint8' ) | (enumLiteral_4= 'uint16' ) | (enumLiteral_5= 'uint24' ) | (enumLiteral_6= 'uint32' ) | (enumLiteral_7= 'uint40' ) | (enumLiteral_8= 'uint48' ) | (enumLiteral_9= 'uint56' ) | (enumLiteral_10= 'uint64' ) | (enumLiteral_11= 'uint80' ) | (enumLiteral_12= 'uint88' ) | (enumLiteral_13= 'uint96' ) | (enumLiteral_14= 'uint104' ) | (enumLiteral_15= 'uint128' ) | (enumLiteral_16= 'uint160' ) | (enumLiteral_17= 'uint200' ) | (enumLiteral_18= 'uint256' ) )
            {
            // InternalSM2.g:8037:2: ( (enumLiteral_0= 'uint' ) | (enumLiteral_1= 'uint2' ) | (enumLiteral_2= 'uint4' ) | (enumLiteral_3= 'uint8' ) | (enumLiteral_4= 'uint16' ) | (enumLiteral_5= 'uint24' ) | (enumLiteral_6= 'uint32' ) | (enumLiteral_7= 'uint40' ) | (enumLiteral_8= 'uint48' ) | (enumLiteral_9= 'uint56' ) | (enumLiteral_10= 'uint64' ) | (enumLiteral_11= 'uint80' ) | (enumLiteral_12= 'uint88' ) | (enumLiteral_13= 'uint96' ) | (enumLiteral_14= 'uint104' ) | (enumLiteral_15= 'uint128' ) | (enumLiteral_16= 'uint160' ) | (enumLiteral_17= 'uint200' ) | (enumLiteral_18= 'uint256' ) )
            int alt200=19;
            switch ( input.LA(1) ) {
            case 89:
                {
                alt200=1;
                }
                break;
            case 90:
                {
                alt200=2;
                }
                break;
            case 91:
                {
                alt200=3;
                }
                break;
            case 92:
                {
                alt200=4;
                }
                break;
            case 93:
                {
                alt200=5;
                }
                break;
            case 94:
                {
                alt200=6;
                }
                break;
            case 95:
                {
                alt200=7;
                }
                break;
            case 96:
                {
                alt200=8;
                }
                break;
            case 97:
                {
                alt200=9;
                }
                break;
            case 98:
                {
                alt200=10;
                }
                break;
            case 99:
                {
                alt200=11;
                }
                break;
            case 100:
                {
                alt200=12;
                }
                break;
            case 101:
                {
                alt200=13;
                }
                break;
            case 102:
                {
                alt200=14;
                }
                break;
            case 103:
                {
                alt200=15;
                }
                break;
            case 104:
                {
                alt200=16;
                }
                break;
            case 105:
                {
                alt200=17;
                }
                break;
            case 106:
                {
                alt200=18;
                }
                break;
            case 107:
                {
                alt200=19;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 200, 0, input);

                throw nvae;
            }

            switch (alt200) {
                case 1 :
                    // InternalSM2.g:8038:3: (enumLiteral_0= 'uint' )
                    {
                    // InternalSM2.g:8038:3: (enumLiteral_0= 'uint' )
                    // InternalSM2.g:8039:4: enumLiteral_0= 'uint'
                    {
                    enumLiteral_0=(Token)match(input,89,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getUINTEGERAccess().getUINTEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:8046:3: (enumLiteral_1= 'uint2' )
                    {
                    // InternalSM2.g:8046:3: (enumLiteral_1= 'uint2' )
                    // InternalSM2.g:8047:4: enumLiteral_1= 'uint2'
                    {
                    enumLiteral_1=(Token)match(input,90,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT2EnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getUINTEGERAccess().getUINT2EnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:8054:3: (enumLiteral_2= 'uint4' )
                    {
                    // InternalSM2.g:8054:3: (enumLiteral_2= 'uint4' )
                    // InternalSM2.g:8055:4: enumLiteral_2= 'uint4'
                    {
                    enumLiteral_2=(Token)match(input,91,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT4EnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getUINTEGERAccess().getUINT4EnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:8062:3: (enumLiteral_3= 'uint8' )
                    {
                    // InternalSM2.g:8062:3: (enumLiteral_3= 'uint8' )
                    // InternalSM2.g:8063:4: enumLiteral_3= 'uint8'
                    {
                    enumLiteral_3=(Token)match(input,92,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT8EnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getUINTEGERAccess().getUINT8EnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:8070:3: (enumLiteral_4= 'uint16' )
                    {
                    // InternalSM2.g:8070:3: (enumLiteral_4= 'uint16' )
                    // InternalSM2.g:8071:4: enumLiteral_4= 'uint16'
                    {
                    enumLiteral_4=(Token)match(input,93,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT16EnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getUINTEGERAccess().getUINT16EnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:8078:3: (enumLiteral_5= 'uint24' )
                    {
                    // InternalSM2.g:8078:3: (enumLiteral_5= 'uint24' )
                    // InternalSM2.g:8079:4: enumLiteral_5= 'uint24'
                    {
                    enumLiteral_5=(Token)match(input,94,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT24EnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getUINTEGERAccess().getUINT24EnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:8086:3: (enumLiteral_6= 'uint32' )
                    {
                    // InternalSM2.g:8086:3: (enumLiteral_6= 'uint32' )
                    // InternalSM2.g:8087:4: enumLiteral_6= 'uint32'
                    {
                    enumLiteral_6=(Token)match(input,95,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT32EnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_6, grammarAccess.getUINTEGERAccess().getUINT32EnumLiteralDeclaration_6());
                    			

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:8094:3: (enumLiteral_7= 'uint40' )
                    {
                    // InternalSM2.g:8094:3: (enumLiteral_7= 'uint40' )
                    // InternalSM2.g:8095:4: enumLiteral_7= 'uint40'
                    {
                    enumLiteral_7=(Token)match(input,96,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT40EnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_7, grammarAccess.getUINTEGERAccess().getUINT40EnumLiteralDeclaration_7());
                    			

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:8102:3: (enumLiteral_8= 'uint48' )
                    {
                    // InternalSM2.g:8102:3: (enumLiteral_8= 'uint48' )
                    // InternalSM2.g:8103:4: enumLiteral_8= 'uint48'
                    {
                    enumLiteral_8=(Token)match(input,97,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT48EnumLiteralDeclaration_8().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_8, grammarAccess.getUINTEGERAccess().getUINT48EnumLiteralDeclaration_8());
                    			

                    }


                    }
                    break;
                case 10 :
                    // InternalSM2.g:8110:3: (enumLiteral_9= 'uint56' )
                    {
                    // InternalSM2.g:8110:3: (enumLiteral_9= 'uint56' )
                    // InternalSM2.g:8111:4: enumLiteral_9= 'uint56'
                    {
                    enumLiteral_9=(Token)match(input,98,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT56EnumLiteralDeclaration_9().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_9, grammarAccess.getUINTEGERAccess().getUINT56EnumLiteralDeclaration_9());
                    			

                    }


                    }
                    break;
                case 11 :
                    // InternalSM2.g:8118:3: (enumLiteral_10= 'uint64' )
                    {
                    // InternalSM2.g:8118:3: (enumLiteral_10= 'uint64' )
                    // InternalSM2.g:8119:4: enumLiteral_10= 'uint64'
                    {
                    enumLiteral_10=(Token)match(input,99,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT64EnumLiteralDeclaration_10().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_10, grammarAccess.getUINTEGERAccess().getUINT64EnumLiteralDeclaration_10());
                    			

                    }


                    }
                    break;
                case 12 :
                    // InternalSM2.g:8126:3: (enumLiteral_11= 'uint80' )
                    {
                    // InternalSM2.g:8126:3: (enumLiteral_11= 'uint80' )
                    // InternalSM2.g:8127:4: enumLiteral_11= 'uint80'
                    {
                    enumLiteral_11=(Token)match(input,100,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT80EnumLiteralDeclaration_11().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_11, grammarAccess.getUINTEGERAccess().getUINT80EnumLiteralDeclaration_11());
                    			

                    }


                    }
                    break;
                case 13 :
                    // InternalSM2.g:8134:3: (enumLiteral_12= 'uint88' )
                    {
                    // InternalSM2.g:8134:3: (enumLiteral_12= 'uint88' )
                    // InternalSM2.g:8135:4: enumLiteral_12= 'uint88'
                    {
                    enumLiteral_12=(Token)match(input,101,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT88EnumLiteralDeclaration_12().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_12, grammarAccess.getUINTEGERAccess().getUINT88EnumLiteralDeclaration_12());
                    			

                    }


                    }
                    break;
                case 14 :
                    // InternalSM2.g:8142:3: (enumLiteral_13= 'uint96' )
                    {
                    // InternalSM2.g:8142:3: (enumLiteral_13= 'uint96' )
                    // InternalSM2.g:8143:4: enumLiteral_13= 'uint96'
                    {
                    enumLiteral_13=(Token)match(input,102,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT96EnumLiteralDeclaration_13().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_13, grammarAccess.getUINTEGERAccess().getUINT96EnumLiteralDeclaration_13());
                    			

                    }


                    }
                    break;
                case 15 :
                    // InternalSM2.g:8150:3: (enumLiteral_14= 'uint104' )
                    {
                    // InternalSM2.g:8150:3: (enumLiteral_14= 'uint104' )
                    // InternalSM2.g:8151:4: enumLiteral_14= 'uint104'
                    {
                    enumLiteral_14=(Token)match(input,103,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT104EnumLiteralDeclaration_14().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_14, grammarAccess.getUINTEGERAccess().getUINT104EnumLiteralDeclaration_14());
                    			

                    }


                    }
                    break;
                case 16 :
                    // InternalSM2.g:8158:3: (enumLiteral_15= 'uint128' )
                    {
                    // InternalSM2.g:8158:3: (enumLiteral_15= 'uint128' )
                    // InternalSM2.g:8159:4: enumLiteral_15= 'uint128'
                    {
                    enumLiteral_15=(Token)match(input,104,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT128EnumLiteralDeclaration_15().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_15, grammarAccess.getUINTEGERAccess().getUINT128EnumLiteralDeclaration_15());
                    			

                    }


                    }
                    break;
                case 17 :
                    // InternalSM2.g:8166:3: (enumLiteral_16= 'uint160' )
                    {
                    // InternalSM2.g:8166:3: (enumLiteral_16= 'uint160' )
                    // InternalSM2.g:8167:4: enumLiteral_16= 'uint160'
                    {
                    enumLiteral_16=(Token)match(input,105,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT160EnumLiteralDeclaration_16().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_16, grammarAccess.getUINTEGERAccess().getUINT160EnumLiteralDeclaration_16());
                    			

                    }


                    }
                    break;
                case 18 :
                    // InternalSM2.g:8174:3: (enumLiteral_17= 'uint200' )
                    {
                    // InternalSM2.g:8174:3: (enumLiteral_17= 'uint200' )
                    // InternalSM2.g:8175:4: enumLiteral_17= 'uint200'
                    {
                    enumLiteral_17=(Token)match(input,106,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT200EnumLiteralDeclaration_17().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_17, grammarAccess.getUINTEGERAccess().getUINT200EnumLiteralDeclaration_17());
                    			

                    }


                    }
                    break;
                case 19 :
                    // InternalSM2.g:8182:3: (enumLiteral_18= 'uint256' )
                    {
                    // InternalSM2.g:8182:3: (enumLiteral_18= 'uint256' )
                    // InternalSM2.g:8183:4: enumLiteral_18= 'uint256'
                    {
                    enumLiteral_18=(Token)match(input,107,FOLLOW_2); 

                    				current = grammarAccess.getUINTEGERAccess().getUINT256EnumLiteralDeclaration_18().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_18, grammarAccess.getUINTEGERAccess().getUINT256EnumLiteralDeclaration_18());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUINTEGER"


    // $ANTLR start "ruleINTEGER"
    // InternalSM2.g:8193:1: ruleINTEGER returns [Enumerator current=null] : ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'int2' ) | (enumLiteral_2= 'int4' ) | (enumLiteral_3= 'int8' ) | (enumLiteral_4= 'int16' ) | (enumLiteral_5= 'int24' ) | (enumLiteral_6= 'int32' ) | (enumLiteral_7= 'int40' ) | (enumLiteral_8= 'int48' ) | (enumLiteral_9= 'int56' ) | (enumLiteral_10= 'int64' ) | (enumLiteral_11= 'int80' ) | (enumLiteral_12= 'int88' ) | (enumLiteral_13= 'int96' ) | (enumLiteral_14= 'int104' ) | (enumLiteral_15= 'int128' ) | (enumLiteral_16= 'int160' ) | (enumLiteral_17= 'int200' ) | (enumLiteral_18= 'int256' ) ) ;
    public final Enumerator ruleINTEGER() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;
        Token enumLiteral_8=null;
        Token enumLiteral_9=null;
        Token enumLiteral_10=null;
        Token enumLiteral_11=null;
        Token enumLiteral_12=null;
        Token enumLiteral_13=null;
        Token enumLiteral_14=null;
        Token enumLiteral_15=null;
        Token enumLiteral_16=null;
        Token enumLiteral_17=null;
        Token enumLiteral_18=null;


        	enterRule();

        try {
            // InternalSM2.g:8199:2: ( ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'int2' ) | (enumLiteral_2= 'int4' ) | (enumLiteral_3= 'int8' ) | (enumLiteral_4= 'int16' ) | (enumLiteral_5= 'int24' ) | (enumLiteral_6= 'int32' ) | (enumLiteral_7= 'int40' ) | (enumLiteral_8= 'int48' ) | (enumLiteral_9= 'int56' ) | (enumLiteral_10= 'int64' ) | (enumLiteral_11= 'int80' ) | (enumLiteral_12= 'int88' ) | (enumLiteral_13= 'int96' ) | (enumLiteral_14= 'int104' ) | (enumLiteral_15= 'int128' ) | (enumLiteral_16= 'int160' ) | (enumLiteral_17= 'int200' ) | (enumLiteral_18= 'int256' ) ) )
            // InternalSM2.g:8200:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'int2' ) | (enumLiteral_2= 'int4' ) | (enumLiteral_3= 'int8' ) | (enumLiteral_4= 'int16' ) | (enumLiteral_5= 'int24' ) | (enumLiteral_6= 'int32' ) | (enumLiteral_7= 'int40' ) | (enumLiteral_8= 'int48' ) | (enumLiteral_9= 'int56' ) | (enumLiteral_10= 'int64' ) | (enumLiteral_11= 'int80' ) | (enumLiteral_12= 'int88' ) | (enumLiteral_13= 'int96' ) | (enumLiteral_14= 'int104' ) | (enumLiteral_15= 'int128' ) | (enumLiteral_16= 'int160' ) | (enumLiteral_17= 'int200' ) | (enumLiteral_18= 'int256' ) )
            {
            // InternalSM2.g:8200:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'int2' ) | (enumLiteral_2= 'int4' ) | (enumLiteral_3= 'int8' ) | (enumLiteral_4= 'int16' ) | (enumLiteral_5= 'int24' ) | (enumLiteral_6= 'int32' ) | (enumLiteral_7= 'int40' ) | (enumLiteral_8= 'int48' ) | (enumLiteral_9= 'int56' ) | (enumLiteral_10= 'int64' ) | (enumLiteral_11= 'int80' ) | (enumLiteral_12= 'int88' ) | (enumLiteral_13= 'int96' ) | (enumLiteral_14= 'int104' ) | (enumLiteral_15= 'int128' ) | (enumLiteral_16= 'int160' ) | (enumLiteral_17= 'int200' ) | (enumLiteral_18= 'int256' ) )
            int alt201=19;
            switch ( input.LA(1) ) {
            case 108:
                {
                alt201=1;
                }
                break;
            case 109:
                {
                alt201=2;
                }
                break;
            case 110:
                {
                alt201=3;
                }
                break;
            case 111:
                {
                alt201=4;
                }
                break;
            case 112:
                {
                alt201=5;
                }
                break;
            case 113:
                {
                alt201=6;
                }
                break;
            case 114:
                {
                alt201=7;
                }
                break;
            case 115:
                {
                alt201=8;
                }
                break;
            case 116:
                {
                alt201=9;
                }
                break;
            case 117:
                {
                alt201=10;
                }
                break;
            case 118:
                {
                alt201=11;
                }
                break;
            case 119:
                {
                alt201=12;
                }
                break;
            case 120:
                {
                alt201=13;
                }
                break;
            case 121:
                {
                alt201=14;
                }
                break;
            case 122:
                {
                alt201=15;
                }
                break;
            case 123:
                {
                alt201=16;
                }
                break;
            case 124:
                {
                alt201=17;
                }
                break;
            case 125:
                {
                alt201=18;
                }
                break;
            case 126:
                {
                alt201=19;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 201, 0, input);

                throw nvae;
            }

            switch (alt201) {
                case 1 :
                    // InternalSM2.g:8201:3: (enumLiteral_0= 'int' )
                    {
                    // InternalSM2.g:8201:3: (enumLiteral_0= 'int' )
                    // InternalSM2.g:8202:4: enumLiteral_0= 'int'
                    {
                    enumLiteral_0=(Token)match(input,108,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getINTEGERAccess().getINTEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:8209:3: (enumLiteral_1= 'int2' )
                    {
                    // InternalSM2.g:8209:3: (enumLiteral_1= 'int2' )
                    // InternalSM2.g:8210:4: enumLiteral_1= 'int2'
                    {
                    enumLiteral_1=(Token)match(input,109,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT2EnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getINTEGERAccess().getINT2EnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:8217:3: (enumLiteral_2= 'int4' )
                    {
                    // InternalSM2.g:8217:3: (enumLiteral_2= 'int4' )
                    // InternalSM2.g:8218:4: enumLiteral_2= 'int4'
                    {
                    enumLiteral_2=(Token)match(input,110,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT4EnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getINTEGERAccess().getINT4EnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:8225:3: (enumLiteral_3= 'int8' )
                    {
                    // InternalSM2.g:8225:3: (enumLiteral_3= 'int8' )
                    // InternalSM2.g:8226:4: enumLiteral_3= 'int8'
                    {
                    enumLiteral_3=(Token)match(input,111,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT8EnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getINTEGERAccess().getINT8EnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:8233:3: (enumLiteral_4= 'int16' )
                    {
                    // InternalSM2.g:8233:3: (enumLiteral_4= 'int16' )
                    // InternalSM2.g:8234:4: enumLiteral_4= 'int16'
                    {
                    enumLiteral_4=(Token)match(input,112,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT16EnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getINTEGERAccess().getINT16EnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:8241:3: (enumLiteral_5= 'int24' )
                    {
                    // InternalSM2.g:8241:3: (enumLiteral_5= 'int24' )
                    // InternalSM2.g:8242:4: enumLiteral_5= 'int24'
                    {
                    enumLiteral_5=(Token)match(input,113,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT24EnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getINTEGERAccess().getINT24EnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:8249:3: (enumLiteral_6= 'int32' )
                    {
                    // InternalSM2.g:8249:3: (enumLiteral_6= 'int32' )
                    // InternalSM2.g:8250:4: enumLiteral_6= 'int32'
                    {
                    enumLiteral_6=(Token)match(input,114,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT32EnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_6, grammarAccess.getINTEGERAccess().getINT32EnumLiteralDeclaration_6());
                    			

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:8257:3: (enumLiteral_7= 'int40' )
                    {
                    // InternalSM2.g:8257:3: (enumLiteral_7= 'int40' )
                    // InternalSM2.g:8258:4: enumLiteral_7= 'int40'
                    {
                    enumLiteral_7=(Token)match(input,115,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT40EnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_7, grammarAccess.getINTEGERAccess().getINT40EnumLiteralDeclaration_7());
                    			

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:8265:3: (enumLiteral_8= 'int48' )
                    {
                    // InternalSM2.g:8265:3: (enumLiteral_8= 'int48' )
                    // InternalSM2.g:8266:4: enumLiteral_8= 'int48'
                    {
                    enumLiteral_8=(Token)match(input,116,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT48EnumLiteralDeclaration_8().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_8, grammarAccess.getINTEGERAccess().getINT48EnumLiteralDeclaration_8());
                    			

                    }


                    }
                    break;
                case 10 :
                    // InternalSM2.g:8273:3: (enumLiteral_9= 'int56' )
                    {
                    // InternalSM2.g:8273:3: (enumLiteral_9= 'int56' )
                    // InternalSM2.g:8274:4: enumLiteral_9= 'int56'
                    {
                    enumLiteral_9=(Token)match(input,117,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT56EnumLiteralDeclaration_9().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_9, grammarAccess.getINTEGERAccess().getINT56EnumLiteralDeclaration_9());
                    			

                    }


                    }
                    break;
                case 11 :
                    // InternalSM2.g:8281:3: (enumLiteral_10= 'int64' )
                    {
                    // InternalSM2.g:8281:3: (enumLiteral_10= 'int64' )
                    // InternalSM2.g:8282:4: enumLiteral_10= 'int64'
                    {
                    enumLiteral_10=(Token)match(input,118,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT64EnumLiteralDeclaration_10().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_10, grammarAccess.getINTEGERAccess().getINT64EnumLiteralDeclaration_10());
                    			

                    }


                    }
                    break;
                case 12 :
                    // InternalSM2.g:8289:3: (enumLiteral_11= 'int80' )
                    {
                    // InternalSM2.g:8289:3: (enumLiteral_11= 'int80' )
                    // InternalSM2.g:8290:4: enumLiteral_11= 'int80'
                    {
                    enumLiteral_11=(Token)match(input,119,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT80EnumLiteralDeclaration_11().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_11, grammarAccess.getINTEGERAccess().getINT80EnumLiteralDeclaration_11());
                    			

                    }


                    }
                    break;
                case 13 :
                    // InternalSM2.g:8297:3: (enumLiteral_12= 'int88' )
                    {
                    // InternalSM2.g:8297:3: (enumLiteral_12= 'int88' )
                    // InternalSM2.g:8298:4: enumLiteral_12= 'int88'
                    {
                    enumLiteral_12=(Token)match(input,120,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT88EnumLiteralDeclaration_12().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_12, grammarAccess.getINTEGERAccess().getINT88EnumLiteralDeclaration_12());
                    			

                    }


                    }
                    break;
                case 14 :
                    // InternalSM2.g:8305:3: (enumLiteral_13= 'int96' )
                    {
                    // InternalSM2.g:8305:3: (enumLiteral_13= 'int96' )
                    // InternalSM2.g:8306:4: enumLiteral_13= 'int96'
                    {
                    enumLiteral_13=(Token)match(input,121,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT96EnumLiteralDeclaration_13().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_13, grammarAccess.getINTEGERAccess().getINT96EnumLiteralDeclaration_13());
                    			

                    }


                    }
                    break;
                case 15 :
                    // InternalSM2.g:8313:3: (enumLiteral_14= 'int104' )
                    {
                    // InternalSM2.g:8313:3: (enumLiteral_14= 'int104' )
                    // InternalSM2.g:8314:4: enumLiteral_14= 'int104'
                    {
                    enumLiteral_14=(Token)match(input,122,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT104EnumLiteralDeclaration_14().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_14, grammarAccess.getINTEGERAccess().getINT104EnumLiteralDeclaration_14());
                    			

                    }


                    }
                    break;
                case 16 :
                    // InternalSM2.g:8321:3: (enumLiteral_15= 'int128' )
                    {
                    // InternalSM2.g:8321:3: (enumLiteral_15= 'int128' )
                    // InternalSM2.g:8322:4: enumLiteral_15= 'int128'
                    {
                    enumLiteral_15=(Token)match(input,123,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT128EnumLiteralDeclaration_15().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_15, grammarAccess.getINTEGERAccess().getINT128EnumLiteralDeclaration_15());
                    			

                    }


                    }
                    break;
                case 17 :
                    // InternalSM2.g:8329:3: (enumLiteral_16= 'int160' )
                    {
                    // InternalSM2.g:8329:3: (enumLiteral_16= 'int160' )
                    // InternalSM2.g:8330:4: enumLiteral_16= 'int160'
                    {
                    enumLiteral_16=(Token)match(input,124,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT160EnumLiteralDeclaration_16().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_16, grammarAccess.getINTEGERAccess().getINT160EnumLiteralDeclaration_16());
                    			

                    }


                    }
                    break;
                case 18 :
                    // InternalSM2.g:8337:3: (enumLiteral_17= 'int200' )
                    {
                    // InternalSM2.g:8337:3: (enumLiteral_17= 'int200' )
                    // InternalSM2.g:8338:4: enumLiteral_17= 'int200'
                    {
                    enumLiteral_17=(Token)match(input,125,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT200EnumLiteralDeclaration_17().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_17, grammarAccess.getINTEGERAccess().getINT200EnumLiteralDeclaration_17());
                    			

                    }


                    }
                    break;
                case 19 :
                    // InternalSM2.g:8345:3: (enumLiteral_18= 'int256' )
                    {
                    // InternalSM2.g:8345:3: (enumLiteral_18= 'int256' )
                    // InternalSM2.g:8346:4: enumLiteral_18= 'int256'
                    {
                    enumLiteral_18=(Token)match(input,126,FOLLOW_2); 

                    				current = grammarAccess.getINTEGERAccess().getINT256EnumLiteralDeclaration_18().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_18, grammarAccess.getINTEGERAccess().getINT256EnumLiteralDeclaration_18());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleINTEGER"


    // $ANTLR start "ruleBYTES"
    // InternalSM2.g:8356:1: ruleBYTES returns [Enumerator current=null] : ( (enumLiteral_0= 'bytes' ) | (enumLiteral_1= 'bytes2' ) | (enumLiteral_2= 'bytes3' ) | (enumLiteral_3= 'bytes4' ) | (enumLiteral_4= 'bytes5' ) | (enumLiteral_5= 'bytes6' ) | (enumLiteral_6= 'bytes7' ) | (enumLiteral_7= 'bytes8' ) | (enumLiteral_8= 'bytes10' ) | (enumLiteral_9= 'bytes12' ) | (enumLiteral_10= 'bytes14' ) | (enumLiteral_11= 'bytes16' ) | (enumLiteral_12= 'bytes18' ) | (enumLiteral_13= 'bytes20' ) | (enumLiteral_14= 'bytes24' ) | (enumLiteral_15= 'bytes28' ) | (enumLiteral_16= 'bytes30' ) | (enumLiteral_17= 'bytes32' ) ) ;
    public final Enumerator ruleBYTES() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;
        Token enumLiteral_8=null;
        Token enumLiteral_9=null;
        Token enumLiteral_10=null;
        Token enumLiteral_11=null;
        Token enumLiteral_12=null;
        Token enumLiteral_13=null;
        Token enumLiteral_14=null;
        Token enumLiteral_15=null;
        Token enumLiteral_16=null;
        Token enumLiteral_17=null;


        	enterRule();

        try {
            // InternalSM2.g:8362:2: ( ( (enumLiteral_0= 'bytes' ) | (enumLiteral_1= 'bytes2' ) | (enumLiteral_2= 'bytes3' ) | (enumLiteral_3= 'bytes4' ) | (enumLiteral_4= 'bytes5' ) | (enumLiteral_5= 'bytes6' ) | (enumLiteral_6= 'bytes7' ) | (enumLiteral_7= 'bytes8' ) | (enumLiteral_8= 'bytes10' ) | (enumLiteral_9= 'bytes12' ) | (enumLiteral_10= 'bytes14' ) | (enumLiteral_11= 'bytes16' ) | (enumLiteral_12= 'bytes18' ) | (enumLiteral_13= 'bytes20' ) | (enumLiteral_14= 'bytes24' ) | (enumLiteral_15= 'bytes28' ) | (enumLiteral_16= 'bytes30' ) | (enumLiteral_17= 'bytes32' ) ) )
            // InternalSM2.g:8363:2: ( (enumLiteral_0= 'bytes' ) | (enumLiteral_1= 'bytes2' ) | (enumLiteral_2= 'bytes3' ) | (enumLiteral_3= 'bytes4' ) | (enumLiteral_4= 'bytes5' ) | (enumLiteral_5= 'bytes6' ) | (enumLiteral_6= 'bytes7' ) | (enumLiteral_7= 'bytes8' ) | (enumLiteral_8= 'bytes10' ) | (enumLiteral_9= 'bytes12' ) | (enumLiteral_10= 'bytes14' ) | (enumLiteral_11= 'bytes16' ) | (enumLiteral_12= 'bytes18' ) | (enumLiteral_13= 'bytes20' ) | (enumLiteral_14= 'bytes24' ) | (enumLiteral_15= 'bytes28' ) | (enumLiteral_16= 'bytes30' ) | (enumLiteral_17= 'bytes32' ) )
            {
            // InternalSM2.g:8363:2: ( (enumLiteral_0= 'bytes' ) | (enumLiteral_1= 'bytes2' ) | (enumLiteral_2= 'bytes3' ) | (enumLiteral_3= 'bytes4' ) | (enumLiteral_4= 'bytes5' ) | (enumLiteral_5= 'bytes6' ) | (enumLiteral_6= 'bytes7' ) | (enumLiteral_7= 'bytes8' ) | (enumLiteral_8= 'bytes10' ) | (enumLiteral_9= 'bytes12' ) | (enumLiteral_10= 'bytes14' ) | (enumLiteral_11= 'bytes16' ) | (enumLiteral_12= 'bytes18' ) | (enumLiteral_13= 'bytes20' ) | (enumLiteral_14= 'bytes24' ) | (enumLiteral_15= 'bytes28' ) | (enumLiteral_16= 'bytes30' ) | (enumLiteral_17= 'bytes32' ) )
            int alt202=18;
            switch ( input.LA(1) ) {
            case 127:
                {
                alt202=1;
                }
                break;
            case 128:
                {
                alt202=2;
                }
                break;
            case 129:
                {
                alt202=3;
                }
                break;
            case 130:
                {
                alt202=4;
                }
                break;
            case 131:
                {
                alt202=5;
                }
                break;
            case 132:
                {
                alt202=6;
                }
                break;
            case 133:
                {
                alt202=7;
                }
                break;
            case 134:
                {
                alt202=8;
                }
                break;
            case 135:
                {
                alt202=9;
                }
                break;
            case 136:
                {
                alt202=10;
                }
                break;
            case 137:
                {
                alt202=11;
                }
                break;
            case 138:
                {
                alt202=12;
                }
                break;
            case 139:
                {
                alt202=13;
                }
                break;
            case 140:
                {
                alt202=14;
                }
                break;
            case 141:
                {
                alt202=15;
                }
                break;
            case 142:
                {
                alt202=16;
                }
                break;
            case 143:
                {
                alt202=17;
                }
                break;
            case 144:
                {
                alt202=18;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 202, 0, input);

                throw nvae;
            }

            switch (alt202) {
                case 1 :
                    // InternalSM2.g:8364:3: (enumLiteral_0= 'bytes' )
                    {
                    // InternalSM2.g:8364:3: (enumLiteral_0= 'bytes' )
                    // InternalSM2.g:8365:4: enumLiteral_0= 'bytes'
                    {
                    enumLiteral_0=(Token)match(input,127,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTESEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getBYTESAccess().getBYTESEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:8372:3: (enumLiteral_1= 'bytes2' )
                    {
                    // InternalSM2.g:8372:3: (enumLiteral_1= 'bytes2' )
                    // InternalSM2.g:8373:4: enumLiteral_1= 'bytes2'
                    {
                    enumLiteral_1=(Token)match(input,128,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES2EnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getBYTESAccess().getBYTES2EnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:8380:3: (enumLiteral_2= 'bytes3' )
                    {
                    // InternalSM2.g:8380:3: (enumLiteral_2= 'bytes3' )
                    // InternalSM2.g:8381:4: enumLiteral_2= 'bytes3'
                    {
                    enumLiteral_2=(Token)match(input,129,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES3EnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getBYTESAccess().getBYTES3EnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:8388:3: (enumLiteral_3= 'bytes4' )
                    {
                    // InternalSM2.g:8388:3: (enumLiteral_3= 'bytes4' )
                    // InternalSM2.g:8389:4: enumLiteral_3= 'bytes4'
                    {
                    enumLiteral_3=(Token)match(input,130,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES4EnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getBYTESAccess().getBYTES4EnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:8396:3: (enumLiteral_4= 'bytes5' )
                    {
                    // InternalSM2.g:8396:3: (enumLiteral_4= 'bytes5' )
                    // InternalSM2.g:8397:4: enumLiteral_4= 'bytes5'
                    {
                    enumLiteral_4=(Token)match(input,131,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES5EnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getBYTESAccess().getBYTES5EnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:8404:3: (enumLiteral_5= 'bytes6' )
                    {
                    // InternalSM2.g:8404:3: (enumLiteral_5= 'bytes6' )
                    // InternalSM2.g:8405:4: enumLiteral_5= 'bytes6'
                    {
                    enumLiteral_5=(Token)match(input,132,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES6EnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getBYTESAccess().getBYTES6EnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:8412:3: (enumLiteral_6= 'bytes7' )
                    {
                    // InternalSM2.g:8412:3: (enumLiteral_6= 'bytes7' )
                    // InternalSM2.g:8413:4: enumLiteral_6= 'bytes7'
                    {
                    enumLiteral_6=(Token)match(input,133,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES7EnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_6, grammarAccess.getBYTESAccess().getBYTES7EnumLiteralDeclaration_6());
                    			

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:8420:3: (enumLiteral_7= 'bytes8' )
                    {
                    // InternalSM2.g:8420:3: (enumLiteral_7= 'bytes8' )
                    // InternalSM2.g:8421:4: enumLiteral_7= 'bytes8'
                    {
                    enumLiteral_7=(Token)match(input,134,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES8EnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_7, grammarAccess.getBYTESAccess().getBYTES8EnumLiteralDeclaration_7());
                    			

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:8428:3: (enumLiteral_8= 'bytes10' )
                    {
                    // InternalSM2.g:8428:3: (enumLiteral_8= 'bytes10' )
                    // InternalSM2.g:8429:4: enumLiteral_8= 'bytes10'
                    {
                    enumLiteral_8=(Token)match(input,135,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES10EnumLiteralDeclaration_8().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_8, grammarAccess.getBYTESAccess().getBYTES10EnumLiteralDeclaration_8());
                    			

                    }


                    }
                    break;
                case 10 :
                    // InternalSM2.g:8436:3: (enumLiteral_9= 'bytes12' )
                    {
                    // InternalSM2.g:8436:3: (enumLiteral_9= 'bytes12' )
                    // InternalSM2.g:8437:4: enumLiteral_9= 'bytes12'
                    {
                    enumLiteral_9=(Token)match(input,136,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES12EnumLiteralDeclaration_9().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_9, grammarAccess.getBYTESAccess().getBYTES12EnumLiteralDeclaration_9());
                    			

                    }


                    }
                    break;
                case 11 :
                    // InternalSM2.g:8444:3: (enumLiteral_10= 'bytes14' )
                    {
                    // InternalSM2.g:8444:3: (enumLiteral_10= 'bytes14' )
                    // InternalSM2.g:8445:4: enumLiteral_10= 'bytes14'
                    {
                    enumLiteral_10=(Token)match(input,137,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES14EnumLiteralDeclaration_10().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_10, grammarAccess.getBYTESAccess().getBYTES14EnumLiteralDeclaration_10());
                    			

                    }


                    }
                    break;
                case 12 :
                    // InternalSM2.g:8452:3: (enumLiteral_11= 'bytes16' )
                    {
                    // InternalSM2.g:8452:3: (enumLiteral_11= 'bytes16' )
                    // InternalSM2.g:8453:4: enumLiteral_11= 'bytes16'
                    {
                    enumLiteral_11=(Token)match(input,138,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES16EnumLiteralDeclaration_11().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_11, grammarAccess.getBYTESAccess().getBYTES16EnumLiteralDeclaration_11());
                    			

                    }


                    }
                    break;
                case 13 :
                    // InternalSM2.g:8460:3: (enumLiteral_12= 'bytes18' )
                    {
                    // InternalSM2.g:8460:3: (enumLiteral_12= 'bytes18' )
                    // InternalSM2.g:8461:4: enumLiteral_12= 'bytes18'
                    {
                    enumLiteral_12=(Token)match(input,139,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES18EnumLiteralDeclaration_12().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_12, grammarAccess.getBYTESAccess().getBYTES18EnumLiteralDeclaration_12());
                    			

                    }


                    }
                    break;
                case 14 :
                    // InternalSM2.g:8468:3: (enumLiteral_13= 'bytes20' )
                    {
                    // InternalSM2.g:8468:3: (enumLiteral_13= 'bytes20' )
                    // InternalSM2.g:8469:4: enumLiteral_13= 'bytes20'
                    {
                    enumLiteral_13=(Token)match(input,140,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES20EnumLiteralDeclaration_13().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_13, grammarAccess.getBYTESAccess().getBYTES20EnumLiteralDeclaration_13());
                    			

                    }


                    }
                    break;
                case 15 :
                    // InternalSM2.g:8476:3: (enumLiteral_14= 'bytes24' )
                    {
                    // InternalSM2.g:8476:3: (enumLiteral_14= 'bytes24' )
                    // InternalSM2.g:8477:4: enumLiteral_14= 'bytes24'
                    {
                    enumLiteral_14=(Token)match(input,141,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES24EnumLiteralDeclaration_14().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_14, grammarAccess.getBYTESAccess().getBYTES24EnumLiteralDeclaration_14());
                    			

                    }


                    }
                    break;
                case 16 :
                    // InternalSM2.g:8484:3: (enumLiteral_15= 'bytes28' )
                    {
                    // InternalSM2.g:8484:3: (enumLiteral_15= 'bytes28' )
                    // InternalSM2.g:8485:4: enumLiteral_15= 'bytes28'
                    {
                    enumLiteral_15=(Token)match(input,142,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES28EnumLiteralDeclaration_15().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_15, grammarAccess.getBYTESAccess().getBYTES28EnumLiteralDeclaration_15());
                    			

                    }


                    }
                    break;
                case 17 :
                    // InternalSM2.g:8492:3: (enumLiteral_16= 'bytes30' )
                    {
                    // InternalSM2.g:8492:3: (enumLiteral_16= 'bytes30' )
                    // InternalSM2.g:8493:4: enumLiteral_16= 'bytes30'
                    {
                    enumLiteral_16=(Token)match(input,143,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES30EnumLiteralDeclaration_16().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_16, grammarAccess.getBYTESAccess().getBYTES30EnumLiteralDeclaration_16());
                    			

                    }


                    }
                    break;
                case 18 :
                    // InternalSM2.g:8500:3: (enumLiteral_17= 'bytes32' )
                    {
                    // InternalSM2.g:8500:3: (enumLiteral_17= 'bytes32' )
                    // InternalSM2.g:8501:4: enumLiteral_17= 'bytes32'
                    {
                    enumLiteral_17=(Token)match(input,144,FOLLOW_2); 

                    				current = grammarAccess.getBYTESAccess().getBYTES32EnumLiteralDeclaration_17().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_17, grammarAccess.getBYTESAccess().getBYTES32EnumLiteralDeclaration_17());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBYTES"


    // $ANTLR start "ruleInputModifier"
    // InternalSM2.g:8511:1: ruleInputModifier returns [Enumerator current=null] : ( (enumLiteral_0= 'view' ) | (enumLiteral_1= 'pure' ) | (enumLiteral_2= 'payable' ) ) ;
    public final Enumerator ruleInputModifier() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalSM2.g:8517:2: ( ( (enumLiteral_0= 'view' ) | (enumLiteral_1= 'pure' ) | (enumLiteral_2= 'payable' ) ) )
            // InternalSM2.g:8518:2: ( (enumLiteral_0= 'view' ) | (enumLiteral_1= 'pure' ) | (enumLiteral_2= 'payable' ) )
            {
            // InternalSM2.g:8518:2: ( (enumLiteral_0= 'view' ) | (enumLiteral_1= 'pure' ) | (enumLiteral_2= 'payable' ) )
            int alt203=3;
            switch ( input.LA(1) ) {
            case 188:
                {
                alt203=1;
                }
                break;
            case 189:
                {
                alt203=2;
                }
                break;
            case 190:
                {
                alt203=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 203, 0, input);

                throw nvae;
            }

            switch (alt203) {
                case 1 :
                    // InternalSM2.g:8519:3: (enumLiteral_0= 'view' )
                    {
                    // InternalSM2.g:8519:3: (enumLiteral_0= 'view' )
                    // InternalSM2.g:8520:4: enumLiteral_0= 'view'
                    {
                    enumLiteral_0=(Token)match(input,188,FOLLOW_2); 

                    				current = grammarAccess.getInputModifierAccess().getVIEWEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getInputModifierAccess().getVIEWEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:8527:3: (enumLiteral_1= 'pure' )
                    {
                    // InternalSM2.g:8527:3: (enumLiteral_1= 'pure' )
                    // InternalSM2.g:8528:4: enumLiteral_1= 'pure'
                    {
                    enumLiteral_1=(Token)match(input,189,FOLLOW_2); 

                    				current = grammarAccess.getInputModifierAccess().getPUREEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getInputModifierAccess().getPUREEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:8535:3: (enumLiteral_2= 'payable' )
                    {
                    // InternalSM2.g:8535:3: (enumLiteral_2= 'payable' )
                    // InternalSM2.g:8536:4: enumLiteral_2= 'payable'
                    {
                    enumLiteral_2=(Token)match(input,190,FOLLOW_2); 

                    				current = grammarAccess.getInputModifierAccess().getPAYABLEEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getInputModifierAccess().getPAYABLEEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputModifier"


    // $ANTLR start "ruleStorageData"
    // InternalSM2.g:8546:1: ruleStorageData returns [Enumerator current=null] : ( (enumLiteral_0= 'memory' ) | (enumLiteral_1= 'storage' ) ) ;
    public final Enumerator ruleStorageData() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSM2.g:8552:2: ( ( (enumLiteral_0= 'memory' ) | (enumLiteral_1= 'storage' ) ) )
            // InternalSM2.g:8553:2: ( (enumLiteral_0= 'memory' ) | (enumLiteral_1= 'storage' ) )
            {
            // InternalSM2.g:8553:2: ( (enumLiteral_0= 'memory' ) | (enumLiteral_1= 'storage' ) )
            int alt204=2;
            int LA204_0 = input.LA(1);

            if ( (LA204_0==191) ) {
                alt204=1;
            }
            else if ( (LA204_0==192) ) {
                alt204=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 204, 0, input);

                throw nvae;
            }
            switch (alt204) {
                case 1 :
                    // InternalSM2.g:8554:3: (enumLiteral_0= 'memory' )
                    {
                    // InternalSM2.g:8554:3: (enumLiteral_0= 'memory' )
                    // InternalSM2.g:8555:4: enumLiteral_0= 'memory'
                    {
                    enumLiteral_0=(Token)match(input,191,FOLLOW_2); 

                    				current = grammarAccess.getStorageDataAccess().getMEMORYEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getStorageDataAccess().getMEMORYEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:8562:3: (enumLiteral_1= 'storage' )
                    {
                    // InternalSM2.g:8562:3: (enumLiteral_1= 'storage' )
                    // InternalSM2.g:8563:4: enumLiteral_1= 'storage'
                    {
                    enumLiteral_1=(Token)match(input,192,FOLLOW_2); 

                    				current = grammarAccess.getStorageDataAccess().getSTORAGEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getStorageDataAccess().getSTORAGEEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStorageData"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:8573:1: ruleVisibility returns [Enumerator current=null] : ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) ) ;
    public final Enumerator ruleVisibility() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalSM2.g:8579:2: ( ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) ) )
            // InternalSM2.g:8580:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) )
            {
            // InternalSM2.g:8580:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) )
            int alt205=3;
            switch ( input.LA(1) ) {
            case 74:
                {
                alt205=1;
                }
                break;
            case 193:
                {
                alt205=2;
                }
                break;
            case 75:
                {
                alt205=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 205, 0, input);

                throw nvae;
            }

            switch (alt205) {
                case 1 :
                    // InternalSM2.g:8581:3: (enumLiteral_0= 'public' )
                    {
                    // InternalSM2.g:8581:3: (enumLiteral_0= 'public' )
                    // InternalSM2.g:8582:4: enumLiteral_0= 'public'
                    {
                    enumLiteral_0=(Token)match(input,74,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:8589:3: (enumLiteral_1= 'private' )
                    {
                    // InternalSM2.g:8589:3: (enumLiteral_1= 'private' )
                    // InternalSM2.g:8590:4: enumLiteral_1= 'private'
                    {
                    enumLiteral_1=(Token)match(input,193,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:8597:3: (enumLiteral_2= 'internal' )
                    {
                    // InternalSM2.g:8597:3: (enumLiteral_2= 'internal' )
                    // InternalSM2.g:8598:4: enumLiteral_2= 'internal'
                    {
                    enumLiteral_2=(Token)match(input,75,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:8608:1: ruleCoin returns [Enumerator current=null] : ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) ;
    public final Enumerator ruleCoin() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:8614:2: ( ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) )
            // InternalSM2.g:8615:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            {
            // InternalSM2.g:8615:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            int alt206=6;
            switch ( input.LA(1) ) {
            case 194:
                {
                alt206=1;
                }
                break;
            case 195:
                {
                alt206=2;
                }
                break;
            case 196:
                {
                alt206=3;
                }
                break;
            case 197:
                {
                alt206=4;
                }
                break;
            case 198:
                {
                alt206=5;
                }
                break;
            case 199:
                {
                alt206=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 206, 0, input);

                throw nvae;
            }

            switch (alt206) {
                case 1 :
                    // InternalSM2.g:8616:3: (enumLiteral_0= 'ether' )
                    {
                    // InternalSM2.g:8616:3: (enumLiteral_0= 'ether' )
                    // InternalSM2.g:8617:4: enumLiteral_0= 'ether'
                    {
                    enumLiteral_0=(Token)match(input,194,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:8624:3: (enumLiteral_1= 'wei' )
                    {
                    // InternalSM2.g:8624:3: (enumLiteral_1= 'wei' )
                    // InternalSM2.g:8625:4: enumLiteral_1= 'wei'
                    {
                    enumLiteral_1=(Token)match(input,195,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:8632:3: (enumLiteral_2= 'gwei' )
                    {
                    // InternalSM2.g:8632:3: (enumLiteral_2= 'gwei' )
                    // InternalSM2.g:8633:4: enumLiteral_2= 'gwei'
                    {
                    enumLiteral_2=(Token)match(input,196,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:8640:3: (enumLiteral_3= 'pwei' )
                    {
                    // InternalSM2.g:8640:3: (enumLiteral_3= 'pwei' )
                    // InternalSM2.g:8641:4: enumLiteral_3= 'pwei'
                    {
                    enumLiteral_3=(Token)match(input,197,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:8648:3: (enumLiteral_4= 'finney' )
                    {
                    // InternalSM2.g:8648:3: (enumLiteral_4= 'finney' )
                    // InternalSM2.g:8649:4: enumLiteral_4= 'finney'
                    {
                    enumLiteral_4=(Token)match(input,198,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:8656:3: (enumLiteral_5= 'szabo' )
                    {
                    // InternalSM2.g:8656:3: (enumLiteral_5= 'szabo' )
                    // InternalSM2.g:8657:4: enumLiteral_5= 'szabo'
                    {
                    enumLiteral_5=(Token)match(input,199,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:8667:1: ruleComparationOperator returns [Enumerator current=null] : ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) ;
    public final Enumerator ruleComparationOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:8673:2: ( ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) )
            // InternalSM2.g:8674:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            {
            // InternalSM2.g:8674:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            int alt207=6;
            switch ( input.LA(1) ) {
            case 45:
                {
                alt207=1;
                }
                break;
            case 173:
                {
                alt207=2;
                }
                break;
            case 46:
                {
                alt207=3;
                }
                break;
            case 174:
                {
                alt207=4;
                }
                break;
            case 171:
                {
                alt207=5;
                }
                break;
            case 172:
                {
                alt207=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 207, 0, input);

                throw nvae;
            }

            switch (alt207) {
                case 1 :
                    // InternalSM2.g:8675:3: (enumLiteral_0= '>' )
                    {
                    // InternalSM2.g:8675:3: (enumLiteral_0= '>' )
                    // InternalSM2.g:8676:4: enumLiteral_0= '>'
                    {
                    enumLiteral_0=(Token)match(input,45,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:8683:3: (enumLiteral_1= '<' )
                    {
                    // InternalSM2.g:8683:3: (enumLiteral_1= '<' )
                    // InternalSM2.g:8684:4: enumLiteral_1= '<'
                    {
                    enumLiteral_1=(Token)match(input,173,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:8691:3: (enumLiteral_2= '>=' )
                    {
                    // InternalSM2.g:8691:3: (enumLiteral_2= '>=' )
                    // InternalSM2.g:8692:4: enumLiteral_2= '>='
                    {
                    enumLiteral_2=(Token)match(input,46,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:8699:3: (enumLiteral_3= '<=' )
                    {
                    // InternalSM2.g:8699:3: (enumLiteral_3= '<=' )
                    // InternalSM2.g:8700:4: enumLiteral_3= '<='
                    {
                    enumLiteral_3=(Token)match(input,174,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:8707:3: (enumLiteral_4= '==' )
                    {
                    // InternalSM2.g:8707:3: (enumLiteral_4= '==' )
                    // InternalSM2.g:8708:4: enumLiteral_4= '=='
                    {
                    enumLiteral_4=(Token)match(input,171,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:8715:3: (enumLiteral_5= '!=' )
                    {
                    // InternalSM2.g:8715:3: (enumLiteral_5= '!=' )
                    // InternalSM2.g:8716:4: enumLiteral_5= '!='
                    {
                    enumLiteral_5=(Token)match(input,172,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparationOperator"

    // Delegated rules


    protected DFA135 dfa135 = new DFA135(this);
    protected DFA156 dfa156 = new DFA156(this);
    protected DFA178 dfa178 = new DFA178(this);
    protected DFA183 dfa183 = new DFA183(this);
    protected DFA184 dfa184 = new DFA184(this);
    protected DFA187 dfa187 = new DFA187(this);
    protected DFA192 dfa192 = new DFA192(this);
    protected DFA199 dfa199 = new DFA199(this);
    static final String dfa_1s = "\15\uffff";
    static final String dfa_2s = "\1\u009b\1\13\1\6\1\55\1\uffff\6\6\1\14\1\uffff";
    static final String dfa_3s = "\1\u009b\1\13\1\21\1\u00ae\1\uffff\6\21\1\u00c7\1\uffff";
    static final String dfa_4s = "\4\uffff\1\1\7\uffff\1\2";
    static final String dfa_5s = "\15\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\2",
            "\1\3\10\uffff\1\4\1\uffff\1\4",
            "\1\5\1\7\174\uffff\1\11\1\12\1\6\1\10",
            "",
            "\1\4\10\uffff\1\13\1\uffff\1\4",
            "\1\4\10\uffff\1\13\1\uffff\1\4",
            "\1\4\10\uffff\1\13\1\uffff\1\4",
            "\1\4\10\uffff\1\13\1\uffff\1\4",
            "\1\4\10\uffff\1\13\1\uffff\1\4",
            "\1\4\10\uffff\1\13\1\uffff\1\4",
            "\1\4\u00b5\uffff\6\14",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA135 extends DFA {

        public DFA135(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 135;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "4819:2: (this_Restriction_0= ruleRestriction | this_RestrictionGas_1= ruleRestrictionGas )";
        }
    }
    static final String dfa_7s = "\71\uffff";
    static final String dfa_8s = "\2\uffff\1\31\6\uffff\3\43\1\uffff\1\45\2\uffff\1\51\4\uffff\1\53\4\uffff\1\51\1\53\12\uffff\2\61\1\43\3\uffff\3\61\1\43\1\61\1\uffff\7\61";
    static final String dfa_9s = "\2\6\1\4\6\uffff\2\5\1\4\1\uffff\1\5\2\6\1\5\4\6\1\5\4\uffff\2\5\6\6\2\uffff\1\5\1\uffff\3\5\1\uffff\1\u00b6\1\uffff\5\5\1\uffff\7\5";
    static final String dfa_10s = "\1\u00a4\1\6\1\u00b7\6\uffff\1\u00b7\2\u00b5\1\uffff\1\u00b5\2\21\1\u00ae\4\21\1\u00ae\4\uffff\2\u00ae\6\21\2\uffff\1\5\1\uffff\1\u00b7\1\u00b5\1\u00b7\1\uffff\1\u00b7\1\uffff\1\u00b7\1\u00b5\1\u00b7\2\u00b5\1\uffff\7\u00b5";
    static final String dfa_11s = "\3\uffff\1\3\1\4\1\5\1\6\1\7\1\10\3\uffff\1\20\11\uffff\1\14\1\13\1\15\1\2\10\uffff\1\21\1\11\1\uffff\1\1\3\uffff\1\17\1\uffff\1\16\5\uffff\1\12\7\uffff";
    static final String dfa_12s = "\71\uffff}>";
    static final String[] dfa_13s = {
            "\1\2\4\uffff\1\5\3\uffff\1\11\1\uffff\1\12\1\13\1\uffff\1\4\5\uffff\1\6\1\7\1\10\1\14\65\uffff\1\3\5\uffff\71\3\22\uffff\1\1",
            "\1\15",
            "\3\31\2\uffff\1\31\1\uffff\2\31\1\uffff\2\31\1\uffff\2\31\1\uffff\1\31\5\uffff\4\31\2\uffff\1\31\14\uffff\1\21\1\22\44\uffff\1\31\5\uffff\71\31\13\uffff\4\31\3\uffff\1\31\6\uffff\1\16\1\17\1\23\1\24\5\27\1\26\1\30\1\25\1\20",
            "",
            "",
            "",
            "",
            "",
            "",
            "\2\43\2\uffff\1\43\1\uffff\2\43\1\uffff\2\43\1\uffff\2\43\1\uffff\1\43\5\uffff\4\43\2\uffff\1\43\14\uffff\1\36\1\37\44\uffff\1\43\5\uffff\71\43\13\uffff\4\43\3\uffff\1\43\6\42\1\34\1\35\1\40\1\41\5\27\1\26\1\30\1\33\1\32",
            "\2\43\2\uffff\1\43\1\uffff\2\43\1\uffff\2\43\1\uffff\2\43\1\uffff\1\43\5\uffff\4\43\2\uffff\1\43\14\uffff\1\36\1\37\44\uffff\1\43\5\uffff\71\43\13\uffff\4\43\3\uffff\1\43\6\uffff\1\34\1\35\1\40\1\41\5\27\1\26\1\30",
            "\1\44\2\43\2\uffff\1\43\1\uffff\2\43\1\uffff\2\43\1\uffff\2\43\1\uffff\1\43\5\uffff\4\43\2\uffff\1\43\62\uffff\1\43\5\uffff\71\43\13\uffff\4\43\3\uffff\1\43\17\uffff\1\26\1\30",
            "",
            "\2\45\2\uffff\1\45\1\uffff\2\45\1\uffff\2\45\1\uffff\2\45\1\uffff\1\45\5\uffff\4\45\2\uffff\1\45\62\uffff\1\45\5\uffff\71\45\13\uffff\4\45\3\uffff\1\45\17\uffff\1\26\1\30",
            "\1\50\10\uffff\1\46\1\uffff\1\47",
            "\1\50\10\uffff\1\46\1\uffff\1\47",
            "\2\51\2\uffff\1\51\1\uffff\2\51\1\uffff\2\51\1\uffff\2\51\1\uffff\1\51\5\uffff\4\51\2\uffff\1\51\14\uffff\1\36\1\37\44\uffff\1\51\5\uffff\71\51\13\uffff\4\51\3\uffff\1\51\6\uffff\1\34\1\35\1\40\1\41",
            "\1\52\10\uffff\1\46\1\uffff\1\47",
            "\1\52\10\uffff\1\46\1\uffff\1\47",
            "\1\52\10\uffff\1\46\1\uffff\1\47",
            "\1\52\10\uffff\1\46\1\uffff\1\47",
            "\2\53\2\uffff\1\53\1\uffff\2\53\1\uffff\2\53\1\uffff\2\53\1\uffff\1\53\5\uffff\4\53\2\uffff\1\53\14\uffff\1\36\1\37\44\uffff\1\53\5\uffff\71\53\13\uffff\4\53\3\uffff\1\53\6\uffff\1\34\1\35\1\40\1\41",
            "",
            "",
            "",
            "",
            "\2\51\2\uffff\1\51\1\uffff\2\51\1\uffff\2\51\1\uffff\2\51\1\uffff\1\51\5\uffff\4\51\2\uffff\1\51\14\uffff\1\36\1\37\44\uffff\1\51\5\uffff\71\51\13\uffff\4\51\3\uffff\1\51\6\uffff\1\34\1\35\1\40\1\41",
            "\2\53\2\uffff\1\53\1\uffff\2\53\1\uffff\2\53\1\uffff\2\53\1\uffff\1\53\5\uffff\4\53\2\uffff\1\53\14\uffff\1\36\1\37\44\uffff\1\53\5\uffff\71\53\13\uffff\4\53\3\uffff\1\53\6\uffff\1\34\1\35\1\40\1\41",
            "\1\56\10\uffff\1\54\1\uffff\1\55",
            "\1\56\10\uffff\1\54\1\uffff\1\55",
            "\1\56\10\uffff\1\54\1\uffff\1\55",
            "\1\56\10\uffff\1\54\1\uffff\1\55",
            "\1\56\10\uffff\1\54\1\uffff\1\55",
            "\1\56\10\uffff\1\54\1\uffff\1\55",
            "",
            "",
            "\1\57",
            "",
            "\2\61\2\uffff\1\61\1\uffff\2\61\1\uffff\2\61\1\uffff\2\61\1\uffff\1\61\5\uffff\4\61\2\uffff\1\61\62\uffff\1\61\5\uffff\71\61\13\uffff\4\61\3\uffff\1\61\17\uffff\1\26\1\30\1\62\1\60",
            "\2\61\2\uffff\1\61\1\uffff\2\61\1\uffff\2\61\1\uffff\2\61\1\uffff\1\61\5\uffff\4\61\2\uffff\1\61\62\uffff\1\61\5\uffff\71\61\13\uffff\4\61\3\uffff\1\61\17\uffff\1\26\1\30",
            "\2\43\2\uffff\1\43\1\uffff\2\43\1\uffff\2\43\1\uffff\2\43\1\uffff\1\43\5\uffff\4\43\2\uffff\1\43\62\uffff\1\43\5\uffff\71\43\13\uffff\4\43\3\uffff\1\43\17\uffff\1\26\1\30\1\63\1\64",
            "",
            "\1\63\1\64",
            "",
            "\2\61\2\uffff\1\61\1\uffff\2\61\1\uffff\2\61\1\uffff\2\61\1\uffff\1\61\5\uffff\4\61\2\uffff\1\61\62\uffff\1\61\5\uffff\71\61\13\uffff\4\61\3\uffff\1\61\17\uffff\1\26\1\30\1\65\1\66",
            "\2\61\2\uffff\1\61\1\uffff\2\61\1\uffff\2\61\1\uffff\2\61\1\uffff\1\61\5\uffff\4\61\2\uffff\1\61\62\uffff\1\61\5\uffff\71\61\13\uffff\4\61\3\uffff\1\61\17\uffff\1\26\1\30",
            "\2\61\2\uffff\1\61\1\uffff\2\61\1\uffff\2\61\1\uffff\2\61\1\uffff\1\61\5\uffff\4\61\2\uffff\1\61\62\uffff\1\61\5\uffff\71\61\13\uffff\4\61\3\uffff\1\61\17\uffff\1\26\1\30\1\70\1\67",
            "\2\43\2\uffff\1\43\1\uffff\2\43\1\uffff\2\43\1\uffff\2\43\1\uffff\1\43\5\uffff\4\43\2\uffff\1\43\62\uffff\1\43\5\uffff\71\43\13\uffff\4\43\3\uffff\1\43\17\uffff\1\26\1\30",
            "\2\61\2\uffff\1\61\1\uffff\2\61\1\uffff\2\61\1\uffff\2\61\1\uffff\1\61\5\uffff\4\61\2\uffff\1\61\62\uffff\1\61\5\uffff\71\61\13\uffff\4\61\3\uffff\1\61\17\uffff\1\26\1\30",
            "",
            "\2\61\2\uffff\1\61\1\uffff\2\61\1\uffff\2\61\1\uffff\2\61\1\uffff\1\61\5\uffff\4\61\2\uffff\1\61\62\uffff\1\61\5\uffff\71\61\13\uffff\4\61\3\uffff\1\61\17\uffff\1\26\1\30",
            "\2\61\2\uffff\1\61\1\uffff\2\61\1\uffff\2\61\1\uffff\2\61\1\uffff\1\61\5\uffff\4\61\2\uffff\1\61\62\uffff\1\61\5\uffff\71\61\13\uffff\4\61\3\uffff\1\61\17\uffff\1\26\1\30",
            "\2\61\2\uffff\1\61\1\uffff\2\61\1\uffff\2\61\1\uffff\2\61\1\uffff\1\61\5\uffff\4\61\2\uffff\1\61\62\uffff\1\61\5\uffff\71\61\13\uffff\4\61\3\uffff\1\61\17\uffff\1\26\1\30",
            "\2\61\2\uffff\1\61\1\uffff\2\61\1\uffff\2\61\1\uffff\2\61\1\uffff\1\61\5\uffff\4\61\2\uffff\1\61\62\uffff\1\61\5\uffff\71\61\13\uffff\4\61\3\uffff\1\61\17\uffff\1\26\1\30",
            "\2\61\2\uffff\1\61\1\uffff\2\61\1\uffff\2\61\1\uffff\2\61\1\uffff\1\61\5\uffff\4\61\2\uffff\1\61\62\uffff\1\61\5\uffff\71\61\13\uffff\4\61\3\uffff\1\61\17\uffff\1\26\1\30",
            "\2\61\2\uffff\1\61\1\uffff\2\61\1\uffff\2\61\1\uffff\2\61\1\uffff\1\61\5\uffff\4\61\2\uffff\1\61\62\uffff\1\61\5\uffff\71\61\13\uffff\4\61\3\uffff\1\61\17\uffff\1\26\1\30",
            "\2\61\2\uffff\1\61\1\uffff\2\61\1\uffff\2\61\1\uffff\2\61\1\uffff\1\61\5\uffff\4\61\2\uffff\1\61\62\uffff\1\61\5\uffff\71\61\13\uffff\4\61\3\uffff\1\61\17\uffff\1\26\1\30"
    };

    static final short[] dfa_7 = DFA.unpackEncodedString(dfa_7s);
    static final short[] dfa_8 = DFA.unpackEncodedString(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final char[] dfa_10 = DFA.unpackEncodedStringToUnsignedChars(dfa_10s);
    static final short[] dfa_11 = DFA.unpackEncodedString(dfa_11s);
    static final short[] dfa_12 = DFA.unpackEncodedString(dfa_12s);
    static final short[][] dfa_13 = unpackEncodedStringArray(dfa_13s);

    class DFA156 extends DFA {

        public DFA156(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 156;
            this.eot = dfa_7;
            this.eof = dfa_8;
            this.min = dfa_9;
            this.max = dfa_10;
            this.accept = dfa_11;
            this.special = dfa_12;
            this.transition = dfa_13;
        }
        public String getDescription() {
            return "5672:2: (this_NegationExpression_0= ruleNegationExpression | this_SyntaxExpression_1= ruleSyntaxExpression | this_TypeCastingExpression_2= ruleTypeCastingExpression | this_CreateObjectExpression_3= ruleCreateObjectExpression | this_TupleExpression_4= ruleTupleExpression | this_DeleteExpression_5= ruleDeleteExpression | this_EmitEventExpression_6= ruleEmitEventExpression | this_ReturnExpression_7= ruleReturnExpression | this_ComparationExpression_8= ruleComparationExpression | this_ArithmeticalComparationExpression_9= ruleArithmeticalComparationExpression | this_ArithmeticalExpression_10= ruleArithmeticalExpression | this_AndExpression_11= ruleAndExpression | this_OrExpression_12= ruleOrExpression | this_IncrementLoopExpression_13= ruleIncrementLoopExpression | this_DecrementLoopExpression_14= ruleDecrementLoopExpression | this_ConditionalExpression_15= ruleConditionalExpression | this_TimeExpression_16= ruleTimeExpression )";
        }
    }
    static final String dfa_14s = "\22\uffff";
    static final String dfa_15s = "\17\uffff\1\21\2\uffff";
    static final String dfa_16s = "\1\6\3\55\6\6\4\55\1\uffff\1\4\2\uffff";
    static final String dfa_17s = "\1\21\1\u00b7\1\u00ae\1\u00b7\6\21\4\u00ae\1\uffff\1\u00b7\2\uffff";
    static final String dfa_18s = "\16\uffff\1\2\1\uffff\1\1\1\3";
    static final String dfa_19s = "\22\uffff}>";
    static final String[] dfa_20s = {
            "\1\3\10\uffff\1\1\1\uffff\1\2",
            "\1\6\1\7\174\uffff\1\4\1\5\1\10\1\11\7\uffff\1\13\1\12",
            "\1\6\1\7\174\uffff\1\4\1\5\1\10\1\11",
            "\2\16\174\uffff\4\16\7\uffff\1\14\1\15",
            "\1\17\10\uffff\1\20\1\uffff\1\20",
            "\1\17\10\uffff\1\20\1\uffff\1\20",
            "\1\17\10\uffff\1\20\1\uffff\1\20",
            "\1\17\10\uffff\1\20\1\uffff\1\20",
            "\1\17\10\uffff\1\20\1\uffff\1\20",
            "\1\17\10\uffff\1\20\1\uffff\1\20",
            "\1\6\1\7\174\uffff\1\4\1\5\1\10\1\11",
            "\1\6\1\7\174\uffff\1\4\1\5\1\10\1\11",
            "\1\6\1\7\174\uffff\1\4\1\5\1\10\1\11",
            "\1\6\1\7\174\uffff\1\4\1\5\1\10\1\11",
            "",
            "\3\21\2\uffff\1\21\1\uffff\2\21\1\uffff\2\21\1\uffff\2\21\1\uffff\1\21\5\uffff\4\21\2\uffff\1\21\62\uffff\1\21\5\uffff\71\21\13\uffff\4\21\3\uffff\1\21\17\uffff\2\21\2\20",
            "",
            ""
    };

    static final short[] dfa_14 = DFA.unpackEncodedString(dfa_14s);
    static final short[] dfa_15 = DFA.unpackEncodedString(dfa_15s);
    static final char[] dfa_16 = DFA.unpackEncodedStringToUnsignedChars(dfa_16s);
    static final char[] dfa_17 = DFA.unpackEncodedStringToUnsignedChars(dfa_17s);
    static final short[] dfa_18 = DFA.unpackEncodedString(dfa_18s);
    static final short[] dfa_19 = DFA.unpackEncodedString(dfa_19s);
    static final short[][] dfa_20 = unpackEncodedStringArray(dfa_20s);

    class DFA178 extends DFA {

        public DFA178(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 178;
            this.eot = dfa_14;
            this.eof = dfa_15;
            this.min = dfa_16;
            this.max = dfa_17;
            this.accept = dfa_18;
            this.special = dfa_19;
            this.transition = dfa_20;
        }
        public String getDescription() {
            return "6501:2: ( ( (this_NumberExpression_0= ruleNumberExpression | this_IncrementLoopExpression_1= ruleIncrementLoopExpression | this_DecrementLoopExpression_2= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_9= ruleNumberExpression | this_IncrementLoopExpression_10= ruleIncrementLoopExpression | this_DecrementLoopExpression_11= ruleDecrementLoopExpression ) ) | (this_STRING_12= RULE_STRING (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) (this_NumberExpression_19= ruleNumberExpression | this_IncrementLoopExpression_20= ruleIncrementLoopExpression | this_DecrementLoopExpression_21= ruleDecrementLoopExpression ) ) | ( (this_NumberExpression_22= ruleNumberExpression | this_IncrementLoopExpression_23= ruleIncrementLoopExpression | this_DecrementLoopExpression_24= ruleDecrementLoopExpression ) (kw= '==' | kw= '!=' | kw= '>' | kw= '>=' | kw= '<' | kw= '<=' ) this_STRING_31= RULE_STRING ) )";
        }
    }
    static final String dfa_21s = "\13\uffff";
    static final String dfa_22s = "\1\6\1\uffff\3\55\2\uffff\2\6\1\uffff\1\u00b4";
    static final String dfa_23s = "\1\u00a4\1\uffff\2\u00b7\1\u00b4\2\uffff\2\21\1\uffff\1\u00b7";
    static final String dfa_24s = "\1\uffff\1\1\3\uffff\1\4\1\3\2\uffff\1\2\1\uffff";
    static final String dfa_25s = "\13\uffff}>";
    static final String[] dfa_26s = {
            "\1\2\10\uffff\1\3\1\uffff\1\4\1\5\u0091\uffff\1\1",
            "",
            "\2\6\174\uffff\1\7\1\10\2\6\5\uffff\1\11\1\uffff\2\6",
            "\2\6\174\uffff\4\6\5\uffff\1\5\1\uffff\2\6",
            "\2\6\174\uffff\4\6\5\uffff\1\5",
            "",
            "",
            "\1\12\10\uffff\1\6\1\uffff\1\6",
            "\1\12\10\uffff\1\6\1\uffff\1\6",
            "",
            "\1\5\1\uffff\2\6"
    };

    static final short[] dfa_21 = DFA.unpackEncodedString(dfa_21s);
    static final char[] dfa_22 = DFA.unpackEncodedStringToUnsignedChars(dfa_22s);
    static final char[] dfa_23 = DFA.unpackEncodedStringToUnsignedChars(dfa_23s);
    static final short[] dfa_24 = DFA.unpackEncodedString(dfa_24s);
    static final short[] dfa_25 = DFA.unpackEncodedString(dfa_25s);
    static final short[][] dfa_26 = unpackEncodedStringArray(dfa_26s);

    class DFA183 extends DFA {

        public DFA183(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 183;
            this.eot = dfa_21;
            this.eof = dfa_21;
            this.min = dfa_22;
            this.max = dfa_23;
            this.accept = dfa_24;
            this.special = dfa_25;
            this.transition = dfa_26;
        }
        public String getDescription() {
            return "6925:3: (this_NegationExpression_0= ruleNegationExpression | this_STRING_1= RULE_STRING | this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression | this_ComparationExpression_3= ruleComparationExpression )";
        }
    }
    static final String dfa_27s = "\1\6\1\uffff\3\55\2\uffff\2\6\1\uffff\1\u00b5";
    static final String dfa_28s = "\1\u00a4\1\uffff\2\u00b7\1\u00b5\2\uffff\2\21\1\uffff\1\u00b7";
    static final String[] dfa_29s = {
            "\1\2\10\uffff\1\3\1\uffff\1\4\1\5\u0091\uffff\1\1",
            "",
            "\2\6\174\uffff\1\7\1\10\2\6\6\uffff\1\11\2\6",
            "\2\6\174\uffff\4\6\6\uffff\1\5\2\6",
            "\2\6\174\uffff\4\6\6\uffff\1\5",
            "",
            "",
            "\1\12\10\uffff\1\6\1\uffff\1\6",
            "\1\12\10\uffff\1\6\1\uffff\1\6",
            "",
            "\1\5\2\6"
    };
    static final char[] dfa_27 = DFA.unpackEncodedStringToUnsignedChars(dfa_27s);
    static final char[] dfa_28 = DFA.unpackEncodedStringToUnsignedChars(dfa_28s);
    static final short[][] dfa_29 = unpackEncodedStringArray(dfa_29s);

    class DFA184 extends DFA {

        public DFA184(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 184;
            this.eot = dfa_21;
            this.eof = dfa_21;
            this.min = dfa_27;
            this.max = dfa_28;
            this.accept = dfa_24;
            this.special = dfa_25;
            this.transition = dfa_29;
        }
        public String getDescription() {
            return "7001:3: (this_NegationExpression_0= ruleNegationExpression | this_STRING_1= RULE_STRING | this_ArithmeticalComparationExpression_2= ruleArithmeticalComparationExpression | this_ComparationExpression_3= ruleComparationExpression )";
        }
    }
    static final String dfa_30s = "\54\uffff";
    static final String dfa_31s = "\2\6\1\55\2\14\1\4\1\u00b4\1\uffff\2\55\6\6\1\uffff\6\6\2\55\1\uffff\1\5\3\14\1\u00b6\10\14\1\uffff\4\14";
    static final String dfa_32s = "\1\u00a4\1\6\2\u00b7\3\u00b5\1\uffff\2\u00ae\6\21\1\uffff\6\21\2\u00ae\1\uffff\1\5\2\u00b7\1\u00b5\2\u00b7\1\u00b5\1\u00b7\5\u00b5\1\uffff\4\u00b5";
    static final String dfa_33s = "\7\uffff\1\1\10\uffff\1\2\10\uffff\1\4\15\uffff\1\3\4\uffff";
    static final String dfa_34s = "\54\uffff}>";
    static final String[] dfa_35s = {
            "\1\2\10\uffff\1\3\1\uffff\1\4\1\5\u0091\uffff\1\1",
            "\1\6",
            "\1\14\1\15\174\uffff\1\12\1\13\1\16\1\17\5\uffff\1\7\1\20\1\10\1\11",
            "\1\31\40\uffff\1\23\1\24\174\uffff\1\21\1\22\1\25\1\26\5\uffff\1\7\1\20\1\30\1\27",
            "\1\31\40\uffff\1\23\1\24\174\uffff\1\21\1\22\1\25\1\26\5\uffff\1\7\1\20",
            "\1\32\7\uffff\1\31\u00a7\uffff\1\7\1\20",
            "\1\7\1\20",
            "",
            "\1\23\1\24\174\uffff\1\21\1\22\1\25\1\26",
            "\1\23\1\24\174\uffff\1\21\1\22\1\25\1\26",
            "\1\33\10\uffff\1\34\1\uffff\1\35",
            "\1\33\10\uffff\1\34\1\uffff\1\35",
            "\1\36\10\uffff\1\34\1\uffff\1\35",
            "\1\36\10\uffff\1\34\1\uffff\1\35",
            "\1\36\10\uffff\1\34\1\uffff\1\35",
            "\1\36\10\uffff\1\34\1\uffff\1\35",
            "",
            "\1\41\10\uffff\1\37\1\uffff\1\40",
            "\1\41\10\uffff\1\37\1\uffff\1\40",
            "\1\41\10\uffff\1\37\1\uffff\1\40",
            "\1\41\10\uffff\1\37\1\uffff\1\40",
            "\1\41\10\uffff\1\37\1\uffff\1\40",
            "\1\41\10\uffff\1\37\1\uffff\1\40",
            "\1\23\1\24\174\uffff\1\21\1\22\1\25\1\26",
            "\1\23\1\24\174\uffff\1\21\1\22\1\25\1\26",
            "",
            "\1\42",
            "\1\31\u00a7\uffff\1\7\1\20\1\44\1\43",
            "\1\47\u00a7\uffff\1\7\1\20\1\45\1\46",
            "\1\47\u00a7\uffff\1\7\1\20",
            "\1\44\1\43",
            "\1\47\u00a7\uffff\1\7\1\20\1\51\1\50",
            "\1\47\u00a7\uffff\1\7\1\20",
            "\1\47\u00a7\uffff\1\7\1\20\1\53\1\52",
            "\1\31\u00a7\uffff\1\7\1\20",
            "\1\47\u00a7\uffff\1\7\1\20",
            "\1\47\u00a7\uffff\1\7\1\20",
            "\1\47\u00a7\uffff\1\7\1\20",
            "\1\47\u00a7\uffff\1\7\1\20",
            "",
            "\1\47\u00a7\uffff\1\7\1\20",
            "\1\47\u00a7\uffff\1\7\1\20",
            "\1\47\u00a7\uffff\1\7\1\20",
            "\1\47\u00a7\uffff\1\7\1\20"
    };

    static final short[] dfa_30 = DFA.unpackEncodedString(dfa_30s);
    static final char[] dfa_31 = DFA.unpackEncodedStringToUnsignedChars(dfa_31s);
    static final char[] dfa_32 = DFA.unpackEncodedStringToUnsignedChars(dfa_32s);
    static final short[] dfa_33 = DFA.unpackEncodedString(dfa_33s);
    static final short[] dfa_34 = DFA.unpackEncodedString(dfa_34s);
    static final short[][] dfa_35 = unpackEncodedStringArray(dfa_35s);

    class DFA187 extends DFA {

        public DFA187(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 187;
            this.eot = dfa_30;
            this.eof = dfa_30;
            this.min = dfa_31;
            this.max = dfa_32;
            this.accept = dfa_33;
            this.special = dfa_34;
            this.transition = dfa_35;
        }
        public String getDescription() {
            return "7187:3: (this_AndExpression_2= ruleAndExpression | this_OrExpression_3= ruleOrExpression | this_ArithmeticalComparationExpression_4= ruleArithmeticalComparationExpression | this_ComparationExpression_5= ruleComparationExpression )";
        }
    }
    static final String dfa_36s = "\2\6\1\55\2\14\1\4\1\u00b4\1\55\6\6\1\uffff\1\55\1\uffff\6\6\2\55\1\uffff\1\5\3\14\1\u00b6\4\14\1\uffff\10\14";
    static final String dfa_37s = "\1\u00a4\1\6\2\u00b7\3\u00b5\1\u00ae\6\21\1\uffff\1\u00ae\1\uffff\6\21\2\u00ae\1\uffff\1\5\1\u00b7\1\u00b5\3\u00b7\1\u00b5\1\u00b7\1\u00b5\1\uffff\10\u00b5";
    static final String dfa_38s = "\16\uffff\1\1\1\uffff\1\2\10\uffff\1\4\11\uffff\1\3\10\uffff";
    static final String[] dfa_39s = {
            "\1\2\10\uffff\1\3\1\uffff\1\4\1\5\u0091\uffff\1\1",
            "\1\6",
            "\1\12\1\13\174\uffff\1\10\1\11\1\14\1\15\5\uffff\1\16\1\20\1\7\1\17",
            "\1\31\40\uffff\1\23\1\24\174\uffff\1\21\1\22\1\25\1\26\5\uffff\1\16\1\20\1\30\1\27",
            "\1\31\40\uffff\1\23\1\24\174\uffff\1\21\1\22\1\25\1\26\5\uffff\1\16\1\20",
            "\1\32\7\uffff\1\31\u00a7\uffff\1\16\1\20",
            "\1\16\1\20",
            "\1\23\1\24\174\uffff\1\21\1\22\1\25\1\26",
            "\1\35\10\uffff\1\33\1\uffff\1\34",
            "\1\35\10\uffff\1\33\1\uffff\1\34",
            "\1\36\10\uffff\1\33\1\uffff\1\34",
            "\1\36\10\uffff\1\33\1\uffff\1\34",
            "\1\36\10\uffff\1\33\1\uffff\1\34",
            "\1\36\10\uffff\1\33\1\uffff\1\34",
            "",
            "\1\23\1\24\174\uffff\1\21\1\22\1\25\1\26",
            "",
            "\1\41\10\uffff\1\37\1\uffff\1\40",
            "\1\41\10\uffff\1\37\1\uffff\1\40",
            "\1\41\10\uffff\1\37\1\uffff\1\40",
            "\1\41\10\uffff\1\37\1\uffff\1\40",
            "\1\41\10\uffff\1\37\1\uffff\1\40",
            "\1\41\10\uffff\1\37\1\uffff\1\40",
            "\1\23\1\24\174\uffff\1\21\1\22\1\25\1\26",
            "\1\23\1\24\174\uffff\1\21\1\22\1\25\1\26",
            "",
            "\1\42",
            "\1\43\u00a7\uffff\1\16\1\20\1\45\1\44",
            "\1\43\u00a7\uffff\1\16\1\20",
            "\1\31\u00a7\uffff\1\16\1\20\1\47\1\46",
            "\1\47\1\46",
            "\1\43\u00a7\uffff\1\16\1\20\1\51\1\50",
            "\1\43\u00a7\uffff\1\16\1\20",
            "\1\43\u00a7\uffff\1\16\1\20\1\53\1\52",
            "\1\31\u00a7\uffff\1\16\1\20",
            "",
            "\1\43\u00a7\uffff\1\16\1\20",
            "\1\43\u00a7\uffff\1\16\1\20",
            "\1\43\u00a7\uffff\1\16\1\20",
            "\1\43\u00a7\uffff\1\16\1\20",
            "\1\43\u00a7\uffff\1\16\1\20",
            "\1\43\u00a7\uffff\1\16\1\20",
            "\1\43\u00a7\uffff\1\16\1\20",
            "\1\43\u00a7\uffff\1\16\1\20"
    };
    static final char[] dfa_36 = DFA.unpackEncodedStringToUnsignedChars(dfa_36s);
    static final char[] dfa_37 = DFA.unpackEncodedStringToUnsignedChars(dfa_37s);
    static final short[] dfa_38 = DFA.unpackEncodedString(dfa_38s);
    static final short[][] dfa_39 = unpackEncodedStringArray(dfa_39s);

    class DFA192 extends DFA {

        public DFA192(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 192;
            this.eot = dfa_30;
            this.eof = dfa_30;
            this.min = dfa_36;
            this.max = dfa_37;
            this.accept = dfa_38;
            this.special = dfa_34;
            this.transition = dfa_39;
        }
        public String getDescription() {
            return "7431:5: (lv_condition_2_1= ruleAndExpression | lv_condition_2_2= ruleOrExpression | lv_condition_2_3= ruleArithmeticalComparationExpression | lv_condition_2_4= ruleComparationExpression )";
        }
    }
    static final String dfa_40s = "\2\6\1\55\2\14\1\4\1\u00b4\2\6\2\55\4\6\2\uffff\1\55\6\6\1\55\1\uffff\1\5\3\14\1\u00b6\5\14\1\uffff\7\14";
    static final String dfa_41s = "\1\u00a4\1\6\2\u00b7\3\u00b5\2\21\2\u00ae\4\21\2\uffff\1\u00ae\6\21\1\u00ae\1\uffff\1\5\1\u00b7\1\u00b5\4\u00b7\3\u00b5\1\uffff\7\u00b5";
    static final String dfa_42s = "\17\uffff\1\1\1\2\10\uffff\1\4\12\uffff\1\3\7\uffff";
    static final String[] dfa_43s = {
            "\1\2\10\uffff\1\3\1\uffff\1\4\1\5\u0091\uffff\1\1",
            "\1\6",
            "\1\13\1\14\174\uffff\1\7\1\10\1\15\1\16\5\uffff\1\17\1\20\1\12\1\11",
            "\1\31\40\uffff\1\24\1\25\174\uffff\1\22\1\23\1\26\1\27\5\uffff\1\17\1\20\1\21\1\30",
            "\1\31\40\uffff\1\24\1\25\174\uffff\1\22\1\23\1\26\1\27\5\uffff\1\17\1\20",
            "\1\32\7\uffff\1\31\u00a7\uffff\1\17\1\20",
            "\1\17\1\20",
            "\1\35\10\uffff\1\33\1\uffff\1\34",
            "\1\35\10\uffff\1\33\1\uffff\1\34",
            "\1\24\1\25\174\uffff\1\22\1\23\1\26\1\27",
            "\1\24\1\25\174\uffff\1\22\1\23\1\26\1\27",
            "\1\36\10\uffff\1\33\1\uffff\1\34",
            "\1\36\10\uffff\1\33\1\uffff\1\34",
            "\1\36\10\uffff\1\33\1\uffff\1\34",
            "\1\36\10\uffff\1\33\1\uffff\1\34",
            "",
            "",
            "\1\24\1\25\174\uffff\1\22\1\23\1\26\1\27",
            "\1\37\10\uffff\1\40\1\uffff\1\41",
            "\1\37\10\uffff\1\40\1\uffff\1\41",
            "\1\37\10\uffff\1\40\1\uffff\1\41",
            "\1\37\10\uffff\1\40\1\uffff\1\41",
            "\1\37\10\uffff\1\40\1\uffff\1\41",
            "\1\37\10\uffff\1\40\1\uffff\1\41",
            "\1\24\1\25\174\uffff\1\22\1\23\1\26\1\27",
            "",
            "\1\42",
            "\1\44\u00a7\uffff\1\17\1\20\1\43\1\45",
            "\1\44\u00a7\uffff\1\17\1\20",
            "\1\31\u00a7\uffff\1\17\1\20\1\47\1\46",
            "\1\47\1\46",
            "\1\44\u00a7\uffff\1\17\1\20\1\50\1\51",
            "\1\44\u00a7\uffff\1\17\1\20\1\53\1\52",
            "\1\44\u00a7\uffff\1\17\1\20",
            "\1\31\u00a7\uffff\1\17\1\20",
            "\1\44\u00a7\uffff\1\17\1\20",
            "",
            "\1\44\u00a7\uffff\1\17\1\20",
            "\1\44\u00a7\uffff\1\17\1\20",
            "\1\44\u00a7\uffff\1\17\1\20",
            "\1\44\u00a7\uffff\1\17\1\20",
            "\1\44\u00a7\uffff\1\17\1\20",
            "\1\44\u00a7\uffff\1\17\1\20",
            "\1\44\u00a7\uffff\1\17\1\20"
    };
    static final char[] dfa_40 = DFA.unpackEncodedStringToUnsignedChars(dfa_40s);
    static final char[] dfa_41 = DFA.unpackEncodedStringToUnsignedChars(dfa_41s);
    static final short[] dfa_42 = DFA.unpackEncodedString(dfa_42s);
    static final short[][] dfa_43 = unpackEncodedStringArray(dfa_43s);

    class DFA199 extends DFA {

        public DFA199(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 199;
            this.eot = dfa_30;
            this.eof = dfa_30;
            this.min = dfa_40;
            this.max = dfa_41;
            this.accept = dfa_42;
            this.special = dfa_34;
            this.transition = dfa_43;
        }
        public String getDescription() {
            return "7955:5: (lv_condition_9_1= ruleAndExpression | lv_condition_9_2= ruleOrExpression | lv_condition_9_3= ruleArithmeticalComparationExpression | lv_condition_9_4= ruleComparationExpression )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0009000000000000L,0xFFFFFFFFFE2A1080L,0x00000000010BFFFFL});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000600000000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000700000000000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x00000000000000A0L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x03E0000000000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x000000003C168840L,0xFFFFFFFFFE080000L,0x000000100003FFFFL});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0400000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0xF800000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000018L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000000000100L,0x0000000000000100L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x00000000000002A0L,0xFFFFFFFFFF2AA200L,0x00000006110BFFFFL});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000000280L,0xFFFFFFFFFF2AA200L,0x00000006110BFFFFL});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000000280L,0xFFFFFFFFFF2AA000L,0x00000006110BFFFFL});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000000000280L,0xFFFFFFFFFF2AA000L,0x00000000110BFFFFL});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000000000200L,0x0000000000002000L,0x0000000010000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000000000000200L,0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000001000L,0xFFFFFFFFFE080000L,0x00000000000FFFFBL});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000C00L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000000000080L,0xFFFFFFFFFF2A8000L,0x00000000010BFFFFL});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000000060L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000000000020L,0x0000000000004000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000000000000000L,0x0000000000004000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000000000L,0xFFFFFFFFFE080000L,0x00000000000FFFFBL});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000000000000L,0x0000000000010000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000000000000080L,0x0000000000000C00L,0x0000000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000000000000020L,0xFFFFFFFFFE2A0000L,0x00000000010BFFFFL});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000000000L,0xFFFFFFFFFE2A0000L,0x00000000010BFFFFL});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000000000000020L,0x0000000000080000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000000000L,0x0000000000080000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000000080L,0x0000000000100000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000000000020L,0x0000000000200000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0000000000000010L,0x0000000000400000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0000000000000220L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0000000000004200L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000004L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000300000L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000400000L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x0000000000010080L,0x0000000000000000L,0x8000000000300000L,0x0000000000000001L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x0000000000010080L,0x0000000000000000L,0x8000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x0000000000000080L,0x0000000000000000L,0x8000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0000000000010080L,0x0000000000000C00L,0x0000000000300000L,0x0000000000000002L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0000000000010080L,0x0000000000000C00L,0x0000000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x0000000000008010L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x0000000000010080L,0x0000000000000C00L,0x8000000000300000L,0x0000000000000003L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x0000000000010080L,0x0000000000000C00L,0x8000000000000000L,0x0000000000000003L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x0000000000000080L,0x0000000000000C00L,0x8000000000000000L,0x0000000000000003L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_73 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_74 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000002000000L});
    public static final BitSet FOLLOW_75 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_76 = new BitSet(new long[]{0x0000000000000080L,0x0000000000000C00L,0x0000000000300000L,0x0000000000000002L});
    public static final BitSet FOLLOW_77 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_78 = new BitSet(new long[]{0x0000000000000080L,0x0000000000000000L,0x0000000004300000L});
    public static final BitSet FOLLOW_79 = new BitSet(new long[]{0x0000000000000080L,0x0000000000000000L,0x0000000004000000L});
    public static final BitSet FOLLOW_80 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_81 = new BitSet(new long[]{0x0000000000028040L});
    public static final BitSet FOLLOW_82 = new BitSet(new long[]{0x0000600000000000L,0x0000000000000000L,0x0000780000000000L});
    public static final BitSet FOLLOW_83 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000000L,0x00000000000000FCL});
    public static final BitSet FOLLOW_84 = new BitSet(new long[]{0x0000000000200000L,0x0000000000000C00L,0x0000000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_85 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000C00L,0x0000000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_86 = new BitSet(new long[]{0x0000000000000180L,0x0000000000000000L,0x7000000000000000L});
    public static final BitSet FOLLOW_87 = new BitSet(new long[]{0x000000003C168A40L,0xFFFFFFFFFE080000L,0x0B000011E803FFFFL});
    public static final BitSet FOLLOW_88 = new BitSet(new long[]{0x000000003C168A40L,0xFFFFFFFFFE080000L,0x0B000011E003FFFFL});
    public static final BitSet FOLLOW_89 = new BitSet(new long[]{0x000000003C168A40L,0xFFFFFFFFFE080000L,0x00000011E003FFFFL});
    public static final BitSet FOLLOW_90 = new BitSet(new long[]{0x0000000000000200L,0x0000000000000000L,0x00000001E0000000L});
    public static final BitSet FOLLOW_91 = new BitSet(new long[]{0x0000000000005000L});
    public static final BitSet FOLLOW_92 = new BitSet(new long[]{0x0000000003C00000L,0x0000000000000000L,0x0000000800000000L});
    public static final BitSet FOLLOW_93 = new BitSet(new long[]{0x0000000003800000L,0x0000000000000000L,0x0000000800000000L});
    public static final BitSet FOLLOW_94 = new BitSet(new long[]{0x0000000003000000L,0x0000000000000000L,0x0000000800000000L});
    public static final BitSet FOLLOW_95 = new BitSet(new long[]{0x0000000002000000L,0x0000000000000000L,0x0000000800000000L});
    public static final BitSet FOLLOW_96 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000800000000L});
    public static final BitSet FOLLOW_97 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x000007E000000000L});
    public static final BitSet FOLLOW_98 = new BitSet(new long[]{0x00000000000000C0L});
    public static final BitSet FOLLOW_99 = new BitSet(new long[]{0x000000003C169840L,0xFFFFFFFFFE080000L,0x000000100003FFFFL});
    public static final BitSet FOLLOW_100 = new BitSet(new long[]{0x0000000000000800L,0x0000000000000000L,0x0000000000300000L});
    public static final BitSet FOLLOW_101 = new BitSet(new long[]{0x000000003C16D840L,0xFFFFFFFFFE080000L,0x000000100003FFFFL});
    public static final BitSet FOLLOW_102 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000180000000000L});
    public static final BitSet FOLLOW_103 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x000F800000000000L});
    public static final BitSet FOLLOW_104 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0010000000000000L});
    public static final BitSet FOLLOW_105 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0020000000000000L});
    public static final BitSet FOLLOW_106 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0040000000000000L});
    public static final BitSet FOLLOW_107 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0080000000000000L});
    public static final BitSet FOLLOW_108 = new BitSet(new long[]{0x0000000000068040L,0x0000000000000000L,0x0000001000000000L});
    public static final BitSet FOLLOW_109 = new BitSet(new long[]{0x000000003C168A40L,0xFFFFFFFFFE080000L,0x000000100003FFFFL});
    public static final BitSet FOLLOW_110 = new BitSet(new long[]{0x0000000040000002L});
    public static final BitSet FOLLOW_111 = new BitSet(new long[]{0x000000003C168860L,0xFFFFFFFFFE080000L,0x000000100003FFFFL});
    public static final BitSet FOLLOW_112 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_113 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0100000000000000L});
    public static final BitSet FOLLOW_114 = new BitSet(new long[]{0x0000000000000000L,0x0000100002000000L,0x0400000000000000L});
    public static final BitSet FOLLOW_115 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_116 = new BitSet(new long[]{0x000000003C168840L,0xFFFFFFFFFE080000L,0x0B0000100003FFFFL});
    public static final BitSet FOLLOW_117 = new BitSet(new long[]{0x0000000100000200L});

}