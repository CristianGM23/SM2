package org.xtext.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_ID", "RULE_OPENKEY", "RULE_CLOSEKEY", "RULE_NUMBER", "RULE_DOT", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_STRING", "RULE_EMAIL", "RULE_COMMA", "RULE_INT", "RULE_PARAMSLONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_NOTICELONGCOMENT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'pragma'", "'solidity'", "'contract'", "'is'", "'^'", "'>'", "'>='", "'<'", "'<='", "'import'", "'as'", "'event'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'enum'", "'='", "'require'", "'function'", "'//'", "'/*'", "'*/'", "'int'", "'uint'", "'uint8'", "'uint256'", "'string'", "'address'", "'address payable'", "'double'", "'bool'", "'public'", "'private'", "'internal'", "'external'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'=='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'"
    };
    public static final int T__50=50;
    public static final int RULE_OPENPARENTHESIS=11;
    public static final int RULE_EOLINE=5;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int RULE_CLOSEKEY=8;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_PARAMSLONGCOMENT=17;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=6;
    public static final int RULE_COMMA=15;
    public static final int RULE_RETURNSLONGCOMENT=19;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=16;
    public static final int T__29=29;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=22;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int RULE_SEMICOLON=4;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_TITLELONGCOMENT=20;
    public static final int RULE_STRING=13;
    public static final int RULE_EMAIL=14;
    public static final int RULE_NOTICELONGCOMENT=21;
    public static final int RULE_SL_COMMENT=23;
    public static final int T__37=37;
    public static final int RULE_OPENKEY=7;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int RULE_CLOSEPARENTHESIS=12;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__73=73;
    public static final int RULE_DOT=10;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__74=74;
    public static final int T__31=31;
    public static final int T__75=75;
    public static final int T__32=32;
    public static final int T__76=76;
    public static final int RULE_WS=24;
    public static final int RULE_ANY_OTHER=25;
    public static final int RULE_NUMBER=9;
    public static final int RULE_DEVLONGCOMENT=18;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }



     	private SM2GrammarAccess grammarAccess;

        public InternalSM2Parser(TokenStream input, SM2GrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "SmartContract";
       	}

       	@Override
       	protected SM2GrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleSmartContract"
    // InternalSM2.g:65:1: entryRuleSmartContract returns [EObject current=null] : iv_ruleSmartContract= ruleSmartContract EOF ;
    public final EObject entryRuleSmartContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSmartContract = null;


        try {
            // InternalSM2.g:65:54: (iv_ruleSmartContract= ruleSmartContract EOF )
            // InternalSM2.g:66:2: iv_ruleSmartContract= ruleSmartContract EOF
            {
             newCompositeNode(grammarAccess.getSmartContractRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSmartContract=ruleSmartContract();

            state._fsp--;

             current =iv_ruleSmartContract; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSmartContract"


    // $ANTLR start "ruleSmartContract"
    // InternalSM2.g:72:1: ruleSmartContract returns [EObject current=null] : ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_contract_6_0= 'contract' ) ) ( (lv_nameContract_7_0= RULE_ID ) ) (otherlv_8= 'is' ( (lv_nameContractFather_9_0= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY (this_EOLINE_11= RULE_EOLINE )? ( (lv_attributes_12_0= ruleAttributes ) )* ( (lv_events_13_0= ruleEvent ) )* ( (lv_modifier_14_0= ruleModifier ) )* ( (lv_clauses_15_0= ruleClause ) )* ( (lv_comments_16_0= ruleComment ) )* this_CLOSEKEY_17= RULE_CLOSEKEY ) ;
    public final EObject ruleSmartContract() throws RecognitionException {
        EObject current = null;

        Token lv_compiler_0_0=null;
        Token otherlv_1=null;
        Token this_SEMICOLON_3=null;
        Token this_EOLINE_4=null;
        Token lv_contract_6_0=null;
        Token lv_nameContract_7_0=null;
        Token otherlv_8=null;
        Token lv_nameContractFather_9_0=null;
        Token this_OPENKEY_10=null;
        Token this_EOLINE_11=null;
        Token this_CLOSEKEY_17=null;
        EObject lv_VersionCompiler_2_0 = null;

        EObject lv_imports_5_0 = null;

        EObject lv_attributes_12_0 = null;

        EObject lv_events_13_0 = null;

        EObject lv_modifier_14_0 = null;

        EObject lv_clauses_15_0 = null;

        EObject lv_comments_16_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:78:2: ( ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_contract_6_0= 'contract' ) ) ( (lv_nameContract_7_0= RULE_ID ) ) (otherlv_8= 'is' ( (lv_nameContractFather_9_0= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY (this_EOLINE_11= RULE_EOLINE )? ( (lv_attributes_12_0= ruleAttributes ) )* ( (lv_events_13_0= ruleEvent ) )* ( (lv_modifier_14_0= ruleModifier ) )* ( (lv_clauses_15_0= ruleClause ) )* ( (lv_comments_16_0= ruleComment ) )* this_CLOSEKEY_17= RULE_CLOSEKEY ) )
            // InternalSM2.g:79:2: ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_contract_6_0= 'contract' ) ) ( (lv_nameContract_7_0= RULE_ID ) ) (otherlv_8= 'is' ( (lv_nameContractFather_9_0= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY (this_EOLINE_11= RULE_EOLINE )? ( (lv_attributes_12_0= ruleAttributes ) )* ( (lv_events_13_0= ruleEvent ) )* ( (lv_modifier_14_0= ruleModifier ) )* ( (lv_clauses_15_0= ruleClause ) )* ( (lv_comments_16_0= ruleComment ) )* this_CLOSEKEY_17= RULE_CLOSEKEY )
            {
            // InternalSM2.g:79:2: ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_contract_6_0= 'contract' ) ) ( (lv_nameContract_7_0= RULE_ID ) ) (otherlv_8= 'is' ( (lv_nameContractFather_9_0= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY (this_EOLINE_11= RULE_EOLINE )? ( (lv_attributes_12_0= ruleAttributes ) )* ( (lv_events_13_0= ruleEvent ) )* ( (lv_modifier_14_0= ruleModifier ) )* ( (lv_clauses_15_0= ruleClause ) )* ( (lv_comments_16_0= ruleComment ) )* this_CLOSEKEY_17= RULE_CLOSEKEY )
            // InternalSM2.g:80:3: ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_contract_6_0= 'contract' ) ) ( (lv_nameContract_7_0= RULE_ID ) ) (otherlv_8= 'is' ( (lv_nameContractFather_9_0= RULE_ID ) ) )? this_OPENKEY_10= RULE_OPENKEY (this_EOLINE_11= RULE_EOLINE )? ( (lv_attributes_12_0= ruleAttributes ) )* ( (lv_events_13_0= ruleEvent ) )* ( (lv_modifier_14_0= ruleModifier ) )* ( (lv_clauses_15_0= ruleClause ) )* ( (lv_comments_16_0= ruleComment ) )* this_CLOSEKEY_17= RULE_CLOSEKEY
            {
            // InternalSM2.g:80:3: ( (lv_compiler_0_0= 'pragma' ) )
            // InternalSM2.g:81:4: (lv_compiler_0_0= 'pragma' )
            {
            // InternalSM2.g:81:4: (lv_compiler_0_0= 'pragma' )
            // InternalSM2.g:82:5: lv_compiler_0_0= 'pragma'
            {
            lv_compiler_0_0=(Token)match(input,26,FOLLOW_3); 

            					newLeafNode(lv_compiler_0_0, grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSmartContractRule());
            					}
            					setWithLastConsumed(current, "compiler", lv_compiler_0_0, "pragma");
            				

            }


            }

            otherlv_1=(Token)match(input,27,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getSmartContractAccess().getSolidityKeyword_1());
            		
            // InternalSM2.g:98:3: ( (lv_VersionCompiler_2_0= ruleVersion ) )
            // InternalSM2.g:99:4: (lv_VersionCompiler_2_0= ruleVersion )
            {
            // InternalSM2.g:99:4: (lv_VersionCompiler_2_0= ruleVersion )
            // InternalSM2.g:100:5: lv_VersionCompiler_2_0= ruleVersion
            {

            					newCompositeNode(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_5);
            lv_VersionCompiler_2_0=ruleVersion();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            					}
            					set(
            						current,
            						"VersionCompiler",
            						lv_VersionCompiler_2_0,
            						"org.xtext.SM2.Version");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_SEMICOLON_3=(Token)match(input,RULE_SEMICOLON,FOLLOW_6); 

            			newLeafNode(this_SEMICOLON_3, grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3());
            		
            // InternalSM2.g:121:3: (this_EOLINE_4= RULE_EOLINE )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_EOLINE) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalSM2.g:122:4: this_EOLINE_4= RULE_EOLINE
                    {
                    this_EOLINE_4=(Token)match(input,RULE_EOLINE,FOLLOW_7); 

                    				newLeafNode(this_EOLINE_4, grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4());
                    			

                    }
                    break;

            }

            // InternalSM2.g:127:3: ( (lv_imports_5_0= ruleImport ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==35) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSM2.g:128:4: (lv_imports_5_0= ruleImport )
            	    {
            	    // InternalSM2.g:128:4: (lv_imports_5_0= ruleImport )
            	    // InternalSM2.g:129:5: lv_imports_5_0= ruleImport
            	    {

            	    					newCompositeNode(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_5_0());
            	    				
            	    pushFollow(FOLLOW_7);
            	    lv_imports_5_0=ruleImport();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"imports",
            	    						lv_imports_5_0,
            	    						"org.xtext.SM2.Import");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalSM2.g:146:3: ( (lv_contract_6_0= 'contract' ) )
            // InternalSM2.g:147:4: (lv_contract_6_0= 'contract' )
            {
            // InternalSM2.g:147:4: (lv_contract_6_0= 'contract' )
            // InternalSM2.g:148:5: lv_contract_6_0= 'contract'
            {
            lv_contract_6_0=(Token)match(input,28,FOLLOW_8); 

            					newLeafNode(lv_contract_6_0, grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSmartContractRule());
            					}
            					addWithLastConsumed(current, "contract", lv_contract_6_0, "contract");
            				

            }


            }

            // InternalSM2.g:160:3: ( (lv_nameContract_7_0= RULE_ID ) )
            // InternalSM2.g:161:4: (lv_nameContract_7_0= RULE_ID )
            {
            // InternalSM2.g:161:4: (lv_nameContract_7_0= RULE_ID )
            // InternalSM2.g:162:5: lv_nameContract_7_0= RULE_ID
            {
            lv_nameContract_7_0=(Token)match(input,RULE_ID,FOLLOW_9); 

            					newLeafNode(lv_nameContract_7_0, grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSmartContractRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameContract",
            						lv_nameContract_7_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:178:3: (otherlv_8= 'is' ( (lv_nameContractFather_9_0= RULE_ID ) ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==29) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalSM2.g:179:4: otherlv_8= 'is' ( (lv_nameContractFather_9_0= RULE_ID ) )
                    {
                    otherlv_8=(Token)match(input,29,FOLLOW_8); 

                    				newLeafNode(otherlv_8, grammarAccess.getSmartContractAccess().getIsKeyword_8_0());
                    			
                    // InternalSM2.g:183:4: ( (lv_nameContractFather_9_0= RULE_ID ) )
                    // InternalSM2.g:184:5: (lv_nameContractFather_9_0= RULE_ID )
                    {
                    // InternalSM2.g:184:5: (lv_nameContractFather_9_0= RULE_ID )
                    // InternalSM2.g:185:6: lv_nameContractFather_9_0= RULE_ID
                    {
                    lv_nameContractFather_9_0=(Token)match(input,RULE_ID,FOLLOW_10); 

                    						newLeafNode(lv_nameContractFather_9_0, grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_8_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getSmartContractRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"nameContractFather",
                    							lv_nameContractFather_9_0,
                    							"org.eclipse.xtext.common.Terminals.ID");
                    					

                    }


                    }


                    }
                    break;

            }

            this_OPENKEY_10=(Token)match(input,RULE_OPENKEY,FOLLOW_11); 

            			newLeafNode(this_OPENKEY_10, grammarAccess.getSmartContractAccess().getOPENKEYTerminalRuleCall_9());
            		
            // InternalSM2.g:206:3: (this_EOLINE_11= RULE_EOLINE )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==RULE_EOLINE) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalSM2.g:207:4: this_EOLINE_11= RULE_EOLINE
                    {
                    this_EOLINE_11=(Token)match(input,RULE_EOLINE,FOLLOW_12); 

                    				newLeafNode(this_EOLINE_11, grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_10());
                    			

                    }
                    break;

            }

            // InternalSM2.g:212:3: ( (lv_attributes_12_0= ruleAttributes ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==RULE_ID||LA5_0==40||(LA5_0>=42 && LA5_0<=43)||(LA5_0>=50 && LA5_0<=58)) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalSM2.g:213:4: (lv_attributes_12_0= ruleAttributes )
            	    {
            	    // InternalSM2.g:213:4: (lv_attributes_12_0= ruleAttributes )
            	    // InternalSM2.g:214:5: lv_attributes_12_0= ruleAttributes
            	    {

            	    					newCompositeNode(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_11_0());
            	    				
            	    pushFollow(FOLLOW_12);
            	    lv_attributes_12_0=ruleAttributes();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"attributes",
            	    						lv_attributes_12_0,
            	    						"org.xtext.SM2.Attributes");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            // InternalSM2.g:231:3: ( (lv_events_13_0= ruleEvent ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==37) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalSM2.g:232:4: (lv_events_13_0= ruleEvent )
            	    {
            	    // InternalSM2.g:232:4: (lv_events_13_0= ruleEvent )
            	    // InternalSM2.g:233:5: lv_events_13_0= ruleEvent
            	    {

            	    					newCompositeNode(grammarAccess.getSmartContractAccess().getEventsEventParserRuleCall_12_0());
            	    				
            	    pushFollow(FOLLOW_13);
            	    lv_events_13_0=ruleEvent();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"events",
            	    						lv_events_13_0,
            	    						"org.xtext.SM2.Event");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            // InternalSM2.g:250:3: ( (lv_modifier_14_0= ruleModifier ) )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==38) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalSM2.g:251:4: (lv_modifier_14_0= ruleModifier )
            	    {
            	    // InternalSM2.g:251:4: (lv_modifier_14_0= ruleModifier )
            	    // InternalSM2.g:252:5: lv_modifier_14_0= ruleModifier
            	    {

            	    					newCompositeNode(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_13_0());
            	    				
            	    pushFollow(FOLLOW_14);
            	    lv_modifier_14_0=ruleModifier();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"modifier",
            	    						lv_modifier_14_0,
            	    						"org.xtext.SM2.Modifier");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            // InternalSM2.g:269:3: ( (lv_clauses_15_0= ruleClause ) )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==46) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalSM2.g:270:4: (lv_clauses_15_0= ruleClause )
            	    {
            	    // InternalSM2.g:270:4: (lv_clauses_15_0= ruleClause )
            	    // InternalSM2.g:271:5: lv_clauses_15_0= ruleClause
            	    {

            	    					newCompositeNode(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_14_0());
            	    				
            	    pushFollow(FOLLOW_15);
            	    lv_clauses_15_0=ruleClause();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"clauses",
            	    						lv_clauses_15_0,
            	    						"org.xtext.SM2.Clause");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            // InternalSM2.g:288:3: ( (lv_comments_16_0= ruleComment ) )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( ((LA9_0>=47 && LA9_0<=48)) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalSM2.g:289:4: (lv_comments_16_0= ruleComment )
            	    {
            	    // InternalSM2.g:289:4: (lv_comments_16_0= ruleComment )
            	    // InternalSM2.g:290:5: lv_comments_16_0= ruleComment
            	    {

            	    					newCompositeNode(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_15_0());
            	    				
            	    pushFollow(FOLLOW_16);
            	    lv_comments_16_0=ruleComment();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"comments",
            	    						lv_comments_16_0,
            	    						"org.xtext.SM2.Comment");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

            this_CLOSEKEY_17=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); 

            			newLeafNode(this_CLOSEKEY_17, grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_16());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSmartContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:315:1: entryRuleVersion returns [EObject current=null] : iv_ruleVersion= ruleVersion EOF ;
    public final EObject entryRuleVersion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVersion = null;


        try {
            // InternalSM2.g:315:48: (iv_ruleVersion= ruleVersion EOF )
            // InternalSM2.g:316:2: iv_ruleVersion= ruleVersion EOF
            {
             newCompositeNode(grammarAccess.getVersionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVersion=ruleVersion();

            state._fsp--;

             current =iv_ruleVersion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:322:1: ruleVersion returns [EObject current=null] : ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? ) ) ;
    public final EObject ruleVersion() throws RecognitionException {
        EObject current = null;

        Token lv_symbol_0_0=null;
        Token lv_numberVersion_1_0=null;
        Token this_DOT_2=null;
        Token lv_numberVersion2_3_0=null;
        Token this_DOT_4=null;
        Token lv_numberVersion3_5_0=null;
        Token lv_symbol_6_1=null;
        Token lv_symbol_6_2=null;
        Token lv_numberVersion_7_0=null;
        Token this_DOT_8=null;
        Token lv_numberVersion2_9_0=null;
        Token this_DOT_10=null;
        Token lv_numberVersion3_11_0=null;
        Token lv_symbol2_12_1=null;
        Token lv_symbol2_12_2=null;
        Token lv_numberVersionOptional_13_0=null;
        Token this_DOT_14=null;
        Token lv_numberVersionOptional2_15_0=null;
        Token this_DOT_16=null;
        Token lv_numberVersionOptional3_17_0=null;


        	enterRule();

        try {
            // InternalSM2.g:328:2: ( ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? ) ) )
            // InternalSM2.g:329:2: ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? ) )
            {
            // InternalSM2.g:329:2: ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? ) )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==30) ) {
                alt13=1;
            }
            else if ( ((LA13_0>=31 && LA13_0<=32)) ) {
                alt13=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // InternalSM2.g:330:3: ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) )
                    {
                    // InternalSM2.g:330:3: ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) ) )
                    // InternalSM2.g:331:4: ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_NUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_NUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_NUMBER ) )
                    {
                    // InternalSM2.g:331:4: ( (lv_symbol_0_0= '^' ) )
                    // InternalSM2.g:332:5: (lv_symbol_0_0= '^' )
                    {
                    // InternalSM2.g:332:5: (lv_symbol_0_0= '^' )
                    // InternalSM2.g:333:6: lv_symbol_0_0= '^'
                    {
                    lv_symbol_0_0=(Token)match(input,30,FOLLOW_17); 

                    						newLeafNode(lv_symbol_0_0, grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_0_0, "^");
                    					

                    }


                    }

                    // InternalSM2.g:345:4: ( (lv_numberVersion_1_0= RULE_NUMBER ) )
                    // InternalSM2.g:346:5: (lv_numberVersion_1_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:346:5: (lv_numberVersion_1_0= RULE_NUMBER )
                    // InternalSM2.g:347:6: lv_numberVersion_1_0= RULE_NUMBER
                    {
                    lv_numberVersion_1_0=(Token)match(input,RULE_NUMBER,FOLLOW_18); 

                    						newLeafNode(lv_numberVersion_1_0, grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_0_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"numberVersion",
                    							lv_numberVersion_1_0,
                    							"org.xtext.SM2.NUMBER");
                    					

                    }


                    }

                    this_DOT_2=(Token)match(input,RULE_DOT,FOLLOW_17); 

                    				newLeafNode(this_DOT_2, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_2());
                    			
                    // InternalSM2.g:367:4: ( (lv_numberVersion2_3_0= RULE_NUMBER ) )
                    // InternalSM2.g:368:5: (lv_numberVersion2_3_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:368:5: (lv_numberVersion2_3_0= RULE_NUMBER )
                    // InternalSM2.g:369:6: lv_numberVersion2_3_0= RULE_NUMBER
                    {
                    lv_numberVersion2_3_0=(Token)match(input,RULE_NUMBER,FOLLOW_18); 

                    						newLeafNode(lv_numberVersion2_3_0, grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_0_3_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"numberVersion2",
                    							lv_numberVersion2_3_0,
                    							"org.xtext.SM2.NUMBER");
                    					

                    }


                    }

                    this_DOT_4=(Token)match(input,RULE_DOT,FOLLOW_17); 

                    				newLeafNode(this_DOT_4, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_4());
                    			
                    // InternalSM2.g:389:4: ( (lv_numberVersion3_5_0= RULE_NUMBER ) )
                    // InternalSM2.g:390:5: (lv_numberVersion3_5_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:390:5: (lv_numberVersion3_5_0= RULE_NUMBER )
                    // InternalSM2.g:391:6: lv_numberVersion3_5_0= RULE_NUMBER
                    {
                    lv_numberVersion3_5_0=(Token)match(input,RULE_NUMBER,FOLLOW_2); 

                    						newLeafNode(lv_numberVersion3_5_0, grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_0_5_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"numberVersion3",
                    							lv_numberVersion3_5_0,
                    							"org.xtext.SM2.NUMBER");
                    					

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:409:3: ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? )
                    {
                    // InternalSM2.g:409:3: ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )? )
                    // InternalSM2.g:410:4: ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_NUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_NUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_NUMBER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )?
                    {
                    // InternalSM2.g:410:4: ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) )
                    // InternalSM2.g:411:5: ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) )
                    {
                    // InternalSM2.g:411:5: ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) )
                    // InternalSM2.g:412:6: (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' )
                    {
                    // InternalSM2.g:412:6: (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' )
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==31) ) {
                        alt10=1;
                    }
                    else if ( (LA10_0==32) ) {
                        alt10=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 10, 0, input);

                        throw nvae;
                    }
                    switch (alt10) {
                        case 1 :
                            // InternalSM2.g:413:7: lv_symbol_6_1= '>'
                            {
                            lv_symbol_6_1=(Token)match(input,31,FOLLOW_17); 

                            							newLeafNode(lv_symbol_6_1, grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_1_0_0_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getVersionRule());
                            							}
                            							setWithLastConsumed(current, "symbol", lv_symbol_6_1, null);
                            						

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:424:7: lv_symbol_6_2= '>='
                            {
                            lv_symbol_6_2=(Token)match(input,32,FOLLOW_17); 

                            							newLeafNode(lv_symbol_6_2, grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_1_0_0_1());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getVersionRule());
                            							}
                            							setWithLastConsumed(current, "symbol", lv_symbol_6_2, null);
                            						

                            }
                            break;

                    }


                    }


                    }

                    // InternalSM2.g:437:4: ( (lv_numberVersion_7_0= RULE_NUMBER ) )
                    // InternalSM2.g:438:5: (lv_numberVersion_7_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:438:5: (lv_numberVersion_7_0= RULE_NUMBER )
                    // InternalSM2.g:439:6: lv_numberVersion_7_0= RULE_NUMBER
                    {
                    lv_numberVersion_7_0=(Token)match(input,RULE_NUMBER,FOLLOW_18); 

                    						newLeafNode(lv_numberVersion_7_0, grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_1_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"numberVersion",
                    							lv_numberVersion_7_0,
                    							"org.xtext.SM2.NUMBER");
                    					

                    }


                    }

                    this_DOT_8=(Token)match(input,RULE_DOT,FOLLOW_17); 

                    				newLeafNode(this_DOT_8, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_2());
                    			
                    // InternalSM2.g:459:4: ( (lv_numberVersion2_9_0= RULE_NUMBER ) )
                    // InternalSM2.g:460:5: (lv_numberVersion2_9_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:460:5: (lv_numberVersion2_9_0= RULE_NUMBER )
                    // InternalSM2.g:461:6: lv_numberVersion2_9_0= RULE_NUMBER
                    {
                    lv_numberVersion2_9_0=(Token)match(input,RULE_NUMBER,FOLLOW_18); 

                    						newLeafNode(lv_numberVersion2_9_0, grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_1_3_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"numberVersion2",
                    							lv_numberVersion2_9_0,
                    							"org.xtext.SM2.NUMBER");
                    					

                    }


                    }

                    this_DOT_10=(Token)match(input,RULE_DOT,FOLLOW_17); 

                    				newLeafNode(this_DOT_10, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_4());
                    			
                    // InternalSM2.g:481:4: ( (lv_numberVersion3_11_0= RULE_NUMBER ) )
                    // InternalSM2.g:482:5: (lv_numberVersion3_11_0= RULE_NUMBER )
                    {
                    // InternalSM2.g:482:5: (lv_numberVersion3_11_0= RULE_NUMBER )
                    // InternalSM2.g:483:6: lv_numberVersion3_11_0= RULE_NUMBER
                    {
                    lv_numberVersion3_11_0=(Token)match(input,RULE_NUMBER,FOLLOW_19); 

                    						newLeafNode(lv_numberVersion3_11_0, grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_1_5_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"numberVersion3",
                    							lv_numberVersion3_11_0,
                    							"org.xtext.SM2.NUMBER");
                    					

                    }


                    }

                    // InternalSM2.g:499:4: ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) ) )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( ((LA12_0>=33 && LA12_0<=34)) ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // InternalSM2.g:500:5: ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) )
                            {
                            // InternalSM2.g:500:5: ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) )
                            // InternalSM2.g:501:6: ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) )
                            {
                            // InternalSM2.g:501:6: ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) )
                            // InternalSM2.g:502:7: (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' )
                            {
                            // InternalSM2.g:502:7: (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' )
                            int alt11=2;
                            int LA11_0 = input.LA(1);

                            if ( (LA11_0==33) ) {
                                alt11=1;
                            }
                            else if ( (LA11_0==34) ) {
                                alt11=2;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 11, 0, input);

                                throw nvae;
                            }
                            switch (alt11) {
                                case 1 :
                                    // InternalSM2.g:503:8: lv_symbol2_12_1= '<'
                                    {
                                    lv_symbol2_12_1=(Token)match(input,33,FOLLOW_17); 

                                    								newLeafNode(lv_symbol2_12_1, grammarAccess.getVersionAccess().getSymbol2LessThanSignKeyword_1_6_0_0_0());
                                    							

                                    								if (current==null) {
                                    									current = createModelElement(grammarAccess.getVersionRule());
                                    								}
                                    								setWithLastConsumed(current, "symbol2", lv_symbol2_12_1, null);
                                    							

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:514:8: lv_symbol2_12_2= '<='
                                    {
                                    lv_symbol2_12_2=(Token)match(input,34,FOLLOW_17); 

                                    								newLeafNode(lv_symbol2_12_2, grammarAccess.getVersionAccess().getSymbol2LessThanSignEqualsSignKeyword_1_6_0_0_1());
                                    							

                                    								if (current==null) {
                                    									current = createModelElement(grammarAccess.getVersionRule());
                                    								}
                                    								setWithLastConsumed(current, "symbol2", lv_symbol2_12_2, null);
                                    							

                                    }
                                    break;

                            }


                            }


                            }

                            // InternalSM2.g:527:5: ( (lv_numberVersionOptional_13_0= RULE_NUMBER ) )
                            // InternalSM2.g:528:6: (lv_numberVersionOptional_13_0= RULE_NUMBER )
                            {
                            // InternalSM2.g:528:6: (lv_numberVersionOptional_13_0= RULE_NUMBER )
                            // InternalSM2.g:529:7: lv_numberVersionOptional_13_0= RULE_NUMBER
                            {
                            lv_numberVersionOptional_13_0=(Token)match(input,RULE_NUMBER,FOLLOW_18); 

                            							newLeafNode(lv_numberVersionOptional_13_0, grammarAccess.getVersionAccess().getNumberVersionOptionalNUMBERTerminalRuleCall_1_6_1_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getVersionRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"numberVersionOptional",
                            								lv_numberVersionOptional_13_0,
                            								"org.xtext.SM2.NUMBER");
                            						

                            }


                            }

                            this_DOT_14=(Token)match(input,RULE_DOT,FOLLOW_17); 

                            					newLeafNode(this_DOT_14, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_2());
                            				
                            // InternalSM2.g:549:5: ( (lv_numberVersionOptional2_15_0= RULE_NUMBER ) )
                            // InternalSM2.g:550:6: (lv_numberVersionOptional2_15_0= RULE_NUMBER )
                            {
                            // InternalSM2.g:550:6: (lv_numberVersionOptional2_15_0= RULE_NUMBER )
                            // InternalSM2.g:551:7: lv_numberVersionOptional2_15_0= RULE_NUMBER
                            {
                            lv_numberVersionOptional2_15_0=(Token)match(input,RULE_NUMBER,FOLLOW_18); 

                            							newLeafNode(lv_numberVersionOptional2_15_0, grammarAccess.getVersionAccess().getNumberVersionOptional2NUMBERTerminalRuleCall_1_6_3_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getVersionRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"numberVersionOptional2",
                            								lv_numberVersionOptional2_15_0,
                            								"org.xtext.SM2.NUMBER");
                            						

                            }


                            }

                            this_DOT_16=(Token)match(input,RULE_DOT,FOLLOW_17); 

                            					newLeafNode(this_DOT_16, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_4());
                            				
                            // InternalSM2.g:571:5: ( (lv_numberVersionOptional3_17_0= RULE_NUMBER ) )
                            // InternalSM2.g:572:6: (lv_numberVersionOptional3_17_0= RULE_NUMBER )
                            {
                            // InternalSM2.g:572:6: (lv_numberVersionOptional3_17_0= RULE_NUMBER )
                            // InternalSM2.g:573:7: lv_numberVersionOptional3_17_0= RULE_NUMBER
                            {
                            lv_numberVersionOptional3_17_0=(Token)match(input,RULE_NUMBER,FOLLOW_2); 

                            							newLeafNode(lv_numberVersionOptional3_17_0, grammarAccess.getVersionAccess().getNumberVersionOptional3NUMBERTerminalRuleCall_1_6_5_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getVersionRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"numberVersionOptional3",
                            								lv_numberVersionOptional3_17_0,
                            								"org.xtext.SM2.NUMBER");
                            						

                            }


                            }


                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleImport"
    // InternalSM2.g:595:1: entryRuleImport returns [EObject current=null] : iv_ruleImport= ruleImport EOF ;
    public final EObject entryRuleImport() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleImport = null;


        try {
            // InternalSM2.g:595:47: (iv_ruleImport= ruleImport EOF )
            // InternalSM2.g:596:2: iv_ruleImport= ruleImport EOF
            {
             newCompositeNode(grammarAccess.getImportRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleImport=ruleImport();

            state._fsp--;

             current =iv_ruleImport; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2.g:602:1: ruleImport returns [EObject current=null] : (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) ;
    public final EObject ruleImport() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameLibrary_1_0=null;
        Token otherlv_2=null;
        Token lv_alias_3_0=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;


        	enterRule();

        try {
            // InternalSM2.g:608:2: ( (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:609:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:609:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:610:3: otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,35,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getImportAccess().getImportKeyword_0());
            		
            // InternalSM2.g:614:3: ( (lv_nameLibrary_1_0= RULE_ID ) )
            // InternalSM2.g:615:4: (lv_nameLibrary_1_0= RULE_ID )
            {
            // InternalSM2.g:615:4: (lv_nameLibrary_1_0= RULE_ID )
            // InternalSM2.g:616:5: lv_nameLibrary_1_0= RULE_ID
            {
            lv_nameLibrary_1_0=(Token)match(input,RULE_ID,FOLLOW_20); 

            					newLeafNode(lv_nameLibrary_1_0, grammarAccess.getImportAccess().getNameLibraryIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getImportRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameLibrary",
            						lv_nameLibrary_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2.g:632:3: (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==36) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalSM2.g:633:4: otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,36,FOLLOW_8); 

                    				newLeafNode(otherlv_2, grammarAccess.getImportAccess().getAsKeyword_2_0());
                    			
                    // InternalSM2.g:637:4: ( (lv_alias_3_0= RULE_ID ) )
                    // InternalSM2.g:638:5: (lv_alias_3_0= RULE_ID )
                    {
                    // InternalSM2.g:638:5: (lv_alias_3_0= RULE_ID )
                    // InternalSM2.g:639:6: lv_alias_3_0= RULE_ID
                    {
                    lv_alias_3_0=(Token)match(input,RULE_ID,FOLLOW_5); 

                    						newLeafNode(lv_alias_3_0, grammarAccess.getImportAccess().getAliasIDTerminalRuleCall_2_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getImportRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"alias",
                    							lv_alias_3_0,
                    							"org.eclipse.xtext.common.Terminals.ID");
                    					

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_21); 

            			newLeafNode(this_SEMICOLON_4, grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_3());
            		
            // InternalSM2.g:660:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==RULE_EOLINE) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalSM2.g:661:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_5, grammarAccess.getImportAccess().getEOLINETerminalRuleCall_4());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:670:1: entryRuleAttributes returns [EObject current=null] : iv_ruleAttributes= ruleAttributes EOF ;
    public final EObject entryRuleAttributes() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttributes = null;


        try {
            // InternalSM2.g:670:51: (iv_ruleAttributes= ruleAttributes EOF )
            // InternalSM2.g:671:2: iv_ruleAttributes= ruleAttributes EOF
            {
             newCompositeNode(grammarAccess.getAttributesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAttributes=ruleAttributes();

            state._fsp--;

             current =iv_ruleAttributes; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:677:1: ruleAttributes returns [EObject current=null] : (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) ;
    public final EObject ruleAttributes() throws RecognitionException {
        EObject current = null;

        EObject this_Property_0 = null;

        EObject this_DataType_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:683:2: ( (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) )
            // InternalSM2.g:684:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            {
            // InternalSM2.g:684:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( ((LA16_0>=50 && LA16_0<=58)) ) {
                alt16=1;
            }
            else if ( (LA16_0==RULE_ID||LA16_0==40||(LA16_0>=42 && LA16_0<=43)) ) {
                alt16=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }
            switch (alt16) {
                case 1 :
                    // InternalSM2.g:685:3: this_Property_0= ruleProperty
                    {

                    			newCompositeNode(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Property_0=ruleProperty();

                    state._fsp--;


                    			current = this_Property_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:694:3: this_DataType_1= ruleDataType
                    {

                    			newCompositeNode(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_DataType_1=ruleDataType();

                    state._fsp--;


                    			current = this_DataType_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleEvent"
    // InternalSM2.g:706:1: entryRuleEvent returns [EObject current=null] : iv_ruleEvent= ruleEvent EOF ;
    public final EObject entryRuleEvent() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvent = null;


        try {
            // InternalSM2.g:706:46: (iv_ruleEvent= ruleEvent EOF )
            // InternalSM2.g:707:2: iv_ruleEvent= ruleEvent EOF
            {
             newCompositeNode(grammarAccess.getEventRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEvent=ruleEvent();

            state._fsp--;

             current =iv_ruleEvent; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalSM2.g:713:1: ruleEvent returns [EObject current=null] : (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject ruleEvent() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEvent_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;
        EObject lv_inputParams_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:719:2: ( (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:720:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:720:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:721:3: otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,37,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getEventAccess().getEventKeyword_0());
            		
            // InternalSM2.g:725:3: ( (lv_nameEvent_1_0= RULE_ID ) )
            // InternalSM2.g:726:4: (lv_nameEvent_1_0= RULE_ID )
            {
            // InternalSM2.g:726:4: (lv_nameEvent_1_0= RULE_ID )
            // InternalSM2.g:727:5: lv_nameEvent_1_0= RULE_ID
            {
            lv_nameEvent_1_0=(Token)match(input,RULE_ID,FOLLOW_22); 

            					newLeafNode(lv_nameEvent_1_0, grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEventRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameEvent",
            						lv_nameEvent_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_23); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		
            // InternalSM2.g:747:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( ((LA17_0>=50 && LA17_0<=58)) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalSM2.g:748:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:748:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:749:5: lv_inputParams_3_0= ruleInputParam
            	    {

            	    					newCompositeNode(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_23);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getEventRule());
            	    					}
            	    					add(
            	    						current,
            	    						"inputParams",
            	    						lv_inputParams_3_0,
            	    						"org.xtext.SM2.InputParam");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); 

            			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
            		
            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_21); 

            			newLeafNode(this_SEMICOLON_5, grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5());
            		
            // InternalSM2.g:774:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==RULE_EOLINE) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalSM2.g:775:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_6, grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:784:1: entryRuleModifier returns [EObject current=null] : iv_ruleModifier= ruleModifier EOF ;
    public final EObject entryRuleModifier() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModifier = null;


        try {
            // InternalSM2.g:784:49: (iv_ruleModifier= ruleModifier EOF )
            // InternalSM2.g:785:2: iv_ruleModifier= ruleModifier EOF
            {
             newCompositeNode(grammarAccess.getModifierRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModifier=ruleModifier();

            state._fsp--;

             current =iv_ruleModifier; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:791:1: ruleModifier returns [EObject current=null] : (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? ) ;
    public final EObject ruleModifier() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameModifier_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_EOLINE_6=null;
        Token lv_expr_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Token otherlv_10=null;
        Token this_CLOSEKEY_11=null;
        Token this_EOLINE_12=null;
        EObject lv_inputParams_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:797:2: ( (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? ) )
            // InternalSM2.g:798:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? )
            {
            // InternalSM2.g:798:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )? )
            // InternalSM2.g:799:3: otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_expr_7_0= RULE_STRING ) ) this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= '_;' this_CLOSEKEY_11= RULE_CLOSEKEY (this_EOLINE_12= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,38,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getModifierAccess().getModifierKeyword_0());
            		
            // InternalSM2.g:803:3: ( (lv_nameModifier_1_0= RULE_ID ) )
            // InternalSM2.g:804:4: (lv_nameModifier_1_0= RULE_ID )
            {
            // InternalSM2.g:804:4: (lv_nameModifier_1_0= RULE_ID )
            // InternalSM2.g:805:5: lv_nameModifier_1_0= RULE_ID
            {
            lv_nameModifier_1_0=(Token)match(input,RULE_ID,FOLLOW_22); 

            					newLeafNode(lv_nameModifier_1_0, grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getModifierRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameModifier",
            						lv_nameModifier_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_23); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		
            // InternalSM2.g:825:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( ((LA19_0>=50 && LA19_0<=58)) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalSM2.g:826:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:826:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:827:5: lv_inputParams_3_0= ruleInputParam
            	    {

            	    					newCompositeNode(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_23);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModifierRule());
            	    					}
            	    					add(
            	    						current,
            	    						"inputParams",
            	    						lv_inputParams_3_0,
            	    						"org.xtext.SM2.InputParam");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_10); 

            			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
            		
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_24); 

            			newLeafNode(this_OPENKEY_5, grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5());
            		
            // InternalSM2.g:852:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==RULE_EOLINE) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalSM2.g:853:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_25); 

                    				newLeafNode(this_EOLINE_6, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }

            // InternalSM2.g:858:3: ( (lv_expr_7_0= RULE_STRING ) )
            // InternalSM2.g:859:4: (lv_expr_7_0= RULE_STRING )
            {
            // InternalSM2.g:859:4: (lv_expr_7_0= RULE_STRING )
            // InternalSM2.g:860:5: lv_expr_7_0= RULE_STRING
            {
            lv_expr_7_0=(Token)match(input,RULE_STRING,FOLLOW_5); 

            					newLeafNode(lv_expr_7_0, grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getModifierRule());
            					}
            					setWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_7_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_26); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8());
            		
            // InternalSM2.g:880:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==RULE_EOLINE) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalSM2.g:881:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_27); 

                    				newLeafNode(this_EOLINE_9, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9());
                    			

                    }
                    break;

            }

            otherlv_10=(Token)match(input,39,FOLLOW_28); 

            			newLeafNode(otherlv_10, grammarAccess.getModifierAccess().get_Keyword_10());
            		
            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_21); 

            			newLeafNode(this_CLOSEKEY_11, grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11());
            		
            // InternalSM2.g:894:3: (this_EOLINE_12= RULE_EOLINE )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==RULE_EOLINE) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalSM2.g:895:4: this_EOLINE_12= RULE_EOLINE
                    {
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_12, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:904:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalSM2.g:904:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalSM2.g:905:2: iv_ruleDataType= ruleDataType EOF
            {
             newCompositeNode(grammarAccess.getDataTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;

             current =iv_ruleDataType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:911:1: ruleDataType returns [EObject current=null] : (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        Token this_ID_2=null;
        EObject this_CompositeType_0 = null;

        EObject this_Enum_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:917:2: ( (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID ) )
            // InternalSM2.g:918:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID )
            {
            // InternalSM2.g:918:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID )
            int alt23=3;
            switch ( input.LA(1) ) {
            case 40:
            case 42:
                {
                alt23=1;
                }
                break;
            case 43:
                {
                alt23=2;
                }
                break;
            case RULE_ID:
                {
                alt23=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }

            switch (alt23) {
                case 1 :
                    // InternalSM2.g:919:3: this_CompositeType_0= ruleCompositeType
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_CompositeType_0=ruleCompositeType();

                    state._fsp--;


                    			current = this_CompositeType_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:928:3: this_Enum_1= ruleEnum
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Enum_1=ruleEnum();

                    state._fsp--;


                    			current = this_Enum_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2.g:937:3: this_ID_2= RULE_ID
                    {
                    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			newLeafNode(this_ID_2, grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2.g:945:1: entryRuleCompositeType returns [EObject current=null] : iv_ruleCompositeType= ruleCompositeType EOF ;
    public final EObject entryRuleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompositeType = null;


        try {
            // InternalSM2.g:945:54: (iv_ruleCompositeType= ruleCompositeType EOF )
            // InternalSM2.g:946:2: iv_ruleCompositeType= ruleCompositeType EOF
            {
             newCompositeNode(grammarAccess.getCompositeTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCompositeType=ruleCompositeType();

            state._fsp--;

             current =iv_ruleCompositeType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2.g:952:1: ruleCompositeType returns [EObject current=null] : (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) ;
    public final EObject ruleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject this_Mapping_0 = null;

        EObject this_Struct_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:958:2: ( (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) )
            // InternalSM2.g:959:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            {
            // InternalSM2.g:959:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==40) ) {
                alt24=1;
            }
            else if ( (LA24_0==42) ) {
                alt24=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }
            switch (alt24) {
                case 1 :
                    // InternalSM2.g:960:3: this_Mapping_0= ruleMapping
                    {

                    			newCompositeNode(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Mapping_0=ruleMapping();

                    state._fsp--;


                    			current = this_Mapping_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:969:3: this_Struct_1= ruleStruct
                    {

                    			newCompositeNode(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Struct_1=ruleStruct();

                    state._fsp--;


                    			current = this_Struct_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:981:1: entryRuleMapping returns [EObject current=null] : iv_ruleMapping= ruleMapping EOF ;
    public final EObject entryRuleMapping() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMapping = null;


        try {
            // InternalSM2.g:981:48: (iv_ruleMapping= ruleMapping EOF )
            // InternalSM2.g:982:2: iv_ruleMapping= ruleMapping EOF
            {
             newCompositeNode(grammarAccess.getMappingRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMapping=ruleMapping();

            state._fsp--;

             current =iv_ruleMapping; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:988:1: ruleMapping returns [EObject current=null] : (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON ) ;
    public final EObject ruleMapping() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_3=null;
        Token lv_expr_4_0=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token lv_nameMapping_7_0=null;
        Token this_SEMICOLON_8=null;
        Enumerator lv_type_2_0 = null;

        Enumerator lv_visibility_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:994:2: ( (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON ) )
            // InternalSM2.g:995:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON )
            {
            // InternalSM2.g:995:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON )
            // InternalSM2.g:996:3: otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON
            {
            otherlv_0=(Token)match(input,40,FOLLOW_22); 

            			newLeafNode(otherlv_0, grammarAccess.getMappingAccess().getMappingKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_29); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:1004:3: ( (lv_type_2_0= ruleSingularType ) )
            // InternalSM2.g:1005:4: (lv_type_2_0= ruleSingularType )
            {
            // InternalSM2.g:1005:4: (lv_type_2_0= ruleSingularType )
            // InternalSM2.g:1006:5: lv_type_2_0= ruleSingularType
            {

            					newCompositeNode(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_2_0());
            				
            pushFollow(FOLLOW_30);
            lv_type_2_0=ruleSingularType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMappingRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_2_0,
            						"org.xtext.SM2.SingularType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,41,FOLLOW_25); 

            			newLeafNode(otherlv_3, grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3());
            		
            // InternalSM2.g:1027:3: ( (lv_expr_4_0= RULE_STRING ) )
            // InternalSM2.g:1028:4: (lv_expr_4_0= RULE_STRING )
            {
            // InternalSM2.g:1028:4: (lv_expr_4_0= RULE_STRING )
            // InternalSM2.g:1029:5: lv_expr_4_0= RULE_STRING
            {
            lv_expr_4_0=(Token)match(input,RULE_STRING,FOLLOW_31); 

            					newLeafNode(lv_expr_4_0, grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMappingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_4_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_32); 

            			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
            		
            // InternalSM2.g:1049:3: ( (lv_visibility_6_0= ruleVisibility ) )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( ((LA25_0>=59 && LA25_0<=62)) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalSM2.g:1050:4: (lv_visibility_6_0= ruleVisibility )
                    {
                    // InternalSM2.g:1050:4: (lv_visibility_6_0= ruleVisibility )
                    // InternalSM2.g:1051:5: lv_visibility_6_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0());
                    				
                    pushFollow(FOLLOW_8);
                    lv_visibility_6_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getMappingRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_6_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:1068:3: ( (lv_nameMapping_7_0= RULE_ID ) )
            // InternalSM2.g:1069:4: (lv_nameMapping_7_0= RULE_ID )
            {
            // InternalSM2.g:1069:4: (lv_nameMapping_7_0= RULE_ID )
            // InternalSM2.g:1070:5: lv_nameMapping_7_0= RULE_ID
            {
            lv_nameMapping_7_0=(Token)match(input,RULE_ID,FOLLOW_5); 

            					newLeafNode(lv_nameMapping_7_0, grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMappingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameMapping",
            						lv_nameMapping_7_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); 

            			newLeafNode(this_SEMICOLON_8, grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:1094:1: entryRuleStruct returns [EObject current=null] : iv_ruleStruct= ruleStruct EOF ;
    public final EObject entryRuleStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStruct = null;


        try {
            // InternalSM2.g:1094:47: (iv_ruleStruct= ruleStruct EOF )
            // InternalSM2.g:1095:2: iv_ruleStruct= ruleStruct EOF
            {
             newCompositeNode(grammarAccess.getStructRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStruct=ruleStruct();

            state._fsp--;

             current =iv_ruleStruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:1101:1: ruleStruct returns [EObject current=null] : (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser ) ;
    public final EObject ruleStruct() throws RecognitionException {
        EObject current = null;

        EObject this_PersonalizedStruct_0 = null;

        EObject this_User_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1107:2: ( (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser ) )
            // InternalSM2.g:1108:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser )
            {
            // InternalSM2.g:1108:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser )
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==42) ) {
                int LA26_1 = input.LA(2);

                if ( (LA26_1==RULE_ID) ) {
                    int LA26_2 = input.LA(3);

                    if ( (LA26_2==RULE_OPENKEY) ) {
                        switch ( input.LA(4) ) {
                        case RULE_EOLINE:
                            {
                            int LA26_4 = input.LA(5);

                            if ( (LA26_4==RULE_STRING) ) {
                                alt26=2;
                            }
                            else if ( ((LA26_4>=50 && LA26_4<=58)) ) {
                                alt26=1;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 26, 4, input);

                                throw nvae;
                            }
                            }
                            break;
                        case RULE_STRING:
                            {
                            alt26=2;
                            }
                            break;
                        case 50:
                        case 51:
                        case 52:
                        case 53:
                        case 54:
                        case 55:
                        case 56:
                        case 57:
                        case 58:
                            {
                            alt26=1;
                            }
                            break;
                        default:
                            NoViableAltException nvae =
                                new NoViableAltException("", 26, 3, input);

                            throw nvae;
                        }

                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 26, 2, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 26, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 26, 0, input);

                throw nvae;
            }
            switch (alt26) {
                case 1 :
                    // InternalSM2.g:1109:3: this_PersonalizedStruct_0= rulePersonalizedStruct
                    {

                    			newCompositeNode(grammarAccess.getStructAccess().getPersonalizedStructParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_PersonalizedStruct_0=rulePersonalizedStruct();

                    state._fsp--;


                    			current = this_PersonalizedStruct_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1118:3: this_User_1= ruleUser
                    {

                    			newCompositeNode(grammarAccess.getStructAccess().getUserParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_User_1=ruleUser();

                    state._fsp--;


                    			current = this_User_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRulePersonalizedStruct"
    // InternalSM2.g:1130:1: entryRulePersonalizedStruct returns [EObject current=null] : iv_rulePersonalizedStruct= rulePersonalizedStruct EOF ;
    public final EObject entryRulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonalizedStruct = null;


        try {
            // InternalSM2.g:1130:59: (iv_rulePersonalizedStruct= rulePersonalizedStruct EOF )
            // InternalSM2.g:1131:2: iv_rulePersonalizedStruct= rulePersonalizedStruct EOF
            {
             newCompositeNode(grammarAccess.getPersonalizedStructRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePersonalizedStruct=rulePersonalizedStruct();

            state._fsp--;

             current =iv_rulePersonalizedStruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonalizedStruct"


    // $ANTLR start "rulePersonalizedStruct"
    // InternalSM2.g:1137:1: rulePersonalizedStruct returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject rulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_CLOSEKEY_5=null;
        Token this_EOLINE_6=null;
        EObject lv_properties_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1143:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1144:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1144:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1145:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) ) this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,42,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getPersonalizedStructAccess().getStructKeyword_0());
            		
            // InternalSM2.g:1149:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1150:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1150:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1151:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_10); 

            					newLeafNode(lv_nameStruct_1_0, grammarAccess.getPersonalizedStructAccess().getNameStructIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPersonalizedStructRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameStruct",
            						lv_nameStruct_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_33); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2());
            		
            // InternalSM2.g:1171:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==RULE_EOLINE) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalSM2.g:1172:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_29); 

                    				newLeafNode(this_EOLINE_3, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3());
                    			

                    }
                    break;

            }

            // InternalSM2.g:1177:3: ( (lv_properties_4_0= ruleProperty ) )
            // InternalSM2.g:1178:4: (lv_properties_4_0= ruleProperty )
            {
            // InternalSM2.g:1178:4: (lv_properties_4_0= ruleProperty )
            // InternalSM2.g:1179:5: lv_properties_4_0= ruleProperty
            {

            					newCompositeNode(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_28);
            lv_properties_4_0=ruleProperty();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPersonalizedStructRule());
            					}
            					add(
            						current,
            						"properties",
            						lv_properties_4_0,
            						"org.xtext.SM2.Property");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_21); 

            			newLeafNode(this_CLOSEKEY_5, grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5());
            		
            // InternalSM2.g:1200:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==RULE_EOLINE) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalSM2.g:1201:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_6, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonalizedStruct"


    // $ANTLR start "entryRuleUser"
    // InternalSM2.g:1210:1: entryRuleUser returns [EObject current=null] : iv_ruleUser= ruleUser EOF ;
    public final EObject entryRuleUser() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUser = null;


        try {
            // InternalSM2.g:1210:45: (iv_ruleUser= ruleUser EOF )
            // InternalSM2.g:1211:2: iv_ruleUser= ruleUser EOF
            {
             newCompositeNode(grammarAccess.getUserRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleUser=ruleUser();

            state._fsp--;

             current =iv_ruleUser; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUser"


    // $ANTLR start "ruleUser"
    // InternalSM2.g:1217:1: ruleUser returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_address_4_0= RULE_STRING ) ) this_SEMICOLON_5= RULE_SEMICOLON ( (lv_nameUser_6_0= RULE_STRING ) ) this_SEMICOLON_7= RULE_SEMICOLON ( (lv_lastNameUser_8_0= RULE_STRING ) ) this_SEMICOLON_9= RULE_SEMICOLON ( (lv_email_10_0= RULE_EMAIL ) ) this_SEMICOLON_11= RULE_SEMICOLON ( (lv_amountAccount_12_0= RULE_STRING ) ) this_SEMICOLON_13= RULE_SEMICOLON this_CLOSEKEY_14= RULE_CLOSEKEY (this_EOLINE_15= RULE_EOLINE )? ) ;
    public final EObject ruleUser() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token lv_address_4_0=null;
        Token this_SEMICOLON_5=null;
        Token lv_nameUser_6_0=null;
        Token this_SEMICOLON_7=null;
        Token lv_lastNameUser_8_0=null;
        Token this_SEMICOLON_9=null;
        Token lv_email_10_0=null;
        Token this_SEMICOLON_11=null;
        Token lv_amountAccount_12_0=null;
        Token this_SEMICOLON_13=null;
        Token this_CLOSEKEY_14=null;
        Token this_EOLINE_15=null;


        	enterRule();

        try {
            // InternalSM2.g:1223:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_address_4_0= RULE_STRING ) ) this_SEMICOLON_5= RULE_SEMICOLON ( (lv_nameUser_6_0= RULE_STRING ) ) this_SEMICOLON_7= RULE_SEMICOLON ( (lv_lastNameUser_8_0= RULE_STRING ) ) this_SEMICOLON_9= RULE_SEMICOLON ( (lv_email_10_0= RULE_EMAIL ) ) this_SEMICOLON_11= RULE_SEMICOLON ( (lv_amountAccount_12_0= RULE_STRING ) ) this_SEMICOLON_13= RULE_SEMICOLON this_CLOSEKEY_14= RULE_CLOSEKEY (this_EOLINE_15= RULE_EOLINE )? ) )
            // InternalSM2.g:1224:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_address_4_0= RULE_STRING ) ) this_SEMICOLON_5= RULE_SEMICOLON ( (lv_nameUser_6_0= RULE_STRING ) ) this_SEMICOLON_7= RULE_SEMICOLON ( (lv_lastNameUser_8_0= RULE_STRING ) ) this_SEMICOLON_9= RULE_SEMICOLON ( (lv_email_10_0= RULE_EMAIL ) ) this_SEMICOLON_11= RULE_SEMICOLON ( (lv_amountAccount_12_0= RULE_STRING ) ) this_SEMICOLON_13= RULE_SEMICOLON this_CLOSEKEY_14= RULE_CLOSEKEY (this_EOLINE_15= RULE_EOLINE )? )
            {
            // InternalSM2.g:1224:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_address_4_0= RULE_STRING ) ) this_SEMICOLON_5= RULE_SEMICOLON ( (lv_nameUser_6_0= RULE_STRING ) ) this_SEMICOLON_7= RULE_SEMICOLON ( (lv_lastNameUser_8_0= RULE_STRING ) ) this_SEMICOLON_9= RULE_SEMICOLON ( (lv_email_10_0= RULE_EMAIL ) ) this_SEMICOLON_11= RULE_SEMICOLON ( (lv_amountAccount_12_0= RULE_STRING ) ) this_SEMICOLON_13= RULE_SEMICOLON this_CLOSEKEY_14= RULE_CLOSEKEY (this_EOLINE_15= RULE_EOLINE )? )
            // InternalSM2.g:1225:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_address_4_0= RULE_STRING ) ) this_SEMICOLON_5= RULE_SEMICOLON ( (lv_nameUser_6_0= RULE_STRING ) ) this_SEMICOLON_7= RULE_SEMICOLON ( (lv_lastNameUser_8_0= RULE_STRING ) ) this_SEMICOLON_9= RULE_SEMICOLON ( (lv_email_10_0= RULE_EMAIL ) ) this_SEMICOLON_11= RULE_SEMICOLON ( (lv_amountAccount_12_0= RULE_STRING ) ) this_SEMICOLON_13= RULE_SEMICOLON this_CLOSEKEY_14= RULE_CLOSEKEY (this_EOLINE_15= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,42,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getUserAccess().getStructKeyword_0());
            		
            // InternalSM2.g:1229:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1230:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1230:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1231:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_10); 

            					newLeafNode(lv_nameStruct_1_0, grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameStruct",
            						lv_nameStruct_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_24); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2());
            		
            // InternalSM2.g:1251:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==RULE_EOLINE) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalSM2.g:1252:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_25); 

                    				newLeafNode(this_EOLINE_3, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3());
                    			

                    }
                    break;

            }

            // InternalSM2.g:1257:3: ( (lv_address_4_0= RULE_STRING ) )
            // InternalSM2.g:1258:4: (lv_address_4_0= RULE_STRING )
            {
            // InternalSM2.g:1258:4: (lv_address_4_0= RULE_STRING )
            // InternalSM2.g:1259:5: lv_address_4_0= RULE_STRING
            {
            lv_address_4_0=(Token)match(input,RULE_STRING,FOLLOW_5); 

            					newLeafNode(lv_address_4_0, grammarAccess.getUserAccess().getAddressSTRINGTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"address",
            						lv_address_4_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_25); 

            			newLeafNode(this_SEMICOLON_5, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_5());
            		
            // InternalSM2.g:1279:3: ( (lv_nameUser_6_0= RULE_STRING ) )
            // InternalSM2.g:1280:4: (lv_nameUser_6_0= RULE_STRING )
            {
            // InternalSM2.g:1280:4: (lv_nameUser_6_0= RULE_STRING )
            // InternalSM2.g:1281:5: lv_nameUser_6_0= RULE_STRING
            {
            lv_nameUser_6_0=(Token)match(input,RULE_STRING,FOLLOW_5); 

            					newLeafNode(lv_nameUser_6_0, grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameUser",
            						lv_nameUser_6_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_25); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_7());
            		
            // InternalSM2.g:1301:3: ( (lv_lastNameUser_8_0= RULE_STRING ) )
            // InternalSM2.g:1302:4: (lv_lastNameUser_8_0= RULE_STRING )
            {
            // InternalSM2.g:1302:4: (lv_lastNameUser_8_0= RULE_STRING )
            // InternalSM2.g:1303:5: lv_lastNameUser_8_0= RULE_STRING
            {
            lv_lastNameUser_8_0=(Token)match(input,RULE_STRING,FOLLOW_5); 

            					newLeafNode(lv_lastNameUser_8_0, grammarAccess.getUserAccess().getLastNameUserSTRINGTerminalRuleCall_8_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"lastNameUser",
            						lv_lastNameUser_8_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_34); 

            			newLeafNode(this_SEMICOLON_9, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_9());
            		
            // InternalSM2.g:1323:3: ( (lv_email_10_0= RULE_EMAIL ) )
            // InternalSM2.g:1324:4: (lv_email_10_0= RULE_EMAIL )
            {
            // InternalSM2.g:1324:4: (lv_email_10_0= RULE_EMAIL )
            // InternalSM2.g:1325:5: lv_email_10_0= RULE_EMAIL
            {
            lv_email_10_0=(Token)match(input,RULE_EMAIL,FOLLOW_5); 

            					newLeafNode(lv_email_10_0, grammarAccess.getUserAccess().getEmailEMAILTerminalRuleCall_10_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"email",
            						lv_email_10_0,
            						"org.xtext.SM2.EMAIL");
            				

            }


            }

            this_SEMICOLON_11=(Token)match(input,RULE_SEMICOLON,FOLLOW_25); 

            			newLeafNode(this_SEMICOLON_11, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_11());
            		
            // InternalSM2.g:1345:3: ( (lv_amountAccount_12_0= RULE_STRING ) )
            // InternalSM2.g:1346:4: (lv_amountAccount_12_0= RULE_STRING )
            {
            // InternalSM2.g:1346:4: (lv_amountAccount_12_0= RULE_STRING )
            // InternalSM2.g:1347:5: lv_amountAccount_12_0= RULE_STRING
            {
            lv_amountAccount_12_0=(Token)match(input,RULE_STRING,FOLLOW_5); 

            					newLeafNode(lv_amountAccount_12_0, grammarAccess.getUserAccess().getAmountAccountSTRINGTerminalRuleCall_12_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getUserRule());
            					}
            					setWithLastConsumed(
            						current,
            						"amountAccount",
            						lv_amountAccount_12_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            this_SEMICOLON_13=(Token)match(input,RULE_SEMICOLON,FOLLOW_28); 

            			newLeafNode(this_SEMICOLON_13, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_13());
            		
            this_CLOSEKEY_14=(Token)match(input,RULE_CLOSEKEY,FOLLOW_21); 

            			newLeafNode(this_CLOSEKEY_14, grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_14());
            		
            // InternalSM2.g:1371:3: (this_EOLINE_15= RULE_EOLINE )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==RULE_EOLINE) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalSM2.g:1372:4: this_EOLINE_15= RULE_EOLINE
                    {
                    this_EOLINE_15=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_15, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_15());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUser"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:1381:1: entryRuleEnum returns [EObject current=null] : iv_ruleEnum= ruleEnum EOF ;
    public final EObject entryRuleEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnum = null;


        try {
            // InternalSM2.g:1381:45: (iv_ruleEnum= ruleEnum EOF )
            // InternalSM2.g:1382:2: iv_ruleEnum= ruleEnum EOF
            {
             newCompositeNode(grammarAccess.getEnumRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEnum=ruleEnum();

            state._fsp--;

             current =iv_ruleEnum; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:1388:1: ruleEnum returns [EObject current=null] : (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( (lv_expr_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEnum_1_0=null;
        Token this_OPENKEY_2=null;
        Token lv_expr_3_0=null;
        Token this_COMMA_4=null;
        Token this_CLOSEKEY_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;


        	enterRule();

        try {
            // InternalSM2.g:1394:2: ( (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( (lv_expr_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:1395:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( (lv_expr_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:1395:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( (lv_expr_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:1396:3: otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( (lv_expr_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,43,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getEnumAccess().getEnumKeyword_0());
            		
            // InternalSM2.g:1400:3: ( (lv_nameEnum_1_0= RULE_ID ) )
            // InternalSM2.g:1401:4: (lv_nameEnum_1_0= RULE_ID )
            {
            // InternalSM2.g:1401:4: (lv_nameEnum_1_0= RULE_ID )
            // InternalSM2.g:1402:5: lv_nameEnum_1_0= RULE_ID
            {
            lv_nameEnum_1_0=(Token)match(input,RULE_ID,FOLLOW_10); 

            					newLeafNode(lv_nameEnum_1_0, grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEnumRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameEnum",
            						lv_nameEnum_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_25); 

            			newLeafNode(this_OPENKEY_2, grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2());
            		
            // InternalSM2.g:1422:3: ( (lv_expr_3_0= RULE_STRING ) )
            // InternalSM2.g:1423:4: (lv_expr_3_0= RULE_STRING )
            {
            // InternalSM2.g:1423:4: (lv_expr_3_0= RULE_STRING )
            // InternalSM2.g:1424:5: lv_expr_3_0= RULE_STRING
            {
            lv_expr_3_0=(Token)match(input,RULE_STRING,FOLLOW_35); 

            					newLeafNode(lv_expr_3_0, grammarAccess.getEnumAccess().getExprSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEnumRule());
            					}
            					addWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2.g:1440:3: (this_COMMA_4= RULE_COMMA )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==RULE_COMMA) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalSM2.g:1441:4: this_COMMA_4= RULE_COMMA
                    {
                    this_COMMA_4=(Token)match(input,RULE_COMMA,FOLLOW_28); 

                    				newLeafNode(this_COMMA_4, grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_4());
                    			

                    }
                    break;

            }

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_5); 

            			newLeafNode(this_CLOSEKEY_5, grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_5());
            		
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_21); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_6());
            		
            // InternalSM2.g:1454:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==RULE_EOLINE) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalSM2.g:1455:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_7());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:1464:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // InternalSM2.g:1464:49: (iv_ruleProperty= ruleProperty EOF )
            // InternalSM2.g:1465:2: iv_ruleProperty= ruleProperty EOF
            {
             newCompositeNode(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleProperty=ruleProperty();

            state._fsp--;

             current =iv_ruleProperty; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:1471:1: ruleProperty returns [EObject current=null] : ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        Token lv_nameProperty_2_0=null;
        Token otherlv_3=null;
        Token lv_inicialization_4_0=null;
        Token this_INT_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        Enumerator lv_type_0_0 = null;

        Enumerator lv_visibility_1_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1477:2: ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:1478:2: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:1478:2: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:1479:3: ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:1479:3: ( (lv_type_0_0= ruleSingularType ) )
            // InternalSM2.g:1480:4: (lv_type_0_0= ruleSingularType )
            {
            // InternalSM2.g:1480:4: (lv_type_0_0= ruleSingularType )
            // InternalSM2.g:1481:5: lv_type_0_0= ruleSingularType
            {

            					newCompositeNode(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0());
            				
            pushFollow(FOLLOW_32);
            lv_type_0_0=ruleSingularType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPropertyRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_0_0,
            						"org.xtext.SM2.SingularType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:1498:3: ( (lv_visibility_1_0= ruleVisibility ) )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( ((LA33_0>=59 && LA33_0<=62)) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // InternalSM2.g:1499:4: (lv_visibility_1_0= ruleVisibility )
                    {
                    // InternalSM2.g:1499:4: (lv_visibility_1_0= ruleVisibility )
                    // InternalSM2.g:1500:5: lv_visibility_1_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_8);
                    lv_visibility_1_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_1_0,
                    						"org.xtext.SM2.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:1517:3: ( (lv_nameProperty_2_0= RULE_ID ) )
            // InternalSM2.g:1518:4: (lv_nameProperty_2_0= RULE_ID )
            {
            // InternalSM2.g:1518:4: (lv_nameProperty_2_0= RULE_ID )
            // InternalSM2.g:1519:5: lv_nameProperty_2_0= RULE_ID
            {
            lv_nameProperty_2_0=(Token)match(input,RULE_ID,FOLLOW_36); 

            					newLeafNode(lv_nameProperty_2_0, grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameProperty",
            						lv_nameProperty_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_3=(Token)match(input,44,FOLLOW_37); 

            			newLeafNode(otherlv_3, grammarAccess.getPropertyAccess().getEqualsSignKeyword_3());
            		
            // InternalSM2.g:1539:3: ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )?
            int alt34=3;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==RULE_STRING) ) {
                alt34=1;
            }
            else if ( (LA34_0==RULE_INT) ) {
                alt34=2;
            }
            switch (alt34) {
                case 1 :
                    // InternalSM2.g:1540:4: ( (lv_inicialization_4_0= RULE_STRING ) )
                    {
                    // InternalSM2.g:1540:4: ( (lv_inicialization_4_0= RULE_STRING ) )
                    // InternalSM2.g:1541:5: (lv_inicialization_4_0= RULE_STRING )
                    {
                    // InternalSM2.g:1541:5: (lv_inicialization_4_0= RULE_STRING )
                    // InternalSM2.g:1542:6: lv_inicialization_4_0= RULE_STRING
                    {
                    lv_inicialization_4_0=(Token)match(input,RULE_STRING,FOLLOW_5); 

                    						newLeafNode(lv_inicialization_4_0, grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"inicialization",
                    							lv_inicialization_4_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1559:4: this_INT_5= RULE_INT
                    {
                    this_INT_5=(Token)match(input,RULE_INT,FOLLOW_5); 

                    				newLeafNode(this_INT_5, grammarAccess.getPropertyAccess().getINTTerminalRuleCall_4_1());
                    			

                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_21); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_5());
            		
            // InternalSM2.g:1568:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==RULE_EOLINE) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalSM2.g:1569:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                    				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:1578:1: entryRuleInputParam returns [EObject current=null] : iv_ruleInputParam= ruleInputParam EOF ;
    public final EObject entryRuleInputParam() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputParam = null;


        try {
            // InternalSM2.g:1578:51: (iv_ruleInputParam= ruleInputParam EOF )
            // InternalSM2.g:1579:2: iv_ruleInputParam= ruleInputParam EOF
            {
             newCompositeNode(grammarAccess.getInputParamRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputParam=ruleInputParam();

            state._fsp--;

             current =iv_ruleInputParam; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:1585:1: ruleInputParam returns [EObject current=null] : ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_nameParam_1_0= RULE_ID ) ) ) ( (lv_comma_2_0= RULE_COMMA ) )? ) ;
    public final EObject ruleInputParam() throws RecognitionException {
        EObject current = null;

        Token lv_nameParam_1_0=null;
        Token lv_comma_2_0=null;
        Enumerator lv_type_0_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1591:2: ( ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_nameParam_1_0= RULE_ID ) ) ) ( (lv_comma_2_0= RULE_COMMA ) )? ) )
            // InternalSM2.g:1592:2: ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_nameParam_1_0= RULE_ID ) ) ) ( (lv_comma_2_0= RULE_COMMA ) )? )
            {
            // InternalSM2.g:1592:2: ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_nameParam_1_0= RULE_ID ) ) ) ( (lv_comma_2_0= RULE_COMMA ) )? )
            // InternalSM2.g:1593:3: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_nameParam_1_0= RULE_ID ) ) ) ( (lv_comma_2_0= RULE_COMMA ) )?
            {
            // InternalSM2.g:1593:3: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_nameParam_1_0= RULE_ID ) ) )
            // InternalSM2.g:1594:4: ( (lv_type_0_0= ruleSingularType ) ) ( (lv_nameParam_1_0= RULE_ID ) )
            {
            // InternalSM2.g:1594:4: ( (lv_type_0_0= ruleSingularType ) )
            // InternalSM2.g:1595:5: (lv_type_0_0= ruleSingularType )
            {
            // InternalSM2.g:1595:5: (lv_type_0_0= ruleSingularType )
            // InternalSM2.g:1596:6: lv_type_0_0= ruleSingularType
            {

            						newCompositeNode(grammarAccess.getInputParamAccess().getTypeSingularTypeEnumRuleCall_0_0_0());
            					
            pushFollow(FOLLOW_8);
            lv_type_0_0=ruleSingularType();

            state._fsp--;


            						if (current==null) {
            							current = createModelElementForParent(grammarAccess.getInputParamRule());
            						}
            						set(
            							current,
            							"type",
            							lv_type_0_0,
            							"org.xtext.SM2.SingularType");
            						afterParserOrEnumRuleCall();
            					

            }


            }

            // InternalSM2.g:1613:4: ( (lv_nameParam_1_0= RULE_ID ) )
            // InternalSM2.g:1614:5: (lv_nameParam_1_0= RULE_ID )
            {
            // InternalSM2.g:1614:5: (lv_nameParam_1_0= RULE_ID )
            // InternalSM2.g:1615:6: lv_nameParam_1_0= RULE_ID
            {
            lv_nameParam_1_0=(Token)match(input,RULE_ID,FOLLOW_38); 

            						newLeafNode(lv_nameParam_1_0, grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_1_0());
            					

            						if (current==null) {
            							current = createModelElement(grammarAccess.getInputParamRule());
            						}
            						setWithLastConsumed(
            							current,
            							"nameParam",
            							lv_nameParam_1_0,
            							"org.eclipse.xtext.common.Terminals.ID");
            					

            }


            }


            }

            // InternalSM2.g:1632:3: ( (lv_comma_2_0= RULE_COMMA ) )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==RULE_COMMA) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalSM2.g:1633:4: (lv_comma_2_0= RULE_COMMA )
                    {
                    // InternalSM2.g:1633:4: (lv_comma_2_0= RULE_COMMA )
                    // InternalSM2.g:1634:5: lv_comma_2_0= RULE_COMMA
                    {
                    lv_comma_2_0=(Token)match(input,RULE_COMMA,FOLLOW_2); 

                    					newLeafNode(lv_comma_2_0, grammarAccess.getInputParamAccess().getCommaCOMMATerminalRuleCall_1_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getInputParamRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"comma",
                    						lv_comma_2_0,
                    						"org.xtext.SM2.COMMA");
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:1654:1: entryRuleRestriction returns [EObject current=null] : iv_ruleRestriction= ruleRestriction EOF ;
    public final EObject entryRuleRestriction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestriction = null;


        try {
            // InternalSM2.g:1654:52: (iv_ruleRestriction= ruleRestriction EOF )
            // InternalSM2.g:1655:2: iv_ruleRestriction= ruleRestriction EOF
            {
             newCompositeNode(grammarAccess.getRestrictionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestriction=ruleRestriction();

            state._fsp--;

             current =iv_ruleRestriction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:1661:1: ruleRestriction returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) ;
    public final EObject ruleRestriction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        EObject lv_expr1_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        EObject lv_expr2_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1667:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) )
            // InternalSM2.g:1668:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            {
            // InternalSM2.g:1668:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            // InternalSM2.g:1669:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,45,FOLLOW_22); 

            			newLeafNode(otherlv_0, grammarAccess.getRestrictionAccess().getRequireKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_39); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:1677:3: ( (lv_expr1_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:1678:4: (lv_expr1_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:1678:4: (lv_expr1_2_0= ruleSyntaxExpression )
            // InternalSM2.g:1679:5: lv_expr1_2_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr1SyntaxExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_40);
            lv_expr1_2_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"expr1",
            						lv_expr1_2_0,
            						"org.xtext.SM2.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:1696:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:1697:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:1697:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:1698:5: lv_operator_3_0= ruleComparationOperator
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_39);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"operator",
            						lv_operator_3_0,
            						"org.xtext.SM2.ComparationOperator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:1715:3: ( (lv_expr2_4_0= ruleSyntaxExpression ) )
            // InternalSM2.g:1716:4: (lv_expr2_4_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:1716:4: (lv_expr2_4_0= ruleSyntaxExpression )
            // InternalSM2.g:1717:5: lv_expr2_4_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr2SyntaxExpressionParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_31);
            lv_expr2_4_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"expr2",
            						lv_expr2_4_0,
            						"org.xtext.SM2.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); 

            			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
            		
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_41); 

            			newLeafNode(this_SEMICOLON_6, grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6());
            		
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_7, grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:1750:1: entryRuleRestrictionGas returns [EObject current=null] : iv_ruleRestrictionGas= ruleRestrictionGas EOF ;
    public final EObject entryRuleRestrictionGas() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionGas = null;


        try {
            // InternalSM2.g:1750:55: (iv_ruleRestrictionGas= ruleRestrictionGas EOF )
            // InternalSM2.g:1751:2: iv_ruleRestrictionGas= ruleRestrictionGas EOF
            {
             newCompositeNode(grammarAccess.getRestrictionGasRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionGas=ruleRestrictionGas();

            state._fsp--;

             current =iv_ruleRestrictionGas; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:1757:1: ruleRestrictionGas returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) ;
    public final EObject ruleRestrictionGas() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_amount_4_0=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        EObject lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        Enumerator lv_typeCoin_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1763:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) )
            // InternalSM2.g:1764:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            {
            // InternalSM2.g:1764:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            // InternalSM2.g:1765:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,45,FOLLOW_22); 

            			newLeafNode(otherlv_0, grammarAccess.getRestrictionGasAccess().getRequireKeyword_0());
            		
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_39); 

            			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1());
            		
            // InternalSM2.g:1773:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:1774:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:1774:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2.g:1775:5: lv_expr_2_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_40);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_2_0,
            						"org.xtext.SM2.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:1792:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:1793:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:1793:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:1794:5: lv_operator_3_0= ruleComparationOperator
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_42);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"operator",
            						lv_operator_3_0,
            						"org.xtext.SM2.ComparationOperator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:1811:3: ( (lv_amount_4_0= RULE_INT ) )
            // InternalSM2.g:1812:4: (lv_amount_4_0= RULE_INT )
            {
            // InternalSM2.g:1812:4: (lv_amount_4_0= RULE_INT )
            // InternalSM2.g:1813:5: lv_amount_4_0= RULE_INT
            {
            lv_amount_4_0=(Token)match(input,RULE_INT,FOLLOW_43); 

            					newLeafNode(lv_amount_4_0, grammarAccess.getRestrictionGasAccess().getAmountINTTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRestrictionGasRule());
            					}
            					setWithLastConsumed(
            						current,
            						"amount",
            						lv_amount_4_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalSM2.g:1829:3: ( (lv_typeCoin_5_0= ruleCoin ) )
            // InternalSM2.g:1830:4: (lv_typeCoin_5_0= ruleCoin )
            {
            // InternalSM2.g:1830:4: (lv_typeCoin_5_0= ruleCoin )
            // InternalSM2.g:1831:5: lv_typeCoin_5_0= ruleCoin
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0());
            				
            pushFollow(FOLLOW_31);
            lv_typeCoin_5_0=ruleCoin();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"typeCoin",
            						lv_typeCoin_5_0,
            						"org.xtext.SM2.Coin");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); 

            			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
            		
            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_41); 

            			newLeafNode(this_SEMICOLON_7, grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7());
            		
            this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_8, grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2.g:1864:1: entryRuleClause returns [EObject current=null] : iv_ruleClause= ruleClause EOF ;
    public final EObject entryRuleClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClause = null;


        try {
            // InternalSM2.g:1864:47: (iv_ruleClause= ruleClause EOF )
            // InternalSM2.g:1865:2: iv_ruleClause= ruleClause EOF
            {
             newCompositeNode(grammarAccess.getClauseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleClause=ruleClause();

            state._fsp--;

             current =iv_ruleClause; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2.g:1871:1: ruleClause returns [EObject current=null] : (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY this_EOLINE_8= RULE_EOLINE ( (lv_restriction_9_0= ruleRestriction ) )? ( (lv_restrictionGas_10_0= ruleRestrictionGas ) )? ( (lv_expression_11_0= ruleExpression ) )? (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE ) ;
    public final EObject ruleClause() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameFunction_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token this_OPENKEY_7=null;
        Token this_EOLINE_8=null;
        Token this_EOLINE_12=null;
        Token this_CLOSEKEY_13=null;
        Token this_EOLINE_14=null;
        Enumerator lv_visibilityAccess_4_0 = null;

        EObject lv_restriction_9_0 = null;

        EObject lv_restrictionGas_10_0 = null;

        EObject lv_expression_11_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1877:2: ( (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY this_EOLINE_8= RULE_EOLINE ( (lv_restriction_9_0= ruleRestriction ) )? ( (lv_restrictionGas_10_0= ruleRestrictionGas ) )? ( (lv_expression_11_0= ruleExpression ) )? (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE ) )
            // InternalSM2.g:1878:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY this_EOLINE_8= RULE_EOLINE ( (lv_restriction_9_0= ruleRestriction ) )? ( (lv_restrictionGas_10_0= ruleRestrictionGas ) )? ( (lv_expression_11_0= ruleExpression ) )? (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE )
            {
            // InternalSM2.g:1878:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY this_EOLINE_8= RULE_EOLINE ( (lv_restriction_9_0= ruleRestriction ) )? ( (lv_restrictionGas_10_0= ruleRestrictionGas ) )? ( (lv_expression_11_0= ruleExpression ) )? (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE )
            // InternalSM2.g:1879:3: otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_OPENKEY_7= RULE_OPENKEY this_EOLINE_8= RULE_EOLINE ( (lv_restriction_9_0= ruleRestriction ) )? ( (lv_restrictionGas_10_0= ruleRestrictionGas ) )? ( (lv_expression_11_0= ruleExpression ) )? (this_EOLINE_12= RULE_EOLINE )? this_CLOSEKEY_13= RULE_CLOSEKEY this_EOLINE_14= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,46,FOLLOW_8); 

            			newLeafNode(otherlv_0, grammarAccess.getClauseAccess().getFunctionKeyword_0());
            		
            // InternalSM2.g:1883:3: ( (lv_nameFunction_1_0= RULE_ID ) )
            // InternalSM2.g:1884:4: (lv_nameFunction_1_0= RULE_ID )
            {
            // InternalSM2.g:1884:4: (lv_nameFunction_1_0= RULE_ID )
            // InternalSM2.g:1885:5: lv_nameFunction_1_0= RULE_ID
            {
            lv_nameFunction_1_0=(Token)match(input,RULE_ID,FOLLOW_22); 

            					newLeafNode(lv_nameFunction_1_0, grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getClauseRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameFunction",
            						lv_nameFunction_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_8); 

            			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2());
            		
            // InternalSM2.g:1905:3: ( (otherlv_3= RULE_ID ) )
            // InternalSM2.g:1906:4: (otherlv_3= RULE_ID )
            {
            // InternalSM2.g:1906:4: (otherlv_3= RULE_ID )
            // InternalSM2.g:1907:5: otherlv_3= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getClauseRule());
            					}
            				
            otherlv_3=(Token)match(input,RULE_ID,FOLLOW_44); 

            					newLeafNode(otherlv_3, grammarAccess.getClauseAccess().getInputParamsInputParamCrossReference_3_0());
            				

            }


            }

            // InternalSM2.g:1918:3: ( (lv_visibilityAccess_4_0= ruleVisibility ) )
            // InternalSM2.g:1919:4: (lv_visibilityAccess_4_0= ruleVisibility )
            {
            // InternalSM2.g:1919:4: (lv_visibilityAccess_4_0= ruleVisibility )
            // InternalSM2.g:1920:5: lv_visibilityAccess_4_0= ruleVisibility
            {

            					newCompositeNode(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0());
            				
            pushFollow(FOLLOW_45);
            lv_visibilityAccess_4_0=ruleVisibility();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getClauseRule());
            					}
            					set(
            						current,
            						"visibilityAccess",
            						lv_visibilityAccess_4_0,
            						"org.xtext.SM2.Visibility");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2.g:1937:3: ( (otherlv_5= RULE_ID ) )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==RULE_ID) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalSM2.g:1938:4: (otherlv_5= RULE_ID )
                    {
                    // InternalSM2.g:1938:4: (otherlv_5= RULE_ID )
                    // InternalSM2.g:1939:5: otherlv_5= RULE_ID
                    {

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getClauseRule());
                    					}
                    				
                    otherlv_5=(Token)match(input,RULE_ID,FOLLOW_31); 

                    					newLeafNode(otherlv_5, grammarAccess.getClauseAccess().getModifierModifierCrossReference_5_0());
                    				

                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_10); 

            			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
            		
            this_OPENKEY_7=(Token)match(input,RULE_OPENKEY,FOLLOW_41); 

            			newLeafNode(this_OPENKEY_7, grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_7());
            		
            this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_46); 

            			newLeafNode(this_EOLINE_8, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_8());
            		
            // InternalSM2.g:1962:3: ( (lv_restriction_9_0= ruleRestriction ) )?
            int alt38=2;
            alt38 = dfa38.predict(input);
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:1963:4: (lv_restriction_9_0= ruleRestriction )
                    {
                    // InternalSM2.g:1963:4: (lv_restriction_9_0= ruleRestriction )
                    // InternalSM2.g:1964:5: lv_restriction_9_0= ruleRestriction
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_9_0());
                    				
                    pushFollow(FOLLOW_46);
                    lv_restriction_9_0=ruleRestriction();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"restriction",
                    						lv_restriction_9_0,
                    						"org.xtext.SM2.Restriction");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:1981:3: ( (lv_restrictionGas_10_0= ruleRestrictionGas ) )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==45) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalSM2.g:1982:4: (lv_restrictionGas_10_0= ruleRestrictionGas )
                    {
                    // InternalSM2.g:1982:4: (lv_restrictionGas_10_0= ruleRestrictionGas )
                    // InternalSM2.g:1983:5: lv_restrictionGas_10_0= ruleRestrictionGas
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_10_0());
                    				
                    pushFollow(FOLLOW_47);
                    lv_restrictionGas_10_0=ruleRestrictionGas();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"restrictionGas",
                    						lv_restrictionGas_10_0,
                    						"org.xtext.SM2.RestrictionGas");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:2000:3: ( (lv_expression_11_0= ruleExpression ) )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==RULE_OPENPARENTHESIS||LA40_0==RULE_STRING||LA40_0==RULE_INT) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalSM2.g:2001:4: (lv_expression_11_0= ruleExpression )
                    {
                    // InternalSM2.g:2001:4: (lv_expression_11_0= ruleExpression )
                    // InternalSM2.g:2002:5: lv_expression_11_0= ruleExpression
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_11_0());
                    				
                    pushFollow(FOLLOW_48);
                    lv_expression_11_0=ruleExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"expression",
                    						lv_expression_11_0,
                    						"org.xtext.SM2.Expression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2.g:2019:3: (this_EOLINE_12= RULE_EOLINE )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==RULE_EOLINE) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalSM2.g:2020:4: this_EOLINE_12= RULE_EOLINE
                    {
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_28); 

                    				newLeafNode(this_EOLINE_12, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_12());
                    			

                    }
                    break;

            }

            this_CLOSEKEY_13=(Token)match(input,RULE_CLOSEKEY,FOLLOW_41); 

            			newLeafNode(this_CLOSEKEY_13, grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_13());
            		
            this_EOLINE_14=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_14, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_14());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:2037:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // InternalSM2.g:2037:51: (iv_ruleExpression= ruleExpression EOF )
            // InternalSM2.g:2038:2: iv_ruleExpression= ruleExpression EOF
            {
             newCompositeNode(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;

             current =iv_ruleExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:2044:1: ruleExpression returns [EObject current=null] : (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_SyntaxExpression_1= ruleSyntaxExpression ) ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_ArithmethicalExpression_0 = null;

        EObject this_SyntaxExpression_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:2050:2: ( (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_SyntaxExpression_1= ruleSyntaxExpression ) )
            // InternalSM2.g:2051:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_SyntaxExpression_1= ruleSyntaxExpression )
            {
            // InternalSM2.g:2051:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_SyntaxExpression_1= ruleSyntaxExpression )
            int alt42=2;
            switch ( input.LA(1) ) {
            case RULE_OPENPARENTHESIS:
                {
                alt42=1;
                }
                break;
            case RULE_INT:
                {
                int LA42_2 = input.LA(2);

                if ( ((LA42_2>=73 && LA42_2<=76)) ) {
                    alt42=1;
                }
                else if ( (LA42_2==EOF||(LA42_2>=RULE_SEMICOLON && LA42_2<=RULE_EOLINE)||LA42_2==RULE_CLOSEKEY) ) {
                    alt42=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 42, 2, input);

                    throw nvae;
                }
                }
                break;
            case RULE_STRING:
                {
                alt42=2;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 42, 0, input);

                throw nvae;
            }

            switch (alt42) {
                case 1 :
                    // InternalSM2.g:2052:3: this_ArithmethicalExpression_0= ruleArithmethicalExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalExpression_0=ruleArithmethicalExpression();

                    state._fsp--;


                    			current = this_ArithmethicalExpression_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2061:3: this_SyntaxExpression_1= ruleSyntaxExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_SyntaxExpression_1=ruleSyntaxExpression();

                    state._fsp--;


                    			current = this_SyntaxExpression_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleArithmethicalExpression"
    // InternalSM2.g:2073:1: entryRuleArithmethicalExpression returns [EObject current=null] : iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF ;
    public final EObject entryRuleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalExpression = null;


        try {
            // InternalSM2.g:2073:64: (iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF )
            // InternalSM2.g:2074:2: iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF
            {
             newCompositeNode(grammarAccess.getArithmethicalExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalExpression=ruleArithmethicalExpression();

            state._fsp--;

             current =iv_ruleArithmethicalExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalExpression"


    // $ANTLR start "ruleArithmethicalExpression"
    // InternalSM2.g:2080:1: ruleArithmethicalExpression returns [EObject current=null] : ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INT ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INT ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= RULE_INT ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INT ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) ) ;
    public final EObject ruleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token lv_op1_1_0=null;
        Token lv_op2_3_0=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token lv_op1_5_0=null;
        Token lv_op2_7_0=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Enumerator lv_operator_2_0 = null;

        Enumerator lv_operator_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2086:2: ( ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INT ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INT ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= RULE_INT ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INT ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) ) )
            // InternalSM2.g:2087:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INT ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INT ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= RULE_INT ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INT ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:2087:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INT ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INT ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= RULE_INT ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INT ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) )
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==RULE_OPENPARENTHESIS) ) {
                alt44=1;
            }
            else if ( (LA44_0==RULE_INT) ) {
                alt44=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 44, 0, input);

                throw nvae;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:2088:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INT ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INT ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:2088:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INT ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INT ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:2089:4: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= RULE_INT ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INT ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                    {
                    this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_42); 

                    				newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0());
                    			
                    // InternalSM2.g:2093:4: ( (lv_op1_1_0= RULE_INT ) )
                    // InternalSM2.g:2094:5: (lv_op1_1_0= RULE_INT )
                    {
                    // InternalSM2.g:2094:5: (lv_op1_1_0= RULE_INT )
                    // InternalSM2.g:2095:6: lv_op1_1_0= RULE_INT
                    {
                    lv_op1_1_0=(Token)match(input,RULE_INT,FOLLOW_49); 

                    						newLeafNode(lv_op1_1_0, grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_0_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"op1",
                    							lv_op1_1_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    // InternalSM2.g:2111:4: ( (lv_operator_2_0= ruleArithmeticalOperator ) )
                    // InternalSM2.g:2112:5: (lv_operator_2_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2.g:2112:5: (lv_operator_2_0= ruleArithmeticalOperator )
                    // InternalSM2.g:2113:6: lv_operator_2_0= ruleArithmeticalOperator
                    {

                    						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0());
                    					
                    pushFollow(FOLLOW_42);
                    lv_operator_2_0=ruleArithmeticalOperator();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                    						}
                    						set(
                    							current,
                    							"operator",
                    							lv_operator_2_0,
                    							"org.xtext.SM2.ArithmeticalOperator");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalSM2.g:2130:4: ( (lv_op2_3_0= RULE_INT ) )
                    // InternalSM2.g:2131:5: (lv_op2_3_0= RULE_INT )
                    {
                    // InternalSM2.g:2131:5: (lv_op2_3_0= RULE_INT )
                    // InternalSM2.g:2132:6: lv_op2_3_0= RULE_INT
                    {
                    lv_op2_3_0=(Token)match(input,RULE_INT,FOLLOW_31); 

                    						newLeafNode(lv_op2_3_0, grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_0_3_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"op2",
                    							lv_op2_3_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 

                    				newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2154:3: ( ( (lv_op1_5_0= RULE_INT ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INT ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:2154:3: ( ( (lv_op1_5_0= RULE_INT ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INT ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? )
                    // InternalSM2.g:2155:4: ( (lv_op1_5_0= RULE_INT ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INT ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )?
                    {
                    // InternalSM2.g:2155:4: ( (lv_op1_5_0= RULE_INT ) )
                    // InternalSM2.g:2156:5: (lv_op1_5_0= RULE_INT )
                    {
                    // InternalSM2.g:2156:5: (lv_op1_5_0= RULE_INT )
                    // InternalSM2.g:2157:6: lv_op1_5_0= RULE_INT
                    {
                    lv_op1_5_0=(Token)match(input,RULE_INT,FOLLOW_49); 

                    						newLeafNode(lv_op1_5_0, grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_1_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"op1",
                    							lv_op1_5_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    // InternalSM2.g:2173:4: ( (lv_operator_6_0= ruleArithmeticalOperator ) )
                    // InternalSM2.g:2174:5: (lv_operator_6_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2.g:2174:5: (lv_operator_6_0= ruleArithmeticalOperator )
                    // InternalSM2.g:2175:6: lv_operator_6_0= ruleArithmeticalOperator
                    {

                    						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0());
                    					
                    pushFollow(FOLLOW_42);
                    lv_operator_6_0=ruleArithmeticalOperator();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                    						}
                    						set(
                    							current,
                    							"operator",
                    							lv_operator_6_0,
                    							"org.xtext.SM2.ArithmeticalOperator");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalSM2.g:2192:4: ( (lv_op2_7_0= RULE_INT ) )
                    // InternalSM2.g:2193:5: (lv_op2_7_0= RULE_INT )
                    {
                    // InternalSM2.g:2193:5: (lv_op2_7_0= RULE_INT )
                    // InternalSM2.g:2194:6: lv_op2_7_0= RULE_INT
                    {
                    lv_op2_7_0=(Token)match(input,RULE_INT,FOLLOW_50); 

                    						newLeafNode(lv_op2_7_0, grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_1_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"op2",
                    							lv_op2_7_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    // InternalSM2.g:2210:4: (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )?
                    int alt43=2;
                    int LA43_0 = input.LA(1);

                    if ( (LA43_0==RULE_SEMICOLON) ) {
                        alt43=1;
                    }
                    switch (alt43) {
                        case 1 :
                            // InternalSM2.g:2211:5: this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE
                            {
                            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_41); 

                            					newLeafNode(this_SEMICOLON_8, grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0());
                            				
                            this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                            					newLeafNode(this_EOLINE_9, grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:2225:1: entryRuleSyntaxExpression returns [EObject current=null] : iv_ruleSyntaxExpression= ruleSyntaxExpression EOF ;
    public final EObject entryRuleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSyntaxExpression = null;


        try {
            // InternalSM2.g:2225:57: (iv_ruleSyntaxExpression= ruleSyntaxExpression EOF )
            // InternalSM2.g:2226:2: iv_ruleSyntaxExpression= ruleSyntaxExpression EOF
            {
             newCompositeNode(grammarAccess.getSyntaxExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSyntaxExpression=ruleSyntaxExpression();

            state._fsp--;

             current =iv_ruleSyntaxExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:2232:1: ruleSyntaxExpression returns [EObject current=null] : ( ( (lv_text_0_0= RULE_STRING ) ) | (this_INT_1= RULE_INT (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) ) ;
    public final EObject ruleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        Token lv_text_0_0=null;
        Token this_INT_1=null;
        Token this_SEMICOLON_2=null;
        Token this_EOLINE_3=null;


        	enterRule();

        try {
            // InternalSM2.g:2238:2: ( ( ( (lv_text_0_0= RULE_STRING ) ) | (this_INT_1= RULE_INT (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) ) )
            // InternalSM2.g:2239:2: ( ( (lv_text_0_0= RULE_STRING ) ) | (this_INT_1= RULE_INT (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:2239:2: ( ( (lv_text_0_0= RULE_STRING ) ) | (this_INT_1= RULE_INT (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) )
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==RULE_STRING) ) {
                alt46=1;
            }
            else if ( (LA46_0==RULE_INT) ) {
                alt46=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 46, 0, input);

                throw nvae;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:2240:3: ( (lv_text_0_0= RULE_STRING ) )
                    {
                    // InternalSM2.g:2240:3: ( (lv_text_0_0= RULE_STRING ) )
                    // InternalSM2.g:2241:4: (lv_text_0_0= RULE_STRING )
                    {
                    // InternalSM2.g:2241:4: (lv_text_0_0= RULE_STRING )
                    // InternalSM2.g:2242:5: lv_text_0_0= RULE_STRING
                    {
                    lv_text_0_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    					newLeafNode(lv_text_0_0, grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getSyntaxExpressionRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"text",
                    						lv_text_0_0,
                    						"org.eclipse.xtext.common.Terminals.STRING");
                    				

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2259:3: (this_INT_1= RULE_INT (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:2259:3: (this_INT_1= RULE_INT (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
                    // InternalSM2.g:2260:4: this_INT_1= RULE_INT (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
                    {
                    this_INT_1=(Token)match(input,RULE_INT,FOLLOW_50); 

                    				newLeafNode(this_INT_1, grammarAccess.getSyntaxExpressionAccess().getINTTerminalRuleCall_1_0());
                    			
                    // InternalSM2.g:2264:4: (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
                    int alt45=2;
                    int LA45_0 = input.LA(1);

                    if ( (LA45_0==RULE_SEMICOLON) ) {
                        alt45=1;
                    }
                    switch (alt45) {
                        case 1 :
                            // InternalSM2.g:2265:5: this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE
                            {
                            this_SEMICOLON_2=(Token)match(input,RULE_SEMICOLON,FOLLOW_41); 

                            					newLeafNode(this_SEMICOLON_2, grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0());
                            				
                            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

                            					newLeafNode(this_EOLINE_3, grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:2279:1: entryRuleComment returns [EObject current=null] : iv_ruleComment= ruleComment EOF ;
    public final EObject entryRuleComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleComment = null;


        try {
            // InternalSM2.g:2279:48: (iv_ruleComment= ruleComment EOF )
            // InternalSM2.g:2280:2: iv_ruleComment= ruleComment EOF
            {
             newCompositeNode(grammarAccess.getCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleComment=ruleComment();

            state._fsp--;

             current =iv_ruleComment; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:2286:1: ruleComment returns [EObject current=null] : (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) ;
    public final EObject ruleComment() throws RecognitionException {
        EObject current = null;

        EObject this_ShortComment_0 = null;

        EObject this_LongComment_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:2292:2: ( (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) )
            // InternalSM2.g:2293:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            {
            // InternalSM2.g:2293:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==47) ) {
                alt47=1;
            }
            else if ( (LA47_0==48) ) {
                alt47=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 47, 0, input);

                throw nvae;
            }
            switch (alt47) {
                case 1 :
                    // InternalSM2.g:2294:3: this_ShortComment_0= ruleShortComment
                    {

                    			newCompositeNode(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_ShortComment_0=ruleShortComment();

                    state._fsp--;


                    			current = this_ShortComment_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2303:3: this_LongComment_1= ruleLongComment
                    {

                    			newCompositeNode(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_LongComment_1=ruleLongComment();

                    state._fsp--;


                    			current = this_LongComment_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:2315:1: entryRuleShortComment returns [EObject current=null] : iv_ruleShortComment= ruleShortComment EOF ;
    public final EObject entryRuleShortComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleShortComment = null;


        try {
            // InternalSM2.g:2315:53: (iv_ruleShortComment= ruleShortComment EOF )
            // InternalSM2.g:2316:2: iv_ruleShortComment= ruleShortComment EOF
            {
             newCompositeNode(grammarAccess.getShortCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleShortComment=ruleShortComment();

            state._fsp--;

             current =iv_ruleShortComment; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:2322:1: ruleShortComment returns [EObject current=null] : (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) this_EOLINE_2= RULE_EOLINE ) ;
    public final EObject ruleShortComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expr_1_0=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:2328:2: ( (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) this_EOLINE_2= RULE_EOLINE ) )
            // InternalSM2.g:2329:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) this_EOLINE_2= RULE_EOLINE )
            {
            // InternalSM2.g:2329:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) this_EOLINE_2= RULE_EOLINE )
            // InternalSM2.g:2330:3: otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) this_EOLINE_2= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,47,FOLLOW_25); 

            			newLeafNode(otherlv_0, grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0());
            		
            // InternalSM2.g:2334:3: ( (lv_expr_1_0= RULE_STRING ) )
            // InternalSM2.g:2335:4: (lv_expr_1_0= RULE_STRING )
            {
            // InternalSM2.g:2335:4: (lv_expr_1_0= RULE_STRING )
            // InternalSM2.g:2336:5: lv_expr_1_0= RULE_STRING
            {
            lv_expr_1_0=(Token)match(input,RULE_STRING,FOLLOW_41); 

            					newLeafNode(lv_expr_1_0, grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getShortCommentRule());
            					}
            					setWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); 

            			newLeafNode(this_EOLINE_2, grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:2360:1: entryRuleLongComment returns [EObject current=null] : iv_ruleLongComment= ruleLongComment EOF ;
    public final EObject entryRuleLongComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLongComment = null;


        try {
            // InternalSM2.g:2360:52: (iv_ruleLongComment= ruleLongComment EOF )
            // InternalSM2.g:2361:2: iv_ruleLongComment= ruleLongComment EOF
            {
             newCompositeNode(grammarAccess.getLongCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLongComment=ruleLongComment();

            state._fsp--;

             current =iv_ruleLongComment; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:2367:1: ruleLongComment returns [EObject current=null] : (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) otherlv_2= '*/' ) ;
    public final EObject ruleLongComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expression_1_1=null;
        Token lv_expression_1_2=null;
        Token lv_expression_1_3=null;
        Token lv_expression_1_4=null;
        Token lv_expression_1_5=null;
        Token lv_expression_1_6=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSM2.g:2373:2: ( (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) otherlv_2= '*/' ) )
            // InternalSM2.g:2374:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) otherlv_2= '*/' )
            {
            // InternalSM2.g:2374:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) otherlv_2= '*/' )
            // InternalSM2.g:2375:3: otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) otherlv_2= '*/'
            {
            otherlv_0=(Token)match(input,48,FOLLOW_51); 

            			newLeafNode(otherlv_0, grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0());
            		
            // InternalSM2.g:2379:3: ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )
            // InternalSM2.g:2380:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
            {
            // InternalSM2.g:2380:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
            // InternalSM2.g:2381:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
            {
            // InternalSM2.g:2381:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
            int alt48=6;
            switch ( input.LA(1) ) {
            case RULE_STRING:
                {
                alt48=1;
                }
                break;
            case RULE_PARAMSLONGCOMENT:
                {
                alt48=2;
                }
                break;
            case RULE_DEVLONGCOMENT:
                {
                alt48=3;
                }
                break;
            case RULE_RETURNSLONGCOMENT:
                {
                alt48=4;
                }
                break;
            case RULE_TITLELONGCOMENT:
                {
                alt48=5;
                }
                break;
            case RULE_NOTICELONGCOMENT:
                {
                alt48=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 48, 0, input);

                throw nvae;
            }

            switch (alt48) {
                case 1 :
                    // InternalSM2.g:2382:6: lv_expression_1_1= RULE_STRING
                    {
                    lv_expression_1_1=(Token)match(input,RULE_STRING,FOLLOW_52); 

                    						newLeafNode(lv_expression_1_1, grammarAccess.getLongCommentAccess().getExpressionSTRINGTerminalRuleCall_1_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLongCommentRule());
                    						}
                    						addWithLastConsumed(
                    							current,
                    							"expression",
                    							lv_expression_1_1,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2397:6: lv_expression_1_2= RULE_PARAMSLONGCOMENT
                    {
                    lv_expression_1_2=(Token)match(input,RULE_PARAMSLONGCOMENT,FOLLOW_52); 

                    						newLeafNode(lv_expression_1_2, grammarAccess.getLongCommentAccess().getExpressionPARAMSLONGCOMENTTerminalRuleCall_1_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLongCommentRule());
                    						}
                    						addWithLastConsumed(
                    							current,
                    							"expression",
                    							lv_expression_1_2,
                    							"org.xtext.SM2.PARAMSLONGCOMENT");
                    					

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2412:6: lv_expression_1_3= RULE_DEVLONGCOMENT
                    {
                    lv_expression_1_3=(Token)match(input,RULE_DEVLONGCOMENT,FOLLOW_52); 

                    						newLeafNode(lv_expression_1_3, grammarAccess.getLongCommentAccess().getExpressionDEVLONGCOMENTTerminalRuleCall_1_0_2());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLongCommentRule());
                    						}
                    						addWithLastConsumed(
                    							current,
                    							"expression",
                    							lv_expression_1_3,
                    							"org.xtext.SM2.DEVLONGCOMENT");
                    					

                    }
                    break;
                case 4 :
                    // InternalSM2.g:2427:6: lv_expression_1_4= RULE_RETURNSLONGCOMENT
                    {
                    lv_expression_1_4=(Token)match(input,RULE_RETURNSLONGCOMENT,FOLLOW_52); 

                    						newLeafNode(lv_expression_1_4, grammarAccess.getLongCommentAccess().getExpressionRETURNSLONGCOMENTTerminalRuleCall_1_0_3());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLongCommentRule());
                    						}
                    						addWithLastConsumed(
                    							current,
                    							"expression",
                    							lv_expression_1_4,
                    							"org.xtext.SM2.RETURNSLONGCOMENT");
                    					

                    }
                    break;
                case 5 :
                    // InternalSM2.g:2442:6: lv_expression_1_5= RULE_TITLELONGCOMENT
                    {
                    lv_expression_1_5=(Token)match(input,RULE_TITLELONGCOMENT,FOLLOW_52); 

                    						newLeafNode(lv_expression_1_5, grammarAccess.getLongCommentAccess().getExpressionTITLELONGCOMENTTerminalRuleCall_1_0_4());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLongCommentRule());
                    						}
                    						addWithLastConsumed(
                    							current,
                    							"expression",
                    							lv_expression_1_5,
                    							"org.xtext.SM2.TITLELONGCOMENT");
                    					

                    }
                    break;
                case 6 :
                    // InternalSM2.g:2457:6: lv_expression_1_6= RULE_NOTICELONGCOMENT
                    {
                    lv_expression_1_6=(Token)match(input,RULE_NOTICELONGCOMENT,FOLLOW_52); 

                    						newLeafNode(lv_expression_1_6, grammarAccess.getLongCommentAccess().getExpressionNOTICELONGCOMENTTerminalRuleCall_1_0_5());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLongCommentRule());
                    						}
                    						addWithLastConsumed(
                    							current,
                    							"expression",
                    							lv_expression_1_6,
                    							"org.xtext.SM2.NOTICELONGCOMENT");
                    					

                    }
                    break;

            }


            }


            }

            otherlv_2=(Token)match(input,49,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "ruleSingularType"
    // InternalSM2.g:2482:1: ruleSingularType returns [Enumerator current=null] : ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) ) ;
    public final Enumerator ruleSingularType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;
        Token enumLiteral_8=null;


        	enterRule();

        try {
            // InternalSM2.g:2488:2: ( ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) ) )
            // InternalSM2.g:2489:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) )
            {
            // InternalSM2.g:2489:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) )
            int alt49=9;
            switch ( input.LA(1) ) {
            case 50:
                {
                alt49=1;
                }
                break;
            case 51:
                {
                alt49=2;
                }
                break;
            case 52:
                {
                alt49=3;
                }
                break;
            case 53:
                {
                alt49=4;
                }
                break;
            case 54:
                {
                alt49=5;
                }
                break;
            case 55:
                {
                alt49=6;
                }
                break;
            case 56:
                {
                alt49=7;
                }
                break;
            case 57:
                {
                alt49=8;
                }
                break;
            case 58:
                {
                alt49=9;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 49, 0, input);

                throw nvae;
            }

            switch (alt49) {
                case 1 :
                    // InternalSM2.g:2490:3: (enumLiteral_0= 'int' )
                    {
                    // InternalSM2.g:2490:3: (enumLiteral_0= 'int' )
                    // InternalSM2.g:2491:4: enumLiteral_0= 'int'
                    {
                    enumLiteral_0=(Token)match(input,50,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2498:3: (enumLiteral_1= 'uint' )
                    {
                    // InternalSM2.g:2498:3: (enumLiteral_1= 'uint' )
                    // InternalSM2.g:2499:4: enumLiteral_1= 'uint'
                    {
                    enumLiteral_1=(Token)match(input,51,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2506:3: (enumLiteral_2= 'uint8' )
                    {
                    // InternalSM2.g:2506:3: (enumLiteral_2= 'uint8' )
                    // InternalSM2.g:2507:4: enumLiteral_2= 'uint8'
                    {
                    enumLiteral_2=(Token)match(input,52,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:2514:3: (enumLiteral_3= 'uint256' )
                    {
                    // InternalSM2.g:2514:3: (enumLiteral_3= 'uint256' )
                    // InternalSM2.g:2515:4: enumLiteral_3= 'uint256'
                    {
                    enumLiteral_3=(Token)match(input,53,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:2522:3: (enumLiteral_4= 'string' )
                    {
                    // InternalSM2.g:2522:3: (enumLiteral_4= 'string' )
                    // InternalSM2.g:2523:4: enumLiteral_4= 'string'
                    {
                    enumLiteral_4=(Token)match(input,54,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:2530:3: (enumLiteral_5= 'address' )
                    {
                    // InternalSM2.g:2530:3: (enumLiteral_5= 'address' )
                    // InternalSM2.g:2531:4: enumLiteral_5= 'address'
                    {
                    enumLiteral_5=(Token)match(input,55,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:2538:3: (enumLiteral_6= 'address payable' )
                    {
                    // InternalSM2.g:2538:3: (enumLiteral_6= 'address payable' )
                    // InternalSM2.g:2539:4: enumLiteral_6= 'address payable'
                    {
                    enumLiteral_6=(Token)match(input,56,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_6, grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6());
                    			

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:2546:3: (enumLiteral_7= 'double' )
                    {
                    // InternalSM2.g:2546:3: (enumLiteral_7= 'double' )
                    // InternalSM2.g:2547:4: enumLiteral_7= 'double'
                    {
                    enumLiteral_7=(Token)match(input,57,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_7, grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7());
                    			

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:2554:3: (enumLiteral_8= 'bool' )
                    {
                    // InternalSM2.g:2554:3: (enumLiteral_8= 'bool' )
                    // InternalSM2.g:2555:4: enumLiteral_8= 'bool'
                    {
                    enumLiteral_8=(Token)match(input,58,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_8, grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:2565:1: ruleVisibility returns [Enumerator current=null] : ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) ;
    public final Enumerator ruleVisibility() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalSM2.g:2571:2: ( ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) )
            // InternalSM2.g:2572:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            {
            // InternalSM2.g:2572:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            int alt50=4;
            switch ( input.LA(1) ) {
            case 59:
                {
                alt50=1;
                }
                break;
            case 60:
                {
                alt50=2;
                }
                break;
            case 61:
                {
                alt50=3;
                }
                break;
            case 62:
                {
                alt50=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 50, 0, input);

                throw nvae;
            }

            switch (alt50) {
                case 1 :
                    // InternalSM2.g:2573:3: (enumLiteral_0= 'public' )
                    {
                    // InternalSM2.g:2573:3: (enumLiteral_0= 'public' )
                    // InternalSM2.g:2574:4: enumLiteral_0= 'public'
                    {
                    enumLiteral_0=(Token)match(input,59,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2581:3: (enumLiteral_1= 'private' )
                    {
                    // InternalSM2.g:2581:3: (enumLiteral_1= 'private' )
                    // InternalSM2.g:2582:4: enumLiteral_1= 'private'
                    {
                    enumLiteral_1=(Token)match(input,60,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2589:3: (enumLiteral_2= 'internal' )
                    {
                    // InternalSM2.g:2589:3: (enumLiteral_2= 'internal' )
                    // InternalSM2.g:2590:4: enumLiteral_2= 'internal'
                    {
                    enumLiteral_2=(Token)match(input,61,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:2597:3: (enumLiteral_3= 'external' )
                    {
                    // InternalSM2.g:2597:3: (enumLiteral_3= 'external' )
                    // InternalSM2.g:2598:4: enumLiteral_3= 'external'
                    {
                    enumLiteral_3=(Token)match(input,62,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:2608:1: ruleCoin returns [Enumerator current=null] : ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) ;
    public final Enumerator ruleCoin() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:2614:2: ( ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) )
            // InternalSM2.g:2615:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            {
            // InternalSM2.g:2615:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            int alt51=6;
            switch ( input.LA(1) ) {
            case 63:
                {
                alt51=1;
                }
                break;
            case 64:
                {
                alt51=2;
                }
                break;
            case 65:
                {
                alt51=3;
                }
                break;
            case 66:
                {
                alt51=4;
                }
                break;
            case 67:
                {
                alt51=5;
                }
                break;
            case 68:
                {
                alt51=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 51, 0, input);

                throw nvae;
            }

            switch (alt51) {
                case 1 :
                    // InternalSM2.g:2616:3: (enumLiteral_0= 'ether' )
                    {
                    // InternalSM2.g:2616:3: (enumLiteral_0= 'ether' )
                    // InternalSM2.g:2617:4: enumLiteral_0= 'ether'
                    {
                    enumLiteral_0=(Token)match(input,63,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2624:3: (enumLiteral_1= 'wei' )
                    {
                    // InternalSM2.g:2624:3: (enumLiteral_1= 'wei' )
                    // InternalSM2.g:2625:4: enumLiteral_1= 'wei'
                    {
                    enumLiteral_1=(Token)match(input,64,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2632:3: (enumLiteral_2= 'gwei' )
                    {
                    // InternalSM2.g:2632:3: (enumLiteral_2= 'gwei' )
                    // InternalSM2.g:2633:4: enumLiteral_2= 'gwei'
                    {
                    enumLiteral_2=(Token)match(input,65,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:2640:3: (enumLiteral_3= 'pwei' )
                    {
                    // InternalSM2.g:2640:3: (enumLiteral_3= 'pwei' )
                    // InternalSM2.g:2641:4: enumLiteral_3= 'pwei'
                    {
                    enumLiteral_3=(Token)match(input,66,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:2648:3: (enumLiteral_4= 'finney' )
                    {
                    // InternalSM2.g:2648:3: (enumLiteral_4= 'finney' )
                    // InternalSM2.g:2649:4: enumLiteral_4= 'finney'
                    {
                    enumLiteral_4=(Token)match(input,67,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:2656:3: (enumLiteral_5= 'szabo' )
                    {
                    // InternalSM2.g:2656:3: (enumLiteral_5= 'szabo' )
                    // InternalSM2.g:2657:4: enumLiteral_5= 'szabo'
                    {
                    enumLiteral_5=(Token)match(input,68,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:2667:1: ruleComparationOperator returns [Enumerator current=null] : ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) ;
    public final Enumerator ruleComparationOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:2673:2: ( ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) )
            // InternalSM2.g:2674:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            {
            // InternalSM2.g:2674:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            int alt52=6;
            switch ( input.LA(1) ) {
            case 31:
                {
                alt52=1;
                }
                break;
            case 33:
                {
                alt52=2;
                }
                break;
            case 32:
                {
                alt52=3;
                }
                break;
            case 34:
                {
                alt52=4;
                }
                break;
            case 69:
                {
                alt52=5;
                }
                break;
            case 70:
                {
                alt52=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 52, 0, input);

                throw nvae;
            }

            switch (alt52) {
                case 1 :
                    // InternalSM2.g:2675:3: (enumLiteral_0= '>' )
                    {
                    // InternalSM2.g:2675:3: (enumLiteral_0= '>' )
                    // InternalSM2.g:2676:4: enumLiteral_0= '>'
                    {
                    enumLiteral_0=(Token)match(input,31,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2683:3: (enumLiteral_1= '<' )
                    {
                    // InternalSM2.g:2683:3: (enumLiteral_1= '<' )
                    // InternalSM2.g:2684:4: enumLiteral_1= '<'
                    {
                    enumLiteral_1=(Token)match(input,33,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2691:3: (enumLiteral_2= '>=' )
                    {
                    // InternalSM2.g:2691:3: (enumLiteral_2= '>=' )
                    // InternalSM2.g:2692:4: enumLiteral_2= '>='
                    {
                    enumLiteral_2=(Token)match(input,32,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:2699:3: (enumLiteral_3= '<=' )
                    {
                    // InternalSM2.g:2699:3: (enumLiteral_3= '<=' )
                    // InternalSM2.g:2700:4: enumLiteral_3= '<='
                    {
                    enumLiteral_3=(Token)match(input,34,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:2707:3: (enumLiteral_4= '==' )
                    {
                    // InternalSM2.g:2707:3: (enumLiteral_4= '==' )
                    // InternalSM2.g:2708:4: enumLiteral_4= '=='
                    {
                    enumLiteral_4=(Token)match(input,69,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:2715:3: (enumLiteral_5= '!=' )
                    {
                    // InternalSM2.g:2715:3: (enumLiteral_5= '!=' )
                    // InternalSM2.g:2716:4: enumLiteral_5= '!='
                    {
                    enumLiteral_5=(Token)match(input,70,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:2726:1: ruleLogicalPairOperator returns [Enumerator current=null] : ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) ;
    public final Enumerator ruleLogicalPairOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSM2.g:2732:2: ( ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) )
            // InternalSM2.g:2733:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            {
            // InternalSM2.g:2733:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==71) ) {
                alt53=1;
            }
            else if ( (LA53_0==72) ) {
                alt53=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 53, 0, input);

                throw nvae;
            }
            switch (alt53) {
                case 1 :
                    // InternalSM2.g:2734:3: (enumLiteral_0= '&&' )
                    {
                    // InternalSM2.g:2734:3: (enumLiteral_0= '&&' )
                    // InternalSM2.g:2735:4: enumLiteral_0= '&&'
                    {
                    enumLiteral_0=(Token)match(input,71,FOLLOW_2); 

                    				current = grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2742:3: (enumLiteral_1= '||' )
                    {
                    // InternalSM2.g:2742:3: (enumLiteral_1= '||' )
                    // InternalSM2.g:2743:4: enumLiteral_1= '||'
                    {
                    enumLiteral_1=(Token)match(input,72,FOLLOW_2); 

                    				current = grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:2753:1: ruleArithmeticalOperator returns [Enumerator current=null] : ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) ) ;
    public final Enumerator ruleArithmeticalOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalSM2.g:2759:2: ( ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) ) )
            // InternalSM2.g:2760:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) )
            {
            // InternalSM2.g:2760:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) )
            int alt54=4;
            switch ( input.LA(1) ) {
            case 73:
                {
                alt54=1;
                }
                break;
            case 74:
                {
                alt54=2;
                }
                break;
            case 75:
                {
                alt54=3;
                }
                break;
            case 76:
                {
                alt54=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 54, 0, input);

                throw nvae;
            }

            switch (alt54) {
                case 1 :
                    // InternalSM2.g:2761:3: (enumLiteral_0= '+' )
                    {
                    // InternalSM2.g:2761:3: (enumLiteral_0= '+' )
                    // InternalSM2.g:2762:4: enumLiteral_0= '+'
                    {
                    enumLiteral_0=(Token)match(input,73,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2769:3: (enumLiteral_1= '-' )
                    {
                    // InternalSM2.g:2769:3: (enumLiteral_1= '-' )
                    // InternalSM2.g:2770:4: enumLiteral_1= '-'
                    {
                    enumLiteral_1=(Token)match(input,74,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2777:3: (enumLiteral_2= '*' )
                    {
                    // InternalSM2.g:2777:3: (enumLiteral_2= '*' )
                    // InternalSM2.g:2778:4: enumLiteral_2= '*'
                    {
                    enumLiteral_2=(Token)match(input,75,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:2785:3: (enumLiteral_3= '/' )
                    {
                    // InternalSM2.g:2785:3: (enumLiteral_3= '/' )
                    // InternalSM2.g:2786:4: enumLiteral_3= '/'
                    {
                    enumLiteral_3=(Token)match(input,76,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmeticalOperator"

    // Delegated rules


    protected DFA38 dfa38 = new DFA38(this);
    static final String dfa_1s = "\20\uffff";
    static final String dfa_2s = "\1\5\1\13\1\uffff\1\15\1\37\1\4\6\15\1\5\1\4\1\uffff\1\37";
    static final String dfa_3s = "\1\55\1\13\1\uffff\1\20\2\106\6\20\1\5\1\104\1\uffff\1\106";
    static final String dfa_4s = "\2\uffff\1\2\13\uffff\1\1\1\uffff";
    static final String dfa_5s = "\20\uffff}>";
    static final String[] dfa_6s = {
            "\1\2\2\uffff\1\2\2\uffff\1\2\1\uffff\1\2\2\uffff\1\2\34\uffff\1\1",
            "\1\3",
            "",
            "\1\4\2\uffff\1\5",
            "\1\6\1\10\1\7\1\11\42\uffff\1\12\1\13",
            "\1\14\32\uffff\1\6\1\10\1\7\1\11\42\uffff\1\12\1\13",
            "\1\16\2\uffff\1\15",
            "\1\16\2\uffff\1\15",
            "\1\16\2\uffff\1\15",
            "\1\16\2\uffff\1\15",
            "\1\16\2\uffff\1\15",
            "\1\16\2\uffff\1\15",
            "\1\17",
            "\1\16\7\uffff\1\16\62\uffff\6\2",
            "",
            "\1\6\1\10\1\7\1\11\42\uffff\1\12\1\13"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA38 extends DFA {

        public DFA38(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 38;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "1962:3: ( (lv_restriction_9_0= ruleRestriction ) )?";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x00000001C0000000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000810000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000810000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000020000080L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x07FDCD6000000160L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x07FDCD6000000140L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0001C06000000100L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0001C04000000100L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0001C00000000100L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0001800000000100L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000600000002L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000001000000010L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x07FC000000001000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000002020L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000008000000020L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x07FC000000000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x7800000000000040L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x07FC000000000020L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000008100L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000000012010L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000008002L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000000012000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000000780000000L,0x0000000000000060L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x8000000000000000L,0x000000000000001FL});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x7800000000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000001040L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000200000012920L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000000000012920L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000000120L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001E00L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x00000000003E2000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0002000000000000L});

}