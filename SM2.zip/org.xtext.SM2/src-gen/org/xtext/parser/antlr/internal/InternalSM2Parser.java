package org.xtext.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_ID", "RULE_OPENKEY", "RULE_CLOSEKEY", "RULE_SINGLENUMBER", "RULE_DOT", "RULE_INTEGER", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_FLOAT", "RULE_STRING", "RULE_EMAIL", "RULE_COMMA", "RULE_IF", "RULE_ELSE", "RULE_PARAMSLONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_NOTICELONGCOMENT", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'pragma'", "'solidity'", "'contract'", "'is'", "'^'", "'>'", "'>='", "'<'", "'<='", "'import'", "'as'", "'interface'", "'constructor'", "'public'", "'internal'", "'='", "'event'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'address'", "'string'", "'uint'", "'amountAccount'", "'enum'", "'[]'", "'['", "']'", "'memory'", "'local'", "'require'", "'payable'", "'function'", "'//'", "'/*'", "'*/'", "'int'", "'uint8'", "'uint256'", "'address payable'", "'double'", "'bool'", "'byte'", "'bytes32'", "'private'", "'external'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'=='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'", "'%'"
    };
    public static final int T__50=50;
    public static final int RULE_OPENPARENTHESIS=12;
    public static final int RULE_EOLINE=5;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_PARAMSLONGCOMENT=20;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=6;
    public static final int RULE_INT=25;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=26;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int RULE_TITLELONGCOMENT=23;
    public static final int RULE_EMAIL=16;
    public static final int RULE_NOTICELONGCOMENT=24;
    public static final int T__37=37;
    public static final int RULE_OPENKEY=7;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int RULE_CLOSEPARENTHESIS=13;
    public static final int T__35=35;
    public static final int RULE_IF=18;
    public static final int T__36=36;
    public static final int RULE_DOT=10;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_DEVLONGCOMENT=21;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int RULE_FLOAT=14;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__91=91;
    public static final int T__92=92;
    public static final int T__90=90;
    public static final int RULE_SINGLENUMBER=9;
    public static final int RULE_CLOSEKEY=8;
    public static final int RULE_COMMA=17;
    public static final int RULE_RETURNSLONGCOMENT=22;
    public static final int RULE_SEMICOLON=4;
    public static final int RULE_ELSE=19;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_STRING=15;
    public static final int RULE_SL_COMMENT=27;
    public static final int T__77=77;
    public static final int T__78=78;
    public static final int T__79=79;
    public static final int T__73=73;
    public static final int EOF=-1;
    public static final int T__74=74;
    public static final int T__75=75;
    public static final int T__76=76;
    public static final int T__80=80;
    public static final int T__81=81;
    public static final int T__82=82;
    public static final int T__83=83;
    public static final int RULE_WS=28;
    public static final int RULE_ANY_OTHER=29;
    public static final int T__88=88;
    public static final int T__89=89;
    public static final int T__84=84;
    public static final int T__85=85;
    public static final int RULE_INTEGER=11;
    public static final int T__86=86;
    public static final int T__87=87;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }



     	private SM2GrammarAccess grammarAccess;

        public InternalSM2Parser(TokenStream input, SM2GrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "SmartContract";
       	}

       	@Override
       	protected SM2GrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleSmartContract"
    // InternalSM2.g:65:1: entryRuleSmartContract returns [EObject current=null] : iv_ruleSmartContract= ruleSmartContract EOF ;
    public final EObject entryRuleSmartContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSmartContract = null;


        try {
            // InternalSM2.g:65:54: (iv_ruleSmartContract= ruleSmartContract EOF )
            // InternalSM2.g:66:2: iv_ruleSmartContract= ruleSmartContract EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSmartContractRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSmartContract=ruleSmartContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSmartContract; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSmartContract"


    // $ANTLR start "ruleSmartContract"
    // InternalSM2.g:72:1: ruleSmartContract returns [EObject current=null] : ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contract_7_0= 'contract' ) ) ( (lv_nameContract_8_0= RULE_ID ) ) (otherlv_9= 'is' ( (lv_nameContractFather_10_0= RULE_ID ) ) )? this_OPENKEY_11= RULE_OPENKEY (this_EOLINE_12= RULE_EOLINE )? ( (lv_attributes_13_0= ruleAttributes ) )* ( (lv_constructor_14_0= ruleConstructor ) )? ( (lv_events_15_0= ruleEvent ) )* ( (lv_modifier_16_0= ruleModifier ) )* ( (lv_clauses_17_0= ruleClause ) )* ( (lv_comments_18_0= ruleComment ) )* this_CLOSEKEY_19= RULE_CLOSEKEY ) ;
    public final EObject ruleSmartContract() throws RecognitionException {
        EObject current = null;

        Token lv_compiler_0_0=null;
        Token otherlv_1=null;
        Token this_SEMICOLON_3=null;
        Token this_EOLINE_4=null;
        Token lv_contract_7_0=null;
        Token lv_nameContract_8_0=null;
        Token otherlv_9=null;
        Token lv_nameContractFather_10_0=null;
        Token this_OPENKEY_11=null;
        Token this_EOLINE_12=null;
        Token this_CLOSEKEY_19=null;
        EObject lv_VersionCompiler_2_0 = null;

        EObject lv_imports_5_0 = null;

        EObject lv_interfaces_6_0 = null;

        EObject lv_attributes_13_0 = null;

        EObject lv_constructor_14_0 = null;

        EObject lv_events_15_0 = null;

        EObject lv_modifier_16_0 = null;

        EObject lv_clauses_17_0 = null;

        EObject lv_comments_18_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:78:2: ( ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contract_7_0= 'contract' ) ) ( (lv_nameContract_8_0= RULE_ID ) ) (otherlv_9= 'is' ( (lv_nameContractFather_10_0= RULE_ID ) ) )? this_OPENKEY_11= RULE_OPENKEY (this_EOLINE_12= RULE_EOLINE )? ( (lv_attributes_13_0= ruleAttributes ) )* ( (lv_constructor_14_0= ruleConstructor ) )? ( (lv_events_15_0= ruleEvent ) )* ( (lv_modifier_16_0= ruleModifier ) )* ( (lv_clauses_17_0= ruleClause ) )* ( (lv_comments_18_0= ruleComment ) )* this_CLOSEKEY_19= RULE_CLOSEKEY ) )
            // InternalSM2.g:79:2: ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contract_7_0= 'contract' ) ) ( (lv_nameContract_8_0= RULE_ID ) ) (otherlv_9= 'is' ( (lv_nameContractFather_10_0= RULE_ID ) ) )? this_OPENKEY_11= RULE_OPENKEY (this_EOLINE_12= RULE_EOLINE )? ( (lv_attributes_13_0= ruleAttributes ) )* ( (lv_constructor_14_0= ruleConstructor ) )? ( (lv_events_15_0= ruleEvent ) )* ( (lv_modifier_16_0= ruleModifier ) )* ( (lv_clauses_17_0= ruleClause ) )* ( (lv_comments_18_0= ruleComment ) )* this_CLOSEKEY_19= RULE_CLOSEKEY )
            {
            // InternalSM2.g:79:2: ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contract_7_0= 'contract' ) ) ( (lv_nameContract_8_0= RULE_ID ) ) (otherlv_9= 'is' ( (lv_nameContractFather_10_0= RULE_ID ) ) )? this_OPENKEY_11= RULE_OPENKEY (this_EOLINE_12= RULE_EOLINE )? ( (lv_attributes_13_0= ruleAttributes ) )* ( (lv_constructor_14_0= ruleConstructor ) )? ( (lv_events_15_0= ruleEvent ) )* ( (lv_modifier_16_0= ruleModifier ) )* ( (lv_clauses_17_0= ruleClause ) )* ( (lv_comments_18_0= ruleComment ) )* this_CLOSEKEY_19= RULE_CLOSEKEY )
            // InternalSM2.g:80:3: ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleImport ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contract_7_0= 'contract' ) ) ( (lv_nameContract_8_0= RULE_ID ) ) (otherlv_9= 'is' ( (lv_nameContractFather_10_0= RULE_ID ) ) )? this_OPENKEY_11= RULE_OPENKEY (this_EOLINE_12= RULE_EOLINE )? ( (lv_attributes_13_0= ruleAttributes ) )* ( (lv_constructor_14_0= ruleConstructor ) )? ( (lv_events_15_0= ruleEvent ) )* ( (lv_modifier_16_0= ruleModifier ) )* ( (lv_clauses_17_0= ruleClause ) )* ( (lv_comments_18_0= ruleComment ) )* this_CLOSEKEY_19= RULE_CLOSEKEY
            {
            // InternalSM2.g:80:3: ( (lv_compiler_0_0= 'pragma' ) )
            // InternalSM2.g:81:4: (lv_compiler_0_0= 'pragma' )
            {
            // InternalSM2.g:81:4: (lv_compiler_0_0= 'pragma' )
            // InternalSM2.g:82:5: lv_compiler_0_0= 'pragma'
            {
            lv_compiler_0_0=(Token)match(input,30,FOLLOW_3); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_compiler_0_0, grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getSmartContractRule());
              					}
              					setWithLastConsumed(current, "compiler", lv_compiler_0_0, "pragma");
              				
            }

            }


            }

            otherlv_1=(Token)match(input,31,FOLLOW_4); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getSmartContractAccess().getSolidityKeyword_1());
              		
            }
            // InternalSM2.g:98:3: ( (lv_VersionCompiler_2_0= ruleVersion ) )
            // InternalSM2.g:99:4: (lv_VersionCompiler_2_0= ruleVersion )
            {
            // InternalSM2.g:99:4: (lv_VersionCompiler_2_0= ruleVersion )
            // InternalSM2.g:100:5: lv_VersionCompiler_2_0= ruleVersion
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_5);
            lv_VersionCompiler_2_0=ruleVersion();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getSmartContractRule());
              					}
              					set(
              						current,
              						"VersionCompiler",
              						lv_VersionCompiler_2_0,
              						"org.xtext.SM2.Version");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_SEMICOLON_3=(Token)match(input,RULE_SEMICOLON,FOLLOW_6); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_3, grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:121:3: (this_EOLINE_4= RULE_EOLINE )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_EOLINE) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalSM2.g:122:4: this_EOLINE_4= RULE_EOLINE
                    {
                    this_EOLINE_4=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_4, grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:127:3: ( (lv_imports_5_0= ruleImport ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==39) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSM2.g:128:4: (lv_imports_5_0= ruleImport )
            	    {
            	    // InternalSM2.g:128:4: (lv_imports_5_0= ruleImport )
            	    // InternalSM2.g:129:5: lv_imports_5_0= ruleImport
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_5_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_7);
            	    lv_imports_5_0=ruleImport();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"imports",
            	      						lv_imports_5_0,
            	      						"org.xtext.SM2.Import");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalSM2.g:146:3: ( (lv_interfaces_6_0= ruleInterface ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==41) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalSM2.g:147:4: (lv_interfaces_6_0= ruleInterface )
            	    {
            	    // InternalSM2.g:147:4: (lv_interfaces_6_0= ruleInterface )
            	    // InternalSM2.g:148:5: lv_interfaces_6_0= ruleInterface
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getInterfacesInterfaceParserRuleCall_6_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_8);
            	    lv_interfaces_6_0=ruleInterface();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"interfaces",
            	      						lv_interfaces_6_0,
            	      						"org.xtext.SM2.Interface");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            // InternalSM2.g:165:3: ( (lv_contract_7_0= 'contract' ) )
            // InternalSM2.g:166:4: (lv_contract_7_0= 'contract' )
            {
            // InternalSM2.g:166:4: (lv_contract_7_0= 'contract' )
            // InternalSM2.g:167:5: lv_contract_7_0= 'contract'
            {
            lv_contract_7_0=(Token)match(input,32,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_contract_7_0, grammarAccess.getSmartContractAccess().getContractContractKeyword_7_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getSmartContractRule());
              					}
              					addWithLastConsumed(current, "contract", lv_contract_7_0, "contract");
              				
            }

            }


            }

            // InternalSM2.g:179:3: ( (lv_nameContract_8_0= RULE_ID ) )
            // InternalSM2.g:180:4: (lv_nameContract_8_0= RULE_ID )
            {
            // InternalSM2.g:180:4: (lv_nameContract_8_0= RULE_ID )
            // InternalSM2.g:181:5: lv_nameContract_8_0= RULE_ID
            {
            lv_nameContract_8_0=(Token)match(input,RULE_ID,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameContract_8_0, grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_8_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getSmartContractRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameContract",
              						lv_nameContract_8_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:197:3: (otherlv_9= 'is' ( (lv_nameContractFather_10_0= RULE_ID ) ) )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==33) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalSM2.g:198:4: otherlv_9= 'is' ( (lv_nameContractFather_10_0= RULE_ID ) )
                    {
                    otherlv_9=(Token)match(input,33,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_9, grammarAccess.getSmartContractAccess().getIsKeyword_9_0());
                      			
                    }
                    // InternalSM2.g:202:4: ( (lv_nameContractFather_10_0= RULE_ID ) )
                    // InternalSM2.g:203:5: (lv_nameContractFather_10_0= RULE_ID )
                    {
                    // InternalSM2.g:203:5: (lv_nameContractFather_10_0= RULE_ID )
                    // InternalSM2.g:204:6: lv_nameContractFather_10_0= RULE_ID
                    {
                    lv_nameContractFather_10_0=(Token)match(input,RULE_ID,FOLLOW_11); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_nameContractFather_10_0, grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_9_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getSmartContractRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"nameContractFather",
                      							lv_nameContractFather_10_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_OPENKEY_11=(Token)match(input,RULE_OPENKEY,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_11, grammarAccess.getSmartContractAccess().getOPENKEYTerminalRuleCall_10());
              		
            }
            // InternalSM2.g:225:3: (this_EOLINE_12= RULE_EOLINE )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==RULE_EOLINE) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalSM2.g:226:4: this_EOLINE_12= RULE_EOLINE
                    {
                    this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_13); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_12, grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_11());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:231:3: ( (lv_attributes_13_0= ruleAttributes ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==RULE_ID||LA6_0==49||(LA6_0>=51 && LA6_0<=54)||LA6_0==56||(LA6_0>=68 && LA6_0<=75)) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalSM2.g:232:4: (lv_attributes_13_0= ruleAttributes )
            	    {
            	    // InternalSM2.g:232:4: (lv_attributes_13_0= ruleAttributes )
            	    // InternalSM2.g:233:5: lv_attributes_13_0= ruleAttributes
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_12_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_13);
            	    lv_attributes_13_0=ruleAttributes();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"attributes",
            	      						lv_attributes_13_0,
            	      						"org.xtext.SM2.Attributes");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            // InternalSM2.g:250:3: ( (lv_constructor_14_0= ruleConstructor ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==42) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalSM2.g:251:4: (lv_constructor_14_0= ruleConstructor )
                    {
                    // InternalSM2.g:251:4: (lv_constructor_14_0= ruleConstructor )
                    // InternalSM2.g:252:5: lv_constructor_14_0= ruleConstructor
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getSmartContractAccess().getConstructorConstructorParserRuleCall_13_0());
                      				
                    }
                    pushFollow(FOLLOW_14);
                    lv_constructor_14_0=ruleConstructor();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
                      					}
                      					set(
                      						current,
                      						"constructor",
                      						lv_constructor_14_0,
                      						"org.xtext.SM2.Constructor");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:269:3: ( (lv_events_15_0= ruleEvent ) )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==46) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalSM2.g:270:4: (lv_events_15_0= ruleEvent )
            	    {
            	    // InternalSM2.g:270:4: (lv_events_15_0= ruleEvent )
            	    // InternalSM2.g:271:5: lv_events_15_0= ruleEvent
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getEventsEventParserRuleCall_14_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_14);
            	    lv_events_15_0=ruleEvent();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"events",
            	      						lv_events_15_0,
            	      						"org.xtext.SM2.Event");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            // InternalSM2.g:288:3: ( (lv_modifier_16_0= ruleModifier ) )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==47) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalSM2.g:289:4: (lv_modifier_16_0= ruleModifier )
            	    {
            	    // InternalSM2.g:289:4: (lv_modifier_16_0= ruleModifier )
            	    // InternalSM2.g:290:5: lv_modifier_16_0= ruleModifier
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_15_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_15);
            	    lv_modifier_16_0=ruleModifier();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"modifier",
            	      						lv_modifier_16_0,
            	      						"org.xtext.SM2.Modifier");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

            // InternalSM2.g:307:3: ( (lv_clauses_17_0= ruleClause ) )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==64) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalSM2.g:308:4: (lv_clauses_17_0= ruleClause )
            	    {
            	    // InternalSM2.g:308:4: (lv_clauses_17_0= ruleClause )
            	    // InternalSM2.g:309:5: lv_clauses_17_0= ruleClause
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_16_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_16);
            	    lv_clauses_17_0=ruleClause();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"clauses",
            	      						lv_clauses_17_0,
            	      						"org.xtext.SM2.Clause");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

            // InternalSM2.g:326:3: ( (lv_comments_18_0= ruleComment ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( ((LA11_0>=65 && LA11_0<=66)) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalSM2.g:327:4: (lv_comments_18_0= ruleComment )
            	    {
            	    // InternalSM2.g:327:4: (lv_comments_18_0= ruleComment )
            	    // InternalSM2.g:328:5: lv_comments_18_0= ruleComment
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_17_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_17);
            	    lv_comments_18_0=ruleComment();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"comments",
            	      						lv_comments_18_0,
            	      						"org.xtext.SM2.Comment");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

            this_CLOSEKEY_19=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_19, grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_18());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSmartContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:353:1: entryRuleVersion returns [EObject current=null] : iv_ruleVersion= ruleVersion EOF ;
    public final EObject entryRuleVersion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVersion = null;


        try {
            // InternalSM2.g:353:48: (iv_ruleVersion= ruleVersion EOF )
            // InternalSM2.g:354:2: iv_ruleVersion= ruleVersion EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getVersionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleVersion=ruleVersion();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleVersion; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:360:1: ruleVersion returns [EObject current=null] : ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_INTEGER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_INTEGER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )? ) ) ;
    public final EObject ruleVersion() throws RecognitionException {
        EObject current = null;

        Token lv_symbol_0_0=null;
        Token lv_numberVersion_1_0=null;
        Token this_DOT_2=null;
        Token lv_numberVersion2_3_0=null;
        Token this_DOT_4=null;
        Token lv_numberVersion3_5_0=null;
        Token lv_symbol_6_1=null;
        Token lv_symbol_6_2=null;
        Token lv_numberVersion_7_0=null;
        Token this_DOT_8=null;
        Token lv_numberVersion2_9_0=null;
        Token this_DOT_10=null;
        Token lv_numberVersion3_11_0=null;
        Token lv_symbol2_12_1=null;
        Token lv_symbol2_12_2=null;
        Token lv_numberVersionOptional_13_0=null;
        Token this_DOT_14=null;
        Token lv_numberVersionOptional2_15_0=null;
        Token this_DOT_16=null;
        Token lv_numberVersionOptional3_17_0=null;


        	enterRule();

        try {
            // InternalSM2.g:366:2: ( ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_INTEGER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_INTEGER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )? ) ) )
            // InternalSM2.g:367:2: ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_INTEGER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_INTEGER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )? ) )
            {
            // InternalSM2.g:367:2: ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_INTEGER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_INTEGER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )? ) )
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==34) ) {
                alt15=1;
            }
            else if ( ((LA15_0>=35 && LA15_0<=36)) ) {
                alt15=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }
            switch (alt15) {
                case 1 :
                    // InternalSM2.g:368:3: ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_INTEGER ) ) )
                    {
                    // InternalSM2.g:368:3: ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_INTEGER ) ) )
                    // InternalSM2.g:369:4: ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_INTEGER ) )
                    {
                    // InternalSM2.g:369:4: ( (lv_symbol_0_0= '^' ) )
                    // InternalSM2.g:370:5: (lv_symbol_0_0= '^' )
                    {
                    // InternalSM2.g:370:5: (lv_symbol_0_0= '^' )
                    // InternalSM2.g:371:6: lv_symbol_0_0= '^'
                    {
                    lv_symbol_0_0=(Token)match(input,34,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_symbol_0_0, grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(current, "symbol", lv_symbol_0_0, "^");
                      					
                    }

                    }


                    }

                    // InternalSM2.g:383:4: ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) )
                    // InternalSM2.g:384:5: (lv_numberVersion_1_0= RULE_SINGLENUMBER )
                    {
                    // InternalSM2.g:384:5: (lv_numberVersion_1_0= RULE_SINGLENUMBER )
                    // InternalSM2.g:385:6: lv_numberVersion_1_0= RULE_SINGLENUMBER
                    {
                    lv_numberVersion_1_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_19); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion_1_0, grammarAccess.getVersionAccess().getNumberVersionSINGLENUMBERTerminalRuleCall_0_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion",
                      							lv_numberVersion_1_0,
                      							"org.xtext.SM2.SINGLENUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_2=(Token)match(input,RULE_DOT,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_2, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_2());
                      			
                    }
                    // InternalSM2.g:405:4: ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) )
                    // InternalSM2.g:406:5: (lv_numberVersion2_3_0= RULE_SINGLENUMBER )
                    {
                    // InternalSM2.g:406:5: (lv_numberVersion2_3_0= RULE_SINGLENUMBER )
                    // InternalSM2.g:407:6: lv_numberVersion2_3_0= RULE_SINGLENUMBER
                    {
                    lv_numberVersion2_3_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_19); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion2_3_0, grammarAccess.getVersionAccess().getNumberVersion2SINGLENUMBERTerminalRuleCall_0_3_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion2",
                      							lv_numberVersion2_3_0,
                      							"org.xtext.SM2.SINGLENUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_4=(Token)match(input,RULE_DOT,FOLLOW_20); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_4, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_4());
                      			
                    }
                    // InternalSM2.g:427:4: ( (lv_numberVersion3_5_0= RULE_INTEGER ) )
                    // InternalSM2.g:428:5: (lv_numberVersion3_5_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:428:5: (lv_numberVersion3_5_0= RULE_INTEGER )
                    // InternalSM2.g:429:6: lv_numberVersion3_5_0= RULE_INTEGER
                    {
                    lv_numberVersion3_5_0=(Token)match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion3_5_0, grammarAccess.getVersionAccess().getNumberVersion3INTEGERTerminalRuleCall_0_5_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion3",
                      							lv_numberVersion3_5_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:447:3: ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_INTEGER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )? )
                    {
                    // InternalSM2.g:447:3: ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_INTEGER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )? )
                    // InternalSM2.g:448:4: ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_INTEGER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )?
                    {
                    // InternalSM2.g:448:4: ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) )
                    // InternalSM2.g:449:5: ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) )
                    {
                    // InternalSM2.g:449:5: ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) )
                    // InternalSM2.g:450:6: (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' )
                    {
                    // InternalSM2.g:450:6: (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' )
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==35) ) {
                        alt12=1;
                    }
                    else if ( (LA12_0==36) ) {
                        alt12=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 12, 0, input);

                        throw nvae;
                    }
                    switch (alt12) {
                        case 1 :
                            // InternalSM2.g:451:7: lv_symbol_6_1= '>'
                            {
                            lv_symbol_6_1=(Token)match(input,35,FOLLOW_18); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_symbol_6_1, grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_1_0_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(current, "symbol", lv_symbol_6_1, null);
                              						
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:462:7: lv_symbol_6_2= '>='
                            {
                            lv_symbol_6_2=(Token)match(input,36,FOLLOW_18); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_symbol_6_2, grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_1_0_0_1());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(current, "symbol", lv_symbol_6_2, null);
                              						
                            }

                            }
                            break;

                    }


                    }


                    }

                    // InternalSM2.g:475:4: ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) )
                    // InternalSM2.g:476:5: (lv_numberVersion_7_0= RULE_SINGLENUMBER )
                    {
                    // InternalSM2.g:476:5: (lv_numberVersion_7_0= RULE_SINGLENUMBER )
                    // InternalSM2.g:477:6: lv_numberVersion_7_0= RULE_SINGLENUMBER
                    {
                    lv_numberVersion_7_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_19); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion_7_0, grammarAccess.getVersionAccess().getNumberVersionSINGLENUMBERTerminalRuleCall_1_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion",
                      							lv_numberVersion_7_0,
                      							"org.xtext.SM2.SINGLENUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_8=(Token)match(input,RULE_DOT,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_8, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_2());
                      			
                    }
                    // InternalSM2.g:497:4: ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) )
                    // InternalSM2.g:498:5: (lv_numberVersion2_9_0= RULE_SINGLENUMBER )
                    {
                    // InternalSM2.g:498:5: (lv_numberVersion2_9_0= RULE_SINGLENUMBER )
                    // InternalSM2.g:499:6: lv_numberVersion2_9_0= RULE_SINGLENUMBER
                    {
                    lv_numberVersion2_9_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_19); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion2_9_0, grammarAccess.getVersionAccess().getNumberVersion2SINGLENUMBERTerminalRuleCall_1_3_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion2",
                      							lv_numberVersion2_9_0,
                      							"org.xtext.SM2.SINGLENUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_10=(Token)match(input,RULE_DOT,FOLLOW_20); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_10, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_4());
                      			
                    }
                    // InternalSM2.g:519:4: ( (lv_numberVersion3_11_0= RULE_INTEGER ) )
                    // InternalSM2.g:520:5: (lv_numberVersion3_11_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:520:5: (lv_numberVersion3_11_0= RULE_INTEGER )
                    // InternalSM2.g:521:6: lv_numberVersion3_11_0= RULE_INTEGER
                    {
                    lv_numberVersion3_11_0=(Token)match(input,RULE_INTEGER,FOLLOW_21); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion3_11_0, grammarAccess.getVersionAccess().getNumberVersion3INTEGERTerminalRuleCall_1_5_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion3",
                      							lv_numberVersion3_11_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }

                    // InternalSM2.g:537:4: ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )?
                    int alt14=2;
                    int LA14_0 = input.LA(1);

                    if ( ((LA14_0>=37 && LA14_0<=38)) ) {
                        alt14=1;
                    }
                    switch (alt14) {
                        case 1 :
                            // InternalSM2.g:538:5: ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:538:5: ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) )
                            // InternalSM2.g:539:6: ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) )
                            {
                            // InternalSM2.g:539:6: ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) )
                            // InternalSM2.g:540:7: (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' )
                            {
                            // InternalSM2.g:540:7: (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' )
                            int alt13=2;
                            int LA13_0 = input.LA(1);

                            if ( (LA13_0==37) ) {
                                alt13=1;
                            }
                            else if ( (LA13_0==38) ) {
                                alt13=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 13, 0, input);

                                throw nvae;
                            }
                            switch (alt13) {
                                case 1 :
                                    // InternalSM2.g:541:8: lv_symbol2_12_1= '<'
                                    {
                                    lv_symbol2_12_1=(Token)match(input,37,FOLLOW_18); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      								newLeafNode(lv_symbol2_12_1, grammarAccess.getVersionAccess().getSymbol2LessThanSignKeyword_1_6_0_0_0());
                                      							
                                    }
                                    if ( state.backtracking==0 ) {

                                      								if (current==null) {
                                      									current = createModelElement(grammarAccess.getVersionRule());
                                      								}
                                      								setWithLastConsumed(current, "symbol2", lv_symbol2_12_1, null);
                                      							
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:552:8: lv_symbol2_12_2= '<='
                                    {
                                    lv_symbol2_12_2=(Token)match(input,38,FOLLOW_18); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      								newLeafNode(lv_symbol2_12_2, grammarAccess.getVersionAccess().getSymbol2LessThanSignEqualsSignKeyword_1_6_0_0_1());
                                      							
                                    }
                                    if ( state.backtracking==0 ) {

                                      								if (current==null) {
                                      									current = createModelElement(grammarAccess.getVersionRule());
                                      								}
                                      								setWithLastConsumed(current, "symbol2", lv_symbol2_12_2, null);
                                      							
                                    }

                                    }
                                    break;

                            }


                            }


                            }

                            // InternalSM2.g:565:5: ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) )
                            // InternalSM2.g:566:6: (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER )
                            {
                            // InternalSM2.g:566:6: (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER )
                            // InternalSM2.g:567:7: lv_numberVersionOptional_13_0= RULE_SINGLENUMBER
                            {
                            lv_numberVersionOptional_13_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_19); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_numberVersionOptional_13_0, grammarAccess.getVersionAccess().getNumberVersionOptionalSINGLENUMBERTerminalRuleCall_1_6_1_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"numberVersionOptional",
                              								lv_numberVersionOptional_13_0,
                              								"org.xtext.SM2.SINGLENUMBER");
                              						
                            }

                            }


                            }

                            this_DOT_14=(Token)match(input,RULE_DOT,FOLLOW_18); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_DOT_14, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_2());
                              				
                            }
                            // InternalSM2.g:587:5: ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) )
                            // InternalSM2.g:588:6: (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER )
                            {
                            // InternalSM2.g:588:6: (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER )
                            // InternalSM2.g:589:7: lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER
                            {
                            lv_numberVersionOptional2_15_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_19); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_numberVersionOptional2_15_0, grammarAccess.getVersionAccess().getNumberVersionOptional2SINGLENUMBERTerminalRuleCall_1_6_3_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"numberVersionOptional2",
                              								lv_numberVersionOptional2_15_0,
                              								"org.xtext.SM2.SINGLENUMBER");
                              						
                            }

                            }


                            }

                            this_DOT_16=(Token)match(input,RULE_DOT,FOLLOW_20); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_DOT_16, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_4());
                              				
                            }
                            // InternalSM2.g:609:5: ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) )
                            // InternalSM2.g:610:6: (lv_numberVersionOptional3_17_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:610:6: (lv_numberVersionOptional3_17_0= RULE_INTEGER )
                            // InternalSM2.g:611:7: lv_numberVersionOptional3_17_0= RULE_INTEGER
                            {
                            lv_numberVersionOptional3_17_0=(Token)match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_numberVersionOptional3_17_0, grammarAccess.getVersionAccess().getNumberVersionOptional3INTEGERTerminalRuleCall_1_6_5_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"numberVersionOptional3",
                              								lv_numberVersionOptional3_17_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleImport"
    // InternalSM2.g:633:1: entryRuleImport returns [EObject current=null] : iv_ruleImport= ruleImport EOF ;
    public final EObject entryRuleImport() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleImport = null;


        try {
            // InternalSM2.g:633:47: (iv_ruleImport= ruleImport EOF )
            // InternalSM2.g:634:2: iv_ruleImport= ruleImport EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getImportRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleImport=ruleImport();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleImport; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2.g:640:1: ruleImport returns [EObject current=null] : (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) ;
    public final EObject ruleImport() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameLibrary_1_0=null;
        Token otherlv_2=null;
        Token lv_alias_3_0=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;


        	enterRule();

        try {
            // InternalSM2.g:646:2: ( (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:647:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:647:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:648:3: otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,39,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getImportAccess().getImportKeyword_0());
              		
            }
            // InternalSM2.g:652:3: ( (lv_nameLibrary_1_0= RULE_ID ) )
            // InternalSM2.g:653:4: (lv_nameLibrary_1_0= RULE_ID )
            {
            // InternalSM2.g:653:4: (lv_nameLibrary_1_0= RULE_ID )
            // InternalSM2.g:654:5: lv_nameLibrary_1_0= RULE_ID
            {
            lv_nameLibrary_1_0=(Token)match(input,RULE_ID,FOLLOW_22); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameLibrary_1_0, grammarAccess.getImportAccess().getNameLibraryIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getImportRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameLibrary",
              						lv_nameLibrary_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:670:3: (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==40) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalSM2.g:671:4: otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,40,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getImportAccess().getAsKeyword_2_0());
                      			
                    }
                    // InternalSM2.g:675:4: ( (lv_alias_3_0= RULE_ID ) )
                    // InternalSM2.g:676:5: (lv_alias_3_0= RULE_ID )
                    {
                    // InternalSM2.g:676:5: (lv_alias_3_0= RULE_ID )
                    // InternalSM2.g:677:6: lv_alias_3_0= RULE_ID
                    {
                    lv_alias_3_0=(Token)match(input,RULE_ID,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_alias_3_0, grammarAccess.getImportAccess().getAliasIDTerminalRuleCall_2_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getImportRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"alias",
                      							lv_alias_3_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_4, grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:698:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==RULE_EOLINE) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalSM2.g:699:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_5, grammarAccess.getImportAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleInterface"
    // InternalSM2.g:708:1: entryRuleInterface returns [EObject current=null] : iv_ruleInterface= ruleInterface EOF ;
    public final EObject entryRuleInterface() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInterface = null;


        try {
            // InternalSM2.g:708:50: (iv_ruleInterface= ruleInterface EOF )
            // InternalSM2.g:709:2: iv_ruleInterface= ruleInterface EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getInterfaceRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleInterface=ruleInterface();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleInterface; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInterface"


    // $ANTLR start "ruleInterface"
    // InternalSM2.g:715:1: ruleInterface returns [EObject current=null] : (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (lv_clauses_8_0= ruleHeadClause ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE ) ;
    public final EObject ruleInterface() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameInterface_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_EOLINE_5=null;
        Token this_EOLINE_7=null;
        Token this_SEMICOLON_9=null;
        Token this_EOLINE_10=null;
        Token this_CLOSEKEY_11=null;
        Token this_EOLINE_12=null;
        EObject lv_enums_4_0 = null;

        EObject lv_structs_6_0 = null;

        EObject lv_clauses_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:721:2: ( (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (lv_clauses_8_0= ruleHeadClause ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE ) )
            // InternalSM2.g:722:2: (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (lv_clauses_8_0= ruleHeadClause ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE )
            {
            // InternalSM2.g:722:2: (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (lv_clauses_8_0= ruleHeadClause ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE )
            // InternalSM2.g:723:3: otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (lv_clauses_8_0= ruleHeadClause ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,41,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getInterfaceAccess().getInterfaceKeyword_0());
              		
            }
            // InternalSM2.g:727:3: ( (lv_nameInterface_1_0= RULE_ID ) )
            // InternalSM2.g:728:4: (lv_nameInterface_1_0= RULE_ID )
            {
            // InternalSM2.g:728:4: (lv_nameInterface_1_0= RULE_ID )
            // InternalSM2.g:729:5: lv_nameInterface_1_0= RULE_ID
            {
            lv_nameInterface_1_0=(Token)match(input,RULE_ID,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameInterface_1_0, grammarAccess.getInterfaceAccess().getNameInterfaceIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getInterfaceRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameInterface",
              						lv_nameInterface_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getInterfaceAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_25); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_3, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_3());
              		
            }
            // InternalSM2.g:753:3: ( (lv_enums_4_0= ruleEnum ) )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==56) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalSM2.g:754:4: (lv_enums_4_0= ruleEnum )
            	    {
            	    // InternalSM2.g:754:4: (lv_enums_4_0= ruleEnum )
            	    // InternalSM2.g:755:5: lv_enums_4_0= ruleEnum
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getInterfaceAccess().getEnumsEnumParserRuleCall_4_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_25);
            	    lv_enums_4_0=ruleEnum();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getInterfaceRule());
            	      					}
            	      					add(
            	      						current,
            	      						"enums",
            	      						lv_enums_4_0,
            	      						"org.xtext.SM2.Enum");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

            this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_26); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_5, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_5());
              		
            }
            // InternalSM2.g:776:3: ( (lv_structs_6_0= ruleStruct ) )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==51) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalSM2.g:777:4: (lv_structs_6_0= ruleStruct )
            	    {
            	    // InternalSM2.g:777:4: (lv_structs_6_0= ruleStruct )
            	    // InternalSM2.g:778:5: lv_structs_6_0= ruleStruct
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getInterfaceAccess().getStructsStructParserRuleCall_6_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_26);
            	    lv_structs_6_0=ruleStruct();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getInterfaceRule());
            	      					}
            	      					add(
            	      						current,
            	      						"structs",
            	      						lv_structs_6_0,
            	      						"org.xtext.SM2.Struct");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_7, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_7());
              		
            }
            // InternalSM2.g:799:3: ( (lv_clauses_8_0= ruleHeadClause ) )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==64) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalSM2.g:800:4: (lv_clauses_8_0= ruleHeadClause )
            	    {
            	    // InternalSM2.g:800:4: (lv_clauses_8_0= ruleHeadClause )
            	    // InternalSM2.g:801:5: lv_clauses_8_0= ruleHeadClause
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getInterfaceAccess().getClausesHeadClauseParserRuleCall_8_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_27);
            	    lv_clauses_8_0=ruleHeadClause();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getInterfaceRule());
            	      					}
            	      					add(
            	      						current,
            	      						"clauses",
            	      						lv_clauses_8_0,
            	      						"org.xtext.SM2.HeadClause");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_9, grammarAccess.getInterfaceAccess().getSEMICOLONTerminalRuleCall_9());
              		
            }
            this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_28); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_10, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_10());
              		
            }
            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_11, grammarAccess.getInterfaceAccess().getCLOSEKEYTerminalRuleCall_11());
              		
            }
            this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_12, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_12());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInterface"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:838:1: entryRuleAttributes returns [EObject current=null] : iv_ruleAttributes= ruleAttributes EOF ;
    public final EObject entryRuleAttributes() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttributes = null;


        try {
            // InternalSM2.g:838:51: (iv_ruleAttributes= ruleAttributes EOF )
            // InternalSM2.g:839:2: iv_ruleAttributes= ruleAttributes EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getAttributesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleAttributes=ruleAttributes();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleAttributes; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:845:1: ruleAttributes returns [EObject current=null] : (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) ;
    public final EObject ruleAttributes() throws RecognitionException {
        EObject current = null;

        EObject this_Property_0 = null;

        EObject this_DataType_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:851:2: ( (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) )
            // InternalSM2.g:852:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            {
            // InternalSM2.g:852:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( ((LA21_0>=52 && LA21_0<=54)||(LA21_0>=68 && LA21_0<=75)) ) {
                alt21=1;
            }
            else if ( (LA21_0==RULE_ID||LA21_0==49||LA21_0==51||LA21_0==56) ) {
                alt21=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }
            switch (alt21) {
                case 1 :
                    // InternalSM2.g:853:3: this_Property_0= ruleProperty
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Property_0=ruleProperty();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Property_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:862:3: this_DataType_1= ruleDataType
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_DataType_1=ruleDataType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_DataType_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleConstructor"
    // InternalSM2.g:874:1: entryRuleConstructor returns [EObject current=null] : iv_ruleConstructor= ruleConstructor EOF ;
    public final EObject entryRuleConstructor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConstructor = null;


        try {
            // InternalSM2.g:874:52: (iv_ruleConstructor= ruleConstructor EOF )
            // InternalSM2.g:875:2: iv_ruleConstructor= ruleConstructor EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConstructorRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleConstructor=ruleConstructor();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleConstructor; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConstructor"


    // $ANTLR start "ruleConstructor"
    // InternalSM2.g:881:1: ruleConstructor returns [EObject current=null] : (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )* otherlv_7= '=' ( (lv_value_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY ) ;
    public final EObject ruleConstructor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_2=null;
        Token lv_type_3_1=null;
        Token lv_type_3_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token this_CLOSEKEY_9=null;
        EObject lv_value_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:887:2: ( (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )* otherlv_7= '=' ( (lv_value_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY ) )
            // InternalSM2.g:888:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )* otherlv_7= '=' ( (lv_value_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY )
            {
            // InternalSM2.g:888:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )* otherlv_7= '=' ( (lv_value_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY )
            // InternalSM2.g:889:3: otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )* otherlv_7= '=' ( (lv_value_8_0= ruleExpression ) ) this_CLOSEKEY_9= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,42,FOLLOW_29); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getConstructorAccess().getConstructorKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConstructorAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:897:3: ( (otherlv_2= RULE_ID ) )
            // InternalSM2.g:898:4: (otherlv_2= RULE_ID )
            {
            // InternalSM2.g:898:4: (otherlv_2= RULE_ID )
            // InternalSM2.g:899:5: otherlv_2= RULE_ID
            {
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getConstructorRule());
              					}
              				
            }
            otherlv_2=(Token)match(input,RULE_ID,FOLLOW_30); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(otherlv_2, grammarAccess.getConstructorAccess().getInputParamsInputParamCrossReference_2_0());
              				
            }

            }


            }

            // InternalSM2.g:910:3: ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) )
            // InternalSM2.g:911:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            {
            // InternalSM2.g:911:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            // InternalSM2.g:912:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            {
            // InternalSM2.g:912:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==43) ) {
                alt22=1;
            }
            else if ( (LA22_0==44) ) {
                alt22=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }
            switch (alt22) {
                case 1 :
                    // InternalSM2.g:913:6: lv_type_3_1= 'public'
                    {
                    lv_type_3_1=(Token)match(input,43,FOLLOW_31); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_3_1, grammarAccess.getConstructorAccess().getTypePublicKeyword_3_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getConstructorRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_3_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:924:6: lv_type_3_2= 'internal'
                    {
                    lv_type_3_2=(Token)match(input,44,FOLLOW_31); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_3_2, grammarAccess.getConstructorAccess().getTypeInternalKeyword_3_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getConstructorRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_3_2, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getConstructorAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_32); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getConstructorAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:945:3: ( (otherlv_6= RULE_ID ) )*
            loop23:
            do {
                int alt23=2;
                int LA23_0 = input.LA(1);

                if ( (LA23_0==RULE_ID) ) {
                    alt23=1;
                }


                switch (alt23) {
            	case 1 :
            	    // InternalSM2.g:946:4: (otherlv_6= RULE_ID )
            	    {
            	    // InternalSM2.g:946:4: (otherlv_6= RULE_ID )
            	    // InternalSM2.g:947:5: otherlv_6= RULE_ID
            	    {
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElement(grammarAccess.getConstructorRule());
            	      					}
            	      				
            	    }
            	    otherlv_6=(Token)match(input,RULE_ID,FOLLOW_32); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_6, grammarAccess.getConstructorAccess().getAttributesAttributesCrossReference_6_0());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop23;
                }
            } while (true);

            otherlv_7=(Token)match(input,45,FOLLOW_33); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_7, grammarAccess.getConstructorAccess().getEqualsSignKeyword_7());
              		
            }
            // InternalSM2.g:962:3: ( (lv_value_8_0= ruleExpression ) )
            // InternalSM2.g:963:4: (lv_value_8_0= ruleExpression )
            {
            // InternalSM2.g:963:4: (lv_value_8_0= ruleExpression )
            // InternalSM2.g:964:5: lv_value_8_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getConstructorAccess().getValueExpressionParserRuleCall_8_0());
              				
            }
            pushFollow(FOLLOW_28);
            lv_value_8_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getConstructorRule());
              					}
              					set(
              						current,
              						"value",
              						lv_value_8_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEKEY_9=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_9, grammarAccess.getConstructorAccess().getCLOSEKEYTerminalRuleCall_9());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConstructor"


    // $ANTLR start "entryRuleEvent"
    // InternalSM2.g:989:1: entryRuleEvent returns [EObject current=null] : iv_ruleEvent= ruleEvent EOF ;
    public final EObject entryRuleEvent() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvent = null;


        try {
            // InternalSM2.g:989:46: (iv_ruleEvent= ruleEvent EOF )
            // InternalSM2.g:990:2: iv_ruleEvent= ruleEvent EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getEventRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleEvent=ruleEvent();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleEvent; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalSM2.g:996:1: ruleEvent returns [EObject current=null] : (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject ruleEvent() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEvent_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;
        EObject lv_inputParams_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1002:2: ( (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1003:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1003:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1004:3: otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,46,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getEventAccess().getEventKeyword_0());
              		
            }
            // InternalSM2.g:1008:3: ( (lv_nameEvent_1_0= RULE_ID ) )
            // InternalSM2.g:1009:4: (lv_nameEvent_1_0= RULE_ID )
            {
            // InternalSM2.g:1009:4: (lv_nameEvent_1_0= RULE_ID )
            // InternalSM2.g:1010:5: lv_nameEvent_1_0= RULE_ID
            {
            lv_nameEvent_1_0=(Token)match(input,RULE_ID,FOLLOW_29); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameEvent_1_0, grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEventRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameEvent",
              						lv_nameEvent_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_34); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1030:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( ((LA24_0>=52 && LA24_0<=54)||(LA24_0>=68 && LA24_0<=75)) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalSM2.g:1031:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1031:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:1032:5: lv_inputParams_3_0= ruleInputParam
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_34);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getEventRule());
            	      					}
            	      					add(
            	      						current,
            	      						"inputParams",
            	      						lv_inputParams_3_0,
            	      						"org.xtext.SM2.InputParam");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_5, grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1057:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==RULE_EOLINE) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalSM2.g:1058:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:1067:1: entryRuleModifier returns [EObject current=null] : iv_ruleModifier= ruleModifier EOF ;
    public final EObject entryRuleModifier() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModifier = null;


        try {
            // InternalSM2.g:1067:49: (iv_ruleModifier= ruleModifier EOF )
            // InternalSM2.g:1068:2: iv_ruleModifier= ruleModifier EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getModifierRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleModifier=ruleModifier();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleModifier; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:1074:1: ruleModifier returns [EObject current=null] : (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? ) ;
    public final EObject ruleModifier() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameModifier_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_EOLINE_6=null;
        Token this_SEMICOLON_9=null;
        Token this_EOLINE_10=null;
        Token otherlv_11=null;
        Token this_CLOSEKEY_12=null;
        Token this_EOLINE_13=null;
        EObject lv_inputParams_3_0 = null;

        EObject lv_conditions_7_0 = null;

        EObject lv_expr_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1080:2: ( (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? ) )
            // InternalSM2.g:1081:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? )
            {
            // InternalSM2.g:1081:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? )
            // InternalSM2.g:1082:3: otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,47,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getModifierAccess().getModifierKeyword_0());
              		
            }
            // InternalSM2.g:1086:3: ( (lv_nameModifier_1_0= RULE_ID ) )
            // InternalSM2.g:1087:4: (lv_nameModifier_1_0= RULE_ID )
            {
            // InternalSM2.g:1087:4: (lv_nameModifier_1_0= RULE_ID )
            // InternalSM2.g:1088:5: lv_nameModifier_1_0= RULE_ID
            {
            lv_nameModifier_1_0=(Token)match(input,RULE_ID,FOLLOW_29); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameModifier_1_0, grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getModifierRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameModifier",
              						lv_nameModifier_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_34); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1108:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( ((LA26_0>=52 && LA26_0<=54)||(LA26_0>=68 && LA26_0<=75)) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalSM2.g:1109:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1109:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:1110:5: lv_inputParams_3_0= ruleInputParam
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_34);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getModifierRule());
            	      					}
            	      					add(
            	      						current,
            	      						"inputParams",
            	      						lv_inputParams_3_0,
            	      						"org.xtext.SM2.InputParam");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_35); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1135:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==RULE_EOLINE) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalSM2.g:1136:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_36); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:1141:3: ( (lv_conditions_7_0= ruleConditional ) )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==RULE_IF) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalSM2.g:1142:4: (lv_conditions_7_0= ruleConditional )
                    {
                    // InternalSM2.g:1142:4: (lv_conditions_7_0= ruleConditional )
                    // InternalSM2.g:1143:5: lv_conditions_7_0= ruleConditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getModifierAccess().getConditionsConditionalParserRuleCall_7_0());
                      				
                    }
                    pushFollow(FOLLOW_33);
                    lv_conditions_7_0=ruleConditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getModifierRule());
                      					}
                      					add(
                      						current,
                      						"conditions",
                      						lv_conditions_7_0,
                      						"org.xtext.SM2.Conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1160:3: ( (lv_expr_8_0= ruleExpression ) )
            // InternalSM2.g:1161:4: (lv_expr_8_0= ruleExpression )
            {
            // InternalSM2.g:1161:4: (lv_expr_8_0= ruleExpression )
            // InternalSM2.g:1162:5: lv_expr_8_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getModifierAccess().getExprExpressionParserRuleCall_8_0());
              				
            }
            pushFollow(FOLLOW_5);
            lv_expr_8_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getModifierRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_8_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_37); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_9, grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_9());
              		
            }
            // InternalSM2.g:1183:3: (this_EOLINE_10= RULE_EOLINE )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==RULE_EOLINE) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalSM2.g:1184:4: this_EOLINE_10= RULE_EOLINE
                    {
                    this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_38); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_10, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_10());
                      			
                    }

                    }
                    break;

            }

            otherlv_11=(Token)match(input,48,FOLLOW_28); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_11, grammarAccess.getModifierAccess().get_Keyword_11());
              		
            }
            this_CLOSEKEY_12=(Token)match(input,RULE_CLOSEKEY,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_12, grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_12());
              		
            }
            // InternalSM2.g:1197:3: (this_EOLINE_13= RULE_EOLINE )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==RULE_EOLINE) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalSM2.g:1198:4: this_EOLINE_13= RULE_EOLINE
                    {
                    this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_13, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_13());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:1207:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalSM2.g:1207:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalSM2.g:1208:2: iv_ruleDataType= ruleDataType EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getDataTypeRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleDataType; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:1214:1: ruleDataType returns [EObject current=null] : (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        Token this_ID_2=null;
        EObject this_CompositeType_0 = null;

        EObject this_Enum_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1220:2: ( (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID ) )
            // InternalSM2.g:1221:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID )
            {
            // InternalSM2.g:1221:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID )
            int alt31=3;
            switch ( input.LA(1) ) {
            case 49:
            case 51:
                {
                alt31=1;
                }
                break;
            case 56:
                {
                alt31=2;
                }
                break;
            case RULE_ID:
                {
                alt31=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 31, 0, input);

                throw nvae;
            }

            switch (alt31) {
                case 1 :
                    // InternalSM2.g:1222:3: this_CompositeType_0= ruleCompositeType
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_CompositeType_0=ruleCompositeType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_CompositeType_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1231:3: this_Enum_1= ruleEnum
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Enum_1=ruleEnum();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Enum_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1240:3: this_ID_2= RULE_ID
                    {
                    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(this_ID_2, grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2());
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2.g:1248:1: entryRuleCompositeType returns [EObject current=null] : iv_ruleCompositeType= ruleCompositeType EOF ;
    public final EObject entryRuleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompositeType = null;


        try {
            // InternalSM2.g:1248:54: (iv_ruleCompositeType= ruleCompositeType EOF )
            // InternalSM2.g:1249:2: iv_ruleCompositeType= ruleCompositeType EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCompositeTypeRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleCompositeType=ruleCompositeType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleCompositeType; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2.g:1255:1: ruleCompositeType returns [EObject current=null] : (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) ;
    public final EObject ruleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject this_Mapping_0 = null;

        EObject this_Struct_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:1261:2: ( (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) )
            // InternalSM2.g:1262:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            {
            // InternalSM2.g:1262:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==49) ) {
                alt32=1;
            }
            else if ( (LA32_0==51) ) {
                alt32=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 32, 0, input);

                throw nvae;
            }
            switch (alt32) {
                case 1 :
                    // InternalSM2.g:1263:3: this_Mapping_0= ruleMapping
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Mapping_0=ruleMapping();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Mapping_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1272:3: this_Struct_1= ruleStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Struct_1=ruleStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Struct_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleNumber"
    // InternalSM2.g:1284:1: entryRuleNumber returns [EObject current=null] : iv_ruleNumber= ruleNumber EOF ;
    public final EObject entryRuleNumber() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNumber = null;


        try {
            // InternalSM2.g:1284:47: (iv_ruleNumber= ruleNumber EOF )
            // InternalSM2.g:1285:2: iv_ruleNumber= ruleNumber EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getNumberRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleNumber=ruleNumber();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleNumber; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNumber"


    // $ANTLR start "ruleNumber"
    // InternalSM2.g:1291:1: ruleNumber returns [EObject current=null] : ( ( (lv_number_0_0= RULE_SINGLENUMBER ) ) | this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) ;
    public final EObject ruleNumber() throws RecognitionException {
        EObject current = null;

        Token lv_number_0_0=null;
        Token this_INTEGER_1=null;
        Token this_FLOAT_2=null;


        	enterRule();

        try {
            // InternalSM2.g:1297:2: ( ( ( (lv_number_0_0= RULE_SINGLENUMBER ) ) | this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) )
            // InternalSM2.g:1298:2: ( ( (lv_number_0_0= RULE_SINGLENUMBER ) ) | this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT )
            {
            // InternalSM2.g:1298:2: ( ( (lv_number_0_0= RULE_SINGLENUMBER ) ) | this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT )
            int alt33=3;
            switch ( input.LA(1) ) {
            case RULE_SINGLENUMBER:
                {
                alt33=1;
                }
                break;
            case RULE_INTEGER:
                {
                alt33=2;
                }
                break;
            case RULE_FLOAT:
                {
                alt33=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 33, 0, input);

                throw nvae;
            }

            switch (alt33) {
                case 1 :
                    // InternalSM2.g:1299:3: ( (lv_number_0_0= RULE_SINGLENUMBER ) )
                    {
                    // InternalSM2.g:1299:3: ( (lv_number_0_0= RULE_SINGLENUMBER ) )
                    // InternalSM2.g:1300:4: (lv_number_0_0= RULE_SINGLENUMBER )
                    {
                    // InternalSM2.g:1300:4: (lv_number_0_0= RULE_SINGLENUMBER )
                    // InternalSM2.g:1301:5: lv_number_0_0= RULE_SINGLENUMBER
                    {
                    lv_number_0_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_number_0_0, grammarAccess.getNumberAccess().getNumberSINGLENUMBERTerminalRuleCall_0_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getNumberRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"number",
                      						lv_number_0_0,
                      						"org.xtext.SM2.SINGLENUMBER");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1318:3: this_INTEGER_1= RULE_INTEGER
                    {
                    this_INTEGER_1=(Token)match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(this_INTEGER_1, grammarAccess.getNumberAccess().getINTEGERTerminalRuleCall_1());
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1323:3: this_FLOAT_2= RULE_FLOAT
                    {
                    this_FLOAT_2=(Token)match(input,RULE_FLOAT,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			newLeafNode(this_FLOAT_2, grammarAccess.getNumberAccess().getFLOATTerminalRuleCall_2());
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNumber"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:1331:1: entryRuleMapping returns [EObject current=null] : iv_ruleMapping= ruleMapping EOF ;
    public final EObject entryRuleMapping() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMapping = null;


        try {
            // InternalSM2.g:1331:48: (iv_ruleMapping= ruleMapping EOF )
            // InternalSM2.g:1332:2: iv_ruleMapping= ruleMapping EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMappingRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleMapping=ruleMapping();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleMapping; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:1338:1: ruleMapping returns [EObject current=null] : (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON ) ;
    public final EObject ruleMapping() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_3=null;
        Token lv_expr_4_0=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token lv_nameMapping_7_0=null;
        Token this_SEMICOLON_8=null;
        Enumerator lv_type_2_0 = null;

        Enumerator lv_visibility_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1344:2: ( (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON ) )
            // InternalSM2.g:1345:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON )
            {
            // InternalSM2.g:1345:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON )
            // InternalSM2.g:1346:3: otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_type_2_0= ruleSingularType ) ) otherlv_3= '=>' ( (lv_expr_4_0= RULE_STRING ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS ( (lv_visibility_6_0= ruleVisibility ) )? ( (lv_nameMapping_7_0= RULE_ID ) ) this_SEMICOLON_8= RULE_SEMICOLON
            {
            otherlv_0=(Token)match(input,49,FOLLOW_29); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getMappingAccess().getMappingKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_39); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1354:3: ( (lv_type_2_0= ruleSingularType ) )
            // InternalSM2.g:1355:4: (lv_type_2_0= ruleSingularType )
            {
            // InternalSM2.g:1355:4: (lv_type_2_0= ruleSingularType )
            // InternalSM2.g:1356:5: lv_type_2_0= ruleSingularType
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_40);
            lv_type_2_0=ruleSingularType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getMappingRule());
              					}
              					set(
              						current,
              						"type",
              						lv_type_2_0,
              						"org.xtext.SM2.SingularType");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,50,FOLLOW_41); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3());
              		
            }
            // InternalSM2.g:1377:3: ( (lv_expr_4_0= RULE_STRING ) )
            // InternalSM2.g:1378:4: (lv_expr_4_0= RULE_STRING )
            {
            // InternalSM2.g:1378:4: (lv_expr_4_0= RULE_STRING )
            // InternalSM2.g:1379:5: lv_expr_4_0= RULE_STRING
            {
            lv_expr_4_0=(Token)match(input,RULE_STRING,FOLLOW_31); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr_4_0, grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getMappingRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr",
              						lv_expr_4_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_42); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1399:3: ( (lv_visibility_6_0= ruleVisibility ) )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( ((LA34_0>=43 && LA34_0<=44)||(LA34_0>=76 && LA34_0<=77)) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalSM2.g:1400:4: (lv_visibility_6_0= ruleVisibility )
                    {
                    // InternalSM2.g:1400:4: (lv_visibility_6_0= ruleVisibility )
                    // InternalSM2.g:1401:5: lv_visibility_6_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_9);
                    lv_visibility_6_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getMappingRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_6_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1418:3: ( (lv_nameMapping_7_0= RULE_ID ) )
            // InternalSM2.g:1419:4: (lv_nameMapping_7_0= RULE_ID )
            {
            // InternalSM2.g:1419:4: (lv_nameMapping_7_0= RULE_ID )
            // InternalSM2.g:1420:5: lv_nameMapping_7_0= RULE_ID
            {
            lv_nameMapping_7_0=(Token)match(input,RULE_ID,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameMapping_7_0, grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getMappingRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameMapping",
              						lv_nameMapping_7_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:1444:1: entryRuleStruct returns [EObject current=null] : iv_ruleStruct= ruleStruct EOF ;
    public final EObject entryRuleStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStruct = null;


        try {
            // InternalSM2.g:1444:47: (iv_ruleStruct= ruleStruct EOF )
            // InternalSM2.g:1445:2: iv_ruleStruct= ruleStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleStruct=ruleStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:1451:1: ruleStruct returns [EObject current=null] : ( ( (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser ) ) ) ;
    public final EObject ruleStruct() throws RecognitionException {
        EObject current = null;

        EObject lv_typeStruct_0_1 = null;

        EObject lv_typeStruct_0_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:1457:2: ( ( ( (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser ) ) ) )
            // InternalSM2.g:1458:2: ( ( (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser ) ) )
            {
            // InternalSM2.g:1458:2: ( ( (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser ) ) )
            // InternalSM2.g:1459:3: ( (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser ) )
            {
            // InternalSM2.g:1459:3: ( (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser ) )
            // InternalSM2.g:1460:4: (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser )
            {
            // InternalSM2.g:1460:4: (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser )
            int alt35=2;
            alt35 = dfa35.predict(input);
            switch (alt35) {
                case 1 :
                    // InternalSM2.g:1461:5: lv_typeStruct_0_1= rulePersonalizedStruct
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getStructAccess().getTypeStructPersonalizedStructParserRuleCall_0_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_typeStruct_0_1=rulePersonalizedStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getStructRule());
                      					}
                      					set(
                      						current,
                      						"typeStruct",
                      						lv_typeStruct_0_1,
                      						"org.xtext.SM2.PersonalizedStruct");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1477:5: lv_typeStruct_0_2= ruleUser
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getStructAccess().getTypeStructUserParserRuleCall_0_1());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_typeStruct_0_2=ruleUser();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getStructRule());
                      					}
                      					set(
                      						current,
                      						"typeStruct",
                      						lv_typeStruct_0_2,
                      						"org.xtext.SM2.User");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }
                    break;

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRulePersonalizedStruct"
    // InternalSM2.g:1498:1: entryRulePersonalizedStruct returns [EObject current=null] : iv_rulePersonalizedStruct= rulePersonalizedStruct EOF ;
    public final EObject entryRulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonalizedStruct = null;


        try {
            // InternalSM2.g:1498:59: (iv_rulePersonalizedStruct= rulePersonalizedStruct EOF )
            // InternalSM2.g:1499:2: iv_rulePersonalizedStruct= rulePersonalizedStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPersonalizedStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePersonalizedStruct=rulePersonalizedStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePersonalizedStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonalizedStruct"


    // $ANTLR start "rulePersonalizedStruct"
    // InternalSM2.g:1505:1: rulePersonalizedStruct returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject rulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_CLOSEKEY_5=null;
        Token this_EOLINE_6=null;
        EObject lv_properties_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1511:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1512:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1512:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1513:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,51,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getPersonalizedStructAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:1517:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1518:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1518:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1519:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getPersonalizedStructAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPersonalizedStructRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_43); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1539:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==RULE_EOLINE) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalSM2.g:1540:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_39); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:1545:3: ( (lv_properties_4_0= ruleProperty ) )+
            int cnt37=0;
            loop37:
            do {
                int alt37=2;
                int LA37_0 = input.LA(1);

                if ( ((LA37_0>=52 && LA37_0<=54)||(LA37_0>=68 && LA37_0<=75)) ) {
                    alt37=1;
                }


                switch (alt37) {
            	case 1 :
            	    // InternalSM2.g:1546:4: (lv_properties_4_0= ruleProperty )
            	    {
            	    // InternalSM2.g:1546:4: (lv_properties_4_0= ruleProperty )
            	    // InternalSM2.g:1547:5: lv_properties_4_0= ruleProperty
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_44);
            	    lv_properties_4_0=ruleProperty();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getPersonalizedStructRule());
            	      					}
            	      					add(
            	      						current,
            	      						"properties",
            	      						lv_properties_4_0,
            	      						"org.xtext.SM2.Property");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt37 >= 1 ) break loop37;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(37, input);
                        throw eee;
                }
                cnt37++;
            } while (true);

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_5, grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1568:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt38=2;
            alt38 = dfa38.predict(input);
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:1569:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonalizedStruct"


    // $ANTLR start "entryRuleUser"
    // InternalSM2.g:1578:1: entryRuleUser returns [EObject current=null] : iv_ruleUser= ruleUser EOF ;
    public final EObject entryRuleUser() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUser = null;


        try {
            // InternalSM2.g:1578:45: (iv_ruleUser= ruleUser EOF )
            // InternalSM2.g:1579:2: iv_ruleUser= ruleUser EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getUserRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleUser=ruleUser();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleUser; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUser"


    // $ANTLR start "ruleUser"
    // InternalSM2.g:1585:1: ruleUser returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' otherlv_29= 'amountAccount' ( (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) ) | this_INTEGER_32= RULE_INTEGER )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) ;
    public final EObject ruleUser() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_0=null;
        Token otherlv_6=null;
        Token this_STRING_7=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Token otherlv_10=null;
        Token lv_nameUser_11_0=null;
        Token otherlv_12=null;
        Token this_STRING_13=null;
        Token this_SEMICOLON_14=null;
        Token this_EOLINE_15=null;
        Token otherlv_16=null;
        Token lv_surname_17_0=null;
        Token otherlv_18=null;
        Token this_STRING_19=null;
        Token this_SEMICOLON_20=null;
        Token this_EOLINE_21=null;
        Token otherlv_22=null;
        Token lv_email_23_0=null;
        Token otherlv_24=null;
        Token this_EMAIL_25=null;
        Token this_SEMICOLON_26=null;
        Token this_EOLINE_27=null;
        Token otherlv_28=null;
        Token otherlv_29=null;
        Token otherlv_30=null;
        Token lv_amount_31_0=null;
        Token this_INTEGER_32=null;
        Token this_SEMICOLON_33=null;
        Token this_EOLINE_34=null;
        Token this_CLOSEKEY_35=null;
        Token this_EOLINE_36=null;


        	enterRule();

        try {
            // InternalSM2.g:1591:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' otherlv_29= 'amountAccount' ( (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) ) | this_INTEGER_32= RULE_INTEGER )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) )
            // InternalSM2.g:1592:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' otherlv_29= 'amountAccount' ( (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) ) | this_INTEGER_32= RULE_INTEGER )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            {
            // InternalSM2.g:1592:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' otherlv_29= 'amountAccount' ( (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) ) | this_INTEGER_32= RULE_INTEGER )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            // InternalSM2.g:1593:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'uint' otherlv_29= 'amountAccount' ( (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) ) | this_INTEGER_32= RULE_INTEGER )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,51,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getUserAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:1597:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1598:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1598:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1599:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1619:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==RULE_EOLINE) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalSM2.g:1620:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_46); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            otherlv_4=(Token)match(input,52,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getUserAccess().getAddressKeyword_4());
              		
            }
            // InternalSM2.g:1629:3: ( (lv_idAdress_5_0= RULE_ID ) )
            // InternalSM2.g:1630:4: (lv_idAdress_5_0= RULE_ID )
            {
            // InternalSM2.g:1630:4: (lv_idAdress_5_0= RULE_ID )
            // InternalSM2.g:1631:5: lv_idAdress_5_0= RULE_ID
            {
            lv_idAdress_5_0=(Token)match(input,RULE_ID,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_idAdress_5_0, grammarAccess.getUserAccess().getIdAdressIDTerminalRuleCall_5_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"idAdress",
              						lv_idAdress_5_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:1647:3: (otherlv_6= '=' this_STRING_7= RULE_STRING )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==45) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalSM2.g:1648:4: otherlv_6= '=' this_STRING_7= RULE_STRING
                    {
                    otherlv_6=(Token)match(input,45,FOLLOW_41); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_6, grammarAccess.getUserAccess().getEqualsSignKeyword_6_0());
                      			
                    }
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_7, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_6_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            // InternalSM2.g:1661:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==RULE_EOLINE) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalSM2.g:1662:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_49); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_8());
                      			
                    }

                    }
                    break;

            }

            otherlv_10=(Token)match(input,53,FOLLOW_41); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_10, grammarAccess.getUserAccess().getStringKeyword_9());
              		
            }
            // InternalSM2.g:1671:3: ( (lv_nameUser_11_0= RULE_STRING ) )
            // InternalSM2.g:1672:4: (lv_nameUser_11_0= RULE_STRING )
            {
            // InternalSM2.g:1672:4: (lv_nameUser_11_0= RULE_STRING )
            // InternalSM2.g:1673:5: lv_nameUser_11_0= RULE_STRING
            {
            lv_nameUser_11_0=(Token)match(input,RULE_STRING,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameUser_11_0, grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_10_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameUser",
              						lv_nameUser_11_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1689:3: (otherlv_12= '=' this_STRING_13= RULE_STRING )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==45) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalSM2.g:1690:4: otherlv_12= '=' this_STRING_13= RULE_STRING
                    {
                    otherlv_12=(Token)match(input,45,FOLLOW_41); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_12, grammarAccess.getUserAccess().getEqualsSignKeyword_11_0());
                      			
                    }
                    this_STRING_13=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_13, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_11_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_14=(Token)match(input,RULE_SEMICOLON,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_14, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_12());
              		
            }
            // InternalSM2.g:1703:3: (this_EOLINE_15= RULE_EOLINE )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==RULE_EOLINE) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalSM2.g:1704:4: this_EOLINE_15= RULE_EOLINE
                    {
                    this_EOLINE_15=(Token)match(input,RULE_EOLINE,FOLLOW_49); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_15, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_13());
                      			
                    }

                    }
                    break;

            }

            otherlv_16=(Token)match(input,53,FOLLOW_41); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_16, grammarAccess.getUserAccess().getStringKeyword_14());
              		
            }
            // InternalSM2.g:1713:3: ( (lv_surname_17_0= RULE_STRING ) )
            // InternalSM2.g:1714:4: (lv_surname_17_0= RULE_STRING )
            {
            // InternalSM2.g:1714:4: (lv_surname_17_0= RULE_STRING )
            // InternalSM2.g:1715:5: lv_surname_17_0= RULE_STRING
            {
            lv_surname_17_0=(Token)match(input,RULE_STRING,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_surname_17_0, grammarAccess.getUserAccess().getSurnameSTRINGTerminalRuleCall_15_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"surname",
              						lv_surname_17_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1731:3: (otherlv_18= '=' this_STRING_19= RULE_STRING )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==45) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:1732:4: otherlv_18= '=' this_STRING_19= RULE_STRING
                    {
                    otherlv_18=(Token)match(input,45,FOLLOW_41); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_18, grammarAccess.getUserAccess().getEqualsSignKeyword_16_0());
                      			
                    }
                    this_STRING_19=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_19, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_16_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_20=(Token)match(input,RULE_SEMICOLON,FOLLOW_48); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_20, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_17());
              		
            }
            // InternalSM2.g:1745:3: (this_EOLINE_21= RULE_EOLINE )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==RULE_EOLINE) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalSM2.g:1746:4: this_EOLINE_21= RULE_EOLINE
                    {
                    this_EOLINE_21=(Token)match(input,RULE_EOLINE,FOLLOW_49); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_21, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_18());
                      			
                    }

                    }
                    break;

            }

            otherlv_22=(Token)match(input,53,FOLLOW_41); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_22, grammarAccess.getUserAccess().getStringKeyword_19());
              		
            }
            // InternalSM2.g:1755:3: ( (lv_email_23_0= RULE_STRING ) )
            // InternalSM2.g:1756:4: (lv_email_23_0= RULE_STRING )
            {
            // InternalSM2.g:1756:4: (lv_email_23_0= RULE_STRING )
            // InternalSM2.g:1757:5: lv_email_23_0= RULE_STRING
            {
            lv_email_23_0=(Token)match(input,RULE_STRING,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_email_23_0, grammarAccess.getUserAccess().getEmailSTRINGTerminalRuleCall_20_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"email",
              						lv_email_23_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1773:3: (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==45) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:1774:4: otherlv_24= '=' this_EMAIL_25= RULE_EMAIL
                    {
                    otherlv_24=(Token)match(input,45,FOLLOW_50); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_24, grammarAccess.getUserAccess().getEqualsSignKeyword_21_0());
                      			
                    }
                    this_EMAIL_25=(Token)match(input,RULE_EMAIL,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EMAIL_25, grammarAccess.getUserAccess().getEMAILTerminalRuleCall_21_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_26=(Token)match(input,RULE_SEMICOLON,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_26, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_22());
              		
            }
            // InternalSM2.g:1787:3: (this_EOLINE_27= RULE_EOLINE )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==RULE_EOLINE) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalSM2.g:1788:4: this_EOLINE_27= RULE_EOLINE
                    {
                    this_EOLINE_27=(Token)match(input,RULE_EOLINE,FOLLOW_52); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_27, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_23());
                      			
                    }

                    }
                    break;

            }

            otherlv_28=(Token)match(input,54,FOLLOW_53); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_28, grammarAccess.getUserAccess().getUintKeyword_24());
              		
            }
            otherlv_29=(Token)match(input,55,FOLLOW_54); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_29, grammarAccess.getUserAccess().getAmountAccountKeyword_25());
              		
            }
            // InternalSM2.g:1801:3: ( (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) ) | this_INTEGER_32= RULE_INTEGER )?
            int alt48=3;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==45) ) {
                alt48=1;
            }
            else if ( (LA48_0==RULE_INTEGER) ) {
                alt48=2;
            }
            switch (alt48) {
                case 1 :
                    // InternalSM2.g:1802:4: (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) )
                    {
                    // InternalSM2.g:1802:4: (otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) ) )
                    // InternalSM2.g:1803:5: otherlv_30= '=' ( (lv_amount_31_0= RULE_FLOAT ) )
                    {
                    otherlv_30=(Token)match(input,45,FOLLOW_55); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_30, grammarAccess.getUserAccess().getEqualsSignKeyword_26_0_0());
                      				
                    }
                    // InternalSM2.g:1807:5: ( (lv_amount_31_0= RULE_FLOAT ) )
                    // InternalSM2.g:1808:6: (lv_amount_31_0= RULE_FLOAT )
                    {
                    // InternalSM2.g:1808:6: (lv_amount_31_0= RULE_FLOAT )
                    // InternalSM2.g:1809:7: lv_amount_31_0= RULE_FLOAT
                    {
                    lv_amount_31_0=(Token)match(input,RULE_FLOAT,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_amount_31_0, grammarAccess.getUserAccess().getAmountFLOATTerminalRuleCall_26_0_1_0());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getUserRule());
                      							}
                      							setWithLastConsumed(
                      								current,
                      								"amount",
                      								lv_amount_31_0,
                      								"org.xtext.SM2.FLOAT");
                      						
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1827:4: this_INTEGER_32= RULE_INTEGER
                    {
                    this_INTEGER_32=(Token)match(input,RULE_INTEGER,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_INTEGER_32, grammarAccess.getUserAccess().getINTEGERTerminalRuleCall_26_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_33=(Token)match(input,RULE_SEMICOLON,FOLLOW_56); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_33, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_27());
              		
            }
            // InternalSM2.g:1836:3: (this_EOLINE_34= RULE_EOLINE )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==RULE_EOLINE) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // InternalSM2.g:1837:4: this_EOLINE_34= RULE_EOLINE
                    {
                    this_EOLINE_34=(Token)match(input,RULE_EOLINE,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_34, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_28());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_35=(Token)match(input,RULE_CLOSEKEY,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_35, grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_29());
              		
            }
            // InternalSM2.g:1846:3: (this_EOLINE_36= RULE_EOLINE )?
            int alt50=2;
            alt50 = dfa50.predict(input);
            switch (alt50) {
                case 1 :
                    // InternalSM2.g:1847:4: this_EOLINE_36= RULE_EOLINE
                    {
                    this_EOLINE_36=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_36, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_30());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUser"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:1856:1: entryRuleEnum returns [EObject current=null] : iv_ruleEnum= ruleEnum EOF ;
    public final EObject entryRuleEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnum = null;


        try {
            // InternalSM2.g:1856:45: (iv_ruleEnum= ruleEnum EOF )
            // InternalSM2.g:1857:2: iv_ruleEnum= ruleEnum EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getEnumRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleEnum=ruleEnum();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleEnum; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:1863:1: ruleEnum returns [EObject current=null] : (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEnum_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_STRING_3=null;
        Token this_COMMA_4=null;
        Token this_CLOSEKEY_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;


        	enterRule();

        try {
            // InternalSM2.g:1869:2: ( (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:1870:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:1870:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:1871:3: otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,56,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getEnumAccess().getEnumKeyword_0());
              		
            }
            // InternalSM2.g:1875:3: ( (lv_nameEnum_1_0= RULE_ID ) )
            // InternalSM2.g:1876:4: (lv_nameEnum_1_0= RULE_ID )
            {
            // InternalSM2.g:1876:4: (lv_nameEnum_1_0= RULE_ID )
            // InternalSM2.g:1877:5: lv_nameEnum_1_0= RULE_ID
            {
            lv_nameEnum_1_0=(Token)match(input,RULE_ID,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameEnum_1_0, grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEnumRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameEnum",
              						lv_nameEnum_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_41); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1897:3: (this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )? )+
            int cnt52=0;
            loop52:
            do {
                int alt52=2;
                int LA52_0 = input.LA(1);

                if ( (LA52_0==RULE_STRING) ) {
                    alt52=1;
                }


                switch (alt52) {
            	case 1 :
            	    // InternalSM2.g:1898:4: this_STRING_3= RULE_STRING (this_COMMA_4= RULE_COMMA )?
            	    {
            	    this_STRING_3=(Token)match(input,RULE_STRING,FOLLOW_57); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      				newLeafNode(this_STRING_3, grammarAccess.getEnumAccess().getSTRINGTerminalRuleCall_3_0());
            	      			
            	    }
            	    // InternalSM2.g:1902:4: (this_COMMA_4= RULE_COMMA )?
            	    int alt51=2;
            	    int LA51_0 = input.LA(1);

            	    if ( (LA51_0==RULE_COMMA) ) {
            	        alt51=1;
            	    }
            	    switch (alt51) {
            	        case 1 :
            	            // InternalSM2.g:1903:5: this_COMMA_4= RULE_COMMA
            	            {
            	            this_COMMA_4=(Token)match(input,RULE_COMMA,FOLLOW_58); if (state.failed) return current;
            	            if ( state.backtracking==0 ) {

            	              					newLeafNode(this_COMMA_4, grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_3_1());
            	              				
            	            }

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt52 >= 1 ) break loop52;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(52, input);
                        throw eee;
                }
                cnt52++;
            } while (true);

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_5, grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_4());
              		
            }
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1917:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt53=2;
            alt53 = dfa53.predict(input);
            switch (alt53) {
                case 1 :
                    // InternalSM2.g:1918:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleArray"
    // InternalSM2.g:1927:1: entryRuleArray returns [EObject current=null] : iv_ruleArray= ruleArray EOF ;
    public final EObject entryRuleArray() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArray = null;


        try {
            // InternalSM2.g:1927:46: (iv_ruleArray= ruleArray EOF )
            // InternalSM2.g:1928:2: iv_ruleArray= ruleArray EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArrayRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArray=ruleArray();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArray; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArray"


    // $ANTLR start "ruleArray"
    // InternalSM2.g:1934:1: ruleArray returns [EObject current=null] : ( ( ( (lv_isArray_0_0= '[]' ) ) | (otherlv_1= '[' ( ( (lv_dimension_2_0= RULE_SINGLENUMBER ) ) | this_INTEGER_3= RULE_INTEGER ) otherlv_4= ']' ) ) (otherlv_5= '[]' | (otherlv_6= '[' ( ( (lv_dimension_7_0= RULE_SINGLENUMBER ) ) | this_INTEGER_8= RULE_INTEGER ) otherlv_9= ']' ) )* ) ;
    public final EObject ruleArray() throws RecognitionException {
        EObject current = null;

        Token lv_isArray_0_0=null;
        Token otherlv_1=null;
        Token lv_dimension_2_0=null;
        Token this_INTEGER_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token lv_dimension_7_0=null;
        Token this_INTEGER_8=null;
        Token otherlv_9=null;


        	enterRule();

        try {
            // InternalSM2.g:1940:2: ( ( ( ( (lv_isArray_0_0= '[]' ) ) | (otherlv_1= '[' ( ( (lv_dimension_2_0= RULE_SINGLENUMBER ) ) | this_INTEGER_3= RULE_INTEGER ) otherlv_4= ']' ) ) (otherlv_5= '[]' | (otherlv_6= '[' ( ( (lv_dimension_7_0= RULE_SINGLENUMBER ) ) | this_INTEGER_8= RULE_INTEGER ) otherlv_9= ']' ) )* ) )
            // InternalSM2.g:1941:2: ( ( ( (lv_isArray_0_0= '[]' ) ) | (otherlv_1= '[' ( ( (lv_dimension_2_0= RULE_SINGLENUMBER ) ) | this_INTEGER_3= RULE_INTEGER ) otherlv_4= ']' ) ) (otherlv_5= '[]' | (otherlv_6= '[' ( ( (lv_dimension_7_0= RULE_SINGLENUMBER ) ) | this_INTEGER_8= RULE_INTEGER ) otherlv_9= ']' ) )* )
            {
            // InternalSM2.g:1941:2: ( ( ( (lv_isArray_0_0= '[]' ) ) | (otherlv_1= '[' ( ( (lv_dimension_2_0= RULE_SINGLENUMBER ) ) | this_INTEGER_3= RULE_INTEGER ) otherlv_4= ']' ) ) (otherlv_5= '[]' | (otherlv_6= '[' ( ( (lv_dimension_7_0= RULE_SINGLENUMBER ) ) | this_INTEGER_8= RULE_INTEGER ) otherlv_9= ']' ) )* )
            // InternalSM2.g:1942:3: ( ( (lv_isArray_0_0= '[]' ) ) | (otherlv_1= '[' ( ( (lv_dimension_2_0= RULE_SINGLENUMBER ) ) | this_INTEGER_3= RULE_INTEGER ) otherlv_4= ']' ) ) (otherlv_5= '[]' | (otherlv_6= '[' ( ( (lv_dimension_7_0= RULE_SINGLENUMBER ) ) | this_INTEGER_8= RULE_INTEGER ) otherlv_9= ']' ) )*
            {
            // InternalSM2.g:1942:3: ( ( (lv_isArray_0_0= '[]' ) ) | (otherlv_1= '[' ( ( (lv_dimension_2_0= RULE_SINGLENUMBER ) ) | this_INTEGER_3= RULE_INTEGER ) otherlv_4= ']' ) )
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==57) ) {
                alt55=1;
            }
            else if ( (LA55_0==58) ) {
                alt55=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 55, 0, input);

                throw nvae;
            }
            switch (alt55) {
                case 1 :
                    // InternalSM2.g:1943:4: ( (lv_isArray_0_0= '[]' ) )
                    {
                    // InternalSM2.g:1943:4: ( (lv_isArray_0_0= '[]' ) )
                    // InternalSM2.g:1944:5: (lv_isArray_0_0= '[]' )
                    {
                    // InternalSM2.g:1944:5: (lv_isArray_0_0= '[]' )
                    // InternalSM2.g:1945:6: lv_isArray_0_0= '[]'
                    {
                    lv_isArray_0_0=(Token)match(input,57,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_isArray_0_0, grammarAccess.getArrayAccess().getIsArrayLeftSquareBracketRightSquareBracketKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArrayRule());
                      						}
                      						setWithLastConsumed(current, "isArray", lv_isArray_0_0, "[]");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1958:4: (otherlv_1= '[' ( ( (lv_dimension_2_0= RULE_SINGLENUMBER ) ) | this_INTEGER_3= RULE_INTEGER ) otherlv_4= ']' )
                    {
                    // InternalSM2.g:1958:4: (otherlv_1= '[' ( ( (lv_dimension_2_0= RULE_SINGLENUMBER ) ) | this_INTEGER_3= RULE_INTEGER ) otherlv_4= ']' )
                    // InternalSM2.g:1959:5: otherlv_1= '[' ( ( (lv_dimension_2_0= RULE_SINGLENUMBER ) ) | this_INTEGER_3= RULE_INTEGER ) otherlv_4= ']'
                    {
                    otherlv_1=(Token)match(input,58,FOLLOW_60); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_1, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_0_1_0());
                      				
                    }
                    // InternalSM2.g:1963:5: ( ( (lv_dimension_2_0= RULE_SINGLENUMBER ) ) | this_INTEGER_3= RULE_INTEGER )
                    int alt54=2;
                    int LA54_0 = input.LA(1);

                    if ( (LA54_0==RULE_SINGLENUMBER) ) {
                        alt54=1;
                    }
                    else if ( (LA54_0==RULE_INTEGER) ) {
                        alt54=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 54, 0, input);

                        throw nvae;
                    }
                    switch (alt54) {
                        case 1 :
                            // InternalSM2.g:1964:6: ( (lv_dimension_2_0= RULE_SINGLENUMBER ) )
                            {
                            // InternalSM2.g:1964:6: ( (lv_dimension_2_0= RULE_SINGLENUMBER ) )
                            // InternalSM2.g:1965:7: (lv_dimension_2_0= RULE_SINGLENUMBER )
                            {
                            // InternalSM2.g:1965:7: (lv_dimension_2_0= RULE_SINGLENUMBER )
                            // InternalSM2.g:1966:8: lv_dimension_2_0= RULE_SINGLENUMBER
                            {
                            lv_dimension_2_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_61); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              								newLeafNode(lv_dimension_2_0, grammarAccess.getArrayAccess().getDimensionSINGLENUMBERTerminalRuleCall_0_1_1_0_0());
                              							
                            }
                            if ( state.backtracking==0 ) {

                              								if (current==null) {
                              									current = createModelElement(grammarAccess.getArrayRule());
                              								}
                              								setWithLastConsumed(
                              									current,
                              									"dimension",
                              									lv_dimension_2_0,
                              									"org.xtext.SM2.SINGLENUMBER");
                              							
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:1983:6: this_INTEGER_3= RULE_INTEGER
                            {
                            this_INTEGER_3=(Token)match(input,RULE_INTEGER,FOLLOW_61); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(this_INTEGER_3, grammarAccess.getArrayAccess().getINTEGERTerminalRuleCall_0_1_1_1());
                              					
                            }

                            }
                            break;

                    }

                    otherlv_4=(Token)match(input,59,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_4, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_0_1_2());
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1994:3: (otherlv_5= '[]' | (otherlv_6= '[' ( ( (lv_dimension_7_0= RULE_SINGLENUMBER ) ) | this_INTEGER_8= RULE_INTEGER ) otherlv_9= ']' ) )*
            loop57:
            do {
                int alt57=3;
                int LA57_0 = input.LA(1);

                if ( (LA57_0==57) ) {
                    alt57=1;
                }
                else if ( (LA57_0==58) ) {
                    alt57=2;
                }


                switch (alt57) {
            	case 1 :
            	    // InternalSM2.g:1995:4: otherlv_5= '[]'
            	    {
            	    otherlv_5=(Token)match(input,57,FOLLOW_59); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      				newLeafNode(otherlv_5, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_1_0());
            	      			
            	    }

            	    }
            	    break;
            	case 2 :
            	    // InternalSM2.g:2000:4: (otherlv_6= '[' ( ( (lv_dimension_7_0= RULE_SINGLENUMBER ) ) | this_INTEGER_8= RULE_INTEGER ) otherlv_9= ']' )
            	    {
            	    // InternalSM2.g:2000:4: (otherlv_6= '[' ( ( (lv_dimension_7_0= RULE_SINGLENUMBER ) ) | this_INTEGER_8= RULE_INTEGER ) otherlv_9= ']' )
            	    // InternalSM2.g:2001:5: otherlv_6= '[' ( ( (lv_dimension_7_0= RULE_SINGLENUMBER ) ) | this_INTEGER_8= RULE_INTEGER ) otherlv_9= ']'
            	    {
            	    otherlv_6=(Token)match(input,58,FOLLOW_60); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_6, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_1_1_0());
            	      				
            	    }
            	    // InternalSM2.g:2005:5: ( ( (lv_dimension_7_0= RULE_SINGLENUMBER ) ) | this_INTEGER_8= RULE_INTEGER )
            	    int alt56=2;
            	    int LA56_0 = input.LA(1);

            	    if ( (LA56_0==RULE_SINGLENUMBER) ) {
            	        alt56=1;
            	    }
            	    else if ( (LA56_0==RULE_INTEGER) ) {
            	        alt56=2;
            	    }
            	    else {
            	        if (state.backtracking>0) {state.failed=true; return current;}
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 56, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt56) {
            	        case 1 :
            	            // InternalSM2.g:2006:6: ( (lv_dimension_7_0= RULE_SINGLENUMBER ) )
            	            {
            	            // InternalSM2.g:2006:6: ( (lv_dimension_7_0= RULE_SINGLENUMBER ) )
            	            // InternalSM2.g:2007:7: (lv_dimension_7_0= RULE_SINGLENUMBER )
            	            {
            	            // InternalSM2.g:2007:7: (lv_dimension_7_0= RULE_SINGLENUMBER )
            	            // InternalSM2.g:2008:8: lv_dimension_7_0= RULE_SINGLENUMBER
            	            {
            	            lv_dimension_7_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_61); if (state.failed) return current;
            	            if ( state.backtracking==0 ) {

            	              								newLeafNode(lv_dimension_7_0, grammarAccess.getArrayAccess().getDimensionSINGLENUMBERTerminalRuleCall_1_1_1_0_0());
            	              							
            	            }
            	            if ( state.backtracking==0 ) {

            	              								if (current==null) {
            	              									current = createModelElement(grammarAccess.getArrayRule());
            	              								}
            	              								setWithLastConsumed(
            	              									current,
            	              									"dimension",
            	              									lv_dimension_7_0,
            	              									"org.xtext.SM2.SINGLENUMBER");
            	              							
            	            }

            	            }


            	            }


            	            }
            	            break;
            	        case 2 :
            	            // InternalSM2.g:2025:6: this_INTEGER_8= RULE_INTEGER
            	            {
            	            this_INTEGER_8=(Token)match(input,RULE_INTEGER,FOLLOW_61); if (state.failed) return current;
            	            if ( state.backtracking==0 ) {

            	              						newLeafNode(this_INTEGER_8, grammarAccess.getArrayAccess().getINTEGERTerminalRuleCall_1_1_1_1());
            	              					
            	            }

            	            }
            	            break;

            	    }

            	    otherlv_9=(Token)match(input,59,FOLLOW_59); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_9, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_1_1_2());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop57;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArray"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:2040:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // InternalSM2.g:2040:49: (iv_ruleProperty= ruleProperty EOF )
            // InternalSM2.g:2041:2: iv_ruleProperty= ruleProperty EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleProperty=ruleProperty();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleProperty; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:2047:1: ruleProperty returns [EObject current=null] : ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( ( (lv_inicialization_5_0= RULE_STRING ) ) | this_INTEGER_6= RULE_INTEGER )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token lv_inicialization_5_0=null;
        Token this_INTEGER_6=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        Enumerator lv_type_0_0 = null;

        EObject lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2053:2: ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( ( (lv_inicialization_5_0= RULE_STRING ) ) | this_INTEGER_6= RULE_INTEGER )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? ) )
            // InternalSM2.g:2054:2: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( ( (lv_inicialization_5_0= RULE_STRING ) ) | this_INTEGER_6= RULE_INTEGER )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            {
            // InternalSM2.g:2054:2: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( ( (lv_inicialization_5_0= RULE_STRING ) ) | this_INTEGER_6= RULE_INTEGER )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )? )
            // InternalSM2.g:2055:3: ( (lv_type_0_0= ruleSingularType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( ( (lv_inicialization_5_0= RULE_STRING ) ) | this_INTEGER_6= RULE_INTEGER )? this_SEMICOLON_7= RULE_SEMICOLON (this_EOLINE_8= RULE_EOLINE )?
            {
            // InternalSM2.g:2055:3: ( (lv_type_0_0= ruleSingularType ) )
            // InternalSM2.g:2056:4: (lv_type_0_0= ruleSingularType )
            {
            // InternalSM2.g:2056:4: (lv_type_0_0= ruleSingularType )
            // InternalSM2.g:2057:5: lv_type_0_0= ruleSingularType
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_62);
            lv_type_0_0=ruleSingularType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getPropertyRule());
              					}
              					set(
              						current,
              						"type",
              						lv_type_0_0,
              						"org.xtext.SM2.SingularType");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2074:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( ((LA58_0>=57 && LA58_0<=58)) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // InternalSM2.g:2075:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:2075:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:2076:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_42);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2093:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( ((LA59_0>=43 && LA59_0<=44)||(LA59_0>=76 && LA59_0<=77)) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // InternalSM2.g:2094:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:2094:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:2095:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_9);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2112:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:2113:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:2113:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:2114:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_63); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            otherlv_4=(Token)match(input,45,FOLLOW_64); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getPropertyAccess().getEqualsSignKeyword_4());
              		
            }
            // InternalSM2.g:2134:3: ( ( (lv_inicialization_5_0= RULE_STRING ) ) | this_INTEGER_6= RULE_INTEGER )?
            int alt60=3;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==RULE_STRING) ) {
                alt60=1;
            }
            else if ( (LA60_0==RULE_INTEGER) ) {
                alt60=2;
            }
            switch (alt60) {
                case 1 :
                    // InternalSM2.g:2135:4: ( (lv_inicialization_5_0= RULE_STRING ) )
                    {
                    // InternalSM2.g:2135:4: ( (lv_inicialization_5_0= RULE_STRING ) )
                    // InternalSM2.g:2136:5: (lv_inicialization_5_0= RULE_STRING )
                    {
                    // InternalSM2.g:2136:5: (lv_inicialization_5_0= RULE_STRING )
                    // InternalSM2.g:2137:6: lv_inicialization_5_0= RULE_STRING
                    {
                    lv_inicialization_5_0=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_inicialization_5_0, grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_5_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"inicialization",
                      							lv_inicialization_5_0,
                      							"org.eclipse.xtext.common.Terminals.STRING");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2154:4: this_INTEGER_6= RULE_INTEGER
                    {
                    this_INTEGER_6=(Token)match(input,RULE_INTEGER,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_INTEGER_6, grammarAccess.getPropertyAccess().getINTEGERTerminalRuleCall_5_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_23); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_7, grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:2163:3: (this_EOLINE_8= RULE_EOLINE )?
            int alt61=2;
            int LA61_0 = input.LA(1);

            if ( (LA61_0==RULE_EOLINE) ) {
                alt61=1;
            }
            switch (alt61) {
                case 1 :
                    // InternalSM2.g:2164:4: this_EOLINE_8= RULE_EOLINE
                    {
                    this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_8, grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:2173:1: entryRuleInputParam returns [EObject current=null] : iv_ruleInputParam= ruleInputParam EOF ;
    public final EObject entryRuleInputParam() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputParam = null;


        try {
            // InternalSM2.g:2173:51: (iv_ruleInputParam= ruleInputParam EOF )
            // InternalSM2.g:2174:2: iv_ruleInputParam= ruleInputParam EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getInputParamRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleInputParam=ruleInputParam();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleInputParam; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:2180:1: ruleInputParam returns [EObject current=null] : ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) ( (lv_comma_5_0= RULE_COMMA ) )? ) ;
    public final EObject ruleInputParam() throws RecognitionException {
        EObject current = null;

        Token lv_storage_2_0=null;
        Token otherlv_3=null;
        Token lv_nameParam_4_0=null;
        Token lv_comma_5_0=null;
        Enumerator lv_type_0_0 = null;

        EObject lv_isArray_1_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2186:2: ( ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) ( (lv_comma_5_0= RULE_COMMA ) )? ) )
            // InternalSM2.g:2187:2: ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) ( (lv_comma_5_0= RULE_COMMA ) )? )
            {
            // InternalSM2.g:2187:2: ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) ( (lv_comma_5_0= RULE_COMMA ) )? )
            // InternalSM2.g:2188:3: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) ( (lv_comma_5_0= RULE_COMMA ) )?
            {
            // InternalSM2.g:2188:3: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) )
            // InternalSM2.g:2189:4: ( (lv_type_0_0= ruleSingularType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) )
            {
            // InternalSM2.g:2189:4: ( (lv_type_0_0= ruleSingularType ) )
            // InternalSM2.g:2190:5: (lv_type_0_0= ruleSingularType )
            {
            // InternalSM2.g:2190:5: (lv_type_0_0= ruleSingularType )
            // InternalSM2.g:2191:6: lv_type_0_0= ruleSingularType
            {
            if ( state.backtracking==0 ) {

              						newCompositeNode(grammarAccess.getInputParamAccess().getTypeSingularTypeEnumRuleCall_0_0_0());
              					
            }
            pushFollow(FOLLOW_65);
            lv_type_0_0=ruleSingularType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElementForParent(grammarAccess.getInputParamRule());
              						}
              						set(
              							current,
              							"type",
              							lv_type_0_0,
              							"org.xtext.SM2.SingularType");
              						afterParserOrEnumRuleCall();
              					
            }

            }


            }

            // InternalSM2.g:2208:4: ( (lv_isArray_1_0= ruleArray ) )?
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( ((LA62_0>=57 && LA62_0<=58)) ) {
                alt62=1;
            }
            switch (alt62) {
                case 1 :
                    // InternalSM2.g:2209:5: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:2209:5: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:2210:6: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getInputParamAccess().getIsArrayArrayParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_66);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getInputParamRule());
                      						}
                      						set(
                      							current,
                      							"isArray",
                      							lv_isArray_1_0,
                      							"org.xtext.SM2.Array");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2227:4: ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )?
            int alt63=3;
            int LA63_0 = input.LA(1);

            if ( (LA63_0==60) ) {
                alt63=1;
            }
            else if ( (LA63_0==61) ) {
                alt63=2;
            }
            switch (alt63) {
                case 1 :
                    // InternalSM2.g:2228:5: ( (lv_storage_2_0= 'memory' ) )
                    {
                    // InternalSM2.g:2228:5: ( (lv_storage_2_0= 'memory' ) )
                    // InternalSM2.g:2229:6: (lv_storage_2_0= 'memory' )
                    {
                    // InternalSM2.g:2229:6: (lv_storage_2_0= 'memory' )
                    // InternalSM2.g:2230:7: lv_storage_2_0= 'memory'
                    {
                    lv_storage_2_0=(Token)match(input,60,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_storage_2_0, grammarAccess.getInputParamAccess().getStorageMemoryKeyword_0_2_0_0());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getInputParamRule());
                      							}
                      							setWithLastConsumed(current, "storage", lv_storage_2_0, "memory");
                      						
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2243:5: otherlv_3= 'local'
                    {
                    otherlv_3=(Token)match(input,61,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_3, grammarAccess.getInputParamAccess().getLocalKeyword_0_2_1());
                      				
                    }

                    }
                    break;

            }

            // InternalSM2.g:2248:4: ( (lv_nameParam_4_0= RULE_ID ) )
            // InternalSM2.g:2249:5: (lv_nameParam_4_0= RULE_ID )
            {
            // InternalSM2.g:2249:5: (lv_nameParam_4_0= RULE_ID )
            // InternalSM2.g:2250:6: lv_nameParam_4_0= RULE_ID
            {
            lv_nameParam_4_0=(Token)match(input,RULE_ID,FOLLOW_67); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						newLeafNode(lv_nameParam_4_0, grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_3_0());
              					
            }
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElement(grammarAccess.getInputParamRule());
              						}
              						setWithLastConsumed(
              							current,
              							"nameParam",
              							lv_nameParam_4_0,
              							"org.eclipse.xtext.common.Terminals.ID");
              					
            }

            }


            }


            }

            // InternalSM2.g:2267:3: ( (lv_comma_5_0= RULE_COMMA ) )?
            int alt64=2;
            int LA64_0 = input.LA(1);

            if ( (LA64_0==RULE_COMMA) ) {
                alt64=1;
            }
            switch (alt64) {
                case 1 :
                    // InternalSM2.g:2268:4: (lv_comma_5_0= RULE_COMMA )
                    {
                    // InternalSM2.g:2268:4: (lv_comma_5_0= RULE_COMMA )
                    // InternalSM2.g:2269:5: lv_comma_5_0= RULE_COMMA
                    {
                    lv_comma_5_0=(Token)match(input,RULE_COMMA,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_comma_5_0, grammarAccess.getInputParamAccess().getCommaCOMMATerminalRuleCall_1_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getInputParamRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"comma",
                      						lv_comma_5_0,
                      						"org.xtext.SM2.COMMA");
                      				
                    }

                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:2289:1: entryRuleRestriction returns [EObject current=null] : iv_ruleRestriction= ruleRestriction EOF ;
    public final EObject entryRuleRestriction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestriction = null;


        try {
            // InternalSM2.g:2289:52: (iv_ruleRestriction= ruleRestriction EOF )
            // InternalSM2.g:2290:2: iv_ruleRestriction= ruleRestriction EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRestrictionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRestriction=ruleRestriction();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRestriction; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:2296:1: ruleRestriction returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) ;
    public final EObject ruleRestriction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        EObject lv_expr1_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        EObject lv_expr2_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2302:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) )
            // InternalSM2.g:2303:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            {
            // InternalSM2.g:2303:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            // InternalSM2.g:2304:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,62,FOLLOW_29); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getRestrictionAccess().getRequireKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_33); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:2312:3: ( (lv_expr1_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:2313:4: (lv_expr1_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:2313:4: (lv_expr1_2_0= ruleSyntaxExpression )
            // InternalSM2.g:2314:5: lv_expr1_2_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr1SyntaxExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_68);
            lv_expr1_2_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"expr1",
              						lv_expr1_2_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2331:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:2332:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:2332:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:2333:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_33);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2350:3: ( (lv_expr2_4_0= ruleSyntaxExpression ) )
            // InternalSM2.g:2351:4: (lv_expr2_4_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:2351:4: (lv_expr2_4_0= ruleSyntaxExpression )
            // InternalSM2.g:2352:5: lv_expr2_4_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr2SyntaxExpressionParserRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_31);
            lv_expr2_4_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"expr2",
              						lv_expr2_4_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_7, grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:2385:1: entryRuleRestrictionGas returns [EObject current=null] : iv_ruleRestrictionGas= ruleRestrictionGas EOF ;
    public final EObject entryRuleRestrictionGas() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionGas = null;


        try {
            // InternalSM2.g:2385:55: (iv_ruleRestrictionGas= ruleRestrictionGas EOF )
            // InternalSM2.g:2386:2: iv_ruleRestrictionGas= ruleRestrictionGas EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRestrictionGasRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionGas=ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRestrictionGas; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:2392:1: ruleRestrictionGas returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= ruleNumber ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) ;
    public final EObject ruleRestrictionGas() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token this_SEMICOLON_7=null;
        Token this_EOLINE_8=null;
        EObject lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        EObject lv_amount_4_0 = null;

        Enumerator lv_typeCoin_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2398:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= ruleNumber ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE ) )
            // InternalSM2.g:2399:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= ruleNumber ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            {
            // InternalSM2.g:2399:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= ruleNumber ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE )
            // InternalSM2.g:2400:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= ruleNumber ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS this_SEMICOLON_7= RULE_SEMICOLON this_EOLINE_8= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,62,FOLLOW_29); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getRestrictionGasAccess().getRequireKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_33); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:2408:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:2409:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:2409:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2.g:2410:5: lv_expr_2_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_68);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_2_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2427:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:2428:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:2428:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:2429:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_69);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2446:3: ( (lv_amount_4_0= ruleNumber ) )
            // InternalSM2.g:2447:4: (lv_amount_4_0= ruleNumber )
            {
            // InternalSM2.g:2447:4: (lv_amount_4_0= ruleNumber )
            // InternalSM2.g:2448:5: lv_amount_4_0= ruleNumber
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getAmountNumberParserRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_70);
            lv_amount_4_0=ruleNumber();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"amount",
              						lv_amount_4_0,
              						"org.xtext.SM2.Number");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2465:3: ( (lv_typeCoin_5_0= ruleCoin ) )
            // InternalSM2.g:2466:4: (lv_typeCoin_5_0= ruleCoin )
            {
            // InternalSM2.g:2466:4: (lv_typeCoin_5_0= ruleCoin )
            // InternalSM2.g:2467:5: lv_typeCoin_5_0= ruleCoin
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0());
              				
            }
            pushFollow(FOLLOW_31);
            lv_typeCoin_5_0=ruleCoin();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"typeCoin",
              						lv_typeCoin_5_0,
              						"org.xtext.SM2.Coin");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }
            this_SEMICOLON_7=(Token)match(input,RULE_SEMICOLON,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_7, grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            this_EOLINE_8=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_8, grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2.g:2500:1: entryRuleClause returns [EObject current=null] : iv_ruleClause= ruleClause EOF ;
    public final EObject entryRuleClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClause = null;


        try {
            // InternalSM2.g:2500:47: (iv_ruleClause= ruleClause EOF )
            // InternalSM2.g:2501:2: iv_ruleClause= ruleClause EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getClauseRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleClause=ruleClause();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleClause; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2.g:2507:1: ruleClause returns [EObject current=null] : (this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE ) ;
    public final EObject ruleClause() throws RecognitionException {
        EObject current = null;

        Token lv_ispayable_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_EOLINE_9=null;
        Token this_CLOSEKEY_10=null;
        Token this_EOLINE_11=null;
        EObject this_HeadClause_0 = null;

        EObject lv_restriction_4_0 = null;

        EObject lv_restrictionGas_5_0 = null;

        EObject lv_localAttributes_6_0 = null;

        EObject lv_conditions_7_0 = null;

        EObject lv_expression_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2513:2: ( (this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE ) )
            // InternalSM2.g:2514:2: (this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE )
            {
            // InternalSM2.g:2514:2: (this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE )
            // InternalSM2.g:2515:3: this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE
            {
            if ( state.backtracking==0 ) {

              			newCompositeNode(grammarAccess.getClauseAccess().getHeadClauseParserRuleCall_0());
              		
            }
            pushFollow(FOLLOW_71);
            this_HeadClause_0=ruleHeadClause();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			current = this_HeadClause_0;
              			afterParserOrEnumRuleCall();
              		
            }
            // InternalSM2.g:2523:3: ( (lv_ispayable_1_0= 'payable' ) )?
            int alt65=2;
            int LA65_0 = input.LA(1);

            if ( (LA65_0==63) ) {
                alt65=1;
            }
            switch (alt65) {
                case 1 :
                    // InternalSM2.g:2524:4: (lv_ispayable_1_0= 'payable' )
                    {
                    // InternalSM2.g:2524:4: (lv_ispayable_1_0= 'payable' )
                    // InternalSM2.g:2525:5: lv_ispayable_1_0= 'payable'
                    {
                    lv_ispayable_1_0=(Token)match(input,63,FOLLOW_11); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_ispayable_1_0, grammarAccess.getClauseAccess().getIspayablePayableKeyword_1_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getClauseRule());
                      					}
                      					setWithLastConsumed(current, "ispayable", lv_ispayable_1_0, "payable");
                      				
                    }

                    }


                    }
                    break;

            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_72); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_3, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_3());
              		
            }
            // InternalSM2.g:2545:3: ( (lv_restriction_4_0= ruleRestriction ) )?
            int alt66=2;
            alt66 = dfa66.predict(input);
            switch (alt66) {
                case 1 :
                    // InternalSM2.g:2546:4: (lv_restriction_4_0= ruleRestriction )
                    {
                    // InternalSM2.g:2546:4: (lv_restriction_4_0= ruleRestriction )
                    // InternalSM2.g:2547:5: lv_restriction_4_0= ruleRestriction
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_4_0());
                      				
                    }
                    pushFollow(FOLLOW_72);
                    lv_restriction_4_0=ruleRestriction();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getClauseRule());
                      					}
                      					add(
                      						current,
                      						"restriction",
                      						lv_restriction_4_0,
                      						"org.xtext.SM2.Restriction");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2564:3: ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )?
            int alt67=2;
            int LA67_0 = input.LA(1);

            if ( (LA67_0==62) ) {
                alt67=1;
            }
            switch (alt67) {
                case 1 :
                    // InternalSM2.g:2565:4: (lv_restrictionGas_5_0= ruleRestrictionGas )
                    {
                    // InternalSM2.g:2565:4: (lv_restrictionGas_5_0= ruleRestrictionGas )
                    // InternalSM2.g:2566:5: lv_restrictionGas_5_0= ruleRestrictionGas
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_5_0());
                      				
                    }
                    pushFollow(FOLLOW_73);
                    lv_restrictionGas_5_0=ruleRestrictionGas();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getClauseRule());
                      					}
                      					add(
                      						current,
                      						"restrictionGas",
                      						lv_restrictionGas_5_0,
                      						"org.xtext.SM2.RestrictionGas");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2583:3: ( (lv_localAttributes_6_0= ruleAttributes ) )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==RULE_ID||LA68_0==49||(LA68_0>=51 && LA68_0<=54)||LA68_0==56||(LA68_0>=68 && LA68_0<=75)) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // InternalSM2.g:2584:4: (lv_localAttributes_6_0= ruleAttributes )
                    {
                    // InternalSM2.g:2584:4: (lv_localAttributes_6_0= ruleAttributes )
                    // InternalSM2.g:2585:5: lv_localAttributes_6_0= ruleAttributes
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getClauseAccess().getLocalAttributesAttributesParserRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_36);
                    lv_localAttributes_6_0=ruleAttributes();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getClauseRule());
                      					}
                      					add(
                      						current,
                      						"localAttributes",
                      						lv_localAttributes_6_0,
                      						"org.xtext.SM2.Attributes");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2602:3: ( (lv_conditions_7_0= ruleConditional ) )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==RULE_IF) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // InternalSM2.g:2603:4: (lv_conditions_7_0= ruleConditional )
                    {
                    // InternalSM2.g:2603:4: (lv_conditions_7_0= ruleConditional )
                    // InternalSM2.g:2604:5: lv_conditions_7_0= ruleConditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getClauseAccess().getConditionsConditionalParserRuleCall_7_0());
                      				
                    }
                    pushFollow(FOLLOW_33);
                    lv_conditions_7_0=ruleConditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getClauseRule());
                      					}
                      					add(
                      						current,
                      						"conditions",
                      						lv_conditions_7_0,
                      						"org.xtext.SM2.Conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2621:3: ( (lv_expression_8_0= ruleExpression ) )+
            int cnt70=0;
            loop70:
            do {
                int alt70=2;
                int LA70_0 = input.LA(1);

                if ( (LA70_0==RULE_SINGLENUMBER||(LA70_0>=RULE_INTEGER && LA70_0<=RULE_OPENPARENTHESIS)||(LA70_0>=RULE_FLOAT && LA70_0<=RULE_STRING)) ) {
                    alt70=1;
                }


                switch (alt70) {
            	case 1 :
            	    // InternalSM2.g:2622:4: (lv_expression_8_0= ruleExpression )
            	    {
            	    // InternalSM2.g:2622:4: (lv_expression_8_0= ruleExpression )
            	    // InternalSM2.g:2623:5: lv_expression_8_0= ruleExpression
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_8_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_74);
            	    lv_expression_8_0=ruleExpression();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getClauseRule());
            	      					}
            	      					add(
            	      						current,
            	      						"expression",
            	      						lv_expression_8_0,
            	      						"org.xtext.SM2.Expression");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt70 >= 1 ) break loop70;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(70, input);
                        throw eee;
                }
                cnt70++;
            } while (true);

            // InternalSM2.g:2640:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt71=2;
            int LA71_0 = input.LA(1);

            if ( (LA71_0==RULE_EOLINE) ) {
                alt71=1;
            }
            switch (alt71) {
                case 1 :
                    // InternalSM2.g:2641:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_28); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_9());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_10=(Token)match(input,RULE_CLOSEKEY,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_10, grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_10());
              		
            }
            this_EOLINE_11=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_11, grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_11());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRuleHeadClause"
    // InternalSM2.g:2658:1: entryRuleHeadClause returns [EObject current=null] : iv_ruleHeadClause= ruleHeadClause EOF ;
    public final EObject entryRuleHeadClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleHeadClause = null;


        try {
            // InternalSM2.g:2658:51: (iv_ruleHeadClause= ruleHeadClause EOF )
            // InternalSM2.g:2659:2: iv_ruleHeadClause= ruleHeadClause EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getHeadClauseRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleHeadClause=ruleHeadClause();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleHeadClause; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleHeadClause"


    // $ANTLR start "ruleHeadClause"
    // InternalSM2.g:2665:1: ruleHeadClause returns [EObject current=null] : (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) ;
    public final EObject ruleHeadClause() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameFunction_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Enumerator lv_visibilityAccess_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2671:2: ( (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2672:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2672:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2673:3: otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS
            {
            otherlv_0=(Token)match(input,64,FOLLOW_9); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getHeadClauseAccess().getFunctionKeyword_0());
              		
            }
            // InternalSM2.g:2677:3: ( (lv_nameFunction_1_0= RULE_ID ) )
            // InternalSM2.g:2678:4: (lv_nameFunction_1_0= RULE_ID )
            {
            // InternalSM2.g:2678:4: (lv_nameFunction_1_0= RULE_ID )
            // InternalSM2.g:2679:5: lv_nameFunction_1_0= RULE_ID
            {
            lv_nameFunction_1_0=(Token)match(input,RULE_ID,FOLLOW_29); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameFunction_1_0, grammarAccess.getHeadClauseAccess().getNameFunctionIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getHeadClauseRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameFunction",
              						lv_nameFunction_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_42); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getHeadClauseAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2699:3: ( (otherlv_3= RULE_ID ) )*
            loop72:
            do {
                int alt72=2;
                int LA72_0 = input.LA(1);

                if ( (LA72_0==RULE_ID) ) {
                    alt72=1;
                }


                switch (alt72) {
            	case 1 :
            	    // InternalSM2.g:2700:4: (otherlv_3= RULE_ID )
            	    {
            	    // InternalSM2.g:2700:4: (otherlv_3= RULE_ID )
            	    // InternalSM2.g:2701:5: otherlv_3= RULE_ID
            	    {
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElement(grammarAccess.getHeadClauseRule());
            	      					}
            	      				
            	    }
            	    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_42); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_3, grammarAccess.getHeadClauseAccess().getInputParamsInputParamCrossReference_3_0());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop72;
                }
            } while (true);

            // InternalSM2.g:2712:3: ( (lv_visibilityAccess_4_0= ruleVisibility ) )
            // InternalSM2.g:2713:4: (lv_visibilityAccess_4_0= ruleVisibility )
            {
            // InternalSM2.g:2713:4: (lv_visibilityAccess_4_0= ruleVisibility )
            // InternalSM2.g:2714:5: lv_visibilityAccess_4_0= ruleVisibility
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getHeadClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_75);
            lv_visibilityAccess_4_0=ruleVisibility();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getHeadClauseRule());
              					}
              					set(
              						current,
              						"visibilityAccess",
              						lv_visibilityAccess_4_0,
              						"org.xtext.SM2.Visibility");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2731:3: ( (otherlv_5= RULE_ID ) )?
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==RULE_ID) ) {
                alt73=1;
            }
            switch (alt73) {
                case 1 :
                    // InternalSM2.g:2732:4: (otherlv_5= RULE_ID )
                    {
                    // InternalSM2.g:2732:4: (otherlv_5= RULE_ID )
                    // InternalSM2.g:2733:5: otherlv_5= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getHeadClauseRule());
                      					}
                      				
                    }
                    otherlv_5=(Token)match(input,RULE_ID,FOLLOW_31); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_5, grammarAccess.getHeadClauseAccess().getModifierModifierCrossReference_5_0());
                      				
                    }

                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getHeadClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleHeadClause"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:2752:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // InternalSM2.g:2752:51: (iv_ruleExpression= ruleExpression EOF )
            // InternalSM2.g:2753:2: iv_ruleExpression= ruleExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:2759:1: ruleExpression returns [EObject current=null] : (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression ) ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_ArithmethicalExpression_0 = null;

        EObject this_ArithmethicalLogicalExpression_1 = null;

        EObject this_SyntaxExpression_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:2765:2: ( (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression ) )
            // InternalSM2.g:2766:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression )
            {
            // InternalSM2.g:2766:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression )
            int alt74=3;
            alt74 = dfa74.predict(input);
            switch (alt74) {
                case 1 :
                    // InternalSM2.g:2767:3: this_ArithmethicalExpression_0= ruleArithmethicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalExpression_0=ruleArithmethicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ArithmethicalExpression_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2776:3: this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalLogicalExpressionParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalLogicalExpression_1=ruleArithmethicalLogicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ArithmethicalLogicalExpression_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2785:3: this_SyntaxExpression_2= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_SyntaxExpression_2=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_SyntaxExpression_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleArithmethicalExpression"
    // InternalSM2.g:2797:1: entryRuleArithmethicalExpression returns [EObject current=null] : iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF ;
    public final EObject entryRuleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalExpression = null;


        try {
            // InternalSM2.g:2797:64: (iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF )
            // InternalSM2.g:2798:2: iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmethicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalExpression=ruleArithmethicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArithmethicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalExpression"


    // $ANTLR start "ruleArithmethicalExpression"
    // InternalSM2.g:2804:1: ruleArithmethicalExpression returns [EObject current=null] : ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= ruleNumber ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= ruleNumber ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= ruleNumber ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= ruleNumber ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) ) ;
    public final EObject ruleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        EObject lv_op1_1_0 = null;

        Enumerator lv_operator_2_0 = null;

        EObject lv_op2_3_0 = null;

        EObject lv_op1_5_0 = null;

        Enumerator lv_operator_6_0 = null;

        EObject lv_op2_7_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2810:2: ( ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= ruleNumber ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= ruleNumber ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= ruleNumber ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= ruleNumber ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) ) )
            // InternalSM2.g:2811:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= ruleNumber ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= ruleNumber ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= ruleNumber ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= ruleNumber ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:2811:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= ruleNumber ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= ruleNumber ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS ) | ( ( (lv_op1_5_0= ruleNumber ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= ruleNumber ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) )
            int alt76=2;
            int LA76_0 = input.LA(1);

            if ( (LA76_0==RULE_OPENPARENTHESIS) ) {
                alt76=1;
            }
            else if ( (LA76_0==RULE_SINGLENUMBER||LA76_0==RULE_INTEGER||LA76_0==RULE_FLOAT) ) {
                alt76=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 76, 0, input);

                throw nvae;
            }
            switch (alt76) {
                case 1 :
                    // InternalSM2.g:2812:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= ruleNumber ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= ruleNumber ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:2812:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= ruleNumber ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= ruleNumber ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:2813:4: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= ruleNumber ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= ruleNumber ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS
                    {
                    this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_69); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0());
                      			
                    }
                    // InternalSM2.g:2817:4: ( (lv_op1_1_0= ruleNumber ) )
                    // InternalSM2.g:2818:5: (lv_op1_1_0= ruleNumber )
                    {
                    // InternalSM2.g:2818:5: (lv_op1_1_0= ruleNumber )
                    // InternalSM2.g:2819:6: lv_op1_1_0= ruleNumber
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOp1NumberParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_76);
                    lv_op1_1_0=ruleNumber();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"op1",
                      							lv_op1_1_0,
                      							"org.xtext.SM2.Number");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2836:4: ( (lv_operator_2_0= ruleArithmeticalOperator ) )
                    // InternalSM2.g:2837:5: (lv_operator_2_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2.g:2837:5: (lv_operator_2_0= ruleArithmeticalOperator )
                    // InternalSM2.g:2838:6: lv_operator_2_0= ruleArithmeticalOperator
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0());
                      					
                    }
                    pushFollow(FOLLOW_69);
                    lv_operator_2_0=ruleArithmeticalOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"operator",
                      							lv_operator_2_0,
                      							"org.xtext.SM2.ArithmeticalOperator");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2855:4: ( (lv_op2_3_0= ruleNumber ) )
                    // InternalSM2.g:2856:5: (lv_op2_3_0= ruleNumber )
                    {
                    // InternalSM2.g:2856:5: (lv_op2_3_0= ruleNumber )
                    // InternalSM2.g:2857:6: lv_op2_3_0= ruleNumber
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOp2NumberParserRuleCall_0_3_0());
                      					
                    }
                    pushFollow(FOLLOW_31);
                    lv_op2_3_0=ruleNumber();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"op2",
                      							lv_op2_3_0,
                      							"org.xtext.SM2.Number");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:2880:3: ( ( (lv_op1_5_0= ruleNumber ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= ruleNumber ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:2880:3: ( ( (lv_op1_5_0= ruleNumber ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= ruleNumber ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? )
                    // InternalSM2.g:2881:4: ( (lv_op1_5_0= ruleNumber ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= ruleNumber ) ) (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )?
                    {
                    // InternalSM2.g:2881:4: ( (lv_op1_5_0= ruleNumber ) )
                    // InternalSM2.g:2882:5: (lv_op1_5_0= ruleNumber )
                    {
                    // InternalSM2.g:2882:5: (lv_op1_5_0= ruleNumber )
                    // InternalSM2.g:2883:6: lv_op1_5_0= ruleNumber
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOp1NumberParserRuleCall_1_0_0());
                      					
                    }
                    pushFollow(FOLLOW_76);
                    lv_op1_5_0=ruleNumber();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"op1",
                      							lv_op1_5_0,
                      							"org.xtext.SM2.Number");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2900:4: ( (lv_operator_6_0= ruleArithmeticalOperator ) )
                    // InternalSM2.g:2901:5: (lv_operator_6_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2.g:2901:5: (lv_operator_6_0= ruleArithmeticalOperator )
                    // InternalSM2.g:2902:6: lv_operator_6_0= ruleArithmeticalOperator
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_69);
                    lv_operator_6_0=ruleArithmeticalOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"operator",
                      							lv_operator_6_0,
                      							"org.xtext.SM2.ArithmeticalOperator");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2919:4: ( (lv_op2_7_0= ruleNumber ) )
                    // InternalSM2.g:2920:5: (lv_op2_7_0= ruleNumber )
                    {
                    // InternalSM2.g:2920:5: (lv_op2_7_0= ruleNumber )
                    // InternalSM2.g:2921:6: lv_op2_7_0= ruleNumber
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOp2NumberParserRuleCall_1_2_0());
                      					
                    }
                    pushFollow(FOLLOW_77);
                    lv_op2_7_0=ruleNumber();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"op2",
                      							lv_op2_7_0,
                      							"org.xtext.SM2.Number");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:2938:4: (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )?
                    int alt75=2;
                    int LA75_0 = input.LA(1);

                    if ( (LA75_0==RULE_SEMICOLON) ) {
                        int LA75_1 = input.LA(2);

                        if ( (LA75_1==RULE_EOLINE) ) {
                            int LA75_3 = input.LA(3);

                            if ( (LA75_3==EOF||(LA75_3>=RULE_SEMICOLON && LA75_3<=RULE_EOLINE)||(LA75_3>=RULE_CLOSEKEY && LA75_3<=RULE_SINGLENUMBER)||(LA75_3>=RULE_INTEGER && LA75_3<=RULE_STRING)) ) {
                                alt75=1;
                            }
                        }
                    }
                    switch (alt75) {
                        case 1 :
                            // InternalSM2.g:2939:5: this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE
                            {
                            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_24); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_8, grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0());
                              				
                            }
                            this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_9, grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalExpression"


    // $ANTLR start "entryRuleArithmethicalLogicalExpression"
    // InternalSM2.g:2953:1: entryRuleArithmethicalLogicalExpression returns [EObject current=null] : iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF ;
    public final EObject entryRuleArithmethicalLogicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalLogicalExpression = null;


        try {
            // InternalSM2.g:2953:71: (iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF )
            // InternalSM2.g:2954:2: iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalLogicalExpression=ruleArithmethicalLogicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArithmethicalLogicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalLogicalExpression"


    // $ANTLR start "ruleArithmethicalLogicalExpression"
    // InternalSM2.g:2960:1: ruleArithmethicalLogicalExpression returns [EObject current=null] : (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= ruleNumber ) ) ( (lv_operator1_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= ruleNumber ) ) ( (lv_operator2_4_0= ruleComparationOperator ) ) ( ( (lv_expr_5_0= ruleArithmethicalExpression ) ) | ( (lv_expr_6_0= ruleNumber ) ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) ;
    public final EObject ruleArithmethicalLogicalExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token this_CLOSEPARENTHESIS_7=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        EObject lv_op1_1_0 = null;

        Enumerator lv_operator1_2_0 = null;

        EObject lv_op2_3_0 = null;

        Enumerator lv_operator2_4_0 = null;

        EObject lv_expr_5_0 = null;

        EObject lv_expr_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2966:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= ruleNumber ) ) ( (lv_operator1_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= ruleNumber ) ) ( (lv_operator2_4_0= ruleComparationOperator ) ) ( ( (lv_expr_5_0= ruleArithmethicalExpression ) ) | ( (lv_expr_6_0= ruleNumber ) ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? ) )
            // InternalSM2.g:2967:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= ruleNumber ) ) ( (lv_operator1_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= ruleNumber ) ) ( (lv_operator2_4_0= ruleComparationOperator ) ) ( ( (lv_expr_5_0= ruleArithmethicalExpression ) ) | ( (lv_expr_6_0= ruleNumber ) ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? )
            {
            // InternalSM2.g:2967:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= ruleNumber ) ) ( (lv_operator1_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= ruleNumber ) ) ( (lv_operator2_4_0= ruleComparationOperator ) ) ( ( (lv_expr_5_0= ruleArithmethicalExpression ) ) | ( (lv_expr_6_0= ruleNumber ) ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )? )
            // InternalSM2.g:2968:3: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( (lv_op1_1_0= ruleNumber ) ) ( (lv_operator1_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= ruleNumber ) ) ( (lv_operator2_4_0= ruleComparationOperator ) ) ( ( (lv_expr_5_0= ruleArithmethicalExpression ) ) | ( (lv_expr_6_0= ruleNumber ) ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )?
            {
            this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_69); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0());
              		
            }
            // InternalSM2.g:2972:3: ( (lv_op1_1_0= ruleNumber ) )
            // InternalSM2.g:2973:4: (lv_op1_1_0= ruleNumber )
            {
            // InternalSM2.g:2973:4: (lv_op1_1_0= ruleNumber )
            // InternalSM2.g:2974:5: lv_op1_1_0= ruleNumber
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getOp1NumberParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_76);
            lv_op1_1_0=ruleNumber();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"op1",
              						lv_op1_1_0,
              						"org.xtext.SM2.Number");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:2991:3: ( (lv_operator1_2_0= ruleArithmeticalOperator ) )
            // InternalSM2.g:2992:4: (lv_operator1_2_0= ruleArithmeticalOperator )
            {
            // InternalSM2.g:2992:4: (lv_operator1_2_0= ruleArithmeticalOperator )
            // InternalSM2.g:2993:5: lv_operator1_2_0= ruleArithmeticalOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator1ArithmeticalOperatorEnumRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_69);
            lv_operator1_2_0=ruleArithmeticalOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"operator1",
              						lv_operator1_2_0,
              						"org.xtext.SM2.ArithmeticalOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3010:3: ( (lv_op2_3_0= ruleNumber ) )
            // InternalSM2.g:3011:4: (lv_op2_3_0= ruleNumber )
            {
            // InternalSM2.g:3011:4: (lv_op2_3_0= ruleNumber )
            // InternalSM2.g:3012:5: lv_op2_3_0= ruleNumber
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getOp2NumberParserRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_68);
            lv_op2_3_0=ruleNumber();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"op2",
              						lv_op2_3_0,
              						"org.xtext.SM2.Number");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3029:3: ( (lv_operator2_4_0= ruleComparationOperator ) )
            // InternalSM2.g:3030:4: (lv_operator2_4_0= ruleComparationOperator )
            {
            // InternalSM2.g:3030:4: (lv_operator2_4_0= ruleComparationOperator )
            // InternalSM2.g:3031:5: lv_operator2_4_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator2ComparationOperatorEnumRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_69);
            lv_operator2_4_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"operator2",
              						lv_operator2_4_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3048:3: ( ( (lv_expr_5_0= ruleArithmethicalExpression ) ) | ( (lv_expr_6_0= ruleNumber ) ) )
            int alt77=2;
            switch ( input.LA(1) ) {
            case RULE_OPENPARENTHESIS:
                {
                alt77=1;
                }
                break;
            case RULE_SINGLENUMBER:
                {
                int LA77_2 = input.LA(2);

                if ( ((LA77_2>=88 && LA77_2<=92)) ) {
                    alt77=1;
                }
                else if ( (LA77_2==RULE_CLOSEPARENTHESIS) ) {
                    alt77=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 77, 2, input);

                    throw nvae;
                }
                }
                break;
            case RULE_INTEGER:
                {
                int LA77_3 = input.LA(2);

                if ( ((LA77_3>=88 && LA77_3<=92)) ) {
                    alt77=1;
                }
                else if ( (LA77_3==RULE_CLOSEPARENTHESIS) ) {
                    alt77=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 77, 3, input);

                    throw nvae;
                }
                }
                break;
            case RULE_FLOAT:
                {
                int LA77_4 = input.LA(2);

                if ( ((LA77_4>=88 && LA77_4<=92)) ) {
                    alt77=1;
                }
                else if ( (LA77_4==RULE_CLOSEPARENTHESIS) ) {
                    alt77=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 77, 4, input);

                    throw nvae;
                }
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 77, 0, input);

                throw nvae;
            }

            switch (alt77) {
                case 1 :
                    // InternalSM2.g:3049:4: ( (lv_expr_5_0= ruleArithmethicalExpression ) )
                    {
                    // InternalSM2.g:3049:4: ( (lv_expr_5_0= ruleArithmethicalExpression ) )
                    // InternalSM2.g:3050:5: (lv_expr_5_0= ruleArithmethicalExpression )
                    {
                    // InternalSM2.g:3050:5: (lv_expr_5_0= ruleArithmethicalExpression )
                    // InternalSM2.g:3051:6: lv_expr_5_0= ruleArithmethicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getExprArithmethicalExpressionParserRuleCall_5_0_0());
                      					
                    }
                    pushFollow(FOLLOW_31);
                    lv_expr_5_0=ruleArithmethicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"expr",
                      							lv_expr_5_0,
                      							"org.xtext.SM2.ArithmethicalExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3069:4: ( (lv_expr_6_0= ruleNumber ) )
                    {
                    // InternalSM2.g:3069:4: ( (lv_expr_6_0= ruleNumber ) )
                    // InternalSM2.g:3070:5: (lv_expr_6_0= ruleNumber )
                    {
                    // InternalSM2.g:3070:5: (lv_expr_6_0= ruleNumber )
                    // InternalSM2.g:3071:6: lv_expr_6_0= ruleNumber
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getExprNumberParserRuleCall_5_1_0());
                      					
                    }
                    pushFollow(FOLLOW_31);
                    lv_expr_6_0=ruleNumber();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"expr",
                      							lv_expr_6_0,
                      							"org.xtext.SM2.Number");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_7=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_77); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_7, grammarAccess.getArithmethicalLogicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:3093:3: (this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )?
            int alt78=2;
            int LA78_0 = input.LA(1);

            if ( (LA78_0==RULE_SEMICOLON) ) {
                int LA78_1 = input.LA(2);

                if ( (LA78_1==RULE_EOLINE) ) {
                    int LA78_3 = input.LA(3);

                    if ( (LA78_3==EOF||(LA78_3>=RULE_SEMICOLON && LA78_3<=RULE_EOLINE)||(LA78_3>=RULE_CLOSEKEY && LA78_3<=RULE_SINGLENUMBER)||(LA78_3>=RULE_INTEGER && LA78_3<=RULE_STRING)) ) {
                        alt78=1;
                    }
                }
            }
            switch (alt78) {
                case 1 :
                    // InternalSM2.g:3094:4: this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE
                    {
                    this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_24); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_8, grammarAccess.getArithmethicalLogicalExpressionAccess().getSEMICOLONTerminalRuleCall_7_0());
                      			
                    }
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getArithmethicalLogicalExpressionAccess().getEOLINETerminalRuleCall_7_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalLogicalExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:3107:1: entryRuleSyntaxExpression returns [EObject current=null] : iv_ruleSyntaxExpression= ruleSyntaxExpression EOF ;
    public final EObject entryRuleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSyntaxExpression = null;


        try {
            // InternalSM2.g:3107:57: (iv_ruleSyntaxExpression= ruleSyntaxExpression EOF )
            // InternalSM2.g:3108:2: iv_ruleSyntaxExpression= ruleSyntaxExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSyntaxExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSyntaxExpression=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSyntaxExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:3114:1: ruleSyntaxExpression returns [EObject current=null] : ( ( (lv_text_0_0= RULE_STRING ) ) | (this_Number_1= ruleNumber (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) ) ;
    public final EObject ruleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        Token lv_text_0_0=null;
        Token this_SEMICOLON_2=null;
        Token this_EOLINE_3=null;
        EObject this_Number_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:3120:2: ( ( ( (lv_text_0_0= RULE_STRING ) ) | (this_Number_1= ruleNumber (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) ) )
            // InternalSM2.g:3121:2: ( ( (lv_text_0_0= RULE_STRING ) ) | (this_Number_1= ruleNumber (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:3121:2: ( ( (lv_text_0_0= RULE_STRING ) ) | (this_Number_1= ruleNumber (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) )
            int alt80=2;
            int LA80_0 = input.LA(1);

            if ( (LA80_0==RULE_STRING) ) {
                alt80=1;
            }
            else if ( (LA80_0==RULE_SINGLENUMBER||LA80_0==RULE_INTEGER||LA80_0==RULE_FLOAT) ) {
                alt80=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 80, 0, input);

                throw nvae;
            }
            switch (alt80) {
                case 1 :
                    // InternalSM2.g:3122:3: ( (lv_text_0_0= RULE_STRING ) )
                    {
                    // InternalSM2.g:3122:3: ( (lv_text_0_0= RULE_STRING ) )
                    // InternalSM2.g:3123:4: (lv_text_0_0= RULE_STRING )
                    {
                    // InternalSM2.g:3123:4: (lv_text_0_0= RULE_STRING )
                    // InternalSM2.g:3124:5: lv_text_0_0= RULE_STRING
                    {
                    lv_text_0_0=(Token)match(input,RULE_STRING,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_text_0_0, grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getSyntaxExpressionRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"text",
                      						lv_text_0_0,
                      						"org.eclipse.xtext.common.Terminals.STRING");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3141:3: (this_Number_1= ruleNumber (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:3141:3: (this_Number_1= ruleNumber (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
                    // InternalSM2.g:3142:4: this_Number_1= ruleNumber (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
                    {
                    if ( state.backtracking==0 ) {

                      				newCompositeNode(grammarAccess.getSyntaxExpressionAccess().getNumberParserRuleCall_1_0());
                      			
                    }
                    pushFollow(FOLLOW_77);
                    this_Number_1=ruleNumber();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = this_Number_1;
                      				afterParserOrEnumRuleCall();
                      			
                    }
                    // InternalSM2.g:3150:4: (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
                    int alt79=2;
                    int LA79_0 = input.LA(1);

                    if ( (LA79_0==RULE_SEMICOLON) ) {
                        int LA79_1 = input.LA(2);

                        if ( (LA79_1==RULE_EOLINE) ) {
                            int LA79_3 = input.LA(3);

                            if ( (LA79_3==EOF||(LA79_3>=RULE_SEMICOLON && LA79_3<=RULE_EOLINE)||(LA79_3>=RULE_CLOSEKEY && LA79_3<=RULE_SINGLENUMBER)||(LA79_3>=RULE_INTEGER && LA79_3<=RULE_STRING)||(LA79_3>=35 && LA79_3<=38)||(LA79_3>=84 && LA79_3<=85)) ) {
                                alt79=1;
                            }
                        }
                    }
                    switch (alt79) {
                        case 1 :
                            // InternalSM2.g:3151:5: this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE
                            {
                            this_SEMICOLON_2=(Token)match(input,RULE_SEMICOLON,FOLLOW_24); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_2, grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0());
                              				
                            }
                            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_3, grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleConditional"
    // InternalSM2.g:3165:1: entryRuleConditional returns [EObject current=null] : iv_ruleConditional= ruleConditional EOF ;
    public final EObject entryRuleConditional() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConditional = null;


        try {
            // InternalSM2.g:3165:52: (iv_ruleConditional= ruleConditional EOF )
            // InternalSM2.g:3166:2: iv_ruleConditional= ruleConditional EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConditionalRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleConditional=ruleConditional();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleConditional; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConditional"


    // $ANTLR start "ruleConditional"
    // InternalSM2.g:3172:1: ruleConditional returns [EObject current=null] : (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_Expression_2= ruleExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_OPENKEY_4= RULE_OPENKEY ( (lv_expressions_5_0= ruleExpression ) )* this_CLOSEKEY_6= RULE_CLOSEKEY (this_ELSE_7= RULE_ELSE ( (lv_needOtherCondition_8_0= ruleConditional ) ) ) ) ;
    public final EObject ruleConditional() throws RecognitionException {
        EObject current = null;

        Token this_IF_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_3=null;
        Token this_OPENKEY_4=null;
        Token this_CLOSEKEY_6=null;
        Token this_ELSE_7=null;
        EObject this_Expression_2 = null;

        EObject lv_expressions_5_0 = null;

        EObject lv_needOtherCondition_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3178:2: ( (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_Expression_2= ruleExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_OPENKEY_4= RULE_OPENKEY ( (lv_expressions_5_0= ruleExpression ) )* this_CLOSEKEY_6= RULE_CLOSEKEY (this_ELSE_7= RULE_ELSE ( (lv_needOtherCondition_8_0= ruleConditional ) ) ) ) )
            // InternalSM2.g:3179:2: (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_Expression_2= ruleExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_OPENKEY_4= RULE_OPENKEY ( (lv_expressions_5_0= ruleExpression ) )* this_CLOSEKEY_6= RULE_CLOSEKEY (this_ELSE_7= RULE_ELSE ( (lv_needOtherCondition_8_0= ruleConditional ) ) ) )
            {
            // InternalSM2.g:3179:2: (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_Expression_2= ruleExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_OPENKEY_4= RULE_OPENKEY ( (lv_expressions_5_0= ruleExpression ) )* this_CLOSEKEY_6= RULE_CLOSEKEY (this_ELSE_7= RULE_ELSE ( (lv_needOtherCondition_8_0= ruleConditional ) ) ) )
            // InternalSM2.g:3180:3: this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS this_Expression_2= ruleExpression this_CLOSEPARENTHESIS_3= RULE_CLOSEPARENTHESIS this_OPENKEY_4= RULE_OPENKEY ( (lv_expressions_5_0= ruleExpression ) )* this_CLOSEKEY_6= RULE_CLOSEKEY (this_ELSE_7= RULE_ELSE ( (lv_needOtherCondition_8_0= ruleConditional ) ) )
            {
            this_IF_0=(Token)match(input,RULE_IF,FOLLOW_29); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_IF_0, grammarAccess.getConditionalAccess().getIFTerminalRuleCall_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_33); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConditionalAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            if ( state.backtracking==0 ) {

              			newCompositeNode(grammarAccess.getConditionalAccess().getExpressionParserRuleCall_2());
              		
            }
            pushFollow(FOLLOW_31);
            this_Expression_2=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			current = this_Expression_2;
              			afterParserOrEnumRuleCall();
              		
            }
            this_CLOSEPARENTHESIS_3=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_3, grammarAccess.getConditionalAccess().getCLOSEPARENTHESISTerminalRuleCall_3());
              		
            }
            this_OPENKEY_4=(Token)match(input,RULE_OPENKEY,FOLLOW_78); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_4, grammarAccess.getConditionalAccess().getOPENKEYTerminalRuleCall_4());
              		
            }
            // InternalSM2.g:3204:3: ( (lv_expressions_5_0= ruleExpression ) )*
            loop81:
            do {
                int alt81=2;
                int LA81_0 = input.LA(1);

                if ( (LA81_0==RULE_SINGLENUMBER||(LA81_0>=RULE_INTEGER && LA81_0<=RULE_OPENPARENTHESIS)||(LA81_0>=RULE_FLOAT && LA81_0<=RULE_STRING)) ) {
                    alt81=1;
                }


                switch (alt81) {
            	case 1 :
            	    // InternalSM2.g:3205:4: (lv_expressions_5_0= ruleExpression )
            	    {
            	    // InternalSM2.g:3205:4: (lv_expressions_5_0= ruleExpression )
            	    // InternalSM2.g:3206:5: lv_expressions_5_0= ruleExpression
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getConditionalAccess().getExpressionsExpressionParserRuleCall_5_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_78);
            	    lv_expressions_5_0=ruleExpression();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getConditionalRule());
            	      					}
            	      					add(
            	      						current,
            	      						"expressions",
            	      						lv_expressions_5_0,
            	      						"org.xtext.SM2.Expression");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop81;
                }
            } while (true);

            this_CLOSEKEY_6=(Token)match(input,RULE_CLOSEKEY,FOLLOW_79); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_6, grammarAccess.getConditionalAccess().getCLOSEKEYTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:3227:3: (this_ELSE_7= RULE_ELSE ( (lv_needOtherCondition_8_0= ruleConditional ) ) )
            // InternalSM2.g:3228:4: this_ELSE_7= RULE_ELSE ( (lv_needOtherCondition_8_0= ruleConditional ) )
            {
            this_ELSE_7=(Token)match(input,RULE_ELSE,FOLLOW_80); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(this_ELSE_7, grammarAccess.getConditionalAccess().getELSETerminalRuleCall_7_0());
              			
            }
            // InternalSM2.g:3232:4: ( (lv_needOtherCondition_8_0= ruleConditional ) )
            // InternalSM2.g:3233:5: (lv_needOtherCondition_8_0= ruleConditional )
            {
            // InternalSM2.g:3233:5: (lv_needOtherCondition_8_0= ruleConditional )
            // InternalSM2.g:3234:6: lv_needOtherCondition_8_0= ruleConditional
            {
            if ( state.backtracking==0 ) {

              						newCompositeNode(grammarAccess.getConditionalAccess().getNeedOtherConditionConditionalParserRuleCall_7_1_0());
              					
            }
            pushFollow(FOLLOW_2);
            lv_needOtherCondition_8_0=ruleConditional();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElementForParent(grammarAccess.getConditionalRule());
              						}
              						set(
              							current,
              							"needOtherCondition",
              							lv_needOtherCondition_8_0,
              							"org.xtext.SM2.Conditional");
              						afterParserOrEnumRuleCall();
              					
            }

            }


            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConditional"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:3256:1: entryRuleComment returns [EObject current=null] : iv_ruleComment= ruleComment EOF ;
    public final EObject entryRuleComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleComment = null;


        try {
            // InternalSM2.g:3256:48: (iv_ruleComment= ruleComment EOF )
            // InternalSM2.g:3257:2: iv_ruleComment= ruleComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleComment=ruleComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:3263:1: ruleComment returns [EObject current=null] : (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) ;
    public final EObject ruleComment() throws RecognitionException {
        EObject current = null;

        EObject this_ShortComment_0 = null;

        EObject this_LongComment_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:3269:2: ( (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) )
            // InternalSM2.g:3270:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            {
            // InternalSM2.g:3270:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            int alt82=2;
            int LA82_0 = input.LA(1);

            if ( (LA82_0==65) ) {
                alt82=1;
            }
            else if ( (LA82_0==66) ) {
                alt82=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 82, 0, input);

                throw nvae;
            }
            switch (alt82) {
                case 1 :
                    // InternalSM2.g:3271:3: this_ShortComment_0= ruleShortComment
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ShortComment_0=ruleShortComment();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ShortComment_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3280:3: this_LongComment_1= ruleLongComment
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_LongComment_1=ruleLongComment();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_LongComment_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:3292:1: entryRuleShortComment returns [EObject current=null] : iv_ruleShortComment= ruleShortComment EOF ;
    public final EObject entryRuleShortComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleShortComment = null;


        try {
            // InternalSM2.g:3292:53: (iv_ruleShortComment= ruleShortComment EOF )
            // InternalSM2.g:3293:2: iv_ruleShortComment= ruleShortComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getShortCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleShortComment=ruleShortComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleShortComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:3299:1: ruleShortComment returns [EObject current=null] : (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) ) ;
    public final EObject ruleShortComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expr_1_0=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:3305:2: ( (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) ) )
            // InternalSM2.g:3306:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) )
            {
            // InternalSM2.g:3306:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) )
            // InternalSM2.g:3307:3: otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE )
            {
            otherlv_0=(Token)match(input,65,FOLLOW_41); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0());
              		
            }
            // InternalSM2.g:3311:3: ( (lv_expr_1_0= RULE_STRING ) )
            // InternalSM2.g:3312:4: (lv_expr_1_0= RULE_STRING )
            {
            // InternalSM2.g:3312:4: (lv_expr_1_0= RULE_STRING )
            // InternalSM2.g:3313:5: lv_expr_1_0= RULE_STRING
            {
            lv_expr_1_0=(Token)match(input,RULE_STRING,FOLLOW_24); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr_1_0, grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getShortCommentRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr",
              						lv_expr_1_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:3329:3: ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE )
            // InternalSM2.g:3330:4: ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE
            {
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(this_EOLINE_2, grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:3340:1: entryRuleLongComment returns [EObject current=null] : iv_ruleLongComment= ruleLongComment EOF ;
    public final EObject entryRuleLongComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLongComment = null;


        try {
            // InternalSM2.g:3340:52: (iv_ruleLongComment= ruleLongComment EOF )
            // InternalSM2.g:3341:2: iv_ruleLongComment= ruleLongComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLongCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLongComment=ruleLongComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLongComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:3347:1: ruleLongComment returns [EObject current=null] : (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' ) ) ;
    public final EObject ruleLongComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expression_1_1=null;
        Token lv_expression_1_2=null;
        Token lv_expression_1_3=null;
        Token lv_expression_1_4=null;
        Token lv_expression_1_5=null;
        Token lv_expression_1_6=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSM2.g:3353:2: ( (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' ) ) )
            // InternalSM2.g:3354:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' ) )
            {
            // InternalSM2.g:3354:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' ) )
            // InternalSM2.g:3355:3: otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) ) ( ( '*/' )=>otherlv_2= '*/' )
            {
            otherlv_0=(Token)match(input,66,FOLLOW_81); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0());
              		
            }
            // InternalSM2.g:3359:3: ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )
            // InternalSM2.g:3360:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
            {
            // InternalSM2.g:3360:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
            // InternalSM2.g:3361:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
            {
            // InternalSM2.g:3361:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
            int alt83=6;
            switch ( input.LA(1) ) {
            case RULE_STRING:
                {
                alt83=1;
                }
                break;
            case RULE_PARAMSLONGCOMENT:
                {
                alt83=2;
                }
                break;
            case RULE_DEVLONGCOMENT:
                {
                alt83=3;
                }
                break;
            case RULE_RETURNSLONGCOMENT:
                {
                alt83=4;
                }
                break;
            case RULE_TITLELONGCOMENT:
                {
                alt83=5;
                }
                break;
            case RULE_NOTICELONGCOMENT:
                {
                alt83=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 83, 0, input);

                throw nvae;
            }

            switch (alt83) {
                case 1 :
                    // InternalSM2.g:3362:6: lv_expression_1_1= RULE_STRING
                    {
                    lv_expression_1_1=(Token)match(input,RULE_STRING,FOLLOW_82); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_1, grammarAccess.getLongCommentAccess().getExpressionSTRINGTerminalRuleCall_1_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_1,
                      							"org.eclipse.xtext.common.Terminals.STRING");
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3377:6: lv_expression_1_2= RULE_PARAMSLONGCOMENT
                    {
                    lv_expression_1_2=(Token)match(input,RULE_PARAMSLONGCOMENT,FOLLOW_82); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_2, grammarAccess.getLongCommentAccess().getExpressionPARAMSLONGCOMENTTerminalRuleCall_1_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_2,
                      							"org.xtext.SM2.PARAMSLONGCOMENT");
                      					
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:3392:6: lv_expression_1_3= RULE_DEVLONGCOMENT
                    {
                    lv_expression_1_3=(Token)match(input,RULE_DEVLONGCOMENT,FOLLOW_82); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_3, grammarAccess.getLongCommentAccess().getExpressionDEVLONGCOMENTTerminalRuleCall_1_0_2());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_3,
                      							"org.xtext.SM2.DEVLONGCOMENT");
                      					
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:3407:6: lv_expression_1_4= RULE_RETURNSLONGCOMENT
                    {
                    lv_expression_1_4=(Token)match(input,RULE_RETURNSLONGCOMENT,FOLLOW_82); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_4, grammarAccess.getLongCommentAccess().getExpressionRETURNSLONGCOMENTTerminalRuleCall_1_0_3());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_4,
                      							"org.xtext.SM2.RETURNSLONGCOMENT");
                      					
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:3422:6: lv_expression_1_5= RULE_TITLELONGCOMENT
                    {
                    lv_expression_1_5=(Token)match(input,RULE_TITLELONGCOMENT,FOLLOW_82); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_5, grammarAccess.getLongCommentAccess().getExpressionTITLELONGCOMENTTerminalRuleCall_1_0_4());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_5,
                      							"org.xtext.SM2.TITLELONGCOMENT");
                      					
                    }

                    }
                    break;
                case 6 :
                    // InternalSM2.g:3437:6: lv_expression_1_6= RULE_NOTICELONGCOMENT
                    {
                    lv_expression_1_6=(Token)match(input,RULE_NOTICELONGCOMENT,FOLLOW_82); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_expression_1_6, grammarAccess.getLongCommentAccess().getExpressionNOTICELONGCOMENTTerminalRuleCall_1_0_5());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLongCommentRule());
                      						}
                      						addWithLastConsumed(
                      							current,
                      							"expression",
                      							lv_expression_1_6,
                      							"org.xtext.SM2.NOTICELONGCOMENT");
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:3454:3: ( ( '*/' )=>otherlv_2= '*/' )
            // InternalSM2.g:3455:4: ( '*/' )=>otherlv_2= '*/'
            {
            otherlv_2=(Token)match(input,67,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_2, grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "ruleSingularType"
    // InternalSM2.g:3465:1: ruleSingularType returns [Enumerator current=null] : ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) ) ;
    public final Enumerator ruleSingularType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;
        Token enumLiteral_8=null;
        Token enumLiteral_9=null;
        Token enumLiteral_10=null;


        	enterRule();

        try {
            // InternalSM2.g:3471:2: ( ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) ) )
            // InternalSM2.g:3472:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) )
            {
            // InternalSM2.g:3472:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) )
            int alt84=11;
            switch ( input.LA(1) ) {
            case 68:
                {
                alt84=1;
                }
                break;
            case 54:
                {
                alt84=2;
                }
                break;
            case 69:
                {
                alt84=3;
                }
                break;
            case 70:
                {
                alt84=4;
                }
                break;
            case 53:
                {
                alt84=5;
                }
                break;
            case 52:
                {
                alt84=6;
                }
                break;
            case 71:
                {
                alt84=7;
                }
                break;
            case 72:
                {
                alt84=8;
                }
                break;
            case 73:
                {
                alt84=9;
                }
                break;
            case 74:
                {
                alt84=10;
                }
                break;
            case 75:
                {
                alt84=11;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 84, 0, input);

                throw nvae;
            }

            switch (alt84) {
                case 1 :
                    // InternalSM2.g:3473:3: (enumLiteral_0= 'int' )
                    {
                    // InternalSM2.g:3473:3: (enumLiteral_0= 'int' )
                    // InternalSM2.g:3474:4: enumLiteral_0= 'int'
                    {
                    enumLiteral_0=(Token)match(input,68,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3481:3: (enumLiteral_1= 'uint' )
                    {
                    // InternalSM2.g:3481:3: (enumLiteral_1= 'uint' )
                    // InternalSM2.g:3482:4: enumLiteral_1= 'uint'
                    {
                    enumLiteral_1=(Token)match(input,54,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3489:3: (enumLiteral_2= 'uint8' )
                    {
                    // InternalSM2.g:3489:3: (enumLiteral_2= 'uint8' )
                    // InternalSM2.g:3490:4: enumLiteral_2= 'uint8'
                    {
                    enumLiteral_2=(Token)match(input,69,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:3497:3: (enumLiteral_3= 'uint256' )
                    {
                    // InternalSM2.g:3497:3: (enumLiteral_3= 'uint256' )
                    // InternalSM2.g:3498:4: enumLiteral_3= 'uint256'
                    {
                    enumLiteral_3=(Token)match(input,70,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:3505:3: (enumLiteral_4= 'string' )
                    {
                    // InternalSM2.g:3505:3: (enumLiteral_4= 'string' )
                    // InternalSM2.g:3506:4: enumLiteral_4= 'string'
                    {
                    enumLiteral_4=(Token)match(input,53,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:3513:3: (enumLiteral_5= 'address' )
                    {
                    // InternalSM2.g:3513:3: (enumLiteral_5= 'address' )
                    // InternalSM2.g:3514:4: enumLiteral_5= 'address'
                    {
                    enumLiteral_5=(Token)match(input,52,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:3521:3: (enumLiteral_6= 'address payable' )
                    {
                    // InternalSM2.g:3521:3: (enumLiteral_6= 'address payable' )
                    // InternalSM2.g:3522:4: enumLiteral_6= 'address payable'
                    {
                    enumLiteral_6=(Token)match(input,71,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_6, grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6());
                      			
                    }

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:3529:3: (enumLiteral_7= 'double' )
                    {
                    // InternalSM2.g:3529:3: (enumLiteral_7= 'double' )
                    // InternalSM2.g:3530:4: enumLiteral_7= 'double'
                    {
                    enumLiteral_7=(Token)match(input,72,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_7, grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7());
                      			
                    }

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:3537:3: (enumLiteral_8= 'bool' )
                    {
                    // InternalSM2.g:3537:3: (enumLiteral_8= 'bool' )
                    // InternalSM2.g:3538:4: enumLiteral_8= 'bool'
                    {
                    enumLiteral_8=(Token)match(input,73,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_8, grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8());
                      			
                    }

                    }


                    }
                    break;
                case 10 :
                    // InternalSM2.g:3545:3: (enumLiteral_9= 'byte' )
                    {
                    // InternalSM2.g:3545:3: (enumLiteral_9= 'byte' )
                    // InternalSM2.g:3546:4: enumLiteral_9= 'byte'
                    {
                    enumLiteral_9=(Token)match(input,74,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getBYTEEnumLiteralDeclaration_9().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_9, grammarAccess.getSingularTypeAccess().getBYTEEnumLiteralDeclaration_9());
                      			
                    }

                    }


                    }
                    break;
                case 11 :
                    // InternalSM2.g:3553:3: (enumLiteral_10= 'bytes32' )
                    {
                    // InternalSM2.g:3553:3: (enumLiteral_10= 'bytes32' )
                    // InternalSM2.g:3554:4: enumLiteral_10= 'bytes32'
                    {
                    enumLiteral_10=(Token)match(input,75,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getSingularTypeAccess().getBYTE32EnumLiteralDeclaration_10().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_10, grammarAccess.getSingularTypeAccess().getBYTE32EnumLiteralDeclaration_10());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:3564:1: ruleVisibility returns [Enumerator current=null] : ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) ;
    public final Enumerator ruleVisibility() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalSM2.g:3570:2: ( ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) )
            // InternalSM2.g:3571:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            {
            // InternalSM2.g:3571:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            int alt85=4;
            switch ( input.LA(1) ) {
            case 43:
                {
                alt85=1;
                }
                break;
            case 76:
                {
                alt85=2;
                }
                break;
            case 44:
                {
                alt85=3;
                }
                break;
            case 77:
                {
                alt85=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 85, 0, input);

                throw nvae;
            }

            switch (alt85) {
                case 1 :
                    // InternalSM2.g:3572:3: (enumLiteral_0= 'public' )
                    {
                    // InternalSM2.g:3572:3: (enumLiteral_0= 'public' )
                    // InternalSM2.g:3573:4: enumLiteral_0= 'public'
                    {
                    enumLiteral_0=(Token)match(input,43,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3580:3: (enumLiteral_1= 'private' )
                    {
                    // InternalSM2.g:3580:3: (enumLiteral_1= 'private' )
                    // InternalSM2.g:3581:4: enumLiteral_1= 'private'
                    {
                    enumLiteral_1=(Token)match(input,76,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3588:3: (enumLiteral_2= 'internal' )
                    {
                    // InternalSM2.g:3588:3: (enumLiteral_2= 'internal' )
                    // InternalSM2.g:3589:4: enumLiteral_2= 'internal'
                    {
                    enumLiteral_2=(Token)match(input,44,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:3596:3: (enumLiteral_3= 'external' )
                    {
                    // InternalSM2.g:3596:3: (enumLiteral_3= 'external' )
                    // InternalSM2.g:3597:4: enumLiteral_3= 'external'
                    {
                    enumLiteral_3=(Token)match(input,77,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:3607:1: ruleCoin returns [Enumerator current=null] : ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) ;
    public final Enumerator ruleCoin() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:3613:2: ( ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) )
            // InternalSM2.g:3614:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            {
            // InternalSM2.g:3614:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            int alt86=6;
            switch ( input.LA(1) ) {
            case 78:
                {
                alt86=1;
                }
                break;
            case 79:
                {
                alt86=2;
                }
                break;
            case 80:
                {
                alt86=3;
                }
                break;
            case 81:
                {
                alt86=4;
                }
                break;
            case 82:
                {
                alt86=5;
                }
                break;
            case 83:
                {
                alt86=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 86, 0, input);

                throw nvae;
            }

            switch (alt86) {
                case 1 :
                    // InternalSM2.g:3615:3: (enumLiteral_0= 'ether' )
                    {
                    // InternalSM2.g:3615:3: (enumLiteral_0= 'ether' )
                    // InternalSM2.g:3616:4: enumLiteral_0= 'ether'
                    {
                    enumLiteral_0=(Token)match(input,78,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3623:3: (enumLiteral_1= 'wei' )
                    {
                    // InternalSM2.g:3623:3: (enumLiteral_1= 'wei' )
                    // InternalSM2.g:3624:4: enumLiteral_1= 'wei'
                    {
                    enumLiteral_1=(Token)match(input,79,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3631:3: (enumLiteral_2= 'gwei' )
                    {
                    // InternalSM2.g:3631:3: (enumLiteral_2= 'gwei' )
                    // InternalSM2.g:3632:4: enumLiteral_2= 'gwei'
                    {
                    enumLiteral_2=(Token)match(input,80,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:3639:3: (enumLiteral_3= 'pwei' )
                    {
                    // InternalSM2.g:3639:3: (enumLiteral_3= 'pwei' )
                    // InternalSM2.g:3640:4: enumLiteral_3= 'pwei'
                    {
                    enumLiteral_3=(Token)match(input,81,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:3647:3: (enumLiteral_4= 'finney' )
                    {
                    // InternalSM2.g:3647:3: (enumLiteral_4= 'finney' )
                    // InternalSM2.g:3648:4: enumLiteral_4= 'finney'
                    {
                    enumLiteral_4=(Token)match(input,82,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:3655:3: (enumLiteral_5= 'szabo' )
                    {
                    // InternalSM2.g:3655:3: (enumLiteral_5= 'szabo' )
                    // InternalSM2.g:3656:4: enumLiteral_5= 'szabo'
                    {
                    enumLiteral_5=(Token)match(input,83,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:3666:1: ruleComparationOperator returns [Enumerator current=null] : ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) ;
    public final Enumerator ruleComparationOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:3672:2: ( ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) )
            // InternalSM2.g:3673:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            {
            // InternalSM2.g:3673:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            int alt87=6;
            switch ( input.LA(1) ) {
            case 35:
                {
                alt87=1;
                }
                break;
            case 37:
                {
                alt87=2;
                }
                break;
            case 36:
                {
                alt87=3;
                }
                break;
            case 38:
                {
                alt87=4;
                }
                break;
            case 84:
                {
                alt87=5;
                }
                break;
            case 85:
                {
                alt87=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 87, 0, input);

                throw nvae;
            }

            switch (alt87) {
                case 1 :
                    // InternalSM2.g:3674:3: (enumLiteral_0= '>' )
                    {
                    // InternalSM2.g:3674:3: (enumLiteral_0= '>' )
                    // InternalSM2.g:3675:4: enumLiteral_0= '>'
                    {
                    enumLiteral_0=(Token)match(input,35,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3682:3: (enumLiteral_1= '<' )
                    {
                    // InternalSM2.g:3682:3: (enumLiteral_1= '<' )
                    // InternalSM2.g:3683:4: enumLiteral_1= '<'
                    {
                    enumLiteral_1=(Token)match(input,37,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3690:3: (enumLiteral_2= '>=' )
                    {
                    // InternalSM2.g:3690:3: (enumLiteral_2= '>=' )
                    // InternalSM2.g:3691:4: enumLiteral_2= '>='
                    {
                    enumLiteral_2=(Token)match(input,36,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:3698:3: (enumLiteral_3= '<=' )
                    {
                    // InternalSM2.g:3698:3: (enumLiteral_3= '<=' )
                    // InternalSM2.g:3699:4: enumLiteral_3= '<='
                    {
                    enumLiteral_3=(Token)match(input,38,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:3706:3: (enumLiteral_4= '==' )
                    {
                    // InternalSM2.g:3706:3: (enumLiteral_4= '==' )
                    // InternalSM2.g:3707:4: enumLiteral_4= '=='
                    {
                    enumLiteral_4=(Token)match(input,84,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:3714:3: (enumLiteral_5= '!=' )
                    {
                    // InternalSM2.g:3714:3: (enumLiteral_5= '!=' )
                    // InternalSM2.g:3715:4: enumLiteral_5= '!='
                    {
                    enumLiteral_5=(Token)match(input,85,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:3725:1: ruleLogicalPairOperator returns [Enumerator current=null] : ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) ;
    public final Enumerator ruleLogicalPairOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSM2.g:3731:2: ( ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) )
            // InternalSM2.g:3732:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            {
            // InternalSM2.g:3732:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            int alt88=2;
            int LA88_0 = input.LA(1);

            if ( (LA88_0==86) ) {
                alt88=1;
            }
            else if ( (LA88_0==87) ) {
                alt88=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 88, 0, input);

                throw nvae;
            }
            switch (alt88) {
                case 1 :
                    // InternalSM2.g:3733:3: (enumLiteral_0= '&&' )
                    {
                    // InternalSM2.g:3733:3: (enumLiteral_0= '&&' )
                    // InternalSM2.g:3734:4: enumLiteral_0= '&&'
                    {
                    enumLiteral_0=(Token)match(input,86,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3741:3: (enumLiteral_1= '||' )
                    {
                    // InternalSM2.g:3741:3: (enumLiteral_1= '||' )
                    // InternalSM2.g:3742:4: enumLiteral_1= '||'
                    {
                    enumLiteral_1=(Token)match(input,87,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:3752:1: ruleArithmeticalOperator returns [Enumerator current=null] : ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) ;
    public final Enumerator ruleArithmeticalOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;


        	enterRule();

        try {
            // InternalSM2.g:3758:2: ( ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) )
            // InternalSM2.g:3759:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            {
            // InternalSM2.g:3759:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            int alt89=5;
            switch ( input.LA(1) ) {
            case 88:
                {
                alt89=1;
                }
                break;
            case 89:
                {
                alt89=2;
                }
                break;
            case 90:
                {
                alt89=3;
                }
                break;
            case 91:
                {
                alt89=4;
                }
                break;
            case 92:
                {
                alt89=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 89, 0, input);

                throw nvae;
            }

            switch (alt89) {
                case 1 :
                    // InternalSM2.g:3760:3: (enumLiteral_0= '+' )
                    {
                    // InternalSM2.g:3760:3: (enumLiteral_0= '+' )
                    // InternalSM2.g:3761:4: enumLiteral_0= '+'
                    {
                    enumLiteral_0=(Token)match(input,88,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3768:3: (enumLiteral_1= '-' )
                    {
                    // InternalSM2.g:3768:3: (enumLiteral_1= '-' )
                    // InternalSM2.g:3769:4: enumLiteral_1= '-'
                    {
                    enumLiteral_1=(Token)match(input,89,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:3776:3: (enumLiteral_2= '*' )
                    {
                    // InternalSM2.g:3776:3: (enumLiteral_2= '*' )
                    // InternalSM2.g:3777:4: enumLiteral_2= '*'
                    {
                    enumLiteral_2=(Token)match(input,90,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:3784:3: (enumLiteral_3= '/' )
                    {
                    // InternalSM2.g:3784:3: (enumLiteral_3= '/' )
                    // InternalSM2.g:3785:4: enumLiteral_3= '/'
                    {
                    enumLiteral_3=(Token)match(input,91,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:3792:3: (enumLiteral_4= '%' )
                    {
                    // InternalSM2.g:3792:3: (enumLiteral_4= '%' )
                    // InternalSM2.g:3793:4: enumLiteral_4= '%'
                    {
                    enumLiteral_4=(Token)match(input,92,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmeticalOperator"

    // Delegated rules


    protected DFA35 dfa35 = new DFA35(this);
    protected DFA38 dfa38 = new DFA38(this);
    protected DFA50 dfa50 = new DFA50(this);
    protected DFA53 dfa53 = new DFA53(this);
    protected DFA66 dfa66 = new DFA66(this);
    protected DFA74 dfa74 = new DFA74(this);
    static final String dfa_1s = "\16\uffff";
    static final String dfa_2s = "\1\63\1\6\1\7\1\5\1\64\1\uffff\1\6\2\4\1\uffff\1\4\1\5\1\10\1\6";
    static final String dfa_3s = "\1\63\1\6\1\7\2\113\1\uffff\1\115\1\55\1\17\1\uffff\1\4\2\113\1\115";
    static final String dfa_4s = "\5\uffff\1\1\3\uffff\1\2\4\uffff";
    static final String dfa_5s = "\16\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\4\56\uffff\1\6\2\5\15\uffff\10\5",
            "\1\6\2\5\15\uffff\10\5",
            "",
            "\1\7\44\uffff\2\5\14\uffff\2\5\21\uffff\2\5",
            "\1\11\50\uffff\1\10",
            "\1\5\6\uffff\1\5\3\uffff\1\12",
            "",
            "\1\13",
            "\1\14\2\uffff\1\5\53\uffff\1\5\1\15\1\5\15\uffff\10\5",
            "\1\5\53\uffff\1\5\1\15\1\5\15\uffff\10\5",
            "\1\5\10\uffff\1\11\33\uffff\2\5\14\uffff\2\5\21\uffff\2\5"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA35 extends DFA {

        public DFA35(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 35;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "1460:4: (lv_typeStruct_0_1= rulePersonalizedStruct | lv_typeStruct_0_2= ruleUser )";
        }
    }
    static final String dfa_7s = "\1\2\1\3\14\uffff";
    static final String dfa_8s = "\1\5\1\4\2\uffff\1\6\1\14\6\6\1\15\1\4";
    static final String dfa_9s = "\2\113\2\uffff\1\6\1\14\2\115\5\15\1\100";
    static final String dfa_10s = "\2\uffff\1\2\1\1\12\uffff";
    static final String[] dfa_11s = {
            "\1\1\1\2\1\uffff\2\2\1\uffff\2\2\1\uffff\2\2\2\uffff\1\2\27\uffff\1\2\3\uffff\2\2\1\uffff\1\2\1\uffff\4\2\1\uffff\1\2\7\uffff\3\2\1\uffff\10\2",
            "\1\2\2\3\1\uffff\2\3\1\uffff\2\3\1\uffff\2\3\2\uffff\1\3\27\uffff\1\3\3\uffff\2\3\1\uffff\1\3\1\uffff\4\3\1\uffff\1\3\7\uffff\1\4\2\3\1\uffff\10\3",
            "",
            "",
            "\1\5",
            "\1\6",
            "\1\7\44\uffff\1\10\1\12\37\uffff\1\11\1\13",
            "\1\7\44\uffff\1\10\1\12\37\uffff\1\11\1\13",
            "\1\14\6\uffff\1\15",
            "\1\14\6\uffff\1\15",
            "\1\14\6\uffff\1\15",
            "\1\14\6\uffff\1\15",
            "\1\15",
            "\1\2\2\uffff\1\3\67\uffff\1\3\1\2"
    };
    static final short[] dfa_7 = DFA.unpackEncodedString(dfa_7s);
    static final char[] dfa_8 = DFA.unpackEncodedStringToUnsignedChars(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final short[] dfa_10 = DFA.unpackEncodedString(dfa_10s);
    static final short[][] dfa_11 = unpackEncodedStringArray(dfa_11s);

    class DFA38 extends DFA {

        public DFA38(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 38;
            this.eot = dfa_1;
            this.eof = dfa_7;
            this.min = dfa_8;
            this.max = dfa_9;
            this.accept = dfa_10;
            this.special = dfa_5;
            this.transition = dfa_11;
        }
        public String getDescription() {
            return "1568:3: (this_EOLINE_6= RULE_EOLINE )?";
        }
    }
    static final String dfa_12s = "\1\2\1\4\14\uffff";
    static final String dfa_13s = "\1\5\1\4\1\uffff\1\6\1\uffff\1\14\6\6\1\15\1\4";
    static final String dfa_14s = "\2\113\1\uffff\1\6\1\uffff\1\14\2\115\5\15\1\100";
    static final String dfa_15s = "\2\uffff\1\2\1\uffff\1\1\11\uffff";
    static final String[] dfa_16s = {
            "\1\1\1\2\1\uffff\2\2\1\uffff\2\2\1\uffff\2\2\2\uffff\1\2\27\uffff\1\2\3\uffff\2\2\1\uffff\1\2\1\uffff\4\2\1\uffff\1\2\7\uffff\3\2\1\uffff\10\2",
            "\1\2\2\4\1\uffff\2\4\1\uffff\2\4\1\uffff\2\4\2\uffff\1\4\27\uffff\1\4\3\uffff\2\4\1\uffff\1\4\1\uffff\4\4\1\uffff\1\4\7\uffff\1\3\2\4\1\uffff\10\4",
            "",
            "\1\5",
            "",
            "\1\6",
            "\1\7\44\uffff\1\10\1\12\37\uffff\1\11\1\13",
            "\1\7\44\uffff\1\10\1\12\37\uffff\1\11\1\13",
            "\1\14\6\uffff\1\15",
            "\1\14\6\uffff\1\15",
            "\1\14\6\uffff\1\15",
            "\1\14\6\uffff\1\15",
            "\1\15",
            "\1\2\2\uffff\1\4\67\uffff\1\4\1\2"
    };
    static final short[] dfa_12 = DFA.unpackEncodedString(dfa_12s);
    static final char[] dfa_13 = DFA.unpackEncodedStringToUnsignedChars(dfa_13s);
    static final char[] dfa_14 = DFA.unpackEncodedStringToUnsignedChars(dfa_14s);
    static final short[] dfa_15 = DFA.unpackEncodedString(dfa_15s);
    static final short[][] dfa_16 = unpackEncodedStringArray(dfa_16s);

    class DFA50 extends DFA {

        public DFA50(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 50;
            this.eot = dfa_1;
            this.eof = dfa_12;
            this.min = dfa_13;
            this.max = dfa_14;
            this.accept = dfa_15;
            this.special = dfa_5;
            this.transition = dfa_16;
        }
        public String getDescription() {
            return "1846:3: (this_EOLINE_36= RULE_EOLINE )?";
        }
    }
    static final String dfa_17s = "\130\uffff";
    static final String dfa_18s = "\1\2\1\5\126\uffff";
    static final String dfa_19s = "\2\5\1\uffff\1\6\1\4\1\uffff\1\7\1\5\1\64\13\6\1\4\1\6\1\11\4\6\1\55\1\4\1\5\1\6\1\11\2\73\3\4\1\5\1\65\1\17\2\73\1\6\1\4\1\5\1\10\1\5\1\6\1\4\1\6\1\10\1\6\1\4\1\17\1\5\1\6\1\4\1\65\1\17\1\14\1\4\1\6\1\17\1\5\5\6\1\4\1\65\1\17\1\15\2\4\1\20\1\5\1\4\1\66\1\67\1\4\1\16\1\4\1\5\1\4\1\10\1\5\1\4";
    static final String dfa_20s = "\2\113\1\uffff\1\6\1\100\1\uffff\1\7\2\113\13\115\1\55\1\115\1\13\4\6\1\55\1\17\1\65\1\115\1\13\2\73\1\17\2\4\1\113\1\65\1\17\2\73\1\115\1\4\3\113\1\115\1\55\1\115\1\113\1\115\1\113\1\17\1\65\1\6\1\4\1\65\1\17\1\14\1\55\1\115\1\17\1\65\1\115\4\15\1\4\1\65\1\17\1\15\1\100\1\55\1\20\1\66\1\4\1\66\1\67\1\55\1\16\1\4\1\10\1\4\1\10\2\113";
    static final String dfa_21s = "\2\uffff\1\2\2\uffff\1\1\122\uffff";
    static final String dfa_22s = "\130\uffff}>";
    static final String[] dfa_23s = {
            "\1\1\1\2\1\uffff\2\2\1\uffff\2\2\1\uffff\2\2\2\uffff\1\2\27\uffff\1\2\3\uffff\2\2\1\uffff\1\2\1\uffff\4\2\1\uffff\1\2\7\uffff\3\2\1\uffff\10\2",
            "\1\4\1\5\1\uffff\2\5\1\uffff\2\5\1\uffff\2\5\2\uffff\1\5\27\uffff\1\5\3\uffff\2\5\1\uffff\1\5\1\uffff\1\3\3\5\1\uffff\1\5\7\uffff\3\5\1\uffff\10\5",
            "",
            "\1\6",
            "\1\2\1\5\55\uffff\1\5\14\uffff\1\2",
            "",
            "\1\7",
            "\1\10\56\uffff\1\11\1\16\1\13\15\uffff\1\12\1\14\1\15\1\17\1\20\1\21\1\22\1\23",
            "\1\11\1\16\1\13\15\uffff\1\12\1\14\1\15\1\17\1\20\1\21\1\22\1\23",
            "\1\24\44\uffff\1\27\1\31\14\uffff\1\25\1\26\21\uffff\1\30\1\32",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\25\1\26\21\uffff\1\30\1\32",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\25\1\26\21\uffff\1\30\1\32",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\25\1\26\21\uffff\1\30\1\32",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\25\1\26\21\uffff\1\30\1\32",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\25\1\26\21\uffff\1\30\1\32",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\25\1\26\21\uffff\1\30\1\32",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\25\1\26\21\uffff\1\30\1\32",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\25\1\26\21\uffff\1\30\1\32",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\25\1\26\21\uffff\1\30\1\32",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\25\1\26\21\uffff\1\30\1\32",
            "\1\35\50\uffff\1\34",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\36\1\37\21\uffff\1\30\1\32",
            "\1\40\1\uffff\1\41",
            "\1\33",
            "\1\33",
            "\1\33",
            "\1\33",
            "\1\42",
            "\1\45\6\uffff\1\44\3\uffff\1\43",
            "\1\46\57\uffff\1\47",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\36\1\37\21\uffff\1\30\1\32",
            "\1\50\1\uffff\1\51",
            "\1\52",
            "\1\52",
            "\1\45\6\uffff\1\44\3\uffff\1\53",
            "\1\54",
            "\1\45",
            "\1\55\2\uffff\1\56\53\uffff\1\57\1\16\1\13\15\uffff\1\12\1\14\1\15\1\17\1\20\1\21\1\22\1\23",
            "\1\47",
            "\1\60",
            "\1\61",
            "\1\61",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\36\1\37\21\uffff\1\30\1\32",
            "\1\45",
            "\1\62\2\uffff\1\56\53\uffff\1\57\1\63\1\13\15\uffff\1\12\1\14\1\15\1\17\1\20\1\21\1\22\1\23",
            "\1\56\53\uffff\1\57\1\16\1\13\15\uffff\1\12\1\14\1\15\1\17\1\20\1\21\1\22\1\23",
            "\1\64\1\5\1\uffff\1\5\41\uffff\1\5\3\uffff\2\5\1\uffff\1\5\1\uffff\1\3\3\5\1\uffff\1\5\7\uffff\3\5\1\uffff\10\5",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\25\1\26\21\uffff\1\30\1\32",
            "\1\66\50\uffff\1\65",
            "\1\33\44\uffff\1\27\1\31\14\uffff\1\36\1\37\21\uffff\1\30\1\32",
            "\1\56\53\uffff\1\57\1\63\1\13\15\uffff\1\12\1\14\1\15\1\17\1\20\1\21\1\22\1\23",
            "\1\33\10\uffff\1\60\33\uffff\1\27\1\31\14\uffff\1\25\1\26\21\uffff\1\30\1\32",
            "\2\2\1\5\1\uffff\1\5\41\uffff\1\5\3\uffff\2\5\1\uffff\1\5\1\uffff\1\3\3\5\1\uffff\1\5\7\uffff\1\67\2\5\1\uffff\10\5",
            "\1\70",
            "\1\71\57\uffff\1\72",
            "\1\73",
            "\1\66",
            "\1\72",
            "\1\74",
            "\1\75",
            "\1\77\50\uffff\1\76",
            "\1\100\44\uffff\1\101\1\103\37\uffff\1\102\1\104",
            "\1\105",
            "\1\106\57\uffff\1\107",
            "\1\100\44\uffff\1\101\1\103\37\uffff\1\102\1\104",
            "\1\110\6\uffff\1\111",
            "\1\110\6\uffff\1\111",
            "\1\110\6\uffff\1\111",
            "\1\110\6\uffff\1\111",
            "\1\77",
            "\1\107",
            "\1\112",
            "\1\111",
            "\1\2\2\uffff\1\5\67\uffff\1\5\1\2",
            "\1\114\50\uffff\1\113",
            "\1\115",
            "\1\116\60\uffff\1\117",
            "\1\114",
            "\1\117",
            "\1\120",
            "\1\123\6\uffff\1\122\41\uffff\1\121",
            "\1\124",
            "\1\123",
            "\1\125\2\uffff\1\126",
            "\1\123",
            "\1\126",
            "\1\127\1\5\1\uffff\1\5\41\uffff\1\5\3\uffff\2\5\1\uffff\1\5\1\uffff\1\3\3\5\1\uffff\1\5\7\uffff\3\5\1\uffff\10\5",
            "\2\2\1\5\1\uffff\1\5\41\uffff\1\5\3\uffff\2\5\1\uffff\1\5\1\uffff\1\3\3\5\1\uffff\1\5\7\uffff\1\67\2\5\1\uffff\10\5"
    };

    static final short[] dfa_17 = DFA.unpackEncodedString(dfa_17s);
    static final short[] dfa_18 = DFA.unpackEncodedString(dfa_18s);
    static final char[] dfa_19 = DFA.unpackEncodedStringToUnsignedChars(dfa_19s);
    static final char[] dfa_20 = DFA.unpackEncodedStringToUnsignedChars(dfa_20s);
    static final short[] dfa_21 = DFA.unpackEncodedString(dfa_21s);
    static final short[] dfa_22 = DFA.unpackEncodedString(dfa_22s);
    static final short[][] dfa_23 = unpackEncodedStringArray(dfa_23s);

    class DFA53 extends DFA {

        public DFA53(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 53;
            this.eot = dfa_17;
            this.eof = dfa_18;
            this.min = dfa_19;
            this.max = dfa_20;
            this.accept = dfa_21;
            this.special = dfa_22;
            this.transition = dfa_23;
        }
        public String getDescription() {
            return "1917:3: (this_EOLINE_7= RULE_EOLINE )?";
        }
    }
    static final String dfa_24s = "\24\uffff";
    static final String dfa_25s = "\1\6\1\14\1\uffff\1\11\1\43\3\4\6\11\1\5\1\uffff\3\4\1\43";
    static final String dfa_26s = "\1\113\1\14\1\uffff\1\17\4\125\6\17\1\5\1\uffff\3\123\1\125";
    static final String dfa_27s = "\2\uffff\1\2\14\uffff\1\1\4\uffff";
    static final String dfa_28s = "\24\uffff}>";
    static final String[] dfa_29s = {
            "\1\2\2\uffff\1\2\1\uffff\2\2\1\uffff\2\2\2\uffff\1\2\36\uffff\1\2\1\uffff\4\2\1\uffff\1\2\5\uffff\1\1\5\uffff\10\2",
            "\1\3",
            "",
            "\1\5\1\uffff\1\6\2\uffff\1\7\1\4",
            "\1\10\1\12\1\11\1\13\55\uffff\1\14\1\15",
            "\1\16\36\uffff\1\10\1\12\1\11\1\13\55\uffff\1\14\1\15",
            "\1\16\36\uffff\1\10\1\12\1\11\1\13\55\uffff\1\14\1\15",
            "\1\16\36\uffff\1\10\1\12\1\11\1\13\55\uffff\1\14\1\15",
            "\1\20\1\uffff\1\21\2\uffff\1\22\1\17",
            "\1\20\1\uffff\1\21\2\uffff\1\22\1\17",
            "\1\20\1\uffff\1\21\2\uffff\1\22\1\17",
            "\1\20\1\uffff\1\21\2\uffff\1\22\1\17",
            "\1\20\1\uffff\1\21\2\uffff\1\22\1\17",
            "\1\20\1\uffff\1\21\2\uffff\1\22\1\17",
            "\1\23",
            "",
            "\1\17\10\uffff\1\17\100\uffff\6\2",
            "\1\17\10\uffff\1\17\100\uffff\6\2",
            "\1\17\10\uffff\1\17\100\uffff\6\2",
            "\1\10\1\12\1\11\1\13\55\uffff\1\14\1\15"
    };

    static final short[] dfa_24 = DFA.unpackEncodedString(dfa_24s);
    static final char[] dfa_25 = DFA.unpackEncodedStringToUnsignedChars(dfa_25s);
    static final char[] dfa_26 = DFA.unpackEncodedStringToUnsignedChars(dfa_26s);
    static final short[] dfa_27 = DFA.unpackEncodedString(dfa_27s);
    static final short[] dfa_28 = DFA.unpackEncodedString(dfa_28s);
    static final short[][] dfa_29 = unpackEncodedStringArray(dfa_29s);

    class DFA66 extends DFA {

        public DFA66(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 66;
            this.eot = dfa_24;
            this.eof = dfa_24;
            this.min = dfa_25;
            this.max = dfa_26;
            this.accept = dfa_27;
            this.special = dfa_28;
            this.transition = dfa_29;
        }
        public String getDescription() {
            return "2545:3: ( (lv_restriction_4_0= ruleRestriction ) )?";
        }
    }
    static final String dfa_30s = "\23\uffff";
    static final String dfa_31s = "\2\uffff\3\5\16\uffff";
    static final String dfa_32s = "\2\11\3\4\1\uffff\3\130\1\uffff\5\11\3\15\1\uffff";
    static final String dfa_33s = "\1\17\1\16\3\134\1\uffff\3\134\1\uffff\5\16\3\125\1\uffff";
    static final String dfa_34s = "\5\uffff\1\3\3\uffff\1\1\10\uffff\1\2";
    static final String dfa_35s = "\23\uffff}>";
    static final String[] dfa_36s = {
            "\1\2\1\uffff\1\3\1\1\1\uffff\1\4\1\5",
            "\1\6\1\uffff\1\7\2\uffff\1\10",
            "\2\5\2\uffff\2\5\1\uffff\5\5\110\uffff\5\11",
            "\2\5\2\uffff\2\5\1\uffff\5\5\110\uffff\5\11",
            "\2\5\2\uffff\2\5\1\uffff\5\5\110\uffff\5\11",
            "",
            "\1\12\1\13\1\14\1\15\1\16",
            "\1\12\1\13\1\14\1\15\1\16",
            "\1\12\1\13\1\14\1\15\1\16",
            "",
            "\1\17\1\uffff\1\20\2\uffff\1\21",
            "\1\17\1\uffff\1\20\2\uffff\1\21",
            "\1\17\1\uffff\1\20\2\uffff\1\21",
            "\1\17\1\uffff\1\20\2\uffff\1\21",
            "\1\17\1\uffff\1\20\2\uffff\1\21",
            "\1\11\25\uffff\4\22\55\uffff\2\22",
            "\1\11\25\uffff\4\22\55\uffff\2\22",
            "\1\11\25\uffff\4\22\55\uffff\2\22",
            ""
    };

    static final short[] dfa_30 = DFA.unpackEncodedString(dfa_30s);
    static final short[] dfa_31 = DFA.unpackEncodedString(dfa_31s);
    static final char[] dfa_32 = DFA.unpackEncodedStringToUnsignedChars(dfa_32s);
    static final char[] dfa_33 = DFA.unpackEncodedStringToUnsignedChars(dfa_33s);
    static final short[] dfa_34 = DFA.unpackEncodedString(dfa_34s);
    static final short[] dfa_35 = DFA.unpackEncodedString(dfa_35s);
    static final short[][] dfa_36 = unpackEncodedStringArray(dfa_36s);

    class DFA74 extends DFA {

        public DFA74(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 74;
            this.eot = dfa_30;
            this.eof = dfa_31;
            this.min = dfa_32;
            this.max = dfa_33;
            this.accept = dfa_34;
            this.special = dfa_35;
            this.transition = dfa_36;
        }
        public String getDescription() {
            return "2766:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000001C00000000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000028100000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000028100000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000020100000000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000200000080L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x017AC40000000160L,0x0000000000000FF7L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x017AC40000000140L,0x0000000000000FF7L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000C00000000100L,0x0000000000000007L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000800000000100L,0x0000000000000007L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000100L,0x0000000000000007L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000100L,0x0000000000000006L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000006000000002L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000010000000010L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0100000000000020L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x000A000000000020L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000000000010L,0x0000000000000001L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000180000000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000200000000040L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x000000000000DA00L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0070000000002000L,0x0000000000000FF0L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x000000000004DA20L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x000000000004DA00L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0001000000000020L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0070000000000000L,0x0000000000000FF0L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000180000000040L,0x0000000000003000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0070000000000020L,0x0000000000000FF0L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0070000000000100L,0x0000000000000FF0L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0010000000000020L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000200000000010L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0020000000000020L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0040000000000020L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0000200000000810L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0000000000000120L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0000000000028100L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0000000000008100L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0600000000000002L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0000000000000A00L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x0800000000000000L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x0600180000000040L,0x0000000000003000L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x0000000000008810L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x3600000000000040L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x3000000000000040L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x0000007800000000L,0x0000000000300000L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x0000000000005A00L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x0000000000000000L,0x00000000000FC000L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x8000000000000080L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0x417A00000004DA40L,0x0000000000000FF0L});
    public static final BitSet FOLLOW_73 = new BitSet(new long[]{0x017A00000004DA40L,0x0000000000000FF0L});
    public static final BitSet FOLLOW_74 = new BitSet(new long[]{0x000000000000DB20L});
    public static final BitSet FOLLOW_75 = new BitSet(new long[]{0x0000000000002040L});
    public static final BitSet FOLLOW_76 = new BitSet(new long[]{0x0000000000000000L,0x000000001F000000L});
    public static final BitSet FOLLOW_77 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_78 = new BitSet(new long[]{0x000000000000DB00L});
    public static final BitSet FOLLOW_79 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_80 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_81 = new BitSet(new long[]{0x0000000001F08000L});
    public static final BitSet FOLLOW_82 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});

}