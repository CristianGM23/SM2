package org.xtext.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_CLOSEKEY", "RULE_SINGLENUMBER", "RULE_DOT", "RULE_INTEGER", "RULE_ID", "RULE_OPENKEY", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_STRING", "RULE_EMAIL", "RULE_FLOAT", "RULE_COMMA", "RULE_BOOLVALUE", "RULE_IF", "RULE_ELSE", "RULE_PARAMSLONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_NOTICELONGCOMENT", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'pragma'", "'solidity'", "'^'", "'>'", "'>='", "'<'", "'<='", "'import'", "'as'", "'interface'", "'contract'", "'is'", "'constructor'", "'public'", "'internal'", "'event'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'address'", "'='", "'string'", "'float'", "'amountAccount'", "'enum'", "'[]'", "'['", "']'", "'int'", "'uint8'", "'uint256'", "'bool'", "'address payable'", "'bytes'", "'bytes32'", "'memory'", "'local'", "'require'", "'payable'", "'function'", "'kill'", "'msg.sender'", "'=='", "'selfdestruct'", "'//'", "'/*'", "'*/'", "'!'", "'uint'", "'double'", "'byte'", "'seconds'", "'minutes'", "'hours'", "'days'", "'weeks'", "'years'", "'private'", "'external'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'", "'%'"
    };
    public static final int T__50=50;
    public static final int RULE_OPENPARENTHESIS=12;
    public static final int RULE_EOLINE=5;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_PARAMSLONGCOMENT=21;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=10;
    public static final int RULE_INT=26;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=27;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int RULE_TITLELONGCOMENT=24;
    public static final int RULE_EMAIL=15;
    public static final int RULE_NOTICELONGCOMENT=25;
    public static final int T__37=37;
    public static final int RULE_OPENKEY=11;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int RULE_CLOSEPARENTHESIS=13;
    public static final int T__35=35;
    public static final int RULE_IF=19;
    public static final int T__36=36;
    public static final int RULE_DOT=8;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_DEVLONGCOMENT=22;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int RULE_FLOAT=16;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__91=91;
    public static final int T__100=100;
    public static final int T__92=92;
    public static final int T__93=93;
    public static final int T__102=102;
    public static final int T__94=94;
    public static final int T__101=101;
    public static final int T__90=90;
    public static final int RULE_SINGLENUMBER=7;
    public static final int T__99=99;
    public static final int RULE_CLOSEKEY=6;
    public static final int T__95=95;
    public static final int T__96=96;
    public static final int T__97=97;
    public static final int T__98=98;
    public static final int RULE_COMMA=17;
    public static final int RULE_RETURNSLONGCOMENT=23;
    public static final int RULE_SEMICOLON=4;
    public static final int RULE_ELSE=20;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int RULE_BOOLVALUE=18;
    public static final int T__72=72;
    public static final int RULE_STRING=14;
    public static final int RULE_SL_COMMENT=28;
    public static final int T__77=77;
    public static final int T__78=78;
    public static final int T__79=79;
    public static final int T__73=73;
    public static final int EOF=-1;
    public static final int T__74=74;
    public static final int T__75=75;
    public static final int T__76=76;
    public static final int T__80=80;
    public static final int T__81=81;
    public static final int T__82=82;
    public static final int T__83=83;
    public static final int RULE_WS=29;
    public static final int RULE_ANY_OTHER=30;
    public static final int T__88=88;
    public static final int T__89=89;
    public static final int T__84=84;
    public static final int T__104=104;
    public static final int T__85=85;
    public static final int T__103=103;
    public static final int RULE_INTEGER=9;
    public static final int T__86=86;
    public static final int T__87=87;
    public static final int T__105=105;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }



     	private SM2GrammarAccess grammarAccess;

        public InternalSM2Parser(TokenStream input, SM2GrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "SmartContract";
       	}

       	@Override
       	protected SM2GrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleSmartContract"
    // InternalSM2.g:65:1: entryRuleSmartContract returns [EObject current=null] : iv_ruleSmartContract= ruleSmartContract EOF ;
    public final EObject entryRuleSmartContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSmartContract = null;


        try {
            // InternalSM2.g:65:54: (iv_ruleSmartContract= ruleSmartContract EOF )
            // InternalSM2.g:66:2: iv_ruleSmartContract= ruleSmartContract EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSmartContractRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSmartContract=ruleSmartContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSmartContract; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSmartContract"


    // $ANTLR start "ruleSmartContract"
    // InternalSM2.g:72:1: ruleSmartContract returns [EObject current=null] : ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY ) ;
    public final EObject ruleSmartContract() throws RecognitionException {
        EObject current = null;

        Token lv_compiler_0_0=null;
        Token otherlv_1=null;
        Token this_SEMICOLON_3=null;
        Token this_EOLINE_4=null;
        Token this_CLOSEKEY_8=null;
        EObject lv_VersionCompiler_2_0 = null;

        EObject lv_imports_5_0 = null;

        EObject lv_interfaces_6_0 = null;

        EObject lv_contracts_7_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:78:2: ( ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY ) )
            // InternalSM2.g:79:2: ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY )
            {
            // InternalSM2.g:79:2: ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY )
            // InternalSM2.g:80:3: ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) this_SEMICOLON_3= RULE_SEMICOLON (this_EOLINE_4= RULE_EOLINE )? ( (lv_imports_5_0= ruleLibrary ) )* ( (lv_interfaces_6_0= ruleInterface ) )* ( (lv_contracts_7_0= ruleContract ) ) this_CLOSEKEY_8= RULE_CLOSEKEY
            {
            // InternalSM2.g:80:3: ( (lv_compiler_0_0= 'pragma' ) )
            // InternalSM2.g:81:4: (lv_compiler_0_0= 'pragma' )
            {
            // InternalSM2.g:81:4: (lv_compiler_0_0= 'pragma' )
            // InternalSM2.g:82:5: lv_compiler_0_0= 'pragma'
            {
            lv_compiler_0_0=(Token)match(input,31,FOLLOW_3); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_compiler_0_0, grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getSmartContractRule());
              					}
              					setWithLastConsumed(current, "compiler", lv_compiler_0_0, "pragma");
              				
            }

            }


            }

            otherlv_1=(Token)match(input,32,FOLLOW_4); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getSmartContractAccess().getSolidityKeyword_1());
              		
            }
            // InternalSM2.g:98:3: ( (lv_VersionCompiler_2_0= ruleVersion ) )
            // InternalSM2.g:99:4: (lv_VersionCompiler_2_0= ruleVersion )
            {
            // InternalSM2.g:99:4: (lv_VersionCompiler_2_0= ruleVersion )
            // InternalSM2.g:100:5: lv_VersionCompiler_2_0= ruleVersion
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_5);
            lv_VersionCompiler_2_0=ruleVersion();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getSmartContractRule());
              					}
              					set(
              						current,
              						"VersionCompiler",
              						lv_VersionCompiler_2_0,
              						"org.xtext.SM2.Version");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_SEMICOLON_3=(Token)match(input,RULE_SEMICOLON,FOLLOW_6); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_3, grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:121:3: (this_EOLINE_4= RULE_EOLINE )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_EOLINE) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalSM2.g:122:4: this_EOLINE_4= RULE_EOLINE
                    {
                    this_EOLINE_4=(Token)match(input,RULE_EOLINE,FOLLOW_6); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_4, grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:127:3: ( (lv_imports_5_0= ruleLibrary ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==38) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSM2.g:128:4: (lv_imports_5_0= ruleLibrary )
            	    {
            	    // InternalSM2.g:128:4: (lv_imports_5_0= ruleLibrary )
            	    // InternalSM2.g:129:5: lv_imports_5_0= ruleLibrary
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getImportsLibraryParserRuleCall_5_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_6);
            	    lv_imports_5_0=ruleLibrary();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"imports",
            	      						lv_imports_5_0,
            	      						"org.xtext.SM2.Library");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalSM2.g:146:3: ( (lv_interfaces_6_0= ruleInterface ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==40) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalSM2.g:147:4: (lv_interfaces_6_0= ruleInterface )
            	    {
            	    // InternalSM2.g:147:4: (lv_interfaces_6_0= ruleInterface )
            	    // InternalSM2.g:148:5: lv_interfaces_6_0= ruleInterface
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSmartContractAccess().getInterfacesInterfaceParserRuleCall_6_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_6);
            	    lv_interfaces_6_0=ruleInterface();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"interfaces",
            	      						lv_interfaces_6_0,
            	      						"org.xtext.SM2.Interface");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            // InternalSM2.g:165:3: ( (lv_contracts_7_0= ruleContract ) )
            // InternalSM2.g:166:4: (lv_contracts_7_0= ruleContract )
            {
            // InternalSM2.g:166:4: (lv_contracts_7_0= ruleContract )
            // InternalSM2.g:167:5: lv_contracts_7_0= ruleContract
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getSmartContractAccess().getContractsContractParserRuleCall_7_0());
              				
            }
            pushFollow(FOLLOW_7);
            lv_contracts_7_0=ruleContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getSmartContractRule());
              					}
              					add(
              						current,
              						"contracts",
              						lv_contracts_7_0,
              						"org.xtext.SM2.Contract");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEKEY_8=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_8, grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSmartContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:192:1: entryRuleVersion returns [EObject current=null] : iv_ruleVersion= ruleVersion EOF ;
    public final EObject entryRuleVersion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVersion = null;


        try {
            // InternalSM2.g:192:48: (iv_ruleVersion= ruleVersion EOF )
            // InternalSM2.g:193:2: iv_ruleVersion= ruleVersion EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getVersionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleVersion=ruleVersion();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleVersion; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:199:1: ruleVersion returns [EObject current=null] : ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_INTEGER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_INTEGER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )? ) ) ;
    public final EObject ruleVersion() throws RecognitionException {
        EObject current = null;

        Token lv_symbol_0_0=null;
        Token lv_numberVersion_1_0=null;
        Token this_DOT_2=null;
        Token lv_numberVersion2_3_0=null;
        Token this_DOT_4=null;
        Token lv_numberVersion3_5_0=null;
        Token lv_symbol_6_1=null;
        Token lv_symbol_6_2=null;
        Token lv_numberVersion_7_0=null;
        Token this_DOT_8=null;
        Token lv_numberVersion2_9_0=null;
        Token this_DOT_10=null;
        Token lv_numberVersion3_11_0=null;
        Token lv_symbol2_12_1=null;
        Token lv_symbol2_12_2=null;
        Token lv_numberVersionOptional_13_0=null;
        Token this_DOT_14=null;
        Token lv_numberVersionOptional2_15_0=null;
        Token this_DOT_16=null;
        Token lv_numberVersionOptional3_17_0=null;


        	enterRule();

        try {
            // InternalSM2.g:205:2: ( ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_INTEGER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_INTEGER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )? ) ) )
            // InternalSM2.g:206:2: ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_INTEGER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_INTEGER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )? ) )
            {
            // InternalSM2.g:206:2: ( ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_INTEGER ) ) ) | ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_INTEGER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )? ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==33) ) {
                alt7=1;
            }
            else if ( ((LA7_0>=34 && LA7_0<=35)) ) {
                alt7=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalSM2.g:207:3: ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_INTEGER ) ) )
                    {
                    // InternalSM2.g:207:3: ( ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_INTEGER ) ) )
                    // InternalSM2.g:208:4: ( (lv_symbol_0_0= '^' ) ) ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) ) this_DOT_2= RULE_DOT ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) ) this_DOT_4= RULE_DOT ( (lv_numberVersion3_5_0= RULE_INTEGER ) )
                    {
                    // InternalSM2.g:208:4: ( (lv_symbol_0_0= '^' ) )
                    // InternalSM2.g:209:5: (lv_symbol_0_0= '^' )
                    {
                    // InternalSM2.g:209:5: (lv_symbol_0_0= '^' )
                    // InternalSM2.g:210:6: lv_symbol_0_0= '^'
                    {
                    lv_symbol_0_0=(Token)match(input,33,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_symbol_0_0, grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(current, "symbol", lv_symbol_0_0, "^");
                      					
                    }

                    }


                    }

                    // InternalSM2.g:222:4: ( (lv_numberVersion_1_0= RULE_SINGLENUMBER ) )
                    // InternalSM2.g:223:5: (lv_numberVersion_1_0= RULE_SINGLENUMBER )
                    {
                    // InternalSM2.g:223:5: (lv_numberVersion_1_0= RULE_SINGLENUMBER )
                    // InternalSM2.g:224:6: lv_numberVersion_1_0= RULE_SINGLENUMBER
                    {
                    lv_numberVersion_1_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion_1_0, grammarAccess.getVersionAccess().getNumberVersionSINGLENUMBERTerminalRuleCall_0_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion",
                      							lv_numberVersion_1_0,
                      							"org.xtext.SM2.SINGLENUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_2=(Token)match(input,RULE_DOT,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_2, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_2());
                      			
                    }
                    // InternalSM2.g:244:4: ( (lv_numberVersion2_3_0= RULE_SINGLENUMBER ) )
                    // InternalSM2.g:245:5: (lv_numberVersion2_3_0= RULE_SINGLENUMBER )
                    {
                    // InternalSM2.g:245:5: (lv_numberVersion2_3_0= RULE_SINGLENUMBER )
                    // InternalSM2.g:246:6: lv_numberVersion2_3_0= RULE_SINGLENUMBER
                    {
                    lv_numberVersion2_3_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion2_3_0, grammarAccess.getVersionAccess().getNumberVersion2SINGLENUMBERTerminalRuleCall_0_3_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion2",
                      							lv_numberVersion2_3_0,
                      							"org.xtext.SM2.SINGLENUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_4=(Token)match(input,RULE_DOT,FOLLOW_10); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_4, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_4());
                      			
                    }
                    // InternalSM2.g:266:4: ( (lv_numberVersion3_5_0= RULE_INTEGER ) )
                    // InternalSM2.g:267:5: (lv_numberVersion3_5_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:267:5: (lv_numberVersion3_5_0= RULE_INTEGER )
                    // InternalSM2.g:268:6: lv_numberVersion3_5_0= RULE_INTEGER
                    {
                    lv_numberVersion3_5_0=(Token)match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion3_5_0, grammarAccess.getVersionAccess().getNumberVersion3INTEGERTerminalRuleCall_0_5_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion3",
                      							lv_numberVersion3_5_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:286:3: ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_INTEGER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )? )
                    {
                    // InternalSM2.g:286:3: ( ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_INTEGER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )? )
                    // InternalSM2.g:287:4: ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) ) ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) ) this_DOT_8= RULE_DOT ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) ) this_DOT_10= RULE_DOT ( (lv_numberVersion3_11_0= RULE_INTEGER ) ) ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )?
                    {
                    // InternalSM2.g:287:4: ( ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) ) )
                    // InternalSM2.g:288:5: ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) )
                    {
                    // InternalSM2.g:288:5: ( (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' ) )
                    // InternalSM2.g:289:6: (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' )
                    {
                    // InternalSM2.g:289:6: (lv_symbol_6_1= '>' | lv_symbol_6_2= '>=' )
                    int alt4=2;
                    int LA4_0 = input.LA(1);

                    if ( (LA4_0==34) ) {
                        alt4=1;
                    }
                    else if ( (LA4_0==35) ) {
                        alt4=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 0, input);

                        throw nvae;
                    }
                    switch (alt4) {
                        case 1 :
                            // InternalSM2.g:290:7: lv_symbol_6_1= '>'
                            {
                            lv_symbol_6_1=(Token)match(input,34,FOLLOW_8); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_symbol_6_1, grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_1_0_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(current, "symbol", lv_symbol_6_1, null);
                              						
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:301:7: lv_symbol_6_2= '>='
                            {
                            lv_symbol_6_2=(Token)match(input,35,FOLLOW_8); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_symbol_6_2, grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_1_0_0_1());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(current, "symbol", lv_symbol_6_2, null);
                              						
                            }

                            }
                            break;

                    }


                    }


                    }

                    // InternalSM2.g:314:4: ( (lv_numberVersion_7_0= RULE_SINGLENUMBER ) )
                    // InternalSM2.g:315:5: (lv_numberVersion_7_0= RULE_SINGLENUMBER )
                    {
                    // InternalSM2.g:315:5: (lv_numberVersion_7_0= RULE_SINGLENUMBER )
                    // InternalSM2.g:316:6: lv_numberVersion_7_0= RULE_SINGLENUMBER
                    {
                    lv_numberVersion_7_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion_7_0, grammarAccess.getVersionAccess().getNumberVersionSINGLENUMBERTerminalRuleCall_1_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion",
                      							lv_numberVersion_7_0,
                      							"org.xtext.SM2.SINGLENUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_8=(Token)match(input,RULE_DOT,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_8, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_2());
                      			
                    }
                    // InternalSM2.g:336:4: ( (lv_numberVersion2_9_0= RULE_SINGLENUMBER ) )
                    // InternalSM2.g:337:5: (lv_numberVersion2_9_0= RULE_SINGLENUMBER )
                    {
                    // InternalSM2.g:337:5: (lv_numberVersion2_9_0= RULE_SINGLENUMBER )
                    // InternalSM2.g:338:6: lv_numberVersion2_9_0= RULE_SINGLENUMBER
                    {
                    lv_numberVersion2_9_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_9); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion2_9_0, grammarAccess.getVersionAccess().getNumberVersion2SINGLENUMBERTerminalRuleCall_1_3_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion2",
                      							lv_numberVersion2_9_0,
                      							"org.xtext.SM2.SINGLENUMBER");
                      					
                    }

                    }


                    }

                    this_DOT_10=(Token)match(input,RULE_DOT,FOLLOW_10); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_DOT_10, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_4());
                      			
                    }
                    // InternalSM2.g:358:4: ( (lv_numberVersion3_11_0= RULE_INTEGER ) )
                    // InternalSM2.g:359:5: (lv_numberVersion3_11_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:359:5: (lv_numberVersion3_11_0= RULE_INTEGER )
                    // InternalSM2.g:360:6: lv_numberVersion3_11_0= RULE_INTEGER
                    {
                    lv_numberVersion3_11_0=(Token)match(input,RULE_INTEGER,FOLLOW_11); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_numberVersion3_11_0, grammarAccess.getVersionAccess().getNumberVersion3INTEGERTerminalRuleCall_1_5_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getVersionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"numberVersion3",
                      							lv_numberVersion3_11_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }

                    // InternalSM2.g:376:4: ( ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) ) )?
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( ((LA6_0>=36 && LA6_0<=37)) ) {
                        alt6=1;
                    }
                    switch (alt6) {
                        case 1 :
                            // InternalSM2.g:377:5: ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) ) ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) ) this_DOT_14= RULE_DOT ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) ) this_DOT_16= RULE_DOT ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:377:5: ( ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) ) )
                            // InternalSM2.g:378:6: ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) )
                            {
                            // InternalSM2.g:378:6: ( (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' ) )
                            // InternalSM2.g:379:7: (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' )
                            {
                            // InternalSM2.g:379:7: (lv_symbol2_12_1= '<' | lv_symbol2_12_2= '<=' )
                            int alt5=2;
                            int LA5_0 = input.LA(1);

                            if ( (LA5_0==36) ) {
                                alt5=1;
                            }
                            else if ( (LA5_0==37) ) {
                                alt5=2;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return current;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 5, 0, input);

                                throw nvae;
                            }
                            switch (alt5) {
                                case 1 :
                                    // InternalSM2.g:380:8: lv_symbol2_12_1= '<'
                                    {
                                    lv_symbol2_12_1=(Token)match(input,36,FOLLOW_8); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      								newLeafNode(lv_symbol2_12_1, grammarAccess.getVersionAccess().getSymbol2LessThanSignKeyword_1_6_0_0_0());
                                      							
                                    }
                                    if ( state.backtracking==0 ) {

                                      								if (current==null) {
                                      									current = createModelElement(grammarAccess.getVersionRule());
                                      								}
                                      								setWithLastConsumed(current, "symbol2", lv_symbol2_12_1, null);
                                      							
                                    }

                                    }
                                    break;
                                case 2 :
                                    // InternalSM2.g:391:8: lv_symbol2_12_2= '<='
                                    {
                                    lv_symbol2_12_2=(Token)match(input,37,FOLLOW_8); if (state.failed) return current;
                                    if ( state.backtracking==0 ) {

                                      								newLeafNode(lv_symbol2_12_2, grammarAccess.getVersionAccess().getSymbol2LessThanSignEqualsSignKeyword_1_6_0_0_1());
                                      							
                                    }
                                    if ( state.backtracking==0 ) {

                                      								if (current==null) {
                                      									current = createModelElement(grammarAccess.getVersionRule());
                                      								}
                                      								setWithLastConsumed(current, "symbol2", lv_symbol2_12_2, null);
                                      							
                                    }

                                    }
                                    break;

                            }


                            }


                            }

                            // InternalSM2.g:404:5: ( (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER ) )
                            // InternalSM2.g:405:6: (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER )
                            {
                            // InternalSM2.g:405:6: (lv_numberVersionOptional_13_0= RULE_SINGLENUMBER )
                            // InternalSM2.g:406:7: lv_numberVersionOptional_13_0= RULE_SINGLENUMBER
                            {
                            lv_numberVersionOptional_13_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_9); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_numberVersionOptional_13_0, grammarAccess.getVersionAccess().getNumberVersionOptionalSINGLENUMBERTerminalRuleCall_1_6_1_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"numberVersionOptional",
                              								lv_numberVersionOptional_13_0,
                              								"org.xtext.SM2.SINGLENUMBER");
                              						
                            }

                            }


                            }

                            this_DOT_14=(Token)match(input,RULE_DOT,FOLLOW_8); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_DOT_14, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_2());
                              				
                            }
                            // InternalSM2.g:426:5: ( (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER ) )
                            // InternalSM2.g:427:6: (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER )
                            {
                            // InternalSM2.g:427:6: (lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER )
                            // InternalSM2.g:428:7: lv_numberVersionOptional2_15_0= RULE_SINGLENUMBER
                            {
                            lv_numberVersionOptional2_15_0=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_9); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_numberVersionOptional2_15_0, grammarAccess.getVersionAccess().getNumberVersionOptional2SINGLENUMBERTerminalRuleCall_1_6_3_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"numberVersionOptional2",
                              								lv_numberVersionOptional2_15_0,
                              								"org.xtext.SM2.SINGLENUMBER");
                              						
                            }

                            }


                            }

                            this_DOT_16=(Token)match(input,RULE_DOT,FOLLOW_10); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_DOT_16, grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_4());
                              				
                            }
                            // InternalSM2.g:448:5: ( (lv_numberVersionOptional3_17_0= RULE_INTEGER ) )
                            // InternalSM2.g:449:6: (lv_numberVersionOptional3_17_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:449:6: (lv_numberVersionOptional3_17_0= RULE_INTEGER )
                            // InternalSM2.g:450:7: lv_numberVersionOptional3_17_0= RULE_INTEGER
                            {
                            lv_numberVersionOptional3_17_0=(Token)match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_numberVersionOptional3_17_0, grammarAccess.getVersionAccess().getNumberVersionOptional3INTEGERTerminalRuleCall_1_6_5_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getVersionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"numberVersionOptional3",
                              								lv_numberVersionOptional3_17_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleLibrary"
    // InternalSM2.g:472:1: entryRuleLibrary returns [EObject current=null] : iv_ruleLibrary= ruleLibrary EOF ;
    public final EObject entryRuleLibrary() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLibrary = null;


        try {
            // InternalSM2.g:472:48: (iv_ruleLibrary= ruleLibrary EOF )
            // InternalSM2.g:473:2: iv_ruleLibrary= ruleLibrary EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLibraryRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLibrary=ruleLibrary();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLibrary; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLibrary"


    // $ANTLR start "ruleLibrary"
    // InternalSM2.g:479:1: ruleLibrary returns [EObject current=null] : (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) ;
    public final EObject ruleLibrary() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameLibrary_1_0=null;
        Token otherlv_2=null;
        Token lv_alias_3_0=null;
        Token this_SEMICOLON_4=null;
        Token this_EOLINE_5=null;


        	enterRule();

        try {
            // InternalSM2.g:485:2: ( (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? ) )
            // InternalSM2.g:486:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            {
            // InternalSM2.g:486:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )? )
            // InternalSM2.g:487:3: otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_ID ) ) (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )? this_SEMICOLON_4= RULE_SEMICOLON (this_EOLINE_5= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,38,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getLibraryAccess().getImportKeyword_0());
              		
            }
            // InternalSM2.g:491:3: ( (lv_nameLibrary_1_0= RULE_ID ) )
            // InternalSM2.g:492:4: (lv_nameLibrary_1_0= RULE_ID )
            {
            // InternalSM2.g:492:4: (lv_nameLibrary_1_0= RULE_ID )
            // InternalSM2.g:493:5: lv_nameLibrary_1_0= RULE_ID
            {
            lv_nameLibrary_1_0=(Token)match(input,RULE_ID,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameLibrary_1_0, grammarAccess.getLibraryAccess().getNameLibraryIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getLibraryRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameLibrary",
              						lv_nameLibrary_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:509:3: (otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==39) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalSM2.g:510:4: otherlv_2= 'as' ( (lv_alias_3_0= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,39,FOLLOW_12); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getLibraryAccess().getAsKeyword_2_0());
                      			
                    }
                    // InternalSM2.g:514:4: ( (lv_alias_3_0= RULE_ID ) )
                    // InternalSM2.g:515:5: (lv_alias_3_0= RULE_ID )
                    {
                    // InternalSM2.g:515:5: (lv_alias_3_0= RULE_ID )
                    // InternalSM2.g:516:6: lv_alias_3_0= RULE_ID
                    {
                    lv_alias_3_0=(Token)match(input,RULE_ID,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_alias_3_0, grammarAccess.getLibraryAccess().getAliasIDTerminalRuleCall_2_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getLibraryRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"alias",
                      							lv_alias_3_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_SEMICOLON_4=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_4, grammarAccess.getLibraryAccess().getSEMICOLONTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:537:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==RULE_EOLINE) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalSM2.g:538:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_5, grammarAccess.getLibraryAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLibrary"


    // $ANTLR start "entryRuleInterface"
    // InternalSM2.g:547:1: entryRuleInterface returns [EObject current=null] : iv_ruleInterface= ruleInterface EOF ;
    public final EObject entryRuleInterface() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInterface = null;


        try {
            // InternalSM2.g:547:50: (iv_ruleInterface= ruleInterface EOF )
            // InternalSM2.g:548:2: iv_ruleInterface= ruleInterface EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getInterfaceRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleInterface=ruleInterface();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleInterface; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInterface"


    // $ANTLR start "ruleInterface"
    // InternalSM2.g:554:1: ruleInterface returns [EObject current=null] : (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (otherlv_8= RULE_ID ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE ) ;
    public final EObject ruleInterface() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameInterface_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_EOLINE_5=null;
        Token this_EOLINE_7=null;
        Token otherlv_8=null;
        Token this_SEMICOLON_9=null;
        Token this_EOLINE_10=null;
        Token this_CLOSEKEY_11=null;
        Token this_EOLINE_12=null;
        EObject lv_enums_4_0 = null;

        EObject lv_structs_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:560:2: ( (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (otherlv_8= RULE_ID ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE ) )
            // InternalSM2.g:561:2: (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (otherlv_8= RULE_ID ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE )
            {
            // InternalSM2.g:561:2: (otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (otherlv_8= RULE_ID ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE )
            // InternalSM2.g:562:3: otherlv_0= 'interface' ( (lv_nameInterface_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_enums_4_0= ruleEnum ) )* this_EOLINE_5= RULE_EOLINE ( (lv_structs_6_0= ruleStruct ) )* this_EOLINE_7= RULE_EOLINE ( (otherlv_8= RULE_ID ) )* this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE this_CLOSEKEY_11= RULE_CLOSEKEY this_EOLINE_12= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,40,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getInterfaceAccess().getInterfaceKeyword_0());
              		
            }
            // InternalSM2.g:566:3: ( (lv_nameInterface_1_0= RULE_ID ) )
            // InternalSM2.g:567:4: (lv_nameInterface_1_0= RULE_ID )
            {
            // InternalSM2.g:567:4: (lv_nameInterface_1_0= RULE_ID )
            // InternalSM2.g:568:5: lv_nameInterface_1_0= RULE_ID
            {
            lv_nameInterface_1_0=(Token)match(input,RULE_ID,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameInterface_1_0, grammarAccess.getInterfaceAccess().getNameInterfaceIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getInterfaceRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameInterface",
              						lv_nameInterface_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getInterfaceAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_17); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_3, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_3());
              		
            }
            // InternalSM2.g:592:3: ( (lv_enums_4_0= ruleEnum ) )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==57) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalSM2.g:593:4: (lv_enums_4_0= ruleEnum )
            	    {
            	    // InternalSM2.g:593:4: (lv_enums_4_0= ruleEnum )
            	    // InternalSM2.g:594:5: lv_enums_4_0= ruleEnum
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getInterfaceAccess().getEnumsEnumParserRuleCall_4_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_17);
            	    lv_enums_4_0=ruleEnum();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getInterfaceRule());
            	      					}
            	      					add(
            	      						current,
            	      						"enums",
            	      						lv_enums_4_0,
            	      						"org.xtext.SM2.Enum");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

            this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_18); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_5, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_5());
              		
            }
            // InternalSM2.g:615:3: ( (lv_structs_6_0= ruleStruct ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==51) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalSM2.g:616:4: (lv_structs_6_0= ruleStruct )
            	    {
            	    // InternalSM2.g:616:4: (lv_structs_6_0= ruleStruct )
            	    // InternalSM2.g:617:5: lv_structs_6_0= ruleStruct
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getInterfaceAccess().getStructsStructParserRuleCall_6_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_18);
            	    lv_structs_6_0=ruleStruct();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getInterfaceRule());
            	      					}
            	      					add(
            	      						current,
            	      						"structs",
            	      						lv_structs_6_0,
            	      						"org.xtext.SM2.Struct");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_19); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_7, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_7());
              		
            }
            // InternalSM2.g:638:3: ( (otherlv_8= RULE_ID ) )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==RULE_ID) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalSM2.g:639:4: (otherlv_8= RULE_ID )
            	    {
            	    // InternalSM2.g:639:4: (otherlv_8= RULE_ID )
            	    // InternalSM2.g:640:5: otherlv_8= RULE_ID
            	    {
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElement(grammarAccess.getInterfaceRule());
            	      					}
            	      				
            	    }
            	    otherlv_8=(Token)match(input,RULE_ID,FOLLOW_19); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_8, grammarAccess.getInterfaceAccess().getFunctionsHeadClauseCrossReference_8_0());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_9, grammarAccess.getInterfaceAccess().getSEMICOLONTerminalRuleCall_9());
              		
            }
            this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_10, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_10());
              		
            }
            this_CLOSEKEY_11=(Token)match(input,RULE_CLOSEKEY,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_11, grammarAccess.getInterfaceAccess().getCLOSEKEYTerminalRuleCall_11());
              		
            }
            this_EOLINE_12=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_12, grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_12());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInterface"


    // $ANTLR start "entryRuleContract"
    // InternalSM2.g:671:1: entryRuleContract returns [EObject current=null] : iv_ruleContract= ruleContract EOF ;
    public final EObject entryRuleContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleContract = null;


        try {
            // InternalSM2.g:671:49: (iv_ruleContract= ruleContract EOF )
            // InternalSM2.g:672:2: iv_ruleContract= ruleContract EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getContractRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleContract=ruleContract();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleContract; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleContract"


    // $ANTLR start "ruleContract"
    // InternalSM2.g:678:1: ruleContract returns [EObject current=null] : ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* ) ;
    public final EObject ruleContract() throws RecognitionException {
        EObject current = null;

        Token lv_contract_0_0=null;
        Token lv_nameContract_1_0=null;
        Token otherlv_2=null;
        Token lv_nameContractFather_3_0=null;
        Token this_OPENKEY_4=null;
        Token this_EOLINE_5=null;
        EObject lv_attributes_6_0 = null;

        EObject lv_constructor_7_0 = null;

        EObject lv_events_8_0 = null;

        EObject lv_modifier_9_0 = null;

        EObject lv_functions_10_0 = null;

        EObject lv_comments_11_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:684:2: ( ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* ) )
            // InternalSM2.g:685:2: ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* )
            {
            // InternalSM2.g:685:2: ( ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )* )
            // InternalSM2.g:686:3: ( (lv_contract_0_0= 'contract' ) ) ( (lv_nameContract_1_0= RULE_ID ) ) (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )? this_OPENKEY_4= RULE_OPENKEY (this_EOLINE_5= RULE_EOLINE )? ( (lv_attributes_6_0= ruleAttributes ) )* ( (lv_constructor_7_0= ruleConstructor ) )? ( (lv_events_8_0= ruleEvent ) )* ( (lv_modifier_9_0= ruleModifier ) )* ( (lv_functions_10_0= ruleFunction ) )* ( (lv_comments_11_0= ruleComment ) )*
            {
            // InternalSM2.g:686:3: ( (lv_contract_0_0= 'contract' ) )
            // InternalSM2.g:687:4: (lv_contract_0_0= 'contract' )
            {
            // InternalSM2.g:687:4: (lv_contract_0_0= 'contract' )
            // InternalSM2.g:688:5: lv_contract_0_0= 'contract'
            {
            lv_contract_0_0=(Token)match(input,41,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_contract_0_0, grammarAccess.getContractAccess().getContractContractKeyword_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getContractRule());
              					}
              					setWithLastConsumed(current, "contract", lv_contract_0_0, "contract");
              				
            }

            }


            }

            // InternalSM2.g:700:3: ( (lv_nameContract_1_0= RULE_ID ) )
            // InternalSM2.g:701:4: (lv_nameContract_1_0= RULE_ID )
            {
            // InternalSM2.g:701:4: (lv_nameContract_1_0= RULE_ID )
            // InternalSM2.g:702:5: lv_nameContract_1_0= RULE_ID
            {
            lv_nameContract_1_0=(Token)match(input,RULE_ID,FOLLOW_20); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameContract_1_0, grammarAccess.getContractAccess().getNameContractIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getContractRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameContract",
              						lv_nameContract_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:718:3: (otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==42) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalSM2.g:719:4: otherlv_2= 'is' ( (lv_nameContractFather_3_0= RULE_ID ) )
                    {
                    otherlv_2=(Token)match(input,42,FOLLOW_12); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_2, grammarAccess.getContractAccess().getIsKeyword_2_0());
                      			
                    }
                    // InternalSM2.g:723:4: ( (lv_nameContractFather_3_0= RULE_ID ) )
                    // InternalSM2.g:724:5: (lv_nameContractFather_3_0= RULE_ID )
                    {
                    // InternalSM2.g:724:5: (lv_nameContractFather_3_0= RULE_ID )
                    // InternalSM2.g:725:6: lv_nameContractFather_3_0= RULE_ID
                    {
                    lv_nameContractFather_3_0=(Token)match(input,RULE_ID,FOLLOW_15); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_nameContractFather_3_0, grammarAccess.getContractAccess().getNameContractFatherIDTerminalRuleCall_2_1_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getContractRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"nameContractFather",
                      							lv_nameContractFather_3_0,
                      							"org.eclipse.xtext.common.Terminals.ID");
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_OPENKEY_4=(Token)match(input,RULE_OPENKEY,FOLLOW_21); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_4, grammarAccess.getContractAccess().getOPENKEYTerminalRuleCall_3());
              		
            }
            // InternalSM2.g:746:3: (this_EOLINE_5= RULE_EOLINE )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==RULE_EOLINE) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalSM2.g:747:4: this_EOLINE_5= RULE_EOLINE
                    {
                    this_EOLINE_5=(Token)match(input,RULE_EOLINE,FOLLOW_22); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_5, grammarAccess.getContractAccess().getEOLINETerminalRuleCall_4());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:752:3: ( (lv_attributes_6_0= ruleAttributes ) )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==RULE_ID||LA15_0==49||(LA15_0>=51 && LA15_0<=52)||(LA15_0>=54 && LA15_0<=55)||LA15_0==57||(LA15_0>=61 && LA15_0<=67)) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalSM2.g:753:4: (lv_attributes_6_0= ruleAttributes )
            	    {
            	    // InternalSM2.g:753:4: (lv_attributes_6_0= ruleAttributes )
            	    // InternalSM2.g:754:5: lv_attributes_6_0= ruleAttributes
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getAttributesAttributesParserRuleCall_5_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_22);
            	    lv_attributes_6_0=ruleAttributes();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"attributes",
            	      						lv_attributes_6_0,
            	      						"org.xtext.SM2.Attributes");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

            // InternalSM2.g:771:3: ( (lv_constructor_7_0= ruleConstructor ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==43) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalSM2.g:772:4: (lv_constructor_7_0= ruleConstructor )
                    {
                    // InternalSM2.g:772:4: (lv_constructor_7_0= ruleConstructor )
                    // InternalSM2.g:773:5: lv_constructor_7_0= ruleConstructor
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getContractAccess().getConstructorConstructorParserRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_23);
                    lv_constructor_7_0=ruleConstructor();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getContractRule());
                      					}
                      					set(
                      						current,
                      						"constructor",
                      						lv_constructor_7_0,
                      						"org.xtext.SM2.Constructor");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:790:3: ( (lv_events_8_0= ruleEvent ) )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( (LA17_0==46) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalSM2.g:791:4: (lv_events_8_0= ruleEvent )
            	    {
            	    // InternalSM2.g:791:4: (lv_events_8_0= ruleEvent )
            	    // InternalSM2.g:792:5: lv_events_8_0= ruleEvent
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getEventsEventParserRuleCall_7_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_23);
            	    lv_events_8_0=ruleEvent();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"events",
            	      						lv_events_8_0,
            	      						"org.xtext.SM2.Event");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

            // InternalSM2.g:809:3: ( (lv_modifier_9_0= ruleModifier ) )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==47) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalSM2.g:810:4: (lv_modifier_9_0= ruleModifier )
            	    {
            	    // InternalSM2.g:810:4: (lv_modifier_9_0= ruleModifier )
            	    // InternalSM2.g:811:5: lv_modifier_9_0= ruleModifier
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getModifierModifierParserRuleCall_8_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_24);
            	    lv_modifier_9_0=ruleModifier();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"modifier",
            	      						lv_modifier_9_0,
            	      						"org.xtext.SM2.Modifier");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

            // InternalSM2.g:828:3: ( (lv_functions_10_0= ruleFunction ) )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==72) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalSM2.g:829:4: (lv_functions_10_0= ruleFunction )
            	    {
            	    // InternalSM2.g:829:4: (lv_functions_10_0= ruleFunction )
            	    // InternalSM2.g:830:5: lv_functions_10_0= ruleFunction
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getFunctionsFunctionParserRuleCall_9_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_25);
            	    lv_functions_10_0=ruleFunction();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"functions",
            	      						lv_functions_10_0,
            	      						"org.xtext.SM2.Function");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

            // InternalSM2.g:847:3: ( (lv_comments_11_0= ruleComment ) )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( ((LA20_0>=77 && LA20_0<=78)) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalSM2.g:848:4: (lv_comments_11_0= ruleComment )
            	    {
            	    // InternalSM2.g:848:4: (lv_comments_11_0= ruleComment )
            	    // InternalSM2.g:849:5: lv_comments_11_0= ruleComment
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getContractAccess().getCommentsCommentParserRuleCall_10_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_26);
            	    lv_comments_11_0=ruleComment();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getContractRule());
            	      					}
            	      					add(
            	      						current,
            	      						"comments",
            	      						lv_comments_11_0,
            	      						"org.xtext.SM2.Comment");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleContract"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:870:1: entryRuleAttributes returns [EObject current=null] : iv_ruleAttributes= ruleAttributes EOF ;
    public final EObject entryRuleAttributes() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttributes = null;


        try {
            // InternalSM2.g:870:51: (iv_ruleAttributes= ruleAttributes EOF )
            // InternalSM2.g:871:2: iv_ruleAttributes= ruleAttributes EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getAttributesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleAttributes=ruleAttributes();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleAttributes; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:877:1: ruleAttributes returns [EObject current=null] : (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) ;
    public final EObject ruleAttributes() throws RecognitionException {
        EObject current = null;

        EObject this_Property_0 = null;

        EObject this_DataType_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:883:2: ( (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) )
            // InternalSM2.g:884:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            {
            // InternalSM2.g:884:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==RULE_ID||LA21_0==52||(LA21_0>=54 && LA21_0<=55)||(LA21_0>=61 && LA21_0<=67)) ) {
                alt21=1;
            }
            else if ( (LA21_0==49||LA21_0==51||LA21_0==57) ) {
                alt21=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }
            switch (alt21) {
                case 1 :
                    // InternalSM2.g:885:3: this_Property_0= ruleProperty
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Property_0=ruleProperty();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Property_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:894:3: this_DataType_1= ruleDataType
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_DataType_1=ruleDataType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_DataType_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleConstructor"
    // InternalSM2.g:906:1: entryRuleConstructor returns [EObject current=null] : iv_ruleConstructor= ruleConstructor EOF ;
    public final EObject entryRuleConstructor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConstructor = null;


        try {
            // InternalSM2.g:906:52: (iv_ruleConstructor= ruleConstructor EOF )
            // InternalSM2.g:907:2: iv_ruleConstructor= ruleConstructor EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConstructorRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleConstructor=ruleConstructor();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleConstructor; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConstructor"


    // $ANTLR start "ruleConstructor"
    // InternalSM2.g:913:1: ruleConstructor returns [EObject current=null] : (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY ) ;
    public final EObject ruleConstructor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_2=null;
        Token lv_type_3_1=null;
        Token lv_type_3_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token otherlv_6=null;
        Token this_CLOSEKEY_7=null;


        	enterRule();

        try {
            // InternalSM2.g:919:2: ( (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY ) )
            // InternalSM2.g:920:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY )
            {
            // InternalSM2.g:920:2: (otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY )
            // InternalSM2.g:921:3: otherlv_0= 'constructor' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (otherlv_2= RULE_ID ) ) ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (otherlv_6= RULE_ID ) )? this_CLOSEKEY_7= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,43,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getConstructorAccess().getConstructorKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConstructorAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:929:3: ( (otherlv_2= RULE_ID ) )
            // InternalSM2.g:930:4: (otherlv_2= RULE_ID )
            {
            // InternalSM2.g:930:4: (otherlv_2= RULE_ID )
            // InternalSM2.g:931:5: otherlv_2= RULE_ID
            {
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getConstructorRule());
              					}
              				
            }
            otherlv_2=(Token)match(input,RULE_ID,FOLLOW_28); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(otherlv_2, grammarAccess.getConstructorAccess().getInputParamsInputParamCrossReference_2_0());
              				
            }

            }


            }

            // InternalSM2.g:942:3: ( ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) ) )
            // InternalSM2.g:943:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            {
            // InternalSM2.g:943:4: ( (lv_type_3_1= 'public' | lv_type_3_2= 'internal' ) )
            // InternalSM2.g:944:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            {
            // InternalSM2.g:944:5: (lv_type_3_1= 'public' | lv_type_3_2= 'internal' )
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==44) ) {
                alt22=1;
            }
            else if ( (LA22_0==45) ) {
                alt22=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }
            switch (alt22) {
                case 1 :
                    // InternalSM2.g:945:6: lv_type_3_1= 'public'
                    {
                    lv_type_3_1=(Token)match(input,44,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_3_1, grammarAccess.getConstructorAccess().getTypePublicKeyword_3_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getConstructorRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_3_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:956:6: lv_type_3_2= 'internal'
                    {
                    lv_type_3_2=(Token)match(input,45,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_type_3_2, grammarAccess.getConstructorAccess().getTypeInternalKeyword_3_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getConstructorRule());
                      						}
                      						setWithLastConsumed(current, "type", lv_type_3_2, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getConstructorAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_30); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getConstructorAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:977:3: ( (otherlv_6= RULE_ID ) )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==RULE_ID) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalSM2.g:978:4: (otherlv_6= RULE_ID )
                    {
                    // InternalSM2.g:978:4: (otherlv_6= RULE_ID )
                    // InternalSM2.g:979:5: otherlv_6= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getConstructorRule());
                      					}
                      				
                    }
                    otherlv_6=(Token)match(input,RULE_ID,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_6, grammarAccess.getConstructorAccess().getAttributesAttributesCrossReference_6_0());
                      				
                    }

                    }


                    }
                    break;

            }

            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_7, grammarAccess.getConstructorAccess().getCLOSEKEYTerminalRuleCall_7());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConstructor"


    // $ANTLR start "entryRuleEvent"
    // InternalSM2.g:998:1: entryRuleEvent returns [EObject current=null] : iv_ruleEvent= ruleEvent EOF ;
    public final EObject entryRuleEvent() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvent = null;


        try {
            // InternalSM2.g:998:46: (iv_ruleEvent= ruleEvent EOF )
            // InternalSM2.g:999:2: iv_ruleEvent= ruleEvent EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getEventRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleEvent=ruleEvent();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleEvent; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalSM2.g:1005:1: ruleEvent returns [EObject current=null] : (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject ruleEvent() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEvent_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_SEMICOLON_5=null;
        Token this_EOLINE_6=null;
        EObject lv_inputParams_3_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1011:2: ( (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1012:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1012:2: (otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1013:3: otherlv_0= 'event' ( (lv_nameEvent_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_SEMICOLON_5= RULE_SEMICOLON (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,46,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getEventAccess().getEventKeyword_0());
              		
            }
            // InternalSM2.g:1017:3: ( (lv_nameEvent_1_0= RULE_ID ) )
            // InternalSM2.g:1018:4: (lv_nameEvent_1_0= RULE_ID )
            {
            // InternalSM2.g:1018:4: (lv_nameEvent_1_0= RULE_ID )
            // InternalSM2.g:1019:5: lv_nameEvent_1_0= RULE_ID
            {
            lv_nameEvent_1_0=(Token)match(input,RULE_ID,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameEvent_1_0, grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEventRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameEvent",
              						lv_nameEvent_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_31); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1039:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( (LA24_0==52||LA24_0==54||(LA24_0>=61 && LA24_0<=65)||LA24_0==67||(LA24_0>=81 && LA24_0<=83)) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalSM2.g:1040:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1040:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:1041:5: lv_inputParams_3_0= ruleInputParam
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_31);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getEventRule());
            	      					}
            	      					add(
            	      						current,
            	      						"inputParams",
            	      						lv_inputParams_3_0,
            	      						"org.xtext.SM2.InputParam");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_SEMICOLON_5=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_5, grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1066:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==RULE_EOLINE) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalSM2.g:1067:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:1076:1: entryRuleModifier returns [EObject current=null] : iv_ruleModifier= ruleModifier EOF ;
    public final EObject entryRuleModifier() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModifier = null;


        try {
            // InternalSM2.g:1076:49: (iv_ruleModifier= ruleModifier EOF )
            // InternalSM2.g:1077:2: iv_ruleModifier= ruleModifier EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getModifierRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleModifier=ruleModifier();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleModifier; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:1083:1: ruleModifier returns [EObject current=null] : (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? ) ;
    public final EObject ruleModifier() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameModifier_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_EOLINE_6=null;
        Token this_SEMICOLON_9=null;
        Token this_EOLINE_10=null;
        Token otherlv_11=null;
        Token this_CLOSEKEY_12=null;
        Token this_EOLINE_13=null;
        EObject lv_inputParams_3_0 = null;

        EObject lv_conditions_7_0 = null;

        EObject lv_expr_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1089:2: ( (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? ) )
            // InternalSM2.g:1090:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? )
            {
            // InternalSM2.g:1090:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )? )
            // InternalSM2.g:1091:3: otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParams_3_0= ruleInputParam ) )* this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY (this_EOLINE_6= RULE_EOLINE )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expr_8_0= ruleExpression ) ) this_SEMICOLON_9= RULE_SEMICOLON (this_EOLINE_10= RULE_EOLINE )? otherlv_11= '_;' this_CLOSEKEY_12= RULE_CLOSEKEY (this_EOLINE_13= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,47,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getModifierAccess().getModifierKeyword_0());
              		
            }
            // InternalSM2.g:1095:3: ( (lv_nameModifier_1_0= RULE_ID ) )
            // InternalSM2.g:1096:4: (lv_nameModifier_1_0= RULE_ID )
            {
            // InternalSM2.g:1096:4: (lv_nameModifier_1_0= RULE_ID )
            // InternalSM2.g:1097:5: lv_nameModifier_1_0= RULE_ID
            {
            lv_nameModifier_1_0=(Token)match(input,RULE_ID,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameModifier_1_0, grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getModifierRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameModifier",
              						lv_nameModifier_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_31); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1117:3: ( (lv_inputParams_3_0= ruleInputParam ) )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0==52||LA26_0==54||(LA26_0>=61 && LA26_0<=65)||LA26_0==67||(LA26_0>=81 && LA26_0<=83)) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalSM2.g:1118:4: (lv_inputParams_3_0= ruleInputParam )
            	    {
            	    // InternalSM2.g:1118:4: (lv_inputParams_3_0= ruleInputParam )
            	    // InternalSM2.g:1119:5: lv_inputParams_3_0= ruleInputParam
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_31);
            	    lv_inputParams_3_0=ruleInputParam();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getModifierRule());
            	      					}
            	      					add(
            	      						current,
            	      						"inputParams",
            	      						lv_inputParams_3_0,
            	      						"org.xtext.SM2.InputParam");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_32); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1144:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==RULE_EOLINE) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalSM2.g:1145:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_32); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:1150:3: ( (lv_conditions_7_0= ruleConditional ) )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==RULE_IF) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalSM2.g:1151:4: (lv_conditions_7_0= ruleConditional )
                    {
                    // InternalSM2.g:1151:4: (lv_conditions_7_0= ruleConditional )
                    // InternalSM2.g:1152:5: lv_conditions_7_0= ruleConditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getModifierAccess().getConditionsConditionalParserRuleCall_7_0());
                      				
                    }
                    pushFollow(FOLLOW_32);
                    lv_conditions_7_0=ruleConditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getModifierRule());
                      					}
                      					add(
                      						current,
                      						"conditions",
                      						lv_conditions_7_0,
                      						"org.xtext.SM2.Conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1169:3: ( (lv_expr_8_0= ruleExpression ) )
            // InternalSM2.g:1170:4: (lv_expr_8_0= ruleExpression )
            {
            // InternalSM2.g:1170:4: (lv_expr_8_0= ruleExpression )
            // InternalSM2.g:1171:5: lv_expr_8_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getModifierAccess().getExprExpressionParserRuleCall_8_0());
              				
            }
            pushFollow(FOLLOW_5);
            lv_expr_8_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getModifierRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_8_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_33); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_9, grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_9());
              		
            }
            // InternalSM2.g:1192:3: (this_EOLINE_10= RULE_EOLINE )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==RULE_EOLINE) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalSM2.g:1193:4: this_EOLINE_10= RULE_EOLINE
                    {
                    this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_34); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_10, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_10());
                      			
                    }

                    }
                    break;

            }

            otherlv_11=(Token)match(input,48,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_11, grammarAccess.getModifierAccess().get_Keyword_11());
              		
            }
            this_CLOSEKEY_12=(Token)match(input,RULE_CLOSEKEY,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_12, grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_12());
              		
            }
            // InternalSM2.g:1206:3: (this_EOLINE_13= RULE_EOLINE )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==RULE_EOLINE) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalSM2.g:1207:4: this_EOLINE_13= RULE_EOLINE
                    {
                    this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_13, grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_13());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:1216:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalSM2.g:1216:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalSM2.g:1217:2: iv_ruleDataType= ruleDataType EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getDataTypeRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleDataType; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:1223:1: ruleDataType returns [EObject current=null] : (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        EObject this_Mapping_0 = null;

        EObject this_Enum_1 = null;

        EObject this_Struct_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:1229:2: ( (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct ) )
            // InternalSM2.g:1230:2: (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct )
            {
            // InternalSM2.g:1230:2: (this_Mapping_0= ruleMapping | this_Enum_1= ruleEnum | this_Struct_2= ruleStruct )
            int alt31=3;
            switch ( input.LA(1) ) {
            case 49:
                {
                alt31=1;
                }
                break;
            case 57:
                {
                alt31=2;
                }
                break;
            case 51:
                {
                alt31=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 31, 0, input);

                throw nvae;
            }

            switch (alt31) {
                case 1 :
                    // InternalSM2.g:1231:3: this_Mapping_0= ruleMapping
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getMappingParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Mapping_0=ruleMapping();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Mapping_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1240:3: this_Enum_1= ruleEnum
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Enum_1=ruleEnum();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Enum_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1249:3: this_Struct_2= ruleStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getDataTypeAccess().getStructParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Struct_2=ruleStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Struct_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:1261:1: entryRuleMapping returns [EObject current=null] : iv_ruleMapping= ruleMapping EOF ;
    public final EObject entryRuleMapping() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMapping = null;


        try {
            // InternalSM2.g:1261:48: (iv_ruleMapping= ruleMapping EOF )
            // InternalSM2.g:1262:2: iv_ruleMapping= ruleMapping EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getMappingRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleMapping=ruleMapping();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleMapping; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:1268:1: ruleMapping returns [EObject current=null] : (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON ) ;
    public final EObject ruleMapping() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token lv_nameMapping_8_0=null;
        Token this_SEMICOLON_9=null;
        Enumerator lv_key_2_0 = null;

        Enumerator lv_valueBasicType_5_0 = null;

        Enumerator lv_visibility_7_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1274:2: ( (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON ) )
            // InternalSM2.g:1275:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON )
            {
            // InternalSM2.g:1275:2: (otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON )
            // InternalSM2.g:1276:3: otherlv_0= 'mapping' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_key_2_0= ruleBasicType ) ) otherlv_3= '=>' ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ( (lv_visibility_7_0= ruleVisibility ) )? ( (lv_nameMapping_8_0= RULE_ID ) ) this_SEMICOLON_9= RULE_SEMICOLON
            {
            otherlv_0=(Token)match(input,49,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getMappingAccess().getMappingKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_35); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:1284:3: ( (lv_key_2_0= ruleBasicType ) )
            // InternalSM2.g:1285:4: (lv_key_2_0= ruleBasicType )
            {
            // InternalSM2.g:1285:4: (lv_key_2_0= ruleBasicType )
            // InternalSM2.g:1286:5: lv_key_2_0= ruleBasicType
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getMappingAccess().getKeyBasicTypeEnumRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_36);
            lv_key_2_0=ruleBasicType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getMappingRule());
              					}
              					set(
              						current,
              						"key",
              						lv_key_2_0,
              						"org.xtext.SM2.BasicType");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,50,FOLLOW_37); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3());
              		
            }
            // InternalSM2.g:1307:3: ( ( (otherlv_4= RULE_ID ) ) | ( (lv_valueBasicType_5_0= ruleBasicType ) ) )
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==RULE_ID) ) {
                alt32=1;
            }
            else if ( (LA32_0==52||LA32_0==54||(LA32_0>=61 && LA32_0<=65)||LA32_0==67||(LA32_0>=81 && LA32_0<=83)) ) {
                alt32=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 32, 0, input);

                throw nvae;
            }
            switch (alt32) {
                case 1 :
                    // InternalSM2.g:1308:4: ( (otherlv_4= RULE_ID ) )
                    {
                    // InternalSM2.g:1308:4: ( (otherlv_4= RULE_ID ) )
                    // InternalSM2.g:1309:5: (otherlv_4= RULE_ID )
                    {
                    // InternalSM2.g:1309:5: (otherlv_4= RULE_ID )
                    // InternalSM2.g:1310:6: otherlv_4= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getMappingRule());
                      						}
                      					
                    }
                    otherlv_4=(Token)match(input,RULE_ID,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(otherlv_4, grammarAccess.getMappingAccess().getValueStructCrossReference_4_0_0());
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1322:4: ( (lv_valueBasicType_5_0= ruleBasicType ) )
                    {
                    // InternalSM2.g:1322:4: ( (lv_valueBasicType_5_0= ruleBasicType ) )
                    // InternalSM2.g:1323:5: (lv_valueBasicType_5_0= ruleBasicType )
                    {
                    // InternalSM2.g:1323:5: (lv_valueBasicType_5_0= ruleBasicType )
                    // InternalSM2.g:1324:6: lv_valueBasicType_5_0= ruleBasicType
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getMappingAccess().getValueBasicTypeBasicTypeEnumRuleCall_4_1_0());
                      					
                    }
                    pushFollow(FOLLOW_29);
                    lv_valueBasicType_5_0=ruleBasicType();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getMappingRule());
                      						}
                      						set(
                      							current,
                      							"valueBasicType",
                      							lv_valueBasicType_5_0,
                      							"org.xtext.SM2.BasicType");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_38); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1346:3: ( (lv_visibility_7_0= ruleVisibility ) )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( ((LA33_0>=44 && LA33_0<=45)||(LA33_0>=90 && LA33_0<=91)) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // InternalSM2.g:1347:4: (lv_visibility_7_0= ruleVisibility )
                    {
                    // InternalSM2.g:1347:4: (lv_visibility_7_0= ruleVisibility )
                    // InternalSM2.g:1348:5: lv_visibility_7_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_12);
                    lv_visibility_7_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getMappingRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_7_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:1365:3: ( (lv_nameMapping_8_0= RULE_ID ) )
            // InternalSM2.g:1366:4: (lv_nameMapping_8_0= RULE_ID )
            {
            // InternalSM2.g:1366:4: (lv_nameMapping_8_0= RULE_ID )
            // InternalSM2.g:1367:5: lv_nameMapping_8_0= RULE_ID
            {
            lv_nameMapping_8_0=(Token)match(input,RULE_ID,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameMapping_8_0, grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getMappingRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameMapping",
              						lv_nameMapping_8_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_9, grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:1391:1: entryRuleStruct returns [EObject current=null] : iv_ruleStruct= ruleStruct EOF ;
    public final EObject entryRuleStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStruct = null;


        try {
            // InternalSM2.g:1391:47: (iv_ruleStruct= ruleStruct EOF )
            // InternalSM2.g:1392:2: iv_ruleStruct= ruleStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleStruct=ruleStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:1398:1: ruleStruct returns [EObject current=null] : (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany ) ;
    public final EObject ruleStruct() throws RecognitionException {
        EObject current = null;

        EObject this_PersonalizedStruct_0 = null;

        EObject this_User_1 = null;

        EObject this_Company_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:1404:2: ( (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany ) )
            // InternalSM2.g:1405:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )
            {
            // InternalSM2.g:1405:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )
            int alt34=3;
            alt34 = dfa34.predict(input);
            switch (alt34) {
                case 1 :
                    // InternalSM2.g:1406:3: this_PersonalizedStruct_0= rulePersonalizedStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructAccess().getPersonalizedStructParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PersonalizedStruct_0=rulePersonalizedStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PersonalizedStruct_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:1415:3: this_User_1= ruleUser
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructAccess().getUserParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_User_1=ruleUser();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_User_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:1424:3: this_Company_2= ruleCompany
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructAccess().getCompanyParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_Company_2=ruleCompany();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_Company_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRulePersonalizedStruct"
    // InternalSM2.g:1436:1: entryRulePersonalizedStruct returns [EObject current=null] : iv_rulePersonalizedStruct= rulePersonalizedStruct EOF ;
    public final EObject entryRulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonalizedStruct = null;


        try {
            // InternalSM2.g:1436:59: (iv_rulePersonalizedStruct= rulePersonalizedStruct EOF )
            // InternalSM2.g:1437:2: iv_rulePersonalizedStruct= rulePersonalizedStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPersonalizedStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePersonalizedStruct=rulePersonalizedStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePersonalizedStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonalizedStruct"


    // $ANTLR start "rulePersonalizedStruct"
    // InternalSM2.g:1443:1: rulePersonalizedStruct returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) ;
    public final EObject rulePersonalizedStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_CLOSEKEY_5=null;
        Token this_EOLINE_6=null;
        EObject lv_properties_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:1449:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? ) )
            // InternalSM2.g:1450:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            {
            // InternalSM2.g:1450:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )? )
            // InternalSM2.g:1451:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? ( (lv_properties_4_0= ruleProperty ) )+ this_CLOSEKEY_5= RULE_CLOSEKEY (this_EOLINE_6= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,51,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getPersonalizedStructAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:1455:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1456:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1456:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1457:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getPersonalizedStructAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPersonalizedStructRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_39); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1477:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==RULE_EOLINE) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalSM2.g:1478:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_40); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:1483:3: ( (lv_properties_4_0= ruleProperty ) )+
            int cnt36=0;
            loop36:
            do {
                int alt36=2;
                int LA36_0 = input.LA(1);

                if ( (LA36_0==RULE_ID||LA36_0==52||(LA36_0>=54 && LA36_0<=55)||(LA36_0>=61 && LA36_0<=67)) ) {
                    alt36=1;
                }


                switch (alt36) {
            	case 1 :
            	    // InternalSM2.g:1484:4: (lv_properties_4_0= ruleProperty )
            	    {
            	    // InternalSM2.g:1484:4: (lv_properties_4_0= ruleProperty )
            	    // InternalSM2.g:1485:5: lv_properties_4_0= ruleProperty
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_41);
            	    lv_properties_4_0=ruleProperty();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getPersonalizedStructRule());
            	      					}
            	      					add(
            	      						current,
            	      						"properties",
            	      						lv_properties_4_0,
            	      						"org.xtext.SM2.Property");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt36 >= 1 ) break loop36;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(36, input);
                        throw eee;
                }
                cnt36++;
            } while (true);

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_5, grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:1506:3: (this_EOLINE_6= RULE_EOLINE )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==RULE_EOLINE) ) {
                int LA37_1 = input.LA(2);

                if ( (LA37_1==EOF||(LA37_1>=RULE_EOLINE && LA37_1<=RULE_CLOSEKEY)||LA37_1==RULE_INTEGER||LA37_1==RULE_OPENPARENTHESIS||LA37_1==RULE_STRING||LA37_1==RULE_FLOAT||LA37_1==RULE_IF||LA37_1==43||(LA37_1>=46 && LA37_1<=47)||LA37_1==49||(LA37_1>=51 && LA37_1<=52)||(LA37_1>=54 && LA37_1<=55)||LA37_1==57||(LA37_1>=61 && LA37_1<=67)||LA37_1==72||(LA37_1>=77 && LA37_1<=78)) ) {
                    alt37=1;
                }
                else if ( (LA37_1==RULE_ID) ) {
                    int LA37_4 = input.LA(3);

                    if ( (LA37_4==RULE_ID) ) {
                        int LA37_5 = input.LA(4);

                        if ( (LA37_5==53) ) {
                            alt37=1;
                        }
                    }
                    else if ( (LA37_4==RULE_INTEGER||(LA37_4>=44 && LA37_4<=45)||(LA37_4>=58 && LA37_4<=59)||(LA37_4>=90 && LA37_4<=91)) ) {
                        alt37=1;
                    }
                }
            }
            switch (alt37) {
                case 1 :
                    // InternalSM2.g:1507:4: this_EOLINE_6= RULE_EOLINE
                    {
                    this_EOLINE_6=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_6, grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonalizedStruct"


    // $ANTLR start "entryRuleUser"
    // InternalSM2.g:1516:1: entryRuleUser returns [EObject current=null] : iv_ruleUser= ruleUser EOF ;
    public final EObject entryRuleUser() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleUser = null;


        try {
            // InternalSM2.g:1516:45: (iv_ruleUser= ruleUser EOF )
            // InternalSM2.g:1517:2: iv_ruleUser= ruleUser EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getUserRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleUser=ruleUser();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleUser; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleUser"


    // $ANTLR start "ruleUser"
    // InternalSM2.g:1523:1: ruleUser returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) ;
    public final EObject ruleUser() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_0=null;
        Token otherlv_6=null;
        Token this_STRING_7=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        Token otherlv_10=null;
        Token lv_nameUser_11_0=null;
        Token otherlv_12=null;
        Token this_STRING_13=null;
        Token this_SEMICOLON_14=null;
        Token this_EOLINE_15=null;
        Token otherlv_16=null;
        Token lv_surname_17_0=null;
        Token otherlv_18=null;
        Token this_STRING_19=null;
        Token this_SEMICOLON_20=null;
        Token this_EOLINE_21=null;
        Token otherlv_22=null;
        Token lv_email_23_0=null;
        Token otherlv_24=null;
        Token this_EMAIL_25=null;
        Token this_SEMICOLON_26=null;
        Token this_EOLINE_27=null;
        Token otherlv_28=null;
        Token otherlv_29=null;
        Token otherlv_30=null;
        Token lv_amount_31_0=null;
        Token this_FLOAT_32=null;
        Token this_SEMICOLON_33=null;
        Token this_EOLINE_34=null;
        Token this_CLOSEKEY_35=null;
        Token this_EOLINE_36=null;


        	enterRule();

        try {
            // InternalSM2.g:1529:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) )
            // InternalSM2.g:1530:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            {
            // InternalSM2.g:1530:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            // InternalSM2.g:1531:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON (this_EOLINE_9= RULE_EOLINE )? otherlv_10= 'string' ( (lv_nameUser_11_0= RULE_STRING ) ) (otherlv_12= '=' this_STRING_13= RULE_STRING )? this_SEMICOLON_14= RULE_SEMICOLON (this_EOLINE_15= RULE_EOLINE )? otherlv_16= 'string' ( (lv_surname_17_0= RULE_STRING ) ) (otherlv_18= '=' this_STRING_19= RULE_STRING )? this_SEMICOLON_20= RULE_SEMICOLON (this_EOLINE_21= RULE_EOLINE )? otherlv_22= 'string' ( (lv_email_23_0= RULE_STRING ) ) (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )? this_SEMICOLON_26= RULE_SEMICOLON (this_EOLINE_27= RULE_EOLINE )? otherlv_28= 'float' otherlv_29= 'amountAccount' (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )? this_SEMICOLON_33= RULE_SEMICOLON (this_EOLINE_34= RULE_EOLINE )? this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,51,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getUserAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:1535:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1536:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1536:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1537:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_42); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1557:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==RULE_EOLINE) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:1558:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_43); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            otherlv_4=(Token)match(input,52,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getUserAccess().getAddressKeyword_4());
              		
            }
            // InternalSM2.g:1567:3: ( (lv_idAdress_5_0= RULE_ID ) )
            // InternalSM2.g:1568:4: (lv_idAdress_5_0= RULE_ID )
            {
            // InternalSM2.g:1568:4: (lv_idAdress_5_0= RULE_ID )
            // InternalSM2.g:1569:5: lv_idAdress_5_0= RULE_ID
            {
            lv_idAdress_5_0=(Token)match(input,RULE_ID,FOLLOW_44); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_idAdress_5_0, grammarAccess.getUserAccess().getIdAdressIDTerminalRuleCall_5_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"idAdress",
              						lv_idAdress_5_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:1585:3: (otherlv_6= '=' this_STRING_7= RULE_STRING )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==53) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalSM2.g:1586:4: otherlv_6= '=' this_STRING_7= RULE_STRING
                    {
                    otherlv_6=(Token)match(input,53,FOLLOW_45); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_6, grammarAccess.getUserAccess().getEqualsSignKeyword_6_0());
                      			
                    }
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_7, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_6_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_46); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            // InternalSM2.g:1599:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==RULE_EOLINE) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalSM2.g:1600:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_8());
                      			
                    }

                    }
                    break;

            }

            otherlv_10=(Token)match(input,54,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_10, grammarAccess.getUserAccess().getStringKeyword_9());
              		
            }
            // InternalSM2.g:1609:3: ( (lv_nameUser_11_0= RULE_STRING ) )
            // InternalSM2.g:1610:4: (lv_nameUser_11_0= RULE_STRING )
            {
            // InternalSM2.g:1610:4: (lv_nameUser_11_0= RULE_STRING )
            // InternalSM2.g:1611:5: lv_nameUser_11_0= RULE_STRING
            {
            lv_nameUser_11_0=(Token)match(input,RULE_STRING,FOLLOW_44); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameUser_11_0, grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_10_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameUser",
              						lv_nameUser_11_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1627:3: (otherlv_12= '=' this_STRING_13= RULE_STRING )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==53) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalSM2.g:1628:4: otherlv_12= '=' this_STRING_13= RULE_STRING
                    {
                    otherlv_12=(Token)match(input,53,FOLLOW_45); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_12, grammarAccess.getUserAccess().getEqualsSignKeyword_11_0());
                      			
                    }
                    this_STRING_13=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_13, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_11_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_14=(Token)match(input,RULE_SEMICOLON,FOLLOW_46); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_14, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_12());
              		
            }
            // InternalSM2.g:1641:3: (this_EOLINE_15= RULE_EOLINE )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==RULE_EOLINE) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalSM2.g:1642:4: this_EOLINE_15= RULE_EOLINE
                    {
                    this_EOLINE_15=(Token)match(input,RULE_EOLINE,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_15, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_13());
                      			
                    }

                    }
                    break;

            }

            otherlv_16=(Token)match(input,54,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_16, grammarAccess.getUserAccess().getStringKeyword_14());
              		
            }
            // InternalSM2.g:1651:3: ( (lv_surname_17_0= RULE_STRING ) )
            // InternalSM2.g:1652:4: (lv_surname_17_0= RULE_STRING )
            {
            // InternalSM2.g:1652:4: (lv_surname_17_0= RULE_STRING )
            // InternalSM2.g:1653:5: lv_surname_17_0= RULE_STRING
            {
            lv_surname_17_0=(Token)match(input,RULE_STRING,FOLLOW_44); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_surname_17_0, grammarAccess.getUserAccess().getSurnameSTRINGTerminalRuleCall_15_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"surname",
              						lv_surname_17_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1669:3: (otherlv_18= '=' this_STRING_19= RULE_STRING )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==53) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalSM2.g:1670:4: otherlv_18= '=' this_STRING_19= RULE_STRING
                    {
                    otherlv_18=(Token)match(input,53,FOLLOW_45); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_18, grammarAccess.getUserAccess().getEqualsSignKeyword_16_0());
                      			
                    }
                    this_STRING_19=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_19, grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_16_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_20=(Token)match(input,RULE_SEMICOLON,FOLLOW_46); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_20, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_17());
              		
            }
            // InternalSM2.g:1683:3: (this_EOLINE_21= RULE_EOLINE )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==RULE_EOLINE) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:1684:4: this_EOLINE_21= RULE_EOLINE
                    {
                    this_EOLINE_21=(Token)match(input,RULE_EOLINE,FOLLOW_47); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_21, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_18());
                      			
                    }

                    }
                    break;

            }

            otherlv_22=(Token)match(input,54,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_22, grammarAccess.getUserAccess().getStringKeyword_19());
              		
            }
            // InternalSM2.g:1693:3: ( (lv_email_23_0= RULE_STRING ) )
            // InternalSM2.g:1694:4: (lv_email_23_0= RULE_STRING )
            {
            // InternalSM2.g:1694:4: (lv_email_23_0= RULE_STRING )
            // InternalSM2.g:1695:5: lv_email_23_0= RULE_STRING
            {
            lv_email_23_0=(Token)match(input,RULE_STRING,FOLLOW_44); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_email_23_0, grammarAccess.getUserAccess().getEmailSTRINGTerminalRuleCall_20_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getUserRule());
              					}
              					setWithLastConsumed(
              						current,
              						"email",
              						lv_email_23_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1711:3: (otherlv_24= '=' this_EMAIL_25= RULE_EMAIL )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==53) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalSM2.g:1712:4: otherlv_24= '=' this_EMAIL_25= RULE_EMAIL
                    {
                    otherlv_24=(Token)match(input,53,FOLLOW_48); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_24, grammarAccess.getUserAccess().getEqualsSignKeyword_21_0());
                      			
                    }
                    this_EMAIL_25=(Token)match(input,RULE_EMAIL,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EMAIL_25, grammarAccess.getUserAccess().getEMAILTerminalRuleCall_21_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_26=(Token)match(input,RULE_SEMICOLON,FOLLOW_49); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_26, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_22());
              		
            }
            // InternalSM2.g:1725:3: (this_EOLINE_27= RULE_EOLINE )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==RULE_EOLINE) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:1726:4: this_EOLINE_27= RULE_EOLINE
                    {
                    this_EOLINE_27=(Token)match(input,RULE_EOLINE,FOLLOW_50); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_27, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_23());
                      			
                    }

                    }
                    break;

            }

            otherlv_28=(Token)match(input,55,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_28, grammarAccess.getUserAccess().getFloatKeyword_24());
              		
            }
            otherlv_29=(Token)match(input,56,FOLLOW_44); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_29, grammarAccess.getUserAccess().getAmountAccountKeyword_25());
              		
            }
            // InternalSM2.g:1739:3: (otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT ) )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==53) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalSM2.g:1740:4: otherlv_30= '=' ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT )
                    {
                    otherlv_30=(Token)match(input,53,FOLLOW_52); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_30, grammarAccess.getUserAccess().getEqualsSignKeyword_26_0());
                      			
                    }
                    // InternalSM2.g:1744:4: ( ( (lv_amount_31_0= RULE_INTEGER ) ) | this_FLOAT_32= RULE_FLOAT )
                    int alt47=2;
                    int LA47_0 = input.LA(1);

                    if ( (LA47_0==RULE_INTEGER) ) {
                        alt47=1;
                    }
                    else if ( (LA47_0==RULE_FLOAT) ) {
                        alt47=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 47, 0, input);

                        throw nvae;
                    }
                    switch (alt47) {
                        case 1 :
                            // InternalSM2.g:1745:5: ( (lv_amount_31_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:1745:5: ( (lv_amount_31_0= RULE_INTEGER ) )
                            // InternalSM2.g:1746:6: (lv_amount_31_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:1746:6: (lv_amount_31_0= RULE_INTEGER )
                            // InternalSM2.g:1747:7: lv_amount_31_0= RULE_INTEGER
                            {
                            lv_amount_31_0=(Token)match(input,RULE_INTEGER,FOLLOW_5); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_amount_31_0, grammarAccess.getUserAccess().getAmountINTEGERTerminalRuleCall_26_1_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getUserRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"amount",
                              								lv_amount_31_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:1764:5: this_FLOAT_32= RULE_FLOAT
                            {
                            this_FLOAT_32=(Token)match(input,RULE_FLOAT,FOLLOW_5); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_32, grammarAccess.getUserAccess().getFLOATTerminalRuleCall_26_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }
                    break;

            }

            this_SEMICOLON_33=(Token)match(input,RULE_SEMICOLON,FOLLOW_53); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_33, grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_27());
              		
            }
            // InternalSM2.g:1774:3: (this_EOLINE_34= RULE_EOLINE )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==RULE_EOLINE) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // InternalSM2.g:1775:4: this_EOLINE_34= RULE_EOLINE
                    {
                    this_EOLINE_34=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_34, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_28());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_35=(Token)match(input,RULE_CLOSEKEY,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_35, grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_29());
              		
            }
            // InternalSM2.g:1784:3: (this_EOLINE_36= RULE_EOLINE )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==RULE_EOLINE) ) {
                int LA50_1 = input.LA(2);

                if ( (LA50_1==EOF||(LA50_1>=RULE_EOLINE && LA50_1<=RULE_CLOSEKEY)||LA50_1==RULE_INTEGER||LA50_1==RULE_OPENPARENTHESIS||LA50_1==RULE_STRING||LA50_1==RULE_FLOAT||LA50_1==RULE_IF||LA50_1==43||(LA50_1>=46 && LA50_1<=47)||LA50_1==49||(LA50_1>=51 && LA50_1<=52)||(LA50_1>=54 && LA50_1<=55)||LA50_1==57||(LA50_1>=61 && LA50_1<=67)||LA50_1==72||(LA50_1>=77 && LA50_1<=78)) ) {
                    alt50=1;
                }
                else if ( (LA50_1==RULE_ID) ) {
                    int LA50_4 = input.LA(3);

                    if ( (LA50_4==RULE_ID) ) {
                        int LA50_5 = input.LA(4);

                        if ( (LA50_5==53) ) {
                            alt50=1;
                        }
                    }
                    else if ( (LA50_4==RULE_INTEGER||(LA50_4>=44 && LA50_4<=45)||(LA50_4>=58 && LA50_4<=59)||(LA50_4>=90 && LA50_4<=91)) ) {
                        alt50=1;
                    }
                }
            }
            switch (alt50) {
                case 1 :
                    // InternalSM2.g:1785:4: this_EOLINE_36= RULE_EOLINE
                    {
                    this_EOLINE_36=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_36, grammarAccess.getUserAccess().getEOLINETerminalRuleCall_30());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleUser"


    // $ANTLR start "entryRuleCompany"
    // InternalSM2.g:1794:1: entryRuleCompany returns [EObject current=null] : iv_ruleCompany= ruleCompany EOF ;
    public final EObject entryRuleCompany() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompany = null;


        try {
            // InternalSM2.g:1794:48: (iv_ruleCompany= ruleCompany EOF )
            // InternalSM2.g:1795:2: iv_ruleCompany= ruleCompany EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCompanyRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleCompany=ruleCompany();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleCompany; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompany"


    // $ANTLR start "ruleCompany"
    // InternalSM2.g:1801:1: ruleCompany returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) ;
    public final EObject ruleCompany() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token otherlv_4=null;
        Token lv_idAdress_5_0=null;
        Token otherlv_6=null;
        Token this_STRING_7=null;
        Token this_SEMICOLON_8=null;
        Token otherlv_9=null;
        Token lv_nameCompany_10_0=null;
        Token otherlv_11=null;
        Token this_STRING_12=null;
        Token this_SEMICOLON_13=null;
        Token otherlv_14=null;
        Token lv_city_15_0=null;
        Token otherlv_16=null;
        Token this_STRING_17=null;
        Token this_SEMICOLON_18=null;
        Token otherlv_19=null;
        Token lv_email_20_0=null;
        Token otherlv_21=null;
        Token this_EMAIL_22=null;
        Token this_SEMICOLON_23=null;
        Token otherlv_24=null;
        Token lv_telf_25_0=null;
        Token otherlv_26=null;
        Token this_STRING_27=null;
        Token this_SEMICOLON_28=null;
        Token otherlv_29=null;
        Token otherlv_30=null;
        Token otherlv_31=null;
        Token lv_amount_32_0=null;
        Token this_FLOAT_33=null;
        Token this_SEMICOLON_34=null;
        Token this_CLOSEKEY_35=null;
        Token this_EOLINE_36=null;


        	enterRule();

        try {
            // InternalSM2.g:1807:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? ) )
            // InternalSM2.g:1808:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            {
            // InternalSM2.g:1808:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )? )
            // InternalSM2.g:1809:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY (this_EOLINE_3= RULE_EOLINE )? otherlv_4= 'address' ( (lv_idAdress_5_0= RULE_ID ) ) (otherlv_6= '=' this_STRING_7= RULE_STRING )? this_SEMICOLON_8= RULE_SEMICOLON otherlv_9= 'string' ( (lv_nameCompany_10_0= RULE_STRING ) ) (otherlv_11= '=' this_STRING_12= RULE_STRING )? this_SEMICOLON_13= RULE_SEMICOLON otherlv_14= 'string' ( (lv_city_15_0= RULE_STRING ) ) (otherlv_16= '=' this_STRING_17= RULE_STRING )? this_SEMICOLON_18= RULE_SEMICOLON otherlv_19= 'string' ( (lv_email_20_0= RULE_STRING ) ) (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )? this_SEMICOLON_23= RULE_SEMICOLON otherlv_24= 'string' ( (lv_telf_25_0= RULE_STRING ) ) (otherlv_26= '=' this_STRING_27= RULE_STRING )? this_SEMICOLON_28= RULE_SEMICOLON otherlv_29= 'float' otherlv_30= 'amountAccount' (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )? this_SEMICOLON_34= RULE_SEMICOLON this_CLOSEKEY_35= RULE_CLOSEKEY (this_EOLINE_36= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,51,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getCompanyAccess().getStructKeyword_0());
              		
            }
            // InternalSM2.g:1813:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2.g:1814:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2.g:1814:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2.g:1815:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameStruct_1_0, grammarAccess.getCompanyAccess().getNameStructIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameStruct",
              						lv_nameStruct_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_42); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getCompanyAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:1835:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt51=2;
            int LA51_0 = input.LA(1);

            if ( (LA51_0==RULE_EOLINE) ) {
                alt51=1;
            }
            switch (alt51) {
                case 1 :
                    // InternalSM2.g:1836:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_43); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }

            otherlv_4=(Token)match(input,52,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getCompanyAccess().getAddressKeyword_4());
              		
            }
            // InternalSM2.g:1845:3: ( (lv_idAdress_5_0= RULE_ID ) )
            // InternalSM2.g:1846:4: (lv_idAdress_5_0= RULE_ID )
            {
            // InternalSM2.g:1846:4: (lv_idAdress_5_0= RULE_ID )
            // InternalSM2.g:1847:5: lv_idAdress_5_0= RULE_ID
            {
            lv_idAdress_5_0=(Token)match(input,RULE_ID,FOLLOW_44); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_idAdress_5_0, grammarAccess.getCompanyAccess().getIdAdressIDTerminalRuleCall_5_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"idAdress",
              						lv_idAdress_5_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalSM2.g:1863:3: (otherlv_6= '=' this_STRING_7= RULE_STRING )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==53) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalSM2.g:1864:4: otherlv_6= '=' this_STRING_7= RULE_STRING
                    {
                    otherlv_6=(Token)match(input,53,FOLLOW_45); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_6, grammarAccess.getCompanyAccess().getEqualsSignKeyword_6_0());
                      			
                    }
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_7, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_6_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            otherlv_9=(Token)match(input,54,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_9, grammarAccess.getCompanyAccess().getStringKeyword_8());
              		
            }
            // InternalSM2.g:1881:3: ( (lv_nameCompany_10_0= RULE_STRING ) )
            // InternalSM2.g:1882:4: (lv_nameCompany_10_0= RULE_STRING )
            {
            // InternalSM2.g:1882:4: (lv_nameCompany_10_0= RULE_STRING )
            // InternalSM2.g:1883:5: lv_nameCompany_10_0= RULE_STRING
            {
            lv_nameCompany_10_0=(Token)match(input,RULE_STRING,FOLLOW_44); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameCompany_10_0, grammarAccess.getCompanyAccess().getNameCompanySTRINGTerminalRuleCall_9_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameCompany",
              						lv_nameCompany_10_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1899:3: (otherlv_11= '=' this_STRING_12= RULE_STRING )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==53) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // InternalSM2.g:1900:4: otherlv_11= '=' this_STRING_12= RULE_STRING
                    {
                    otherlv_11=(Token)match(input,53,FOLLOW_45); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_11, grammarAccess.getCompanyAccess().getEqualsSignKeyword_10_0());
                      			
                    }
                    this_STRING_12=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_12, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_10_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_13=(Token)match(input,RULE_SEMICOLON,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_13, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_11());
              		
            }
            otherlv_14=(Token)match(input,54,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_14, grammarAccess.getCompanyAccess().getStringKeyword_12());
              		
            }
            // InternalSM2.g:1917:3: ( (lv_city_15_0= RULE_STRING ) )
            // InternalSM2.g:1918:4: (lv_city_15_0= RULE_STRING )
            {
            // InternalSM2.g:1918:4: (lv_city_15_0= RULE_STRING )
            // InternalSM2.g:1919:5: lv_city_15_0= RULE_STRING
            {
            lv_city_15_0=(Token)match(input,RULE_STRING,FOLLOW_44); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_city_15_0, grammarAccess.getCompanyAccess().getCitySTRINGTerminalRuleCall_13_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"city",
              						lv_city_15_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1935:3: (otherlv_16= '=' this_STRING_17= RULE_STRING )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==53) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalSM2.g:1936:4: otherlv_16= '=' this_STRING_17= RULE_STRING
                    {
                    otherlv_16=(Token)match(input,53,FOLLOW_45); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_16, grammarAccess.getCompanyAccess().getEqualsSignKeyword_14_0());
                      			
                    }
                    this_STRING_17=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_17, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_14_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_18=(Token)match(input,RULE_SEMICOLON,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_18, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_15());
              		
            }
            otherlv_19=(Token)match(input,54,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_19, grammarAccess.getCompanyAccess().getStringKeyword_16());
              		
            }
            // InternalSM2.g:1953:3: ( (lv_email_20_0= RULE_STRING ) )
            // InternalSM2.g:1954:4: (lv_email_20_0= RULE_STRING )
            {
            // InternalSM2.g:1954:4: (lv_email_20_0= RULE_STRING )
            // InternalSM2.g:1955:5: lv_email_20_0= RULE_STRING
            {
            lv_email_20_0=(Token)match(input,RULE_STRING,FOLLOW_44); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_email_20_0, grammarAccess.getCompanyAccess().getEmailSTRINGTerminalRuleCall_17_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"email",
              						lv_email_20_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:1971:3: (otherlv_21= '=' this_EMAIL_22= RULE_EMAIL )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==53) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // InternalSM2.g:1972:4: otherlv_21= '=' this_EMAIL_22= RULE_EMAIL
                    {
                    otherlv_21=(Token)match(input,53,FOLLOW_48); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_21, grammarAccess.getCompanyAccess().getEqualsSignKeyword_18_0());
                      			
                    }
                    this_EMAIL_22=(Token)match(input,RULE_EMAIL,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EMAIL_22, grammarAccess.getCompanyAccess().getEMAILTerminalRuleCall_18_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_23=(Token)match(input,RULE_SEMICOLON,FOLLOW_47); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_23, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_19());
              		
            }
            otherlv_24=(Token)match(input,54,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_24, grammarAccess.getCompanyAccess().getStringKeyword_20());
              		
            }
            // InternalSM2.g:1989:3: ( (lv_telf_25_0= RULE_STRING ) )
            // InternalSM2.g:1990:4: (lv_telf_25_0= RULE_STRING )
            {
            // InternalSM2.g:1990:4: (lv_telf_25_0= RULE_STRING )
            // InternalSM2.g:1991:5: lv_telf_25_0= RULE_STRING
            {
            lv_telf_25_0=(Token)match(input,RULE_STRING,FOLLOW_44); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_telf_25_0, grammarAccess.getCompanyAccess().getTelfSTRINGTerminalRuleCall_21_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getCompanyRule());
              					}
              					setWithLastConsumed(
              						current,
              						"telf",
              						lv_telf_25_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:2007:3: (otherlv_26= '=' this_STRING_27= RULE_STRING )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==53) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalSM2.g:2008:4: otherlv_26= '=' this_STRING_27= RULE_STRING
                    {
                    otherlv_26=(Token)match(input,53,FOLLOW_45); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_26, grammarAccess.getCompanyAccess().getEqualsSignKeyword_22_0());
                      			
                    }
                    this_STRING_27=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_27, grammarAccess.getCompanyAccess().getSTRINGTerminalRuleCall_22_1());
                      			
                    }

                    }
                    break;

            }

            this_SEMICOLON_28=(Token)match(input,RULE_SEMICOLON,FOLLOW_50); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_28, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_23());
              		
            }
            otherlv_29=(Token)match(input,55,FOLLOW_51); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_29, grammarAccess.getCompanyAccess().getFloatKeyword_24());
              		
            }
            otherlv_30=(Token)match(input,56,FOLLOW_44); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_30, grammarAccess.getCompanyAccess().getAmountAccountKeyword_25());
              		
            }
            // InternalSM2.g:2029:3: (otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT ) )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==53) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // InternalSM2.g:2030:4: otherlv_31= '=' ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT )
                    {
                    otherlv_31=(Token)match(input,53,FOLLOW_52); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(otherlv_31, grammarAccess.getCompanyAccess().getEqualsSignKeyword_26_0());
                      			
                    }
                    // InternalSM2.g:2034:4: ( ( (lv_amount_32_0= RULE_INTEGER ) ) | this_FLOAT_33= RULE_FLOAT )
                    int alt57=2;
                    int LA57_0 = input.LA(1);

                    if ( (LA57_0==RULE_INTEGER) ) {
                        alt57=1;
                    }
                    else if ( (LA57_0==RULE_FLOAT) ) {
                        alt57=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 57, 0, input);

                        throw nvae;
                    }
                    switch (alt57) {
                        case 1 :
                            // InternalSM2.g:2035:5: ( (lv_amount_32_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:2035:5: ( (lv_amount_32_0= RULE_INTEGER ) )
                            // InternalSM2.g:2036:6: (lv_amount_32_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:2036:6: (lv_amount_32_0= RULE_INTEGER )
                            // InternalSM2.g:2037:7: lv_amount_32_0= RULE_INTEGER
                            {
                            lv_amount_32_0=(Token)match(input,RULE_INTEGER,FOLLOW_5); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_amount_32_0, grammarAccess.getCompanyAccess().getAmountINTEGERTerminalRuleCall_26_1_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getCompanyRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"amount",
                              								lv_amount_32_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:2054:5: this_FLOAT_33= RULE_FLOAT
                            {
                            this_FLOAT_33=(Token)match(input,RULE_FLOAT,FOLLOW_5); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_33, grammarAccess.getCompanyAccess().getFLOATTerminalRuleCall_26_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }
                    break;

            }

            this_SEMICOLON_34=(Token)match(input,RULE_SEMICOLON,FOLLOW_7); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_34, grammarAccess.getCompanyAccess().getSEMICOLONTerminalRuleCall_27());
              		
            }
            this_CLOSEKEY_35=(Token)match(input,RULE_CLOSEKEY,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_35, grammarAccess.getCompanyAccess().getCLOSEKEYTerminalRuleCall_28());
              		
            }
            // InternalSM2.g:2068:3: (this_EOLINE_36= RULE_EOLINE )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==RULE_EOLINE) ) {
                int LA59_1 = input.LA(2);

                if ( (LA59_1==RULE_ID) ) {
                    int LA59_3 = input.LA(3);

                    if ( (LA59_3==RULE_ID) ) {
                        int LA59_5 = input.LA(4);

                        if ( (LA59_5==53) ) {
                            alt59=1;
                        }
                    }
                    else if ( (LA59_3==RULE_INTEGER||(LA59_3>=44 && LA59_3<=45)||(LA59_3>=58 && LA59_3<=59)||(LA59_3>=90 && LA59_3<=91)) ) {
                        alt59=1;
                    }
                }
                else if ( (LA59_1==EOF||(LA59_1>=RULE_EOLINE && LA59_1<=RULE_CLOSEKEY)||LA59_1==RULE_INTEGER||LA59_1==RULE_OPENPARENTHESIS||LA59_1==RULE_STRING||LA59_1==RULE_FLOAT||LA59_1==RULE_IF||LA59_1==43||(LA59_1>=46 && LA59_1<=47)||LA59_1==49||(LA59_1>=51 && LA59_1<=52)||(LA59_1>=54 && LA59_1<=55)||LA59_1==57||(LA59_1>=61 && LA59_1<=67)||LA59_1==72||(LA59_1>=77 && LA59_1<=78)) ) {
                    alt59=1;
                }
            }
            switch (alt59) {
                case 1 :
                    // InternalSM2.g:2069:4: this_EOLINE_36= RULE_EOLINE
                    {
                    this_EOLINE_36=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_36, grammarAccess.getCompanyAccess().getEOLINETerminalRuleCall_29());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompany"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:2078:1: entryRuleEnum returns [EObject current=null] : iv_ruleEnum= ruleEnum EOF ;
    public final EObject entryRuleEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnum = null;


        try {
            // InternalSM2.g:2078:45: (iv_ruleEnum= ruleEnum EOF )
            // InternalSM2.g:2079:2: iv_ruleEnum= ruleEnum EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getEnumRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleEnum=ruleEnum();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleEnum; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:2085:1: ruleEnum returns [EObject current=null] : (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject ruleEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEnum_1_0=null;
        Token this_OPENKEY_2=null;
        Token lv_literal_3_0=null;
        Token this_COMMA_4=null;
        Token this_CLOSEKEY_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;


        	enterRule();

        try {
            // InternalSM2.g:2091:2: ( (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2092:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2092:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2093:3: otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) this_OPENKEY_2= RULE_OPENKEY ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+ this_CLOSEKEY_5= RULE_CLOSEKEY this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,57,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getEnumAccess().getEnumKeyword_0());
              		
            }
            // InternalSM2.g:2097:3: ( (lv_nameEnum_1_0= RULE_ID ) )
            // InternalSM2.g:2098:4: (lv_nameEnum_1_0= RULE_ID )
            {
            // InternalSM2.g:2098:4: (lv_nameEnum_1_0= RULE_ID )
            // InternalSM2.g:2099:5: lv_nameEnum_1_0= RULE_ID
            {
            lv_nameEnum_1_0=(Token)match(input,RULE_ID,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameEnum_1_0, grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getEnumRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameEnum",
              						lv_nameEnum_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2119:3: ( ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )? )+
            int cnt61=0;
            loop61:
            do {
                int alt61=2;
                int LA61_0 = input.LA(1);

                if ( (LA61_0==RULE_STRING) ) {
                    alt61=1;
                }


                switch (alt61) {
            	case 1 :
            	    // InternalSM2.g:2120:4: ( (lv_literal_3_0= RULE_STRING ) ) (this_COMMA_4= RULE_COMMA )?
            	    {
            	    // InternalSM2.g:2120:4: ( (lv_literal_3_0= RULE_STRING ) )
            	    // InternalSM2.g:2121:5: (lv_literal_3_0= RULE_STRING )
            	    {
            	    // InternalSM2.g:2121:5: (lv_literal_3_0= RULE_STRING )
            	    // InternalSM2.g:2122:6: lv_literal_3_0= RULE_STRING
            	    {
            	    lv_literal_3_0=(Token)match(input,RULE_STRING,FOLLOW_54); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      						newLeafNode(lv_literal_3_0, grammarAccess.getEnumAccess().getLiteralSTRINGTerminalRuleCall_3_0_0());
            	      					
            	    }
            	    if ( state.backtracking==0 ) {

            	      						if (current==null) {
            	      							current = createModelElement(grammarAccess.getEnumRule());
            	      						}
            	      						setWithLastConsumed(
            	      							current,
            	      							"literal",
            	      							lv_literal_3_0,
            	      							"org.eclipse.xtext.common.Terminals.STRING");
            	      					
            	    }

            	    }


            	    }

            	    // InternalSM2.g:2138:4: (this_COMMA_4= RULE_COMMA )?
            	    int alt60=2;
            	    int LA60_0 = input.LA(1);

            	    if ( (LA60_0==RULE_COMMA) ) {
            	        alt60=1;
            	    }
            	    switch (alt60) {
            	        case 1 :
            	            // InternalSM2.g:2139:5: this_COMMA_4= RULE_COMMA
            	            {
            	            this_COMMA_4=(Token)match(input,RULE_COMMA,FOLLOW_55); if (state.failed) return current;
            	            if ( state.backtracking==0 ) {

            	              					newLeafNode(this_COMMA_4, grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_3_1());
            	              				
            	            }

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt61 >= 1 ) break loop61;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(61, input);
                        throw eee;
                }
                cnt61++;
            } while (true);

            this_CLOSEKEY_5=(Token)match(input,RULE_CLOSEKEY,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_5, grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_4());
              		
            }
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:2153:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt62=2;
            alt62 = dfa62.predict(input);
            switch (alt62) {
                case 1 :
                    // InternalSM2.g:2154:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_6());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleArray"
    // InternalSM2.g:2163:1: entryRuleArray returns [String current=null] : iv_ruleArray= ruleArray EOF ;
    public final String entryRuleArray() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleArray = null;


        try {
            // InternalSM2.g:2163:45: (iv_ruleArray= ruleArray EOF )
            // InternalSM2.g:2164:2: iv_ruleArray= ruleArray EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArrayRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArray=ruleArray();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArray.getText(); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArray"


    // $ANTLR start "ruleArray"
    // InternalSM2.g:2170:1: ruleArray returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )* ) ;
    public final AntlrDatatypeRuleToken ruleArray() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_SINGLENUMBER_2=null;
        Token this_INTEGER_3=null;
        Token this_SINGLENUMBER_7=null;
        Token this_INTEGER_8=null;


        	enterRule();

        try {
            // InternalSM2.g:2176:2: ( ( (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )* ) )
            // InternalSM2.g:2177:2: ( (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )* )
            {
            // InternalSM2.g:2177:2: ( (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )* )
            // InternalSM2.g:2178:3: (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) ) (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )*
            {
            // InternalSM2.g:2178:3: (kw= '[]' | (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER ) | (this_INTEGER_3= RULE_INTEGER kw= ']' ) )
            int alt63=3;
            switch ( input.LA(1) ) {
            case 58:
                {
                alt63=1;
                }
                break;
            case 59:
                {
                alt63=2;
                }
                break;
            case RULE_INTEGER:
                {
                alt63=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 63, 0, input);

                throw nvae;
            }

            switch (alt63) {
                case 1 :
                    // InternalSM2.g:2179:4: kw= '[]'
                    {
                    kw=(Token)match(input,58,FOLLOW_56); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current.merge(kw);
                      				newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_0_0());
                      			
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2185:4: (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER )
                    {
                    // InternalSM2.g:2185:4: (kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER )
                    // InternalSM2.g:2186:5: kw= '[' this_SINGLENUMBER_2= RULE_SINGLENUMBER
                    {
                    kw=(Token)match(input,59,FOLLOW_8); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					current.merge(kw);
                      					newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_0_1_0());
                      				
                    }
                    this_SINGLENUMBER_2=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_56); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					current.merge(this_SINGLENUMBER_2);
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_SINGLENUMBER_2, grammarAccess.getArrayAccess().getSINGLENUMBERTerminalRuleCall_0_1_1());
                      				
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:2200:4: (this_INTEGER_3= RULE_INTEGER kw= ']' )
                    {
                    // InternalSM2.g:2200:4: (this_INTEGER_3= RULE_INTEGER kw= ']' )
                    // InternalSM2.g:2201:5: this_INTEGER_3= RULE_INTEGER kw= ']'
                    {
                    this_INTEGER_3=(Token)match(input,RULE_INTEGER,FOLLOW_57); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					current.merge(this_INTEGER_3);
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					newLeafNode(this_INTEGER_3, grammarAccess.getArrayAccess().getINTEGERTerminalRuleCall_0_2_0());
                      				
                    }
                    kw=(Token)match(input,60,FOLLOW_56); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					current.merge(kw);
                      					newLeafNode(kw, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_0_2_1());
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2215:3: (kw= '[]' | (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER ) | (this_INTEGER_8= RULE_INTEGER kw= ']' ) )*
            loop64:
            do {
                int alt64=4;
                switch ( input.LA(1) ) {
                case 58:
                    {
                    alt64=1;
                    }
                    break;
                case 59:
                    {
                    alt64=2;
                    }
                    break;
                case RULE_INTEGER:
                    {
                    alt64=3;
                    }
                    break;

                }

                switch (alt64) {
            	case 1 :
            	    // InternalSM2.g:2216:4: kw= '[]'
            	    {
            	    kw=(Token)match(input,58,FOLLOW_56); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      				current.merge(kw);
            	      				newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketRightSquareBracketKeyword_1_0());
            	      			
            	    }

            	    }
            	    break;
            	case 2 :
            	    // InternalSM2.g:2222:4: (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER )
            	    {
            	    // InternalSM2.g:2222:4: (kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER )
            	    // InternalSM2.g:2223:5: kw= '[' this_SINGLENUMBER_7= RULE_SINGLENUMBER
            	    {
            	    kw=(Token)match(input,59,FOLLOW_8); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					current.merge(kw);
            	      					newLeafNode(kw, grammarAccess.getArrayAccess().getLeftSquareBracketKeyword_1_1_0());
            	      				
            	    }
            	    this_SINGLENUMBER_7=(Token)match(input,RULE_SINGLENUMBER,FOLLOW_56); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					current.merge(this_SINGLENUMBER_7);
            	      				
            	    }
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(this_SINGLENUMBER_7, grammarAccess.getArrayAccess().getSINGLENUMBERTerminalRuleCall_1_1_1());
            	      				
            	    }

            	    }


            	    }
            	    break;
            	case 3 :
            	    // InternalSM2.g:2237:4: (this_INTEGER_8= RULE_INTEGER kw= ']' )
            	    {
            	    // InternalSM2.g:2237:4: (this_INTEGER_8= RULE_INTEGER kw= ']' )
            	    // InternalSM2.g:2238:5: this_INTEGER_8= RULE_INTEGER kw= ']'
            	    {
            	    this_INTEGER_8=(Token)match(input,RULE_INTEGER,FOLLOW_57); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					current.merge(this_INTEGER_8);
            	      				
            	    }
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(this_INTEGER_8, grammarAccess.getArrayAccess().getINTEGERTerminalRuleCall_1_2_0());
            	      				
            	    }
            	    kw=(Token)match(input,60,FOLLOW_56); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					current.merge(kw);
            	      					newLeafNode(kw, grammarAccess.getArrayAccess().getRightSquareBracketKeyword_1_2_1());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop64;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArray"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:2256:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // InternalSM2.g:2256:49: (iv_ruleProperty= ruleProperty EOF )
            // InternalSM2.g:2257:2: iv_ruleProperty= ruleProperty EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleProperty=ruleProperty();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleProperty; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:2263:1: ruleProperty returns [EObject current=null] : (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        EObject this_PropertyString_0 = null;

        EObject this_PropertyInteger_1 = null;

        EObject this_PropertyFloat_2 = null;

        EObject this_PropertyAddress_3 = null;

        EObject this_PropertyBoolean_4 = null;

        EObject this_PropertyBytes_5 = null;

        EObject this_PropertyStruct_6 = null;



        	enterRule();

        try {
            // InternalSM2.g:2269:2: ( (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct ) )
            // InternalSM2.g:2270:2: (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct )
            {
            // InternalSM2.g:2270:2: (this_PropertyString_0= rulePropertyString | this_PropertyInteger_1= rulePropertyInteger | this_PropertyFloat_2= rulePropertyFloat | this_PropertyAddress_3= rulePropertyAddress | this_PropertyBoolean_4= rulePropertyBoolean | this_PropertyBytes_5= rulePropertyBytes | this_PropertyStruct_6= rulePropertyStruct )
            int alt65=7;
            switch ( input.LA(1) ) {
            case 54:
                {
                alt65=1;
                }
                break;
            case 61:
            case 62:
            case 63:
                {
                alt65=2;
                }
                break;
            case 55:
                {
                alt65=3;
                }
                break;
            case 52:
            case 65:
                {
                alt65=4;
                }
                break;
            case 64:
                {
                alt65=5;
                }
                break;
            case 66:
            case 67:
                {
                alt65=6;
                }
                break;
            case RULE_ID:
                {
                alt65=7;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 65, 0, input);

                throw nvae;
            }

            switch (alt65) {
                case 1 :
                    // InternalSM2.g:2271:3: this_PropertyString_0= rulePropertyString
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyStringParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyString_0=rulePropertyString();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyString_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2280:3: this_PropertyInteger_1= rulePropertyInteger
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyIntegerParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyInteger_1=rulePropertyInteger();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyInteger_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2289:3: this_PropertyFloat_2= rulePropertyFloat
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyFloatParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyFloat_2=rulePropertyFloat();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyFloat_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:2298:3: this_PropertyAddress_3= rulePropertyAddress
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyAddressParserRuleCall_3());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyAddress_3=rulePropertyAddress();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyAddress_3;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 5 :
                    // InternalSM2.g:2307:3: this_PropertyBoolean_4= rulePropertyBoolean
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyBooleanParserRuleCall_4());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyBoolean_4=rulePropertyBoolean();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyBoolean_4;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 6 :
                    // InternalSM2.g:2316:3: this_PropertyBytes_5= rulePropertyBytes
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyBytesParserRuleCall_5());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyBytes_5=rulePropertyBytes();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyBytes_5;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 7 :
                    // InternalSM2.g:2325:3: this_PropertyStruct_6= rulePropertyStruct
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getPropertyAccess().getPropertyStructParserRuleCall_6());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PropertyStruct_6=rulePropertyStruct();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PropertyStruct_6;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRulePropertyString"
    // InternalSM2.g:2337:1: entryRulePropertyString returns [EObject current=null] : iv_rulePropertyString= rulePropertyString EOF ;
    public final EObject entryRulePropertyString() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyString = null;


        try {
            // InternalSM2.g:2337:55: (iv_rulePropertyString= rulePropertyString EOF )
            // InternalSM2.g:2338:2: iv_rulePropertyString= rulePropertyString EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyStringRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyString=rulePropertyString();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyString; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyString"


    // $ANTLR start "rulePropertyString"
    // InternalSM2.g:2344:1: rulePropertyString returns [EObject current=null] : (otherlv_0= 'string' ( (lv_inicialization_1_0= RULE_STRING ) )? this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? ) ;
    public final EObject rulePropertyString() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_inicialization_1_0=null;
        Token this_SEMICOLON_2=null;
        Token this_EOLINE_3=null;


        	enterRule();

        try {
            // InternalSM2.g:2350:2: ( (otherlv_0= 'string' ( (lv_inicialization_1_0= RULE_STRING ) )? this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? ) )
            // InternalSM2.g:2351:2: (otherlv_0= 'string' ( (lv_inicialization_1_0= RULE_STRING ) )? this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? )
            {
            // InternalSM2.g:2351:2: (otherlv_0= 'string' ( (lv_inicialization_1_0= RULE_STRING ) )? this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )? )
            // InternalSM2.g:2352:3: otherlv_0= 'string' ( (lv_inicialization_1_0= RULE_STRING ) )? this_SEMICOLON_2= RULE_SEMICOLON (this_EOLINE_3= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,54,FOLLOW_58); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getPropertyStringAccess().getStringKeyword_0());
              		
            }
            // InternalSM2.g:2356:3: ( (lv_inicialization_1_0= RULE_STRING ) )?
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==RULE_STRING) ) {
                alt66=1;
            }
            switch (alt66) {
                case 1 :
                    // InternalSM2.g:2357:4: (lv_inicialization_1_0= RULE_STRING )
                    {
                    // InternalSM2.g:2357:4: (lv_inicialization_1_0= RULE_STRING )
                    // InternalSM2.g:2358:5: lv_inicialization_1_0= RULE_STRING
                    {
                    lv_inicialization_1_0=(Token)match(input,RULE_STRING,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_inicialization_1_0, grammarAccess.getPropertyStringAccess().getInicializationSTRINGTerminalRuleCall_1_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getPropertyStringRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"inicialization",
                      						lv_inicialization_1_0,
                      						"org.eclipse.xtext.common.Terminals.STRING");
                      				
                    }

                    }


                    }
                    break;

            }

            this_SEMICOLON_2=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_2, grammarAccess.getPropertyStringAccess().getSEMICOLONTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:2378:3: (this_EOLINE_3= RULE_EOLINE )?
            int alt67=2;
            int LA67_0 = input.LA(1);

            if ( (LA67_0==RULE_EOLINE) ) {
                alt67=1;
            }
            switch (alt67) {
                case 1 :
                    // InternalSM2.g:2379:4: this_EOLINE_3= RULE_EOLINE
                    {
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getPropertyStringAccess().getEOLINETerminalRuleCall_3());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyString"


    // $ANTLR start "entryRulePropertyInteger"
    // InternalSM2.g:2388:1: entryRulePropertyInteger returns [EObject current=null] : iv_rulePropertyInteger= rulePropertyInteger EOF ;
    public final EObject entryRulePropertyInteger() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyInteger = null;


        try {
            // InternalSM2.g:2388:56: (iv_rulePropertyInteger= rulePropertyInteger EOF )
            // InternalSM2.g:2389:2: iv_rulePropertyInteger= rulePropertyInteger EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyIntegerRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyInteger=rulePropertyInteger();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyInteger; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyInteger"


    // $ANTLR start "rulePropertyInteger"
    // InternalSM2.g:2395:1: rulePropertyInteger returns [EObject current=null] : ( ( ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint8' | lv_option_0_3= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyInteger() throws RecognitionException {
        EObject current = null;

        Token lv_option_0_1=null;
        Token lv_option_0_2=null;
        Token lv_option_0_3=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token lv_inicialization_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2401:2: ( ( ( ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint8' | lv_option_0_3= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2402:2: ( ( ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint8' | lv_option_0_3= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2402:2: ( ( ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint8' | lv_option_0_3= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2403:3: ( ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint8' | lv_option_0_3= 'uint256' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_INTEGER ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:2403:3: ( ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint8' | lv_option_0_3= 'uint256' ) ) )
            // InternalSM2.g:2404:4: ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint8' | lv_option_0_3= 'uint256' ) )
            {
            // InternalSM2.g:2404:4: ( (lv_option_0_1= 'int' | lv_option_0_2= 'uint8' | lv_option_0_3= 'uint256' ) )
            // InternalSM2.g:2405:5: (lv_option_0_1= 'int' | lv_option_0_2= 'uint8' | lv_option_0_3= 'uint256' )
            {
            // InternalSM2.g:2405:5: (lv_option_0_1= 'int' | lv_option_0_2= 'uint8' | lv_option_0_3= 'uint256' )
            int alt68=3;
            switch ( input.LA(1) ) {
            case 61:
                {
                alt68=1;
                }
                break;
            case 62:
                {
                alt68=2;
                }
                break;
            case 63:
                {
                alt68=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 68, 0, input);

                throw nvae;
            }

            switch (alt68) {
                case 1 :
                    // InternalSM2.g:2406:6: lv_option_0_1= 'int'
                    {
                    lv_option_0_1=(Token)match(input,61,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_1, grammarAccess.getPropertyIntegerAccess().getOptionIntKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2417:6: lv_option_0_2= 'uint8'
                    {
                    lv_option_0_2=(Token)match(input,62,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_2, grammarAccess.getPropertyIntegerAccess().getOptionUint8Keyword_0_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_2, null);
                      					
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:2428:6: lv_option_0_3= 'uint256'
                    {
                    lv_option_0_3=(Token)match(input,63,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_3, grammarAccess.getPropertyIntegerAccess().getOptionUint256Keyword_0_0_2());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_3, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:2441:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==RULE_INTEGER||(LA69_0>=58 && LA69_0<=59)) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // InternalSM2.g:2442:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:2442:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:2443:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyIntegerAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_38);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyIntegerRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2460:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( ((LA70_0>=44 && LA70_0<=45)||(LA70_0>=90 && LA70_0<=91)) ) {
                alt70=1;
            }
            switch (alt70) {
                case 1 :
                    // InternalSM2.g:2461:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:2461:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:2462:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyIntegerAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_12);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyIntegerRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2479:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:2480:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:2480:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:2481:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_60); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyIntegerAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyIntegerRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            otherlv_4=(Token)match(input,53,FOLLOW_61); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getPropertyIntegerAccess().getEqualsSignKeyword_4());
              		
            }
            // InternalSM2.g:2501:3: ( (lv_inicialization_5_0= RULE_INTEGER ) )?
            int alt71=2;
            int LA71_0 = input.LA(1);

            if ( (LA71_0==RULE_INTEGER) ) {
                alt71=1;
            }
            switch (alt71) {
                case 1 :
                    // InternalSM2.g:2502:4: (lv_inicialization_5_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:2502:4: (lv_inicialization_5_0= RULE_INTEGER )
                    // InternalSM2.g:2503:5: lv_inicialization_5_0= RULE_INTEGER
                    {
                    lv_inicialization_5_0=(Token)match(input,RULE_INTEGER,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_inicialization_5_0, grammarAccess.getPropertyIntegerAccess().getInicializationINTEGERTerminalRuleCall_5_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getPropertyIntegerRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"inicialization",
                      						lv_inicialization_5_0,
                      						"org.xtext.SM2.INTEGER");
                      				
                    }

                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyIntegerAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:2523:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==RULE_EOLINE) ) {
                alt72=1;
            }
            switch (alt72) {
                case 1 :
                    // InternalSM2.g:2524:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyIntegerAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyInteger"


    // $ANTLR start "entryRulePropertyFloat"
    // InternalSM2.g:2533:1: entryRulePropertyFloat returns [EObject current=null] : iv_rulePropertyFloat= rulePropertyFloat EOF ;
    public final EObject entryRulePropertyFloat() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyFloat = null;


        try {
            // InternalSM2.g:2533:54: (iv_rulePropertyFloat= rulePropertyFloat EOF )
            // InternalSM2.g:2534:2: iv_rulePropertyFloat= rulePropertyFloat EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyFloatRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyFloat=rulePropertyFloat();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyFloat; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyFloat"


    // $ANTLR start "rulePropertyFloat"
    // InternalSM2.g:2540:1: rulePropertyFloat returns [EObject current=null] : (otherlv_0= 'float' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyFloat() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token lv_inicialization_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2546:2: ( (otherlv_0= 'float' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2547:2: (otherlv_0= 'float' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2547:2: (otherlv_0= 'float' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2548:3: otherlv_0= 'float' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_FLOAT ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,55,FOLLOW_59); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getPropertyFloatAccess().getFloatKeyword_0());
              		
            }
            // InternalSM2.g:2552:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt73=2;
            int LA73_0 = input.LA(1);

            if ( (LA73_0==RULE_INTEGER||(LA73_0>=58 && LA73_0<=59)) ) {
                alt73=1;
            }
            switch (alt73) {
                case 1 :
                    // InternalSM2.g:2553:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:2553:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:2554:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyFloatAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_38);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyFloatRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2571:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt74=2;
            int LA74_0 = input.LA(1);

            if ( ((LA74_0>=44 && LA74_0<=45)||(LA74_0>=90 && LA74_0<=91)) ) {
                alt74=1;
            }
            switch (alt74) {
                case 1 :
                    // InternalSM2.g:2572:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:2572:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:2573:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyFloatAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_12);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyFloatRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2590:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:2591:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:2591:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:2592:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_60); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyFloatAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyFloatRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            otherlv_4=(Token)match(input,53,FOLLOW_62); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getPropertyFloatAccess().getEqualsSignKeyword_4());
              		
            }
            // InternalSM2.g:2612:3: ( (lv_inicialization_5_0= RULE_FLOAT ) )?
            int alt75=2;
            int LA75_0 = input.LA(1);

            if ( (LA75_0==RULE_FLOAT) ) {
                alt75=1;
            }
            switch (alt75) {
                case 1 :
                    // InternalSM2.g:2613:4: (lv_inicialization_5_0= RULE_FLOAT )
                    {
                    // InternalSM2.g:2613:4: (lv_inicialization_5_0= RULE_FLOAT )
                    // InternalSM2.g:2614:5: lv_inicialization_5_0= RULE_FLOAT
                    {
                    lv_inicialization_5_0=(Token)match(input,RULE_FLOAT,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_inicialization_5_0, grammarAccess.getPropertyFloatAccess().getInicializationFLOATTerminalRuleCall_5_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getPropertyFloatRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"inicialization",
                      						lv_inicialization_5_0,
                      						"org.xtext.SM2.FLOAT");
                      				
                    }

                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyFloatAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:2634:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt76=2;
            int LA76_0 = input.LA(1);

            if ( (LA76_0==RULE_EOLINE) ) {
                alt76=1;
            }
            switch (alt76) {
                case 1 :
                    // InternalSM2.g:2635:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyFloatAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyFloat"


    // $ANTLR start "entryRulePropertyBoolean"
    // InternalSM2.g:2644:1: entryRulePropertyBoolean returns [EObject current=null] : iv_rulePropertyBoolean= rulePropertyBoolean EOF ;
    public final EObject entryRulePropertyBoolean() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyBoolean = null;


        try {
            // InternalSM2.g:2644:56: (iv_rulePropertyBoolean= rulePropertyBoolean EOF )
            // InternalSM2.g:2645:2: iv_rulePropertyBoolean= rulePropertyBoolean EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyBooleanRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyBoolean=rulePropertyBoolean();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyBoolean; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyBoolean"


    // $ANTLR start "rulePropertyBoolean"
    // InternalSM2.g:2651:1: rulePropertyBoolean returns [EObject current=null] : (otherlv_0= 'bool' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyBoolean() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token lv_inicialization_5_0=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2657:2: ( (otherlv_0= 'bool' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2658:2: (otherlv_0= 'bool' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2658:2: (otherlv_0= 'bool' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2659:3: otherlv_0= 'bool' ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= RULE_BOOLVALUE ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            otherlv_0=(Token)match(input,64,FOLLOW_59); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getPropertyBooleanAccess().getBoolKeyword_0());
              		
            }
            // InternalSM2.g:2663:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt77=2;
            int LA77_0 = input.LA(1);

            if ( (LA77_0==RULE_INTEGER||(LA77_0>=58 && LA77_0<=59)) ) {
                alt77=1;
            }
            switch (alt77) {
                case 1 :
                    // InternalSM2.g:2664:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:2664:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:2665:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBooleanAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_38);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBooleanRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2682:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt78=2;
            int LA78_0 = input.LA(1);

            if ( ((LA78_0>=44 && LA78_0<=45)||(LA78_0>=90 && LA78_0<=91)) ) {
                alt78=1;
            }
            switch (alt78) {
                case 1 :
                    // InternalSM2.g:2683:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:2683:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:2684:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBooleanAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_12);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBooleanRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2701:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:2702:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:2702:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:2703:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_60); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyBooleanAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyBooleanRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            otherlv_4=(Token)match(input,53,FOLLOW_63); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getPropertyBooleanAccess().getEqualsSignKeyword_4());
              		
            }
            // InternalSM2.g:2723:3: ( (lv_inicialization_5_0= RULE_BOOLVALUE ) )?
            int alt79=2;
            int LA79_0 = input.LA(1);

            if ( (LA79_0==RULE_BOOLVALUE) ) {
                alt79=1;
            }
            switch (alt79) {
                case 1 :
                    // InternalSM2.g:2724:4: (lv_inicialization_5_0= RULE_BOOLVALUE )
                    {
                    // InternalSM2.g:2724:4: (lv_inicialization_5_0= RULE_BOOLVALUE )
                    // InternalSM2.g:2725:5: lv_inicialization_5_0= RULE_BOOLVALUE
                    {
                    lv_inicialization_5_0=(Token)match(input,RULE_BOOLVALUE,FOLLOW_5); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_inicialization_5_0, grammarAccess.getPropertyBooleanAccess().getInicializationBOOLVALUETerminalRuleCall_5_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getPropertyBooleanRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"inicialization",
                      						lv_inicialization_5_0,
                      						"org.xtext.SM2.BOOLVALUE");
                      				
                    }

                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyBooleanAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:2745:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt80=2;
            int LA80_0 = input.LA(1);

            if ( (LA80_0==RULE_EOLINE) ) {
                alt80=1;
            }
            switch (alt80) {
                case 1 :
                    // InternalSM2.g:2746:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyBooleanAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyBoolean"


    // $ANTLR start "entryRulePropertyAddress"
    // InternalSM2.g:2755:1: entryRulePropertyAddress returns [EObject current=null] : iv_rulePropertyAddress= rulePropertyAddress EOF ;
    public final EObject entryRulePropertyAddress() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyAddress = null;


        try {
            // InternalSM2.g:2755:56: (iv_rulePropertyAddress= rulePropertyAddress EOF )
            // InternalSM2.g:2756:2: iv_rulePropertyAddress= rulePropertyAddress EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyAddressRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyAddress=rulePropertyAddress();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyAddress; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyAddress"


    // $ANTLR start "rulePropertyAddress"
    // InternalSM2.g:2762:1: rulePropertyAddress returns [EObject current=null] : ( ( ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyAddress() throws RecognitionException {
        EObject current = null;

        Token lv_option_0_1=null;
        Token lv_option_0_2=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;

        EObject lv_inicialization_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2768:2: ( ( ( ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2769:2: ( ( ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2769:2: ( ( ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2770:3: ( ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:2770:3: ( ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) ) )
            // InternalSM2.g:2771:4: ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) )
            {
            // InternalSM2.g:2771:4: ( (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' ) )
            // InternalSM2.g:2772:5: (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' )
            {
            // InternalSM2.g:2772:5: (lv_option_0_1= 'address' | lv_option_0_2= 'address payable' )
            int alt81=2;
            int LA81_0 = input.LA(1);

            if ( (LA81_0==52) ) {
                alt81=1;
            }
            else if ( (LA81_0==65) ) {
                alt81=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 81, 0, input);

                throw nvae;
            }
            switch (alt81) {
                case 1 :
                    // InternalSM2.g:2773:6: lv_option_0_1= 'address'
                    {
                    lv_option_0_1=(Token)match(input,52,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_1, grammarAccess.getPropertyAddressAccess().getOptionAddressKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyAddressRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2784:6: lv_option_0_2= 'address payable'
                    {
                    lv_option_0_2=(Token)match(input,65,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_2, grammarAccess.getPropertyAddressAccess().getOptionAddressPayableKeyword_0_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyAddressRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_2, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:2797:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt82=2;
            int LA82_0 = input.LA(1);

            if ( (LA82_0==RULE_INTEGER||(LA82_0>=58 && LA82_0<=59)) ) {
                alt82=1;
            }
            switch (alt82) {
                case 1 :
                    // InternalSM2.g:2798:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:2798:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:2799:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyAddressAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_38);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2816:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt83=2;
            int LA83_0 = input.LA(1);

            if ( ((LA83_0>=44 && LA83_0<=45)||(LA83_0>=90 && LA83_0<=91)) ) {
                alt83=1;
            }
            switch (alt83) {
                case 1 :
                    // InternalSM2.g:2817:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:2817:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:2818:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyAddressAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_12);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2835:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:2836:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:2836:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:2837:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_60); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyAddressAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyAddressRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            otherlv_4=(Token)match(input,53,FOLLOW_64); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getPropertyAddressAccess().getEqualsSignKeyword_4());
              		
            }
            // InternalSM2.g:2857:3: ( (lv_inicialization_5_0= ruleSyntaxExpression ) )?
            int alt84=2;
            int LA84_0 = input.LA(1);

            if ( (LA84_0==RULE_INTEGER||LA84_0==RULE_STRING||LA84_0==RULE_FLOAT) ) {
                alt84=1;
            }
            switch (alt84) {
                case 1 :
                    // InternalSM2.g:2858:4: (lv_inicialization_5_0= ruleSyntaxExpression )
                    {
                    // InternalSM2.g:2858:4: (lv_inicialization_5_0= ruleSyntaxExpression )
                    // InternalSM2.g:2859:5: lv_inicialization_5_0= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyAddressAccess().getInicializationSyntaxExpressionParserRuleCall_5_0());
                      				
                    }
                    pushFollow(FOLLOW_5);
                    lv_inicialization_5_0=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyAddressRule());
                      					}
                      					set(
                      						current,
                      						"inicialization",
                      						lv_inicialization_5_0,
                      						"org.xtext.SM2.SyntaxExpression");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyAddressAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:2880:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt85=2;
            int LA85_0 = input.LA(1);

            if ( (LA85_0==RULE_EOLINE) ) {
                alt85=1;
            }
            switch (alt85) {
                case 1 :
                    // InternalSM2.g:2881:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyAddressAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyAddress"


    // $ANTLR start "entryRulePropertyBytes"
    // InternalSM2.g:2890:1: entryRulePropertyBytes returns [EObject current=null] : iv_rulePropertyBytes= rulePropertyBytes EOF ;
    public final EObject entryRulePropertyBytes() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyBytes = null;


        try {
            // InternalSM2.g:2890:54: (iv_rulePropertyBytes= rulePropertyBytes EOF )
            // InternalSM2.g:2891:2: iv_rulePropertyBytes= rulePropertyBytes EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyBytesRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyBytes=rulePropertyBytes();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyBytes; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyBytes"


    // $ANTLR start "rulePropertyBytes"
    // InternalSM2.g:2897:1: rulePropertyBytes returns [EObject current=null] : ( ( ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyBytes() throws RecognitionException {
        EObject current = null;

        Token lv_option_0_1=null;
        Token lv_option_0_2=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;

        EObject lv_inicialization_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:2903:2: ( ( ( ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:2904:2: ( ( ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:2904:2: ( ( ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:2905:3: ( ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes32' ) ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:2905:3: ( ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes32' ) ) )
            // InternalSM2.g:2906:4: ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes32' ) )
            {
            // InternalSM2.g:2906:4: ( (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes32' ) )
            // InternalSM2.g:2907:5: (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes32' )
            {
            // InternalSM2.g:2907:5: (lv_option_0_1= 'bytes' | lv_option_0_2= 'bytes32' )
            int alt86=2;
            int LA86_0 = input.LA(1);

            if ( (LA86_0==66) ) {
                alt86=1;
            }
            else if ( (LA86_0==67) ) {
                alt86=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 86, 0, input);

                throw nvae;
            }
            switch (alt86) {
                case 1 :
                    // InternalSM2.g:2908:6: lv_option_0_1= 'bytes'
                    {
                    lv_option_0_1=(Token)match(input,66,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_1, grammarAccess.getPropertyBytesAccess().getOptionBytesKeyword_0_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_1, null);
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:2919:6: lv_option_0_2= 'bytes32'
                    {
                    lv_option_0_2=(Token)match(input,67,FOLLOW_59); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_option_0_2, grammarAccess.getPropertyBytesAccess().getOptionBytes32Keyword_0_0_1());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getPropertyBytesRule());
                      						}
                      						setWithLastConsumed(current, "option", lv_option_0_2, null);
                      					
                    }

                    }
                    break;

            }


            }


            }

            // InternalSM2.g:2932:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt87=2;
            int LA87_0 = input.LA(1);

            if ( (LA87_0==RULE_INTEGER||(LA87_0>=58 && LA87_0<=59)) ) {
                alt87=1;
            }
            switch (alt87) {
                case 1 :
                    // InternalSM2.g:2933:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:2933:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:2934:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBytesAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_38);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2951:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt88=2;
            int LA88_0 = input.LA(1);

            if ( ((LA88_0>=44 && LA88_0<=45)||(LA88_0>=90 && LA88_0<=91)) ) {
                alt88=1;
            }
            switch (alt88) {
                case 1 :
                    // InternalSM2.g:2952:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:2952:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:2953:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBytesAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_12);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:2970:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:2971:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:2971:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:2972:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_60); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyBytesAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyBytesRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            otherlv_4=(Token)match(input,53,FOLLOW_64); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getPropertyBytesAccess().getEqualsSignKeyword_4());
              		
            }
            // InternalSM2.g:2992:3: ( (lv_inicialization_5_0= ruleSyntaxExpression ) )?
            int alt89=2;
            int LA89_0 = input.LA(1);

            if ( (LA89_0==RULE_INTEGER||LA89_0==RULE_STRING||LA89_0==RULE_FLOAT) ) {
                alt89=1;
            }
            switch (alt89) {
                case 1 :
                    // InternalSM2.g:2993:4: (lv_inicialization_5_0= ruleSyntaxExpression )
                    {
                    // InternalSM2.g:2993:4: (lv_inicialization_5_0= ruleSyntaxExpression )
                    // InternalSM2.g:2994:5: lv_inicialization_5_0= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyBytesAccess().getInicializationSyntaxExpressionParserRuleCall_5_0());
                      				
                    }
                    pushFollow(FOLLOW_5);
                    lv_inicialization_5_0=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyBytesRule());
                      					}
                      					set(
                      						current,
                      						"inicialization",
                      						lv_inicialization_5_0,
                      						"org.xtext.SM2.SyntaxExpression");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyBytesAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:3015:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt90=2;
            int LA90_0 = input.LA(1);

            if ( (LA90_0==RULE_EOLINE) ) {
                alt90=1;
            }
            switch (alt90) {
                case 1 :
                    // InternalSM2.g:3016:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyBytesAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyBytes"


    // $ANTLR start "entryRulePropertyStruct"
    // InternalSM2.g:3025:1: entryRulePropertyStruct returns [EObject current=null] : iv_rulePropertyStruct= rulePropertyStruct EOF ;
    public final EObject entryRulePropertyStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePropertyStruct = null;


        try {
            // InternalSM2.g:3025:55: (iv_rulePropertyStruct= rulePropertyStruct EOF )
            // InternalSM2.g:3026:2: iv_rulePropertyStruct= rulePropertyStruct EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPropertyStructRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePropertyStruct=rulePropertyStruct();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePropertyStruct; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePropertyStruct"


    // $ANTLR start "rulePropertyStruct"
    // InternalSM2.g:3032:1: rulePropertyStruct returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) ;
    public final EObject rulePropertyStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameProperty_3_0=null;
        Token otherlv_4=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        AntlrDatatypeRuleToken lv_isArray_1_0 = null;

        Enumerator lv_visibility_2_0 = null;

        EObject lv_inicialization_5_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3038:2: ( ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? ) )
            // InternalSM2.g:3039:2: ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            {
            // InternalSM2.g:3039:2: ( ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )? )
            // InternalSM2.g:3040:3: ( (otherlv_0= RULE_ID ) ) ( (lv_isArray_1_0= ruleArray ) )? ( (lv_visibility_2_0= ruleVisibility ) )? ( (lv_nameProperty_3_0= RULE_ID ) ) otherlv_4= '=' ( (lv_inicialization_5_0= ruleSyntaxExpression ) )? this_SEMICOLON_6= RULE_SEMICOLON (this_EOLINE_7= RULE_EOLINE )?
            {
            // InternalSM2.g:3040:3: ( (otherlv_0= RULE_ID ) )
            // InternalSM2.g:3041:4: (otherlv_0= RULE_ID )
            {
            // InternalSM2.g:3041:4: (otherlv_0= RULE_ID )
            // InternalSM2.g:3042:5: otherlv_0= RULE_ID
            {
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyStructRule());
              					}
              				
            }
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_59); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(otherlv_0, grammarAccess.getPropertyStructAccess().getAssignedStructStructCrossReference_0_0());
              				
            }

            }


            }

            // InternalSM2.g:3053:3: ( (lv_isArray_1_0= ruleArray ) )?
            int alt91=2;
            int LA91_0 = input.LA(1);

            if ( (LA91_0==RULE_INTEGER||(LA91_0>=58 && LA91_0<=59)) ) {
                alt91=1;
            }
            switch (alt91) {
                case 1 :
                    // InternalSM2.g:3054:4: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3054:4: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3055:5: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyStructAccess().getIsArrayArrayParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_38);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyStructRule());
                      					}
                      					set(
                      						current,
                      						"isArray",
                      						lv_isArray_1_0,
                      						"org.xtext.SM2.Array");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3072:3: ( (lv_visibility_2_0= ruleVisibility ) )?
            int alt92=2;
            int LA92_0 = input.LA(1);

            if ( ((LA92_0>=44 && LA92_0<=45)||(LA92_0>=90 && LA92_0<=91)) ) {
                alt92=1;
            }
            switch (alt92) {
                case 1 :
                    // InternalSM2.g:3073:4: (lv_visibility_2_0= ruleVisibility )
                    {
                    // InternalSM2.g:3073:4: (lv_visibility_2_0= ruleVisibility )
                    // InternalSM2.g:3074:5: lv_visibility_2_0= ruleVisibility
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyStructAccess().getVisibilityVisibilityEnumRuleCall_2_0());
                      				
                    }
                    pushFollow(FOLLOW_12);
                    lv_visibility_2_0=ruleVisibility();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyStructRule());
                      					}
                      					set(
                      						current,
                      						"visibility",
                      						lv_visibility_2_0,
                      						"org.xtext.SM2.Visibility");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3091:3: ( (lv_nameProperty_3_0= RULE_ID ) )
            // InternalSM2.g:3092:4: (lv_nameProperty_3_0= RULE_ID )
            {
            // InternalSM2.g:3092:4: (lv_nameProperty_3_0= RULE_ID )
            // InternalSM2.g:3093:5: lv_nameProperty_3_0= RULE_ID
            {
            lv_nameProperty_3_0=(Token)match(input,RULE_ID,FOLLOW_60); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameProperty_3_0, grammarAccess.getPropertyStructAccess().getNamePropertyIDTerminalRuleCall_3_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getPropertyStructRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameProperty",
              						lv_nameProperty_3_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            otherlv_4=(Token)match(input,53,FOLLOW_64); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getPropertyStructAccess().getEqualsSignKeyword_4());
              		
            }
            // InternalSM2.g:3113:3: ( (lv_inicialization_5_0= ruleSyntaxExpression ) )?
            int alt93=2;
            int LA93_0 = input.LA(1);

            if ( (LA93_0==RULE_INTEGER||LA93_0==RULE_STRING||LA93_0==RULE_FLOAT) ) {
                alt93=1;
            }
            switch (alt93) {
                case 1 :
                    // InternalSM2.g:3114:4: (lv_inicialization_5_0= ruleSyntaxExpression )
                    {
                    // InternalSM2.g:3114:4: (lv_inicialization_5_0= ruleSyntaxExpression )
                    // InternalSM2.g:3115:5: lv_inicialization_5_0= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPropertyStructAccess().getInicializationSyntaxExpressionParserRuleCall_5_0());
                      				
                    }
                    pushFollow(FOLLOW_5);
                    lv_inicialization_5_0=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPropertyStructRule());
                      					}
                      					set(
                      						current,
                      						"inicialization",
                      						lv_inicialization_5_0,
                      						"org.xtext.SM2.SyntaxExpression");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getPropertyStructAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:3136:3: (this_EOLINE_7= RULE_EOLINE )?
            int alt94=2;
            int LA94_0 = input.LA(1);

            if ( (LA94_0==RULE_EOLINE) ) {
                alt94=1;
            }
            switch (alt94) {
                case 1 :
                    // InternalSM2.g:3137:4: this_EOLINE_7= RULE_EOLINE
                    {
                    this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_7, grammarAccess.getPropertyStructAccess().getEOLINETerminalRuleCall_7());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePropertyStruct"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:3146:1: entryRuleInputParam returns [EObject current=null] : iv_ruleInputParam= ruleInputParam EOF ;
    public final EObject entryRuleInputParam() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputParam = null;


        try {
            // InternalSM2.g:3146:51: (iv_ruleInputParam= ruleInputParam EOF )
            // InternalSM2.g:3147:2: iv_ruleInputParam= ruleInputParam EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getInputParamRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleInputParam=ruleInputParam();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleInputParam; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:3153:1: ruleInputParam returns [EObject current=null] : ( ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )? ) ;
    public final EObject ruleInputParam() throws RecognitionException {
        EObject current = null;

        Token lv_storage_2_0=null;
        Token otherlv_3=null;
        Token lv_nameParam_4_0=null;
        Token this_COMMA_5=null;
        Enumerator lv_type_0_0 = null;

        AntlrDatatypeRuleToken lv_isArray_1_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3159:2: ( ( ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )? ) )
            // InternalSM2.g:3160:2: ( ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )? )
            {
            // InternalSM2.g:3160:2: ( ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )? )
            // InternalSM2.g:3161:3: ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) ) (this_COMMA_5= RULE_COMMA )?
            {
            // InternalSM2.g:3161:3: ( ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) ) )
            // InternalSM2.g:3162:4: ( (lv_type_0_0= ruleBasicType ) ) ( (lv_isArray_1_0= ruleArray ) )? ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )? ( (lv_nameParam_4_0= RULE_ID ) )
            {
            // InternalSM2.g:3162:4: ( (lv_type_0_0= ruleBasicType ) )
            // InternalSM2.g:3163:5: (lv_type_0_0= ruleBasicType )
            {
            // InternalSM2.g:3163:5: (lv_type_0_0= ruleBasicType )
            // InternalSM2.g:3164:6: lv_type_0_0= ruleBasicType
            {
            if ( state.backtracking==0 ) {

              						newCompositeNode(grammarAccess.getInputParamAccess().getTypeBasicTypeEnumRuleCall_0_0_0());
              					
            }
            pushFollow(FOLLOW_65);
            lv_type_0_0=ruleBasicType();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElementForParent(grammarAccess.getInputParamRule());
              						}
              						set(
              							current,
              							"type",
              							lv_type_0_0,
              							"org.xtext.SM2.BasicType");
              						afterParserOrEnumRuleCall();
              					
            }

            }


            }

            // InternalSM2.g:3181:4: ( (lv_isArray_1_0= ruleArray ) )?
            int alt95=2;
            int LA95_0 = input.LA(1);

            if ( (LA95_0==RULE_INTEGER||(LA95_0>=58 && LA95_0<=59)) ) {
                alt95=1;
            }
            switch (alt95) {
                case 1 :
                    // InternalSM2.g:3182:5: (lv_isArray_1_0= ruleArray )
                    {
                    // InternalSM2.g:3182:5: (lv_isArray_1_0= ruleArray )
                    // InternalSM2.g:3183:6: lv_isArray_1_0= ruleArray
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getInputParamAccess().getIsArrayArrayParserRuleCall_0_1_0());
                      					
                    }
                    pushFollow(FOLLOW_66);
                    lv_isArray_1_0=ruleArray();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getInputParamRule());
                      						}
                      						set(
                      							current,
                      							"isArray",
                      							lv_isArray_1_0,
                      							"org.xtext.SM2.Array");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3200:4: ( ( (lv_storage_2_0= 'memory' ) ) | otherlv_3= 'local' )?
            int alt96=3;
            int LA96_0 = input.LA(1);

            if ( (LA96_0==68) ) {
                alt96=1;
            }
            else if ( (LA96_0==69) ) {
                alt96=2;
            }
            switch (alt96) {
                case 1 :
                    // InternalSM2.g:3201:5: ( (lv_storage_2_0= 'memory' ) )
                    {
                    // InternalSM2.g:3201:5: ( (lv_storage_2_0= 'memory' ) )
                    // InternalSM2.g:3202:6: (lv_storage_2_0= 'memory' )
                    {
                    // InternalSM2.g:3202:6: (lv_storage_2_0= 'memory' )
                    // InternalSM2.g:3203:7: lv_storage_2_0= 'memory'
                    {
                    lv_storage_2_0=(Token)match(input,68,FOLLOW_12); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							newLeafNode(lv_storage_2_0, grammarAccess.getInputParamAccess().getStorageMemoryKeyword_0_2_0_0());
                      						
                    }
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElement(grammarAccess.getInputParamRule());
                      							}
                      							setWithLastConsumed(current, "storage", lv_storage_2_0, "memory");
                      						
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3216:5: otherlv_3= 'local'
                    {
                    otherlv_3=(Token)match(input,69,FOLLOW_12); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_3, grammarAccess.getInputParamAccess().getLocalKeyword_0_2_1());
                      				
                    }

                    }
                    break;

            }

            // InternalSM2.g:3221:4: ( (lv_nameParam_4_0= RULE_ID ) )
            // InternalSM2.g:3222:5: (lv_nameParam_4_0= RULE_ID )
            {
            // InternalSM2.g:3222:5: (lv_nameParam_4_0= RULE_ID )
            // InternalSM2.g:3223:6: lv_nameParam_4_0= RULE_ID
            {
            lv_nameParam_4_0=(Token)match(input,RULE_ID,FOLLOW_67); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						newLeafNode(lv_nameParam_4_0, grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_3_0());
              					
            }
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElement(grammarAccess.getInputParamRule());
              						}
              						setWithLastConsumed(
              							current,
              							"nameParam",
              							lv_nameParam_4_0,
              							"org.eclipse.xtext.common.Terminals.ID");
              					
            }

            }


            }


            }

            // InternalSM2.g:3240:3: (this_COMMA_5= RULE_COMMA )?
            int alt97=2;
            int LA97_0 = input.LA(1);

            if ( (LA97_0==RULE_COMMA) ) {
                alt97=1;
            }
            switch (alt97) {
                case 1 :
                    // InternalSM2.g:3241:4: this_COMMA_5= RULE_COMMA
                    {
                    this_COMMA_5=(Token)match(input,RULE_COMMA,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_COMMA_5, grammarAccess.getInputParamAccess().getCOMMATerminalRuleCall_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:3250:1: entryRuleRestriction returns [EObject current=null] : iv_ruleRestriction= ruleRestriction EOF ;
    public final EObject entryRuleRestriction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestriction = null;


        try {
            // InternalSM2.g:3250:52: (iv_ruleRestriction= ruleRestriction EOF )
            // InternalSM2.g:3251:2: iv_ruleRestriction= ruleRestriction EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRestrictionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRestriction=ruleRestriction();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRestriction; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:3257:1: ruleRestriction returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) ;
    public final EObject ruleRestriction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_5=null;
        Token this_SEMICOLON_6=null;
        Token this_EOLINE_7=null;
        EObject lv_expr1_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        EObject lv_expr2_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3263:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE ) )
            // InternalSM2.g:3264:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            {
            // InternalSM2.g:3264:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE )
            // InternalSM2.g:3265:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr1_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr2_4_0= ruleSyntaxExpression ) ) this_CLOSEPARENTHESIS_5= RULE_CLOSEPARENTHESIS this_SEMICOLON_6= RULE_SEMICOLON this_EOLINE_7= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,70,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getRestrictionAccess().getRequireKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_68); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:3273:3: ( (lv_expr1_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:3274:4: (lv_expr1_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:3274:4: (lv_expr1_2_0= ruleSyntaxExpression )
            // InternalSM2.g:3275:5: lv_expr1_2_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr1SyntaxExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_69);
            lv_expr1_2_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"expr1",
              						lv_expr1_2_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3292:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:3293:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:3293:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:3294:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_68);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3311:3: ( (lv_expr2_4_0= ruleSyntaxExpression ) )
            // InternalSM2.g:3312:4: (lv_expr2_4_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:3312:4: (lv_expr2_4_0= ruleSyntaxExpression )
            // InternalSM2.g:3313:5: lv_expr2_4_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionAccess().getExpr2SyntaxExpressionParserRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_29);
            lv_expr2_4_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionRule());
              					}
              					set(
              						current,
              						"expr2",
              						lv_expr2_4_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_5=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_5, grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5());
              		
            }
            this_SEMICOLON_6=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_6, grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6());
              		
            }
            this_EOLINE_7=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_7, grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:3346:1: entryRuleRestrictionGas returns [EObject current=null] : iv_ruleRestrictionGas= ruleRestrictionGas EOF ;
    public final EObject entryRuleRestrictionGas() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionGas = null;


        try {
            // InternalSM2.g:3346:55: (iv_ruleRestrictionGas= ruleRestrictionGas EOF )
            // InternalSM2.g:3347:2: iv_ruleRestrictionGas= ruleRestrictionGas EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getRestrictionGasRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionGas=ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleRestrictionGas; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:3353:1: ruleRestrictionGas returns [EObject current=null] : (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE ) ;
    public final EObject ruleRestrictionGas() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token lv_amount_4_0=null;
        Token this_FLOAT_5=null;
        Token this_CLOSEPARENTHESIS_7=null;
        Token this_SEMICOLON_8=null;
        Token this_EOLINE_9=null;
        EObject lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        Enumerator lv_typeCoin_6_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3359:2: ( (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE ) )
            // InternalSM2.g:3360:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )
            {
            // InternalSM2.g:3360:2: (otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE )
            // InternalSM2.g:3361:3: otherlv_0= 'require' this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_typeCoin_6_0= ruleCoin ) ) this_CLOSEPARENTHESIS_7= RULE_CLOSEPARENTHESIS this_SEMICOLON_8= RULE_SEMICOLON this_EOLINE_9= RULE_EOLINE
            {
            otherlv_0=(Token)match(input,70,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getRestrictionGasAccess().getRequireKeyword_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_68); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:3369:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2.g:3370:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2.g:3370:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2.g:3371:5: lv_expr_2_0= ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_69);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_2_0,
              						"org.xtext.SM2.SyntaxExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3388:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2.g:3389:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2.g:3389:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2.g:3390:5: lv_operator_3_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_52);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_3_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3407:3: ( ( (lv_amount_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT )
            int alt98=2;
            int LA98_0 = input.LA(1);

            if ( (LA98_0==RULE_INTEGER) ) {
                alt98=1;
            }
            else if ( (LA98_0==RULE_FLOAT) ) {
                alt98=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 98, 0, input);

                throw nvae;
            }
            switch (alt98) {
                case 1 :
                    // InternalSM2.g:3408:4: ( (lv_amount_4_0= RULE_INTEGER ) )
                    {
                    // InternalSM2.g:3408:4: ( (lv_amount_4_0= RULE_INTEGER ) )
                    // InternalSM2.g:3409:5: (lv_amount_4_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:3409:5: (lv_amount_4_0= RULE_INTEGER )
                    // InternalSM2.g:3410:6: lv_amount_4_0= RULE_INTEGER
                    {
                    lv_amount_4_0=(Token)match(input,RULE_INTEGER,FOLLOW_70); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_amount_4_0, grammarAccess.getRestrictionGasAccess().getAmountINTEGERTerminalRuleCall_4_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getRestrictionGasRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"amount",
                      							lv_amount_4_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3427:4: this_FLOAT_5= RULE_FLOAT
                    {
                    this_FLOAT_5=(Token)match(input,RULE_FLOAT,FOLLOW_70); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_FLOAT_5, grammarAccess.getRestrictionGasAccess().getFLOATTerminalRuleCall_4_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:3432:3: ( (lv_typeCoin_6_0= ruleCoin ) )
            // InternalSM2.g:3433:4: (lv_typeCoin_6_0= ruleCoin )
            {
            // InternalSM2.g:3433:4: (lv_typeCoin_6_0= ruleCoin )
            // InternalSM2.g:3434:5: lv_typeCoin_6_0= ruleCoin
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0());
              				
            }
            pushFollow(FOLLOW_29);
            lv_typeCoin_6_0=ruleCoin();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
              					}
              					set(
              						current,
              						"typeCoin",
              						lv_typeCoin_6_0,
              						"org.xtext.SM2.Coin");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_7=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_7, grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }
            this_SEMICOLON_8=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_8, grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7());
              		
            }
            this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_9, grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleFunction"
    // InternalSM2.g:3467:1: entryRuleFunction returns [EObject current=null] : iv_ruleFunction= ruleFunction EOF ;
    public final EObject entryRuleFunction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFunction = null;


        try {
            // InternalSM2.g:3467:49: (iv_ruleFunction= ruleFunction EOF )
            // InternalSM2.g:3468:2: iv_ruleFunction= ruleFunction EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getFunctionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleFunction=ruleFunction();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleFunction; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFunction"


    // $ANTLR start "ruleFunction"
    // InternalSM2.g:3474:1: ruleFunction returns [EObject current=null] : (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions ) ;
    public final EObject ruleFunction() throws RecognitionException {
        EObject current = null;

        EObject this_PredefinedFunctions_0 = null;

        EObject this_PersonalizedFunctions_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:3480:2: ( (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions ) )
            // InternalSM2.g:3481:2: (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions )
            {
            // InternalSM2.g:3481:2: (this_PredefinedFunctions_0= rulePredefinedFunctions | this_PersonalizedFunctions_1= rulePersonalizedFunctions )
            int alt99=2;
            int LA99_0 = input.LA(1);

            if ( (LA99_0==72) ) {
                int LA99_1 = input.LA(2);

                if ( (LA99_1==RULE_ID) ) {
                    alt99=2;
                }
                else if ( (LA99_1==73) ) {
                    alt99=1;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return current;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 99, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 99, 0, input);

                throw nvae;
            }
            switch (alt99) {
                case 1 :
                    // InternalSM2.g:3482:3: this_PredefinedFunctions_0= rulePredefinedFunctions
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getFunctionAccess().getPredefinedFunctionsParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PredefinedFunctions_0=rulePredefinedFunctions();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PredefinedFunctions_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3491:3: this_PersonalizedFunctions_1= rulePersonalizedFunctions
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getFunctionAccess().getPersonalizedFunctionsParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_PersonalizedFunctions_1=rulePersonalizedFunctions();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_PersonalizedFunctions_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFunction"


    // $ANTLR start "entryRulePredefinedFunctions"
    // InternalSM2.g:3503:1: entryRulePredefinedFunctions returns [EObject current=null] : iv_rulePredefinedFunctions= rulePredefinedFunctions EOF ;
    public final EObject entryRulePredefinedFunctions() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePredefinedFunctions = null;


        try {
            // InternalSM2.g:3503:60: (iv_rulePredefinedFunctions= rulePredefinedFunctions EOF )
            // InternalSM2.g:3504:2: iv_rulePredefinedFunctions= rulePredefinedFunctions EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPredefinedFunctionsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePredefinedFunctions=rulePredefinedFunctions();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePredefinedFunctions; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePredefinedFunctions"


    // $ANTLR start "rulePredefinedFunctions"
    // InternalSM2.g:3510:1: rulePredefinedFunctions returns [EObject current=null] : this_Kill_0= ruleKill ;
    public final EObject rulePredefinedFunctions() throws RecognitionException {
        EObject current = null;

        EObject this_Kill_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3516:2: (this_Kill_0= ruleKill )
            // InternalSM2.g:3517:2: this_Kill_0= ruleKill
            {
            if ( state.backtracking==0 ) {

              		newCompositeNode(grammarAccess.getPredefinedFunctionsAccess().getKillParserRuleCall());
              	
            }
            pushFollow(FOLLOW_2);
            this_Kill_0=ruleKill();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              		current = this_Kill_0;
              		afterParserOrEnumRuleCall();
              	
            }

            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePredefinedFunctions"


    // $ANTLR start "entryRulePersonalizedFunctions"
    // InternalSM2.g:3528:1: entryRulePersonalizedFunctions returns [EObject current=null] : iv_rulePersonalizedFunctions= rulePersonalizedFunctions EOF ;
    public final EObject entryRulePersonalizedFunctions() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePersonalizedFunctions = null;


        try {
            // InternalSM2.g:3528:62: (iv_rulePersonalizedFunctions= rulePersonalizedFunctions EOF )
            // InternalSM2.g:3529:2: iv_rulePersonalizedFunctions= rulePersonalizedFunctions EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getPersonalizedFunctionsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_rulePersonalizedFunctions=rulePersonalizedFunctions();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_rulePersonalizedFunctions; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePersonalizedFunctions"


    // $ANTLR start "rulePersonalizedFunctions"
    // InternalSM2.g:3535:1: rulePersonalizedFunctions returns [EObject current=null] : (this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE ) ;
    public final EObject rulePersonalizedFunctions() throws RecognitionException {
        EObject current = null;

        Token lv_ispayable_1_0=null;
        Token this_OPENKEY_2=null;
        Token this_EOLINE_3=null;
        Token this_EOLINE_9=null;
        Token this_CLOSEKEY_10=null;
        Token this_EOLINE_11=null;
        EObject this_HeadClause_0 = null;

        EObject lv_restriction_4_0 = null;

        EObject lv_restrictionGas_5_0 = null;

        EObject lv_localAttributes_6_0 = null;

        EObject lv_conditions_7_0 = null;

        EObject lv_expression_8_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3541:2: ( (this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE ) )
            // InternalSM2.g:3542:2: (this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE )
            {
            // InternalSM2.g:3542:2: (this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE )
            // InternalSM2.g:3543:3: this_HeadClause_0= ruleHeadClause ( (lv_ispayable_1_0= 'payable' ) )? this_OPENKEY_2= RULE_OPENKEY this_EOLINE_3= RULE_EOLINE ( (lv_restriction_4_0= ruleRestriction ) )? ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )? ( (lv_localAttributes_6_0= ruleAttributes ) )? ( (lv_conditions_7_0= ruleConditional ) )? ( (lv_expression_8_0= ruleExpression ) )+ (this_EOLINE_9= RULE_EOLINE )? this_CLOSEKEY_10= RULE_CLOSEKEY this_EOLINE_11= RULE_EOLINE
            {
            if ( state.backtracking==0 ) {

              			newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getHeadClauseParserRuleCall_0());
              		
            }
            pushFollow(FOLLOW_71);
            this_HeadClause_0=ruleHeadClause();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			current = this_HeadClause_0;
              			afterParserOrEnumRuleCall();
              		
            }
            // InternalSM2.g:3551:3: ( (lv_ispayable_1_0= 'payable' ) )?
            int alt100=2;
            int LA100_0 = input.LA(1);

            if ( (LA100_0==71) ) {
                alt100=1;
            }
            switch (alt100) {
                case 1 :
                    // InternalSM2.g:3552:4: (lv_ispayable_1_0= 'payable' )
                    {
                    // InternalSM2.g:3552:4: (lv_ispayable_1_0= 'payable' )
                    // InternalSM2.g:3553:5: lv_ispayable_1_0= 'payable'
                    {
                    lv_ispayable_1_0=(Token)match(input,71,FOLLOW_15); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_ispayable_1_0, grammarAccess.getPersonalizedFunctionsAccess().getIspayablePayableKeyword_1_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					setWithLastConsumed(current, "ispayable", lv_ispayable_1_0, "payable");
                      				
                    }

                    }


                    }
                    break;

            }

            this_OPENKEY_2=(Token)match(input,RULE_OPENKEY,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_2, grammarAccess.getPersonalizedFunctionsAccess().getOPENKEYTerminalRuleCall_2());
              		
            }
            this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_72); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_3, grammarAccess.getPersonalizedFunctionsAccess().getEOLINETerminalRuleCall_3());
              		
            }
            // InternalSM2.g:3573:3: ( (lv_restriction_4_0= ruleRestriction ) )?
            int alt101=2;
            alt101 = dfa101.predict(input);
            switch (alt101) {
                case 1 :
                    // InternalSM2.g:3574:4: (lv_restriction_4_0= ruleRestriction )
                    {
                    // InternalSM2.g:3574:4: (lv_restriction_4_0= ruleRestriction )
                    // InternalSM2.g:3575:5: lv_restriction_4_0= ruleRestriction
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getRestrictionRestrictionParserRuleCall_4_0());
                      				
                    }
                    pushFollow(FOLLOW_72);
                    lv_restriction_4_0=ruleRestriction();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"restriction",
                      						lv_restriction_4_0,
                      						"org.xtext.SM2.Restriction");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3592:3: ( (lv_restrictionGas_5_0= ruleRestrictionGas ) )?
            int alt102=2;
            int LA102_0 = input.LA(1);

            if ( (LA102_0==70) ) {
                alt102=1;
            }
            switch (alt102) {
                case 1 :
                    // InternalSM2.g:3593:4: (lv_restrictionGas_5_0= ruleRestrictionGas )
                    {
                    // InternalSM2.g:3593:4: (lv_restrictionGas_5_0= ruleRestrictionGas )
                    // InternalSM2.g:3594:5: lv_restrictionGas_5_0= ruleRestrictionGas
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getRestrictionGasRestrictionGasParserRuleCall_5_0());
                      				
                    }
                    pushFollow(FOLLOW_73);
                    lv_restrictionGas_5_0=ruleRestrictionGas();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"restrictionGas",
                      						lv_restrictionGas_5_0,
                      						"org.xtext.SM2.RestrictionGas");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3611:3: ( (lv_localAttributes_6_0= ruleAttributes ) )?
            int alt103=2;
            int LA103_0 = input.LA(1);

            if ( (LA103_0==RULE_ID||LA103_0==49||(LA103_0>=51 && LA103_0<=52)||(LA103_0>=54 && LA103_0<=55)||LA103_0==57||(LA103_0>=61 && LA103_0<=67)) ) {
                alt103=1;
            }
            switch (alt103) {
                case 1 :
                    // InternalSM2.g:3612:4: (lv_localAttributes_6_0= ruleAttributes )
                    {
                    // InternalSM2.g:3612:4: (lv_localAttributes_6_0= ruleAttributes )
                    // InternalSM2.g:3613:5: lv_localAttributes_6_0= ruleAttributes
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getLocalAttributesAttributesParserRuleCall_6_0());
                      				
                    }
                    pushFollow(FOLLOW_32);
                    lv_localAttributes_6_0=ruleAttributes();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"localAttributes",
                      						lv_localAttributes_6_0,
                      						"org.xtext.SM2.Attributes");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3630:3: ( (lv_conditions_7_0= ruleConditional ) )?
            int alt104=2;
            int LA104_0 = input.LA(1);

            if ( (LA104_0==RULE_IF) ) {
                alt104=1;
            }
            switch (alt104) {
                case 1 :
                    // InternalSM2.g:3631:4: (lv_conditions_7_0= ruleConditional )
                    {
                    // InternalSM2.g:3631:4: (lv_conditions_7_0= ruleConditional )
                    // InternalSM2.g:3632:5: lv_conditions_7_0= ruleConditional
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getConditionsConditionalParserRuleCall_7_0());
                      				
                    }
                    pushFollow(FOLLOW_32);
                    lv_conditions_7_0=ruleConditional();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
                      					}
                      					add(
                      						current,
                      						"conditions",
                      						lv_conditions_7_0,
                      						"org.xtext.SM2.Conditional");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            // InternalSM2.g:3649:3: ( (lv_expression_8_0= ruleExpression ) )+
            int cnt105=0;
            loop105:
            do {
                int alt105=2;
                int LA105_0 = input.LA(1);

                if ( (LA105_0==RULE_INTEGER||LA105_0==RULE_OPENPARENTHESIS||LA105_0==RULE_STRING||LA105_0==RULE_FLOAT) ) {
                    alt105=1;
                }


                switch (alt105) {
            	case 1 :
            	    // InternalSM2.g:3650:4: (lv_expression_8_0= ruleExpression )
            	    {
            	    // InternalSM2.g:3650:4: (lv_expression_8_0= ruleExpression )
            	    // InternalSM2.g:3651:5: lv_expression_8_0= ruleExpression
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getPersonalizedFunctionsAccess().getExpressionExpressionParserRuleCall_8_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_74);
            	    lv_expression_8_0=ruleExpression();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getPersonalizedFunctionsRule());
            	      					}
            	      					add(
            	      						current,
            	      						"expression",
            	      						lv_expression_8_0,
            	      						"org.xtext.SM2.Expression");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt105 >= 1 ) break loop105;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(105, input);
                        throw eee;
                }
                cnt105++;
            } while (true);

            // InternalSM2.g:3668:3: (this_EOLINE_9= RULE_EOLINE )?
            int alt106=2;
            int LA106_0 = input.LA(1);

            if ( (LA106_0==RULE_EOLINE) ) {
                alt106=1;
            }
            switch (alt106) {
                case 1 :
                    // InternalSM2.g:3669:4: this_EOLINE_9= RULE_EOLINE
                    {
                    this_EOLINE_9=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_9, grammarAccess.getPersonalizedFunctionsAccess().getEOLINETerminalRuleCall_9());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_10=(Token)match(input,RULE_CLOSEKEY,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_10, grammarAccess.getPersonalizedFunctionsAccess().getCLOSEKEYTerminalRuleCall_10());
              		
            }
            this_EOLINE_11=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_EOLINE_11, grammarAccess.getPersonalizedFunctionsAccess().getEOLINETerminalRuleCall_11());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePersonalizedFunctions"


    // $ANTLR start "entryRuleHeadClause"
    // InternalSM2.g:3686:1: entryRuleHeadClause returns [EObject current=null] : iv_ruleHeadClause= ruleHeadClause EOF ;
    public final EObject entryRuleHeadClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleHeadClause = null;


        try {
            // InternalSM2.g:3686:51: (iv_ruleHeadClause= ruleHeadClause EOF )
            // InternalSM2.g:3687:2: iv_ruleHeadClause= ruleHeadClause EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getHeadClauseRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleHeadClause=ruleHeadClause();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleHeadClause; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleHeadClause"


    // $ANTLR start "ruleHeadClause"
    // InternalSM2.g:3693:1: ruleHeadClause returns [EObject current=null] : (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) ;
    public final EObject ruleHeadClause() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameFunction_1_0=null;
        Token this_OPENPARENTHESIS_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Enumerator lv_visibilityAccess_4_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:3699:2: ( (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:3700:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:3700:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:3701:3: otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (otherlv_3= RULE_ID ) )* ( (lv_visibilityAccess_4_0= ruleVisibility ) ) ( (otherlv_5= RULE_ID ) )? this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS
            {
            otherlv_0=(Token)match(input,72,FOLLOW_12); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getHeadClauseAccess().getFunctionKeyword_0());
              		
            }
            // InternalSM2.g:3705:3: ( (lv_nameFunction_1_0= RULE_ID ) )
            // InternalSM2.g:3706:4: (lv_nameFunction_1_0= RULE_ID )
            {
            // InternalSM2.g:3706:4: (lv_nameFunction_1_0= RULE_ID )
            // InternalSM2.g:3707:5: lv_nameFunction_1_0= RULE_ID
            {
            lv_nameFunction_1_0=(Token)match(input,RULE_ID,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_nameFunction_1_0, grammarAccess.getHeadClauseAccess().getNameFunctionIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getHeadClauseRule());
              					}
              					setWithLastConsumed(
              						current,
              						"nameFunction",
              						lv_nameFunction_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_38); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getHeadClauseAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:3727:3: ( (otherlv_3= RULE_ID ) )*
            loop107:
            do {
                int alt107=2;
                int LA107_0 = input.LA(1);

                if ( (LA107_0==RULE_ID) ) {
                    alt107=1;
                }


                switch (alt107) {
            	case 1 :
            	    // InternalSM2.g:3728:4: (otherlv_3= RULE_ID )
            	    {
            	    // InternalSM2.g:3728:4: (otherlv_3= RULE_ID )
            	    // InternalSM2.g:3729:5: otherlv_3= RULE_ID
            	    {
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElement(grammarAccess.getHeadClauseRule());
            	      					}
            	      				
            	    }
            	    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_38); if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					newLeafNode(otherlv_3, grammarAccess.getHeadClauseAccess().getInputParamsInputParamCrossReference_3_0());
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop107;
                }
            } while (true);

            // InternalSM2.g:3740:3: ( (lv_visibilityAccess_4_0= ruleVisibility ) )
            // InternalSM2.g:3741:4: (lv_visibilityAccess_4_0= ruleVisibility )
            {
            // InternalSM2.g:3741:4: (lv_visibilityAccess_4_0= ruleVisibility )
            // InternalSM2.g:3742:5: lv_visibilityAccess_4_0= ruleVisibility
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getHeadClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_75);
            lv_visibilityAccess_4_0=ruleVisibility();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getHeadClauseRule());
              					}
              					set(
              						current,
              						"visibilityAccess",
              						lv_visibilityAccess_4_0,
              						"org.xtext.SM2.Visibility");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:3759:3: ( (otherlv_5= RULE_ID ) )?
            int alt108=2;
            int LA108_0 = input.LA(1);

            if ( (LA108_0==RULE_ID) ) {
                alt108=1;
            }
            switch (alt108) {
                case 1 :
                    // InternalSM2.g:3760:4: (otherlv_5= RULE_ID )
                    {
                    // InternalSM2.g:3760:4: (otherlv_5= RULE_ID )
                    // InternalSM2.g:3761:5: otherlv_5= RULE_ID
                    {
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getHeadClauseRule());
                      					}
                      				
                    }
                    otherlv_5=(Token)match(input,RULE_ID,FOLLOW_29); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_5, grammarAccess.getHeadClauseAccess().getModifierModifierCrossReference_5_0());
                      				
                    }

                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getHeadClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleHeadClause"


    // $ANTLR start "entryRuleKill"
    // InternalSM2.g:3780:1: entryRuleKill returns [EObject current=null] : iv_ruleKill= ruleKill EOF ;
    public final EObject entryRuleKill() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleKill = null;


        try {
            // InternalSM2.g:3780:45: (iv_ruleKill= ruleKill EOF )
            // InternalSM2.g:3781:2: iv_ruleKill= ruleKill EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getKillRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleKill=ruleKill();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleKill; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleKill"


    // $ANTLR start "ruleKill"
    // InternalSM2.g:3787:1: ruleKill returns [EObject current=null] : (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParam_3_0= ruleInputParam ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY ) ;
    public final EObject ruleKill() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token this_OPENPARENTHESIS_2=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_IF_6=null;
        Token this_OPENPARENTHESIS_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token this_CLOSEPARENTHESIS_12=null;
        Token otherlv_13=null;
        Token this_OPENPARENTHESIS_14=null;
        Token this_CLOSEPARENTHESIS_16=null;
        Token this_SEMICOLON_17=null;
        Token this_EOLINE_18=null;
        Token this_CLOSEKEY_19=null;
        EObject lv_inputParam_3_0 = null;

        EObject lv_addressValueCondition_10_0 = null;

        EObject this_InputParam_11 = null;

        EObject lv_addressValue_15_1 = null;

        EObject lv_addressValue_15_2 = null;



        	enterRule();

        try {
            // InternalSM2.g:3793:2: ( (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParam_3_0= ruleInputParam ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY ) )
            // InternalSM2.g:3794:2: (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParam_3_0= ruleInputParam ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY )
            {
            // InternalSM2.g:3794:2: (otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParam_3_0= ruleInputParam ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY )
            // InternalSM2.g:3795:3: otherlv_0= 'function' otherlv_1= 'kill' this_OPENPARENTHESIS_2= RULE_OPENPARENTHESIS ( (lv_inputParam_3_0= ruleInputParam ) )? this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY this_IF_6= RULE_IF this_OPENPARENTHESIS_7= RULE_OPENPARENTHESIS otherlv_8= 'msg.sender' otherlv_9= '==' ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam ) this_CLOSEPARENTHESIS_12= RULE_CLOSEPARENTHESIS otherlv_13= 'selfdestruct' this_OPENPARENTHESIS_14= RULE_OPENPARENTHESIS ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) ) this_CLOSEPARENTHESIS_16= RULE_CLOSEPARENTHESIS this_SEMICOLON_17= RULE_SEMICOLON (this_EOLINE_18= RULE_EOLINE )? this_CLOSEKEY_19= RULE_CLOSEKEY
            {
            otherlv_0=(Token)match(input,72,FOLLOW_76); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getKillAccess().getFunctionKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,73,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getKillAccess().getKillKeyword_1());
              		
            }
            this_OPENPARENTHESIS_2=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_31); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_2, grammarAccess.getKillAccess().getOPENPARENTHESISTerminalRuleCall_2());
              		
            }
            // InternalSM2.g:3807:3: ( (lv_inputParam_3_0= ruleInputParam ) )?
            int alt109=2;
            int LA109_0 = input.LA(1);

            if ( (LA109_0==52||LA109_0==54||(LA109_0>=61 && LA109_0<=65)||LA109_0==67||(LA109_0>=81 && LA109_0<=83)) ) {
                alt109=1;
            }
            switch (alt109) {
                case 1 :
                    // InternalSM2.g:3808:4: (lv_inputParam_3_0= ruleInputParam )
                    {
                    // InternalSM2.g:3808:4: (lv_inputParam_3_0= ruleInputParam )
                    // InternalSM2.g:3809:5: lv_inputParam_3_0= ruleInputParam
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getKillAccess().getInputParamInputParamParserRuleCall_3_0());
                      				
                    }
                    pushFollow(FOLLOW_29);
                    lv_inputParam_3_0=ruleInputParam();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getKillRule());
                      					}
                      					set(
                      						current,
                      						"inputParam",
                      						lv_inputParam_3_0,
                      						"org.xtext.SM2.InputParam");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getKillAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_77); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getKillAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            this_IF_6=(Token)match(input,RULE_IF,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_IF_6, grammarAccess.getKillAccess().getIFTerminalRuleCall_6());
              		
            }
            this_OPENPARENTHESIS_7=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_78); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_7, grammarAccess.getKillAccess().getOPENPARENTHESISTerminalRuleCall_7());
              		
            }
            otherlv_8=(Token)match(input,74,FOLLOW_79); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_8, grammarAccess.getKillAccess().getMsgSenderKeyword_8());
              		
            }
            otherlv_9=(Token)match(input,75,FOLLOW_80); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_9, grammarAccess.getKillAccess().getEqualsSignEqualsSignKeyword_9());
              		
            }
            // InternalSM2.g:3850:3: ( ( (lv_addressValueCondition_10_0= ruleExpression ) ) | this_InputParam_11= ruleInputParam )
            int alt110=2;
            int LA110_0 = input.LA(1);

            if ( (LA110_0==RULE_INTEGER||LA110_0==RULE_OPENPARENTHESIS||LA110_0==RULE_STRING||LA110_0==RULE_FLOAT) ) {
                alt110=1;
            }
            else if ( (LA110_0==52||LA110_0==54||(LA110_0>=61 && LA110_0<=65)||LA110_0==67||(LA110_0>=81 && LA110_0<=83)) ) {
                alt110=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 110, 0, input);

                throw nvae;
            }
            switch (alt110) {
                case 1 :
                    // InternalSM2.g:3851:4: ( (lv_addressValueCondition_10_0= ruleExpression ) )
                    {
                    // InternalSM2.g:3851:4: ( (lv_addressValueCondition_10_0= ruleExpression ) )
                    // InternalSM2.g:3852:5: (lv_addressValueCondition_10_0= ruleExpression )
                    {
                    // InternalSM2.g:3852:5: (lv_addressValueCondition_10_0= ruleExpression )
                    // InternalSM2.g:3853:6: lv_addressValueCondition_10_0= ruleExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getKillAccess().getAddressValueConditionExpressionParserRuleCall_10_0_0());
                      					
                    }
                    pushFollow(FOLLOW_29);
                    lv_addressValueCondition_10_0=ruleExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getKillRule());
                      						}
                      						set(
                      							current,
                      							"addressValueCondition",
                      							lv_addressValueCondition_10_0,
                      							"org.xtext.SM2.Expression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:3871:4: this_InputParam_11= ruleInputParam
                    {
                    if ( state.backtracking==0 ) {

                      				newCompositeNode(grammarAccess.getKillAccess().getInputParamParserRuleCall_10_1());
                      			
                    }
                    pushFollow(FOLLOW_29);
                    this_InputParam_11=ruleInputParam();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = this_InputParam_11;
                      				afterParserOrEnumRuleCall();
                      			
                    }

                    }
                    break;

            }

            this_CLOSEPARENTHESIS_12=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_81); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_12, grammarAccess.getKillAccess().getCLOSEPARENTHESISTerminalRuleCall_11());
              		
            }
            otherlv_13=(Token)match(input,76,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_13, grammarAccess.getKillAccess().getSelfdestructKeyword_12());
              		
            }
            this_OPENPARENTHESIS_14=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_80); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_14, grammarAccess.getKillAccess().getOPENPARENTHESISTerminalRuleCall_13());
              		
            }
            // InternalSM2.g:3892:3: ( ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) ) )
            // InternalSM2.g:3893:4: ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) )
            {
            // InternalSM2.g:3893:4: ( (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam ) )
            // InternalSM2.g:3894:5: (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam )
            {
            // InternalSM2.g:3894:5: (lv_addressValue_15_1= ruleExpression | lv_addressValue_15_2= ruleInputParam )
            int alt111=2;
            int LA111_0 = input.LA(1);

            if ( (LA111_0==RULE_INTEGER||LA111_0==RULE_OPENPARENTHESIS||LA111_0==RULE_STRING||LA111_0==RULE_FLOAT) ) {
                alt111=1;
            }
            else if ( (LA111_0==52||LA111_0==54||(LA111_0>=61 && LA111_0<=65)||LA111_0==67||(LA111_0>=81 && LA111_0<=83)) ) {
                alt111=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 111, 0, input);

                throw nvae;
            }
            switch (alt111) {
                case 1 :
                    // InternalSM2.g:3895:6: lv_addressValue_15_1= ruleExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getKillAccess().getAddressValueExpressionParserRuleCall_14_0_0());
                      					
                    }
                    pushFollow(FOLLOW_29);
                    lv_addressValue_15_1=ruleExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getKillRule());
                      						}
                      						set(
                      							current,
                      							"addressValue",
                      							lv_addressValue_15_1,
                      							"org.xtext.SM2.Expression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3911:6: lv_addressValue_15_2= ruleInputParam
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getKillAccess().getAddressValueInputParamParserRuleCall_14_0_1());
                      					
                    }
                    pushFollow(FOLLOW_29);
                    lv_addressValue_15_2=ruleInputParam();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getKillRule());
                      						}
                      						set(
                      							current,
                      							"addressValue",
                      							lv_addressValue_15_2,
                      							"org.xtext.SM2.InputParam");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }
                    break;

            }


            }


            }

            this_CLOSEPARENTHESIS_16=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_16, grammarAccess.getKillAccess().getCLOSEPARENTHESISTerminalRuleCall_15());
              		
            }
            this_SEMICOLON_17=(Token)match(input,RULE_SEMICOLON,FOLLOW_53); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_SEMICOLON_17, grammarAccess.getKillAccess().getSEMICOLONTerminalRuleCall_16());
              		
            }
            // InternalSM2.g:3937:3: (this_EOLINE_18= RULE_EOLINE )?
            int alt112=2;
            int LA112_0 = input.LA(1);

            if ( (LA112_0==RULE_EOLINE) ) {
                alt112=1;
            }
            switch (alt112) {
                case 1 :
                    // InternalSM2.g:3938:4: this_EOLINE_18= RULE_EOLINE
                    {
                    this_EOLINE_18=(Token)match(input,RULE_EOLINE,FOLLOW_7); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_18, grammarAccess.getKillAccess().getEOLINETerminalRuleCall_17());
                      			
                    }

                    }
                    break;

            }

            this_CLOSEKEY_19=(Token)match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_19, grammarAccess.getKillAccess().getCLOSEKEYTerminalRuleCall_18());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleKill"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:3951:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // InternalSM2.g:3951:51: (iv_ruleExpression= ruleExpression EOF )
            // InternalSM2.g:3952:2: iv_ruleExpression= ruleExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:3958:1: ruleExpression returns [EObject current=null] : (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression ) ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_ArithmethicalExpression_0 = null;

        EObject this_ArithmethicalLogicalExpression_1 = null;

        EObject this_SyntaxExpression_2 = null;

        EObject this_TimeExpression_3 = null;



        	enterRule();

        try {
            // InternalSM2.g:3964:2: ( (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression ) )
            // InternalSM2.g:3965:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression )
            {
            // InternalSM2.g:3965:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression )
            int alt113=4;
            alt113 = dfa113.predict(input);
            switch (alt113) {
                case 1 :
                    // InternalSM2.g:3966:3: this_ArithmethicalExpression_0= ruleArithmethicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalExpression_0=ruleArithmethicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ArithmethicalExpression_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:3975:3: this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalLogicalExpressionParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalLogicalExpression_1=ruleArithmethicalLogicalExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ArithmethicalLogicalExpression_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalSM2.g:3984:3: this_SyntaxExpression_2= ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_SyntaxExpression_2=ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_SyntaxExpression_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 4 :
                    // InternalSM2.g:3993:3: this_TimeExpression_3= ruleTimeExpression
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getExpressionAccess().getTimeExpressionParserRuleCall_3());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_TimeExpression_3=ruleTimeExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_TimeExpression_3;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleArithmethicalExpression"
    // InternalSM2.g:4005:1: entryRuleArithmethicalExpression returns [EObject current=null] : iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF ;
    public final EObject entryRuleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalExpression = null;


        try {
            // InternalSM2.g:4005:64: (iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF )
            // InternalSM2.g:4006:2: iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmethicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalExpression=ruleArithmethicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArithmethicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalExpression"


    // $ANTLR start "ruleArithmethicalExpression"
    // InternalSM2.g:4012:1: ruleArithmethicalExpression returns [EObject current=null] : ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT ) ( (lv_operator_9_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? ) ) ;
    public final EObject ruleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token lv_op1_1_0=null;
        Token this_FLOAT_2=null;
        Token lv_op2_4_0=null;
        Token this_FLOAT_5=null;
        Token this_CLOSEPARENTHESIS_6=null;
        Token lv_op1_7_0=null;
        Token this_FLOAT_8=null;
        Token lv_op2_10_0=null;
        Token this_FLOAT_11=null;
        Token this_SEMICOLON_12=null;
        Token this_EOLINE_13=null;
        Enumerator lv_operator_3_0 = null;

        Enumerator lv_operator_9_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4018:2: ( ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT ) ( (lv_operator_9_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? ) ) )
            // InternalSM2.g:4019:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT ) ( (lv_operator_9_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:4019:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS ) | ( ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT ) ( (lv_operator_9_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? ) )
            int alt119=2;
            int LA119_0 = input.LA(1);

            if ( (LA119_0==RULE_OPENPARENTHESIS) ) {
                alt119=1;
            }
            else if ( (LA119_0==RULE_INTEGER||LA119_0==RULE_FLOAT) ) {
                alt119=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 119, 0, input);

                throw nvae;
            }
            switch (alt119) {
                case 1 :
                    // InternalSM2.g:4020:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                    {
                    // InternalSM2.g:4020:3: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS )
                    // InternalSM2.g:4021:4: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) this_CLOSEPARENTHESIS_6= RULE_CLOSEPARENTHESIS
                    {
                    this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_52); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0());
                      			
                    }
                    // InternalSM2.g:4025:4: ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT )
                    int alt114=2;
                    int LA114_0 = input.LA(1);

                    if ( (LA114_0==RULE_INTEGER) ) {
                        alt114=1;
                    }
                    else if ( (LA114_0==RULE_FLOAT) ) {
                        alt114=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 114, 0, input);

                        throw nvae;
                    }
                    switch (alt114) {
                        case 1 :
                            // InternalSM2.g:4026:5: ( (lv_op1_1_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4026:5: ( (lv_op1_1_0= RULE_INTEGER ) )
                            // InternalSM2.g:4027:6: (lv_op1_1_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4027:6: (lv_op1_1_0= RULE_INTEGER )
                            // InternalSM2.g:4028:7: lv_op1_1_0= RULE_INTEGER
                            {
                            lv_op1_1_0=(Token)match(input,RULE_INTEGER,FOLLOW_82); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op1_1_0, grammarAccess.getArithmethicalExpressionAccess().getOp1INTEGERTerminalRuleCall_0_1_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op1",
                              								lv_op1_1_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4045:5: this_FLOAT_2= RULE_FLOAT
                            {
                            this_FLOAT_2=(Token)match(input,RULE_FLOAT,FOLLOW_82); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_2, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_0_1_1());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:4050:4: ( (lv_operator_3_0= ruleArithmeticalOperator ) )
                    // InternalSM2.g:4051:5: (lv_operator_3_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2.g:4051:5: (lv_operator_3_0= ruleArithmeticalOperator )
                    // InternalSM2.g:4052:6: lv_operator_3_0= ruleArithmeticalOperator
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0());
                      					
                    }
                    pushFollow(FOLLOW_52);
                    lv_operator_3_0=ruleArithmeticalOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"operator",
                      							lv_operator_3_0,
                      							"org.xtext.SM2.ArithmeticalOperator");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:4069:4: ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT )
                    int alt115=2;
                    int LA115_0 = input.LA(1);

                    if ( (LA115_0==RULE_INTEGER) ) {
                        alt115=1;
                    }
                    else if ( (LA115_0==RULE_FLOAT) ) {
                        alt115=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 115, 0, input);

                        throw nvae;
                    }
                    switch (alt115) {
                        case 1 :
                            // InternalSM2.g:4070:5: ( (lv_op2_4_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4070:5: ( (lv_op2_4_0= RULE_INTEGER ) )
                            // InternalSM2.g:4071:6: (lv_op2_4_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4071:6: (lv_op2_4_0= RULE_INTEGER )
                            // InternalSM2.g:4072:7: lv_op2_4_0= RULE_INTEGER
                            {
                            lv_op2_4_0=(Token)match(input,RULE_INTEGER,FOLLOW_29); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op2_4_0, grammarAccess.getArithmethicalExpressionAccess().getOp2INTEGERTerminalRuleCall_0_3_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op2",
                              								lv_op2_4_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4089:5: this_FLOAT_5= RULE_FLOAT
                            {
                            this_FLOAT_5=(Token)match(input,RULE_FLOAT,FOLLOW_29); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_5, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_0_3_1());
                              				
                            }

                            }
                            break;

                    }

                    this_CLOSEPARENTHESIS_6=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_CLOSEPARENTHESIS_6, grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4100:3: ( ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT ) ( (lv_operator_9_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:4100:3: ( ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT ) ( (lv_operator_9_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )? )
                    // InternalSM2.g:4101:4: ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT ) ( (lv_operator_9_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT ) (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )?
                    {
                    // InternalSM2.g:4101:4: ( ( (lv_op1_7_0= RULE_INTEGER ) ) | this_FLOAT_8= RULE_FLOAT )
                    int alt116=2;
                    int LA116_0 = input.LA(1);

                    if ( (LA116_0==RULE_INTEGER) ) {
                        alt116=1;
                    }
                    else if ( (LA116_0==RULE_FLOAT) ) {
                        alt116=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 116, 0, input);

                        throw nvae;
                    }
                    switch (alt116) {
                        case 1 :
                            // InternalSM2.g:4102:5: ( (lv_op1_7_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4102:5: ( (lv_op1_7_0= RULE_INTEGER ) )
                            // InternalSM2.g:4103:6: (lv_op1_7_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4103:6: (lv_op1_7_0= RULE_INTEGER )
                            // InternalSM2.g:4104:7: lv_op1_7_0= RULE_INTEGER
                            {
                            lv_op1_7_0=(Token)match(input,RULE_INTEGER,FOLLOW_82); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op1_7_0, grammarAccess.getArithmethicalExpressionAccess().getOp1INTEGERTerminalRuleCall_1_0_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op1",
                              								lv_op1_7_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4121:5: this_FLOAT_8= RULE_FLOAT
                            {
                            this_FLOAT_8=(Token)match(input,RULE_FLOAT,FOLLOW_82); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_8, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_1_0_1());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:4126:4: ( (lv_operator_9_0= ruleArithmeticalOperator ) )
                    // InternalSM2.g:4127:5: (lv_operator_9_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2.g:4127:5: (lv_operator_9_0= ruleArithmeticalOperator )
                    // InternalSM2.g:4128:6: lv_operator_9_0= ruleArithmeticalOperator
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_52);
                    lv_operator_9_0=ruleArithmeticalOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                      						}
                      						set(
                      							current,
                      							"operator",
                      							lv_operator_9_0,
                      							"org.xtext.SM2.ArithmeticalOperator");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }

                    // InternalSM2.g:4145:4: ( ( (lv_op2_10_0= RULE_INTEGER ) ) | this_FLOAT_11= RULE_FLOAT )
                    int alt117=2;
                    int LA117_0 = input.LA(1);

                    if ( (LA117_0==RULE_INTEGER) ) {
                        alt117=1;
                    }
                    else if ( (LA117_0==RULE_FLOAT) ) {
                        alt117=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 117, 0, input);

                        throw nvae;
                    }
                    switch (alt117) {
                        case 1 :
                            // InternalSM2.g:4146:5: ( (lv_op2_10_0= RULE_INTEGER ) )
                            {
                            // InternalSM2.g:4146:5: ( (lv_op2_10_0= RULE_INTEGER ) )
                            // InternalSM2.g:4147:6: (lv_op2_10_0= RULE_INTEGER )
                            {
                            // InternalSM2.g:4147:6: (lv_op2_10_0= RULE_INTEGER )
                            // InternalSM2.g:4148:7: lv_op2_10_0= RULE_INTEGER
                            {
                            lv_op2_10_0=(Token)match(input,RULE_INTEGER,FOLLOW_83); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              							newLeafNode(lv_op2_10_0, grammarAccess.getArithmethicalExpressionAccess().getOp2INTEGERTerminalRuleCall_1_2_0_0());
                              						
                            }
                            if ( state.backtracking==0 ) {

                              							if (current==null) {
                              								current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                              							}
                              							setWithLastConsumed(
                              								current,
                              								"op2",
                              								lv_op2_10_0,
                              								"org.xtext.SM2.INTEGER");
                              						
                            }

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4165:5: this_FLOAT_11= RULE_FLOAT
                            {
                            this_FLOAT_11=(Token)match(input,RULE_FLOAT,FOLLOW_83); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_11, grammarAccess.getArithmethicalExpressionAccess().getFLOATTerminalRuleCall_1_2_1());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:4170:4: (this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE )?
                    int alt118=2;
                    int LA118_0 = input.LA(1);

                    if ( (LA118_0==RULE_SEMICOLON) ) {
                        int LA118_1 = input.LA(2);

                        if ( (LA118_1==RULE_EOLINE) ) {
                            int LA118_3 = input.LA(3);

                            if ( (LA118_3==EOF||(LA118_3>=RULE_SEMICOLON && LA118_3<=RULE_CLOSEKEY)||LA118_3==RULE_INTEGER||(LA118_3>=RULE_OPENPARENTHESIS && LA118_3<=RULE_STRING)||LA118_3==RULE_FLOAT) ) {
                                alt118=1;
                            }
                        }
                    }
                    switch (alt118) {
                        case 1 :
                            // InternalSM2.g:4171:5: this_SEMICOLON_12= RULE_SEMICOLON this_EOLINE_13= RULE_EOLINE
                            {
                            this_SEMICOLON_12=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_12, grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0());
                              				
                            }
                            this_EOLINE_13=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_13, grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalExpression"


    // $ANTLR start "entryRuleArithmethicalLogicalExpression"
    // InternalSM2.g:4185:1: entryRuleArithmethicalLogicalExpression returns [EObject current=null] : iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF ;
    public final EObject entryRuleArithmethicalLogicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalLogicalExpression = null;


        try {
            // InternalSM2.g:4185:71: (iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF )
            // InternalSM2.g:4186:2: iv_ruleArithmethicalLogicalExpression= ruleArithmethicalLogicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalLogicalExpression=ruleArithmethicalLogicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleArithmethicalLogicalExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalLogicalExpression"


    // $ANTLR start "ruleArithmethicalLogicalExpression"
    // InternalSM2.g:4192:1: ruleArithmethicalLogicalExpression returns [EObject current=null] : (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator1_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_operator2_6_0= ruleComparationOperator ) ) ( (lv_expr_7_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE )? ) ;
    public final EObject ruleArithmethicalLogicalExpression() throws RecognitionException {
        EObject current = null;

        Token this_OPENPARENTHESIS_0=null;
        Token lv_op1_1_0=null;
        Token this_FLOAT_2=null;
        Token lv_op2_4_0=null;
        Token this_FLOAT_5=null;
        Token this_CLOSEPARENTHESIS_8=null;
        Token this_SEMICOLON_9=null;
        Token this_EOLINE_10=null;
        Enumerator lv_operator1_3_0 = null;

        Enumerator lv_operator2_6_0 = null;

        EObject lv_expr_7_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4198:2: ( (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator1_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_operator2_6_0= ruleComparationOperator ) ) ( (lv_expr_7_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE )? ) )
            // InternalSM2.g:4199:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator1_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_operator2_6_0= ruleComparationOperator ) ) ( (lv_expr_7_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE )? )
            {
            // InternalSM2.g:4199:2: (this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator1_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_operator2_6_0= ruleComparationOperator ) ) ( (lv_expr_7_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE )? )
            // InternalSM2.g:4200:3: this_OPENPARENTHESIS_0= RULE_OPENPARENTHESIS ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT ) ( (lv_operator1_3_0= ruleArithmeticalOperator ) ) ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT ) ( (lv_operator2_6_0= ruleComparationOperator ) ) ( (lv_expr_7_0= ruleArithmethicalExpression ) ) this_CLOSEPARENTHESIS_8= RULE_CLOSEPARENTHESIS (this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE )?
            {
            this_OPENPARENTHESIS_0=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_52); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0());
              		
            }
            // InternalSM2.g:4204:3: ( ( (lv_op1_1_0= RULE_INTEGER ) ) | this_FLOAT_2= RULE_FLOAT )
            int alt120=2;
            int LA120_0 = input.LA(1);

            if ( (LA120_0==RULE_INTEGER) ) {
                alt120=1;
            }
            else if ( (LA120_0==RULE_FLOAT) ) {
                alt120=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 120, 0, input);

                throw nvae;
            }
            switch (alt120) {
                case 1 :
                    // InternalSM2.g:4205:4: ( (lv_op1_1_0= RULE_INTEGER ) )
                    {
                    // InternalSM2.g:4205:4: ( (lv_op1_1_0= RULE_INTEGER ) )
                    // InternalSM2.g:4206:5: (lv_op1_1_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:4206:5: (lv_op1_1_0= RULE_INTEGER )
                    // InternalSM2.g:4207:6: lv_op1_1_0= RULE_INTEGER
                    {
                    lv_op1_1_0=(Token)match(input,RULE_INTEGER,FOLLOW_82); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op1_1_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOp1INTEGERTerminalRuleCall_1_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalLogicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op1",
                      							lv_op1_1_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4224:4: this_FLOAT_2= RULE_FLOAT
                    {
                    this_FLOAT_2=(Token)match(input,RULE_FLOAT,FOLLOW_82); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_FLOAT_2, grammarAccess.getArithmethicalLogicalExpressionAccess().getFLOATTerminalRuleCall_1_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:4229:3: ( (lv_operator1_3_0= ruleArithmeticalOperator ) )
            // InternalSM2.g:4230:4: (lv_operator1_3_0= ruleArithmeticalOperator )
            {
            // InternalSM2.g:4230:4: (lv_operator1_3_0= ruleArithmeticalOperator )
            // InternalSM2.g:4231:5: lv_operator1_3_0= ruleArithmeticalOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator1ArithmeticalOperatorEnumRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_52);
            lv_operator1_3_0=ruleArithmeticalOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"operator1",
              						lv_operator1_3_0,
              						"org.xtext.SM2.ArithmeticalOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4248:3: ( ( (lv_op2_4_0= RULE_INTEGER ) ) | this_FLOAT_5= RULE_FLOAT )
            int alt121=2;
            int LA121_0 = input.LA(1);

            if ( (LA121_0==RULE_INTEGER) ) {
                alt121=1;
            }
            else if ( (LA121_0==RULE_FLOAT) ) {
                alt121=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 121, 0, input);

                throw nvae;
            }
            switch (alt121) {
                case 1 :
                    // InternalSM2.g:4249:4: ( (lv_op2_4_0= RULE_INTEGER ) )
                    {
                    // InternalSM2.g:4249:4: ( (lv_op2_4_0= RULE_INTEGER ) )
                    // InternalSM2.g:4250:5: (lv_op2_4_0= RULE_INTEGER )
                    {
                    // InternalSM2.g:4250:5: (lv_op2_4_0= RULE_INTEGER )
                    // InternalSM2.g:4251:6: lv_op2_4_0= RULE_INTEGER
                    {
                    lv_op2_4_0=(Token)match(input,RULE_INTEGER,FOLLOW_69); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						newLeafNode(lv_op2_4_0, grammarAccess.getArithmethicalLogicalExpressionAccess().getOp2INTEGERTerminalRuleCall_3_0_0());
                      					
                    }
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElement(grammarAccess.getArithmethicalLogicalExpressionRule());
                      						}
                      						setWithLastConsumed(
                      							current,
                      							"op2",
                      							lv_op2_4_0,
                      							"org.xtext.SM2.INTEGER");
                      					
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4268:4: this_FLOAT_5= RULE_FLOAT
                    {
                    this_FLOAT_5=(Token)match(input,RULE_FLOAT,FOLLOW_69); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_FLOAT_5, grammarAccess.getArithmethicalLogicalExpressionAccess().getFLOATTerminalRuleCall_3_1());
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:4273:3: ( (lv_operator2_6_0= ruleComparationOperator ) )
            // InternalSM2.g:4274:4: (lv_operator2_6_0= ruleComparationOperator )
            {
            // InternalSM2.g:4274:4: (lv_operator2_6_0= ruleComparationOperator )
            // InternalSM2.g:4275:5: lv_operator2_6_0= ruleComparationOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator2ComparationOperatorEnumRuleCall_4_0());
              				
            }
            pushFollow(FOLLOW_84);
            lv_operator2_6_0=ruleComparationOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"operator2",
              						lv_operator2_6_0,
              						"org.xtext.SM2.ComparationOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4292:3: ( (lv_expr_7_0= ruleArithmethicalExpression ) )
            // InternalSM2.g:4293:4: (lv_expr_7_0= ruleArithmethicalExpression )
            {
            // InternalSM2.g:4293:4: (lv_expr_7_0= ruleArithmethicalExpression )
            // InternalSM2.g:4294:5: lv_expr_7_0= ruleArithmethicalExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getArithmethicalLogicalExpressionAccess().getExprArithmethicalExpressionParserRuleCall_5_0());
              				
            }
            pushFollow(FOLLOW_29);
            lv_expr_7_0=ruleArithmethicalExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getArithmethicalLogicalExpressionRule());
              					}
              					set(
              						current,
              						"expr",
              						lv_expr_7_0,
              						"org.xtext.SM2.ArithmethicalExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_8=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_83); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_8, grammarAccess.getArithmethicalLogicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_6());
              		
            }
            // InternalSM2.g:4315:3: (this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE )?
            int alt122=2;
            int LA122_0 = input.LA(1);

            if ( (LA122_0==RULE_SEMICOLON) ) {
                int LA122_1 = input.LA(2);

                if ( (LA122_1==RULE_EOLINE) ) {
                    int LA122_3 = input.LA(3);

                    if ( (LA122_3==EOF||(LA122_3>=RULE_SEMICOLON && LA122_3<=RULE_CLOSEKEY)||LA122_3==RULE_INTEGER||(LA122_3>=RULE_OPENPARENTHESIS && LA122_3<=RULE_STRING)||LA122_3==RULE_FLOAT) ) {
                        alt122=1;
                    }
                }
            }
            switch (alt122) {
                case 1 :
                    // InternalSM2.g:4316:4: this_SEMICOLON_9= RULE_SEMICOLON this_EOLINE_10= RULE_EOLINE
                    {
                    this_SEMICOLON_9=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_9, grammarAccess.getArithmethicalLogicalExpressionAccess().getSEMICOLONTerminalRuleCall_7_0());
                      			
                    }
                    this_EOLINE_10=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_10, grammarAccess.getArithmethicalLogicalExpressionAccess().getEOLINETerminalRuleCall_7_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalLogicalExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:4329:1: entryRuleSyntaxExpression returns [EObject current=null] : iv_ruleSyntaxExpression= ruleSyntaxExpression EOF ;
    public final EObject entryRuleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSyntaxExpression = null;


        try {
            // InternalSM2.g:4329:57: (iv_ruleSyntaxExpression= ruleSyntaxExpression EOF )
            // InternalSM2.g:4330:2: iv_ruleSyntaxExpression= ruleSyntaxExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSyntaxExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSyntaxExpression=ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSyntaxExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:4336:1: ruleSyntaxExpression returns [EObject current=null] : ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) ) ;
    public final EObject ruleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        Token lv_expr_0_0=null;
        Token this_INTEGER_1=null;
        Token this_FLOAT_2=null;
        Token this_SEMICOLON_3=null;
        Token this_EOLINE_4=null;


        	enterRule();

        try {
            // InternalSM2.g:4342:2: ( ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) ) )
            // InternalSM2.g:4343:2: ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) )
            {
            // InternalSM2.g:4343:2: ( ( (lv_expr_0_0= RULE_STRING ) ) | ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? ) )
            int alt125=2;
            int LA125_0 = input.LA(1);

            if ( (LA125_0==RULE_STRING) ) {
                alt125=1;
            }
            else if ( (LA125_0==RULE_INTEGER||LA125_0==RULE_FLOAT) ) {
                alt125=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 125, 0, input);

                throw nvae;
            }
            switch (alt125) {
                case 1 :
                    // InternalSM2.g:4344:3: ( (lv_expr_0_0= RULE_STRING ) )
                    {
                    // InternalSM2.g:4344:3: ( (lv_expr_0_0= RULE_STRING ) )
                    // InternalSM2.g:4345:4: (lv_expr_0_0= RULE_STRING )
                    {
                    // InternalSM2.g:4345:4: (lv_expr_0_0= RULE_STRING )
                    // InternalSM2.g:4346:5: lv_expr_0_0= RULE_STRING
                    {
                    lv_expr_0_0=(Token)match(input,RULE_STRING,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(lv_expr_0_0, grammarAccess.getSyntaxExpressionAccess().getExprSTRINGTerminalRuleCall_0_0());
                      				
                    }
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElement(grammarAccess.getSyntaxExpressionRule());
                      					}
                      					setWithLastConsumed(
                      						current,
                      						"expr",
                      						lv_expr_0_0,
                      						"org.eclipse.xtext.common.Terminals.STRING");
                      				
                    }

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4363:3: ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? )
                    {
                    // InternalSM2.g:4363:3: ( (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )? )
                    // InternalSM2.g:4364:4: (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT ) (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )?
                    {
                    // InternalSM2.g:4364:4: (this_INTEGER_1= RULE_INTEGER | this_FLOAT_2= RULE_FLOAT )
                    int alt123=2;
                    int LA123_0 = input.LA(1);

                    if ( (LA123_0==RULE_INTEGER) ) {
                        alt123=1;
                    }
                    else if ( (LA123_0==RULE_FLOAT) ) {
                        alt123=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 123, 0, input);

                        throw nvae;
                    }
                    switch (alt123) {
                        case 1 :
                            // InternalSM2.g:4365:5: this_INTEGER_1= RULE_INTEGER
                            {
                            this_INTEGER_1=(Token)match(input,RULE_INTEGER,FOLLOW_83); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_INTEGER_1, grammarAccess.getSyntaxExpressionAccess().getINTEGERTerminalRuleCall_1_0_0());
                              				
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4370:5: this_FLOAT_2= RULE_FLOAT
                            {
                            this_FLOAT_2=(Token)match(input,RULE_FLOAT,FOLLOW_83); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_FLOAT_2, grammarAccess.getSyntaxExpressionAccess().getFLOATTerminalRuleCall_1_0_1());
                              				
                            }

                            }
                            break;

                    }

                    // InternalSM2.g:4375:4: (this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE )?
                    int alt124=2;
                    int LA124_0 = input.LA(1);

                    if ( (LA124_0==RULE_SEMICOLON) ) {
                        int LA124_1 = input.LA(2);

                        if ( (LA124_1==RULE_EOLINE) ) {
                            alt124=1;
                        }
                    }
                    switch (alt124) {
                        case 1 :
                            // InternalSM2.g:4376:5: this_SEMICOLON_3= RULE_SEMICOLON this_EOLINE_4= RULE_EOLINE
                            {
                            this_SEMICOLON_3=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_SEMICOLON_3, grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0());
                              				
                            }
                            this_EOLINE_4=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              					newLeafNode(this_EOLINE_4, grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1());
                              				
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleTimeExpression"
    // InternalSM2.g:4390:1: entryRuleTimeExpression returns [EObject current=null] : iv_ruleTimeExpression= ruleTimeExpression EOF ;
    public final EObject entryRuleTimeExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTimeExpression = null;


        try {
            // InternalSM2.g:4390:55: (iv_ruleTimeExpression= ruleTimeExpression EOF )
            // InternalSM2.g:4391:2: iv_ruleTimeExpression= ruleTimeExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getTimeExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleTimeExpression=ruleTimeExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleTimeExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTimeExpression"


    // $ANTLR start "ruleTimeExpression"
    // InternalSM2.g:4397:1: ruleTimeExpression returns [EObject current=null] : ( ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) ;
    public final EObject ruleTimeExpression() throws RecognitionException {
        EObject current = null;

        Token lv_time_0_0=null;
        Token this_SEMICOLON_2=null;
        Token this_EOLINE_3=null;
        Enumerator lv_unit_1_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4403:2: ( ( ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? ) )
            // InternalSM2.g:4404:2: ( ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
            {
            // InternalSM2.g:4404:2: ( ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )? )
            // InternalSM2.g:4405:3: ( (lv_time_0_0= RULE_INTEGER ) ) ( (lv_unit_1_0= ruleTimeUnit ) ) (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
            {
            // InternalSM2.g:4405:3: ( (lv_time_0_0= RULE_INTEGER ) )
            // InternalSM2.g:4406:4: (lv_time_0_0= RULE_INTEGER )
            {
            // InternalSM2.g:4406:4: (lv_time_0_0= RULE_INTEGER )
            // InternalSM2.g:4407:5: lv_time_0_0= RULE_INTEGER
            {
            lv_time_0_0=(Token)match(input,RULE_INTEGER,FOLLOW_85); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_time_0_0, grammarAccess.getTimeExpressionAccess().getTimeINTEGERTerminalRuleCall_0_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getTimeExpressionRule());
              					}
              					setWithLastConsumed(
              						current,
              						"time",
              						lv_time_0_0,
              						"org.xtext.SM2.INTEGER");
              				
            }

            }


            }

            // InternalSM2.g:4423:3: ( (lv_unit_1_0= ruleTimeUnit ) )
            // InternalSM2.g:4424:4: (lv_unit_1_0= ruleTimeUnit )
            {
            // InternalSM2.g:4424:4: (lv_unit_1_0= ruleTimeUnit )
            // InternalSM2.g:4425:5: lv_unit_1_0= ruleTimeUnit
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getTimeExpressionAccess().getUnitTimeUnitEnumRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_83);
            lv_unit_1_0=ruleTimeUnit();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getTimeExpressionRule());
              					}
              					set(
              						current,
              						"unit",
              						lv_unit_1_0,
              						"org.xtext.SM2.TimeUnit");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalSM2.g:4442:3: (this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE )?
            int alt126=2;
            int LA126_0 = input.LA(1);

            if ( (LA126_0==RULE_SEMICOLON) ) {
                int LA126_1 = input.LA(2);

                if ( (LA126_1==RULE_EOLINE) ) {
                    int LA126_3 = input.LA(3);

                    if ( (LA126_3==EOF||(LA126_3>=RULE_SEMICOLON && LA126_3<=RULE_CLOSEKEY)||LA126_3==RULE_INTEGER||(LA126_3>=RULE_OPENPARENTHESIS && LA126_3<=RULE_STRING)||LA126_3==RULE_FLOAT) ) {
                        alt126=1;
                    }
                }
            }
            switch (alt126) {
                case 1 :
                    // InternalSM2.g:4443:4: this_SEMICOLON_2= RULE_SEMICOLON this_EOLINE_3= RULE_EOLINE
                    {
                    this_SEMICOLON_2=(Token)match(input,RULE_SEMICOLON,FOLLOW_16); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_SEMICOLON_2, grammarAccess.getTimeExpressionAccess().getSEMICOLONTerminalRuleCall_2_0());
                      			
                    }
                    this_EOLINE_3=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_EOLINE_3, grammarAccess.getTimeExpressionAccess().getEOLINETerminalRuleCall_2_1());
                      			
                    }

                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeExpression"


    // $ANTLR start "entryRuleConditional"
    // InternalSM2.g:4456:1: entryRuleConditional returns [EObject current=null] : iv_ruleConditional= ruleConditional EOF ;
    public final EObject entryRuleConditional() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConditional = null;


        try {
            // InternalSM2.g:4456:52: (iv_ruleConditional= ruleConditional EOF )
            // InternalSM2.g:4457:2: iv_ruleConditional= ruleConditional EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getConditionalRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleConditional=ruleConditional();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleConditional; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConditional"


    // $ANTLR start "ruleConditional"
    // InternalSM2.g:4463:1: ruleConditional returns [EObject current=null] : (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) ) ;
    public final EObject ruleConditional() throws RecognitionException {
        EObject current = null;

        Token this_IF_0=null;
        Token this_OPENPARENTHESIS_1=null;
        Token this_CLOSEPARENTHESIS_4=null;
        Token this_OPENKEY_5=null;
        Token this_CLOSEKEY_7=null;
        Token this_ELSE_8=null;
        EObject this_LogicalUnaryOperator_2 = null;

        EObject lv_expression_3_0 = null;

        EObject lv_expressions_6_0 = null;

        EObject lv_needOtherCondition_9_0 = null;



        	enterRule();

        try {
            // InternalSM2.g:4469:2: ( (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) ) )
            // InternalSM2.g:4470:2: (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) )
            {
            // InternalSM2.g:4470:2: (this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) ) )
            // InternalSM2.g:4471:3: this_IF_0= RULE_IF this_OPENPARENTHESIS_1= RULE_OPENPARENTHESIS (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )? ( (lv_expression_3_0= ruleExpression ) ) this_CLOSEPARENTHESIS_4= RULE_CLOSEPARENTHESIS this_OPENKEY_5= RULE_OPENKEY ( (lv_expressions_6_0= ruleExpression ) )* this_CLOSEKEY_7= RULE_CLOSEKEY (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) )
            {
            this_IF_0=(Token)match(input,RULE_IF,FOLLOW_27); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_IF_0, grammarAccess.getConditionalAccess().getIFTerminalRuleCall_0());
              		
            }
            this_OPENPARENTHESIS_1=(Token)match(input,RULE_OPENPARENTHESIS,FOLLOW_86); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENPARENTHESIS_1, grammarAccess.getConditionalAccess().getOPENPARENTHESISTerminalRuleCall_1());
              		
            }
            // InternalSM2.g:4479:3: (this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator )?
            int alt127=2;
            int LA127_0 = input.LA(1);

            if ( (LA127_0==80) ) {
                alt127=1;
            }
            switch (alt127) {
                case 1 :
                    // InternalSM2.g:4480:4: this_LogicalUnaryOperator_2= ruleLogicalUnaryOperator
                    {
                    if ( state.backtracking==0 ) {

                      				newCompositeNode(grammarAccess.getConditionalAccess().getLogicalUnaryOperatorParserRuleCall_2());
                      			
                    }
                    pushFollow(FOLLOW_32);
                    this_LogicalUnaryOperator_2=ruleLogicalUnaryOperator();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = this_LogicalUnaryOperator_2;
                      				afterParserOrEnumRuleCall();
                      			
                    }

                    }
                    break;

            }

            // InternalSM2.g:4489:3: ( (lv_expression_3_0= ruleExpression ) )
            // InternalSM2.g:4490:4: (lv_expression_3_0= ruleExpression )
            {
            // InternalSM2.g:4490:4: (lv_expression_3_0= ruleExpression )
            // InternalSM2.g:4491:5: lv_expression_3_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getConditionalAccess().getExpressionExpressionParserRuleCall_3_0());
              				
            }
            pushFollow(FOLLOW_29);
            lv_expression_3_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getConditionalRule());
              					}
              					set(
              						current,
              						"expression",
              						lv_expression_3_0,
              						"org.xtext.SM2.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            this_CLOSEPARENTHESIS_4=(Token)match(input,RULE_CLOSEPARENTHESIS,FOLLOW_15); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEPARENTHESIS_4, grammarAccess.getConditionalAccess().getCLOSEPARENTHESISTerminalRuleCall_4());
              		
            }
            this_OPENKEY_5=(Token)match(input,RULE_OPENKEY,FOLLOW_74); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_OPENKEY_5, grammarAccess.getConditionalAccess().getOPENKEYTerminalRuleCall_5());
              		
            }
            // InternalSM2.g:4516:3: ( (lv_expressions_6_0= ruleExpression ) )*
            loop128:
            do {
                int alt128=2;
                int LA128_0 = input.LA(1);

                if ( (LA128_0==RULE_INTEGER||LA128_0==RULE_OPENPARENTHESIS||LA128_0==RULE_STRING||LA128_0==RULE_FLOAT) ) {
                    alt128=1;
                }


                switch (alt128) {
            	case 1 :
            	    // InternalSM2.g:4517:4: (lv_expressions_6_0= ruleExpression )
            	    {
            	    // InternalSM2.g:4517:4: (lv_expressions_6_0= ruleExpression )
            	    // InternalSM2.g:4518:5: lv_expressions_6_0= ruleExpression
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getConditionalAccess().getExpressionsExpressionParserRuleCall_6_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_74);
            	    lv_expressions_6_0=ruleExpression();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getConditionalRule());
            	      					}
            	      					add(
            	      						current,
            	      						"expressions",
            	      						lv_expressions_6_0,
            	      						"org.xtext.SM2.Expression");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop128;
                }
            } while (true);

            this_CLOSEKEY_7=(Token)match(input,RULE_CLOSEKEY,FOLLOW_87); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(this_CLOSEKEY_7, grammarAccess.getConditionalAccess().getCLOSEKEYTerminalRuleCall_7());
              		
            }
            // InternalSM2.g:4539:3: (this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) ) )
            // InternalSM2.g:4540:4: this_ELSE_8= RULE_ELSE ( (lv_needOtherCondition_9_0= ruleConditional ) )
            {
            this_ELSE_8=(Token)match(input,RULE_ELSE,FOLLOW_77); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(this_ELSE_8, grammarAccess.getConditionalAccess().getELSETerminalRuleCall_8_0());
              			
            }
            // InternalSM2.g:4544:4: ( (lv_needOtherCondition_9_0= ruleConditional ) )
            // InternalSM2.g:4545:5: (lv_needOtherCondition_9_0= ruleConditional )
            {
            // InternalSM2.g:4545:5: (lv_needOtherCondition_9_0= ruleConditional )
            // InternalSM2.g:4546:6: lv_needOtherCondition_9_0= ruleConditional
            {
            if ( state.backtracking==0 ) {

              						newCompositeNode(grammarAccess.getConditionalAccess().getNeedOtherConditionConditionalParserRuleCall_8_1_0());
              					
            }
            pushFollow(FOLLOW_2);
            lv_needOtherCondition_9_0=ruleConditional();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              						if (current==null) {
              							current = createModelElementForParent(grammarAccess.getConditionalRule());
              						}
              						set(
              							current,
              							"needOtherCondition",
              							lv_needOtherCondition_9_0,
              							"org.xtext.SM2.Conditional");
              						afterParserOrEnumRuleCall();
              					
            }

            }


            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConditional"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:4568:1: entryRuleComment returns [EObject current=null] : iv_ruleComment= ruleComment EOF ;
    public final EObject entryRuleComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleComment = null;


        try {
            // InternalSM2.g:4568:48: (iv_ruleComment= ruleComment EOF )
            // InternalSM2.g:4569:2: iv_ruleComment= ruleComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleComment=ruleComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:4575:1: ruleComment returns [EObject current=null] : (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) ;
    public final EObject ruleComment() throws RecognitionException {
        EObject current = null;

        EObject this_ShortComment_0 = null;

        EObject this_LongComment_1 = null;



        	enterRule();

        try {
            // InternalSM2.g:4581:2: ( (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) )
            // InternalSM2.g:4582:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            {
            // InternalSM2.g:4582:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            int alt129=2;
            int LA129_0 = input.LA(1);

            if ( (LA129_0==77) ) {
                alt129=1;
            }
            else if ( (LA129_0==78) ) {
                alt129=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 129, 0, input);

                throw nvae;
            }
            switch (alt129) {
                case 1 :
                    // InternalSM2.g:4583:3: this_ShortComment_0= ruleShortComment
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ShortComment_0=ruleShortComment();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ShortComment_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalSM2.g:4592:3: this_LongComment_1= ruleLongComment
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_LongComment_1=ruleLongComment();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_LongComment_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:4604:1: entryRuleShortComment returns [EObject current=null] : iv_ruleShortComment= ruleShortComment EOF ;
    public final EObject entryRuleShortComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleShortComment = null;


        try {
            // InternalSM2.g:4604:53: (iv_ruleShortComment= ruleShortComment EOF )
            // InternalSM2.g:4605:2: iv_ruleShortComment= ruleShortComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getShortCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleShortComment=ruleShortComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleShortComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:4611:1: ruleShortComment returns [EObject current=null] : (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) ) ;
    public final EObject ruleShortComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expr_1_0=null;
        Token this_EOLINE_2=null;


        	enterRule();

        try {
            // InternalSM2.g:4617:2: ( (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) ) )
            // InternalSM2.g:4618:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) )
            {
            // InternalSM2.g:4618:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE ) )
            // InternalSM2.g:4619:3: otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE )
            {
            otherlv_0=(Token)match(input,77,FOLLOW_45); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0());
              		
            }
            // InternalSM2.g:4623:3: ( (lv_expr_1_0= RULE_STRING ) )
            // InternalSM2.g:4624:4: (lv_expr_1_0= RULE_STRING )
            {
            // InternalSM2.g:4624:4: (lv_expr_1_0= RULE_STRING )
            // InternalSM2.g:4625:5: lv_expr_1_0= RULE_STRING
            {
            lv_expr_1_0=(Token)match(input,RULE_STRING,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_expr_1_0, grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getShortCommentRule());
              					}
              					setWithLastConsumed(
              						current,
              						"expr",
              						lv_expr_1_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalSM2.g:4641:3: ( ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE )
            // InternalSM2.g:4642:4: ( RULE_EOLINE )=>this_EOLINE_2= RULE_EOLINE
            {
            this_EOLINE_2=(Token)match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(this_EOLINE_2, grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:4652:1: entryRuleLongComment returns [EObject current=null] : iv_ruleLongComment= ruleLongComment EOF ;
    public final EObject entryRuleLongComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLongComment = null;


        try {
            // InternalSM2.g:4652:52: (iv_ruleLongComment= ruleLongComment EOF )
            // InternalSM2.g:4653:2: iv_ruleLongComment= ruleLongComment EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLongCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLongComment=ruleLongComment();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLongComment; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:4659:1: ruleLongComment returns [EObject current=null] : (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) ) ;
    public final EObject ruleLongComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expression_1_1=null;
        Token lv_expression_1_2=null;
        Token lv_expression_1_3=null;
        Token lv_expression_1_4=null;
        Token lv_expression_1_5=null;
        Token lv_expression_1_6=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSM2.g:4665:2: ( (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) ) )
            // InternalSM2.g:4666:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) )
            {
            // InternalSM2.g:4666:2: (otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' ) )
            // InternalSM2.g:4667:3: otherlv_0= '/*' ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )? ( ( '*/' )=>otherlv_2= '*/' )
            {
            otherlv_0=(Token)match(input,78,FOLLOW_88); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0());
              		
            }
            // InternalSM2.g:4671:3: ( ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) ) )?
            int alt131=2;
            int LA131_0 = input.LA(1);

            if ( (LA131_0==RULE_STRING||(LA131_0>=RULE_PARAMSLONGCOMENT && LA131_0<=RULE_NOTICELONGCOMENT)) ) {
                alt131=1;
            }
            switch (alt131) {
                case 1 :
                    // InternalSM2.g:4672:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
                    {
                    // InternalSM2.g:4672:4: ( (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT ) )
                    // InternalSM2.g:4673:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
                    {
                    // InternalSM2.g:4673:5: (lv_expression_1_1= RULE_STRING | lv_expression_1_2= RULE_PARAMSLONGCOMENT | lv_expression_1_3= RULE_DEVLONGCOMENT | lv_expression_1_4= RULE_RETURNSLONGCOMENT | lv_expression_1_5= RULE_TITLELONGCOMENT | lv_expression_1_6= RULE_NOTICELONGCOMENT )
                    int alt130=6;
                    switch ( input.LA(1) ) {
                    case RULE_STRING:
                        {
                        alt130=1;
                        }
                        break;
                    case RULE_PARAMSLONGCOMENT:
                        {
                        alt130=2;
                        }
                        break;
                    case RULE_DEVLONGCOMENT:
                        {
                        alt130=3;
                        }
                        break;
                    case RULE_RETURNSLONGCOMENT:
                        {
                        alt130=4;
                        }
                        break;
                    case RULE_TITLELONGCOMENT:
                        {
                        alt130=5;
                        }
                        break;
                    case RULE_NOTICELONGCOMENT:
                        {
                        alt130=6;
                        }
                        break;
                    default:
                        if (state.backtracking>0) {state.failed=true; return current;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 130, 0, input);

                        throw nvae;
                    }

                    switch (alt130) {
                        case 1 :
                            // InternalSM2.g:4674:6: lv_expression_1_1= RULE_STRING
                            {
                            lv_expression_1_1=(Token)match(input,RULE_STRING,FOLLOW_89); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_1, grammarAccess.getLongCommentAccess().getExpressionSTRINGTerminalRuleCall_1_0_0());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_1,
                              							"org.eclipse.xtext.common.Terminals.STRING");
                              					
                            }

                            }
                            break;
                        case 2 :
                            // InternalSM2.g:4689:6: lv_expression_1_2= RULE_PARAMSLONGCOMENT
                            {
                            lv_expression_1_2=(Token)match(input,RULE_PARAMSLONGCOMENT,FOLLOW_89); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_2, grammarAccess.getLongCommentAccess().getExpressionPARAMSLONGCOMENTTerminalRuleCall_1_0_1());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_2,
                              							"org.xtext.SM2.PARAMSLONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 3 :
                            // InternalSM2.g:4704:6: lv_expression_1_3= RULE_DEVLONGCOMENT
                            {
                            lv_expression_1_3=(Token)match(input,RULE_DEVLONGCOMENT,FOLLOW_89); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_3, grammarAccess.getLongCommentAccess().getExpressionDEVLONGCOMENTTerminalRuleCall_1_0_2());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_3,
                              							"org.xtext.SM2.DEVLONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 4 :
                            // InternalSM2.g:4719:6: lv_expression_1_4= RULE_RETURNSLONGCOMENT
                            {
                            lv_expression_1_4=(Token)match(input,RULE_RETURNSLONGCOMENT,FOLLOW_89); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_4, grammarAccess.getLongCommentAccess().getExpressionRETURNSLONGCOMENTTerminalRuleCall_1_0_3());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_4,
                              							"org.xtext.SM2.RETURNSLONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 5 :
                            // InternalSM2.g:4734:6: lv_expression_1_5= RULE_TITLELONGCOMENT
                            {
                            lv_expression_1_5=(Token)match(input,RULE_TITLELONGCOMENT,FOLLOW_89); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_5, grammarAccess.getLongCommentAccess().getExpressionTITLELONGCOMENTTerminalRuleCall_1_0_4());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_5,
                              							"org.xtext.SM2.TITLELONGCOMENT");
                              					
                            }

                            }
                            break;
                        case 6 :
                            // InternalSM2.g:4749:6: lv_expression_1_6= RULE_NOTICELONGCOMENT
                            {
                            lv_expression_1_6=(Token)match(input,RULE_NOTICELONGCOMENT,FOLLOW_89); if (state.failed) return current;
                            if ( state.backtracking==0 ) {

                              						newLeafNode(lv_expression_1_6, grammarAccess.getLongCommentAccess().getExpressionNOTICELONGCOMENTTerminalRuleCall_1_0_5());
                              					
                            }
                            if ( state.backtracking==0 ) {

                              						if (current==null) {
                              							current = createModelElement(grammarAccess.getLongCommentRule());
                              						}
                              						addWithLastConsumed(
                              							current,
                              							"expression",
                              							lv_expression_1_6,
                              							"org.xtext.SM2.NOTICELONGCOMENT");
                              					
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;

            }

            // InternalSM2.g:4766:3: ( ( '*/' )=>otherlv_2= '*/' )
            // InternalSM2.g:4767:4: ( '*/' )=>otherlv_2= '*/'
            {
            otherlv_2=(Token)match(input,79,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_2, grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "entryRuleLogicalUnaryOperator"
    // InternalSM2.g:4777:1: entryRuleLogicalUnaryOperator returns [EObject current=null] : iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF ;
    public final EObject entryRuleLogicalUnaryOperator() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLogicalUnaryOperator = null;


        try {
            // InternalSM2.g:4777:61: (iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF )
            // InternalSM2.g:4778:2: iv_ruleLogicalUnaryOperator= ruleLogicalUnaryOperator EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLogicalUnaryOperatorRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLogicalUnaryOperator=ruleLogicalUnaryOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLogicalUnaryOperator; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLogicalUnaryOperator"


    // $ANTLR start "ruleLogicalUnaryOperator"
    // InternalSM2.g:4784:1: ruleLogicalUnaryOperator returns [EObject current=null] : ( (lv_operator_0_0= '!' ) ) ;
    public final EObject ruleLogicalUnaryOperator() throws RecognitionException {
        EObject current = null;

        Token lv_operator_0_0=null;


        	enterRule();

        try {
            // InternalSM2.g:4790:2: ( ( (lv_operator_0_0= '!' ) ) )
            // InternalSM2.g:4791:2: ( (lv_operator_0_0= '!' ) )
            {
            // InternalSM2.g:4791:2: ( (lv_operator_0_0= '!' ) )
            // InternalSM2.g:4792:3: (lv_operator_0_0= '!' )
            {
            // InternalSM2.g:4792:3: (lv_operator_0_0= '!' )
            // InternalSM2.g:4793:4: lv_operator_0_0= '!'
            {
            lv_operator_0_0=(Token)match(input,80,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(lv_operator_0_0, grammarAccess.getLogicalUnaryOperatorAccess().getOperatorExclamationMarkKeyword_0());
              			
            }
            if ( state.backtracking==0 ) {

              				if (current==null) {
              					current = createModelElement(grammarAccess.getLogicalUnaryOperatorRule());
              				}
              				setWithLastConsumed(current, "operator", lv_operator_0_0, "!");
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalUnaryOperator"


    // $ANTLR start "ruleBasicType"
    // InternalSM2.g:4808:1: ruleBasicType returns [Enumerator current=null] : ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) ) ;
    public final Enumerator ruleBasicType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;
        Token enumLiteral_8=null;
        Token enumLiteral_9=null;
        Token enumLiteral_10=null;


        	enterRule();

        try {
            // InternalSM2.g:4814:2: ( ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) ) )
            // InternalSM2.g:4815:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) )
            {
            // InternalSM2.g:4815:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'uint256' ) | (enumLiteral_4= 'string' ) | (enumLiteral_5= 'address' ) | (enumLiteral_6= 'address payable' ) | (enumLiteral_7= 'double' ) | (enumLiteral_8= 'bool' ) | (enumLiteral_9= 'byte' ) | (enumLiteral_10= 'bytes32' ) )
            int alt132=11;
            switch ( input.LA(1) ) {
            case 61:
                {
                alt132=1;
                }
                break;
            case 81:
                {
                alt132=2;
                }
                break;
            case 62:
                {
                alt132=3;
                }
                break;
            case 63:
                {
                alt132=4;
                }
                break;
            case 54:
                {
                alt132=5;
                }
                break;
            case 52:
                {
                alt132=6;
                }
                break;
            case 65:
                {
                alt132=7;
                }
                break;
            case 82:
                {
                alt132=8;
                }
                break;
            case 64:
                {
                alt132=9;
                }
                break;
            case 83:
                {
                alt132=10;
                }
                break;
            case 67:
                {
                alt132=11;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 132, 0, input);

                throw nvae;
            }

            switch (alt132) {
                case 1 :
                    // InternalSM2.g:4816:3: (enumLiteral_0= 'int' )
                    {
                    // InternalSM2.g:4816:3: (enumLiteral_0= 'int' )
                    // InternalSM2.g:4817:4: enumLiteral_0= 'int'
                    {
                    enumLiteral_0=(Token)match(input,61,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getINTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getBasicTypeAccess().getINTEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4824:3: (enumLiteral_1= 'uint' )
                    {
                    // InternalSM2.g:4824:3: (enumLiteral_1= 'uint' )
                    // InternalSM2.g:4825:4: enumLiteral_1= 'uint'
                    {
                    enumLiteral_1=(Token)match(input,81,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getBasicTypeAccess().getUINTEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:4832:3: (enumLiteral_2= 'uint8' )
                    {
                    // InternalSM2.g:4832:3: (enumLiteral_2= 'uint8' )
                    // InternalSM2.g:4833:4: enumLiteral_2= 'uint8'
                    {
                    enumLiteral_2=(Token)match(input,62,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT8EnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getBasicTypeAccess().getUINT8EnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:4840:3: (enumLiteral_3= 'uint256' )
                    {
                    // InternalSM2.g:4840:3: (enumLiteral_3= 'uint256' )
                    // InternalSM2.g:4841:4: enumLiteral_3= 'uint256'
                    {
                    enumLiteral_3=(Token)match(input,63,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getUINT256EnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getBasicTypeAccess().getUINT256EnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:4848:3: (enumLiteral_4= 'string' )
                    {
                    // InternalSM2.g:4848:3: (enumLiteral_4= 'string' )
                    // InternalSM2.g:4849:4: enumLiteral_4= 'string'
                    {
                    enumLiteral_4=(Token)match(input,54,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getSTRINGEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getBasicTypeAccess().getSTRINGEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:4856:3: (enumLiteral_5= 'address' )
                    {
                    // InternalSM2.g:4856:3: (enumLiteral_5= 'address' )
                    // InternalSM2.g:4857:4: enumLiteral_5= 'address'
                    {
                    enumLiteral_5=(Token)match(input,52,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getADDRESSEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getBasicTypeAccess().getADDRESSEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:4864:3: (enumLiteral_6= 'address payable' )
                    {
                    // InternalSM2.g:4864:3: (enumLiteral_6= 'address payable' )
                    // InternalSM2.g:4865:4: enumLiteral_6= 'address payable'
                    {
                    enumLiteral_6=(Token)match(input,65,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_6, grammarAccess.getBasicTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6());
                      			
                    }

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:4872:3: (enumLiteral_7= 'double' )
                    {
                    // InternalSM2.g:4872:3: (enumLiteral_7= 'double' )
                    // InternalSM2.g:4873:4: enumLiteral_7= 'double'
                    {
                    enumLiteral_7=(Token)match(input,82,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getDOUBLEEnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_7, grammarAccess.getBasicTypeAccess().getDOUBLEEnumLiteralDeclaration_7());
                      			
                    }

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:4880:3: (enumLiteral_8= 'bool' )
                    {
                    // InternalSM2.g:4880:3: (enumLiteral_8= 'bool' )
                    // InternalSM2.g:4881:4: enumLiteral_8= 'bool'
                    {
                    enumLiteral_8=(Token)match(input,64,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBOOLEANEnumLiteralDeclaration_8().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_8, grammarAccess.getBasicTypeAccess().getBOOLEANEnumLiteralDeclaration_8());
                      			
                    }

                    }


                    }
                    break;
                case 10 :
                    // InternalSM2.g:4888:3: (enumLiteral_9= 'byte' )
                    {
                    // InternalSM2.g:4888:3: (enumLiteral_9= 'byte' )
                    // InternalSM2.g:4889:4: enumLiteral_9= 'byte'
                    {
                    enumLiteral_9=(Token)match(input,83,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTEEnumLiteralDeclaration_9().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_9, grammarAccess.getBasicTypeAccess().getBYTEEnumLiteralDeclaration_9());
                      			
                    }

                    }


                    }
                    break;
                case 11 :
                    // InternalSM2.g:4896:3: (enumLiteral_10= 'bytes32' )
                    {
                    // InternalSM2.g:4896:3: (enumLiteral_10= 'bytes32' )
                    // InternalSM2.g:4897:4: enumLiteral_10= 'bytes32'
                    {
                    enumLiteral_10=(Token)match(input,67,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getBasicTypeAccess().getBYTE32EnumLiteralDeclaration_10().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_10, grammarAccess.getBasicTypeAccess().getBYTE32EnumLiteralDeclaration_10());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBasicType"


    // $ANTLR start "ruleTimeUnit"
    // InternalSM2.g:4907:1: ruleTimeUnit returns [Enumerator current=null] : ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) ) ;
    public final Enumerator ruleTimeUnit() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:4913:2: ( ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) ) )
            // InternalSM2.g:4914:2: ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) )
            {
            // InternalSM2.g:4914:2: ( (enumLiteral_0= 'seconds' ) | (enumLiteral_1= 'minutes' ) | (enumLiteral_2= 'hours' ) | (enumLiteral_3= 'days' ) | (enumLiteral_4= 'weeks' ) | (enumLiteral_5= 'years' ) )
            int alt133=6;
            switch ( input.LA(1) ) {
            case 84:
                {
                alt133=1;
                }
                break;
            case 85:
                {
                alt133=2;
                }
                break;
            case 86:
                {
                alt133=3;
                }
                break;
            case 87:
                {
                alt133=4;
                }
                break;
            case 88:
                {
                alt133=5;
                }
                break;
            case 89:
                {
                alt133=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 133, 0, input);

                throw nvae;
            }

            switch (alt133) {
                case 1 :
                    // InternalSM2.g:4915:3: (enumLiteral_0= 'seconds' )
                    {
                    // InternalSM2.g:4915:3: (enumLiteral_0= 'seconds' )
                    // InternalSM2.g:4916:4: enumLiteral_0= 'seconds'
                    {
                    enumLiteral_0=(Token)match(input,84,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getSECONDSEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getTimeUnitAccess().getSECONDSEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4923:3: (enumLiteral_1= 'minutes' )
                    {
                    // InternalSM2.g:4923:3: (enumLiteral_1= 'minutes' )
                    // InternalSM2.g:4924:4: enumLiteral_1= 'minutes'
                    {
                    enumLiteral_1=(Token)match(input,85,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getMINUTESEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getTimeUnitAccess().getMINUTESEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:4931:3: (enumLiteral_2= 'hours' )
                    {
                    // InternalSM2.g:4931:3: (enumLiteral_2= 'hours' )
                    // InternalSM2.g:4932:4: enumLiteral_2= 'hours'
                    {
                    enumLiteral_2=(Token)match(input,86,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getHOURSEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getTimeUnitAccess().getHOURSEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:4939:3: (enumLiteral_3= 'days' )
                    {
                    // InternalSM2.g:4939:3: (enumLiteral_3= 'days' )
                    // InternalSM2.g:4940:4: enumLiteral_3= 'days'
                    {
                    enumLiteral_3=(Token)match(input,87,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getDAYSEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getTimeUnitAccess().getDAYSEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:4947:3: (enumLiteral_4= 'weeks' )
                    {
                    // InternalSM2.g:4947:3: (enumLiteral_4= 'weeks' )
                    // InternalSM2.g:4948:4: enumLiteral_4= 'weeks'
                    {
                    enumLiteral_4=(Token)match(input,88,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getWEEKSEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getTimeUnitAccess().getWEEKSEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:4955:3: (enumLiteral_5= 'years' )
                    {
                    // InternalSM2.g:4955:3: (enumLiteral_5= 'years' )
                    // InternalSM2.g:4956:4: enumLiteral_5= 'years'
                    {
                    enumLiteral_5=(Token)match(input,89,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getTimeUnitAccess().getYEARSEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getTimeUnitAccess().getYEARSEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTimeUnit"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:4966:1: ruleVisibility returns [Enumerator current=null] : ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) ;
    public final Enumerator ruleVisibility() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalSM2.g:4972:2: ( ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) ) )
            // InternalSM2.g:4973:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            {
            // InternalSM2.g:4973:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) | (enumLiteral_3= 'external' ) )
            int alt134=4;
            switch ( input.LA(1) ) {
            case 44:
                {
                alt134=1;
                }
                break;
            case 90:
                {
                alt134=2;
                }
                break;
            case 45:
                {
                alt134=3;
                }
                break;
            case 91:
                {
                alt134=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 134, 0, input);

                throw nvae;
            }

            switch (alt134) {
                case 1 :
                    // InternalSM2.g:4974:3: (enumLiteral_0= 'public' )
                    {
                    // InternalSM2.g:4974:3: (enumLiteral_0= 'public' )
                    // InternalSM2.g:4975:4: enumLiteral_0= 'public'
                    {
                    enumLiteral_0=(Token)match(input,44,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:4982:3: (enumLiteral_1= 'private' )
                    {
                    // InternalSM2.g:4982:3: (enumLiteral_1= 'private' )
                    // InternalSM2.g:4983:4: enumLiteral_1= 'private'
                    {
                    enumLiteral_1=(Token)match(input,90,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:4990:3: (enumLiteral_2= 'internal' )
                    {
                    // InternalSM2.g:4990:3: (enumLiteral_2= 'internal' )
                    // InternalSM2.g:4991:4: enumLiteral_2= 'internal'
                    {
                    enumLiteral_2=(Token)match(input,45,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:4998:3: (enumLiteral_3= 'external' )
                    {
                    // InternalSM2.g:4998:3: (enumLiteral_3= 'external' )
                    // InternalSM2.g:4999:4: enumLiteral_3= 'external'
                    {
                    enumLiteral_3=(Token)match(input,91,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:5009:1: ruleCoin returns [Enumerator current=null] : ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) ;
    public final Enumerator ruleCoin() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:5015:2: ( ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) )
            // InternalSM2.g:5016:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            {
            // InternalSM2.g:5016:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            int alt135=6;
            switch ( input.LA(1) ) {
            case 92:
                {
                alt135=1;
                }
                break;
            case 93:
                {
                alt135=2;
                }
                break;
            case 94:
                {
                alt135=3;
                }
                break;
            case 95:
                {
                alt135=4;
                }
                break;
            case 96:
                {
                alt135=5;
                }
                break;
            case 97:
                {
                alt135=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 135, 0, input);

                throw nvae;
            }

            switch (alt135) {
                case 1 :
                    // InternalSM2.g:5017:3: (enumLiteral_0= 'ether' )
                    {
                    // InternalSM2.g:5017:3: (enumLiteral_0= 'ether' )
                    // InternalSM2.g:5018:4: enumLiteral_0= 'ether'
                    {
                    enumLiteral_0=(Token)match(input,92,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5025:3: (enumLiteral_1= 'wei' )
                    {
                    // InternalSM2.g:5025:3: (enumLiteral_1= 'wei' )
                    // InternalSM2.g:5026:4: enumLiteral_1= 'wei'
                    {
                    enumLiteral_1=(Token)match(input,93,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5033:3: (enumLiteral_2= 'gwei' )
                    {
                    // InternalSM2.g:5033:3: (enumLiteral_2= 'gwei' )
                    // InternalSM2.g:5034:4: enumLiteral_2= 'gwei'
                    {
                    enumLiteral_2=(Token)match(input,94,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:5041:3: (enumLiteral_3= 'pwei' )
                    {
                    // InternalSM2.g:5041:3: (enumLiteral_3= 'pwei' )
                    // InternalSM2.g:5042:4: enumLiteral_3= 'pwei'
                    {
                    enumLiteral_3=(Token)match(input,95,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:5049:3: (enumLiteral_4= 'finney' )
                    {
                    // InternalSM2.g:5049:3: (enumLiteral_4= 'finney' )
                    // InternalSM2.g:5050:4: enumLiteral_4= 'finney'
                    {
                    enumLiteral_4=(Token)match(input,96,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:5057:3: (enumLiteral_5= 'szabo' )
                    {
                    // InternalSM2.g:5057:3: (enumLiteral_5= 'szabo' )
                    // InternalSM2.g:5058:4: enumLiteral_5= 'szabo'
                    {
                    enumLiteral_5=(Token)match(input,97,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:5068:1: ruleComparationOperator returns [Enumerator current=null] : ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) ;
    public final Enumerator ruleComparationOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2.g:5074:2: ( ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) )
            // InternalSM2.g:5075:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            {
            // InternalSM2.g:5075:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            int alt136=6;
            switch ( input.LA(1) ) {
            case 34:
                {
                alt136=1;
                }
                break;
            case 36:
                {
                alt136=2;
                }
                break;
            case 35:
                {
                alt136=3;
                }
                break;
            case 37:
                {
                alt136=4;
                }
                break;
            case 75:
                {
                alt136=5;
                }
                break;
            case 98:
                {
                alt136=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 136, 0, input);

                throw nvae;
            }

            switch (alt136) {
                case 1 :
                    // InternalSM2.g:5076:3: (enumLiteral_0= '>' )
                    {
                    // InternalSM2.g:5076:3: (enumLiteral_0= '>' )
                    // InternalSM2.g:5077:4: enumLiteral_0= '>'
                    {
                    enumLiteral_0=(Token)match(input,34,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5084:3: (enumLiteral_1= '<' )
                    {
                    // InternalSM2.g:5084:3: (enumLiteral_1= '<' )
                    // InternalSM2.g:5085:4: enumLiteral_1= '<'
                    {
                    enumLiteral_1=(Token)match(input,36,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5092:3: (enumLiteral_2= '>=' )
                    {
                    // InternalSM2.g:5092:3: (enumLiteral_2= '>=' )
                    // InternalSM2.g:5093:4: enumLiteral_2= '>='
                    {
                    enumLiteral_2=(Token)match(input,35,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:5100:3: (enumLiteral_3= '<=' )
                    {
                    // InternalSM2.g:5100:3: (enumLiteral_3= '<=' )
                    // InternalSM2.g:5101:4: enumLiteral_3= '<='
                    {
                    enumLiteral_3=(Token)match(input,37,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:5108:3: (enumLiteral_4= '==' )
                    {
                    // InternalSM2.g:5108:3: (enumLiteral_4= '==' )
                    // InternalSM2.g:5109:4: enumLiteral_4= '=='
                    {
                    enumLiteral_4=(Token)match(input,75,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:5116:3: (enumLiteral_5= '!=' )
                    {
                    // InternalSM2.g:5116:3: (enumLiteral_5= '!=' )
                    // InternalSM2.g:5117:4: enumLiteral_5= '!='
                    {
                    enumLiteral_5=(Token)match(input,98,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:5127:1: ruleLogicalPairOperator returns [Enumerator current=null] : ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) ;
    public final Enumerator ruleLogicalPairOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSM2.g:5133:2: ( ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) )
            // InternalSM2.g:5134:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            {
            // InternalSM2.g:5134:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            int alt137=2;
            int LA137_0 = input.LA(1);

            if ( (LA137_0==99) ) {
                alt137=1;
            }
            else if ( (LA137_0==100) ) {
                alt137=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 137, 0, input);

                throw nvae;
            }
            switch (alt137) {
                case 1 :
                    // InternalSM2.g:5135:3: (enumLiteral_0= '&&' )
                    {
                    // InternalSM2.g:5135:3: (enumLiteral_0= '&&' )
                    // InternalSM2.g:5136:4: enumLiteral_0= '&&'
                    {
                    enumLiteral_0=(Token)match(input,99,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5143:3: (enumLiteral_1= '||' )
                    {
                    // InternalSM2.g:5143:3: (enumLiteral_1= '||' )
                    // InternalSM2.g:5144:4: enumLiteral_1= '||'
                    {
                    enumLiteral_1=(Token)match(input,100,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:5154:1: ruleArithmeticalOperator returns [Enumerator current=null] : ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) ;
    public final Enumerator ruleArithmeticalOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;


        	enterRule();

        try {
            // InternalSM2.g:5160:2: ( ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) ) )
            // InternalSM2.g:5161:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            {
            // InternalSM2.g:5161:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) | (enumLiteral_4= '%' ) )
            int alt138=5;
            switch ( input.LA(1) ) {
            case 101:
                {
                alt138=1;
                }
                break;
            case 102:
                {
                alt138=2;
                }
                break;
            case 103:
                {
                alt138=3;
                }
                break;
            case 104:
                {
                alt138=4;
                }
                break;
            case 105:
                {
                alt138=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 138, 0, input);

                throw nvae;
            }

            switch (alt138) {
                case 1 :
                    // InternalSM2.g:5162:3: (enumLiteral_0= '+' )
                    {
                    // InternalSM2.g:5162:3: (enumLiteral_0= '+' )
                    // InternalSM2.g:5163:4: enumLiteral_0= '+'
                    {
                    enumLiteral_0=(Token)match(input,101,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:5170:3: (enumLiteral_1= '-' )
                    {
                    // InternalSM2.g:5170:3: (enumLiteral_1= '-' )
                    // InternalSM2.g:5171:4: enumLiteral_1= '-'
                    {
                    enumLiteral_1=(Token)match(input,102,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:5178:3: (enumLiteral_2= '*' )
                    {
                    // InternalSM2.g:5178:3: (enumLiteral_2= '*' )
                    // InternalSM2.g:5179:4: enumLiteral_2= '*'
                    {
                    enumLiteral_2=(Token)match(input,103,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:5186:3: (enumLiteral_3= '/' )
                    {
                    // InternalSM2.g:5186:3: (enumLiteral_3= '/' )
                    // InternalSM2.g:5187:4: enumLiteral_3= '/'
                    {
                    enumLiteral_3=(Token)match(input,104,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:5194:3: (enumLiteral_4= '%' )
                    {
                    // InternalSM2.g:5194:3: (enumLiteral_4= '%' )
                    // InternalSM2.g:5195:4: enumLiteral_4= '%'
                    {
                    enumLiteral_4=(Token)match(input,105,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmeticalOperator"

    // $ANTLR start synpred2_InternalSM2
    public final void synpred2_InternalSM2_fragment() throws RecognitionException {   
        // InternalSM2.g:4767:4: ( '*/' )
        // InternalSM2.g:4767:5: '*/'
        {
        match(input,79,FOLLOW_2); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred2_InternalSM2

    // Delegated rules

    public final boolean synpred2_InternalSM2() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred2_InternalSM2_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA34 dfa34 = new DFA34(this);
    protected DFA62 dfa62 = new DFA62(this);
    protected DFA101 dfa101 = new DFA101(this);
    protected DFA113 dfa113 = new DFA113(this);
    static final String dfa_1s = "\70\uffff";
    static final String dfa_2s = "\1\63\1\12\1\13\1\5\1\12\1\uffff\1\11\2\4\1\5\1\4\1\uffff\1\16\1\5\1\4\1\6\1\4\1\16\1\5\3\4\1\16\1\4\1\5\1\4\1\5\1\6\1\4\1\16\1\5\3\4\1\16\1\4\1\5\1\4\1\5\1\6\1\4\1\17\1\5\3\4\1\uffff\1\4\2\5\1\6\1\4\1\11\1\4\1\5\1\11";
    static final String dfa_3s = "\1\63\1\12\1\13\2\103\1\uffff\1\133\1\65\1\20\1\66\1\4\1\uffff\1\16\1\103\1\65\1\103\2\16\1\66\1\16\1\65\1\4\1\16\1\65\1\103\1\65\2\103\2\16\1\66\1\16\1\65\1\4\1\16\1\65\1\103\1\65\2\103\1\16\1\17\1\67\1\16\1\65\1\4\1\uffff\1\65\3\103\1\16\1\133\1\65\1\103\1\133";
    static final String dfa_4s = "\5\uffff\1\1\5\uffff\1\2\42\uffff\1\3\11\uffff";
    static final String dfa_5s = "\70\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\4\4\uffff\1\5\51\uffff\1\6\1\uffff\2\5\5\uffff\7\5",
            "\1\5\51\uffff\1\6\1\uffff\2\5\5\uffff\7\5",
            "",
            "\1\5\1\7\41\uffff\2\5\14\uffff\2\5\36\uffff\2\5",
            "\1\11\60\uffff\1\10",
            "\1\5\4\uffff\1\5\4\uffff\1\12\1\uffff\1\5",
            "\1\13\60\uffff\1\14",
            "\1\15",
            "",
            "\1\16",
            "\1\17\1\5\3\uffff\1\5\51\uffff\1\5\1\uffff\1\20\1\5\5\uffff\7\5",
            "\1\22\60\uffff\1\21",
            "\1\5\3\uffff\1\5\51\uffff\1\5\1\uffff\1\23\1\5\5\uffff\7\5",
            "\1\5\11\uffff\1\24",
            "\1\25",
            "\1\13\60\uffff\1\26",
            "\1\5\11\uffff\1\27",
            "\1\30\60\uffff\1\21",
            "\1\22",
            "\1\31",
            "\1\32\60\uffff\1\13",
            "\1\33\1\5\3\uffff\1\5\51\uffff\1\5\1\uffff\1\34\1\5\5\uffff\7\5",
            "\1\36\60\uffff\1\35",
            "\1\33\1\5\3\uffff\1\5\51\uffff\1\5\1\uffff\1\37\1\5\5\uffff\7\5",
            "\1\5\3\uffff\1\5\51\uffff\1\5\1\uffff\1\37\1\5\5\uffff\7\5",
            "\1\5\11\uffff\1\40",
            "\1\41",
            "\1\13\60\uffff\1\42",
            "\1\5\11\uffff\1\43",
            "\1\44\60\uffff\1\35",
            "\1\36",
            "\1\45",
            "\1\46\60\uffff\1\13",
            "\1\47\1\5\3\uffff\1\5\51\uffff\1\5\1\uffff\1\50\1\5\5\uffff\7\5",
            "\1\52\60\uffff\1\51",
            "\1\47\1\5\3\uffff\1\5\51\uffff\1\5\1\uffff\1\53\1\5\5\uffff\7\5",
            "\1\5\3\uffff\1\5\51\uffff\1\5\1\uffff\1\53\1\5\5\uffff\7\5",
            "\1\5\11\uffff\1\54",
            "\1\55",
            "\1\13\60\uffff\1\56\1\13",
            "\1\5\11\uffff\1\57",
            "\1\60\60\uffff\1\51",
            "\1\52",
            "",
            "\1\61\60\uffff\1\13",
            "\1\62\1\5\3\uffff\1\5\51\uffff\1\5\1\uffff\1\63\1\64\5\uffff\7\5",
            "\1\62\1\5\3\uffff\1\5\51\uffff\1\5\1\uffff\1\5\1\64\5\uffff\7\5",
            "\1\5\3\uffff\1\5\51\uffff\1\5\1\uffff\1\5\1\64\5\uffff\7\5",
            "\1\5\11\uffff\1\65",
            "\2\5\41\uffff\2\5\12\uffff\1\13\1\uffff\2\5\36\uffff\2\5",
            "\1\66\60\uffff\1\56",
            "\2\5\3\uffff\1\5\51\uffff\1\5\1\uffff\1\5\1\67\5\uffff\7\5",
            "\2\5\41\uffff\2\5\12\uffff\1\56\1\uffff\2\5\36\uffff\2\5"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA34 extends DFA {

        public DFA34(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 34;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "1405:2: (this_PersonalizedStruct_0= rulePersonalizedStruct | this_User_1= ruleUser | this_Company_2= ruleCompany )";
        }
    }
    static final String dfa_7s = "\u00f2\uffff";
    static final String dfa_8s = "\1\2\1\5\115\uffff\1\5\50\uffff\1\5\154\uffff\1\5\3\uffff\1\5\6\uffff\2\5";
    static final String dfa_9s = "\2\5\1\uffff\1\12\1\4\1\uffff\1\13\1\5\1\12\1\11\1\4\11\11\1\4\1\11\1\7\1\74\4\12\1\4\1\5\1\11\1\7\1\74\4\12\1\65\1\11\1\7\1\74\4\12\2\65\1\11\1\7\1\74\4\12\1\65\1\11\1\7\1\74\4\12\1\65\1\11\1\7\1\74\4\12\1\65\1\4\1\5\1\11\1\7\1\74\2\11\1\6\1\5\2\11\1\7\1\74\2\11\1\4\1\11\1\7\1\74\2\11\2\4\1\11\1\7\1\74\2\11\1\4\1\11\1\7\1\74\2\11\1\4\1\11\1\7\1\74\2\11\4\4\1\5\1\16\1\66\2\11\1\4\2\11\1\4\1\5\2\11\1\4\1\5\1\4\2\11\1\4\1\5\2\11\3\4\1\5\2\11\3\4\3\5\1\6\1\4\1\16\1\4\3\6\1\5\1\6\1\5\1\6\1\4\1\6\1\4\1\16\1\5\7\4\1\16\1\66\1\16\2\5\2\4\1\16\1\4\1\6\1\4\1\5\1\16\1\5\4\4\1\66\2\16\1\5\1\4\1\5\1\16\2\4\1\5\1\6\2\4\1\17\1\5\2\4\1\17\1\5\1\4\1\67\1\70\1\16\1\4\1\5\3\4\1\5\1\6\1\11\1\4\1\11\1\5\1\16\1\67\3\4\1\6\1\5\1\4\1\70\1\5\2\4\2\11\1\6\2\4\1\5\1\4";
    static final String dfa_10s = "\2\116\1\uffff\1\12\1\63\1\uffff\1\13\2\103\1\133\1\16\11\133\1\65\1\133\1\7\1\74\4\12\1\4\1\103\1\133\1\7\1\74\4\12\1\65\1\133\1\7\1\74\4\12\2\65\1\133\1\7\1\74\4\12\1\65\1\133\1\7\1\74\4\12\1\65\1\133\1\7\1\74\4\12\1\65\1\20\1\66\1\133\1\7\1\74\2\133\1\103\1\116\2\133\1\7\1\74\2\133\1\11\1\133\1\7\1\74\2\133\2\20\1\133\1\7\1\74\2\133\1\22\1\133\1\7\1\74\2\133\1\20\1\133\1\7\1\74\2\133\1\20\3\4\1\103\1\16\1\66\2\133\1\116\2\133\1\4\1\103\2\133\1\4\1\103\1\4\2\133\1\4\1\103\2\133\3\4\1\103\2\133\3\4\4\103\1\65\1\16\1\133\7\103\1\16\2\103\1\16\1\66\2\65\2\103\1\65\1\16\1\4\1\16\1\66\1\16\1\66\1\103\2\65\1\16\1\4\1\103\1\16\1\103\1\16\1\66\1\65\1\16\1\65\1\4\1\66\2\16\1\66\1\65\1\103\1\16\1\65\1\4\2\103\1\16\1\65\1\17\1\67\1\16\1\65\1\17\1\67\1\4\1\67\1\70\1\16\1\65\1\103\1\4\2\65\2\103\1\133\1\16\1\20\1\6\1\16\1\67\1\65\2\4\1\6\1\116\1\4\1\70\1\103\1\116\1\65\1\133\1\20\1\6\2\4\2\116";
    static final String dfa_11s = "\2\uffff\1\2\2\uffff\1\1\u00ec\uffff";
    static final String dfa_12s = "\u00f2\uffff}>";
    static final String[] dfa_13s = {
            "\1\1\1\2\2\uffff\2\2\1\uffff\1\2\1\uffff\1\2\1\uffff\1\2\2\uffff\1\2\27\uffff\1\2\2\uffff\2\2\1\uffff\1\2\1\uffff\2\2\1\uffff\2\2\1\uffff\1\2\3\uffff\7\2\4\uffff\1\2\4\uffff\2\2",
            "\1\4\1\5\2\uffff\2\5\1\uffff\1\5\1\uffff\1\5\1\uffff\1\5\2\uffff\1\5\27\uffff\1\5\2\uffff\2\5\1\uffff\1\5\1\uffff\1\3\1\5\1\uffff\2\5\1\uffff\1\5\3\uffff\7\5\4\uffff\1\5\4\uffff\2\5",
            "",
            "\1\6",
            "\1\2\1\5\4\uffff\1\2\50\uffff\1\5",
            "",
            "\1\7",
            "\1\10\4\uffff\1\23\51\uffff\1\11\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\23\51\uffff\1\11\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\27\1\24\41\uffff\1\30\1\32\14\uffff\1\25\1\26\36\uffff\1\31\1\33",
            "\1\35\11\uffff\1\34",
            "\1\40\1\45\41\uffff\1\41\1\43\14\uffff\1\36\1\37\36\uffff\1\42\1\44",
            "\1\40\1\45\41\uffff\1\41\1\43\14\uffff\1\36\1\37\36\uffff\1\42\1\44",
            "\1\40\1\45\41\uffff\1\41\1\43\14\uffff\1\36\1\37\36\uffff\1\42\1\44",
            "\1\50\1\55\41\uffff\1\51\1\53\14\uffff\1\46\1\47\36\uffff\1\52\1\54",
            "\1\27\1\56\41\uffff\1\30\1\32\14\uffff\1\25\1\26\36\uffff\1\31\1\33",
            "\1\61\1\66\41\uffff\1\62\1\64\14\uffff\1\57\1\60\36\uffff\1\63\1\65",
            "\1\71\1\76\41\uffff\1\72\1\74\14\uffff\1\67\1\70\36\uffff\1\73\1\75",
            "\1\71\1\76\41\uffff\1\72\1\74\14\uffff\1\67\1\70\36\uffff\1\73\1\75",
            "\1\101\1\106\41\uffff\1\102\1\104\14\uffff\1\77\1\100\36\uffff\1\103\1\105",
            "\1\110\60\uffff\1\107",
            "\1\113\1\56\41\uffff\1\30\1\32\14\uffff\1\111\1\112\36\uffff\1\31\1\33",
            "\1\114",
            "\1\115",
            "\1\56",
            "\1\56",
            "\1\56",
            "\1\56",
            "\1\35",
            "\1\116\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\123\1\45\41\uffff\1\41\1\43\14\uffff\1\121\1\122\36\uffff\1\42\1\44",
            "\1\124",
            "\1\125",
            "\1\45",
            "\1\45",
            "\1\45",
            "\1\45",
            "\1\126",
            "\1\131\1\55\41\uffff\1\51\1\53\14\uffff\1\127\1\130\36\uffff\1\52\1\54",
            "\1\132",
            "\1\133",
            "\1\55",
            "\1\55",
            "\1\55",
            "\1\55",
            "\1\134",
            "\1\135",
            "\1\140\1\66\41\uffff\1\62\1\64\14\uffff\1\136\1\137\36\uffff\1\63\1\65",
            "\1\141",
            "\1\142",
            "\1\66",
            "\1\66",
            "\1\66",
            "\1\66",
            "\1\143",
            "\1\146\1\76\41\uffff\1\72\1\74\14\uffff\1\144\1\145\36\uffff\1\73\1\75",
            "\1\147",
            "\1\150",
            "\1\76",
            "\1\76",
            "\1\76",
            "\1\76",
            "\1\151",
            "\1\154\1\106\41\uffff\1\102\1\104\14\uffff\1\152\1\153\36\uffff\1\103\1\105",
            "\1\155",
            "\1\156",
            "\1\106",
            "\1\106",
            "\1\106",
            "\1\106",
            "\1\157",
            "\1\163\4\uffff\1\161\4\uffff\1\160\1\uffff\1\162",
            "\1\165\60\uffff\1\164",
            "\1\113\1\56\41\uffff\1\30\1\32\14\uffff\1\111\1\112\36\uffff\1\31\1\33",
            "\1\166",
            "\1\167",
            "\1\113\1\56\41\uffff\1\30\1\32\14\uffff\1\111\1\112\36\uffff\1\31\1\33",
            "\1\113\1\56\41\uffff\1\30\1\32\14\uffff\1\111\1\112\36\uffff\1\31\1\33",
            "\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\170\1\5\3\uffff\1\5\40\uffff\1\5\2\uffff\2\5\1\uffff\1\5\1\uffff\1\3\1\5\1\uffff\2\5\1\uffff\1\5\3\uffff\7\5\4\uffff\1\5\4\uffff\2\5",
            "\1\27\1\56\41\uffff\1\30\1\32\14\uffff\1\25\1\26\36\uffff\1\31\1\33",
            "\1\123\1\45\41\uffff\1\41\1\43\14\uffff\1\121\1\122\36\uffff\1\42\1\44",
            "\1\171",
            "\1\172",
            "\1\123\1\45\41\uffff\1\41\1\43\14\uffff\1\121\1\122\36\uffff\1\42\1\44",
            "\1\123\1\45\41\uffff\1\41\1\43\14\uffff\1\121\1\122\36\uffff\1\42\1\44",
            "\1\174\4\uffff\1\173",
            "\1\131\1\55\41\uffff\1\51\1\53\14\uffff\1\127\1\130\36\uffff\1\52\1\54",
            "\1\175",
            "\1\176",
            "\1\131\1\55\41\uffff\1\51\1\53\14\uffff\1\127\1\130\36\uffff\1\52\1\54",
            "\1\131\1\55\41\uffff\1\51\1\53\14\uffff\1\127\1\130\36\uffff\1\52\1\54",
            "\1\u0080\13\uffff\1\177",
            "\1\163\4\uffff\1\161\4\uffff\1\u0081\1\uffff\1\162",
            "\1\140\1\66\41\uffff\1\62\1\64\14\uffff\1\136\1\137\36\uffff\1\63\1\65",
            "\1\u0082",
            "\1\u0083",
            "\1\140\1\66\41\uffff\1\62\1\64\14\uffff\1\136\1\137\36\uffff\1\63\1\65",
            "\1\140\1\66\41\uffff\1\62\1\64\14\uffff\1\136\1\137\36\uffff\1\63\1\65",
            "\1\u0085\15\uffff\1\u0084",
            "\1\146\1\76\41\uffff\1\72\1\74\14\uffff\1\144\1\145\36\uffff\1\73\1\75",
            "\1\u0086",
            "\1\u0087",
            "\1\146\1\76\41\uffff\1\72\1\74\14\uffff\1\144\1\145\36\uffff\1\73\1\75",
            "\1\146\1\76\41\uffff\1\72\1\74\14\uffff\1\144\1\145\36\uffff\1\73\1\75",
            "\1\u008b\4\uffff\1\u0089\4\uffff\1\u0088\1\uffff\1\u008a",
            "\1\154\1\106\41\uffff\1\102\1\104\14\uffff\1\152\1\153\36\uffff\1\103\1\105",
            "\1\u008c",
            "\1\u008d",
            "\1\154\1\106\41\uffff\1\102\1\104\14\uffff\1\152\1\153\36\uffff\1\103\1\105",
            "\1\154\1\106\41\uffff\1\102\1\104\14\uffff\1\152\1\153\36\uffff\1\103\1\105",
            "\1\u0091\4\uffff\1\u008f\4\uffff\1\u008e\1\uffff\1\u0090",
            "\1\u0092",
            "\1\u0093",
            "\1\u0093",
            "\1\u0094\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\u0095",
            "\1\u0096",
            "\1\113\1\56\41\uffff\1\30\1\32\14\uffff\1\111\1\112\36\uffff\1\31\1\33",
            "\1\113\1\56\41\uffff\1\30\1\32\14\uffff\1\111\1\112\36\uffff\1\31\1\33",
            "\2\2\1\5\3\uffff\1\u0097\40\uffff\1\5\2\uffff\2\5\1\uffff\1\5\1\uffff\1\3\1\5\1\uffff\2\5\1\uffff\1\5\3\uffff\7\5\4\uffff\1\5\4\uffff\2\5",
            "\1\123\1\45\41\uffff\1\41\1\43\14\uffff\1\121\1\122\36\uffff\1\42\1\44",
            "\1\123\1\45\41\uffff\1\41\1\43\14\uffff\1\121\1\122\36\uffff\1\42\1\44",
            "\1\174",
            "\1\u0098\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\131\1\55\41\uffff\1\51\1\53\14\uffff\1\127\1\130\36\uffff\1\52\1\54",
            "\1\131\1\55\41\uffff\1\51\1\53\14\uffff\1\127\1\130\36\uffff\1\52\1\54",
            "\1\u0080",
            "\1\u0099\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\163",
            "\1\140\1\66\41\uffff\1\62\1\64\14\uffff\1\136\1\137\36\uffff\1\63\1\65",
            "\1\140\1\66\41\uffff\1\62\1\64\14\uffff\1\136\1\137\36\uffff\1\63\1\65",
            "\1\u0085",
            "\1\u009a\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\146\1\76\41\uffff\1\72\1\74\14\uffff\1\144\1\145\36\uffff\1\73\1\75",
            "\1\146\1\76\41\uffff\1\72\1\74\14\uffff\1\144\1\145\36\uffff\1\73\1\75",
            "\1\u008b",
            "\1\u009b",
            "\1\u009b",
            "\1\u009c\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\154\1\106\41\uffff\1\102\1\104\14\uffff\1\152\1\153\36\uffff\1\103\1\105",
            "\1\154\1\106\41\uffff\1\102\1\104\14\uffff\1\152\1\153\36\uffff\1\103\1\105",
            "\1\u0091",
            "\1\u009d",
            "\1\u009d",
            "\1\u009e\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\u00a0\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\u009f\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\u00a1\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\u00a3\60\uffff\1\u00a2",
            "\1\u00a4",
            "\1\2\4\uffff\1\5\1\u00a5\41\uffff\2\5\14\uffff\2\5\36\uffff\2\5",
            "\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\u00a6\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\u00a7\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\35\11\uffff\1\u00a8",
            "\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\u00a9\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\163\1\uffff\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\u00aa",
            "\1\u00ac\60\uffff\1\u00ab",
            "\1\u00ae\60\uffff\1\u00ad",
            "\1\2\5\uffff\1\2\52\uffff\1\5",
            "\1\u008b\1\uffff\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\u0091\1\uffff\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\u00af\60\uffff\1\u00a2",
            "\1\35\11\uffff\1\u00b0",
            "\1\u00a3",
            "\1\u00b1",
            "\1\u00b2",
            "\1\u00b3",
            "\1\u00ac\60\uffff\1\u00b2",
            "\1\u00b4\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\u00b5\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\u00b6\60\uffff\1\u00ad",
            "\1\u00b8\60\uffff\1\u00b7",
            "\1\u00b9",
            "\1\u00ae",
            "\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\u00ba\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\35\11\uffff\1\u00bb",
            "\1\u00b4\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\u00ba\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\u00bc",
            "\1\u00bd\60\uffff\1\u00be",
            "\1\u00c0\60\uffff\1\u00bf",
            "\1\35\11\uffff\1\u00c1",
            "\1\u00c2\60\uffff\1\u00b7",
            "\1\u00b8",
            "\1\u00c3",
            "\1\u00c4",
            "\1\u00c5",
            "\1\u00bd\60\uffff\1\u00c3",
            "\1\u00c6\60\uffff\1\u00bf",
            "\1\u00c7\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\u00c8\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\u00c9",
            "\1\u00cb\60\uffff\1\u00ca",
            "\1\u00c0",
            "\1\u00c7\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\u00cc\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\u00cc\1\16\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\35\11\uffff\1\u00cd",
            "\1\u00cf\60\uffff\1\u00ce",
            "\1\u00d0",
            "\1\u00d1\60\uffff\1\u00d3\1\u00d2",
            "\1\35\11\uffff\1\u00d4",
            "\1\u00d5\60\uffff\1\u00ca",
            "\1\u00d6",
            "\1\u00d1\61\uffff\1\u00d2",
            "\1\u00cb",
            "\1\u00d2",
            "\1\u00d7",
            "\1\u00d8",
            "\1\u00d9\60\uffff\1\u00ce",
            "\1\u00da\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\u00dc\1\u00db\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\u00cf",
            "\1\u00de\60\uffff\1\u00dd",
            "\1\u00e0\60\uffff\1\u00df",
            "\1\u00da\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\u00db\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\u00db\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\1\50\1\55\41\uffff\1\51\1\53\12\uffff\1\u00d7\1\uffff\1\46\1\47\36\uffff\1\52\1\54",
            "\1\35\11\uffff\1\u00e1",
            "\1\u00e2\6\uffff\1\u00e3",
            "\1\u00e4\1\u00e5",
            "\1\u00e6",
            "\1\u00e7",
            "\1\u00e8\60\uffff\1\u00df",
            "\1\u00de",
            "\1\u00de",
            "\1\u00e5",
            "\1\u00e9\1\5\3\uffff\1\5\40\uffff\1\5\2\uffff\2\5\1\uffff\1\5\1\uffff\1\3\1\5\1\uffff\2\5\1\uffff\1\5\3\uffff\7\5\4\uffff\1\5\4\uffff\2\5",
            "\1\u00e0",
            "\1\u00ea",
            "\1\116\1\117\3\uffff\1\23\51\uffff\1\120\1\uffff\1\12\1\u00eb\5\uffff\1\13\1\14\1\15\1\20\1\17\1\21\1\22",
            "\2\2\1\5\3\uffff\1\u0097\40\uffff\1\5\2\uffff\2\5\1\uffff\1\5\1\uffff\1\3\1\5\1\uffff\2\5\1\uffff\1\5\3\uffff\7\5\4\uffff\1\5\4\uffff\2\5",
            "\1\u00ed\60\uffff\1\u00ec",
            "\1\50\1\55\41\uffff\1\51\1\53\12\uffff\1\u00ea\1\uffff\1\46\1\47\36\uffff\1\52\1\54",
            "\1\u00ee\6\uffff\1\u00ef",
            "\1\u00f0",
            "\1\u00ed",
            "\1\u00ed",
            "\1\u00f1\1\5\3\uffff\1\5\40\uffff\1\5\2\uffff\2\5\1\uffff\1\5\1\uffff\1\3\1\5\1\uffff\2\5\1\uffff\1\5\3\uffff\7\5\4\uffff\1\5\4\uffff\2\5",
            "\2\2\1\5\3\uffff\1\u0097\40\uffff\1\5\2\uffff\2\5\1\uffff\1\5\1\uffff\1\3\1\5\1\uffff\2\5\1\uffff\1\5\3\uffff\7\5\4\uffff\1\5\4\uffff\2\5"
    };

    static final short[] dfa_7 = DFA.unpackEncodedString(dfa_7s);
    static final short[] dfa_8 = DFA.unpackEncodedString(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final char[] dfa_10 = DFA.unpackEncodedStringToUnsignedChars(dfa_10s);
    static final short[] dfa_11 = DFA.unpackEncodedString(dfa_11s);
    static final short[] dfa_12 = DFA.unpackEncodedString(dfa_12s);
    static final short[][] dfa_13 = unpackEncodedStringArray(dfa_13s);

    class DFA62 extends DFA {

        public DFA62(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 62;
            this.eot = dfa_7;
            this.eof = dfa_8;
            this.min = dfa_9;
            this.max = dfa_10;
            this.accept = dfa_11;
            this.special = dfa_12;
            this.transition = dfa_13;
        }
        public String getDescription() {
            return "2153:3: (this_EOLINE_7= RULE_EOLINE )?";
        }
    }
    static final String dfa_14s = "\22\uffff";
    static final String dfa_15s = "\1\11\1\14\1\uffff\1\11\1\42\2\4\6\11\1\5\1\uffff\2\4\1\42";
    static final String dfa_16s = "\1\106\1\14\1\uffff\1\20\3\142\6\20\1\5\1\uffff\2\141\1\142";
    static final String dfa_17s = "\2\uffff\1\2\13\uffff\1\1\3\uffff";
    static final String dfa_18s = "\22\uffff}>";
    static final String[] dfa_19s = {
            "\2\2\1\uffff\1\2\1\uffff\1\2\1\uffff\1\2\2\uffff\1\2\35\uffff\1\2\1\uffff\2\2\1\uffff\2\2\1\uffff\1\2\3\uffff\7\2\2\uffff\1\1",
            "\1\3",
            "",
            "\1\5\4\uffff\1\4\1\uffff\1\6",
            "\1\7\1\11\1\10\1\12\45\uffff\1\13\26\uffff\1\14",
            "\1\15\35\uffff\1\7\1\11\1\10\1\12\45\uffff\1\13\26\uffff\1\14",
            "\1\15\35\uffff\1\7\1\11\1\10\1\12\45\uffff\1\13\26\uffff\1\14",
            "\1\17\4\uffff\1\16\1\uffff\1\20",
            "\1\17\4\uffff\1\16\1\uffff\1\20",
            "\1\17\4\uffff\1\16\1\uffff\1\20",
            "\1\17\4\uffff\1\16\1\uffff\1\20",
            "\1\17\4\uffff\1\16\1\uffff\1\20",
            "\1\17\4\uffff\1\16\1\uffff\1\20",
            "\1\21",
            "",
            "\1\16\10\uffff\1\16\116\uffff\6\2",
            "\1\16\10\uffff\1\16\116\uffff\6\2",
            "\1\7\1\11\1\10\1\12\45\uffff\1\13\26\uffff\1\14"
    };

    static final short[] dfa_14 = DFA.unpackEncodedString(dfa_14s);
    static final char[] dfa_15 = DFA.unpackEncodedStringToUnsignedChars(dfa_15s);
    static final char[] dfa_16 = DFA.unpackEncodedStringToUnsignedChars(dfa_16s);
    static final short[] dfa_17 = DFA.unpackEncodedString(dfa_17s);
    static final short[] dfa_18 = DFA.unpackEncodedString(dfa_18s);
    static final short[][] dfa_19 = unpackEncodedStringArray(dfa_19s);

    class DFA101 extends DFA {

        public DFA101(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 101;
            this.eot = dfa_14;
            this.eof = dfa_14;
            this.min = dfa_15;
            this.max = dfa_16;
            this.accept = dfa_17;
            this.special = dfa_18;
            this.transition = dfa_19;
        }
        public String getDescription() {
            return "3573:3: ( (lv_restriction_4_0= ruleRestriction ) )?";
        }
    }
    static final String dfa_20s = "\21\uffff";
    static final String dfa_21s = "\2\uffff\2\4\15\uffff";
    static final String dfa_22s = "\2\11\2\4\1\uffff\2\145\2\uffff\5\11\2\15\1\uffff";
    static final String dfa_23s = "\2\20\2\151\1\uffff\2\151\2\uffff\5\20\2\142\1\uffff";
    static final String dfa_24s = "\4\uffff\1\3\2\uffff\1\4\1\1\7\uffff\1\2";
    static final String dfa_25s = "\21\uffff}>";
    static final String[] dfa_26s = {
            "\1\2\2\uffff\1\1\1\uffff\1\4\1\uffff\1\3",
            "\1\5\6\uffff\1\6",
            "\3\4\2\uffff\1\4\2\uffff\3\4\1\uffff\1\4\103\uffff\6\7\13\uffff\5\10",
            "\3\4\2\uffff\1\4\2\uffff\3\4\1\uffff\1\4\124\uffff\5\10",
            "",
            "\1\11\1\12\1\13\1\14\1\15",
            "\1\11\1\12\1\13\1\14\1\15",
            "",
            "",
            "\1\16\6\uffff\1\17",
            "\1\16\6\uffff\1\17",
            "\1\16\6\uffff\1\17",
            "\1\16\6\uffff\1\17",
            "\1\16\6\uffff\1\17",
            "\1\10\24\uffff\4\20\45\uffff\1\20\26\uffff\1\20",
            "\1\10\24\uffff\4\20\45\uffff\1\20\26\uffff\1\20",
            ""
    };

    static final short[] dfa_20 = DFA.unpackEncodedString(dfa_20s);
    static final short[] dfa_21 = DFA.unpackEncodedString(dfa_21s);
    static final char[] dfa_22 = DFA.unpackEncodedStringToUnsignedChars(dfa_22s);
    static final char[] dfa_23 = DFA.unpackEncodedStringToUnsignedChars(dfa_23s);
    static final short[] dfa_24 = DFA.unpackEncodedString(dfa_24s);
    static final short[] dfa_25 = DFA.unpackEncodedString(dfa_25s);
    static final short[][] dfa_26 = unpackEncodedStringArray(dfa_26s);

    class DFA113 extends DFA {

        public DFA113(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 113;
            this.eot = dfa_20;
            this.eof = dfa_21;
            this.min = dfa_22;
            this.max = dfa_23;
            this.accept = dfa_24;
            this.special = dfa_25;
            this.transition = dfa_26;
        }
        public String getDescription() {
            return "3965:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_ArithmethicalLogicalExpression_1= ruleArithmethicalLogicalExpression | this_SyntaxExpression_2= ruleSyntaxExpression | this_TimeExpression_3= ruleTimeExpression )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000E00000000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000034000000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000003000000002L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000008000000010L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0200000000000020L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0008000000000020L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000000410L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000040000000800L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0xE2DAC80000000422L,0x000000000000610FL});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0xE2DAC80000000402L,0x000000000000610FL});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000C00000000002L,0x0000000000006100L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000800000000002L,0x0000000000006100L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000000002L,0x0000000000006100L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000000002L,0x0000000000006000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000300000000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000000440L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0xE050000000002000L,0x00000000000E000BL});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000000095220L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0001000000000020L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0xE050000000000000L,0x00000000000E000BL});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0xE050000000000400L,0x00000000000E000BL});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000300000000400L,0x000000000C000000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0xE0D0000000000420L,0x000000000000000FL});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0xE0D0000000000400L,0x000000000000000FL});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0xE0D0000000000440L,0x000000000000000FL});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0010000000000020L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0020000000000010L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0040000000000020L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0080000000000020L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0100000000000000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0000000000010200L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0000000000000060L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0000000000024040L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0000000000004040L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0C00000000000202L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x1000000000000000L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0000000000004010L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0C00300000000600L,0x000000000C000000L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x0000000000000210L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x0000000000010010L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x0000000000040010L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x0000000000014210L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0C00000000000600L,0x0000000000000030L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0000000000000400L,0x0000000000000030L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x0000000000014200L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x0000003C00000000L,0x0000000400000800L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x0000000000000000L,0x00000003F0000000L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x0000000000000800L,0x0000000000000080L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0xE2DA000000095620L,0x000000000000004FL});
    public static final BitSet FOLLOW_73 = new BitSet(new long[]{0xE2DA000000095620L,0x000000000000000FL});
    public static final BitSet FOLLOW_74 = new BitSet(new long[]{0x0000000000095260L});
    public static final BitSet FOLLOW_75 = new BitSet(new long[]{0x0000000000002400L});
    public static final BitSet FOLLOW_76 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L});
    public static final BitSet FOLLOW_77 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_78 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_79 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_80 = new BitSet(new long[]{0xE050000000095220L,0x00000000000E000BL});
    public static final BitSet FOLLOW_81 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_82 = new BitSet(new long[]{0x0000000000000000L,0x000003E000000000L});
    public static final BitSet FOLLOW_83 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_84 = new BitSet(new long[]{0x0000000000011200L});
    public static final BitSet FOLLOW_85 = new BitSet(new long[]{0x0000000000000000L,0x0000000003F00000L});
    public static final BitSet FOLLOW_86 = new BitSet(new long[]{0x0000000000095220L,0x0000000000010000L});
    public static final BitSet FOLLOW_87 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_88 = new BitSet(new long[]{0x0000000003E04000L,0x0000000000008000L});
    public static final BitSet FOLLOW_89 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});

}