package org.xtext.ide.contentassist.antlr.internal;

// Hack: Use our own Lexer superclass by means of import. 
// Currently there is no other way to specify the superclass for the lexer.
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.Lexer;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSM2Lexer extends Lexer {
    public static final int T__50=50;
    public static final int RULE_OPENPARENTHESIS=18;
    public static final int RULE_EOLINE=14;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_PARAMSLONGCOMENT=8;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int RULE_INT=25;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=26;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int RULE_TITLELONGCOMENT=11;
    public static final int RULE_NOTICELONGCOMENT=12;
    public static final int RULE_EMAIL=20;
    public static final int T__37=37;
    public static final int RULE_OPENKEY=15;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int RULE_CLOSEPARENTHESIS=19;
    public static final int T__35=35;
    public static final int RULE_IF=22;
    public static final int T__36=36;
    public static final int RULE_DOT=17;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_DEVLONGCOMENT=9;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int RULE_FLOAT=6;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__91=91;
    public static final int T__90=90;
    public static final int RULE_SINGLENUMBER=24;
    public static final int RULE_CLOSEKEY=16;
    public static final int RULE_COMMA=21;
    public static final int RULE_RETURNSLONGCOMENT=10;
    public static final int RULE_SEMICOLON=13;
    public static final int RULE_ELSE=23;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_STRING=7;
    public static final int RULE_SL_COMMENT=27;
    public static final int T__77=77;
    public static final int T__78=78;
    public static final int T__79=79;
    public static final int T__73=73;
    public static final int EOF=-1;
    public static final int T__74=74;
    public static final int T__75=75;
    public static final int T__76=76;
    public static final int T__80=80;
    public static final int T__81=81;
    public static final int T__82=82;
    public static final int T__83=83;
    public static final int RULE_WS=28;
    public static final int RULE_ANY_OTHER=29;
    public static final int T__88=88;
    public static final int T__89=89;
    public static final int T__84=84;
    public static final int T__85=85;
    public static final int RULE_INTEGER=5;
    public static final int T__86=86;
    public static final int T__87=87;

    // delegates
    // delegators

    public InternalSM2Lexer() {;} 
    public InternalSM2Lexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public InternalSM2Lexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "InternalSM2.g"; }

    // $ANTLR start "T__30"
    public final void mT__30() throws RecognitionException {
        try {
            int _type = T__30;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:11:7: ( '>' )
            // InternalSM2.g:11:9: '>'
            {
            match('>'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__30"

    // $ANTLR start "T__31"
    public final void mT__31() throws RecognitionException {
        try {
            int _type = T__31;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:12:7: ( '>=' )
            // InternalSM2.g:12:9: '>='
            {
            match(">="); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__31"

    // $ANTLR start "T__32"
    public final void mT__32() throws RecognitionException {
        try {
            int _type = T__32;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:13:7: ( '<' )
            // InternalSM2.g:13:9: '<'
            {
            match('<'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__32"

    // $ANTLR start "T__33"
    public final void mT__33() throws RecognitionException {
        try {
            int _type = T__33;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:14:7: ( '<=' )
            // InternalSM2.g:14:9: '<='
            {
            match("<="); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__33"

    // $ANTLR start "T__34"
    public final void mT__34() throws RecognitionException {
        try {
            int _type = T__34;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:15:7: ( 'public' )
            // InternalSM2.g:15:9: 'public'
            {
            match("public"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__34"

    // $ANTLR start "T__35"
    public final void mT__35() throws RecognitionException {
        try {
            int _type = T__35;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:16:7: ( 'internal' )
            // InternalSM2.g:16:9: 'internal'
            {
            match("internal"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__35"

    // $ANTLR start "T__36"
    public final void mT__36() throws RecognitionException {
        try {
            int _type = T__36;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:17:7: ( '[]' )
            // InternalSM2.g:17:9: '[]'
            {
            match("[]"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__36"

    // $ANTLR start "T__37"
    public final void mT__37() throws RecognitionException {
        try {
            int _type = T__37;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:18:7: ( 'local' )
            // InternalSM2.g:18:9: 'local'
            {
            match("local"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__37"

    // $ANTLR start "T__38"
    public final void mT__38() throws RecognitionException {
        try {
            int _type = T__38;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:19:7: ( 'int' )
            // InternalSM2.g:19:9: 'int'
            {
            match("int"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__38"

    // $ANTLR start "T__39"
    public final void mT__39() throws RecognitionException {
        try {
            int _type = T__39;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:20:7: ( 'uint' )
            // InternalSM2.g:20:9: 'uint'
            {
            match("uint"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__39"

    // $ANTLR start "T__40"
    public final void mT__40() throws RecognitionException {
        try {
            int _type = T__40;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:21:7: ( 'uint8' )
            // InternalSM2.g:21:9: 'uint8'
            {
            match("uint8"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__40"

    // $ANTLR start "T__41"
    public final void mT__41() throws RecognitionException {
        try {
            int _type = T__41;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:22:7: ( 'uint256' )
            // InternalSM2.g:22:9: 'uint256'
            {
            match("uint256"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__41"

    // $ANTLR start "T__42"
    public final void mT__42() throws RecognitionException {
        try {
            int _type = T__42;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:23:7: ( 'string' )
            // InternalSM2.g:23:9: 'string'
            {
            match("string"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__42"

    // $ANTLR start "T__43"
    public final void mT__43() throws RecognitionException {
        try {
            int _type = T__43;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:24:7: ( 'address' )
            // InternalSM2.g:24:9: 'address'
            {
            match("address"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__43"

    // $ANTLR start "T__44"
    public final void mT__44() throws RecognitionException {
        try {
            int _type = T__44;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:25:7: ( 'address payable' )
            // InternalSM2.g:25:9: 'address payable'
            {
            match("address payable"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__44"

    // $ANTLR start "T__45"
    public final void mT__45() throws RecognitionException {
        try {
            int _type = T__45;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:26:7: ( 'double' )
            // InternalSM2.g:26:9: 'double'
            {
            match("double"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__45"

    // $ANTLR start "T__46"
    public final void mT__46() throws RecognitionException {
        try {
            int _type = T__46;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:27:7: ( 'bool' )
            // InternalSM2.g:27:9: 'bool'
            {
            match("bool"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__46"

    // $ANTLR start "T__47"
    public final void mT__47() throws RecognitionException {
        try {
            int _type = T__47;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:28:7: ( 'byte' )
            // InternalSM2.g:28:9: 'byte'
            {
            match("byte"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__47"

    // $ANTLR start "T__48"
    public final void mT__48() throws RecognitionException {
        try {
            int _type = T__48;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:29:7: ( 'bytes32' )
            // InternalSM2.g:29:9: 'bytes32'
            {
            match("bytes32"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__48"

    // $ANTLR start "T__49"
    public final void mT__49() throws RecognitionException {
        try {
            int _type = T__49;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:30:7: ( 'private' )
            // InternalSM2.g:30:9: 'private'
            {
            match("private"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__49"

    // $ANTLR start "T__50"
    public final void mT__50() throws RecognitionException {
        try {
            int _type = T__50;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:31:7: ( 'external' )
            // InternalSM2.g:31:9: 'external'
            {
            match("external"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__50"

    // $ANTLR start "T__51"
    public final void mT__51() throws RecognitionException {
        try {
            int _type = T__51;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:32:7: ( 'ether' )
            // InternalSM2.g:32:9: 'ether'
            {
            match("ether"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__51"

    // $ANTLR start "T__52"
    public final void mT__52() throws RecognitionException {
        try {
            int _type = T__52;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:33:7: ( 'wei' )
            // InternalSM2.g:33:9: 'wei'
            {
            match("wei"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__52"

    // $ANTLR start "T__53"
    public final void mT__53() throws RecognitionException {
        try {
            int _type = T__53;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:34:7: ( 'gwei' )
            // InternalSM2.g:34:9: 'gwei'
            {
            match("gwei"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__53"

    // $ANTLR start "T__54"
    public final void mT__54() throws RecognitionException {
        try {
            int _type = T__54;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:35:7: ( 'pwei' )
            // InternalSM2.g:35:9: 'pwei'
            {
            match("pwei"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__54"

    // $ANTLR start "T__55"
    public final void mT__55() throws RecognitionException {
        try {
            int _type = T__55;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:36:7: ( 'finney' )
            // InternalSM2.g:36:9: 'finney'
            {
            match("finney"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__55"

    // $ANTLR start "T__56"
    public final void mT__56() throws RecognitionException {
        try {
            int _type = T__56;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:37:7: ( 'szabo' )
            // InternalSM2.g:37:9: 'szabo'
            {
            match("szabo"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__56"

    // $ANTLR start "T__57"
    public final void mT__57() throws RecognitionException {
        try {
            int _type = T__57;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:38:7: ( '==' )
            // InternalSM2.g:38:9: '=='
            {
            match("=="); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__57"

    // $ANTLR start "T__58"
    public final void mT__58() throws RecognitionException {
        try {
            int _type = T__58;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:39:7: ( '!=' )
            // InternalSM2.g:39:9: '!='
            {
            match("!="); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__58"

    // $ANTLR start "T__59"
    public final void mT__59() throws RecognitionException {
        try {
            int _type = T__59;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:40:7: ( '&&' )
            // InternalSM2.g:40:9: '&&'
            {
            match("&&"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__59"

    // $ANTLR start "T__60"
    public final void mT__60() throws RecognitionException {
        try {
            int _type = T__60;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:41:7: ( '||' )
            // InternalSM2.g:41:9: '||'
            {
            match("||"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__60"

    // $ANTLR start "T__61"
    public final void mT__61() throws RecognitionException {
        try {
            int _type = T__61;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:42:7: ( '+' )
            // InternalSM2.g:42:9: '+'
            {
            match('+'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__61"

    // $ANTLR start "T__62"
    public final void mT__62() throws RecognitionException {
        try {
            int _type = T__62;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:43:7: ( '-' )
            // InternalSM2.g:43:9: '-'
            {
            match('-'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__62"

    // $ANTLR start "T__63"
    public final void mT__63() throws RecognitionException {
        try {
            int _type = T__63;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:44:7: ( '*' )
            // InternalSM2.g:44:9: '*'
            {
            match('*'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__63"

    // $ANTLR start "T__64"
    public final void mT__64() throws RecognitionException {
        try {
            int _type = T__64;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:45:7: ( '/' )
            // InternalSM2.g:45:9: '/'
            {
            match('/'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__64"

    // $ANTLR start "T__65"
    public final void mT__65() throws RecognitionException {
        try {
            int _type = T__65;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:46:7: ( 'solidity' )
            // InternalSM2.g:46:9: 'solidity'
            {
            match("solidity"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__65"

    // $ANTLR start "T__66"
    public final void mT__66() throws RecognitionException {
        try {
            int _type = T__66;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:47:7: ( 'is' )
            // InternalSM2.g:47:9: 'is'
            {
            match("is"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__66"

    // $ANTLR start "T__67"
    public final void mT__67() throws RecognitionException {
        try {
            int _type = T__67;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:48:7: ( 'import' )
            // InternalSM2.g:48:9: 'import'
            {
            match("import"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__67"

    // $ANTLR start "T__68"
    public final void mT__68() throws RecognitionException {
        try {
            int _type = T__68;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:49:7: ( 'as' )
            // InternalSM2.g:49:9: 'as'
            {
            match("as"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__68"

    // $ANTLR start "T__69"
    public final void mT__69() throws RecognitionException {
        try {
            int _type = T__69;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:50:7: ( 'interface' )
            // InternalSM2.g:50:9: 'interface'
            {
            match("interface"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__69"

    // $ANTLR start "T__70"
    public final void mT__70() throws RecognitionException {
        try {
            int _type = T__70;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:51:7: ( 'constructor' )
            // InternalSM2.g:51:9: 'constructor'
            {
            match("constructor"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__70"

    // $ANTLR start "T__71"
    public final void mT__71() throws RecognitionException {
        try {
            int _type = T__71;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:52:7: ( '=' )
            // InternalSM2.g:52:9: '='
            {
            match('='); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__71"

    // $ANTLR start "T__72"
    public final void mT__72() throws RecognitionException {
        try {
            int _type = T__72;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:53:7: ( 'event' )
            // InternalSM2.g:53:9: 'event'
            {
            match("event"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__72"

    // $ANTLR start "T__73"
    public final void mT__73() throws RecognitionException {
        try {
            int _type = T__73;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:54:7: ( 'modifier' )
            // InternalSM2.g:54:9: 'modifier'
            {
            match("modifier"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__73"

    // $ANTLR start "T__74"
    public final void mT__74() throws RecognitionException {
        try {
            int _type = T__74;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:55:7: ( '_;' )
            // InternalSM2.g:55:9: '_;'
            {
            match("_;"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__74"

    // $ANTLR start "T__75"
    public final void mT__75() throws RecognitionException {
        try {
            int _type = T__75;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:56:7: ( 'mapping' )
            // InternalSM2.g:56:9: 'mapping'
            {
            match("mapping"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__75"

    // $ANTLR start "T__76"
    public final void mT__76() throws RecognitionException {
        try {
            int _type = T__76;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:57:7: ( '=>' )
            // InternalSM2.g:57:9: '=>'
            {
            match("=>"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__76"

    // $ANTLR start "T__77"
    public final void mT__77() throws RecognitionException {
        try {
            int _type = T__77;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:58:7: ( 'struct' )
            // InternalSM2.g:58:9: 'struct'
            {
            match("struct"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__77"

    // $ANTLR start "T__78"
    public final void mT__78() throws RecognitionException {
        try {
            int _type = T__78;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:59:7: ( 'amountAccount' )
            // InternalSM2.g:59:9: 'amountAccount'
            {
            match("amountAccount"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__78"

    // $ANTLR start "T__79"
    public final void mT__79() throws RecognitionException {
        try {
            int _type = T__79;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:60:7: ( 'enum' )
            // InternalSM2.g:60:9: 'enum'
            {
            match("enum"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__79"

    // $ANTLR start "T__80"
    public final void mT__80() throws RecognitionException {
        try {
            int _type = T__80;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:61:7: ( '[' )
            // InternalSM2.g:61:9: '['
            {
            match('['); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__80"

    // $ANTLR start "T__81"
    public final void mT__81() throws RecognitionException {
        try {
            int _type = T__81;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:62:7: ( ']' )
            // InternalSM2.g:62:9: ']'
            {
            match(']'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__81"

    // $ANTLR start "T__82"
    public final void mT__82() throws RecognitionException {
        try {
            int _type = T__82;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:63:7: ( 'require' )
            // InternalSM2.g:63:9: 'require'
            {
            match("require"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__82"

    // $ANTLR start "T__83"
    public final void mT__83() throws RecognitionException {
        try {
            int _type = T__83;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:64:7: ( 'function' )
            // InternalSM2.g:64:9: 'function'
            {
            match("function"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__83"

    // $ANTLR start "T__84"
    public final void mT__84() throws RecognitionException {
        try {
            int _type = T__84;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:65:7: ( '//' )
            // InternalSM2.g:65:9: '//'
            {
            match("//"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__84"

    // $ANTLR start "T__85"
    public final void mT__85() throws RecognitionException {
        try {
            int _type = T__85;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:66:7: ( '/*' )
            // InternalSM2.g:66:9: '/*'
            {
            match("/*"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__85"

    // $ANTLR start "T__86"
    public final void mT__86() throws RecognitionException {
        try {
            int _type = T__86;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:67:7: ( '*/' )
            // InternalSM2.g:67:9: '*/'
            {
            match("*/"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__86"

    // $ANTLR start "T__87"
    public final void mT__87() throws RecognitionException {
        try {
            int _type = T__87;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:68:7: ( 'pragma' )
            // InternalSM2.g:68:9: 'pragma'
            {
            match("pragma"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__87"

    // $ANTLR start "T__88"
    public final void mT__88() throws RecognitionException {
        try {
            int _type = T__88;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:69:7: ( 'contract' )
            // InternalSM2.g:69:9: 'contract'
            {
            match("contract"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__88"

    // $ANTLR start "T__89"
    public final void mT__89() throws RecognitionException {
        try {
            int _type = T__89;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:70:7: ( '^' )
            // InternalSM2.g:70:9: '^'
            {
            match('^'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__89"

    // $ANTLR start "T__90"
    public final void mT__90() throws RecognitionException {
        try {
            int _type = T__90;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:71:7: ( 'memory' )
            // InternalSM2.g:71:9: 'memory'
            {
            match("memory"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__90"

    // $ANTLR start "T__91"
    public final void mT__91() throws RecognitionException {
        try {
            int _type = T__91;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:72:7: ( 'payable' )
            // InternalSM2.g:72:9: 'payable'
            {
            match("payable"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__91"

    // $ANTLR start "RULE_SINGLENUMBER"
    public final void mRULE_SINGLENUMBER() throws RecognitionException {
        try {
            int _type = RULE_SINGLENUMBER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10137:19: ( '0' .. '9' )
            // InternalSM2.g:10137:21: '0' .. '9'
            {
            matchRange('0','9'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_SINGLENUMBER"

    // $ANTLR start "RULE_INTEGER"
    public final void mRULE_INTEGER() throws RecognitionException {
        try {
            int _type = RULE_INTEGER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10139:14: ( ( '0' .. '9' )+ )
            // InternalSM2.g:10139:16: ( '0' .. '9' )+
            {
            // InternalSM2.g:10139:16: ( '0' .. '9' )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>='0' && LA1_0<='9')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalSM2.g:10139:17: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_INTEGER"

    // $ANTLR start "RULE_FLOAT"
    public final void mRULE_FLOAT() throws RecognitionException {
        try {
            int _type = RULE_FLOAT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10141:12: ( RULE_INTEGER '.' RULE_INTEGER )
            // InternalSM2.g:10141:14: RULE_INTEGER '.' RULE_INTEGER
            {
            mRULE_INTEGER(); 
            match('.'); 
            mRULE_INTEGER(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_FLOAT"

    // $ANTLR start "RULE_CLOSEKEY"
    public final void mRULE_CLOSEKEY() throws RecognitionException {
        try {
            int _type = RULE_CLOSEKEY;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10143:15: ( '}' )
            // InternalSM2.g:10143:17: '}'
            {
            match('}'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_CLOSEKEY"

    // $ANTLR start "RULE_OPENKEY"
    public final void mRULE_OPENKEY() throws RecognitionException {
        try {
            int _type = RULE_OPENKEY;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10145:14: ( '{' )
            // InternalSM2.g:10145:16: '{'
            {
            match('{'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_OPENKEY"

    // $ANTLR start "RULE_OPENPARENTHESIS"
    public final void mRULE_OPENPARENTHESIS() throws RecognitionException {
        try {
            int _type = RULE_OPENPARENTHESIS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10147:22: ( '(' )
            // InternalSM2.g:10147:24: '('
            {
            match('('); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_OPENPARENTHESIS"

    // $ANTLR start "RULE_CLOSEPARENTHESIS"
    public final void mRULE_CLOSEPARENTHESIS() throws RecognitionException {
        try {
            int _type = RULE_CLOSEPARENTHESIS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10149:23: ( ')' )
            // InternalSM2.g:10149:25: ')'
            {
            match(')'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_CLOSEPARENTHESIS"

    // $ANTLR start "RULE_EOLINE"
    public final void mRULE_EOLINE() throws RecognitionException {
        try {
            int _type = RULE_EOLINE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10151:13: ( '/n' )
            // InternalSM2.g:10151:15: '/n'
            {
            match("/n"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_EOLINE"

    // $ANTLR start "RULE_SEMICOLON"
    public final void mRULE_SEMICOLON() throws RecognitionException {
        try {
            int _type = RULE_SEMICOLON;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10153:16: ( ';' )
            // InternalSM2.g:10153:18: ';'
            {
            match(';'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_SEMICOLON"

    // $ANTLR start "RULE_DOT"
    public final void mRULE_DOT() throws RecognitionException {
        try {
            int _type = RULE_DOT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10155:10: ( '.' )
            // InternalSM2.g:10155:12: '.'
            {
            match('.'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_DOT"

    // $ANTLR start "RULE_IF"
    public final void mRULE_IF() throws RecognitionException {
        try {
            int _type = RULE_IF;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10157:9: ( 'if' )
            // InternalSM2.g:10157:11: 'if'
            {
            match("if"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_IF"

    // $ANTLR start "RULE_ELSE"
    public final void mRULE_ELSE() throws RecognitionException {
        try {
            int _type = RULE_ELSE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10159:11: ( 'else' )
            // InternalSM2.g:10159:13: 'else'
            {
            match("else"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_ELSE"

    // $ANTLR start "RULE_COMMA"
    public final void mRULE_COMMA() throws RecognitionException {
        try {
            int _type = RULE_COMMA;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10161:12: ( ',' )
            // InternalSM2.g:10161:14: ','
            {
            match(','); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_COMMA"

    // $ANTLR start "RULE_PARAMSLONGCOMENT"
    public final void mRULE_PARAMSLONGCOMENT() throws RecognitionException {
        try {
            int _type = RULE_PARAMSLONGCOMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10163:23: ( '@param' ( 'a' .. 'z' )+ RULE_EOLINE )
            // InternalSM2.g:10163:25: '@param' ( 'a' .. 'z' )+ RULE_EOLINE
            {
            match("@param"); 

            // InternalSM2.g:10163:34: ( 'a' .. 'z' )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>='a' && LA2_0<='z')) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSM2.g:10163:35: 'a' .. 'z'
            	    {
            	    matchRange('a','z'); 

            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);

            mRULE_EOLINE(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_PARAMSLONGCOMENT"

    // $ANTLR start "RULE_DEVLONGCOMENT"
    public final void mRULE_DEVLONGCOMENT() throws RecognitionException {
        try {
            int _type = RULE_DEVLONGCOMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10165:20: ( '@dev' ( 'a' .. 'z' )+ RULE_EOLINE )
            // InternalSM2.g:10165:22: '@dev' ( 'a' .. 'z' )+ RULE_EOLINE
            {
            match("@dev"); 

            // InternalSM2.g:10165:29: ( 'a' .. 'z' )+
            int cnt3=0;
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( ((LA3_0>='a' && LA3_0<='z')) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalSM2.g:10165:30: 'a' .. 'z'
            	    {
            	    matchRange('a','z'); 

            	    }
            	    break;

            	default :
            	    if ( cnt3 >= 1 ) break loop3;
                        EarlyExitException eee =
                            new EarlyExitException(3, input);
                        throw eee;
                }
                cnt3++;
            } while (true);

            mRULE_EOLINE(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_DEVLONGCOMENT"

    // $ANTLR start "RULE_NOTICELONGCOMENT"
    public final void mRULE_NOTICELONGCOMENT() throws RecognitionException {
        try {
            int _type = RULE_NOTICELONGCOMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10167:23: ( '@notice' ( 'a' .. 'z' )+ RULE_EOLINE )
            // InternalSM2.g:10167:25: '@notice' ( 'a' .. 'z' )+ RULE_EOLINE
            {
            match("@notice"); 

            // InternalSM2.g:10167:35: ( 'a' .. 'z' )+
            int cnt4=0;
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( ((LA4_0>='a' && LA4_0<='z')) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalSM2.g:10167:36: 'a' .. 'z'
            	    {
            	    matchRange('a','z'); 

            	    }
            	    break;

            	default :
            	    if ( cnt4 >= 1 ) break loop4;
                        EarlyExitException eee =
                            new EarlyExitException(4, input);
                        throw eee;
                }
                cnt4++;
            } while (true);

            mRULE_EOLINE(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_NOTICELONGCOMENT"

    // $ANTLR start "RULE_RETURNSLONGCOMENT"
    public final void mRULE_RETURNSLONGCOMENT() throws RecognitionException {
        try {
            int _type = RULE_RETURNSLONGCOMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10169:24: ( '@returns' ( 'a' .. 'z' )+ RULE_EOLINE )
            // InternalSM2.g:10169:26: '@returns' ( 'a' .. 'z' )+ RULE_EOLINE
            {
            match("@returns"); 

            // InternalSM2.g:10169:37: ( 'a' .. 'z' )+
            int cnt5=0;
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( ((LA5_0>='a' && LA5_0<='z')) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalSM2.g:10169:38: 'a' .. 'z'
            	    {
            	    matchRange('a','z'); 

            	    }
            	    break;

            	default :
            	    if ( cnt5 >= 1 ) break loop5;
                        EarlyExitException eee =
                            new EarlyExitException(5, input);
                        throw eee;
                }
                cnt5++;
            } while (true);

            mRULE_EOLINE(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_RETURNSLONGCOMENT"

    // $ANTLR start "RULE_TITLELONGCOMENT"
    public final void mRULE_TITLELONGCOMENT() throws RecognitionException {
        try {
            int _type = RULE_TITLELONGCOMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10171:22: ( '@title' ( 'a' .. 'z' )+ RULE_EOLINE )
            // InternalSM2.g:10171:24: '@title' ( 'a' .. 'z' )+ RULE_EOLINE
            {
            match("@title"); 

            // InternalSM2.g:10171:33: ( 'a' .. 'z' )+
            int cnt6=0;
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( ((LA6_0>='a' && LA6_0<='z')) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalSM2.g:10171:34: 'a' .. 'z'
            	    {
            	    matchRange('a','z'); 

            	    }
            	    break;

            	default :
            	    if ( cnt6 >= 1 ) break loop6;
                        EarlyExitException eee =
                            new EarlyExitException(6, input);
                        throw eee;
                }
                cnt6++;
            } while (true);

            mRULE_EOLINE(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_TITLELONGCOMENT"

    // $ANTLR start "RULE_EMAIL"
    public final void mRULE_EMAIL() throws RecognitionException {
        try {
            int _type = RULE_EMAIL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10173:12: ( ( 'a' .. 'z' )+ ( '0' .. '9' )+ '@' ( 'a' .. 'z' )+ '.' 'a' .. 'z' 'a' .. 'z' ( 'a' .. 'z' )? )
            // InternalSM2.g:10173:14: ( 'a' .. 'z' )+ ( '0' .. '9' )+ '@' ( 'a' .. 'z' )+ '.' 'a' .. 'z' 'a' .. 'z' ( 'a' .. 'z' )?
            {
            // InternalSM2.g:10173:14: ( 'a' .. 'z' )+
            int cnt7=0;
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( ((LA7_0>='a' && LA7_0<='z')) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalSM2.g:10173:15: 'a' .. 'z'
            	    {
            	    matchRange('a','z'); 

            	    }
            	    break;

            	default :
            	    if ( cnt7 >= 1 ) break loop7;
                        EarlyExitException eee =
                            new EarlyExitException(7, input);
                        throw eee;
                }
                cnt7++;
            } while (true);

            // InternalSM2.g:10173:26: ( '0' .. '9' )+
            int cnt8=0;
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( ((LA8_0>='0' && LA8_0<='9')) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalSM2.g:10173:27: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt8 >= 1 ) break loop8;
                        EarlyExitException eee =
                            new EarlyExitException(8, input);
                        throw eee;
                }
                cnt8++;
            } while (true);

            match('@'); 
            // InternalSM2.g:10173:42: ( 'a' .. 'z' )+
            int cnt9=0;
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( ((LA9_0>='a' && LA9_0<='z')) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalSM2.g:10173:43: 'a' .. 'z'
            	    {
            	    matchRange('a','z'); 

            	    }
            	    break;

            	default :
            	    if ( cnt9 >= 1 ) break loop9;
                        EarlyExitException eee =
                            new EarlyExitException(9, input);
                        throw eee;
                }
                cnt9++;
            } while (true);

            match('.'); 
            matchRange('a','z'); 
            matchRange('a','z'); 
            // InternalSM2.g:10173:76: ( 'a' .. 'z' )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( ((LA10_0>='a' && LA10_0<='z')) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalSM2.g:10173:77: 'a' .. 'z'
                    {
                    matchRange('a','z'); 

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_EMAIL"

    // $ANTLR start "RULE_ID"
    public final void mRULE_ID() throws RecognitionException {
        try {
            int _type = RULE_ID;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10175:9: ( ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )* )
            // InternalSM2.g:10175:11: ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
            {
            // InternalSM2.g:10175:11: ( '^' )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0=='^') ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalSM2.g:10175:11: '^'
                    {
                    match('^'); 

                    }
                    break;

            }

            if ( (input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            // InternalSM2.g:10175:40: ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( ((LA12_0>='0' && LA12_0<='9')||(LA12_0>='A' && LA12_0<='Z')||LA12_0=='_'||(LA12_0>='a' && LA12_0<='z')) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalSM2.g:
            	    {
            	    if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_ID"

    // $ANTLR start "RULE_INT"
    public final void mRULE_INT() throws RecognitionException {
        try {
            int _type = RULE_INT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10177:10: ( ( '0' .. '9' )+ )
            // InternalSM2.g:10177:12: ( '0' .. '9' )+
            {
            // InternalSM2.g:10177:12: ( '0' .. '9' )+
            int cnt13=0;
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( ((LA13_0>='0' && LA13_0<='9')) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalSM2.g:10177:13: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt13 >= 1 ) break loop13;
                        EarlyExitException eee =
                            new EarlyExitException(13, input);
                        throw eee;
                }
                cnt13++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_INT"

    // $ANTLR start "RULE_STRING"
    public final void mRULE_STRING() throws RecognitionException {
        try {
            int _type = RULE_STRING;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10179:13: ( ( '\"' ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )* '\"' | '\\'' ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )* '\\'' ) )
            // InternalSM2.g:10179:15: ( '\"' ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )* '\"' | '\\'' ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )* '\\'' )
            {
            // InternalSM2.g:10179:15: ( '\"' ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )* '\"' | '\\'' ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )* '\\'' )
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0=='\"') ) {
                alt16=1;
            }
            else if ( (LA16_0=='\'') ) {
                alt16=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }
            switch (alt16) {
                case 1 :
                    // InternalSM2.g:10179:16: '\"' ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )* '\"'
                    {
                    match('\"'); 
                    // InternalSM2.g:10179:20: ( '\\\\' . | ~ ( ( '\\\\' | '\"' ) ) )*
                    loop14:
                    do {
                        int alt14=3;
                        int LA14_0 = input.LA(1);

                        if ( (LA14_0=='\\') ) {
                            alt14=1;
                        }
                        else if ( ((LA14_0>='\u0000' && LA14_0<='!')||(LA14_0>='#' && LA14_0<='[')||(LA14_0>=']' && LA14_0<='\uFFFF')) ) {
                            alt14=2;
                        }


                        switch (alt14) {
                    	case 1 :
                    	    // InternalSM2.g:10179:21: '\\\\' .
                    	    {
                    	    match('\\'); 
                    	    matchAny(); 

                    	    }
                    	    break;
                    	case 2 :
                    	    // InternalSM2.g:10179:28: ~ ( ( '\\\\' | '\"' ) )
                    	    {
                    	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFF') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse = new MismatchedSetException(null,input);
                    	        recover(mse);
                    	        throw mse;}


                    	    }
                    	    break;

                    	default :
                    	    break loop14;
                        }
                    } while (true);

                    match('\"'); 

                    }
                    break;
                case 2 :
                    // InternalSM2.g:10179:48: '\\'' ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )* '\\''
                    {
                    match('\''); 
                    // InternalSM2.g:10179:53: ( '\\\\' . | ~ ( ( '\\\\' | '\\'' ) ) )*
                    loop15:
                    do {
                        int alt15=3;
                        int LA15_0 = input.LA(1);

                        if ( (LA15_0=='\\') ) {
                            alt15=1;
                        }
                        else if ( ((LA15_0>='\u0000' && LA15_0<='&')||(LA15_0>='(' && LA15_0<='[')||(LA15_0>=']' && LA15_0<='\uFFFF')) ) {
                            alt15=2;
                        }


                        switch (alt15) {
                    	case 1 :
                    	    // InternalSM2.g:10179:54: '\\\\' .
                    	    {
                    	    match('\\'); 
                    	    matchAny(); 

                    	    }
                    	    break;
                    	case 2 :
                    	    // InternalSM2.g:10179:61: ~ ( ( '\\\\' | '\\'' ) )
                    	    {
                    	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='&')||(input.LA(1)>='(' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFF') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse = new MismatchedSetException(null,input);
                    	        recover(mse);
                    	        throw mse;}


                    	    }
                    	    break;

                    	default :
                    	    break loop15;
                        }
                    } while (true);

                    match('\''); 

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_STRING"

    // $ANTLR start "RULE_ML_COMMENT"
    public final void mRULE_ML_COMMENT() throws RecognitionException {
        try {
            int _type = RULE_ML_COMMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10181:17: ( '/*' ( options {greedy=false; } : . )* '*/' )
            // InternalSM2.g:10181:19: '/*' ( options {greedy=false; } : . )* '*/'
            {
            match("/*"); 

            // InternalSM2.g:10181:24: ( options {greedy=false; } : . )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( (LA17_0=='*') ) {
                    int LA17_1 = input.LA(2);

                    if ( (LA17_1=='/') ) {
                        alt17=2;
                    }
                    else if ( ((LA17_1>='\u0000' && LA17_1<='.')||(LA17_1>='0' && LA17_1<='\uFFFF')) ) {
                        alt17=1;
                    }


                }
                else if ( ((LA17_0>='\u0000' && LA17_0<=')')||(LA17_0>='+' && LA17_0<='\uFFFF')) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalSM2.g:10181:52: .
            	    {
            	    matchAny(); 

            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

            match("*/"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_ML_COMMENT"

    // $ANTLR start "RULE_SL_COMMENT"
    public final void mRULE_SL_COMMENT() throws RecognitionException {
        try {
            int _type = RULE_SL_COMMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10183:17: ( '//' (~ ( ( '\\n' | '\\r' ) ) )* ( ( '\\r' )? '\\n' )? )
            // InternalSM2.g:10183:19: '//' (~ ( ( '\\n' | '\\r' ) ) )* ( ( '\\r' )? '\\n' )?
            {
            match("//"); 

            // InternalSM2.g:10183:24: (~ ( ( '\\n' | '\\r' ) ) )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( ((LA18_0>='\u0000' && LA18_0<='\t')||(LA18_0>='\u000B' && LA18_0<='\f')||(LA18_0>='\u000E' && LA18_0<='\uFFFF')) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalSM2.g:10183:24: ~ ( ( '\\n' | '\\r' ) )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

            // InternalSM2.g:10183:40: ( ( '\\r' )? '\\n' )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0=='\n'||LA20_0=='\r') ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalSM2.g:10183:41: ( '\\r' )? '\\n'
                    {
                    // InternalSM2.g:10183:41: ( '\\r' )?
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( (LA19_0=='\r') ) {
                        alt19=1;
                    }
                    switch (alt19) {
                        case 1 :
                            // InternalSM2.g:10183:41: '\\r'
                            {
                            match('\r'); 

                            }
                            break;

                    }

                    match('\n'); 

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_SL_COMMENT"

    // $ANTLR start "RULE_WS"
    public final void mRULE_WS() throws RecognitionException {
        try {
            int _type = RULE_WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10185:9: ( ( ' ' | '\\t' | '\\r' | '\\n' )+ )
            // InternalSM2.g:10185:11: ( ' ' | '\\t' | '\\r' | '\\n' )+
            {
            // InternalSM2.g:10185:11: ( ' ' | '\\t' | '\\r' | '\\n' )+
            int cnt21=0;
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( ((LA21_0>='\t' && LA21_0<='\n')||LA21_0=='\r'||LA21_0==' ') ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalSM2.g:
            	    {
            	    if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||input.LA(1)=='\r'||input.LA(1)==' ' ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    if ( cnt21 >= 1 ) break loop21;
                        EarlyExitException eee =
                            new EarlyExitException(21, input);
                        throw eee;
                }
                cnt21++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_WS"

    // $ANTLR start "RULE_ANY_OTHER"
    public final void mRULE_ANY_OTHER() throws RecognitionException {
        try {
            int _type = RULE_ANY_OTHER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalSM2.g:10187:16: ( . )
            // InternalSM2.g:10187:18: .
            {
            matchAny(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_ANY_OTHER"

    public void mTokens() throws RecognitionException {
        // InternalSM2.g:1:8: ( T__30 | T__31 | T__32 | T__33 | T__34 | T__35 | T__36 | T__37 | T__38 | T__39 | T__40 | T__41 | T__42 | T__43 | T__44 | T__45 | T__46 | T__47 | T__48 | T__49 | T__50 | T__51 | T__52 | T__53 | T__54 | T__55 | T__56 | T__57 | T__58 | T__59 | T__60 | T__61 | T__62 | T__63 | T__64 | T__65 | T__66 | T__67 | T__68 | T__69 | T__70 | T__71 | T__72 | T__73 | T__74 | T__75 | T__76 | T__77 | T__78 | T__79 | T__80 | T__81 | T__82 | T__83 | T__84 | T__85 | T__86 | T__87 | T__88 | T__89 | T__90 | T__91 | RULE_SINGLENUMBER | RULE_INTEGER | RULE_FLOAT | RULE_CLOSEKEY | RULE_OPENKEY | RULE_OPENPARENTHESIS | RULE_CLOSEPARENTHESIS | RULE_EOLINE | RULE_SEMICOLON | RULE_DOT | RULE_IF | RULE_ELSE | RULE_COMMA | RULE_PARAMSLONGCOMENT | RULE_DEVLONGCOMENT | RULE_NOTICELONGCOMENT | RULE_RETURNSLONGCOMENT | RULE_TITLELONGCOMENT | RULE_EMAIL | RULE_ID | RULE_INT | RULE_STRING | RULE_ML_COMMENT | RULE_SL_COMMENT | RULE_WS | RULE_ANY_OTHER )
        int alt22=88;
        alt22 = dfa22.predict(input);
        switch (alt22) {
            case 1 :
                // InternalSM2.g:1:10: T__30
                {
                mT__30(); 

                }
                break;
            case 2 :
                // InternalSM2.g:1:16: T__31
                {
                mT__31(); 

                }
                break;
            case 3 :
                // InternalSM2.g:1:22: T__32
                {
                mT__32(); 

                }
                break;
            case 4 :
                // InternalSM2.g:1:28: T__33
                {
                mT__33(); 

                }
                break;
            case 5 :
                // InternalSM2.g:1:34: T__34
                {
                mT__34(); 

                }
                break;
            case 6 :
                // InternalSM2.g:1:40: T__35
                {
                mT__35(); 

                }
                break;
            case 7 :
                // InternalSM2.g:1:46: T__36
                {
                mT__36(); 

                }
                break;
            case 8 :
                // InternalSM2.g:1:52: T__37
                {
                mT__37(); 

                }
                break;
            case 9 :
                // InternalSM2.g:1:58: T__38
                {
                mT__38(); 

                }
                break;
            case 10 :
                // InternalSM2.g:1:64: T__39
                {
                mT__39(); 

                }
                break;
            case 11 :
                // InternalSM2.g:1:70: T__40
                {
                mT__40(); 

                }
                break;
            case 12 :
                // InternalSM2.g:1:76: T__41
                {
                mT__41(); 

                }
                break;
            case 13 :
                // InternalSM2.g:1:82: T__42
                {
                mT__42(); 

                }
                break;
            case 14 :
                // InternalSM2.g:1:88: T__43
                {
                mT__43(); 

                }
                break;
            case 15 :
                // InternalSM2.g:1:94: T__44
                {
                mT__44(); 

                }
                break;
            case 16 :
                // InternalSM2.g:1:100: T__45
                {
                mT__45(); 

                }
                break;
            case 17 :
                // InternalSM2.g:1:106: T__46
                {
                mT__46(); 

                }
                break;
            case 18 :
                // InternalSM2.g:1:112: T__47
                {
                mT__47(); 

                }
                break;
            case 19 :
                // InternalSM2.g:1:118: T__48
                {
                mT__48(); 

                }
                break;
            case 20 :
                // InternalSM2.g:1:124: T__49
                {
                mT__49(); 

                }
                break;
            case 21 :
                // InternalSM2.g:1:130: T__50
                {
                mT__50(); 

                }
                break;
            case 22 :
                // InternalSM2.g:1:136: T__51
                {
                mT__51(); 

                }
                break;
            case 23 :
                // InternalSM2.g:1:142: T__52
                {
                mT__52(); 

                }
                break;
            case 24 :
                // InternalSM2.g:1:148: T__53
                {
                mT__53(); 

                }
                break;
            case 25 :
                // InternalSM2.g:1:154: T__54
                {
                mT__54(); 

                }
                break;
            case 26 :
                // InternalSM2.g:1:160: T__55
                {
                mT__55(); 

                }
                break;
            case 27 :
                // InternalSM2.g:1:166: T__56
                {
                mT__56(); 

                }
                break;
            case 28 :
                // InternalSM2.g:1:172: T__57
                {
                mT__57(); 

                }
                break;
            case 29 :
                // InternalSM2.g:1:178: T__58
                {
                mT__58(); 

                }
                break;
            case 30 :
                // InternalSM2.g:1:184: T__59
                {
                mT__59(); 

                }
                break;
            case 31 :
                // InternalSM2.g:1:190: T__60
                {
                mT__60(); 

                }
                break;
            case 32 :
                // InternalSM2.g:1:196: T__61
                {
                mT__61(); 

                }
                break;
            case 33 :
                // InternalSM2.g:1:202: T__62
                {
                mT__62(); 

                }
                break;
            case 34 :
                // InternalSM2.g:1:208: T__63
                {
                mT__63(); 

                }
                break;
            case 35 :
                // InternalSM2.g:1:214: T__64
                {
                mT__64(); 

                }
                break;
            case 36 :
                // InternalSM2.g:1:220: T__65
                {
                mT__65(); 

                }
                break;
            case 37 :
                // InternalSM2.g:1:226: T__66
                {
                mT__66(); 

                }
                break;
            case 38 :
                // InternalSM2.g:1:232: T__67
                {
                mT__67(); 

                }
                break;
            case 39 :
                // InternalSM2.g:1:238: T__68
                {
                mT__68(); 

                }
                break;
            case 40 :
                // InternalSM2.g:1:244: T__69
                {
                mT__69(); 

                }
                break;
            case 41 :
                // InternalSM2.g:1:250: T__70
                {
                mT__70(); 

                }
                break;
            case 42 :
                // InternalSM2.g:1:256: T__71
                {
                mT__71(); 

                }
                break;
            case 43 :
                // InternalSM2.g:1:262: T__72
                {
                mT__72(); 

                }
                break;
            case 44 :
                // InternalSM2.g:1:268: T__73
                {
                mT__73(); 

                }
                break;
            case 45 :
                // InternalSM2.g:1:274: T__74
                {
                mT__74(); 

                }
                break;
            case 46 :
                // InternalSM2.g:1:280: T__75
                {
                mT__75(); 

                }
                break;
            case 47 :
                // InternalSM2.g:1:286: T__76
                {
                mT__76(); 

                }
                break;
            case 48 :
                // InternalSM2.g:1:292: T__77
                {
                mT__77(); 

                }
                break;
            case 49 :
                // InternalSM2.g:1:298: T__78
                {
                mT__78(); 

                }
                break;
            case 50 :
                // InternalSM2.g:1:304: T__79
                {
                mT__79(); 

                }
                break;
            case 51 :
                // InternalSM2.g:1:310: T__80
                {
                mT__80(); 

                }
                break;
            case 52 :
                // InternalSM2.g:1:316: T__81
                {
                mT__81(); 

                }
                break;
            case 53 :
                // InternalSM2.g:1:322: T__82
                {
                mT__82(); 

                }
                break;
            case 54 :
                // InternalSM2.g:1:328: T__83
                {
                mT__83(); 

                }
                break;
            case 55 :
                // InternalSM2.g:1:334: T__84
                {
                mT__84(); 

                }
                break;
            case 56 :
                // InternalSM2.g:1:340: T__85
                {
                mT__85(); 

                }
                break;
            case 57 :
                // InternalSM2.g:1:346: T__86
                {
                mT__86(); 

                }
                break;
            case 58 :
                // InternalSM2.g:1:352: T__87
                {
                mT__87(); 

                }
                break;
            case 59 :
                // InternalSM2.g:1:358: T__88
                {
                mT__88(); 

                }
                break;
            case 60 :
                // InternalSM2.g:1:364: T__89
                {
                mT__89(); 

                }
                break;
            case 61 :
                // InternalSM2.g:1:370: T__90
                {
                mT__90(); 

                }
                break;
            case 62 :
                // InternalSM2.g:1:376: T__91
                {
                mT__91(); 

                }
                break;
            case 63 :
                // InternalSM2.g:1:382: RULE_SINGLENUMBER
                {
                mRULE_SINGLENUMBER(); 

                }
                break;
            case 64 :
                // InternalSM2.g:1:400: RULE_INTEGER
                {
                mRULE_INTEGER(); 

                }
                break;
            case 65 :
                // InternalSM2.g:1:413: RULE_FLOAT
                {
                mRULE_FLOAT(); 

                }
                break;
            case 66 :
                // InternalSM2.g:1:424: RULE_CLOSEKEY
                {
                mRULE_CLOSEKEY(); 

                }
                break;
            case 67 :
                // InternalSM2.g:1:438: RULE_OPENKEY
                {
                mRULE_OPENKEY(); 

                }
                break;
            case 68 :
                // InternalSM2.g:1:451: RULE_OPENPARENTHESIS
                {
                mRULE_OPENPARENTHESIS(); 

                }
                break;
            case 69 :
                // InternalSM2.g:1:472: RULE_CLOSEPARENTHESIS
                {
                mRULE_CLOSEPARENTHESIS(); 

                }
                break;
            case 70 :
                // InternalSM2.g:1:494: RULE_EOLINE
                {
                mRULE_EOLINE(); 

                }
                break;
            case 71 :
                // InternalSM2.g:1:506: RULE_SEMICOLON
                {
                mRULE_SEMICOLON(); 

                }
                break;
            case 72 :
                // InternalSM2.g:1:521: RULE_DOT
                {
                mRULE_DOT(); 

                }
                break;
            case 73 :
                // InternalSM2.g:1:530: RULE_IF
                {
                mRULE_IF(); 

                }
                break;
            case 74 :
                // InternalSM2.g:1:538: RULE_ELSE
                {
                mRULE_ELSE(); 

                }
                break;
            case 75 :
                // InternalSM2.g:1:548: RULE_COMMA
                {
                mRULE_COMMA(); 

                }
                break;
            case 76 :
                // InternalSM2.g:1:559: RULE_PARAMSLONGCOMENT
                {
                mRULE_PARAMSLONGCOMENT(); 

                }
                break;
            case 77 :
                // InternalSM2.g:1:581: RULE_DEVLONGCOMENT
                {
                mRULE_DEVLONGCOMENT(); 

                }
                break;
            case 78 :
                // InternalSM2.g:1:600: RULE_NOTICELONGCOMENT
                {
                mRULE_NOTICELONGCOMENT(); 

                }
                break;
            case 79 :
                // InternalSM2.g:1:622: RULE_RETURNSLONGCOMENT
                {
                mRULE_RETURNSLONGCOMENT(); 

                }
                break;
            case 80 :
                // InternalSM2.g:1:645: RULE_TITLELONGCOMENT
                {
                mRULE_TITLELONGCOMENT(); 

                }
                break;
            case 81 :
                // InternalSM2.g:1:666: RULE_EMAIL
                {
                mRULE_EMAIL(); 

                }
                break;
            case 82 :
                // InternalSM2.g:1:677: RULE_ID
                {
                mRULE_ID(); 

                }
                break;
            case 83 :
                // InternalSM2.g:1:685: RULE_INT
                {
                mRULE_INT(); 

                }
                break;
            case 84 :
                // InternalSM2.g:1:694: RULE_STRING
                {
                mRULE_STRING(); 

                }
                break;
            case 85 :
                // InternalSM2.g:1:706: RULE_ML_COMMENT
                {
                mRULE_ML_COMMENT(); 

                }
                break;
            case 86 :
                // InternalSM2.g:1:722: RULE_SL_COMMENT
                {
                mRULE_SL_COMMENT(); 

                }
                break;
            case 87 :
                // InternalSM2.g:1:738: RULE_WS
                {
                mRULE_WS(); 

                }
                break;
            case 88 :
                // InternalSM2.g:1:746: RULE_ANY_OTHER
                {
                mRULE_ANY_OTHER(); 

                }
                break;

        }

    }


    protected DFA22 dfa22 = new DFA22(this);
    static final String DFA22_eotS =
        "\1\uffff\1\56\1\60\2\65\1\75\12\65\1\124\3\54\2\uffff\1\133\1\137\3\65\1\uffff\1\65\1\147\1\150\7\uffff\1\54\1\65\1\uffff\2\54\6\uffff\4\65\1\uffff\3\65\1\u0080\1\65\1\u0082\2\uffff\6\65\1\u0089\15\65\12\uffff\1\u0097\1\u0099\2\uffff\4\65\2\uffff\1\65\2\uffff\1\u00a0\17\uffff\5\65\1\uffff\1\u00a7\1\uffff\1\65\1\uffff\6\65\1\uffff\11\65\1\u00b9\3\65\4\uffff\5\65\1\uffff\3\65\1\u00c6\2\65\1\uffff\2\65\1\u00cd\7\65\1\u00d5\1\u00d7\3\65\1\u00db\1\u00dc\1\uffff\1\u00dd\13\65\1\uffff\3\65\1\u00ed\1\u00ee\1\65\1\uffff\2\65\1\u00f2\4\65\1\uffff\1\65\1\uffff\1\65\1\u00f9\1\u00fa\3\uffff\10\65\1\u0103\1\65\1\u0105\3\65\1\u0109\2\uffff\1\65\1\u010b\1\u010c\1\uffff\3\65\1\u0110\2\65\2\uffff\1\u0113\5\65\1\u0119\1\65\1\uffff\1\u011b\1\uffff\1\u011c\2\65\1\uffff\1\u011f\2\uffff\1\65\1\u0122\1\65\1\uffff\1\u0124\1\65\1\uffff\4\65\1\u012a\1\uffff\1\u012b\2\uffff\1\u012c\1\65\1\uffff\1\u012e\2\uffff\1\65\1\uffff\1\u0130\1\u0131\1\65\1\u0133\1\u0134\3\uffff\1\u0135\1\uffff\1\65\2\uffff\1\65\3\uffff\3\65\1\u013b\1\65\1\uffff\1\u013d\1\uffff";
    static final String DFA22_eofS =
        "\u013e\uffff";
    static final String DFA22_minS =
        "\1\0\2\75\2\60\1\135\12\60\2\75\1\46\1\174\2\uffff\1\57\1\52\2\60\1\73\1\uffff\1\60\1\101\1\56\7\uffff\1\144\1\60\1\uffff\2\0\6\uffff\4\60\1\uffff\6\60\2\uffff\24\60\12\uffff\2\0\2\uffff\4\60\2\uffff\1\60\2\uffff\1\56\17\uffff\5\60\1\uffff\1\60\1\uffff\1\60\1\uffff\6\60\1\uffff\15\60\4\uffff\5\60\1\uffff\6\60\1\uffff\21\60\1\uffff\14\60\1\uffff\6\60\1\uffff\7\60\1\uffff\1\60\1\uffff\3\60\3\uffff\17\60\2\uffff\3\60\1\uffff\6\60\2\uffff\10\60\1\uffff\1\60\1\uffff\3\60\1\uffff\1\60\2\uffff\1\60\1\40\1\143\1\uffff\2\60\1\uffff\5\60\1\uffff\1\60\2\uffff\2\60\1\uffff\1\60\2\uffff\1\143\1\uffff\5\60\3\uffff\1\60\1\uffff\1\157\2\uffff\1\60\3\uffff\1\165\1\60\1\156\1\60\1\164\1\uffff\1\60\1\uffff";
    static final String DFA22_maxS =
        "\1\uffff\2\75\2\172\1\135\12\172\1\76\1\75\1\46\1\174\2\uffff\1\57\1\156\2\172\1\73\1\uffff\2\172\1\71\7\uffff\1\164\1\172\1\uffff\2\uffff\6\uffff\4\172\1\uffff\1\100\5\172\2\uffff\24\172\12\uffff\2\uffff\2\uffff\4\172\2\uffff\1\172\2\uffff\1\71\17\uffff\5\172\1\uffff\1\172\1\uffff\1\172\1\uffff\6\172\1\uffff\15\172\4\uffff\5\172\1\uffff\6\172\1\uffff\21\172\1\uffff\14\172\1\uffff\5\172\1\100\1\uffff\7\172\1\uffff\1\172\1\uffff\3\172\3\uffff\17\172\2\uffff\1\100\2\172\1\uffff\4\172\1\100\1\172\2\uffff\10\172\1\uffff\1\172\1\uffff\3\172\1\uffff\1\172\2\uffff\2\172\1\143\1\uffff\2\172\1\uffff\5\172\1\uffff\1\172\2\uffff\2\172\1\uffff\1\172\2\uffff\1\143\1\uffff\5\172\3\uffff\1\172\1\uffff\1\157\2\uffff\1\172\3\uffff\1\165\1\172\1\156\1\172\1\164\1\uffff\1\172\1\uffff";
    static final String DFA22_acceptS =
        "\24\uffff\1\40\1\41\5\uffff\1\64\3\uffff\1\102\1\103\1\104\1\105\1\107\1\110\1\113\2\uffff\1\122\2\uffff\1\127\1\130\1\2\1\1\1\4\1\3\4\uffff\1\122\6\uffff\1\7\1\63\24\uffff\1\34\1\57\1\52\1\35\1\36\1\37\1\40\1\41\1\71\1\42\2\uffff\1\106\1\43\4\uffff\1\55\1\64\1\uffff\1\74\1\77\1\uffff\1\101\1\102\1\103\1\104\1\105\1\107\1\110\1\113\1\114\1\115\1\116\1\117\1\120\1\124\1\127\5\uffff\1\121\1\uffff\1\45\1\uffff\1\111\6\uffff\1\47\15\uffff\1\67\1\126\1\70\1\125\5\uffff\1\100\6\uffff\1\11\21\uffff\1\27\14\uffff\1\31\6\uffff\1\12\7\uffff\1\21\1\uffff\1\22\3\uffff\1\62\1\112\1\30\17\uffff\1\10\1\13\3\uffff\1\33\6\uffff\1\26\1\53\10\uffff\1\5\1\uffff\1\72\3\uffff\1\46\1\uffff\1\15\1\60\3\uffff\1\20\2\uffff\1\32\5\uffff\1\75\1\uffff\1\24\1\76\2\uffff\1\14\1\uffff\1\17\1\16\1\uffff\1\23\5\uffff\1\56\1\65\1\6\1\uffff\1\44\1\uffff\1\25\1\66\1\uffff\1\73\1\54\1\50\5\uffff\1\51\1\uffff\1\61";
    static final String DFA22_specialS =
        "\1\3\50\uffff\1\1\1\4\61\uffff\1\2\1\0\u00e0\uffff}>";
    static final String[] DFA22_transitionS = {
            "\11\54\2\53\2\54\1\53\22\54\1\53\1\21\1\51\3\54\1\22\1\52\1\41\1\42\1\26\1\24\1\45\1\25\1\44\1\27\12\36\1\54\1\43\1\2\1\20\1\1\1\54\1\46\32\50\1\5\1\54\1\33\1\35\1\32\1\54\1\11\1\13\1\30\1\12\1\14\1\17\1\16\1\47\1\4\2\47\1\6\1\31\2\47\1\3\1\47\1\34\1\10\1\47\1\7\1\47\1\15\3\47\1\40\1\23\1\37\uff82\54",
            "\1\55",
            "\1\57",
            "\12\66\47\uffff\1\64\20\67\1\62\2\67\1\61\1\67\1\63\3\67",
            "\12\66\47\uffff\5\67\1\73\6\67\1\72\1\70\4\67\1\71\7\67",
            "\1\74",
            "\12\66\47\uffff\16\67\1\76\13\67",
            "\12\66\47\uffff\10\67\1\77\21\67",
            "\12\66\47\uffff\16\67\1\102\4\67\1\100\5\67\1\101",
            "\12\66\47\uffff\3\67\1\103\10\67\1\105\5\67\1\104\7\67",
            "\12\66\47\uffff\16\67\1\106\13\67",
            "\12\66\47\uffff\16\67\1\107\11\67\1\110\1\67",
            "\12\66\47\uffff\13\67\1\115\1\67\1\114\5\67\1\112\1\67\1\113\1\67\1\111\2\67",
            "\12\66\47\uffff\4\67\1\116\25\67",
            "\12\66\47\uffff\26\67\1\117\3\67",
            "\12\66\47\uffff\10\67\1\120\13\67\1\121\5\67",
            "\1\122\1\123",
            "\1\125",
            "\1\126",
            "\1\127",
            "",
            "",
            "\1\132",
            "\1\135\4\uffff\1\134\76\uffff\1\136",
            "\12\66\47\uffff\16\67\1\140\13\67",
            "\12\66\47\uffff\1\142\3\67\1\143\11\67\1\141\13\67",
            "\1\144",
            "",
            "\12\66\47\uffff\4\67\1\146\25\67",
            "\32\65\4\uffff\1\65\1\uffff\32\65",
            "\1\152\1\uffff\12\151",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\163\11\uffff\1\164\1\uffff\1\162\1\uffff\1\165\1\uffff\1\166",
            "\12\66\47\uffff\32\67",
            "",
            "\0\167",
            "\0\167",
            "",
            "",
            "",
            "",
            "",
            "",
            "\12\66\47\uffff\1\67\1\171\30\67",
            "\12\66\47\uffff\1\173\7\67\1\172\21\67",
            "\12\66\47\uffff\4\67\1\174\25\67",
            "\12\66\47\uffff\30\67\1\175\1\67",
            "",
            "\12\66\6\uffff\1\176",
            "\12\66\47\uffff\32\67",
            "\12\66\47\uffff\23\67\1\177\6\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\47\uffff\17\67\1\u0081\12\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "",
            "",
            "\12\66\47\uffff\2\67\1\u0083\27\67",
            "\12\66\47\uffff\15\67\1\u0084\14\67",
            "\12\66\47\uffff\21\67\1\u0085\10\67",
            "\12\66\47\uffff\1\u0086\31\67",
            "\12\66\47\uffff\13\67\1\u0087\16\67",
            "\12\66\47\uffff\3\67\1\u0088\26\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\47\uffff\16\67\1\u008a\13\67",
            "\12\66\47\uffff\24\67\1\u008b\5\67",
            "\12\66\47\uffff\16\67\1\u008c\13\67",
            "\12\66\47\uffff\23\67\1\u008d\6\67",
            "\12\66\47\uffff\23\67\1\u008e\6\67",
            "\12\66\47\uffff\7\67\1\u008f\22\67",
            "\12\66\47\uffff\4\67\1\u0090\25\67",
            "\12\66\47\uffff\24\67\1\u0091\5\67",
            "\12\66\47\uffff\22\67\1\u0092\7\67",
            "\12\66\47\uffff\10\67\1\u0093\21\67",
            "\12\66\47\uffff\4\67\1\u0094\25\67",
            "\12\66\47\uffff\15\67\1\u0095\14\67",
            "\12\66\47\uffff\15\67\1\u0096\14\67",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\0\u0098",
            "\0\u009a",
            "",
            "",
            "\12\66\47\uffff\15\67\1\u009b\14\67",
            "\12\66\47\uffff\3\67\1\u009c\26\67",
            "\12\66\47\uffff\17\67\1\u009d\12\67",
            "\12\66\47\uffff\14\67\1\u009e\15\67",
            "",
            "",
            "\12\66\47\uffff\20\67\1\u009f\11\67",
            "",
            "",
            "\1\152\1\uffff\12\151",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\12\66\47\uffff\13\67\1\u00a1\16\67",
            "\12\66\47\uffff\25\67\1\u00a2\4\67",
            "\12\66\47\uffff\6\67\1\u00a3\23\67",
            "\12\66\47\uffff\10\67\1\u00a4\21\67",
            "\12\66\47\uffff\1\u00a5\31\67",
            "",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\4\67\1\u00a6\25\67",
            "",
            "\12\66\47\uffff\16\67\1\u00a8\13\67",
            "",
            "\12\66\47\uffff\1\u00a9\31\67",
            "\12\66\47\uffff\23\67\1\u00aa\6\67",
            "\12\66\47\uffff\10\67\1\u00ab\13\67\1\u00ac\5\67",
            "\12\66\47\uffff\1\67\1\u00ad\30\67",
            "\12\66\47\uffff\10\67\1\u00ae\21\67",
            "\12\66\47\uffff\21\67\1\u00af\10\67",
            "",
            "\12\66\47\uffff\24\67\1\u00b0\5\67",
            "\12\66\47\uffff\1\67\1\u00b1\30\67",
            "\12\66\47\uffff\13\67\1\u00b2\16\67",
            "\12\66\47\uffff\4\67\1\u00b3\25\67",
            "\12\66\47\uffff\4\67\1\u00b4\25\67",
            "\12\66\47\uffff\4\67\1\u00b5\25\67",
            "\12\66\47\uffff\15\67\1\u00b6\14\67",
            "\12\66\47\uffff\14\67\1\u00b7\15\67",
            "\12\66\47\uffff\4\67\1\u00b8\25\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\47\uffff\10\67\1\u00ba\21\67",
            "\12\66\47\uffff\15\67\1\u00bb\14\67",
            "\12\66\47\uffff\2\67\1\u00bc\27\67",
            "",
            "",
            "",
            "",
            "\12\66\47\uffff\22\67\1\u00bd\1\u00be\6\67",
            "\12\66\47\uffff\10\67\1\u00bf\21\67",
            "\12\66\47\uffff\17\67\1\u00c0\12\67",
            "\12\66\47\uffff\16\67\1\u00c1\13\67",
            "\12\66\47\uffff\24\67\1\u00c2\5\67",
            "",
            "\12\66\47\uffff\10\67\1\u00c3\21\67",
            "\12\66\47\uffff\1\u00c4\31\67",
            "\12\66\47\uffff\14\67\1\u00c5\15\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\47\uffff\1\67\1\u00c7\30\67",
            "\12\66\47\uffff\21\67\1\u00c8\10\67",
            "",
            "\12\66\47\uffff\21\67\1\u00c9\10\67",
            "\12\66\47\uffff\13\67\1\u00ca\16\67",
            "\2\66\1\u00cc\5\66\1\u00cb\1\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\47\uffff\15\67\1\u00ce\14\67",
            "\12\66\47\uffff\2\67\1\u00cf\27\67",
            "\12\66\47\uffff\16\67\1\u00d0\13\67",
            "\12\66\47\uffff\3\67\1\u00d1\26\67",
            "\12\66\47\uffff\4\67\1\u00d2\25\67",
            "\12\66\47\uffff\15\67\1\u00d3\14\67",
            "\12\66\47\uffff\13\67\1\u00d4\16\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\22\67\1\u00d6\7\67",
            "\12\66\47\uffff\21\67\1\u00d8\10\67",
            "\12\66\47\uffff\21\67\1\u00d9\10\67",
            "\12\66\47\uffff\23\67\1\u00da\6\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\47\uffff\4\67\1\u00de\25\67",
            "\12\66\47\uffff\23\67\1\u00df\6\67",
            "\12\66\47\uffff\23\67\1\u00e0\6\67",
            "\12\66\47\uffff\21\67\1\u00e1\10\67",
            "\12\66\47\uffff\5\67\1\u00e2\24\67",
            "\12\66\47\uffff\10\67\1\u00e3\21\67",
            "\12\66\47\uffff\21\67\1\u00e4\10\67",
            "\12\66\47\uffff\10\67\1\u00e5\21\67",
            "\12\66\47\uffff\2\67\1\u00e6\27\67",
            "\12\66\47\uffff\23\67\1\u00e7\6\67",
            "\12\66\47\uffff\1\u00e8\31\67",
            "",
            "\12\66\47\uffff\13\67\1\u00e9\16\67",
            "\12\66\47\uffff\5\67\1\u00eb\7\67\1\u00ea\14\67",
            "\12\66\47\uffff\23\67\1\u00ec\6\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\6\uffff\1\176\32\65\4\uffff\1\65\1\uffff\32\65",
            "\5\66\1\u00ef\4\66\6\uffff\1\176",
            "",
            "\12\66\47\uffff\6\67\1\u00f0\23\67",
            "\12\66\47\uffff\23\67\1\u00f1\6\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\47\uffff\10\67\1\u00f3\21\67",
            "\12\66\47\uffff\22\67\1\u00f4\7\67",
            "\12\66\47\uffff\23\67\1\u00f5\6\67",
            "\12\66\47\uffff\4\67\1\u00f6\25\67",
            "",
            "\3\66\1\u00f7\6\66\47\uffff\32\67",
            "",
            "\12\66\47\uffff\15\67\1\u00f8\14\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "",
            "",
            "",
            "\12\66\47\uffff\30\67\1\u00fb\1\67",
            "\12\66\47\uffff\10\67\1\u00fc\21\67",
            "\12\66\47\uffff\21\67\1\u00fd\10\67",
            "\12\66\47\uffff\1\u00fe\31\67",
            "\12\66\47\uffff\10\67\1\u00ff\21\67",
            "\12\66\47\uffff\15\67\1\u0100\14\67",
            "\12\66\47\uffff\30\67\1\u0101\1\67",
            "\12\66\47\uffff\21\67\1\u0102\10\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\47\uffff\4\67\1\u0104\25\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\47\uffff\4\67\1\u0106\25\67",
            "\12\66\47\uffff\1\u0107\31\67",
            "\12\66\47\uffff\1\u0108\31\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "",
            "",
            "\6\66\1\u010a\3\66\6\uffff\1\176",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "",
            "\12\66\47\uffff\23\67\1\u010d\6\67",
            "\12\66\47\uffff\22\67\1\u010e\7\67",
            "\12\66\7\uffff\1\u010f\37\uffff\32\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\2\66\1\u0111\7\66\6\uffff\1\176",
            "\12\66\47\uffff\1\u0112\31\67",
            "",
            "",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\47\uffff\16\67\1\u0114\13\67",
            "\12\66\47\uffff\24\67\1\u0115\5\67",
            "\12\66\47\uffff\2\67\1\u0116\27\67",
            "\12\66\47\uffff\4\67\1\u0117\25\67",
            "\12\66\47\uffff\6\67\1\u0118\23\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\47\uffff\4\67\1\u011a\25\67",
            "",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\47\uffff\13\67\1\u011d\16\67",
            "\12\66\47\uffff\2\67\1\u011e\27\67",
            "",
            "\12\66\6\uffff\1\176\32\65\4\uffff\1\65\1\uffff\32\65",
            "",
            "",
            "\12\66\47\uffff\30\67\1\u0120\1\67",
            "\1\u0121\17\uffff\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\1\u0123",
            "",
            "\12\66\6\uffff\1\176\32\65\4\uffff\1\65\1\uffff\32\65",
            "\12\66\47\uffff\13\67\1\u0125\16\67",
            "",
            "\12\66\47\uffff\15\67\1\u0126\14\67",
            "\12\66\47\uffff\2\67\1\u0127\27\67",
            "\12\66\47\uffff\23\67\1\u0128\6\67",
            "\12\66\47\uffff\21\67\1\u0129\10\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "",
            "",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\47\uffff\4\67\1\u012d\25\67",
            "",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "",
            "",
            "\1\u012f",
            "",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\47\uffff\23\67\1\u0132\6\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "",
            "",
            "",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "",
            "\1\u0136",
            "",
            "",
            "\12\66\47\uffff\16\67\1\u0137\13\67",
            "",
            "",
            "",
            "\1\u0138",
            "\12\66\47\uffff\21\67\1\u0139\10\67",
            "\1\u013a",
            "\12\66\7\uffff\32\65\4\uffff\1\65\1\uffff\32\67",
            "\1\u013c",
            "",
            "\12\65\7\uffff\32\65\4\uffff\1\65\1\uffff\32\65",
            ""
    };

    static final short[] DFA22_eot = DFA.unpackEncodedString(DFA22_eotS);
    static final short[] DFA22_eof = DFA.unpackEncodedString(DFA22_eofS);
    static final char[] DFA22_min = DFA.unpackEncodedStringToUnsignedChars(DFA22_minS);
    static final char[] DFA22_max = DFA.unpackEncodedStringToUnsignedChars(DFA22_maxS);
    static final short[] DFA22_accept = DFA.unpackEncodedString(DFA22_acceptS);
    static final short[] DFA22_special = DFA.unpackEncodedString(DFA22_specialS);
    static final short[][] DFA22_transition;

    static {
        int numStates = DFA22_transitionS.length;
        DFA22_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA22_transition[i] = DFA.unpackEncodedString(DFA22_transitionS[i]);
        }
    }

    class DFA22 extends DFA {

        public DFA22(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 22;
            this.eot = DFA22_eot;
            this.eof = DFA22_eof;
            this.min = DFA22_min;
            this.max = DFA22_max;
            this.accept = DFA22_accept;
            this.special = DFA22_special;
            this.transition = DFA22_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( T__30 | T__31 | T__32 | T__33 | T__34 | T__35 | T__36 | T__37 | T__38 | T__39 | T__40 | T__41 | T__42 | T__43 | T__44 | T__45 | T__46 | T__47 | T__48 | T__49 | T__50 | T__51 | T__52 | T__53 | T__54 | T__55 | T__56 | T__57 | T__58 | T__59 | T__60 | T__61 | T__62 | T__63 | T__64 | T__65 | T__66 | T__67 | T__68 | T__69 | T__70 | T__71 | T__72 | T__73 | T__74 | T__75 | T__76 | T__77 | T__78 | T__79 | T__80 | T__81 | T__82 | T__83 | T__84 | T__85 | T__86 | T__87 | T__88 | T__89 | T__90 | T__91 | RULE_SINGLENUMBER | RULE_INTEGER | RULE_FLOAT | RULE_CLOSEKEY | RULE_OPENKEY | RULE_OPENPARENTHESIS | RULE_CLOSEPARENTHESIS | RULE_EOLINE | RULE_SEMICOLON | RULE_DOT | RULE_IF | RULE_ELSE | RULE_COMMA | RULE_PARAMSLONGCOMENT | RULE_DEVLONGCOMENT | RULE_NOTICELONGCOMENT | RULE_RETURNSLONGCOMENT | RULE_TITLELONGCOMENT | RULE_EMAIL | RULE_ID | RULE_INT | RULE_STRING | RULE_ML_COMMENT | RULE_SL_COMMENT | RULE_WS | RULE_ANY_OTHER );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            IntStream input = _input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA22_93 = input.LA(1);

                        s = -1;
                        if ( ((LA22_93>='\u0000' && LA22_93<='\uFFFF')) ) {s = 154;}

                        else s = 153;

                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA22_41 = input.LA(1);

                        s = -1;
                        if ( ((LA22_41>='\u0000' && LA22_41<='\uFFFF')) ) {s = 119;}

                        else s = 44;

                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA22_92 = input.LA(1);

                        s = -1;
                        if ( ((LA22_92>='\u0000' && LA22_92<='\uFFFF')) ) {s = 152;}

                        else s = 151;

                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA22_0 = input.LA(1);

                        s = -1;
                        if ( (LA22_0=='>') ) {s = 1;}

                        else if ( (LA22_0=='<') ) {s = 2;}

                        else if ( (LA22_0=='p') ) {s = 3;}

                        else if ( (LA22_0=='i') ) {s = 4;}

                        else if ( (LA22_0=='[') ) {s = 5;}

                        else if ( (LA22_0=='l') ) {s = 6;}

                        else if ( (LA22_0=='u') ) {s = 7;}

                        else if ( (LA22_0=='s') ) {s = 8;}

                        else if ( (LA22_0=='a') ) {s = 9;}

                        else if ( (LA22_0=='d') ) {s = 10;}

                        else if ( (LA22_0=='b') ) {s = 11;}

                        else if ( (LA22_0=='e') ) {s = 12;}

                        else if ( (LA22_0=='w') ) {s = 13;}

                        else if ( (LA22_0=='g') ) {s = 14;}

                        else if ( (LA22_0=='f') ) {s = 15;}

                        else if ( (LA22_0=='=') ) {s = 16;}

                        else if ( (LA22_0=='!') ) {s = 17;}

                        else if ( (LA22_0=='&') ) {s = 18;}

                        else if ( (LA22_0=='|') ) {s = 19;}

                        else if ( (LA22_0=='+') ) {s = 20;}

                        else if ( (LA22_0=='-') ) {s = 21;}

                        else if ( (LA22_0=='*') ) {s = 22;}

                        else if ( (LA22_0=='/') ) {s = 23;}

                        else if ( (LA22_0=='c') ) {s = 24;}

                        else if ( (LA22_0=='m') ) {s = 25;}

                        else if ( (LA22_0=='_') ) {s = 26;}

                        else if ( (LA22_0==']') ) {s = 27;}

                        else if ( (LA22_0=='r') ) {s = 28;}

                        else if ( (LA22_0=='^') ) {s = 29;}

                        else if ( ((LA22_0>='0' && LA22_0<='9')) ) {s = 30;}

                        else if ( (LA22_0=='}') ) {s = 31;}

                        else if ( (LA22_0=='{') ) {s = 32;}

                        else if ( (LA22_0=='(') ) {s = 33;}

                        else if ( (LA22_0==')') ) {s = 34;}

                        else if ( (LA22_0==';') ) {s = 35;}

                        else if ( (LA22_0=='.') ) {s = 36;}

                        else if ( (LA22_0==',') ) {s = 37;}

                        else if ( (LA22_0=='@') ) {s = 38;}

                        else if ( (LA22_0=='h'||(LA22_0>='j' && LA22_0<='k')||(LA22_0>='n' && LA22_0<='o')||LA22_0=='q'||LA22_0=='t'||LA22_0=='v'||(LA22_0>='x' && LA22_0<='z')) ) {s = 39;}

                        else if ( ((LA22_0>='A' && LA22_0<='Z')) ) {s = 40;}

                        else if ( (LA22_0=='\"') ) {s = 41;}

                        else if ( (LA22_0=='\'') ) {s = 42;}

                        else if ( ((LA22_0>='\t' && LA22_0<='\n')||LA22_0=='\r'||LA22_0==' ') ) {s = 43;}

                        else if ( ((LA22_0>='\u0000' && LA22_0<='\b')||(LA22_0>='\u000B' && LA22_0<='\f')||(LA22_0>='\u000E' && LA22_0<='\u001F')||(LA22_0>='#' && LA22_0<='%')||LA22_0==':'||LA22_0=='?'||LA22_0=='\\'||LA22_0=='`'||(LA22_0>='~' && LA22_0<='\uFFFF')) ) {s = 44;}

                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA22_42 = input.LA(1);

                        s = -1;
                        if ( ((LA22_42>='\u0000' && LA22_42<='\uFFFF')) ) {s = 119;}

                        else s = 44;

                        if ( s>=0 ) return s;
                        break;
            }
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 22, _s, input);
            error(nvae);
            throw nvae;
        }
    }
 

}