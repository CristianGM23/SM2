package org.xtext.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_DOT", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_OPENKEY", "RULE_CLOSEKEY", "RULE_STRING", "RULE_COMMA", "RULE_NUMVERSION1", "RULE_NUMVERSION2", "RULE_NUMVERSION3", "RULE_BOOLVALUE", "RULE_IF", "RULE_ELSE", "RULE_RETURN", "RULE_RETURNS", "RULE_EMIT", "RULE_BREAK", "RULE_CONTINUE", "RULE_NEW", "RULE_DELETE", "RULE_PARAMSLONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_NOTICELONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_EMAIL", "RULE_CONSTANT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'!'", "'data'", "'value'", "'gas'", "'sender'", "'sig'", "'origin'", "'gasprice'", "'^'", "'>'", "'>='", "'public'", "'internal'", "'private'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'<'", "'<='", "'=='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'", "'%'", "'msg'", "'tx'", "'contract'", "'is'", "'pragma'", "'solidity'", "'constructor'", "'import'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'enum'", "'='", "'require'", "'function'", "'selfdesctruct'", "'keccack256'", "'sha256'", "'sha3'", "'//'", "'/*'", "'*/'", "'int'", "'uint'", "'uint8'", "'string'", "'address'", "'address payable'", "'double'", "'bool'"
    };
    public static final int T__50=50;
    public static final int RULE_RETURNS=22;
    public static final int RULE_OPENPARENTHESIS=7;
    public static final int RULE_EOLINE=10;
    public static final int T__59=59;
    public static final int RULE_EMIT=23;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_PARAMSLONGCOMENT=28;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int RULE_RETURN=21;
    public static final int RULE_INT=5;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=35;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int RULE_DELETE=27;
    public static final int RULE_TITLELONGCOMENT=32;
    public static final int RULE_NOTICELONGCOMENT=30;
    public static final int RULE_EMAIL=33;
    public static final int RULE_CONSTANT=34;
    public static final int RULE_OPENKEY=11;
    public static final int T__39=39;
    public static final int RULE_CLOSEPARENTHESIS=8;
    public static final int RULE_IF=19;
    public static final int RULE_DOT=6;
    public static final int RULE_CONTINUE=25;
    public static final int RULE_DEVLONGCOMENT=29;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__91=91;
    public static final int T__100=100;
    public static final int T__92=92;
    public static final int T__93=93;
    public static final int T__94=94;
    public static final int T__101=101;
    public static final int RULE_NEW=26;
    public static final int T__90=90;
    public static final int T__99=99;
    public static final int RULE_CLOSEKEY=12;
    public static final int T__95=95;
    public static final int T__96=96;
    public static final int T__97=97;
    public static final int T__98=98;
    public static final int RULE_COMMA=14;
    public static final int RULE_RETURNSLONGCOMENT=31;
    public static final int RULE_SEMICOLON=9;
    public static final int RULE_NUMVERSION3=17;
    public static final int RULE_NUMVERSION2=16;
    public static final int RULE_ELSE=20;
    public static final int RULE_NUMVERSION1=15;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int RULE_BOOLVALUE=18;
    public static final int T__72=72;
    public static final int RULE_STRING=13;
    public static final int RULE_SL_COMMENT=36;
    public static final int RULE_BREAK=24;
    public static final int T__77=77;
    public static final int T__78=78;
    public static final int T__79=79;
    public static final int T__73=73;
    public static final int EOF=-1;
    public static final int T__74=74;
    public static final int T__75=75;
    public static final int T__76=76;
    public static final int T__80=80;
    public static final int T__81=81;
    public static final int T__82=82;
    public static final int T__83=83;
    public static final int RULE_WS=37;
    public static final int RULE_ANY_OTHER=38;
    public static final int T__88=88;
    public static final int T__89=89;
    public static final int T__84=84;
    public static final int T__85=85;
    public static final int T__86=86;
    public static final int T__87=87;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }


    	private SM2GrammarAccess grammarAccess;

    	public void setGrammarAccess(SM2GrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleFile"
    // InternalSM2.g:53:1: entryRuleFile : ruleFile EOF ;
    public final void entryRuleFile() throws RecognitionException {
        try {
            // InternalSM2.g:54:1: ( ruleFile EOF )
            // InternalSM2.g:55:1: ruleFile EOF
            {
             before(grammarAccess.getFileRule()); 
            pushFollow(FOLLOW_1);
            ruleFile();

            state._fsp--;

             after(grammarAccess.getFileRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFile"


    // $ANTLR start "ruleFile"
    // InternalSM2.g:62:1: ruleFile : ( ( rule__File__Group__0 ) ) ;
    public final void ruleFile() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:66:2: ( ( ( rule__File__Group__0 ) ) )
            // InternalSM2.g:67:2: ( ( rule__File__Group__0 ) )
            {
            // InternalSM2.g:67:2: ( ( rule__File__Group__0 ) )
            // InternalSM2.g:68:3: ( rule__File__Group__0 )
            {
             before(grammarAccess.getFileAccess().getGroup()); 
            // InternalSM2.g:69:3: ( rule__File__Group__0 )
            // InternalSM2.g:69:4: rule__File__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__File__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFileAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFile"


    // $ANTLR start "entryRuleMSGVariables"
    // InternalSM2.g:78:1: entryRuleMSGVariables : ruleMSGVariables EOF ;
    public final void entryRuleMSGVariables() throws RecognitionException {
        try {
            // InternalSM2.g:79:1: ( ruleMSGVariables EOF )
            // InternalSM2.g:80:1: ruleMSGVariables EOF
            {
             before(grammarAccess.getMSGVariablesRule()); 
            pushFollow(FOLLOW_1);
            ruleMSGVariables();

            state._fsp--;

             after(grammarAccess.getMSGVariablesRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMSGVariables"


    // $ANTLR start "ruleMSGVariables"
    // InternalSM2.g:87:1: ruleMSGVariables : ( ( rule__MSGVariables__Group__0 ) ) ;
    public final void ruleMSGVariables() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:91:2: ( ( ( rule__MSGVariables__Group__0 ) ) )
            // InternalSM2.g:92:2: ( ( rule__MSGVariables__Group__0 ) )
            {
            // InternalSM2.g:92:2: ( ( rule__MSGVariables__Group__0 ) )
            // InternalSM2.g:93:3: ( rule__MSGVariables__Group__0 )
            {
             before(grammarAccess.getMSGVariablesAccess().getGroup()); 
            // InternalSM2.g:94:3: ( rule__MSGVariables__Group__0 )
            // InternalSM2.g:94:4: rule__MSGVariables__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__MSGVariables__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getMSGVariablesAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMSGVariables"


    // $ANTLR start "entryRuleMSGOperation"
    // InternalSM2.g:103:1: entryRuleMSGOperation : ruleMSGOperation EOF ;
    public final void entryRuleMSGOperation() throws RecognitionException {
        try {
            // InternalSM2.g:104:1: ( ruleMSGOperation EOF )
            // InternalSM2.g:105:1: ruleMSGOperation EOF
            {
             before(grammarAccess.getMSGOperationRule()); 
            pushFollow(FOLLOW_1);
            ruleMSGOperation();

            state._fsp--;

             after(grammarAccess.getMSGOperationRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMSGOperation"


    // $ANTLR start "ruleMSGOperation"
    // InternalSM2.g:112:1: ruleMSGOperation : ( ( rule__MSGOperation__Group__0 ) ) ;
    public final void ruleMSGOperation() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:116:2: ( ( ( rule__MSGOperation__Group__0 ) ) )
            // InternalSM2.g:117:2: ( ( rule__MSGOperation__Group__0 ) )
            {
            // InternalSM2.g:117:2: ( ( rule__MSGOperation__Group__0 ) )
            // InternalSM2.g:118:3: ( rule__MSGOperation__Group__0 )
            {
             before(grammarAccess.getMSGOperationAccess().getGroup()); 
            // InternalSM2.g:119:3: ( rule__MSGOperation__Group__0 )
            // InternalSM2.g:119:4: rule__MSGOperation__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getMSGOperationAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMSGOperation"


    // $ANTLR start "entryRuleTxVariables"
    // InternalSM2.g:128:1: entryRuleTxVariables : ruleTxVariables EOF ;
    public final void entryRuleTxVariables() throws RecognitionException {
        try {
            // InternalSM2.g:129:1: ( ruleTxVariables EOF )
            // InternalSM2.g:130:1: ruleTxVariables EOF
            {
             before(grammarAccess.getTxVariablesRule()); 
            pushFollow(FOLLOW_1);
            ruleTxVariables();

            state._fsp--;

             after(grammarAccess.getTxVariablesRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTxVariables"


    // $ANTLR start "ruleTxVariables"
    // InternalSM2.g:137:1: ruleTxVariables : ( ( rule__TxVariables__Group__0 ) ) ;
    public final void ruleTxVariables() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:141:2: ( ( ( rule__TxVariables__Group__0 ) ) )
            // InternalSM2.g:142:2: ( ( rule__TxVariables__Group__0 ) )
            {
            // InternalSM2.g:142:2: ( ( rule__TxVariables__Group__0 ) )
            // InternalSM2.g:143:3: ( rule__TxVariables__Group__0 )
            {
             before(grammarAccess.getTxVariablesAccess().getGroup()); 
            // InternalSM2.g:144:3: ( rule__TxVariables__Group__0 )
            // InternalSM2.g:144:4: rule__TxVariables__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__TxVariables__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTxVariablesAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTxVariables"


    // $ANTLR start "entryRuleTxOperation"
    // InternalSM2.g:153:1: entryRuleTxOperation : ruleTxOperation EOF ;
    public final void entryRuleTxOperation() throws RecognitionException {
        try {
            // InternalSM2.g:154:1: ( ruleTxOperation EOF )
            // InternalSM2.g:155:1: ruleTxOperation EOF
            {
             before(grammarAccess.getTxOperationRule()); 
            pushFollow(FOLLOW_1);
            ruleTxOperation();

            state._fsp--;

             after(grammarAccess.getTxOperationRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTxOperation"


    // $ANTLR start "ruleTxOperation"
    // InternalSM2.g:162:1: ruleTxOperation : ( ( rule__TxOperation__Group__0 ) ) ;
    public final void ruleTxOperation() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:166:2: ( ( ( rule__TxOperation__Group__0 ) ) )
            // InternalSM2.g:167:2: ( ( rule__TxOperation__Group__0 ) )
            {
            // InternalSM2.g:167:2: ( ( rule__TxOperation__Group__0 ) )
            // InternalSM2.g:168:3: ( rule__TxOperation__Group__0 )
            {
             before(grammarAccess.getTxOperationAccess().getGroup()); 
            // InternalSM2.g:169:3: ( rule__TxOperation__Group__0 )
            // InternalSM2.g:169:4: rule__TxOperation__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__TxOperation__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTxOperationAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTxOperation"


    // $ANTLR start "entryRuleContract"
    // InternalSM2.g:178:1: entryRuleContract : ruleContract EOF ;
    public final void entryRuleContract() throws RecognitionException {
        try {
            // InternalSM2.g:179:1: ( ruleContract EOF )
            // InternalSM2.g:180:1: ruleContract EOF
            {
             before(grammarAccess.getContractRule()); 
            pushFollow(FOLLOW_1);
            ruleContract();

            state._fsp--;

             after(grammarAccess.getContractRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleContract"


    // $ANTLR start "ruleContract"
    // InternalSM2.g:187:1: ruleContract : ( ( rule__Contract__Group__0 ) ) ;
    public final void ruleContract() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:191:2: ( ( ( rule__Contract__Group__0 ) ) )
            // InternalSM2.g:192:2: ( ( rule__Contract__Group__0 ) )
            {
            // InternalSM2.g:192:2: ( ( rule__Contract__Group__0 ) )
            // InternalSM2.g:193:3: ( rule__Contract__Group__0 )
            {
             before(grammarAccess.getContractAccess().getGroup()); 
            // InternalSM2.g:194:3: ( rule__Contract__Group__0 )
            // InternalSM2.g:194:4: rule__Contract__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Contract__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getContractAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:203:1: entryRuleVersion : ruleVersion EOF ;
    public final void entryRuleVersion() throws RecognitionException {
        try {
            // InternalSM2.g:204:1: ( ruleVersion EOF )
            // InternalSM2.g:205:1: ruleVersion EOF
            {
             before(grammarAccess.getVersionRule()); 
            pushFollow(FOLLOW_1);
            ruleVersion();

            state._fsp--;

             after(grammarAccess.getVersionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:212:1: ruleVersion : ( ( rule__Version__Group__0 ) ) ;
    public final void ruleVersion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:216:2: ( ( ( rule__Version__Group__0 ) ) )
            // InternalSM2.g:217:2: ( ( rule__Version__Group__0 ) )
            {
            // InternalSM2.g:217:2: ( ( rule__Version__Group__0 ) )
            // InternalSM2.g:218:3: ( rule__Version__Group__0 )
            {
             before(grammarAccess.getVersionAccess().getGroup()); 
            // InternalSM2.g:219:3: ( rule__Version__Group__0 )
            // InternalSM2.g:219:4: rule__Version__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleConstructor"
    // InternalSM2.g:228:1: entryRuleConstructor : ruleConstructor EOF ;
    public final void entryRuleConstructor() throws RecognitionException {
        try {
            // InternalSM2.g:229:1: ( ruleConstructor EOF )
            // InternalSM2.g:230:1: ruleConstructor EOF
            {
             before(grammarAccess.getConstructorRule()); 
            pushFollow(FOLLOW_1);
            ruleConstructor();

            state._fsp--;

             after(grammarAccess.getConstructorRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleConstructor"


    // $ANTLR start "ruleConstructor"
    // InternalSM2.g:237:1: ruleConstructor : ( ( rule__Constructor__Group__0 ) ) ;
    public final void ruleConstructor() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:241:2: ( ( ( rule__Constructor__Group__0 ) ) )
            // InternalSM2.g:242:2: ( ( rule__Constructor__Group__0 ) )
            {
            // InternalSM2.g:242:2: ( ( rule__Constructor__Group__0 ) )
            // InternalSM2.g:243:3: ( rule__Constructor__Group__0 )
            {
             before(grammarAccess.getConstructorAccess().getGroup()); 
            // InternalSM2.g:244:3: ( rule__Constructor__Group__0 )
            // InternalSM2.g:244:4: rule__Constructor__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Constructor__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getConstructorAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleConstructor"


    // $ANTLR start "entryRuleImport"
    // InternalSM2.g:253:1: entryRuleImport : ruleImport EOF ;
    public final void entryRuleImport() throws RecognitionException {
        try {
            // InternalSM2.g:254:1: ( ruleImport EOF )
            // InternalSM2.g:255:1: ruleImport EOF
            {
             before(grammarAccess.getImportRule()); 
            pushFollow(FOLLOW_1);
            ruleImport();

            state._fsp--;

             after(grammarAccess.getImportRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2.g:262:1: ruleImport : ( ( rule__Import__Group__0 ) ) ;
    public final void ruleImport() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:266:2: ( ( ( rule__Import__Group__0 ) ) )
            // InternalSM2.g:267:2: ( ( rule__Import__Group__0 ) )
            {
            // InternalSM2.g:267:2: ( ( rule__Import__Group__0 ) )
            // InternalSM2.g:268:3: ( rule__Import__Group__0 )
            {
             before(grammarAccess.getImportAccess().getGroup()); 
            // InternalSM2.g:269:3: ( rule__Import__Group__0 )
            // InternalSM2.g:269:4: rule__Import__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getImportAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:278:1: entryRuleAttributes : ruleAttributes EOF ;
    public final void entryRuleAttributes() throws RecognitionException {
        try {
            // InternalSM2.g:279:1: ( ruleAttributes EOF )
            // InternalSM2.g:280:1: ruleAttributes EOF
            {
             before(grammarAccess.getAttributesRule()); 
            pushFollow(FOLLOW_1);
            ruleAttributes();

            state._fsp--;

             after(grammarAccess.getAttributesRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:287:1: ruleAttributes : ( ruleDataType ) ;
    public final void ruleAttributes() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:291:2: ( ( ruleDataType ) )
            // InternalSM2.g:292:2: ( ruleDataType )
            {
            // InternalSM2.g:292:2: ( ruleDataType )
            // InternalSM2.g:293:3: ruleDataType
            {
             before(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall()); 
            pushFollow(FOLLOW_2);
            ruleDataType();

            state._fsp--;

             after(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:303:1: entryRuleModifier : ruleModifier EOF ;
    public final void entryRuleModifier() throws RecognitionException {
        try {
            // InternalSM2.g:304:1: ( ruleModifier EOF )
            // InternalSM2.g:305:1: ruleModifier EOF
            {
             before(grammarAccess.getModifierRule()); 
            pushFollow(FOLLOW_1);
            ruleModifier();

            state._fsp--;

             after(grammarAccess.getModifierRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:312:1: ruleModifier : ( ( rule__Modifier__Group__0 ) ) ;
    public final void ruleModifier() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:316:2: ( ( ( rule__Modifier__Group__0 ) ) )
            // InternalSM2.g:317:2: ( ( rule__Modifier__Group__0 ) )
            {
            // InternalSM2.g:317:2: ( ( rule__Modifier__Group__0 ) )
            // InternalSM2.g:318:3: ( rule__Modifier__Group__0 )
            {
             before(grammarAccess.getModifierAccess().getGroup()); 
            // InternalSM2.g:319:3: ( rule__Modifier__Group__0 )
            // InternalSM2.g:319:4: rule__Modifier__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getModifierAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:328:1: entryRuleDataType : ruleDataType EOF ;
    public final void entryRuleDataType() throws RecognitionException {
        try {
            // InternalSM2.g:329:1: ( ruleDataType EOF )
            // InternalSM2.g:330:1: ruleDataType EOF
            {
             before(grammarAccess.getDataTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleDataType();

            state._fsp--;

             after(grammarAccess.getDataTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:337:1: ruleDataType : ( ( rule__DataType__Alternatives ) ) ;
    public final void ruleDataType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:341:2: ( ( ( rule__DataType__Alternatives ) ) )
            // InternalSM2.g:342:2: ( ( rule__DataType__Alternatives ) )
            {
            // InternalSM2.g:342:2: ( ( rule__DataType__Alternatives ) )
            // InternalSM2.g:343:3: ( rule__DataType__Alternatives )
            {
             before(grammarAccess.getDataTypeAccess().getAlternatives()); 
            // InternalSM2.g:344:3: ( rule__DataType__Alternatives )
            // InternalSM2.g:344:4: rule__DataType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__DataType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getDataTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2.g:353:1: entryRuleCompositeType : ruleCompositeType EOF ;
    public final void entryRuleCompositeType() throws RecognitionException {
        try {
            // InternalSM2.g:354:1: ( ruleCompositeType EOF )
            // InternalSM2.g:355:1: ruleCompositeType EOF
            {
             before(grammarAccess.getCompositeTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleCompositeType();

            state._fsp--;

             after(grammarAccess.getCompositeTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2.g:362:1: ruleCompositeType : ( ( rule__CompositeType__Alternatives ) ) ;
    public final void ruleCompositeType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:366:2: ( ( ( rule__CompositeType__Alternatives ) ) )
            // InternalSM2.g:367:2: ( ( rule__CompositeType__Alternatives ) )
            {
            // InternalSM2.g:367:2: ( ( rule__CompositeType__Alternatives ) )
            // InternalSM2.g:368:3: ( rule__CompositeType__Alternatives )
            {
             before(grammarAccess.getCompositeTypeAccess().getAlternatives()); 
            // InternalSM2.g:369:3: ( rule__CompositeType__Alternatives )
            // InternalSM2.g:369:4: rule__CompositeType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__CompositeType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCompositeTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleSingularType"
    // InternalSM2.g:378:1: entryRuleSingularType : ruleSingularType EOF ;
    public final void entryRuleSingularType() throws RecognitionException {
        try {
            // InternalSM2.g:379:1: ( ruleSingularType EOF )
            // InternalSM2.g:380:1: ruleSingularType EOF
            {
             before(grammarAccess.getSingularTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleSingularType();

            state._fsp--;

             after(grammarAccess.getSingularTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSingularType"


    // $ANTLR start "ruleSingularType"
    // InternalSM2.g:387:1: ruleSingularType : ( ( rule__SingularType__Alternatives ) ) ;
    public final void ruleSingularType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:391:2: ( ( ( rule__SingularType__Alternatives ) ) )
            // InternalSM2.g:392:2: ( ( rule__SingularType__Alternatives ) )
            {
            // InternalSM2.g:392:2: ( ( rule__SingularType__Alternatives ) )
            // InternalSM2.g:393:3: ( rule__SingularType__Alternatives )
            {
             before(grammarAccess.getSingularTypeAccess().getAlternatives()); 
            // InternalSM2.g:394:3: ( rule__SingularType__Alternatives )
            // InternalSM2.g:394:4: rule__SingularType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__SingularType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getSingularTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:403:1: entryRuleMapping : ruleMapping EOF ;
    public final void entryRuleMapping() throws RecognitionException {
        try {
            // InternalSM2.g:404:1: ( ruleMapping EOF )
            // InternalSM2.g:405:1: ruleMapping EOF
            {
             before(grammarAccess.getMappingRule()); 
            pushFollow(FOLLOW_1);
            ruleMapping();

            state._fsp--;

             after(grammarAccess.getMappingRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:412:1: ruleMapping : ( ( rule__Mapping__Group__0 ) ) ;
    public final void ruleMapping() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:416:2: ( ( ( rule__Mapping__Group__0 ) ) )
            // InternalSM2.g:417:2: ( ( rule__Mapping__Group__0 ) )
            {
            // InternalSM2.g:417:2: ( ( rule__Mapping__Group__0 ) )
            // InternalSM2.g:418:3: ( rule__Mapping__Group__0 )
            {
             before(grammarAccess.getMappingAccess().getGroup()); 
            // InternalSM2.g:419:3: ( rule__Mapping__Group__0 )
            // InternalSM2.g:419:4: rule__Mapping__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:428:1: entryRuleStruct : ruleStruct EOF ;
    public final void entryRuleStruct() throws RecognitionException {
        try {
            // InternalSM2.g:429:1: ( ruleStruct EOF )
            // InternalSM2.g:430:1: ruleStruct EOF
            {
             before(grammarAccess.getStructRule()); 
            pushFollow(FOLLOW_1);
            ruleStruct();

            state._fsp--;

             after(grammarAccess.getStructRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:437:1: ruleStruct : ( ( rule__Struct__Group__0 ) ) ;
    public final void ruleStruct() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:441:2: ( ( ( rule__Struct__Group__0 ) ) )
            // InternalSM2.g:442:2: ( ( rule__Struct__Group__0 ) )
            {
            // InternalSM2.g:442:2: ( ( rule__Struct__Group__0 ) )
            // InternalSM2.g:443:3: ( rule__Struct__Group__0 )
            {
             before(grammarAccess.getStructAccess().getGroup()); 
            // InternalSM2.g:444:3: ( rule__Struct__Group__0 )
            // InternalSM2.g:444:4: rule__Struct__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Struct__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStructAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:453:1: entryRuleEnum : ruleEnum EOF ;
    public final void entryRuleEnum() throws RecognitionException {
        try {
            // InternalSM2.g:454:1: ( ruleEnum EOF )
            // InternalSM2.g:455:1: ruleEnum EOF
            {
             before(grammarAccess.getEnumRule()); 
            pushFollow(FOLLOW_1);
            ruleEnum();

            state._fsp--;

             after(grammarAccess.getEnumRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:462:1: ruleEnum : ( ( rule__Enum__Group__0 ) ) ;
    public final void ruleEnum() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:466:2: ( ( ( rule__Enum__Group__0 ) ) )
            // InternalSM2.g:467:2: ( ( rule__Enum__Group__0 ) )
            {
            // InternalSM2.g:467:2: ( ( rule__Enum__Group__0 ) )
            // InternalSM2.g:468:3: ( rule__Enum__Group__0 )
            {
             before(grammarAccess.getEnumAccess().getGroup()); 
            // InternalSM2.g:469:3: ( rule__Enum__Group__0 )
            // InternalSM2.g:469:4: rule__Enum__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Enum__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEnumAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:478:1: entryRuleProperty : ruleProperty EOF ;
    public final void entryRuleProperty() throws RecognitionException {
        try {
            // InternalSM2.g:479:1: ( ruleProperty EOF )
            // InternalSM2.g:480:1: ruleProperty EOF
            {
             before(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_1);
            ruleProperty();

            state._fsp--;

             after(grammarAccess.getPropertyRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:487:1: ruleProperty : ( ( rule__Property__Group__0 ) ) ;
    public final void ruleProperty() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:491:2: ( ( ( rule__Property__Group__0 ) ) )
            // InternalSM2.g:492:2: ( ( rule__Property__Group__0 ) )
            {
            // InternalSM2.g:492:2: ( ( rule__Property__Group__0 ) )
            // InternalSM2.g:493:3: ( rule__Property__Group__0 )
            {
             before(grammarAccess.getPropertyAccess().getGroup()); 
            // InternalSM2.g:494:3: ( rule__Property__Group__0 )
            // InternalSM2.g:494:4: rule__Property__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Property__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPropertyAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:503:1: entryRuleInputParam : ruleInputParam EOF ;
    public final void entryRuleInputParam() throws RecognitionException {
        try {
            // InternalSM2.g:504:1: ( ruleInputParam EOF )
            // InternalSM2.g:505:1: ruleInputParam EOF
            {
             before(grammarAccess.getInputParamRule()); 
            pushFollow(FOLLOW_1);
            ruleInputParam();

            state._fsp--;

             after(grammarAccess.getInputParamRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:512:1: ruleInputParam : ( ( rule__InputParam__Group__0 ) ) ;
    public final void ruleInputParam() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:516:2: ( ( ( rule__InputParam__Group__0 ) ) )
            // InternalSM2.g:517:2: ( ( rule__InputParam__Group__0 ) )
            {
            // InternalSM2.g:517:2: ( ( rule__InputParam__Group__0 ) )
            // InternalSM2.g:518:3: ( rule__InputParam__Group__0 )
            {
             before(grammarAccess.getInputParamAccess().getGroup()); 
            // InternalSM2.g:519:3: ( rule__InputParam__Group__0 )
            // InternalSM2.g:519:4: rule__InputParam__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getInputParamAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestrictionClause"
    // InternalSM2.g:528:1: entryRuleRestrictionClause : ruleRestrictionClause EOF ;
    public final void entryRuleRestrictionClause() throws RecognitionException {
        try {
            // InternalSM2.g:529:1: ( ruleRestrictionClause EOF )
            // InternalSM2.g:530:1: ruleRestrictionClause EOF
            {
             before(grammarAccess.getRestrictionClauseRule()); 
            pushFollow(FOLLOW_1);
            ruleRestrictionClause();

            state._fsp--;

             after(grammarAccess.getRestrictionClauseRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRestrictionClause"


    // $ANTLR start "ruleRestrictionClause"
    // InternalSM2.g:537:1: ruleRestrictionClause : ( ( rule__RestrictionClause__Alternatives ) ) ;
    public final void ruleRestrictionClause() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:541:2: ( ( ( rule__RestrictionClause__Alternatives ) ) )
            // InternalSM2.g:542:2: ( ( rule__RestrictionClause__Alternatives ) )
            {
            // InternalSM2.g:542:2: ( ( rule__RestrictionClause__Alternatives ) )
            // InternalSM2.g:543:3: ( rule__RestrictionClause__Alternatives )
            {
             before(grammarAccess.getRestrictionClauseAccess().getAlternatives()); 
            // InternalSM2.g:544:3: ( rule__RestrictionClause__Alternatives )
            // InternalSM2.g:544:4: rule__RestrictionClause__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionClause__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionClauseAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRestrictionClause"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:553:1: entryRuleRestriction : ruleRestriction EOF ;
    public final void entryRuleRestriction() throws RecognitionException {
        try {
            // InternalSM2.g:554:1: ( ruleRestriction EOF )
            // InternalSM2.g:555:1: ruleRestriction EOF
            {
             before(grammarAccess.getRestrictionRule()); 
            pushFollow(FOLLOW_1);
            ruleRestriction();

            state._fsp--;

             after(grammarAccess.getRestrictionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:562:1: ruleRestriction : ( ( rule__Restriction__Group__0 ) ) ;
    public final void ruleRestriction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:566:2: ( ( ( rule__Restriction__Group__0 ) ) )
            // InternalSM2.g:567:2: ( ( rule__Restriction__Group__0 ) )
            {
            // InternalSM2.g:567:2: ( ( rule__Restriction__Group__0 ) )
            // InternalSM2.g:568:3: ( rule__Restriction__Group__0 )
            {
             before(grammarAccess.getRestrictionAccess().getGroup()); 
            // InternalSM2.g:569:3: ( rule__Restriction__Group__0 )
            // InternalSM2.g:569:4: rule__Restriction__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:578:1: entryRuleRestrictionGas : ruleRestrictionGas EOF ;
    public final void entryRuleRestrictionGas() throws RecognitionException {
        try {
            // InternalSM2.g:579:1: ( ruleRestrictionGas EOF )
            // InternalSM2.g:580:1: ruleRestrictionGas EOF
            {
             before(grammarAccess.getRestrictionGasRule()); 
            pushFollow(FOLLOW_1);
            ruleRestrictionGas();

            state._fsp--;

             after(grammarAccess.getRestrictionGasRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:587:1: ruleRestrictionGas : ( ( rule__RestrictionGas__Group__0 ) ) ;
    public final void ruleRestrictionGas() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:591:2: ( ( ( rule__RestrictionGas__Group__0 ) ) )
            // InternalSM2.g:592:2: ( ( rule__RestrictionGas__Group__0 ) )
            {
            // InternalSM2.g:592:2: ( ( rule__RestrictionGas__Group__0 ) )
            // InternalSM2.g:593:3: ( rule__RestrictionGas__Group__0 )
            {
             before(grammarAccess.getRestrictionGasAccess().getGroup()); 
            // InternalSM2.g:594:3: ( rule__RestrictionGas__Group__0 )
            // InternalSM2.g:594:4: rule__RestrictionGas__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2.g:603:1: entryRuleClause : ruleClause EOF ;
    public final void entryRuleClause() throws RecognitionException {
        try {
            // InternalSM2.g:604:1: ( ruleClause EOF )
            // InternalSM2.g:605:1: ruleClause EOF
            {
             before(grammarAccess.getClauseRule()); 
            pushFollow(FOLLOW_1);
            ruleClause();

            state._fsp--;

             after(grammarAccess.getClauseRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2.g:612:1: ruleClause : ( ( rule__Clause__Group__0 ) ) ;
    public final void ruleClause() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:616:2: ( ( ( rule__Clause__Group__0 ) ) )
            // InternalSM2.g:617:2: ( ( rule__Clause__Group__0 ) )
            {
            // InternalSM2.g:617:2: ( ( rule__Clause__Group__0 ) )
            // InternalSM2.g:618:3: ( rule__Clause__Group__0 )
            {
             before(grammarAccess.getClauseAccess().getGroup()); 
            // InternalSM2.g:619:3: ( rule__Clause__Group__0 )
            // InternalSM2.g:619:4: rule__Clause__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Clause__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRuleSelfdestruct"
    // InternalSM2.g:628:1: entryRuleSelfdestruct : ruleSelfdestruct EOF ;
    public final void entryRuleSelfdestruct() throws RecognitionException {
        try {
            // InternalSM2.g:629:1: ( ruleSelfdestruct EOF )
            // InternalSM2.g:630:1: ruleSelfdestruct EOF
            {
             before(grammarAccess.getSelfdestructRule()); 
            pushFollow(FOLLOW_1);
            ruleSelfdestruct();

            state._fsp--;

             after(grammarAccess.getSelfdestructRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSelfdestruct"


    // $ANTLR start "ruleSelfdestruct"
    // InternalSM2.g:637:1: ruleSelfdestruct : ( ( rule__Selfdestruct__Group__0 ) ) ;
    public final void ruleSelfdestruct() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:641:2: ( ( ( rule__Selfdestruct__Group__0 ) ) )
            // InternalSM2.g:642:2: ( ( rule__Selfdestruct__Group__0 ) )
            {
            // InternalSM2.g:642:2: ( ( rule__Selfdestruct__Group__0 ) )
            // InternalSM2.g:643:3: ( rule__Selfdestruct__Group__0 )
            {
             before(grammarAccess.getSelfdestructAccess().getGroup()); 
            // InternalSM2.g:644:3: ( rule__Selfdestruct__Group__0 )
            // InternalSM2.g:644:4: rule__Selfdestruct__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSelfdestructAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSelfdestruct"


    // $ANTLR start "entryRuleCryptographycFunctions"
    // InternalSM2.g:653:1: entryRuleCryptographycFunctions : ruleCryptographycFunctions EOF ;
    public final void entryRuleCryptographycFunctions() throws RecognitionException {
        try {
            // InternalSM2.g:654:1: ( ruleCryptographycFunctions EOF )
            // InternalSM2.g:655:1: ruleCryptographycFunctions EOF
            {
             before(grammarAccess.getCryptographycFunctionsRule()); 
            pushFollow(FOLLOW_1);
            ruleCryptographycFunctions();

            state._fsp--;

             after(grammarAccess.getCryptographycFunctionsRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCryptographycFunctions"


    // $ANTLR start "ruleCryptographycFunctions"
    // InternalSM2.g:662:1: ruleCryptographycFunctions : ( ( rule__CryptographycFunctions__Alternatives ) ) ;
    public final void ruleCryptographycFunctions() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:666:2: ( ( ( rule__CryptographycFunctions__Alternatives ) ) )
            // InternalSM2.g:667:2: ( ( rule__CryptographycFunctions__Alternatives ) )
            {
            // InternalSM2.g:667:2: ( ( rule__CryptographycFunctions__Alternatives ) )
            // InternalSM2.g:668:3: ( rule__CryptographycFunctions__Alternatives )
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getAlternatives()); 
            // InternalSM2.g:669:3: ( rule__CryptographycFunctions__Alternatives )
            // InternalSM2.g:669:4: rule__CryptographycFunctions__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCryptographycFunctionsAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCryptographycFunctions"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:678:1: entryRuleSyntaxExpression : ruleSyntaxExpression EOF ;
    public final void entryRuleSyntaxExpression() throws RecognitionException {
        try {
            // InternalSM2.g:679:1: ( ruleSyntaxExpression EOF )
            // InternalSM2.g:680:1: ruleSyntaxExpression EOF
            {
             before(grammarAccess.getSyntaxExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getSyntaxExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:687:1: ruleSyntaxExpression : ( ( rule__SyntaxExpression__Group__0 ) ) ;
    public final void ruleSyntaxExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:691:2: ( ( ( rule__SyntaxExpression__Group__0 ) ) )
            // InternalSM2.g:692:2: ( ( rule__SyntaxExpression__Group__0 ) )
            {
            // InternalSM2.g:692:2: ( ( rule__SyntaxExpression__Group__0 ) )
            // InternalSM2.g:693:3: ( rule__SyntaxExpression__Group__0 )
            {
             before(grammarAccess.getSyntaxExpressionAccess().getGroup()); 
            // InternalSM2.g:694:3: ( rule__SyntaxExpression__Group__0 )
            // InternalSM2.g:694:4: rule__SyntaxExpression__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSyntaxExpressionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:703:1: entryRuleComment : ruleComment EOF ;
    public final void entryRuleComment() throws RecognitionException {
        try {
            // InternalSM2.g:704:1: ( ruleComment EOF )
            // InternalSM2.g:705:1: ruleComment EOF
            {
             before(grammarAccess.getCommentRule()); 
            pushFollow(FOLLOW_1);
            ruleComment();

            state._fsp--;

             after(grammarAccess.getCommentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:712:1: ruleComment : ( ( rule__Comment__Alternatives ) ) ;
    public final void ruleComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:716:2: ( ( ( rule__Comment__Alternatives ) ) )
            // InternalSM2.g:717:2: ( ( rule__Comment__Alternatives ) )
            {
            // InternalSM2.g:717:2: ( ( rule__Comment__Alternatives ) )
            // InternalSM2.g:718:3: ( rule__Comment__Alternatives )
            {
             before(grammarAccess.getCommentAccess().getAlternatives()); 
            // InternalSM2.g:719:3: ( rule__Comment__Alternatives )
            // InternalSM2.g:719:4: rule__Comment__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Comment__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCommentAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:728:1: entryRuleShortComment : ruleShortComment EOF ;
    public final void entryRuleShortComment() throws RecognitionException {
        try {
            // InternalSM2.g:729:1: ( ruleShortComment EOF )
            // InternalSM2.g:730:1: ruleShortComment EOF
            {
             before(grammarAccess.getShortCommentRule()); 
            pushFollow(FOLLOW_1);
            ruleShortComment();

            state._fsp--;

             after(grammarAccess.getShortCommentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:737:1: ruleShortComment : ( ( rule__ShortComment__Group__0 ) ) ;
    public final void ruleShortComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:741:2: ( ( ( rule__ShortComment__Group__0 ) ) )
            // InternalSM2.g:742:2: ( ( rule__ShortComment__Group__0 ) )
            {
            // InternalSM2.g:742:2: ( ( rule__ShortComment__Group__0 ) )
            // InternalSM2.g:743:3: ( rule__ShortComment__Group__0 )
            {
             before(grammarAccess.getShortCommentAccess().getGroup()); 
            // InternalSM2.g:744:3: ( rule__ShortComment__Group__0 )
            // InternalSM2.g:744:4: rule__ShortComment__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getShortCommentAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:753:1: entryRuleLongComment : ruleLongComment EOF ;
    public final void entryRuleLongComment() throws RecognitionException {
        try {
            // InternalSM2.g:754:1: ( ruleLongComment EOF )
            // InternalSM2.g:755:1: ruleLongComment EOF
            {
             before(grammarAccess.getLongCommentRule()); 
            pushFollow(FOLLOW_1);
            ruleLongComment();

            state._fsp--;

             after(grammarAccess.getLongCommentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:762:1: ruleLongComment : ( ( rule__LongComment__Group__0 ) ) ;
    public final void ruleLongComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:766:2: ( ( ( rule__LongComment__Group__0 ) ) )
            // InternalSM2.g:767:2: ( ( rule__LongComment__Group__0 ) )
            {
            // InternalSM2.g:767:2: ( ( rule__LongComment__Group__0 ) )
            // InternalSM2.g:768:3: ( rule__LongComment__Group__0 )
            {
             before(grammarAccess.getLongCommentAccess().getGroup()); 
            // InternalSM2.g:769:3: ( rule__LongComment__Group__0 )
            // InternalSM2.g:769:4: rule__LongComment__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLongCommentAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:778:1: entryRuleExpression : ruleExpression EOF ;
    public final void entryRuleExpression() throws RecognitionException {
        try {
            // InternalSM2.g:779:1: ( ruleExpression EOF )
            // InternalSM2.g:780:1: ruleExpression EOF
            {
             before(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:787:1: ruleExpression : ( ( rule__Expression__Alternatives ) ) ;
    public final void ruleExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:791:2: ( ( ( rule__Expression__Alternatives ) ) )
            // InternalSM2.g:792:2: ( ( rule__Expression__Alternatives ) )
            {
            // InternalSM2.g:792:2: ( ( rule__Expression__Alternatives ) )
            // InternalSM2.g:793:3: ( rule__Expression__Alternatives )
            {
             before(grammarAccess.getExpressionAccess().getAlternatives()); 
            // InternalSM2.g:794:3: ( rule__Expression__Alternatives )
            // InternalSM2.g:794:4: rule__Expression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Expression__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getExpressionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleLogicalUnaryOperator"
    // InternalSM2.g:803:1: entryRuleLogicalUnaryOperator : ruleLogicalUnaryOperator EOF ;
    public final void entryRuleLogicalUnaryOperator() throws RecognitionException {
        try {
            // InternalSM2.g:804:1: ( ruleLogicalUnaryOperator EOF )
            // InternalSM2.g:805:1: ruleLogicalUnaryOperator EOF
            {
             before(grammarAccess.getLogicalUnaryOperatorRule()); 
            pushFollow(FOLLOW_1);
            ruleLogicalUnaryOperator();

            state._fsp--;

             after(grammarAccess.getLogicalUnaryOperatorRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLogicalUnaryOperator"


    // $ANTLR start "ruleLogicalUnaryOperator"
    // InternalSM2.g:812:1: ruleLogicalUnaryOperator : ( '!' ) ;
    public final void ruleLogicalUnaryOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:816:2: ( ( '!' ) )
            // InternalSM2.g:817:2: ( '!' )
            {
            // InternalSM2.g:817:2: ( '!' )
            // InternalSM2.g:818:3: '!'
            {
             before(grammarAccess.getLogicalUnaryOperatorAccess().getExclamationMarkKeyword()); 
            match(input,39,FOLLOW_2); 
             after(grammarAccess.getLogicalUnaryOperatorAccess().getExclamationMarkKeyword()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLogicalUnaryOperator"


    // $ANTLR start "entryRuleNegationExpression"
    // InternalSM2.g:828:1: entryRuleNegationExpression : ruleNegationExpression EOF ;
    public final void entryRuleNegationExpression() throws RecognitionException {
        try {
            // InternalSM2.g:829:1: ( ruleNegationExpression EOF )
            // InternalSM2.g:830:1: ruleNegationExpression EOF
            {
             before(grammarAccess.getNegationExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleNegationExpression();

            state._fsp--;

             after(grammarAccess.getNegationExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleNegationExpression"


    // $ANTLR start "ruleNegationExpression"
    // InternalSM2.g:837:1: ruleNegationExpression : ( ( rule__NegationExpression__Group__0 ) ) ;
    public final void ruleNegationExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:841:2: ( ( ( rule__NegationExpression__Group__0 ) ) )
            // InternalSM2.g:842:2: ( ( rule__NegationExpression__Group__0 ) )
            {
            // InternalSM2.g:842:2: ( ( rule__NegationExpression__Group__0 ) )
            // InternalSM2.g:843:3: ( rule__NegationExpression__Group__0 )
            {
             before(grammarAccess.getNegationExpressionAccess().getGroup()); 
            // InternalSM2.g:844:3: ( rule__NegationExpression__Group__0 )
            // InternalSM2.g:844:4: rule__NegationExpression__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__NegationExpression__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getNegationExpressionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNegationExpression"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:853:1: ruleVisibility : ( ( rule__Visibility__Alternatives ) ) ;
    public final void ruleVisibility() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:857:1: ( ( ( rule__Visibility__Alternatives ) ) )
            // InternalSM2.g:858:2: ( ( rule__Visibility__Alternatives ) )
            {
            // InternalSM2.g:858:2: ( ( rule__Visibility__Alternatives ) )
            // InternalSM2.g:859:3: ( rule__Visibility__Alternatives )
            {
             before(grammarAccess.getVisibilityAccess().getAlternatives()); 
            // InternalSM2.g:860:3: ( rule__Visibility__Alternatives )
            // InternalSM2.g:860:4: rule__Visibility__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Visibility__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getVisibilityAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:869:1: ruleCoin : ( ( rule__Coin__Alternatives ) ) ;
    public final void ruleCoin() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:873:1: ( ( ( rule__Coin__Alternatives ) ) )
            // InternalSM2.g:874:2: ( ( rule__Coin__Alternatives ) )
            {
            // InternalSM2.g:874:2: ( ( rule__Coin__Alternatives ) )
            // InternalSM2.g:875:3: ( rule__Coin__Alternatives )
            {
             before(grammarAccess.getCoinAccess().getAlternatives()); 
            // InternalSM2.g:876:3: ( rule__Coin__Alternatives )
            // InternalSM2.g:876:4: rule__Coin__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Coin__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCoinAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:885:1: ruleComparationOperator : ( ( rule__ComparationOperator__Alternatives ) ) ;
    public final void ruleComparationOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:889:1: ( ( ( rule__ComparationOperator__Alternatives ) ) )
            // InternalSM2.g:890:2: ( ( rule__ComparationOperator__Alternatives ) )
            {
            // InternalSM2.g:890:2: ( ( rule__ComparationOperator__Alternatives ) )
            // InternalSM2.g:891:3: ( rule__ComparationOperator__Alternatives )
            {
             before(grammarAccess.getComparationOperatorAccess().getAlternatives()); 
            // InternalSM2.g:892:3: ( rule__ComparationOperator__Alternatives )
            // InternalSM2.g:892:4: rule__ComparationOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ComparationOperator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getComparationOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:901:1: ruleLogicalPairOperator : ( ( rule__LogicalPairOperator__Alternatives ) ) ;
    public final void ruleLogicalPairOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:905:1: ( ( ( rule__LogicalPairOperator__Alternatives ) ) )
            // InternalSM2.g:906:2: ( ( rule__LogicalPairOperator__Alternatives ) )
            {
            // InternalSM2.g:906:2: ( ( rule__LogicalPairOperator__Alternatives ) )
            // InternalSM2.g:907:3: ( rule__LogicalPairOperator__Alternatives )
            {
             before(grammarAccess.getLogicalPairOperatorAccess().getAlternatives()); 
            // InternalSM2.g:908:3: ( rule__LogicalPairOperator__Alternatives )
            // InternalSM2.g:908:4: rule__LogicalPairOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__LogicalPairOperator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getLogicalPairOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:917:1: ruleArithmeticalOperator : ( ( rule__ArithmeticalOperator__Alternatives ) ) ;
    public final void ruleArithmeticalOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:921:1: ( ( ( rule__ArithmeticalOperator__Alternatives ) ) )
            // InternalSM2.g:922:2: ( ( rule__ArithmeticalOperator__Alternatives ) )
            {
            // InternalSM2.g:922:2: ( ( rule__ArithmeticalOperator__Alternatives ) )
            // InternalSM2.g:923:3: ( rule__ArithmeticalOperator__Alternatives )
            {
             before(grammarAccess.getArithmeticalOperatorAccess().getAlternatives()); 
            // InternalSM2.g:924:3: ( rule__ArithmeticalOperator__Alternatives )
            // InternalSM2.g:924:4: rule__ArithmeticalOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ArithmeticalOperator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getArithmeticalOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleArithmeticalOperator"


    // $ANTLR start "rule__MSGOperation__Alternatives_1"
    // InternalSM2.g:932:1: rule__MSGOperation__Alternatives_1 : ( ( ( rule__MSGOperation__Alternatives_1_0 ) ) | ( ( rule__MSGOperation__Alternatives_1_1 ) ) | ( ( rule__MSGOperation__Alternatives_1_2 ) ) | ( ( rule__MSGOperation__Alternatives_1_3 ) ) | ( ( rule__MSGOperation__Alternatives_1_4 ) ) );
    public final void rule__MSGOperation__Alternatives_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:936:1: ( ( ( rule__MSGOperation__Alternatives_1_0 ) ) | ( ( rule__MSGOperation__Alternatives_1_1 ) ) | ( ( rule__MSGOperation__Alternatives_1_2 ) ) | ( ( rule__MSGOperation__Alternatives_1_3 ) ) | ( ( rule__MSGOperation__Alternatives_1_4 ) ) )
            int alt1=5;
            switch ( input.LA(1) ) {
            case 40:
                {
                alt1=1;
                }
                break;
            case 41:
                {
                alt1=2;
                }
                break;
            case 42:
                {
                alt1=3;
                }
                break;
            case 43:
                {
                alt1=4;
                }
                break;
            case 44:
                {
                alt1=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // InternalSM2.g:937:2: ( ( rule__MSGOperation__Alternatives_1_0 ) )
                    {
                    // InternalSM2.g:937:2: ( ( rule__MSGOperation__Alternatives_1_0 ) )
                    // InternalSM2.g:938:3: ( rule__MSGOperation__Alternatives_1_0 )
                    {
                     before(grammarAccess.getMSGOperationAccess().getAlternatives_1_0()); 
                    // InternalSM2.g:939:3: ( rule__MSGOperation__Alternatives_1_0 )
                    // InternalSM2.g:939:4: rule__MSGOperation__Alternatives_1_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MSGOperation__Alternatives_1_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getMSGOperationAccess().getAlternatives_1_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:943:2: ( ( rule__MSGOperation__Alternatives_1_1 ) )
                    {
                    // InternalSM2.g:943:2: ( ( rule__MSGOperation__Alternatives_1_1 ) )
                    // InternalSM2.g:944:3: ( rule__MSGOperation__Alternatives_1_1 )
                    {
                     before(grammarAccess.getMSGOperationAccess().getAlternatives_1_1()); 
                    // InternalSM2.g:945:3: ( rule__MSGOperation__Alternatives_1_1 )
                    // InternalSM2.g:945:4: rule__MSGOperation__Alternatives_1_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__MSGOperation__Alternatives_1_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getMSGOperationAccess().getAlternatives_1_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:949:2: ( ( rule__MSGOperation__Alternatives_1_2 ) )
                    {
                    // InternalSM2.g:949:2: ( ( rule__MSGOperation__Alternatives_1_2 ) )
                    // InternalSM2.g:950:3: ( rule__MSGOperation__Alternatives_1_2 )
                    {
                     before(grammarAccess.getMSGOperationAccess().getAlternatives_1_2()); 
                    // InternalSM2.g:951:3: ( rule__MSGOperation__Alternatives_1_2 )
                    // InternalSM2.g:951:4: rule__MSGOperation__Alternatives_1_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__MSGOperation__Alternatives_1_2();

                    state._fsp--;


                    }

                     after(grammarAccess.getMSGOperationAccess().getAlternatives_1_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:955:2: ( ( rule__MSGOperation__Alternatives_1_3 ) )
                    {
                    // InternalSM2.g:955:2: ( ( rule__MSGOperation__Alternatives_1_3 ) )
                    // InternalSM2.g:956:3: ( rule__MSGOperation__Alternatives_1_3 )
                    {
                     before(grammarAccess.getMSGOperationAccess().getAlternatives_1_3()); 
                    // InternalSM2.g:957:3: ( rule__MSGOperation__Alternatives_1_3 )
                    // InternalSM2.g:957:4: rule__MSGOperation__Alternatives_1_3
                    {
                    pushFollow(FOLLOW_2);
                    rule__MSGOperation__Alternatives_1_3();

                    state._fsp--;


                    }

                     after(grammarAccess.getMSGOperationAccess().getAlternatives_1_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:961:2: ( ( rule__MSGOperation__Alternatives_1_4 ) )
                    {
                    // InternalSM2.g:961:2: ( ( rule__MSGOperation__Alternatives_1_4 ) )
                    // InternalSM2.g:962:3: ( rule__MSGOperation__Alternatives_1_4 )
                    {
                     before(grammarAccess.getMSGOperationAccess().getAlternatives_1_4()); 
                    // InternalSM2.g:963:3: ( rule__MSGOperation__Alternatives_1_4 )
                    // InternalSM2.g:963:4: rule__MSGOperation__Alternatives_1_4
                    {
                    pushFollow(FOLLOW_2);
                    rule__MSGOperation__Alternatives_1_4();

                    state._fsp--;


                    }

                     after(grammarAccess.getMSGOperationAccess().getAlternatives_1_4()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Alternatives_1"


    // $ANTLR start "rule__MSGOperation__Alternatives_1_0"
    // InternalSM2.g:971:1: rule__MSGOperation__Alternatives_1_0 : ( ( ( rule__MSGOperation__Group_1_0_0__0 ) ) | ( 'data' ) );
    public final void rule__MSGOperation__Alternatives_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:975:1: ( ( ( rule__MSGOperation__Group_1_0_0__0 ) ) | ( 'data' ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==40) ) {
                int LA2_1 = input.LA(2);

                if ( (LA2_1==EOF||LA2_1==RULE_SEMICOLON) ) {
                    alt2=2;
                }
                else if ( (LA2_1==RULE_OPENPARENTHESIS) ) {
                    alt2=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 2, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalSM2.g:976:2: ( ( rule__MSGOperation__Group_1_0_0__0 ) )
                    {
                    // InternalSM2.g:976:2: ( ( rule__MSGOperation__Group_1_0_0__0 ) )
                    // InternalSM2.g:977:3: ( rule__MSGOperation__Group_1_0_0__0 )
                    {
                     before(grammarAccess.getMSGOperationAccess().getGroup_1_0_0()); 
                    // InternalSM2.g:978:3: ( rule__MSGOperation__Group_1_0_0__0 )
                    // InternalSM2.g:978:4: rule__MSGOperation__Group_1_0_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MSGOperation__Group_1_0_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getMSGOperationAccess().getGroup_1_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:982:2: ( 'data' )
                    {
                    // InternalSM2.g:982:2: ( 'data' )
                    // InternalSM2.g:983:3: 'data'
                    {
                     before(grammarAccess.getMSGOperationAccess().getDataKeyword_1_0_1()); 
                    match(input,40,FOLLOW_2); 
                     after(grammarAccess.getMSGOperationAccess().getDataKeyword_1_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Alternatives_1_0"


    // $ANTLR start "rule__MSGOperation__Alternatives_1_1"
    // InternalSM2.g:992:1: rule__MSGOperation__Alternatives_1_1 : ( ( ( rule__MSGOperation__Group_1_1_0__0 ) ) | ( 'value' ) );
    public final void rule__MSGOperation__Alternatives_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:996:1: ( ( ( rule__MSGOperation__Group_1_1_0__0 ) ) | ( 'value' ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==41) ) {
                int LA3_1 = input.LA(2);

                if ( (LA3_1==RULE_OPENPARENTHESIS) ) {
                    alt3=1;
                }
                else if ( (LA3_1==EOF||LA3_1==RULE_SEMICOLON) ) {
                    alt3=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 3, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalSM2.g:997:2: ( ( rule__MSGOperation__Group_1_1_0__0 ) )
                    {
                    // InternalSM2.g:997:2: ( ( rule__MSGOperation__Group_1_1_0__0 ) )
                    // InternalSM2.g:998:3: ( rule__MSGOperation__Group_1_1_0__0 )
                    {
                     before(grammarAccess.getMSGOperationAccess().getGroup_1_1_0()); 
                    // InternalSM2.g:999:3: ( rule__MSGOperation__Group_1_1_0__0 )
                    // InternalSM2.g:999:4: rule__MSGOperation__Group_1_1_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MSGOperation__Group_1_1_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getMSGOperationAccess().getGroup_1_1_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1003:2: ( 'value' )
                    {
                    // InternalSM2.g:1003:2: ( 'value' )
                    // InternalSM2.g:1004:3: 'value'
                    {
                     before(grammarAccess.getMSGOperationAccess().getValueKeyword_1_1_1()); 
                    match(input,41,FOLLOW_2); 
                     after(grammarAccess.getMSGOperationAccess().getValueKeyword_1_1_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Alternatives_1_1"


    // $ANTLR start "rule__MSGOperation__Alternatives_1_2"
    // InternalSM2.g:1013:1: rule__MSGOperation__Alternatives_1_2 : ( ( ( rule__MSGOperation__Group_1_2_0__0 ) ) | ( 'gas' ) );
    public final void rule__MSGOperation__Alternatives_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1017:1: ( ( ( rule__MSGOperation__Group_1_2_0__0 ) ) | ( 'gas' ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==42) ) {
                int LA4_1 = input.LA(2);

                if ( (LA4_1==RULE_OPENPARENTHESIS) ) {
                    alt4=1;
                }
                else if ( (LA4_1==EOF||LA4_1==RULE_SEMICOLON) ) {
                    alt4=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalSM2.g:1018:2: ( ( rule__MSGOperation__Group_1_2_0__0 ) )
                    {
                    // InternalSM2.g:1018:2: ( ( rule__MSGOperation__Group_1_2_0__0 ) )
                    // InternalSM2.g:1019:3: ( rule__MSGOperation__Group_1_2_0__0 )
                    {
                     before(grammarAccess.getMSGOperationAccess().getGroup_1_2_0()); 
                    // InternalSM2.g:1020:3: ( rule__MSGOperation__Group_1_2_0__0 )
                    // InternalSM2.g:1020:4: rule__MSGOperation__Group_1_2_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MSGOperation__Group_1_2_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getMSGOperationAccess().getGroup_1_2_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1024:2: ( 'gas' )
                    {
                    // InternalSM2.g:1024:2: ( 'gas' )
                    // InternalSM2.g:1025:3: 'gas'
                    {
                     before(grammarAccess.getMSGOperationAccess().getGasKeyword_1_2_1()); 
                    match(input,42,FOLLOW_2); 
                     after(grammarAccess.getMSGOperationAccess().getGasKeyword_1_2_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Alternatives_1_2"


    // $ANTLR start "rule__MSGOperation__Alternatives_1_3"
    // InternalSM2.g:1034:1: rule__MSGOperation__Alternatives_1_3 : ( ( ( rule__MSGOperation__Group_1_3_0__0 ) ) | ( 'sender' ) );
    public final void rule__MSGOperation__Alternatives_1_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1038:1: ( ( ( rule__MSGOperation__Group_1_3_0__0 ) ) | ( 'sender' ) )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==43) ) {
                int LA5_1 = input.LA(2);

                if ( (LA5_1==RULE_OPENPARENTHESIS) ) {
                    alt5=1;
                }
                else if ( (LA5_1==EOF||LA5_1==RULE_SEMICOLON) ) {
                    alt5=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 5, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalSM2.g:1039:2: ( ( rule__MSGOperation__Group_1_3_0__0 ) )
                    {
                    // InternalSM2.g:1039:2: ( ( rule__MSGOperation__Group_1_3_0__0 ) )
                    // InternalSM2.g:1040:3: ( rule__MSGOperation__Group_1_3_0__0 )
                    {
                     before(grammarAccess.getMSGOperationAccess().getGroup_1_3_0()); 
                    // InternalSM2.g:1041:3: ( rule__MSGOperation__Group_1_3_0__0 )
                    // InternalSM2.g:1041:4: rule__MSGOperation__Group_1_3_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MSGOperation__Group_1_3_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getMSGOperationAccess().getGroup_1_3_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1045:2: ( 'sender' )
                    {
                    // InternalSM2.g:1045:2: ( 'sender' )
                    // InternalSM2.g:1046:3: 'sender'
                    {
                     before(grammarAccess.getMSGOperationAccess().getSenderKeyword_1_3_1()); 
                    match(input,43,FOLLOW_2); 
                     after(grammarAccess.getMSGOperationAccess().getSenderKeyword_1_3_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Alternatives_1_3"


    // $ANTLR start "rule__MSGOperation__Alternatives_1_4"
    // InternalSM2.g:1055:1: rule__MSGOperation__Alternatives_1_4 : ( ( ( rule__MSGOperation__Group_1_4_0__0 ) ) | ( 'sig' ) );
    public final void rule__MSGOperation__Alternatives_1_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1059:1: ( ( ( rule__MSGOperation__Group_1_4_0__0 ) ) | ( 'sig' ) )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==44) ) {
                int LA6_1 = input.LA(2);

                if ( (LA6_1==EOF||LA6_1==RULE_SEMICOLON) ) {
                    alt6=2;
                }
                else if ( (LA6_1==RULE_OPENPARENTHESIS) ) {
                    alt6=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalSM2.g:1060:2: ( ( rule__MSGOperation__Group_1_4_0__0 ) )
                    {
                    // InternalSM2.g:1060:2: ( ( rule__MSGOperation__Group_1_4_0__0 ) )
                    // InternalSM2.g:1061:3: ( rule__MSGOperation__Group_1_4_0__0 )
                    {
                     before(grammarAccess.getMSGOperationAccess().getGroup_1_4_0()); 
                    // InternalSM2.g:1062:3: ( rule__MSGOperation__Group_1_4_0__0 )
                    // InternalSM2.g:1062:4: rule__MSGOperation__Group_1_4_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MSGOperation__Group_1_4_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getMSGOperationAccess().getGroup_1_4_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1066:2: ( 'sig' )
                    {
                    // InternalSM2.g:1066:2: ( 'sig' )
                    // InternalSM2.g:1067:3: 'sig'
                    {
                     before(grammarAccess.getMSGOperationAccess().getSigKeyword_1_4_1()); 
                    match(input,44,FOLLOW_2); 
                     after(grammarAccess.getMSGOperationAccess().getSigKeyword_1_4_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Alternatives_1_4"


    // $ANTLR start "rule__TxOperation__Alternatives_1"
    // InternalSM2.g:1076:1: rule__TxOperation__Alternatives_1 : ( ( ( rule__TxOperation__Alternatives_1_0 ) ) | ( ( rule__TxOperation__Group_1_1__0 ) ) | ( 'origin' ) );
    public final void rule__TxOperation__Alternatives_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1080:1: ( ( ( rule__TxOperation__Alternatives_1_0 ) ) | ( ( rule__TxOperation__Group_1_1__0 ) ) | ( 'origin' ) )
            int alt7=3;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==46) ) {
                alt7=1;
            }
            else if ( (LA7_0==45) ) {
                int LA7_2 = input.LA(2);

                if ( (LA7_2==RULE_OPENPARENTHESIS) ) {
                    alt7=2;
                }
                else if ( (LA7_2==EOF||LA7_2==RULE_SEMICOLON) ) {
                    alt7=3;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 7, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalSM2.g:1081:2: ( ( rule__TxOperation__Alternatives_1_0 ) )
                    {
                    // InternalSM2.g:1081:2: ( ( rule__TxOperation__Alternatives_1_0 ) )
                    // InternalSM2.g:1082:3: ( rule__TxOperation__Alternatives_1_0 )
                    {
                     before(grammarAccess.getTxOperationAccess().getAlternatives_1_0()); 
                    // InternalSM2.g:1083:3: ( rule__TxOperation__Alternatives_1_0 )
                    // InternalSM2.g:1083:4: rule__TxOperation__Alternatives_1_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__TxOperation__Alternatives_1_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getTxOperationAccess().getAlternatives_1_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1087:2: ( ( rule__TxOperation__Group_1_1__0 ) )
                    {
                    // InternalSM2.g:1087:2: ( ( rule__TxOperation__Group_1_1__0 ) )
                    // InternalSM2.g:1088:3: ( rule__TxOperation__Group_1_1__0 )
                    {
                     before(grammarAccess.getTxOperationAccess().getGroup_1_1()); 
                    // InternalSM2.g:1089:3: ( rule__TxOperation__Group_1_1__0 )
                    // InternalSM2.g:1089:4: rule__TxOperation__Group_1_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__TxOperation__Group_1_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getTxOperationAccess().getGroup_1_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1093:2: ( 'origin' )
                    {
                    // InternalSM2.g:1093:2: ( 'origin' )
                    // InternalSM2.g:1094:3: 'origin'
                    {
                     before(grammarAccess.getTxOperationAccess().getOriginKeyword_1_2()); 
                    match(input,45,FOLLOW_2); 
                     after(grammarAccess.getTxOperationAccess().getOriginKeyword_1_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Alternatives_1"


    // $ANTLR start "rule__TxOperation__Alternatives_1_0"
    // InternalSM2.g:1103:1: rule__TxOperation__Alternatives_1_0 : ( ( ( rule__TxOperation__Group_1_0_0__0 ) ) | ( 'gasprice' ) );
    public final void rule__TxOperation__Alternatives_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1107:1: ( ( ( rule__TxOperation__Group_1_0_0__0 ) ) | ( 'gasprice' ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==46) ) {
                int LA8_1 = input.LA(2);

                if ( (LA8_1==RULE_OPENPARENTHESIS) ) {
                    alt8=1;
                }
                else if ( (LA8_1==EOF||LA8_1==RULE_SEMICOLON) ) {
                    alt8=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 8, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalSM2.g:1108:2: ( ( rule__TxOperation__Group_1_0_0__0 ) )
                    {
                    // InternalSM2.g:1108:2: ( ( rule__TxOperation__Group_1_0_0__0 ) )
                    // InternalSM2.g:1109:3: ( rule__TxOperation__Group_1_0_0__0 )
                    {
                     before(grammarAccess.getTxOperationAccess().getGroup_1_0_0()); 
                    // InternalSM2.g:1110:3: ( rule__TxOperation__Group_1_0_0__0 )
                    // InternalSM2.g:1110:4: rule__TxOperation__Group_1_0_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__TxOperation__Group_1_0_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getTxOperationAccess().getGroup_1_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1114:2: ( 'gasprice' )
                    {
                    // InternalSM2.g:1114:2: ( 'gasprice' )
                    // InternalSM2.g:1115:3: 'gasprice'
                    {
                     before(grammarAccess.getTxOperationAccess().getGaspriceKeyword_1_0_1()); 
                    match(input,46,FOLLOW_2); 
                     after(grammarAccess.getTxOperationAccess().getGaspriceKeyword_1_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Alternatives_1_0"


    // $ANTLR start "rule__Version__SymbolAlternatives_2_0"
    // InternalSM2.g:1124:1: rule__Version__SymbolAlternatives_2_0 : ( ( '^' ) | ( '>' ) | ( '>=' ) );
    public final void rule__Version__SymbolAlternatives_2_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1128:1: ( ( '^' ) | ( '>' ) | ( '>=' ) )
            int alt9=3;
            switch ( input.LA(1) ) {
            case 47:
                {
                alt9=1;
                }
                break;
            case 48:
                {
                alt9=2;
                }
                break;
            case 49:
                {
                alt9=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalSM2.g:1129:2: ( '^' )
                    {
                    // InternalSM2.g:1129:2: ( '^' )
                    // InternalSM2.g:1130:3: '^'
                    {
                     before(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_2_0_0()); 
                    match(input,47,FOLLOW_2); 
                     after(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_2_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1135:2: ( '>' )
                    {
                    // InternalSM2.g:1135:2: ( '>' )
                    // InternalSM2.g:1136:3: '>'
                    {
                     before(grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_2_0_1()); 
                    match(input,48,FOLLOW_2); 
                     after(grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_2_0_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1141:2: ( '>=' )
                    {
                    // InternalSM2.g:1141:2: ( '>=' )
                    // InternalSM2.g:1142:3: '>='
                    {
                     before(grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_2_0_2()); 
                    match(input,49,FOLLOW_2); 
                     after(grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_2_0_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAlternatives_2_0"


    // $ANTLR start "rule__Constructor__TypeAlternatives_3_0"
    // InternalSM2.g:1151:1: rule__Constructor__TypeAlternatives_3_0 : ( ( 'public' ) | ( 'internal' ) );
    public final void rule__Constructor__TypeAlternatives_3_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1155:1: ( ( 'public' ) | ( 'internal' ) )
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==50) ) {
                alt10=1;
            }
            else if ( (LA10_0==51) ) {
                alt10=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }
            switch (alt10) {
                case 1 :
                    // InternalSM2.g:1156:2: ( 'public' )
                    {
                    // InternalSM2.g:1156:2: ( 'public' )
                    // InternalSM2.g:1157:3: 'public'
                    {
                     before(grammarAccess.getConstructorAccess().getTypePublicKeyword_3_0_0()); 
                    match(input,50,FOLLOW_2); 
                     after(grammarAccess.getConstructorAccess().getTypePublicKeyword_3_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1162:2: ( 'internal' )
                    {
                    // InternalSM2.g:1162:2: ( 'internal' )
                    // InternalSM2.g:1163:3: 'internal'
                    {
                     before(grammarAccess.getConstructorAccess().getTypeInternalKeyword_3_0_1()); 
                    match(input,51,FOLLOW_2); 
                     after(grammarAccess.getConstructorAccess().getTypeInternalKeyword_3_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__TypeAlternatives_3_0"


    // $ANTLR start "rule__DataType__Alternatives"
    // InternalSM2.g:1172:1: rule__DataType__Alternatives : ( ( ruleCompositeType ) | ( ruleEnum ) | ( RULE_ID ) );
    public final void rule__DataType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1176:1: ( ( ruleCompositeType ) | ( ruleEnum ) | ( RULE_ID ) )
            int alt11=3;
            switch ( input.LA(1) ) {
            case 80:
            case 82:
                {
                alt11=1;
                }
                break;
            case 83:
                {
                alt11=2;
                }
                break;
            case RULE_ID:
                {
                alt11=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }

            switch (alt11) {
                case 1 :
                    // InternalSM2.g:1177:2: ( ruleCompositeType )
                    {
                    // InternalSM2.g:1177:2: ( ruleCompositeType )
                    // InternalSM2.g:1178:3: ruleCompositeType
                    {
                     before(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleCompositeType();

                    state._fsp--;

                     after(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1183:2: ( ruleEnum )
                    {
                    // InternalSM2.g:1183:2: ( ruleEnum )
                    // InternalSM2.g:1184:3: ruleEnum
                    {
                     before(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleEnum();

                    state._fsp--;

                     after(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1189:2: ( RULE_ID )
                    {
                    // InternalSM2.g:1189:2: ( RULE_ID )
                    // InternalSM2.g:1190:3: RULE_ID
                    {
                     before(grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataType__Alternatives"


    // $ANTLR start "rule__CompositeType__Alternatives"
    // InternalSM2.g:1199:1: rule__CompositeType__Alternatives : ( ( ruleMapping ) | ( ruleStruct ) );
    public final void rule__CompositeType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1203:1: ( ( ruleMapping ) | ( ruleStruct ) )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==80) ) {
                alt12=1;
            }
            else if ( (LA12_0==82) ) {
                alt12=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // InternalSM2.g:1204:2: ( ruleMapping )
                    {
                    // InternalSM2.g:1204:2: ( ruleMapping )
                    // InternalSM2.g:1205:3: ruleMapping
                    {
                     before(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleMapping();

                    state._fsp--;

                     after(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1210:2: ( ruleStruct )
                    {
                    // InternalSM2.g:1210:2: ( ruleStruct )
                    // InternalSM2.g:1211:3: ruleStruct
                    {
                     before(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleStruct();

                    state._fsp--;

                     after(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CompositeType__Alternatives"


    // $ANTLR start "rule__SingularType__Alternatives"
    // InternalSM2.g:1220:1: rule__SingularType__Alternatives : ( ( ( rule__SingularType__INTAssignment_0 ) ) | ( ( rule__SingularType__UINTAssignment_1 ) ) | ( ( rule__SingularType__UINT8Assignment_2 ) ) | ( ( rule__SingularType__STRINGAssignment_3 ) ) | ( ( rule__SingularType__ADDRESSAssignment_4 ) ) | ( ( rule__SingularType__ADDRESSPAYABLEAssignment_5 ) ) | ( ( rule__SingularType__DOUBLEAssignment_6 ) ) | ( ( rule__SingularType__BOOLEANAssignment_7 ) ) );
    public final void rule__SingularType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1224:1: ( ( ( rule__SingularType__INTAssignment_0 ) ) | ( ( rule__SingularType__UINTAssignment_1 ) ) | ( ( rule__SingularType__UINT8Assignment_2 ) ) | ( ( rule__SingularType__STRINGAssignment_3 ) ) | ( ( rule__SingularType__ADDRESSAssignment_4 ) ) | ( ( rule__SingularType__ADDRESSPAYABLEAssignment_5 ) ) | ( ( rule__SingularType__DOUBLEAssignment_6 ) ) | ( ( rule__SingularType__BOOLEANAssignment_7 ) ) )
            int alt13=8;
            switch ( input.LA(1) ) {
            case 94:
                {
                alt13=1;
                }
                break;
            case 95:
                {
                alt13=2;
                }
                break;
            case 96:
                {
                alt13=3;
                }
                break;
            case 97:
                {
                alt13=4;
                }
                break;
            case 98:
                {
                alt13=5;
                }
                break;
            case 99:
                {
                alt13=6;
                }
                break;
            case 100:
                {
                alt13=7;
                }
                break;
            case 101:
                {
                alt13=8;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }

            switch (alt13) {
                case 1 :
                    // InternalSM2.g:1225:2: ( ( rule__SingularType__INTAssignment_0 ) )
                    {
                    // InternalSM2.g:1225:2: ( ( rule__SingularType__INTAssignment_0 ) )
                    // InternalSM2.g:1226:3: ( rule__SingularType__INTAssignment_0 )
                    {
                     before(grammarAccess.getSingularTypeAccess().getINTAssignment_0()); 
                    // InternalSM2.g:1227:3: ( rule__SingularType__INTAssignment_0 )
                    // InternalSM2.g:1227:4: rule__SingularType__INTAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SingularType__INTAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getSingularTypeAccess().getINTAssignment_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1231:2: ( ( rule__SingularType__UINTAssignment_1 ) )
                    {
                    // InternalSM2.g:1231:2: ( ( rule__SingularType__UINTAssignment_1 ) )
                    // InternalSM2.g:1232:3: ( rule__SingularType__UINTAssignment_1 )
                    {
                     before(grammarAccess.getSingularTypeAccess().getUINTAssignment_1()); 
                    // InternalSM2.g:1233:3: ( rule__SingularType__UINTAssignment_1 )
                    // InternalSM2.g:1233:4: rule__SingularType__UINTAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__SingularType__UINTAssignment_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getSingularTypeAccess().getUINTAssignment_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1237:2: ( ( rule__SingularType__UINT8Assignment_2 ) )
                    {
                    // InternalSM2.g:1237:2: ( ( rule__SingularType__UINT8Assignment_2 ) )
                    // InternalSM2.g:1238:3: ( rule__SingularType__UINT8Assignment_2 )
                    {
                     before(grammarAccess.getSingularTypeAccess().getUINT8Assignment_2()); 
                    // InternalSM2.g:1239:3: ( rule__SingularType__UINT8Assignment_2 )
                    // InternalSM2.g:1239:4: rule__SingularType__UINT8Assignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__SingularType__UINT8Assignment_2();

                    state._fsp--;


                    }

                     after(grammarAccess.getSingularTypeAccess().getUINT8Assignment_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1243:2: ( ( rule__SingularType__STRINGAssignment_3 ) )
                    {
                    // InternalSM2.g:1243:2: ( ( rule__SingularType__STRINGAssignment_3 ) )
                    // InternalSM2.g:1244:3: ( rule__SingularType__STRINGAssignment_3 )
                    {
                     before(grammarAccess.getSingularTypeAccess().getSTRINGAssignment_3()); 
                    // InternalSM2.g:1245:3: ( rule__SingularType__STRINGAssignment_3 )
                    // InternalSM2.g:1245:4: rule__SingularType__STRINGAssignment_3
                    {
                    pushFollow(FOLLOW_2);
                    rule__SingularType__STRINGAssignment_3();

                    state._fsp--;


                    }

                     after(grammarAccess.getSingularTypeAccess().getSTRINGAssignment_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1249:2: ( ( rule__SingularType__ADDRESSAssignment_4 ) )
                    {
                    // InternalSM2.g:1249:2: ( ( rule__SingularType__ADDRESSAssignment_4 ) )
                    // InternalSM2.g:1250:3: ( rule__SingularType__ADDRESSAssignment_4 )
                    {
                     before(grammarAccess.getSingularTypeAccess().getADDRESSAssignment_4()); 
                    // InternalSM2.g:1251:3: ( rule__SingularType__ADDRESSAssignment_4 )
                    // InternalSM2.g:1251:4: rule__SingularType__ADDRESSAssignment_4
                    {
                    pushFollow(FOLLOW_2);
                    rule__SingularType__ADDRESSAssignment_4();

                    state._fsp--;


                    }

                     after(grammarAccess.getSingularTypeAccess().getADDRESSAssignment_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1255:2: ( ( rule__SingularType__ADDRESSPAYABLEAssignment_5 ) )
                    {
                    // InternalSM2.g:1255:2: ( ( rule__SingularType__ADDRESSPAYABLEAssignment_5 ) )
                    // InternalSM2.g:1256:3: ( rule__SingularType__ADDRESSPAYABLEAssignment_5 )
                    {
                     before(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEAssignment_5()); 
                    // InternalSM2.g:1257:3: ( rule__SingularType__ADDRESSPAYABLEAssignment_5 )
                    // InternalSM2.g:1257:4: rule__SingularType__ADDRESSPAYABLEAssignment_5
                    {
                    pushFollow(FOLLOW_2);
                    rule__SingularType__ADDRESSPAYABLEAssignment_5();

                    state._fsp--;


                    }

                     after(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEAssignment_5()); 

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:1261:2: ( ( rule__SingularType__DOUBLEAssignment_6 ) )
                    {
                    // InternalSM2.g:1261:2: ( ( rule__SingularType__DOUBLEAssignment_6 ) )
                    // InternalSM2.g:1262:3: ( rule__SingularType__DOUBLEAssignment_6 )
                    {
                     before(grammarAccess.getSingularTypeAccess().getDOUBLEAssignment_6()); 
                    // InternalSM2.g:1263:3: ( rule__SingularType__DOUBLEAssignment_6 )
                    // InternalSM2.g:1263:4: rule__SingularType__DOUBLEAssignment_6
                    {
                    pushFollow(FOLLOW_2);
                    rule__SingularType__DOUBLEAssignment_6();

                    state._fsp--;


                    }

                     after(grammarAccess.getSingularTypeAccess().getDOUBLEAssignment_6()); 

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:1267:2: ( ( rule__SingularType__BOOLEANAssignment_7 ) )
                    {
                    // InternalSM2.g:1267:2: ( ( rule__SingularType__BOOLEANAssignment_7 ) )
                    // InternalSM2.g:1268:3: ( rule__SingularType__BOOLEANAssignment_7 )
                    {
                     before(grammarAccess.getSingularTypeAccess().getBOOLEANAssignment_7()); 
                    // InternalSM2.g:1269:3: ( rule__SingularType__BOOLEANAssignment_7 )
                    // InternalSM2.g:1269:4: rule__SingularType__BOOLEANAssignment_7
                    {
                    pushFollow(FOLLOW_2);
                    rule__SingularType__BOOLEANAssignment_7();

                    state._fsp--;


                    }

                     after(grammarAccess.getSingularTypeAccess().getBOOLEANAssignment_7()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingularType__Alternatives"


    // $ANTLR start "rule__Property__Alternatives_4"
    // InternalSM2.g:1277:1: rule__Property__Alternatives_4 : ( ( ( rule__Property__InicializationAssignment_4_0 ) ) | ( RULE_INT ) );
    public final void rule__Property__Alternatives_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1281:1: ( ( ( rule__Property__InicializationAssignment_4_0 ) ) | ( RULE_INT ) )
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==RULE_STRING) ) {
                alt14=1;
            }
            else if ( (LA14_0==RULE_INT) ) {
                alt14=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }
            switch (alt14) {
                case 1 :
                    // InternalSM2.g:1282:2: ( ( rule__Property__InicializationAssignment_4_0 ) )
                    {
                    // InternalSM2.g:1282:2: ( ( rule__Property__InicializationAssignment_4_0 ) )
                    // InternalSM2.g:1283:3: ( rule__Property__InicializationAssignment_4_0 )
                    {
                     before(grammarAccess.getPropertyAccess().getInicializationAssignment_4_0()); 
                    // InternalSM2.g:1284:3: ( rule__Property__InicializationAssignment_4_0 )
                    // InternalSM2.g:1284:4: rule__Property__InicializationAssignment_4_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__InicializationAssignment_4_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPropertyAccess().getInicializationAssignment_4_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1288:2: ( RULE_INT )
                    {
                    // InternalSM2.g:1288:2: ( RULE_INT )
                    // InternalSM2.g:1289:3: RULE_INT
                    {
                     before(grammarAccess.getPropertyAccess().getINTTerminalRuleCall_4_1()); 
                    match(input,RULE_INT,FOLLOW_2); 
                     after(grammarAccess.getPropertyAccess().getINTTerminalRuleCall_4_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Alternatives_4"


    // $ANTLR start "rule__RestrictionClause__Alternatives"
    // InternalSM2.g:1298:1: rule__RestrictionClause__Alternatives : ( ( ruleRestriction ) | ( ruleRestrictionGas ) );
    public final void rule__RestrictionClause__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1302:1: ( ( ruleRestriction ) | ( ruleRestrictionGas ) )
            int alt15=2;
            alt15 = dfa15.predict(input);
            switch (alt15) {
                case 1 :
                    // InternalSM2.g:1303:2: ( ruleRestriction )
                    {
                    // InternalSM2.g:1303:2: ( ruleRestriction )
                    // InternalSM2.g:1304:3: ruleRestriction
                    {
                     before(grammarAccess.getRestrictionClauseAccess().getRestrictionParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleRestriction();

                    state._fsp--;

                     after(grammarAccess.getRestrictionClauseAccess().getRestrictionParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1309:2: ( ruleRestrictionGas )
                    {
                    // InternalSM2.g:1309:2: ( ruleRestrictionGas )
                    // InternalSM2.g:1310:3: ruleRestrictionGas
                    {
                     before(grammarAccess.getRestrictionClauseAccess().getRestrictionGasParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleRestrictionGas();

                    state._fsp--;

                     after(grammarAccess.getRestrictionClauseAccess().getRestrictionGasParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionClause__Alternatives"


    // $ANTLR start "rule__CryptographycFunctions__Alternatives"
    // InternalSM2.g:1319:1: rule__CryptographycFunctions__Alternatives : ( ( ( rule__CryptographycFunctions__Group_0__0 ) ) | ( ( rule__CryptographycFunctions__Group_1__0 ) ) | ( ( rule__CryptographycFunctions__Group_2__0 ) ) );
    public final void rule__CryptographycFunctions__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1323:1: ( ( ( rule__CryptographycFunctions__Group_0__0 ) ) | ( ( rule__CryptographycFunctions__Group_1__0 ) ) | ( ( rule__CryptographycFunctions__Group_2__0 ) ) )
            int alt16=3;
            switch ( input.LA(1) ) {
            case 88:
                {
                alt16=1;
                }
                break;
            case 89:
                {
                alt16=2;
                }
                break;
            case 90:
                {
                alt16=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }

            switch (alt16) {
                case 1 :
                    // InternalSM2.g:1324:2: ( ( rule__CryptographycFunctions__Group_0__0 ) )
                    {
                    // InternalSM2.g:1324:2: ( ( rule__CryptographycFunctions__Group_0__0 ) )
                    // InternalSM2.g:1325:3: ( rule__CryptographycFunctions__Group_0__0 )
                    {
                     before(grammarAccess.getCryptographycFunctionsAccess().getGroup_0()); 
                    // InternalSM2.g:1326:3: ( rule__CryptographycFunctions__Group_0__0 )
                    // InternalSM2.g:1326:4: rule__CryptographycFunctions__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__CryptographycFunctions__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getCryptographycFunctionsAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1330:2: ( ( rule__CryptographycFunctions__Group_1__0 ) )
                    {
                    // InternalSM2.g:1330:2: ( ( rule__CryptographycFunctions__Group_1__0 ) )
                    // InternalSM2.g:1331:3: ( rule__CryptographycFunctions__Group_1__0 )
                    {
                     before(grammarAccess.getCryptographycFunctionsAccess().getGroup_1()); 
                    // InternalSM2.g:1332:3: ( rule__CryptographycFunctions__Group_1__0 )
                    // InternalSM2.g:1332:4: rule__CryptographycFunctions__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__CryptographycFunctions__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getCryptographycFunctionsAccess().getGroup_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1336:2: ( ( rule__CryptographycFunctions__Group_2__0 ) )
                    {
                    // InternalSM2.g:1336:2: ( ( rule__CryptographycFunctions__Group_2__0 ) )
                    // InternalSM2.g:1337:3: ( rule__CryptographycFunctions__Group_2__0 )
                    {
                     before(grammarAccess.getCryptographycFunctionsAccess().getGroup_2()); 
                    // InternalSM2.g:1338:3: ( rule__CryptographycFunctions__Group_2__0 )
                    // InternalSM2.g:1338:4: rule__CryptographycFunctions__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__CryptographycFunctions__Group_2__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getCryptographycFunctionsAccess().getGroup_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Alternatives"


    // $ANTLR start "rule__Comment__Alternatives"
    // InternalSM2.g:1346:1: rule__Comment__Alternatives : ( ( ruleShortComment ) | ( ruleLongComment ) );
    public final void rule__Comment__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1350:1: ( ( ruleShortComment ) | ( ruleLongComment ) )
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==91) ) {
                alt17=1;
            }
            else if ( (LA17_0==92) ) {
                alt17=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }
            switch (alt17) {
                case 1 :
                    // InternalSM2.g:1351:2: ( ruleShortComment )
                    {
                    // InternalSM2.g:1351:2: ( ruleShortComment )
                    // InternalSM2.g:1352:3: ruleShortComment
                    {
                     before(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleShortComment();

                    state._fsp--;

                     after(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1357:2: ( ruleLongComment )
                    {
                    // InternalSM2.g:1357:2: ( ruleLongComment )
                    // InternalSM2.g:1358:3: ruleLongComment
                    {
                     before(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleLongComment();

                    state._fsp--;

                     after(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Comment__Alternatives"


    // $ANTLR start "rule__Expression__Alternatives"
    // InternalSM2.g:1367:1: rule__Expression__Alternatives : ( ( ruleNegationExpression ) | ( ruleSyntaxExpression ) );
    public final void rule__Expression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1371:1: ( ( ruleNegationExpression ) | ( ruleSyntaxExpression ) )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==39) ) {
                alt18=1;
            }
            else if ( (LA18_0==RULE_STRING) ) {
                alt18=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    // InternalSM2.g:1372:2: ( ruleNegationExpression )
                    {
                    // InternalSM2.g:1372:2: ( ruleNegationExpression )
                    // InternalSM2.g:1373:3: ruleNegationExpression
                    {
                     before(grammarAccess.getExpressionAccess().getNegationExpressionParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleNegationExpression();

                    state._fsp--;

                     after(grammarAccess.getExpressionAccess().getNegationExpressionParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1378:2: ( ruleSyntaxExpression )
                    {
                    // InternalSM2.g:1378:2: ( ruleSyntaxExpression )
                    // InternalSM2.g:1379:3: ruleSyntaxExpression
                    {
                     before(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleSyntaxExpression();

                    state._fsp--;

                     after(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Expression__Alternatives"


    // $ANTLR start "rule__Visibility__Alternatives"
    // InternalSM2.g:1388:1: rule__Visibility__Alternatives : ( ( ( 'public' ) ) | ( ( 'private' ) ) | ( ( 'internal' ) ) );
    public final void rule__Visibility__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1392:1: ( ( ( 'public' ) ) | ( ( 'private' ) ) | ( ( 'internal' ) ) )
            int alt19=3;
            switch ( input.LA(1) ) {
            case 50:
                {
                alt19=1;
                }
                break;
            case 52:
                {
                alt19=2;
                }
                break;
            case 51:
                {
                alt19=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }

            switch (alt19) {
                case 1 :
                    // InternalSM2.g:1393:2: ( ( 'public' ) )
                    {
                    // InternalSM2.g:1393:2: ( ( 'public' ) )
                    // InternalSM2.g:1394:3: ( 'public' )
                    {
                     before(grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1395:3: ( 'public' )
                    // InternalSM2.g:1395:4: 'public'
                    {
                    match(input,50,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1399:2: ( ( 'private' ) )
                    {
                    // InternalSM2.g:1399:2: ( ( 'private' ) )
                    // InternalSM2.g:1400:3: ( 'private' )
                    {
                     before(grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1401:3: ( 'private' )
                    // InternalSM2.g:1401:4: 'private'
                    {
                    match(input,52,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1405:2: ( ( 'internal' ) )
                    {
                    // InternalSM2.g:1405:2: ( ( 'internal' ) )
                    // InternalSM2.g:1406:3: ( 'internal' )
                    {
                     before(grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1407:3: ( 'internal' )
                    // InternalSM2.g:1407:4: 'internal'
                    {
                    match(input,51,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Visibility__Alternatives"


    // $ANTLR start "rule__Coin__Alternatives"
    // InternalSM2.g:1415:1: rule__Coin__Alternatives : ( ( ( 'ether' ) ) | ( ( 'wei' ) ) | ( ( 'gwei' ) ) | ( ( 'pwei' ) ) | ( ( 'finney' ) ) | ( ( 'szabo' ) ) );
    public final void rule__Coin__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1419:1: ( ( ( 'ether' ) ) | ( ( 'wei' ) ) | ( ( 'gwei' ) ) | ( ( 'pwei' ) ) | ( ( 'finney' ) ) | ( ( 'szabo' ) ) )
            int alt20=6;
            switch ( input.LA(1) ) {
            case 53:
                {
                alt20=1;
                }
                break;
            case 54:
                {
                alt20=2;
                }
                break;
            case 55:
                {
                alt20=3;
                }
                break;
            case 56:
                {
                alt20=4;
                }
                break;
            case 57:
                {
                alt20=5;
                }
                break;
            case 58:
                {
                alt20=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;
            }

            switch (alt20) {
                case 1 :
                    // InternalSM2.g:1420:2: ( ( 'ether' ) )
                    {
                    // InternalSM2.g:1420:2: ( ( 'ether' ) )
                    // InternalSM2.g:1421:3: ( 'ether' )
                    {
                     before(grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1422:3: ( 'ether' )
                    // InternalSM2.g:1422:4: 'ether'
                    {
                    match(input,53,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1426:2: ( ( 'wei' ) )
                    {
                    // InternalSM2.g:1426:2: ( ( 'wei' ) )
                    // InternalSM2.g:1427:3: ( 'wei' )
                    {
                     before(grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1428:3: ( 'wei' )
                    // InternalSM2.g:1428:4: 'wei'
                    {
                    match(input,54,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1432:2: ( ( 'gwei' ) )
                    {
                    // InternalSM2.g:1432:2: ( ( 'gwei' ) )
                    // InternalSM2.g:1433:3: ( 'gwei' )
                    {
                     before(grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1434:3: ( 'gwei' )
                    // InternalSM2.g:1434:4: 'gwei'
                    {
                    match(input,55,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1438:2: ( ( 'pwei' ) )
                    {
                    // InternalSM2.g:1438:2: ( ( 'pwei' ) )
                    // InternalSM2.g:1439:3: ( 'pwei' )
                    {
                     before(grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3()); 
                    // InternalSM2.g:1440:3: ( 'pwei' )
                    // InternalSM2.g:1440:4: 'pwei'
                    {
                    match(input,56,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1444:2: ( ( 'finney' ) )
                    {
                    // InternalSM2.g:1444:2: ( ( 'finney' ) )
                    // InternalSM2.g:1445:3: ( 'finney' )
                    {
                     before(grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4()); 
                    // InternalSM2.g:1446:3: ( 'finney' )
                    // InternalSM2.g:1446:4: 'finney'
                    {
                    match(input,57,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1450:2: ( ( 'szabo' ) )
                    {
                    // InternalSM2.g:1450:2: ( ( 'szabo' ) )
                    // InternalSM2.g:1451:3: ( 'szabo' )
                    {
                     before(grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5()); 
                    // InternalSM2.g:1452:3: ( 'szabo' )
                    // InternalSM2.g:1452:4: 'szabo'
                    {
                    match(input,58,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coin__Alternatives"


    // $ANTLR start "rule__ComparationOperator__Alternatives"
    // InternalSM2.g:1460:1: rule__ComparationOperator__Alternatives : ( ( ( '>' ) ) | ( ( '<' ) ) | ( ( '>=' ) ) | ( ( '<=' ) ) | ( ( '==' ) ) | ( ( '!=' ) ) );
    public final void rule__ComparationOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1464:1: ( ( ( '>' ) ) | ( ( '<' ) ) | ( ( '>=' ) ) | ( ( '<=' ) ) | ( ( '==' ) ) | ( ( '!=' ) ) )
            int alt21=6;
            switch ( input.LA(1) ) {
            case 48:
                {
                alt21=1;
                }
                break;
            case 59:
                {
                alt21=2;
                }
                break;
            case 49:
                {
                alt21=3;
                }
                break;
            case 60:
                {
                alt21=4;
                }
                break;
            case 61:
                {
                alt21=5;
                }
                break;
            case 62:
                {
                alt21=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }

            switch (alt21) {
                case 1 :
                    // InternalSM2.g:1465:2: ( ( '>' ) )
                    {
                    // InternalSM2.g:1465:2: ( ( '>' ) )
                    // InternalSM2.g:1466:3: ( '>' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1467:3: ( '>' )
                    // InternalSM2.g:1467:4: '>'
                    {
                    match(input,48,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1471:2: ( ( '<' ) )
                    {
                    // InternalSM2.g:1471:2: ( ( '<' ) )
                    // InternalSM2.g:1472:3: ( '<' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1473:3: ( '<' )
                    // InternalSM2.g:1473:4: '<'
                    {
                    match(input,59,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1477:2: ( ( '>=' ) )
                    {
                    // InternalSM2.g:1477:2: ( ( '>=' ) )
                    // InternalSM2.g:1478:3: ( '>=' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1479:3: ( '>=' )
                    // InternalSM2.g:1479:4: '>='
                    {
                    match(input,49,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1483:2: ( ( '<=' ) )
                    {
                    // InternalSM2.g:1483:2: ( ( '<=' ) )
                    // InternalSM2.g:1484:3: ( '<=' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3()); 
                    // InternalSM2.g:1485:3: ( '<=' )
                    // InternalSM2.g:1485:4: '<='
                    {
                    match(input,60,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1489:2: ( ( '==' ) )
                    {
                    // InternalSM2.g:1489:2: ( ( '==' ) )
                    // InternalSM2.g:1490:3: ( '==' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4()); 
                    // InternalSM2.g:1491:3: ( '==' )
                    // InternalSM2.g:1491:4: '=='
                    {
                    match(input,61,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1495:2: ( ( '!=' ) )
                    {
                    // InternalSM2.g:1495:2: ( ( '!=' ) )
                    // InternalSM2.g:1496:3: ( '!=' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5()); 
                    // InternalSM2.g:1497:3: ( '!=' )
                    // InternalSM2.g:1497:4: '!='
                    {
                    match(input,62,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparationOperator__Alternatives"


    // $ANTLR start "rule__LogicalPairOperator__Alternatives"
    // InternalSM2.g:1505:1: rule__LogicalPairOperator__Alternatives : ( ( ( '&&' ) ) | ( ( '||' ) ) );
    public final void rule__LogicalPairOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1509:1: ( ( ( '&&' ) ) | ( ( '||' ) ) )
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==63) ) {
                alt22=1;
            }
            else if ( (LA22_0==64) ) {
                alt22=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }
            switch (alt22) {
                case 1 :
                    // InternalSM2.g:1510:2: ( ( '&&' ) )
                    {
                    // InternalSM2.g:1510:2: ( ( '&&' ) )
                    // InternalSM2.g:1511:3: ( '&&' )
                    {
                     before(grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1512:3: ( '&&' )
                    // InternalSM2.g:1512:4: '&&'
                    {
                    match(input,63,FOLLOW_2); 

                    }

                     after(grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1516:2: ( ( '||' ) )
                    {
                    // InternalSM2.g:1516:2: ( ( '||' ) )
                    // InternalSM2.g:1517:3: ( '||' )
                    {
                     before(grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1518:3: ( '||' )
                    // InternalSM2.g:1518:4: '||'
                    {
                    match(input,64,FOLLOW_2); 

                    }

                     after(grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicalPairOperator__Alternatives"


    // $ANTLR start "rule__ArithmeticalOperator__Alternatives"
    // InternalSM2.g:1526:1: rule__ArithmeticalOperator__Alternatives : ( ( ( '+' ) ) | ( ( '-' ) ) | ( ( '*' ) ) | ( ( '/' ) ) | ( ( '%' ) ) );
    public final void rule__ArithmeticalOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1530:1: ( ( ( '+' ) ) | ( ( '-' ) ) | ( ( '*' ) ) | ( ( '/' ) ) | ( ( '%' ) ) )
            int alt23=5;
            switch ( input.LA(1) ) {
            case 65:
                {
                alt23=1;
                }
                break;
            case 66:
                {
                alt23=2;
                }
                break;
            case 67:
                {
                alt23=3;
                }
                break;
            case 68:
                {
                alt23=4;
                }
                break;
            case 69:
                {
                alt23=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }

            switch (alt23) {
                case 1 :
                    // InternalSM2.g:1531:2: ( ( '+' ) )
                    {
                    // InternalSM2.g:1531:2: ( ( '+' ) )
                    // InternalSM2.g:1532:3: ( '+' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1533:3: ( '+' )
                    // InternalSM2.g:1533:4: '+'
                    {
                    match(input,65,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getADDEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1537:2: ( ( '-' ) )
                    {
                    // InternalSM2.g:1537:2: ( ( '-' ) )
                    // InternalSM2.g:1538:3: ( '-' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1539:3: ( '-' )
                    // InternalSM2.g:1539:4: '-'
                    {
                    match(input,66,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getSUBTRACTEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1543:2: ( ( '*' ) )
                    {
                    // InternalSM2.g:1543:2: ( ( '*' ) )
                    // InternalSM2.g:1544:3: ( '*' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1545:3: ( '*' )
                    // InternalSM2.g:1545:4: '*'
                    {
                    match(input,67,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getMULTIPLYEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1549:2: ( ( '/' ) )
                    {
                    // InternalSM2.g:1549:2: ( ( '/' ) )
                    // InternalSM2.g:1550:3: ( '/' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3()); 
                    // InternalSM2.g:1551:3: ( '/' )
                    // InternalSM2.g:1551:4: '/'
                    {
                    match(input,68,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getDIVIDEEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1555:2: ( ( '%' ) )
                    {
                    // InternalSM2.g:1555:2: ( ( '%' ) )
                    // InternalSM2.g:1556:3: ( '%' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4()); 
                    // InternalSM2.g:1557:3: ( '%' )
                    // InternalSM2.g:1557:4: '%'
                    {
                    match(input,69,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getMODULOEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmeticalOperator__Alternatives"


    // $ANTLR start "rule__File__Group__0"
    // InternalSM2.g:1565:1: rule__File__Group__0 : rule__File__Group__0__Impl rule__File__Group__1 ;
    public final void rule__File__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1569:1: ( rule__File__Group__0__Impl rule__File__Group__1 )
            // InternalSM2.g:1570:2: rule__File__Group__0__Impl rule__File__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__File__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__File__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__File__Group__0"


    // $ANTLR start "rule__File__Group__0__Impl"
    // InternalSM2.g:1577:1: rule__File__Group__0__Impl : ( ( rule__File__VersionAssignment_0 ) ) ;
    public final void rule__File__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1581:1: ( ( ( rule__File__VersionAssignment_0 ) ) )
            // InternalSM2.g:1582:1: ( ( rule__File__VersionAssignment_0 ) )
            {
            // InternalSM2.g:1582:1: ( ( rule__File__VersionAssignment_0 ) )
            // InternalSM2.g:1583:2: ( rule__File__VersionAssignment_0 )
            {
             before(grammarAccess.getFileAccess().getVersionAssignment_0()); 
            // InternalSM2.g:1584:2: ( rule__File__VersionAssignment_0 )
            // InternalSM2.g:1584:3: rule__File__VersionAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__File__VersionAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getFileAccess().getVersionAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__File__Group__0__Impl"


    // $ANTLR start "rule__File__Group__1"
    // InternalSM2.g:1592:1: rule__File__Group__1 : rule__File__Group__1__Impl rule__File__Group__2 ;
    public final void rule__File__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1596:1: ( rule__File__Group__1__Impl rule__File__Group__2 )
            // InternalSM2.g:1597:2: rule__File__Group__1__Impl rule__File__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__File__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__File__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__File__Group__1"


    // $ANTLR start "rule__File__Group__1__Impl"
    // InternalSM2.g:1604:1: rule__File__Group__1__Impl : ( ruleImport ) ;
    public final void rule__File__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1608:1: ( ( ruleImport ) )
            // InternalSM2.g:1609:1: ( ruleImport )
            {
            // InternalSM2.g:1609:1: ( ruleImport )
            // InternalSM2.g:1610:2: ruleImport
            {
             before(grammarAccess.getFileAccess().getImportParserRuleCall_1()); 
            pushFollow(FOLLOW_2);
            ruleImport();

            state._fsp--;

             after(grammarAccess.getFileAccess().getImportParserRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__File__Group__1__Impl"


    // $ANTLR start "rule__File__Group__2"
    // InternalSM2.g:1619:1: rule__File__Group__2 : rule__File__Group__2__Impl rule__File__Group__3 ;
    public final void rule__File__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1623:1: ( rule__File__Group__2__Impl rule__File__Group__3 )
            // InternalSM2.g:1624:2: rule__File__Group__2__Impl rule__File__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__File__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__File__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__File__Group__2"


    // $ANTLR start "rule__File__Group__2__Impl"
    // InternalSM2.g:1631:1: rule__File__Group__2__Impl : ( ( rule__File__AttributesAssignment_2 )* ) ;
    public final void rule__File__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1635:1: ( ( ( rule__File__AttributesAssignment_2 )* ) )
            // InternalSM2.g:1636:1: ( ( rule__File__AttributesAssignment_2 )* )
            {
            // InternalSM2.g:1636:1: ( ( rule__File__AttributesAssignment_2 )* )
            // InternalSM2.g:1637:2: ( rule__File__AttributesAssignment_2 )*
            {
             before(grammarAccess.getFileAccess().getAttributesAssignment_2()); 
            // InternalSM2.g:1638:2: ( rule__File__AttributesAssignment_2 )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( (LA24_0==RULE_ID||LA24_0==80||(LA24_0>=82 && LA24_0<=83)) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalSM2.g:1638:3: rule__File__AttributesAssignment_2
            	    {
            	    pushFollow(FOLLOW_5);
            	    rule__File__AttributesAssignment_2();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);

             after(grammarAccess.getFileAccess().getAttributesAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__File__Group__2__Impl"


    // $ANTLR start "rule__File__Group__3"
    // InternalSM2.g:1646:1: rule__File__Group__3 : rule__File__Group__3__Impl rule__File__Group__4 ;
    public final void rule__File__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1650:1: ( rule__File__Group__3__Impl rule__File__Group__4 )
            // InternalSM2.g:1651:2: rule__File__Group__3__Impl rule__File__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__File__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__File__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__File__Group__3"


    // $ANTLR start "rule__File__Group__3__Impl"
    // InternalSM2.g:1658:1: rule__File__Group__3__Impl : ( ( rule__File__ContractAssignment_3 ) ) ;
    public final void rule__File__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1662:1: ( ( ( rule__File__ContractAssignment_3 ) ) )
            // InternalSM2.g:1663:1: ( ( rule__File__ContractAssignment_3 ) )
            {
            // InternalSM2.g:1663:1: ( ( rule__File__ContractAssignment_3 ) )
            // InternalSM2.g:1664:2: ( rule__File__ContractAssignment_3 )
            {
             before(grammarAccess.getFileAccess().getContractAssignment_3()); 
            // InternalSM2.g:1665:2: ( rule__File__ContractAssignment_3 )
            // InternalSM2.g:1665:3: rule__File__ContractAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__File__ContractAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getFileAccess().getContractAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__File__Group__3__Impl"


    // $ANTLR start "rule__File__Group__4"
    // InternalSM2.g:1673:1: rule__File__Group__4 : rule__File__Group__4__Impl ;
    public final void rule__File__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1677:1: ( rule__File__Group__4__Impl )
            // InternalSM2.g:1678:2: rule__File__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__File__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__File__Group__4"


    // $ANTLR start "rule__File__Group__4__Impl"
    // InternalSM2.g:1684:1: rule__File__Group__4__Impl : ( ( rule__File__CommentsAssignment_4 )* ) ;
    public final void rule__File__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1688:1: ( ( ( rule__File__CommentsAssignment_4 )* ) )
            // InternalSM2.g:1689:1: ( ( rule__File__CommentsAssignment_4 )* )
            {
            // InternalSM2.g:1689:1: ( ( rule__File__CommentsAssignment_4 )* )
            // InternalSM2.g:1690:2: ( rule__File__CommentsAssignment_4 )*
            {
             before(grammarAccess.getFileAccess().getCommentsAssignment_4()); 
            // InternalSM2.g:1691:2: ( rule__File__CommentsAssignment_4 )*
            loop25:
            do {
                int alt25=2;
                int LA25_0 = input.LA(1);

                if ( ((LA25_0>=91 && LA25_0<=92)) ) {
                    alt25=1;
                }


                switch (alt25) {
            	case 1 :
            	    // InternalSM2.g:1691:3: rule__File__CommentsAssignment_4
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__File__CommentsAssignment_4();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop25;
                }
            } while (true);

             after(grammarAccess.getFileAccess().getCommentsAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__File__Group__4__Impl"


    // $ANTLR start "rule__MSGVariables__Group__0"
    // InternalSM2.g:1700:1: rule__MSGVariables__Group__0 : rule__MSGVariables__Group__0__Impl rule__MSGVariables__Group__1 ;
    public final void rule__MSGVariables__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1704:1: ( rule__MSGVariables__Group__0__Impl rule__MSGVariables__Group__1 )
            // InternalSM2.g:1705:2: rule__MSGVariables__Group__0__Impl rule__MSGVariables__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__MSGVariables__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGVariables__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGVariables__Group__0"


    // $ANTLR start "rule__MSGVariables__Group__0__Impl"
    // InternalSM2.g:1712:1: rule__MSGVariables__Group__0__Impl : ( 'msg' ) ;
    public final void rule__MSGVariables__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1716:1: ( ( 'msg' ) )
            // InternalSM2.g:1717:1: ( 'msg' )
            {
            // InternalSM2.g:1717:1: ( 'msg' )
            // InternalSM2.g:1718:2: 'msg'
            {
             before(grammarAccess.getMSGVariablesAccess().getMsgKeyword_0()); 
            match(input,70,FOLLOW_2); 
             after(grammarAccess.getMSGVariablesAccess().getMsgKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGVariables__Group__0__Impl"


    // $ANTLR start "rule__MSGVariables__Group__1"
    // InternalSM2.g:1727:1: rule__MSGVariables__Group__1 : rule__MSGVariables__Group__1__Impl ;
    public final void rule__MSGVariables__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1731:1: ( rule__MSGVariables__Group__1__Impl )
            // InternalSM2.g:1732:2: rule__MSGVariables__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MSGVariables__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGVariables__Group__1"


    // $ANTLR start "rule__MSGVariables__Group__1__Impl"
    // InternalSM2.g:1738:1: rule__MSGVariables__Group__1__Impl : ( ruleMSGOperation ) ;
    public final void rule__MSGVariables__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1742:1: ( ( ruleMSGOperation ) )
            // InternalSM2.g:1743:1: ( ruleMSGOperation )
            {
            // InternalSM2.g:1743:1: ( ruleMSGOperation )
            // InternalSM2.g:1744:2: ruleMSGOperation
            {
             before(grammarAccess.getMSGVariablesAccess().getMSGOperationParserRuleCall_1()); 
            pushFollow(FOLLOW_2);
            ruleMSGOperation();

            state._fsp--;

             after(grammarAccess.getMSGVariablesAccess().getMSGOperationParserRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGVariables__Group__1__Impl"


    // $ANTLR start "rule__MSGOperation__Group__0"
    // InternalSM2.g:1754:1: rule__MSGOperation__Group__0 : rule__MSGOperation__Group__0__Impl rule__MSGOperation__Group__1 ;
    public final void rule__MSGOperation__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1758:1: ( rule__MSGOperation__Group__0__Impl rule__MSGOperation__Group__1 )
            // InternalSM2.g:1759:2: rule__MSGOperation__Group__0__Impl rule__MSGOperation__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__MSGOperation__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group__0"


    // $ANTLR start "rule__MSGOperation__Group__0__Impl"
    // InternalSM2.g:1766:1: rule__MSGOperation__Group__0__Impl : ( RULE_DOT ) ;
    public final void rule__MSGOperation__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1770:1: ( ( RULE_DOT ) )
            // InternalSM2.g:1771:1: ( RULE_DOT )
            {
            // InternalSM2.g:1771:1: ( RULE_DOT )
            // InternalSM2.g:1772:2: RULE_DOT
            {
             before(grammarAccess.getMSGOperationAccess().getDOTTerminalRuleCall_0()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getDOTTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group__0__Impl"


    // $ANTLR start "rule__MSGOperation__Group__1"
    // InternalSM2.g:1781:1: rule__MSGOperation__Group__1 : rule__MSGOperation__Group__1__Impl rule__MSGOperation__Group__2 ;
    public final void rule__MSGOperation__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1785:1: ( rule__MSGOperation__Group__1__Impl rule__MSGOperation__Group__2 )
            // InternalSM2.g:1786:2: rule__MSGOperation__Group__1__Impl rule__MSGOperation__Group__2
            {
            pushFollow(FOLLOW_10);
            rule__MSGOperation__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group__1"


    // $ANTLR start "rule__MSGOperation__Group__1__Impl"
    // InternalSM2.g:1793:1: rule__MSGOperation__Group__1__Impl : ( ( rule__MSGOperation__Alternatives_1 ) ) ;
    public final void rule__MSGOperation__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1797:1: ( ( ( rule__MSGOperation__Alternatives_1 ) ) )
            // InternalSM2.g:1798:1: ( ( rule__MSGOperation__Alternatives_1 ) )
            {
            // InternalSM2.g:1798:1: ( ( rule__MSGOperation__Alternatives_1 ) )
            // InternalSM2.g:1799:2: ( rule__MSGOperation__Alternatives_1 )
            {
             before(grammarAccess.getMSGOperationAccess().getAlternatives_1()); 
            // InternalSM2.g:1800:2: ( rule__MSGOperation__Alternatives_1 )
            // InternalSM2.g:1800:3: rule__MSGOperation__Alternatives_1
            {
            pushFollow(FOLLOW_2);
            rule__MSGOperation__Alternatives_1();

            state._fsp--;


            }

             after(grammarAccess.getMSGOperationAccess().getAlternatives_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group__1__Impl"


    // $ANTLR start "rule__MSGOperation__Group__2"
    // InternalSM2.g:1808:1: rule__MSGOperation__Group__2 : rule__MSGOperation__Group__2__Impl ;
    public final void rule__MSGOperation__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1812:1: ( rule__MSGOperation__Group__2__Impl )
            // InternalSM2.g:1813:2: rule__MSGOperation__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group__2"


    // $ANTLR start "rule__MSGOperation__Group__2__Impl"
    // InternalSM2.g:1819:1: rule__MSGOperation__Group__2__Impl : ( ( rule__MSGOperation__Group_2__0 )? ) ;
    public final void rule__MSGOperation__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1823:1: ( ( ( rule__MSGOperation__Group_2__0 )? ) )
            // InternalSM2.g:1824:1: ( ( rule__MSGOperation__Group_2__0 )? )
            {
            // InternalSM2.g:1824:1: ( ( rule__MSGOperation__Group_2__0 )? )
            // InternalSM2.g:1825:2: ( rule__MSGOperation__Group_2__0 )?
            {
             before(grammarAccess.getMSGOperationAccess().getGroup_2()); 
            // InternalSM2.g:1826:2: ( rule__MSGOperation__Group_2__0 )?
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==RULE_SEMICOLON) ) {
                alt26=1;
            }
            switch (alt26) {
                case 1 :
                    // InternalSM2.g:1826:3: rule__MSGOperation__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MSGOperation__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMSGOperationAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group__2__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_0_0__0"
    // InternalSM2.g:1835:1: rule__MSGOperation__Group_1_0_0__0 : rule__MSGOperation__Group_1_0_0__0__Impl rule__MSGOperation__Group_1_0_0__1 ;
    public final void rule__MSGOperation__Group_1_0_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1839:1: ( rule__MSGOperation__Group_1_0_0__0__Impl rule__MSGOperation__Group_1_0_0__1 )
            // InternalSM2.g:1840:2: rule__MSGOperation__Group_1_0_0__0__Impl rule__MSGOperation__Group_1_0_0__1
            {
            pushFollow(FOLLOW_11);
            rule__MSGOperation__Group_1_0_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_0_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_0_0__0"


    // $ANTLR start "rule__MSGOperation__Group_1_0_0__0__Impl"
    // InternalSM2.g:1847:1: rule__MSGOperation__Group_1_0_0__0__Impl : ( 'data' ) ;
    public final void rule__MSGOperation__Group_1_0_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1851:1: ( ( 'data' ) )
            // InternalSM2.g:1852:1: ( 'data' )
            {
            // InternalSM2.g:1852:1: ( 'data' )
            // InternalSM2.g:1853:2: 'data'
            {
             before(grammarAccess.getMSGOperationAccess().getDataKeyword_1_0_0_0()); 
            match(input,40,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getDataKeyword_1_0_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_0_0__0__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_0_0__1"
    // InternalSM2.g:1862:1: rule__MSGOperation__Group_1_0_0__1 : rule__MSGOperation__Group_1_0_0__1__Impl rule__MSGOperation__Group_1_0_0__2 ;
    public final void rule__MSGOperation__Group_1_0_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1866:1: ( rule__MSGOperation__Group_1_0_0__1__Impl rule__MSGOperation__Group_1_0_0__2 )
            // InternalSM2.g:1867:2: rule__MSGOperation__Group_1_0_0__1__Impl rule__MSGOperation__Group_1_0_0__2
            {
            pushFollow(FOLLOW_12);
            rule__MSGOperation__Group_1_0_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_0_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_0_0__1"


    // $ANTLR start "rule__MSGOperation__Group_1_0_0__1__Impl"
    // InternalSM2.g:1874:1: rule__MSGOperation__Group_1_0_0__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__MSGOperation__Group_1_0_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1878:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:1879:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:1879:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:1880:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_0_0_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_0_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_0_0__1__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_0_0__2"
    // InternalSM2.g:1889:1: rule__MSGOperation__Group_1_0_0__2 : rule__MSGOperation__Group_1_0_0__2__Impl rule__MSGOperation__Group_1_0_0__3 ;
    public final void rule__MSGOperation__Group_1_0_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1893:1: ( rule__MSGOperation__Group_1_0_0__2__Impl rule__MSGOperation__Group_1_0_0__3 )
            // InternalSM2.g:1894:2: rule__MSGOperation__Group_1_0_0__2__Impl rule__MSGOperation__Group_1_0_0__3
            {
            pushFollow(FOLLOW_13);
            rule__MSGOperation__Group_1_0_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_0_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_0_0__2"


    // $ANTLR start "rule__MSGOperation__Group_1_0_0__2__Impl"
    // InternalSM2.g:1901:1: rule__MSGOperation__Group_1_0_0__2__Impl : ( ruleExpression ) ;
    public final void rule__MSGOperation__Group_1_0_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1905:1: ( ( ruleExpression ) )
            // InternalSM2.g:1906:1: ( ruleExpression )
            {
            // InternalSM2.g:1906:1: ( ruleExpression )
            // InternalSM2.g:1907:2: ruleExpression
            {
             before(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_0_0_2()); 
            pushFollow(FOLLOW_2);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_0_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_0_0__2__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_0_0__3"
    // InternalSM2.g:1916:1: rule__MSGOperation__Group_1_0_0__3 : rule__MSGOperation__Group_1_0_0__3__Impl ;
    public final void rule__MSGOperation__Group_1_0_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1920:1: ( rule__MSGOperation__Group_1_0_0__3__Impl )
            // InternalSM2.g:1921:2: rule__MSGOperation__Group_1_0_0__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_0_0__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_0_0__3"


    // $ANTLR start "rule__MSGOperation__Group_1_0_0__3__Impl"
    // InternalSM2.g:1927:1: rule__MSGOperation__Group_1_0_0__3__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__MSGOperation__Group_1_0_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1931:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:1932:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:1932:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:1933:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_0_3()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_0_0__3__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_1_0__0"
    // InternalSM2.g:1943:1: rule__MSGOperation__Group_1_1_0__0 : rule__MSGOperation__Group_1_1_0__0__Impl rule__MSGOperation__Group_1_1_0__1 ;
    public final void rule__MSGOperation__Group_1_1_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1947:1: ( rule__MSGOperation__Group_1_1_0__0__Impl rule__MSGOperation__Group_1_1_0__1 )
            // InternalSM2.g:1948:2: rule__MSGOperation__Group_1_1_0__0__Impl rule__MSGOperation__Group_1_1_0__1
            {
            pushFollow(FOLLOW_11);
            rule__MSGOperation__Group_1_1_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_1_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_1_0__0"


    // $ANTLR start "rule__MSGOperation__Group_1_1_0__0__Impl"
    // InternalSM2.g:1955:1: rule__MSGOperation__Group_1_1_0__0__Impl : ( 'value' ) ;
    public final void rule__MSGOperation__Group_1_1_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1959:1: ( ( 'value' ) )
            // InternalSM2.g:1960:1: ( 'value' )
            {
            // InternalSM2.g:1960:1: ( 'value' )
            // InternalSM2.g:1961:2: 'value'
            {
             before(grammarAccess.getMSGOperationAccess().getValueKeyword_1_1_0_0()); 
            match(input,41,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getValueKeyword_1_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_1_0__0__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_1_0__1"
    // InternalSM2.g:1970:1: rule__MSGOperation__Group_1_1_0__1 : rule__MSGOperation__Group_1_1_0__1__Impl rule__MSGOperation__Group_1_1_0__2 ;
    public final void rule__MSGOperation__Group_1_1_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1974:1: ( rule__MSGOperation__Group_1_1_0__1__Impl rule__MSGOperation__Group_1_1_0__2 )
            // InternalSM2.g:1975:2: rule__MSGOperation__Group_1_1_0__1__Impl rule__MSGOperation__Group_1_1_0__2
            {
            pushFollow(FOLLOW_12);
            rule__MSGOperation__Group_1_1_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_1_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_1_0__1"


    // $ANTLR start "rule__MSGOperation__Group_1_1_0__1__Impl"
    // InternalSM2.g:1982:1: rule__MSGOperation__Group_1_1_0__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__MSGOperation__Group_1_1_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1986:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:1987:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:1987:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:1988:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1_0_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_1_0__1__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_1_0__2"
    // InternalSM2.g:1997:1: rule__MSGOperation__Group_1_1_0__2 : rule__MSGOperation__Group_1_1_0__2__Impl rule__MSGOperation__Group_1_1_0__3 ;
    public final void rule__MSGOperation__Group_1_1_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2001:1: ( rule__MSGOperation__Group_1_1_0__2__Impl rule__MSGOperation__Group_1_1_0__3 )
            // InternalSM2.g:2002:2: rule__MSGOperation__Group_1_1_0__2__Impl rule__MSGOperation__Group_1_1_0__3
            {
            pushFollow(FOLLOW_13);
            rule__MSGOperation__Group_1_1_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_1_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_1_0__2"


    // $ANTLR start "rule__MSGOperation__Group_1_1_0__2__Impl"
    // InternalSM2.g:2009:1: rule__MSGOperation__Group_1_1_0__2__Impl : ( ruleExpression ) ;
    public final void rule__MSGOperation__Group_1_1_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2013:1: ( ( ruleExpression ) )
            // InternalSM2.g:2014:1: ( ruleExpression )
            {
            // InternalSM2.g:2014:1: ( ruleExpression )
            // InternalSM2.g:2015:2: ruleExpression
            {
             before(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_1_0_2()); 
            pushFollow(FOLLOW_2);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_1_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_1_0__2__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_1_0__3"
    // InternalSM2.g:2024:1: rule__MSGOperation__Group_1_1_0__3 : rule__MSGOperation__Group_1_1_0__3__Impl ;
    public final void rule__MSGOperation__Group_1_1_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2028:1: ( rule__MSGOperation__Group_1_1_0__3__Impl )
            // InternalSM2.g:2029:2: rule__MSGOperation__Group_1_1_0__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_1_0__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_1_0__3"


    // $ANTLR start "rule__MSGOperation__Group_1_1_0__3__Impl"
    // InternalSM2.g:2035:1: rule__MSGOperation__Group_1_1_0__3__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__MSGOperation__Group_1_1_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2039:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2040:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2040:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2041:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_0_3()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_1_0__3__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_2_0__0"
    // InternalSM2.g:2051:1: rule__MSGOperation__Group_1_2_0__0 : rule__MSGOperation__Group_1_2_0__0__Impl rule__MSGOperation__Group_1_2_0__1 ;
    public final void rule__MSGOperation__Group_1_2_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2055:1: ( rule__MSGOperation__Group_1_2_0__0__Impl rule__MSGOperation__Group_1_2_0__1 )
            // InternalSM2.g:2056:2: rule__MSGOperation__Group_1_2_0__0__Impl rule__MSGOperation__Group_1_2_0__1
            {
            pushFollow(FOLLOW_11);
            rule__MSGOperation__Group_1_2_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_2_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_2_0__0"


    // $ANTLR start "rule__MSGOperation__Group_1_2_0__0__Impl"
    // InternalSM2.g:2063:1: rule__MSGOperation__Group_1_2_0__0__Impl : ( 'gas' ) ;
    public final void rule__MSGOperation__Group_1_2_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2067:1: ( ( 'gas' ) )
            // InternalSM2.g:2068:1: ( 'gas' )
            {
            // InternalSM2.g:2068:1: ( 'gas' )
            // InternalSM2.g:2069:2: 'gas'
            {
             before(grammarAccess.getMSGOperationAccess().getGasKeyword_1_2_0_0()); 
            match(input,42,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getGasKeyword_1_2_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_2_0__0__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_2_0__1"
    // InternalSM2.g:2078:1: rule__MSGOperation__Group_1_2_0__1 : rule__MSGOperation__Group_1_2_0__1__Impl rule__MSGOperation__Group_1_2_0__2 ;
    public final void rule__MSGOperation__Group_1_2_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2082:1: ( rule__MSGOperation__Group_1_2_0__1__Impl rule__MSGOperation__Group_1_2_0__2 )
            // InternalSM2.g:2083:2: rule__MSGOperation__Group_1_2_0__1__Impl rule__MSGOperation__Group_1_2_0__2
            {
            pushFollow(FOLLOW_12);
            rule__MSGOperation__Group_1_2_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_2_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_2_0__1"


    // $ANTLR start "rule__MSGOperation__Group_1_2_0__1__Impl"
    // InternalSM2.g:2090:1: rule__MSGOperation__Group_1_2_0__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__MSGOperation__Group_1_2_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2094:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:2095:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:2095:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:2096:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_2_0_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_2_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_2_0__1__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_2_0__2"
    // InternalSM2.g:2105:1: rule__MSGOperation__Group_1_2_0__2 : rule__MSGOperation__Group_1_2_0__2__Impl rule__MSGOperation__Group_1_2_0__3 ;
    public final void rule__MSGOperation__Group_1_2_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2109:1: ( rule__MSGOperation__Group_1_2_0__2__Impl rule__MSGOperation__Group_1_2_0__3 )
            // InternalSM2.g:2110:2: rule__MSGOperation__Group_1_2_0__2__Impl rule__MSGOperation__Group_1_2_0__3
            {
            pushFollow(FOLLOW_13);
            rule__MSGOperation__Group_1_2_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_2_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_2_0__2"


    // $ANTLR start "rule__MSGOperation__Group_1_2_0__2__Impl"
    // InternalSM2.g:2117:1: rule__MSGOperation__Group_1_2_0__2__Impl : ( ruleExpression ) ;
    public final void rule__MSGOperation__Group_1_2_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2121:1: ( ( ruleExpression ) )
            // InternalSM2.g:2122:1: ( ruleExpression )
            {
            // InternalSM2.g:2122:1: ( ruleExpression )
            // InternalSM2.g:2123:2: ruleExpression
            {
             before(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_2_0_2()); 
            pushFollow(FOLLOW_2);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_2_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_2_0__2__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_2_0__3"
    // InternalSM2.g:2132:1: rule__MSGOperation__Group_1_2_0__3 : rule__MSGOperation__Group_1_2_0__3__Impl ;
    public final void rule__MSGOperation__Group_1_2_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2136:1: ( rule__MSGOperation__Group_1_2_0__3__Impl )
            // InternalSM2.g:2137:2: rule__MSGOperation__Group_1_2_0__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_2_0__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_2_0__3"


    // $ANTLR start "rule__MSGOperation__Group_1_2_0__3__Impl"
    // InternalSM2.g:2143:1: rule__MSGOperation__Group_1_2_0__3__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__MSGOperation__Group_1_2_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2147:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2148:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2148:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2149:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_2_0_3()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_2_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_2_0__3__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_3_0__0"
    // InternalSM2.g:2159:1: rule__MSGOperation__Group_1_3_0__0 : rule__MSGOperation__Group_1_3_0__0__Impl rule__MSGOperation__Group_1_3_0__1 ;
    public final void rule__MSGOperation__Group_1_3_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2163:1: ( rule__MSGOperation__Group_1_3_0__0__Impl rule__MSGOperation__Group_1_3_0__1 )
            // InternalSM2.g:2164:2: rule__MSGOperation__Group_1_3_0__0__Impl rule__MSGOperation__Group_1_3_0__1
            {
            pushFollow(FOLLOW_11);
            rule__MSGOperation__Group_1_3_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_3_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_3_0__0"


    // $ANTLR start "rule__MSGOperation__Group_1_3_0__0__Impl"
    // InternalSM2.g:2171:1: rule__MSGOperation__Group_1_3_0__0__Impl : ( 'sender' ) ;
    public final void rule__MSGOperation__Group_1_3_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2175:1: ( ( 'sender' ) )
            // InternalSM2.g:2176:1: ( 'sender' )
            {
            // InternalSM2.g:2176:1: ( 'sender' )
            // InternalSM2.g:2177:2: 'sender'
            {
             before(grammarAccess.getMSGOperationAccess().getSenderKeyword_1_3_0_0()); 
            match(input,43,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getSenderKeyword_1_3_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_3_0__0__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_3_0__1"
    // InternalSM2.g:2186:1: rule__MSGOperation__Group_1_3_0__1 : rule__MSGOperation__Group_1_3_0__1__Impl rule__MSGOperation__Group_1_3_0__2 ;
    public final void rule__MSGOperation__Group_1_3_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2190:1: ( rule__MSGOperation__Group_1_3_0__1__Impl rule__MSGOperation__Group_1_3_0__2 )
            // InternalSM2.g:2191:2: rule__MSGOperation__Group_1_3_0__1__Impl rule__MSGOperation__Group_1_3_0__2
            {
            pushFollow(FOLLOW_12);
            rule__MSGOperation__Group_1_3_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_3_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_3_0__1"


    // $ANTLR start "rule__MSGOperation__Group_1_3_0__1__Impl"
    // InternalSM2.g:2198:1: rule__MSGOperation__Group_1_3_0__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__MSGOperation__Group_1_3_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2202:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:2203:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:2203:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:2204:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_3_0_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_3_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_3_0__1__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_3_0__2"
    // InternalSM2.g:2213:1: rule__MSGOperation__Group_1_3_0__2 : rule__MSGOperation__Group_1_3_0__2__Impl rule__MSGOperation__Group_1_3_0__3 ;
    public final void rule__MSGOperation__Group_1_3_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2217:1: ( rule__MSGOperation__Group_1_3_0__2__Impl rule__MSGOperation__Group_1_3_0__3 )
            // InternalSM2.g:2218:2: rule__MSGOperation__Group_1_3_0__2__Impl rule__MSGOperation__Group_1_3_0__3
            {
            pushFollow(FOLLOW_13);
            rule__MSGOperation__Group_1_3_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_3_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_3_0__2"


    // $ANTLR start "rule__MSGOperation__Group_1_3_0__2__Impl"
    // InternalSM2.g:2225:1: rule__MSGOperation__Group_1_3_0__2__Impl : ( ruleExpression ) ;
    public final void rule__MSGOperation__Group_1_3_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2229:1: ( ( ruleExpression ) )
            // InternalSM2.g:2230:1: ( ruleExpression )
            {
            // InternalSM2.g:2230:1: ( ruleExpression )
            // InternalSM2.g:2231:2: ruleExpression
            {
             before(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_3_0_2()); 
            pushFollow(FOLLOW_2);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_3_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_3_0__2__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_3_0__3"
    // InternalSM2.g:2240:1: rule__MSGOperation__Group_1_3_0__3 : rule__MSGOperation__Group_1_3_0__3__Impl ;
    public final void rule__MSGOperation__Group_1_3_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2244:1: ( rule__MSGOperation__Group_1_3_0__3__Impl )
            // InternalSM2.g:2245:2: rule__MSGOperation__Group_1_3_0__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_3_0__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_3_0__3"


    // $ANTLR start "rule__MSGOperation__Group_1_3_0__3__Impl"
    // InternalSM2.g:2251:1: rule__MSGOperation__Group_1_3_0__3__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__MSGOperation__Group_1_3_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2255:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2256:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2256:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2257:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3_0_3()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_3_0__3__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_4_0__0"
    // InternalSM2.g:2267:1: rule__MSGOperation__Group_1_4_0__0 : rule__MSGOperation__Group_1_4_0__0__Impl rule__MSGOperation__Group_1_4_0__1 ;
    public final void rule__MSGOperation__Group_1_4_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2271:1: ( rule__MSGOperation__Group_1_4_0__0__Impl rule__MSGOperation__Group_1_4_0__1 )
            // InternalSM2.g:2272:2: rule__MSGOperation__Group_1_4_0__0__Impl rule__MSGOperation__Group_1_4_0__1
            {
            pushFollow(FOLLOW_11);
            rule__MSGOperation__Group_1_4_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_4_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_4_0__0"


    // $ANTLR start "rule__MSGOperation__Group_1_4_0__0__Impl"
    // InternalSM2.g:2279:1: rule__MSGOperation__Group_1_4_0__0__Impl : ( 'sig' ) ;
    public final void rule__MSGOperation__Group_1_4_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2283:1: ( ( 'sig' ) )
            // InternalSM2.g:2284:1: ( 'sig' )
            {
            // InternalSM2.g:2284:1: ( 'sig' )
            // InternalSM2.g:2285:2: 'sig'
            {
             before(grammarAccess.getMSGOperationAccess().getSigKeyword_1_4_0_0()); 
            match(input,44,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getSigKeyword_1_4_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_4_0__0__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_4_0__1"
    // InternalSM2.g:2294:1: rule__MSGOperation__Group_1_4_0__1 : rule__MSGOperation__Group_1_4_0__1__Impl rule__MSGOperation__Group_1_4_0__2 ;
    public final void rule__MSGOperation__Group_1_4_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2298:1: ( rule__MSGOperation__Group_1_4_0__1__Impl rule__MSGOperation__Group_1_4_0__2 )
            // InternalSM2.g:2299:2: rule__MSGOperation__Group_1_4_0__1__Impl rule__MSGOperation__Group_1_4_0__2
            {
            pushFollow(FOLLOW_12);
            rule__MSGOperation__Group_1_4_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_4_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_4_0__1"


    // $ANTLR start "rule__MSGOperation__Group_1_4_0__1__Impl"
    // InternalSM2.g:2306:1: rule__MSGOperation__Group_1_4_0__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__MSGOperation__Group_1_4_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2310:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:2311:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:2311:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:2312:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_4_0_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_4_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_4_0__1__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_4_0__2"
    // InternalSM2.g:2321:1: rule__MSGOperation__Group_1_4_0__2 : rule__MSGOperation__Group_1_4_0__2__Impl rule__MSGOperation__Group_1_4_0__3 ;
    public final void rule__MSGOperation__Group_1_4_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2325:1: ( rule__MSGOperation__Group_1_4_0__2__Impl rule__MSGOperation__Group_1_4_0__3 )
            // InternalSM2.g:2326:2: rule__MSGOperation__Group_1_4_0__2__Impl rule__MSGOperation__Group_1_4_0__3
            {
            pushFollow(FOLLOW_13);
            rule__MSGOperation__Group_1_4_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_4_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_4_0__2"


    // $ANTLR start "rule__MSGOperation__Group_1_4_0__2__Impl"
    // InternalSM2.g:2333:1: rule__MSGOperation__Group_1_4_0__2__Impl : ( ruleExpression ) ;
    public final void rule__MSGOperation__Group_1_4_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2337:1: ( ( ruleExpression ) )
            // InternalSM2.g:2338:1: ( ruleExpression )
            {
            // InternalSM2.g:2338:1: ( ruleExpression )
            // InternalSM2.g:2339:2: ruleExpression
            {
             before(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_4_0_2()); 
            pushFollow(FOLLOW_2);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getMSGOperationAccess().getExpressionParserRuleCall_1_4_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_4_0__2__Impl"


    // $ANTLR start "rule__MSGOperation__Group_1_4_0__3"
    // InternalSM2.g:2348:1: rule__MSGOperation__Group_1_4_0__3 : rule__MSGOperation__Group_1_4_0__3__Impl ;
    public final void rule__MSGOperation__Group_1_4_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2352:1: ( rule__MSGOperation__Group_1_4_0__3__Impl )
            // InternalSM2.g:2353:2: rule__MSGOperation__Group_1_4_0__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_1_4_0__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_4_0__3"


    // $ANTLR start "rule__MSGOperation__Group_1_4_0__3__Impl"
    // InternalSM2.g:2359:1: rule__MSGOperation__Group_1_4_0__3__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__MSGOperation__Group_1_4_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2363:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2364:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2364:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2365:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_4_0_3()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_4_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_1_4_0__3__Impl"


    // $ANTLR start "rule__MSGOperation__Group_2__0"
    // InternalSM2.g:2375:1: rule__MSGOperation__Group_2__0 : rule__MSGOperation__Group_2__0__Impl rule__MSGOperation__Group_2__1 ;
    public final void rule__MSGOperation__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2379:1: ( rule__MSGOperation__Group_2__0__Impl rule__MSGOperation__Group_2__1 )
            // InternalSM2.g:2380:2: rule__MSGOperation__Group_2__0__Impl rule__MSGOperation__Group_2__1
            {
            pushFollow(FOLLOW_14);
            rule__MSGOperation__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_2__0"


    // $ANTLR start "rule__MSGOperation__Group_2__0__Impl"
    // InternalSM2.g:2387:1: rule__MSGOperation__Group_2__0__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__MSGOperation__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2391:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:2392:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:2392:1: ( RULE_SEMICOLON )
            // InternalSM2.g:2393:2: RULE_SEMICOLON
            {
             before(grammarAccess.getMSGOperationAccess().getSEMICOLONTerminalRuleCall_2_0()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getSEMICOLONTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_2__0__Impl"


    // $ANTLR start "rule__MSGOperation__Group_2__1"
    // InternalSM2.g:2402:1: rule__MSGOperation__Group_2__1 : rule__MSGOperation__Group_2__1__Impl ;
    public final void rule__MSGOperation__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2406:1: ( rule__MSGOperation__Group_2__1__Impl )
            // InternalSM2.g:2407:2: rule__MSGOperation__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MSGOperation__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_2__1"


    // $ANTLR start "rule__MSGOperation__Group_2__1__Impl"
    // InternalSM2.g:2413:1: rule__MSGOperation__Group_2__1__Impl : ( RULE_EOLINE ) ;
    public final void rule__MSGOperation__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2417:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:2418:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:2418:1: ( RULE_EOLINE )
            // InternalSM2.g:2419:2: RULE_EOLINE
            {
             before(grammarAccess.getMSGOperationAccess().getEOLINETerminalRuleCall_2_1()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getMSGOperationAccess().getEOLINETerminalRuleCall_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MSGOperation__Group_2__1__Impl"


    // $ANTLR start "rule__TxVariables__Group__0"
    // InternalSM2.g:2429:1: rule__TxVariables__Group__0 : rule__TxVariables__Group__0__Impl rule__TxVariables__Group__1 ;
    public final void rule__TxVariables__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2433:1: ( rule__TxVariables__Group__0__Impl rule__TxVariables__Group__1 )
            // InternalSM2.g:2434:2: rule__TxVariables__Group__0__Impl rule__TxVariables__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__TxVariables__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TxVariables__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxVariables__Group__0"


    // $ANTLR start "rule__TxVariables__Group__0__Impl"
    // InternalSM2.g:2441:1: rule__TxVariables__Group__0__Impl : ( 'tx' ) ;
    public final void rule__TxVariables__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2445:1: ( ( 'tx' ) )
            // InternalSM2.g:2446:1: ( 'tx' )
            {
            // InternalSM2.g:2446:1: ( 'tx' )
            // InternalSM2.g:2447:2: 'tx'
            {
             before(grammarAccess.getTxVariablesAccess().getTxKeyword_0()); 
            match(input,71,FOLLOW_2); 
             after(grammarAccess.getTxVariablesAccess().getTxKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxVariables__Group__0__Impl"


    // $ANTLR start "rule__TxVariables__Group__1"
    // InternalSM2.g:2456:1: rule__TxVariables__Group__1 : rule__TxVariables__Group__1__Impl ;
    public final void rule__TxVariables__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2460:1: ( rule__TxVariables__Group__1__Impl )
            // InternalSM2.g:2461:2: rule__TxVariables__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TxVariables__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxVariables__Group__1"


    // $ANTLR start "rule__TxVariables__Group__1__Impl"
    // InternalSM2.g:2467:1: rule__TxVariables__Group__1__Impl : ( ruleTxOperation ) ;
    public final void rule__TxVariables__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2471:1: ( ( ruleTxOperation ) )
            // InternalSM2.g:2472:1: ( ruleTxOperation )
            {
            // InternalSM2.g:2472:1: ( ruleTxOperation )
            // InternalSM2.g:2473:2: ruleTxOperation
            {
             before(grammarAccess.getTxVariablesAccess().getTxOperationParserRuleCall_1()); 
            pushFollow(FOLLOW_2);
            ruleTxOperation();

            state._fsp--;

             after(grammarAccess.getTxVariablesAccess().getTxOperationParserRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxVariables__Group__1__Impl"


    // $ANTLR start "rule__TxOperation__Group__0"
    // InternalSM2.g:2483:1: rule__TxOperation__Group__0 : rule__TxOperation__Group__0__Impl rule__TxOperation__Group__1 ;
    public final void rule__TxOperation__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2487:1: ( rule__TxOperation__Group__0__Impl rule__TxOperation__Group__1 )
            // InternalSM2.g:2488:2: rule__TxOperation__Group__0__Impl rule__TxOperation__Group__1
            {
            pushFollow(FOLLOW_15);
            rule__TxOperation__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TxOperation__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group__0"


    // $ANTLR start "rule__TxOperation__Group__0__Impl"
    // InternalSM2.g:2495:1: rule__TxOperation__Group__0__Impl : ( RULE_DOT ) ;
    public final void rule__TxOperation__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2499:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2500:1: ( RULE_DOT )
            {
            // InternalSM2.g:2500:1: ( RULE_DOT )
            // InternalSM2.g:2501:2: RULE_DOT
            {
             before(grammarAccess.getTxOperationAccess().getDOTTerminalRuleCall_0()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getTxOperationAccess().getDOTTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group__0__Impl"


    // $ANTLR start "rule__TxOperation__Group__1"
    // InternalSM2.g:2510:1: rule__TxOperation__Group__1 : rule__TxOperation__Group__1__Impl rule__TxOperation__Group__2 ;
    public final void rule__TxOperation__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2514:1: ( rule__TxOperation__Group__1__Impl rule__TxOperation__Group__2 )
            // InternalSM2.g:2515:2: rule__TxOperation__Group__1__Impl rule__TxOperation__Group__2
            {
            pushFollow(FOLLOW_10);
            rule__TxOperation__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TxOperation__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group__1"


    // $ANTLR start "rule__TxOperation__Group__1__Impl"
    // InternalSM2.g:2522:1: rule__TxOperation__Group__1__Impl : ( ( rule__TxOperation__Alternatives_1 ) ) ;
    public final void rule__TxOperation__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2526:1: ( ( ( rule__TxOperation__Alternatives_1 ) ) )
            // InternalSM2.g:2527:1: ( ( rule__TxOperation__Alternatives_1 ) )
            {
            // InternalSM2.g:2527:1: ( ( rule__TxOperation__Alternatives_1 ) )
            // InternalSM2.g:2528:2: ( rule__TxOperation__Alternatives_1 )
            {
             before(grammarAccess.getTxOperationAccess().getAlternatives_1()); 
            // InternalSM2.g:2529:2: ( rule__TxOperation__Alternatives_1 )
            // InternalSM2.g:2529:3: rule__TxOperation__Alternatives_1
            {
            pushFollow(FOLLOW_2);
            rule__TxOperation__Alternatives_1();

            state._fsp--;


            }

             after(grammarAccess.getTxOperationAccess().getAlternatives_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group__1__Impl"


    // $ANTLR start "rule__TxOperation__Group__2"
    // InternalSM2.g:2537:1: rule__TxOperation__Group__2 : rule__TxOperation__Group__2__Impl ;
    public final void rule__TxOperation__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2541:1: ( rule__TxOperation__Group__2__Impl )
            // InternalSM2.g:2542:2: rule__TxOperation__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TxOperation__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group__2"


    // $ANTLR start "rule__TxOperation__Group__2__Impl"
    // InternalSM2.g:2548:1: rule__TxOperation__Group__2__Impl : ( ( rule__TxOperation__Group_2__0 )? ) ;
    public final void rule__TxOperation__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2552:1: ( ( ( rule__TxOperation__Group_2__0 )? ) )
            // InternalSM2.g:2553:1: ( ( rule__TxOperation__Group_2__0 )? )
            {
            // InternalSM2.g:2553:1: ( ( rule__TxOperation__Group_2__0 )? )
            // InternalSM2.g:2554:2: ( rule__TxOperation__Group_2__0 )?
            {
             before(grammarAccess.getTxOperationAccess().getGroup_2()); 
            // InternalSM2.g:2555:2: ( rule__TxOperation__Group_2__0 )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==RULE_SEMICOLON) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalSM2.g:2555:3: rule__TxOperation__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__TxOperation__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTxOperationAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group__2__Impl"


    // $ANTLR start "rule__TxOperation__Group_1_0_0__0"
    // InternalSM2.g:2564:1: rule__TxOperation__Group_1_0_0__0 : rule__TxOperation__Group_1_0_0__0__Impl rule__TxOperation__Group_1_0_0__1 ;
    public final void rule__TxOperation__Group_1_0_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2568:1: ( rule__TxOperation__Group_1_0_0__0__Impl rule__TxOperation__Group_1_0_0__1 )
            // InternalSM2.g:2569:2: rule__TxOperation__Group_1_0_0__0__Impl rule__TxOperation__Group_1_0_0__1
            {
            pushFollow(FOLLOW_11);
            rule__TxOperation__Group_1_0_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TxOperation__Group_1_0_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_0_0__0"


    // $ANTLR start "rule__TxOperation__Group_1_0_0__0__Impl"
    // InternalSM2.g:2576:1: rule__TxOperation__Group_1_0_0__0__Impl : ( 'gasprice' ) ;
    public final void rule__TxOperation__Group_1_0_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2580:1: ( ( 'gasprice' ) )
            // InternalSM2.g:2581:1: ( 'gasprice' )
            {
            // InternalSM2.g:2581:1: ( 'gasprice' )
            // InternalSM2.g:2582:2: 'gasprice'
            {
             before(grammarAccess.getTxOperationAccess().getGaspriceKeyword_1_0_0_0()); 
            match(input,46,FOLLOW_2); 
             after(grammarAccess.getTxOperationAccess().getGaspriceKeyword_1_0_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_0_0__0__Impl"


    // $ANTLR start "rule__TxOperation__Group_1_0_0__1"
    // InternalSM2.g:2591:1: rule__TxOperation__Group_1_0_0__1 : rule__TxOperation__Group_1_0_0__1__Impl rule__TxOperation__Group_1_0_0__2 ;
    public final void rule__TxOperation__Group_1_0_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2595:1: ( rule__TxOperation__Group_1_0_0__1__Impl rule__TxOperation__Group_1_0_0__2 )
            // InternalSM2.g:2596:2: rule__TxOperation__Group_1_0_0__1__Impl rule__TxOperation__Group_1_0_0__2
            {
            pushFollow(FOLLOW_12);
            rule__TxOperation__Group_1_0_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TxOperation__Group_1_0_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_0_0__1"


    // $ANTLR start "rule__TxOperation__Group_1_0_0__1__Impl"
    // InternalSM2.g:2603:1: rule__TxOperation__Group_1_0_0__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__TxOperation__Group_1_0_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2607:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:2608:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:2608:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:2609:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getTxOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_0_0_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getTxOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_0_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_0_0__1__Impl"


    // $ANTLR start "rule__TxOperation__Group_1_0_0__2"
    // InternalSM2.g:2618:1: rule__TxOperation__Group_1_0_0__2 : rule__TxOperation__Group_1_0_0__2__Impl rule__TxOperation__Group_1_0_0__3 ;
    public final void rule__TxOperation__Group_1_0_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2622:1: ( rule__TxOperation__Group_1_0_0__2__Impl rule__TxOperation__Group_1_0_0__3 )
            // InternalSM2.g:2623:2: rule__TxOperation__Group_1_0_0__2__Impl rule__TxOperation__Group_1_0_0__3
            {
            pushFollow(FOLLOW_13);
            rule__TxOperation__Group_1_0_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TxOperation__Group_1_0_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_0_0__2"


    // $ANTLR start "rule__TxOperation__Group_1_0_0__2__Impl"
    // InternalSM2.g:2630:1: rule__TxOperation__Group_1_0_0__2__Impl : ( ruleExpression ) ;
    public final void rule__TxOperation__Group_1_0_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2634:1: ( ( ruleExpression ) )
            // InternalSM2.g:2635:1: ( ruleExpression )
            {
            // InternalSM2.g:2635:1: ( ruleExpression )
            // InternalSM2.g:2636:2: ruleExpression
            {
             before(grammarAccess.getTxOperationAccess().getExpressionParserRuleCall_1_0_0_2()); 
            pushFollow(FOLLOW_2);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getTxOperationAccess().getExpressionParserRuleCall_1_0_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_0_0__2__Impl"


    // $ANTLR start "rule__TxOperation__Group_1_0_0__3"
    // InternalSM2.g:2645:1: rule__TxOperation__Group_1_0_0__3 : rule__TxOperation__Group_1_0_0__3__Impl ;
    public final void rule__TxOperation__Group_1_0_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2649:1: ( rule__TxOperation__Group_1_0_0__3__Impl )
            // InternalSM2.g:2650:2: rule__TxOperation__Group_1_0_0__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TxOperation__Group_1_0_0__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_0_0__3"


    // $ANTLR start "rule__TxOperation__Group_1_0_0__3__Impl"
    // InternalSM2.g:2656:1: rule__TxOperation__Group_1_0_0__3__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__TxOperation__Group_1_0_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2660:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2661:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2661:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2662:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getTxOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_0_3()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getTxOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_0_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_0_0__3__Impl"


    // $ANTLR start "rule__TxOperation__Group_1_1__0"
    // InternalSM2.g:2672:1: rule__TxOperation__Group_1_1__0 : rule__TxOperation__Group_1_1__0__Impl rule__TxOperation__Group_1_1__1 ;
    public final void rule__TxOperation__Group_1_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2676:1: ( rule__TxOperation__Group_1_1__0__Impl rule__TxOperation__Group_1_1__1 )
            // InternalSM2.g:2677:2: rule__TxOperation__Group_1_1__0__Impl rule__TxOperation__Group_1_1__1
            {
            pushFollow(FOLLOW_13);
            rule__TxOperation__Group_1_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TxOperation__Group_1_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_1__0"


    // $ANTLR start "rule__TxOperation__Group_1_1__0__Impl"
    // InternalSM2.g:2684:1: rule__TxOperation__Group_1_1__0__Impl : ( ( rule__TxOperation__Group_1_1_0__0 ) ) ;
    public final void rule__TxOperation__Group_1_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2688:1: ( ( ( rule__TxOperation__Group_1_1_0__0 ) ) )
            // InternalSM2.g:2689:1: ( ( rule__TxOperation__Group_1_1_0__0 ) )
            {
            // InternalSM2.g:2689:1: ( ( rule__TxOperation__Group_1_1_0__0 ) )
            // InternalSM2.g:2690:2: ( rule__TxOperation__Group_1_1_0__0 )
            {
             before(grammarAccess.getTxOperationAccess().getGroup_1_1_0()); 
            // InternalSM2.g:2691:2: ( rule__TxOperation__Group_1_1_0__0 )
            // InternalSM2.g:2691:3: rule__TxOperation__Group_1_1_0__0
            {
            pushFollow(FOLLOW_2);
            rule__TxOperation__Group_1_1_0__0();

            state._fsp--;


            }

             after(grammarAccess.getTxOperationAccess().getGroup_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_1__0__Impl"


    // $ANTLR start "rule__TxOperation__Group_1_1__1"
    // InternalSM2.g:2699:1: rule__TxOperation__Group_1_1__1 : rule__TxOperation__Group_1_1__1__Impl ;
    public final void rule__TxOperation__Group_1_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2703:1: ( rule__TxOperation__Group_1_1__1__Impl )
            // InternalSM2.g:2704:2: rule__TxOperation__Group_1_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TxOperation__Group_1_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_1__1"


    // $ANTLR start "rule__TxOperation__Group_1_1__1__Impl"
    // InternalSM2.g:2710:1: rule__TxOperation__Group_1_1__1__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__TxOperation__Group_1_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2714:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2715:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2715:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2716:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getTxOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_1()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getTxOperationAccess().getCLOSEPARENTHESISTerminalRuleCall_1_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_1__1__Impl"


    // $ANTLR start "rule__TxOperation__Group_1_1_0__0"
    // InternalSM2.g:2726:1: rule__TxOperation__Group_1_1_0__0 : rule__TxOperation__Group_1_1_0__0__Impl rule__TxOperation__Group_1_1_0__1 ;
    public final void rule__TxOperation__Group_1_1_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2730:1: ( rule__TxOperation__Group_1_1_0__0__Impl rule__TxOperation__Group_1_1_0__1 )
            // InternalSM2.g:2731:2: rule__TxOperation__Group_1_1_0__0__Impl rule__TxOperation__Group_1_1_0__1
            {
            pushFollow(FOLLOW_11);
            rule__TxOperation__Group_1_1_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TxOperation__Group_1_1_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_1_0__0"


    // $ANTLR start "rule__TxOperation__Group_1_1_0__0__Impl"
    // InternalSM2.g:2738:1: rule__TxOperation__Group_1_1_0__0__Impl : ( 'origin' ) ;
    public final void rule__TxOperation__Group_1_1_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2742:1: ( ( 'origin' ) )
            // InternalSM2.g:2743:1: ( 'origin' )
            {
            // InternalSM2.g:2743:1: ( 'origin' )
            // InternalSM2.g:2744:2: 'origin'
            {
             before(grammarAccess.getTxOperationAccess().getOriginKeyword_1_1_0_0()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getTxOperationAccess().getOriginKeyword_1_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_1_0__0__Impl"


    // $ANTLR start "rule__TxOperation__Group_1_1_0__1"
    // InternalSM2.g:2753:1: rule__TxOperation__Group_1_1_0__1 : rule__TxOperation__Group_1_1_0__1__Impl rule__TxOperation__Group_1_1_0__2 ;
    public final void rule__TxOperation__Group_1_1_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2757:1: ( rule__TxOperation__Group_1_1_0__1__Impl rule__TxOperation__Group_1_1_0__2 )
            // InternalSM2.g:2758:2: rule__TxOperation__Group_1_1_0__1__Impl rule__TxOperation__Group_1_1_0__2
            {
            pushFollow(FOLLOW_12);
            rule__TxOperation__Group_1_1_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TxOperation__Group_1_1_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_1_0__1"


    // $ANTLR start "rule__TxOperation__Group_1_1_0__1__Impl"
    // InternalSM2.g:2765:1: rule__TxOperation__Group_1_1_0__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__TxOperation__Group_1_1_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2769:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:2770:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:2770:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:2771:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getTxOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1_0_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getTxOperationAccess().getOPENPARENTHESISTerminalRuleCall_1_1_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_1_0__1__Impl"


    // $ANTLR start "rule__TxOperation__Group_1_1_0__2"
    // InternalSM2.g:2780:1: rule__TxOperation__Group_1_1_0__2 : rule__TxOperation__Group_1_1_0__2__Impl ;
    public final void rule__TxOperation__Group_1_1_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2784:1: ( rule__TxOperation__Group_1_1_0__2__Impl )
            // InternalSM2.g:2785:2: rule__TxOperation__Group_1_1_0__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TxOperation__Group_1_1_0__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_1_0__2"


    // $ANTLR start "rule__TxOperation__Group_1_1_0__2__Impl"
    // InternalSM2.g:2791:1: rule__TxOperation__Group_1_1_0__2__Impl : ( ruleExpression ) ;
    public final void rule__TxOperation__Group_1_1_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2795:1: ( ( ruleExpression ) )
            // InternalSM2.g:2796:1: ( ruleExpression )
            {
            // InternalSM2.g:2796:1: ( ruleExpression )
            // InternalSM2.g:2797:2: ruleExpression
            {
             before(grammarAccess.getTxOperationAccess().getExpressionParserRuleCall_1_1_0_2()); 
            pushFollow(FOLLOW_2);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getTxOperationAccess().getExpressionParserRuleCall_1_1_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_1_1_0__2__Impl"


    // $ANTLR start "rule__TxOperation__Group_2__0"
    // InternalSM2.g:2807:1: rule__TxOperation__Group_2__0 : rule__TxOperation__Group_2__0__Impl rule__TxOperation__Group_2__1 ;
    public final void rule__TxOperation__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2811:1: ( rule__TxOperation__Group_2__0__Impl rule__TxOperation__Group_2__1 )
            // InternalSM2.g:2812:2: rule__TxOperation__Group_2__0__Impl rule__TxOperation__Group_2__1
            {
            pushFollow(FOLLOW_14);
            rule__TxOperation__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TxOperation__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_2__0"


    // $ANTLR start "rule__TxOperation__Group_2__0__Impl"
    // InternalSM2.g:2819:1: rule__TxOperation__Group_2__0__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__TxOperation__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2823:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:2824:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:2824:1: ( RULE_SEMICOLON )
            // InternalSM2.g:2825:2: RULE_SEMICOLON
            {
             before(grammarAccess.getTxOperationAccess().getSEMICOLONTerminalRuleCall_2_0()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getTxOperationAccess().getSEMICOLONTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_2__0__Impl"


    // $ANTLR start "rule__TxOperation__Group_2__1"
    // InternalSM2.g:2834:1: rule__TxOperation__Group_2__1 : rule__TxOperation__Group_2__1__Impl ;
    public final void rule__TxOperation__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2838:1: ( rule__TxOperation__Group_2__1__Impl )
            // InternalSM2.g:2839:2: rule__TxOperation__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TxOperation__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_2__1"


    // $ANTLR start "rule__TxOperation__Group_2__1__Impl"
    // InternalSM2.g:2845:1: rule__TxOperation__Group_2__1__Impl : ( RULE_EOLINE ) ;
    public final void rule__TxOperation__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2849:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:2850:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:2850:1: ( RULE_EOLINE )
            // InternalSM2.g:2851:2: RULE_EOLINE
            {
             before(grammarAccess.getTxOperationAccess().getEOLINETerminalRuleCall_2_1()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getTxOperationAccess().getEOLINETerminalRuleCall_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TxOperation__Group_2__1__Impl"


    // $ANTLR start "rule__Contract__Group__0"
    // InternalSM2.g:2861:1: rule__Contract__Group__0 : rule__Contract__Group__0__Impl rule__Contract__Group__1 ;
    public final void rule__Contract__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2865:1: ( rule__Contract__Group__0__Impl rule__Contract__Group__1 )
            // InternalSM2.g:2866:2: rule__Contract__Group__0__Impl rule__Contract__Group__1
            {
            pushFollow(FOLLOW_16);
            rule__Contract__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Contract__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__0"


    // $ANTLR start "rule__Contract__Group__0__Impl"
    // InternalSM2.g:2873:1: rule__Contract__Group__0__Impl : ( 'contract' ) ;
    public final void rule__Contract__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2877:1: ( ( 'contract' ) )
            // InternalSM2.g:2878:1: ( 'contract' )
            {
            // InternalSM2.g:2878:1: ( 'contract' )
            // InternalSM2.g:2879:2: 'contract'
            {
             before(grammarAccess.getContractAccess().getContractKeyword_0()); 
            match(input,72,FOLLOW_2); 
             after(grammarAccess.getContractAccess().getContractKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__0__Impl"


    // $ANTLR start "rule__Contract__Group__1"
    // InternalSM2.g:2888:1: rule__Contract__Group__1 : rule__Contract__Group__1__Impl rule__Contract__Group__2 ;
    public final void rule__Contract__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2892:1: ( rule__Contract__Group__1__Impl rule__Contract__Group__2 )
            // InternalSM2.g:2893:2: rule__Contract__Group__1__Impl rule__Contract__Group__2
            {
            pushFollow(FOLLOW_17);
            rule__Contract__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Contract__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__1"


    // $ANTLR start "rule__Contract__Group__1__Impl"
    // InternalSM2.g:2900:1: rule__Contract__Group__1__Impl : ( ( rule__Contract__NameContractAssignment_1 ) ) ;
    public final void rule__Contract__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2904:1: ( ( ( rule__Contract__NameContractAssignment_1 ) ) )
            // InternalSM2.g:2905:1: ( ( rule__Contract__NameContractAssignment_1 ) )
            {
            // InternalSM2.g:2905:1: ( ( rule__Contract__NameContractAssignment_1 ) )
            // InternalSM2.g:2906:2: ( rule__Contract__NameContractAssignment_1 )
            {
             before(grammarAccess.getContractAccess().getNameContractAssignment_1()); 
            // InternalSM2.g:2907:2: ( rule__Contract__NameContractAssignment_1 )
            // InternalSM2.g:2907:3: rule__Contract__NameContractAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Contract__NameContractAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getContractAccess().getNameContractAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__1__Impl"


    // $ANTLR start "rule__Contract__Group__2"
    // InternalSM2.g:2915:1: rule__Contract__Group__2 : rule__Contract__Group__2__Impl rule__Contract__Group__3 ;
    public final void rule__Contract__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2919:1: ( rule__Contract__Group__2__Impl rule__Contract__Group__3 )
            // InternalSM2.g:2920:2: rule__Contract__Group__2__Impl rule__Contract__Group__3
            {
            pushFollow(FOLLOW_17);
            rule__Contract__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Contract__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__2"


    // $ANTLR start "rule__Contract__Group__2__Impl"
    // InternalSM2.g:2927:1: rule__Contract__Group__2__Impl : ( ( rule__Contract__Group_2__0 )? ) ;
    public final void rule__Contract__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2931:1: ( ( ( rule__Contract__Group_2__0 )? ) )
            // InternalSM2.g:2932:1: ( ( rule__Contract__Group_2__0 )? )
            {
            // InternalSM2.g:2932:1: ( ( rule__Contract__Group_2__0 )? )
            // InternalSM2.g:2933:2: ( rule__Contract__Group_2__0 )?
            {
             before(grammarAccess.getContractAccess().getGroup_2()); 
            // InternalSM2.g:2934:2: ( rule__Contract__Group_2__0 )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==73) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalSM2.g:2934:3: rule__Contract__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Contract__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getContractAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__2__Impl"


    // $ANTLR start "rule__Contract__Group__3"
    // InternalSM2.g:2942:1: rule__Contract__Group__3 : rule__Contract__Group__3__Impl rule__Contract__Group__4 ;
    public final void rule__Contract__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2946:1: ( rule__Contract__Group__3__Impl rule__Contract__Group__4 )
            // InternalSM2.g:2947:2: rule__Contract__Group__3__Impl rule__Contract__Group__4
            {
            pushFollow(FOLLOW_18);
            rule__Contract__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Contract__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__3"


    // $ANTLR start "rule__Contract__Group__3__Impl"
    // InternalSM2.g:2954:1: rule__Contract__Group__3__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Contract__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2958:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:2959:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:2959:1: ( RULE_OPENKEY )
            // InternalSM2.g:2960:2: RULE_OPENKEY
            {
             before(grammarAccess.getContractAccess().getOPENKEYTerminalRuleCall_3()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getContractAccess().getOPENKEYTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__3__Impl"


    // $ANTLR start "rule__Contract__Group__4"
    // InternalSM2.g:2969:1: rule__Contract__Group__4 : rule__Contract__Group__4__Impl rule__Contract__Group__5 ;
    public final void rule__Contract__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2973:1: ( rule__Contract__Group__4__Impl rule__Contract__Group__5 )
            // InternalSM2.g:2974:2: rule__Contract__Group__4__Impl rule__Contract__Group__5
            {
            pushFollow(FOLLOW_18);
            rule__Contract__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Contract__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__4"


    // $ANTLR start "rule__Contract__Group__4__Impl"
    // InternalSM2.g:2981:1: rule__Contract__Group__4__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Contract__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2985:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2986:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2986:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2987:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getContractAccess().getEOLINETerminalRuleCall_4()); 
            // InternalSM2.g:2988:2: ( RULE_EOLINE )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==RULE_EOLINE) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalSM2.g:2988:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getContractAccess().getEOLINETerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__4__Impl"


    // $ANTLR start "rule__Contract__Group__5"
    // InternalSM2.g:2996:1: rule__Contract__Group__5 : rule__Contract__Group__5__Impl rule__Contract__Group__6 ;
    public final void rule__Contract__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3000:1: ( rule__Contract__Group__5__Impl rule__Contract__Group__6 )
            // InternalSM2.g:3001:2: rule__Contract__Group__5__Impl rule__Contract__Group__6
            {
            pushFollow(FOLLOW_19);
            rule__Contract__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Contract__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__5"


    // $ANTLR start "rule__Contract__Group__5__Impl"
    // InternalSM2.g:3008:1: rule__Contract__Group__5__Impl : ( ( rule__Contract__ConstructorAssignment_5 ) ) ;
    public final void rule__Contract__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3012:1: ( ( ( rule__Contract__ConstructorAssignment_5 ) ) )
            // InternalSM2.g:3013:1: ( ( rule__Contract__ConstructorAssignment_5 ) )
            {
            // InternalSM2.g:3013:1: ( ( rule__Contract__ConstructorAssignment_5 ) )
            // InternalSM2.g:3014:2: ( rule__Contract__ConstructorAssignment_5 )
            {
             before(grammarAccess.getContractAccess().getConstructorAssignment_5()); 
            // InternalSM2.g:3015:2: ( rule__Contract__ConstructorAssignment_5 )
            // InternalSM2.g:3015:3: rule__Contract__ConstructorAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__Contract__ConstructorAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getContractAccess().getConstructorAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__5__Impl"


    // $ANTLR start "rule__Contract__Group__6"
    // InternalSM2.g:3023:1: rule__Contract__Group__6 : rule__Contract__Group__6__Impl rule__Contract__Group__7 ;
    public final void rule__Contract__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3027:1: ( rule__Contract__Group__6__Impl rule__Contract__Group__7 )
            // InternalSM2.g:3028:2: rule__Contract__Group__6__Impl rule__Contract__Group__7
            {
            pushFollow(FOLLOW_19);
            rule__Contract__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Contract__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__6"


    // $ANTLR start "rule__Contract__Group__6__Impl"
    // InternalSM2.g:3035:1: rule__Contract__Group__6__Impl : ( ( rule__Contract__CommentsAssignment_6 )* ) ;
    public final void rule__Contract__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3039:1: ( ( ( rule__Contract__CommentsAssignment_6 )* ) )
            // InternalSM2.g:3040:1: ( ( rule__Contract__CommentsAssignment_6 )* )
            {
            // InternalSM2.g:3040:1: ( ( rule__Contract__CommentsAssignment_6 )* )
            // InternalSM2.g:3041:2: ( rule__Contract__CommentsAssignment_6 )*
            {
             before(grammarAccess.getContractAccess().getCommentsAssignment_6()); 
            // InternalSM2.g:3042:2: ( rule__Contract__CommentsAssignment_6 )*
            loop30:
            do {
                int alt30=2;
                int LA30_0 = input.LA(1);

                if ( ((LA30_0>=91 && LA30_0<=92)) ) {
                    alt30=1;
                }


                switch (alt30) {
            	case 1 :
            	    // InternalSM2.g:3042:3: rule__Contract__CommentsAssignment_6
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__Contract__CommentsAssignment_6();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop30;
                }
            } while (true);

             after(grammarAccess.getContractAccess().getCommentsAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__6__Impl"


    // $ANTLR start "rule__Contract__Group__7"
    // InternalSM2.g:3050:1: rule__Contract__Group__7 : rule__Contract__Group__7__Impl rule__Contract__Group__8 ;
    public final void rule__Contract__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3054:1: ( rule__Contract__Group__7__Impl rule__Contract__Group__8 )
            // InternalSM2.g:3055:2: rule__Contract__Group__7__Impl rule__Contract__Group__8
            {
            pushFollow(FOLLOW_19);
            rule__Contract__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Contract__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__7"


    // $ANTLR start "rule__Contract__Group__7__Impl"
    // InternalSM2.g:3062:1: rule__Contract__Group__7__Impl : ( ( rule__Contract__AttributesAssignment_7 )* ) ;
    public final void rule__Contract__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3066:1: ( ( ( rule__Contract__AttributesAssignment_7 )* ) )
            // InternalSM2.g:3067:1: ( ( rule__Contract__AttributesAssignment_7 )* )
            {
            // InternalSM2.g:3067:1: ( ( rule__Contract__AttributesAssignment_7 )* )
            // InternalSM2.g:3068:2: ( rule__Contract__AttributesAssignment_7 )*
            {
             before(grammarAccess.getContractAccess().getAttributesAssignment_7()); 
            // InternalSM2.g:3069:2: ( rule__Contract__AttributesAssignment_7 )*
            loop31:
            do {
                int alt31=2;
                int LA31_0 = input.LA(1);

                if ( (LA31_0==RULE_ID||LA31_0==80||(LA31_0>=82 && LA31_0<=83)) ) {
                    alt31=1;
                }


                switch (alt31) {
            	case 1 :
            	    // InternalSM2.g:3069:3: rule__Contract__AttributesAssignment_7
            	    {
            	    pushFollow(FOLLOW_5);
            	    rule__Contract__AttributesAssignment_7();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop31;
                }
            } while (true);

             after(grammarAccess.getContractAccess().getAttributesAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__7__Impl"


    // $ANTLR start "rule__Contract__Group__8"
    // InternalSM2.g:3077:1: rule__Contract__Group__8 : rule__Contract__Group__8__Impl rule__Contract__Group__9 ;
    public final void rule__Contract__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3081:1: ( rule__Contract__Group__8__Impl rule__Contract__Group__9 )
            // InternalSM2.g:3082:2: rule__Contract__Group__8__Impl rule__Contract__Group__9
            {
            pushFollow(FOLLOW_19);
            rule__Contract__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Contract__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__8"


    // $ANTLR start "rule__Contract__Group__8__Impl"
    // InternalSM2.g:3089:1: rule__Contract__Group__8__Impl : ( ( rule__Contract__ModifierAssignment_8 )* ) ;
    public final void rule__Contract__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3093:1: ( ( ( rule__Contract__ModifierAssignment_8 )* ) )
            // InternalSM2.g:3094:1: ( ( rule__Contract__ModifierAssignment_8 )* )
            {
            // InternalSM2.g:3094:1: ( ( rule__Contract__ModifierAssignment_8 )* )
            // InternalSM2.g:3095:2: ( rule__Contract__ModifierAssignment_8 )*
            {
             before(grammarAccess.getContractAccess().getModifierAssignment_8()); 
            // InternalSM2.g:3096:2: ( rule__Contract__ModifierAssignment_8 )*
            loop32:
            do {
                int alt32=2;
                int LA32_0 = input.LA(1);

                if ( (LA32_0==78) ) {
                    alt32=1;
                }


                switch (alt32) {
            	case 1 :
            	    // InternalSM2.g:3096:3: rule__Contract__ModifierAssignment_8
            	    {
            	    pushFollow(FOLLOW_20);
            	    rule__Contract__ModifierAssignment_8();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop32;
                }
            } while (true);

             after(grammarAccess.getContractAccess().getModifierAssignment_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__8__Impl"


    // $ANTLR start "rule__Contract__Group__9"
    // InternalSM2.g:3104:1: rule__Contract__Group__9 : rule__Contract__Group__9__Impl rule__Contract__Group__10 ;
    public final void rule__Contract__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3108:1: ( rule__Contract__Group__9__Impl rule__Contract__Group__10 )
            // InternalSM2.g:3109:2: rule__Contract__Group__9__Impl rule__Contract__Group__10
            {
            pushFollow(FOLLOW_19);
            rule__Contract__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Contract__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__9"


    // $ANTLR start "rule__Contract__Group__9__Impl"
    // InternalSM2.g:3116:1: rule__Contract__Group__9__Impl : ( ( rule__Contract__ClausesAssignment_9 )* ) ;
    public final void rule__Contract__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3120:1: ( ( ( rule__Contract__ClausesAssignment_9 )* ) )
            // InternalSM2.g:3121:1: ( ( rule__Contract__ClausesAssignment_9 )* )
            {
            // InternalSM2.g:3121:1: ( ( rule__Contract__ClausesAssignment_9 )* )
            // InternalSM2.g:3122:2: ( rule__Contract__ClausesAssignment_9 )*
            {
             before(grammarAccess.getContractAccess().getClausesAssignment_9()); 
            // InternalSM2.g:3123:2: ( rule__Contract__ClausesAssignment_9 )*
            loop33:
            do {
                int alt33=2;
                int LA33_0 = input.LA(1);

                if ( (LA33_0==86) ) {
                    alt33=1;
                }


                switch (alt33) {
            	case 1 :
            	    // InternalSM2.g:3123:3: rule__Contract__ClausesAssignment_9
            	    {
            	    pushFollow(FOLLOW_21);
            	    rule__Contract__ClausesAssignment_9();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop33;
                }
            } while (true);

             after(grammarAccess.getContractAccess().getClausesAssignment_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__9__Impl"


    // $ANTLR start "rule__Contract__Group__10"
    // InternalSM2.g:3131:1: rule__Contract__Group__10 : rule__Contract__Group__10__Impl ;
    public final void rule__Contract__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3135:1: ( rule__Contract__Group__10__Impl )
            // InternalSM2.g:3136:2: rule__Contract__Group__10__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Contract__Group__10__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__10"


    // $ANTLR start "rule__Contract__Group__10__Impl"
    // InternalSM2.g:3142:1: rule__Contract__Group__10__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Contract__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3146:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:3147:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:3147:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:3148:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getContractAccess().getCLOSEKEYTerminalRuleCall_10()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getContractAccess().getCLOSEKEYTerminalRuleCall_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group__10__Impl"


    // $ANTLR start "rule__Contract__Group_2__0"
    // InternalSM2.g:3158:1: rule__Contract__Group_2__0 : rule__Contract__Group_2__0__Impl rule__Contract__Group_2__1 ;
    public final void rule__Contract__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3162:1: ( rule__Contract__Group_2__0__Impl rule__Contract__Group_2__1 )
            // InternalSM2.g:3163:2: rule__Contract__Group_2__0__Impl rule__Contract__Group_2__1
            {
            pushFollow(FOLLOW_16);
            rule__Contract__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Contract__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group_2__0"


    // $ANTLR start "rule__Contract__Group_2__0__Impl"
    // InternalSM2.g:3170:1: rule__Contract__Group_2__0__Impl : ( 'is' ) ;
    public final void rule__Contract__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3174:1: ( ( 'is' ) )
            // InternalSM2.g:3175:1: ( 'is' )
            {
            // InternalSM2.g:3175:1: ( 'is' )
            // InternalSM2.g:3176:2: 'is'
            {
             before(grammarAccess.getContractAccess().getIsKeyword_2_0()); 
            match(input,73,FOLLOW_2); 
             after(grammarAccess.getContractAccess().getIsKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group_2__0__Impl"


    // $ANTLR start "rule__Contract__Group_2__1"
    // InternalSM2.g:3185:1: rule__Contract__Group_2__1 : rule__Contract__Group_2__1__Impl ;
    public final void rule__Contract__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3189:1: ( rule__Contract__Group_2__1__Impl )
            // InternalSM2.g:3190:2: rule__Contract__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Contract__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group_2__1"


    // $ANTLR start "rule__Contract__Group_2__1__Impl"
    // InternalSM2.g:3196:1: rule__Contract__Group_2__1__Impl : ( ( rule__Contract__NameContractFatherAssignment_2_1 ) ) ;
    public final void rule__Contract__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3200:1: ( ( ( rule__Contract__NameContractFatherAssignment_2_1 ) ) )
            // InternalSM2.g:3201:1: ( ( rule__Contract__NameContractFatherAssignment_2_1 ) )
            {
            // InternalSM2.g:3201:1: ( ( rule__Contract__NameContractFatherAssignment_2_1 ) )
            // InternalSM2.g:3202:2: ( rule__Contract__NameContractFatherAssignment_2_1 )
            {
             before(grammarAccess.getContractAccess().getNameContractFatherAssignment_2_1()); 
            // InternalSM2.g:3203:2: ( rule__Contract__NameContractFatherAssignment_2_1 )
            // InternalSM2.g:3203:3: rule__Contract__NameContractFatherAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Contract__NameContractFatherAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getContractAccess().getNameContractFatherAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__Group_2__1__Impl"


    // $ANTLR start "rule__Version__Group__0"
    // InternalSM2.g:3212:1: rule__Version__Group__0 : rule__Version__Group__0__Impl rule__Version__Group__1 ;
    public final void rule__Version__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3216:1: ( rule__Version__Group__0__Impl rule__Version__Group__1 )
            // InternalSM2.g:3217:2: rule__Version__Group__0__Impl rule__Version__Group__1
            {
            pushFollow(FOLLOW_22);
            rule__Version__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__0"


    // $ANTLR start "rule__Version__Group__0__Impl"
    // InternalSM2.g:3224:1: rule__Version__Group__0__Impl : ( 'pragma' ) ;
    public final void rule__Version__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3228:1: ( ( 'pragma' ) )
            // InternalSM2.g:3229:1: ( 'pragma' )
            {
            // InternalSM2.g:3229:1: ( 'pragma' )
            // InternalSM2.g:3230:2: 'pragma'
            {
             before(grammarAccess.getVersionAccess().getPragmaKeyword_0()); 
            match(input,74,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getPragmaKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__0__Impl"


    // $ANTLR start "rule__Version__Group__1"
    // InternalSM2.g:3239:1: rule__Version__Group__1 : rule__Version__Group__1__Impl rule__Version__Group__2 ;
    public final void rule__Version__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3243:1: ( rule__Version__Group__1__Impl rule__Version__Group__2 )
            // InternalSM2.g:3244:2: rule__Version__Group__1__Impl rule__Version__Group__2
            {
            pushFollow(FOLLOW_23);
            rule__Version__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__1"


    // $ANTLR start "rule__Version__Group__1__Impl"
    // InternalSM2.g:3251:1: rule__Version__Group__1__Impl : ( 'solidity' ) ;
    public final void rule__Version__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3255:1: ( ( 'solidity' ) )
            // InternalSM2.g:3256:1: ( 'solidity' )
            {
            // InternalSM2.g:3256:1: ( 'solidity' )
            // InternalSM2.g:3257:2: 'solidity'
            {
             before(grammarAccess.getVersionAccess().getSolidityKeyword_1()); 
            match(input,75,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getSolidityKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__1__Impl"


    // $ANTLR start "rule__Version__Group__2"
    // InternalSM2.g:3266:1: rule__Version__Group__2 : rule__Version__Group__2__Impl rule__Version__Group__3 ;
    public final void rule__Version__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3270:1: ( rule__Version__Group__2__Impl rule__Version__Group__3 )
            // InternalSM2.g:3271:2: rule__Version__Group__2__Impl rule__Version__Group__3
            {
            pushFollow(FOLLOW_24);
            rule__Version__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__2"


    // $ANTLR start "rule__Version__Group__2__Impl"
    // InternalSM2.g:3278:1: rule__Version__Group__2__Impl : ( ( rule__Version__SymbolAssignment_2 ) ) ;
    public final void rule__Version__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3282:1: ( ( ( rule__Version__SymbolAssignment_2 ) ) )
            // InternalSM2.g:3283:1: ( ( rule__Version__SymbolAssignment_2 ) )
            {
            // InternalSM2.g:3283:1: ( ( rule__Version__SymbolAssignment_2 ) )
            // InternalSM2.g:3284:2: ( rule__Version__SymbolAssignment_2 )
            {
             before(grammarAccess.getVersionAccess().getSymbolAssignment_2()); 
            // InternalSM2.g:3285:2: ( rule__Version__SymbolAssignment_2 )
            // InternalSM2.g:3285:3: rule__Version__SymbolAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getSymbolAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__2__Impl"


    // $ANTLR start "rule__Version__Group__3"
    // InternalSM2.g:3293:1: rule__Version__Group__3 : rule__Version__Group__3__Impl rule__Version__Group__4 ;
    public final void rule__Version__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3297:1: ( rule__Version__Group__3__Impl rule__Version__Group__4 )
            // InternalSM2.g:3298:2: rule__Version__Group__3__Impl rule__Version__Group__4
            {
            pushFollow(FOLLOW_8);
            rule__Version__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__3"


    // $ANTLR start "rule__Version__Group__3__Impl"
    // InternalSM2.g:3305:1: rule__Version__Group__3__Impl : ( ( rule__Version__NumberVersionAssignment_3 ) ) ;
    public final void rule__Version__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3309:1: ( ( ( rule__Version__NumberVersionAssignment_3 ) ) )
            // InternalSM2.g:3310:1: ( ( rule__Version__NumberVersionAssignment_3 ) )
            {
            // InternalSM2.g:3310:1: ( ( rule__Version__NumberVersionAssignment_3 ) )
            // InternalSM2.g:3311:2: ( rule__Version__NumberVersionAssignment_3 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersionAssignment_3()); 
            // InternalSM2.g:3312:2: ( rule__Version__NumberVersionAssignment_3 )
            // InternalSM2.g:3312:3: rule__Version__NumberVersionAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersionAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__3__Impl"


    // $ANTLR start "rule__Version__Group__4"
    // InternalSM2.g:3320:1: rule__Version__Group__4 : rule__Version__Group__4__Impl rule__Version__Group__5 ;
    public final void rule__Version__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3324:1: ( rule__Version__Group__4__Impl rule__Version__Group__5 )
            // InternalSM2.g:3325:2: rule__Version__Group__4__Impl rule__Version__Group__5
            {
            pushFollow(FOLLOW_25);
            rule__Version__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__4"


    // $ANTLR start "rule__Version__Group__4__Impl"
    // InternalSM2.g:3332:1: rule__Version__Group__4__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3336:1: ( ( RULE_DOT ) )
            // InternalSM2.g:3337:1: ( RULE_DOT )
            {
            // InternalSM2.g:3337:1: ( RULE_DOT )
            // InternalSM2.g:3338:2: RULE_DOT
            {
             before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_4()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__4__Impl"


    // $ANTLR start "rule__Version__Group__5"
    // InternalSM2.g:3347:1: rule__Version__Group__5 : rule__Version__Group__5__Impl rule__Version__Group__6 ;
    public final void rule__Version__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3351:1: ( rule__Version__Group__5__Impl rule__Version__Group__6 )
            // InternalSM2.g:3352:2: rule__Version__Group__5__Impl rule__Version__Group__6
            {
            pushFollow(FOLLOW_8);
            rule__Version__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__5"


    // $ANTLR start "rule__Version__Group__5__Impl"
    // InternalSM2.g:3359:1: rule__Version__Group__5__Impl : ( ( rule__Version__NumberVersion2Assignment_5 ) ) ;
    public final void rule__Version__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3363:1: ( ( ( rule__Version__NumberVersion2Assignment_5 ) ) )
            // InternalSM2.g:3364:1: ( ( rule__Version__NumberVersion2Assignment_5 ) )
            {
            // InternalSM2.g:3364:1: ( ( rule__Version__NumberVersion2Assignment_5 ) )
            // InternalSM2.g:3365:2: ( rule__Version__NumberVersion2Assignment_5 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersion2Assignment_5()); 
            // InternalSM2.g:3366:2: ( rule__Version__NumberVersion2Assignment_5 )
            // InternalSM2.g:3366:3: rule__Version__NumberVersion2Assignment_5
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion2Assignment_5();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersion2Assignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__5__Impl"


    // $ANTLR start "rule__Version__Group__6"
    // InternalSM2.g:3374:1: rule__Version__Group__6 : rule__Version__Group__6__Impl rule__Version__Group__7 ;
    public final void rule__Version__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3378:1: ( rule__Version__Group__6__Impl rule__Version__Group__7 )
            // InternalSM2.g:3379:2: rule__Version__Group__6__Impl rule__Version__Group__7
            {
            pushFollow(FOLLOW_26);
            rule__Version__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__6"


    // $ANTLR start "rule__Version__Group__6__Impl"
    // InternalSM2.g:3386:1: rule__Version__Group__6__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3390:1: ( ( RULE_DOT ) )
            // InternalSM2.g:3391:1: ( RULE_DOT )
            {
            // InternalSM2.g:3391:1: ( RULE_DOT )
            // InternalSM2.g:3392:2: RULE_DOT
            {
             before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_6()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__6__Impl"


    // $ANTLR start "rule__Version__Group__7"
    // InternalSM2.g:3401:1: rule__Version__Group__7 : rule__Version__Group__7__Impl rule__Version__Group__8 ;
    public final void rule__Version__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3405:1: ( rule__Version__Group__7__Impl rule__Version__Group__8 )
            // InternalSM2.g:3406:2: rule__Version__Group__7__Impl rule__Version__Group__8
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__7"


    // $ANTLR start "rule__Version__Group__7__Impl"
    // InternalSM2.g:3413:1: rule__Version__Group__7__Impl : ( ( rule__Version__NumberVersion3Assignment_7 ) ) ;
    public final void rule__Version__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3417:1: ( ( ( rule__Version__NumberVersion3Assignment_7 ) ) )
            // InternalSM2.g:3418:1: ( ( rule__Version__NumberVersion3Assignment_7 ) )
            {
            // InternalSM2.g:3418:1: ( ( rule__Version__NumberVersion3Assignment_7 ) )
            // InternalSM2.g:3419:2: ( rule__Version__NumberVersion3Assignment_7 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersion3Assignment_7()); 
            // InternalSM2.g:3420:2: ( rule__Version__NumberVersion3Assignment_7 )
            // InternalSM2.g:3420:3: rule__Version__NumberVersion3Assignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion3Assignment_7();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersion3Assignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__7__Impl"


    // $ANTLR start "rule__Version__Group__8"
    // InternalSM2.g:3428:1: rule__Version__Group__8 : rule__Version__Group__8__Impl ;
    public final void rule__Version__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3432:1: ( rule__Version__Group__8__Impl )
            // InternalSM2.g:3433:2: rule__Version__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__8"


    // $ANTLR start "rule__Version__Group__8__Impl"
    // InternalSM2.g:3439:1: rule__Version__Group__8__Impl : ( ( rule__Version__OptionalversionAssignment_8 )? ) ;
    public final void rule__Version__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3443:1: ( ( ( rule__Version__OptionalversionAssignment_8 )? ) )
            // InternalSM2.g:3444:1: ( ( rule__Version__OptionalversionAssignment_8 )? )
            {
            // InternalSM2.g:3444:1: ( ( rule__Version__OptionalversionAssignment_8 )? )
            // InternalSM2.g:3445:2: ( rule__Version__OptionalversionAssignment_8 )?
            {
             before(grammarAccess.getVersionAccess().getOptionalversionAssignment_8()); 
            // InternalSM2.g:3446:2: ( rule__Version__OptionalversionAssignment_8 )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==RULE_ID) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalSM2.g:3446:3: rule__Version__OptionalversionAssignment_8
                    {
                    pushFollow(FOLLOW_2);
                    rule__Version__OptionalversionAssignment_8();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getVersionAccess().getOptionalversionAssignment_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__8__Impl"


    // $ANTLR start "rule__Constructor__Group__0"
    // InternalSM2.g:3455:1: rule__Constructor__Group__0 : rule__Constructor__Group__0__Impl rule__Constructor__Group__1 ;
    public final void rule__Constructor__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3459:1: ( rule__Constructor__Group__0__Impl rule__Constructor__Group__1 )
            // InternalSM2.g:3460:2: rule__Constructor__Group__0__Impl rule__Constructor__Group__1
            {
            pushFollow(FOLLOW_11);
            rule__Constructor__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Constructor__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__0"


    // $ANTLR start "rule__Constructor__Group__0__Impl"
    // InternalSM2.g:3467:1: rule__Constructor__Group__0__Impl : ( 'constructor' ) ;
    public final void rule__Constructor__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3471:1: ( ( 'constructor' ) )
            // InternalSM2.g:3472:1: ( 'constructor' )
            {
            // InternalSM2.g:3472:1: ( 'constructor' )
            // InternalSM2.g:3473:2: 'constructor'
            {
             before(grammarAccess.getConstructorAccess().getConstructorKeyword_0()); 
            match(input,76,FOLLOW_2); 
             after(grammarAccess.getConstructorAccess().getConstructorKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__0__Impl"


    // $ANTLR start "rule__Constructor__Group__1"
    // InternalSM2.g:3482:1: rule__Constructor__Group__1 : rule__Constructor__Group__1__Impl rule__Constructor__Group__2 ;
    public final void rule__Constructor__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3486:1: ( rule__Constructor__Group__1__Impl rule__Constructor__Group__2 )
            // InternalSM2.g:3487:2: rule__Constructor__Group__1__Impl rule__Constructor__Group__2
            {
            pushFollow(FOLLOW_27);
            rule__Constructor__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Constructor__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__1"


    // $ANTLR start "rule__Constructor__Group__1__Impl"
    // InternalSM2.g:3494:1: rule__Constructor__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Constructor__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3498:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:3499:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:3499:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:3500:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getConstructorAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getConstructorAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__1__Impl"


    // $ANTLR start "rule__Constructor__Group__2"
    // InternalSM2.g:3509:1: rule__Constructor__Group__2 : rule__Constructor__Group__2__Impl rule__Constructor__Group__3 ;
    public final void rule__Constructor__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3513:1: ( rule__Constructor__Group__2__Impl rule__Constructor__Group__3 )
            // InternalSM2.g:3514:2: rule__Constructor__Group__2__Impl rule__Constructor__Group__3
            {
            pushFollow(FOLLOW_27);
            rule__Constructor__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Constructor__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__2"


    // $ANTLR start "rule__Constructor__Group__2__Impl"
    // InternalSM2.g:3521:1: rule__Constructor__Group__2__Impl : ( ( rule__Constructor__InputParamsAssignment_2 )* ) ;
    public final void rule__Constructor__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3525:1: ( ( ( rule__Constructor__InputParamsAssignment_2 )* ) )
            // InternalSM2.g:3526:1: ( ( rule__Constructor__InputParamsAssignment_2 )* )
            {
            // InternalSM2.g:3526:1: ( ( rule__Constructor__InputParamsAssignment_2 )* )
            // InternalSM2.g:3527:2: ( rule__Constructor__InputParamsAssignment_2 )*
            {
             before(grammarAccess.getConstructorAccess().getInputParamsAssignment_2()); 
            // InternalSM2.g:3528:2: ( rule__Constructor__InputParamsAssignment_2 )*
            loop35:
            do {
                int alt35=2;
                int LA35_0 = input.LA(1);

                if ( ((LA35_0>=94 && LA35_0<=101)) ) {
                    alt35=1;
                }


                switch (alt35) {
            	case 1 :
            	    // InternalSM2.g:3528:3: rule__Constructor__InputParamsAssignment_2
            	    {
            	    pushFollow(FOLLOW_28);
            	    rule__Constructor__InputParamsAssignment_2();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop35;
                }
            } while (true);

             after(grammarAccess.getConstructorAccess().getInputParamsAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__2__Impl"


    // $ANTLR start "rule__Constructor__Group__3"
    // InternalSM2.g:3536:1: rule__Constructor__Group__3 : rule__Constructor__Group__3__Impl rule__Constructor__Group__4 ;
    public final void rule__Constructor__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3540:1: ( rule__Constructor__Group__3__Impl rule__Constructor__Group__4 )
            // InternalSM2.g:3541:2: rule__Constructor__Group__3__Impl rule__Constructor__Group__4
            {
            pushFollow(FOLLOW_13);
            rule__Constructor__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Constructor__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__3"


    // $ANTLR start "rule__Constructor__Group__3__Impl"
    // InternalSM2.g:3548:1: rule__Constructor__Group__3__Impl : ( ( rule__Constructor__TypeAssignment_3 ) ) ;
    public final void rule__Constructor__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3552:1: ( ( ( rule__Constructor__TypeAssignment_3 ) ) )
            // InternalSM2.g:3553:1: ( ( rule__Constructor__TypeAssignment_3 ) )
            {
            // InternalSM2.g:3553:1: ( ( rule__Constructor__TypeAssignment_3 ) )
            // InternalSM2.g:3554:2: ( rule__Constructor__TypeAssignment_3 )
            {
             before(grammarAccess.getConstructorAccess().getTypeAssignment_3()); 
            // InternalSM2.g:3555:2: ( rule__Constructor__TypeAssignment_3 )
            // InternalSM2.g:3555:3: rule__Constructor__TypeAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Constructor__TypeAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getConstructorAccess().getTypeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__3__Impl"


    // $ANTLR start "rule__Constructor__Group__4"
    // InternalSM2.g:3563:1: rule__Constructor__Group__4 : rule__Constructor__Group__4__Impl rule__Constructor__Group__5 ;
    public final void rule__Constructor__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3567:1: ( rule__Constructor__Group__4__Impl rule__Constructor__Group__5 )
            // InternalSM2.g:3568:2: rule__Constructor__Group__4__Impl rule__Constructor__Group__5
            {
            pushFollow(FOLLOW_29);
            rule__Constructor__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Constructor__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__4"


    // $ANTLR start "rule__Constructor__Group__4__Impl"
    // InternalSM2.g:3575:1: rule__Constructor__Group__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Constructor__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3579:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:3580:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:3580:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:3581:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getConstructorAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getConstructorAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__4__Impl"


    // $ANTLR start "rule__Constructor__Group__5"
    // InternalSM2.g:3590:1: rule__Constructor__Group__5 : rule__Constructor__Group__5__Impl rule__Constructor__Group__6 ;
    public final void rule__Constructor__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3594:1: ( rule__Constructor__Group__5__Impl rule__Constructor__Group__6 )
            // InternalSM2.g:3595:2: rule__Constructor__Group__5__Impl rule__Constructor__Group__6
            {
            pushFollow(FOLLOW_30);
            rule__Constructor__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Constructor__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__5"


    // $ANTLR start "rule__Constructor__Group__5__Impl"
    // InternalSM2.g:3602:1: rule__Constructor__Group__5__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Constructor__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3606:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:3607:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:3607:1: ( RULE_OPENKEY )
            // InternalSM2.g:3608:2: RULE_OPENKEY
            {
             before(grammarAccess.getConstructorAccess().getOPENKEYTerminalRuleCall_5()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getConstructorAccess().getOPENKEYTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__5__Impl"


    // $ANTLR start "rule__Constructor__Group__6"
    // InternalSM2.g:3617:1: rule__Constructor__Group__6 : rule__Constructor__Group__6__Impl rule__Constructor__Group__7 ;
    public final void rule__Constructor__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3621:1: ( rule__Constructor__Group__6__Impl rule__Constructor__Group__7 )
            // InternalSM2.g:3622:2: rule__Constructor__Group__6__Impl rule__Constructor__Group__7
            {
            pushFollow(FOLLOW_31);
            rule__Constructor__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Constructor__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__6"


    // $ANTLR start "rule__Constructor__Group__6__Impl"
    // InternalSM2.g:3629:1: rule__Constructor__Group__6__Impl : ( ( rule__Constructor__AttributesAssignment_6 ) ) ;
    public final void rule__Constructor__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3633:1: ( ( ( rule__Constructor__AttributesAssignment_6 ) ) )
            // InternalSM2.g:3634:1: ( ( rule__Constructor__AttributesAssignment_6 ) )
            {
            // InternalSM2.g:3634:1: ( ( rule__Constructor__AttributesAssignment_6 ) )
            // InternalSM2.g:3635:2: ( rule__Constructor__AttributesAssignment_6 )
            {
             before(grammarAccess.getConstructorAccess().getAttributesAssignment_6()); 
            // InternalSM2.g:3636:2: ( rule__Constructor__AttributesAssignment_6 )
            // InternalSM2.g:3636:3: rule__Constructor__AttributesAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__Constructor__AttributesAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getConstructorAccess().getAttributesAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__6__Impl"


    // $ANTLR start "rule__Constructor__Group__7"
    // InternalSM2.g:3644:1: rule__Constructor__Group__7 : rule__Constructor__Group__7__Impl ;
    public final void rule__Constructor__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3648:1: ( rule__Constructor__Group__7__Impl )
            // InternalSM2.g:3649:2: rule__Constructor__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Constructor__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__7"


    // $ANTLR start "rule__Constructor__Group__7__Impl"
    // InternalSM2.g:3655:1: rule__Constructor__Group__7__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Constructor__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3659:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:3660:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:3660:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:3661:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getConstructorAccess().getCLOSEKEYTerminalRuleCall_7()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getConstructorAccess().getCLOSEKEYTerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__7__Impl"


    // $ANTLR start "rule__Import__Group__0"
    // InternalSM2.g:3671:1: rule__Import__Group__0 : rule__Import__Group__0__Impl rule__Import__Group__1 ;
    public final void rule__Import__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3675:1: ( rule__Import__Group__0__Impl rule__Import__Group__1 )
            // InternalSM2.g:3676:2: rule__Import__Group__0__Impl rule__Import__Group__1
            {
            pushFollow(FOLLOW_32);
            rule__Import__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0"


    // $ANTLR start "rule__Import__Group__0__Impl"
    // InternalSM2.g:3683:1: rule__Import__Group__0__Impl : ( 'import' ) ;
    public final void rule__Import__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3687:1: ( ( 'import' ) )
            // InternalSM2.g:3688:1: ( 'import' )
            {
            // InternalSM2.g:3688:1: ( 'import' )
            // InternalSM2.g:3689:2: 'import'
            {
             before(grammarAccess.getImportAccess().getImportKeyword_0()); 
            match(input,77,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getImportKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0__Impl"


    // $ANTLR start "rule__Import__Group__1"
    // InternalSM2.g:3698:1: rule__Import__Group__1 : rule__Import__Group__1__Impl rule__Import__Group__2 ;
    public final void rule__Import__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3702:1: ( rule__Import__Group__1__Impl rule__Import__Group__2 )
            // InternalSM2.g:3703:2: rule__Import__Group__1__Impl rule__Import__Group__2
            {
            pushFollow(FOLLOW_10);
            rule__Import__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1"


    // $ANTLR start "rule__Import__Group__1__Impl"
    // InternalSM2.g:3710:1: rule__Import__Group__1__Impl : ( RULE_STRING ) ;
    public final void rule__Import__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3714:1: ( ( RULE_STRING ) )
            // InternalSM2.g:3715:1: ( RULE_STRING )
            {
            // InternalSM2.g:3715:1: ( RULE_STRING )
            // InternalSM2.g:3716:2: RULE_STRING
            {
             before(grammarAccess.getImportAccess().getSTRINGTerminalRuleCall_1()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getSTRINGTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1__Impl"


    // $ANTLR start "rule__Import__Group__2"
    // InternalSM2.g:3725:1: rule__Import__Group__2 : rule__Import__Group__2__Impl rule__Import__Group__3 ;
    public final void rule__Import__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3729:1: ( rule__Import__Group__2__Impl rule__Import__Group__3 )
            // InternalSM2.g:3730:2: rule__Import__Group__2__Impl rule__Import__Group__3
            {
            pushFollow(FOLLOW_14);
            rule__Import__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__2"


    // $ANTLR start "rule__Import__Group__2__Impl"
    // InternalSM2.g:3737:1: rule__Import__Group__2__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Import__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3741:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3742:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3742:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3743:2: RULE_SEMICOLON
            {
             before(grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_2()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__2__Impl"


    // $ANTLR start "rule__Import__Group__3"
    // InternalSM2.g:3752:1: rule__Import__Group__3 : rule__Import__Group__3__Impl ;
    public final void rule__Import__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3756:1: ( rule__Import__Group__3__Impl )
            // InternalSM2.g:3757:2: rule__Import__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__3"


    // $ANTLR start "rule__Import__Group__3__Impl"
    // InternalSM2.g:3763:1: rule__Import__Group__3__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Import__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3767:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3768:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3768:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3769:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getImportAccess().getEOLINETerminalRuleCall_3()); 
            // InternalSM2.g:3770:2: ( RULE_EOLINE )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==RULE_EOLINE) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalSM2.g:3770:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getImportAccess().getEOLINETerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__3__Impl"


    // $ANTLR start "rule__Modifier__Group__0"
    // InternalSM2.g:3779:1: rule__Modifier__Group__0 : rule__Modifier__Group__0__Impl rule__Modifier__Group__1 ;
    public final void rule__Modifier__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3783:1: ( rule__Modifier__Group__0__Impl rule__Modifier__Group__1 )
            // InternalSM2.g:3784:2: rule__Modifier__Group__0__Impl rule__Modifier__Group__1
            {
            pushFollow(FOLLOW_16);
            rule__Modifier__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__0"


    // $ANTLR start "rule__Modifier__Group__0__Impl"
    // InternalSM2.g:3791:1: rule__Modifier__Group__0__Impl : ( 'modifier' ) ;
    public final void rule__Modifier__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3795:1: ( ( 'modifier' ) )
            // InternalSM2.g:3796:1: ( 'modifier' )
            {
            // InternalSM2.g:3796:1: ( 'modifier' )
            // InternalSM2.g:3797:2: 'modifier'
            {
             before(grammarAccess.getModifierAccess().getModifierKeyword_0()); 
            match(input,78,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getModifierKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__0__Impl"


    // $ANTLR start "rule__Modifier__Group__1"
    // InternalSM2.g:3806:1: rule__Modifier__Group__1 : rule__Modifier__Group__1__Impl rule__Modifier__Group__2 ;
    public final void rule__Modifier__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3810:1: ( rule__Modifier__Group__1__Impl rule__Modifier__Group__2 )
            // InternalSM2.g:3811:2: rule__Modifier__Group__1__Impl rule__Modifier__Group__2
            {
            pushFollow(FOLLOW_11);
            rule__Modifier__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__1"


    // $ANTLR start "rule__Modifier__Group__1__Impl"
    // InternalSM2.g:3818:1: rule__Modifier__Group__1__Impl : ( ( rule__Modifier__NameModifierAssignment_1 ) ) ;
    public final void rule__Modifier__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3822:1: ( ( ( rule__Modifier__NameModifierAssignment_1 ) ) )
            // InternalSM2.g:3823:1: ( ( rule__Modifier__NameModifierAssignment_1 ) )
            {
            // InternalSM2.g:3823:1: ( ( rule__Modifier__NameModifierAssignment_1 ) )
            // InternalSM2.g:3824:2: ( rule__Modifier__NameModifierAssignment_1 )
            {
             before(grammarAccess.getModifierAccess().getNameModifierAssignment_1()); 
            // InternalSM2.g:3825:2: ( rule__Modifier__NameModifierAssignment_1 )
            // InternalSM2.g:3825:3: rule__Modifier__NameModifierAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__NameModifierAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getModifierAccess().getNameModifierAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__1__Impl"


    // $ANTLR start "rule__Modifier__Group__2"
    // InternalSM2.g:3833:1: rule__Modifier__Group__2 : rule__Modifier__Group__2__Impl rule__Modifier__Group__3 ;
    public final void rule__Modifier__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3837:1: ( rule__Modifier__Group__2__Impl rule__Modifier__Group__3 )
            // InternalSM2.g:3838:2: rule__Modifier__Group__2__Impl rule__Modifier__Group__3
            {
            pushFollow(FOLLOW_33);
            rule__Modifier__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__2"


    // $ANTLR start "rule__Modifier__Group__2__Impl"
    // InternalSM2.g:3845:1: rule__Modifier__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Modifier__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3849:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:3850:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:3850:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:3851:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__2__Impl"


    // $ANTLR start "rule__Modifier__Group__3"
    // InternalSM2.g:3860:1: rule__Modifier__Group__3 : rule__Modifier__Group__3__Impl rule__Modifier__Group__4 ;
    public final void rule__Modifier__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3864:1: ( rule__Modifier__Group__3__Impl rule__Modifier__Group__4 )
            // InternalSM2.g:3865:2: rule__Modifier__Group__3__Impl rule__Modifier__Group__4
            {
            pushFollow(FOLLOW_33);
            rule__Modifier__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__3"


    // $ANTLR start "rule__Modifier__Group__3__Impl"
    // InternalSM2.g:3872:1: rule__Modifier__Group__3__Impl : ( ( rule__Modifier__InputParamsAssignment_3 )* ) ;
    public final void rule__Modifier__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3876:1: ( ( ( rule__Modifier__InputParamsAssignment_3 )* ) )
            // InternalSM2.g:3877:1: ( ( rule__Modifier__InputParamsAssignment_3 )* )
            {
            // InternalSM2.g:3877:1: ( ( rule__Modifier__InputParamsAssignment_3 )* )
            // InternalSM2.g:3878:2: ( rule__Modifier__InputParamsAssignment_3 )*
            {
             before(grammarAccess.getModifierAccess().getInputParamsAssignment_3()); 
            // InternalSM2.g:3879:2: ( rule__Modifier__InputParamsAssignment_3 )*
            loop37:
            do {
                int alt37=2;
                int LA37_0 = input.LA(1);

                if ( ((LA37_0>=94 && LA37_0<=101)) ) {
                    alt37=1;
                }


                switch (alt37) {
            	case 1 :
            	    // InternalSM2.g:3879:3: rule__Modifier__InputParamsAssignment_3
            	    {
            	    pushFollow(FOLLOW_28);
            	    rule__Modifier__InputParamsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop37;
                }
            } while (true);

             after(grammarAccess.getModifierAccess().getInputParamsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__3__Impl"


    // $ANTLR start "rule__Modifier__Group__4"
    // InternalSM2.g:3887:1: rule__Modifier__Group__4 : rule__Modifier__Group__4__Impl rule__Modifier__Group__5 ;
    public final void rule__Modifier__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3891:1: ( rule__Modifier__Group__4__Impl rule__Modifier__Group__5 )
            // InternalSM2.g:3892:2: rule__Modifier__Group__4__Impl rule__Modifier__Group__5
            {
            pushFollow(FOLLOW_29);
            rule__Modifier__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__4"


    // $ANTLR start "rule__Modifier__Group__4__Impl"
    // InternalSM2.g:3899:1: rule__Modifier__Group__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Modifier__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3903:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:3904:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:3904:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:3905:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__4__Impl"


    // $ANTLR start "rule__Modifier__Group__5"
    // InternalSM2.g:3914:1: rule__Modifier__Group__5 : rule__Modifier__Group__5__Impl rule__Modifier__Group__6 ;
    public final void rule__Modifier__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3918:1: ( rule__Modifier__Group__5__Impl rule__Modifier__Group__6 )
            // InternalSM2.g:3919:2: rule__Modifier__Group__5__Impl rule__Modifier__Group__6
            {
            pushFollow(FOLLOW_34);
            rule__Modifier__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__5"


    // $ANTLR start "rule__Modifier__Group__5__Impl"
    // InternalSM2.g:3926:1: rule__Modifier__Group__5__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Modifier__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3930:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:3931:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:3931:1: ( RULE_OPENKEY )
            // InternalSM2.g:3932:2: RULE_OPENKEY
            {
             before(grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__5__Impl"


    // $ANTLR start "rule__Modifier__Group__6"
    // InternalSM2.g:3941:1: rule__Modifier__Group__6 : rule__Modifier__Group__6__Impl rule__Modifier__Group__7 ;
    public final void rule__Modifier__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3945:1: ( rule__Modifier__Group__6__Impl rule__Modifier__Group__7 )
            // InternalSM2.g:3946:2: rule__Modifier__Group__6__Impl rule__Modifier__Group__7
            {
            pushFollow(FOLLOW_34);
            rule__Modifier__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__6"


    // $ANTLR start "rule__Modifier__Group__6__Impl"
    // InternalSM2.g:3953:1: rule__Modifier__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3957:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3958:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3958:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3959:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6()); 
            // InternalSM2.g:3960:2: ( RULE_EOLINE )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==RULE_EOLINE) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:3960:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__6__Impl"


    // $ANTLR start "rule__Modifier__Group__7"
    // InternalSM2.g:3968:1: rule__Modifier__Group__7 : rule__Modifier__Group__7__Impl rule__Modifier__Group__8 ;
    public final void rule__Modifier__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3972:1: ( rule__Modifier__Group__7__Impl rule__Modifier__Group__8 )
            // InternalSM2.g:3973:2: rule__Modifier__Group__7__Impl rule__Modifier__Group__8
            {
            pushFollow(FOLLOW_10);
            rule__Modifier__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__7"


    // $ANTLR start "rule__Modifier__Group__7__Impl"
    // InternalSM2.g:3980:1: rule__Modifier__Group__7__Impl : ( ( rule__Modifier__ExprAssignment_7 ) ) ;
    public final void rule__Modifier__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3984:1: ( ( ( rule__Modifier__ExprAssignment_7 ) ) )
            // InternalSM2.g:3985:1: ( ( rule__Modifier__ExprAssignment_7 ) )
            {
            // InternalSM2.g:3985:1: ( ( rule__Modifier__ExprAssignment_7 ) )
            // InternalSM2.g:3986:2: ( rule__Modifier__ExprAssignment_7 )
            {
             before(grammarAccess.getModifierAccess().getExprAssignment_7()); 
            // InternalSM2.g:3987:2: ( rule__Modifier__ExprAssignment_7 )
            // InternalSM2.g:3987:3: rule__Modifier__ExprAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__ExprAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getModifierAccess().getExprAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__7__Impl"


    // $ANTLR start "rule__Modifier__Group__8"
    // InternalSM2.g:3995:1: rule__Modifier__Group__8 : rule__Modifier__Group__8__Impl rule__Modifier__Group__9 ;
    public final void rule__Modifier__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3999:1: ( rule__Modifier__Group__8__Impl rule__Modifier__Group__9 )
            // InternalSM2.g:4000:2: rule__Modifier__Group__8__Impl rule__Modifier__Group__9
            {
            pushFollow(FOLLOW_35);
            rule__Modifier__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__8"


    // $ANTLR start "rule__Modifier__Group__8__Impl"
    // InternalSM2.g:4007:1: rule__Modifier__Group__8__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Modifier__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4011:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4012:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4012:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4013:2: RULE_SEMICOLON
            {
             before(grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__8__Impl"


    // $ANTLR start "rule__Modifier__Group__9"
    // InternalSM2.g:4022:1: rule__Modifier__Group__9 : rule__Modifier__Group__9__Impl rule__Modifier__Group__10 ;
    public final void rule__Modifier__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4026:1: ( rule__Modifier__Group__9__Impl rule__Modifier__Group__10 )
            // InternalSM2.g:4027:2: rule__Modifier__Group__9__Impl rule__Modifier__Group__10
            {
            pushFollow(FOLLOW_35);
            rule__Modifier__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__9"


    // $ANTLR start "rule__Modifier__Group__9__Impl"
    // InternalSM2.g:4034:1: rule__Modifier__Group__9__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4038:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4039:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4039:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4040:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9()); 
            // InternalSM2.g:4041:2: ( RULE_EOLINE )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==RULE_EOLINE) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalSM2.g:4041:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__9__Impl"


    // $ANTLR start "rule__Modifier__Group__10"
    // InternalSM2.g:4049:1: rule__Modifier__Group__10 : rule__Modifier__Group__10__Impl rule__Modifier__Group__11 ;
    public final void rule__Modifier__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4053:1: ( rule__Modifier__Group__10__Impl rule__Modifier__Group__11 )
            // InternalSM2.g:4054:2: rule__Modifier__Group__10__Impl rule__Modifier__Group__11
            {
            pushFollow(FOLLOW_31);
            rule__Modifier__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__10"


    // $ANTLR start "rule__Modifier__Group__10__Impl"
    // InternalSM2.g:4061:1: rule__Modifier__Group__10__Impl : ( '_;' ) ;
    public final void rule__Modifier__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4065:1: ( ( '_;' ) )
            // InternalSM2.g:4066:1: ( '_;' )
            {
            // InternalSM2.g:4066:1: ( '_;' )
            // InternalSM2.g:4067:2: '_;'
            {
             before(grammarAccess.getModifierAccess().get_Keyword_10()); 
            match(input,79,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().get_Keyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__10__Impl"


    // $ANTLR start "rule__Modifier__Group__11"
    // InternalSM2.g:4076:1: rule__Modifier__Group__11 : rule__Modifier__Group__11__Impl rule__Modifier__Group__12 ;
    public final void rule__Modifier__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4080:1: ( rule__Modifier__Group__11__Impl rule__Modifier__Group__12 )
            // InternalSM2.g:4081:2: rule__Modifier__Group__11__Impl rule__Modifier__Group__12
            {
            pushFollow(FOLLOW_14);
            rule__Modifier__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__11"


    // $ANTLR start "rule__Modifier__Group__11__Impl"
    // InternalSM2.g:4088:1: rule__Modifier__Group__11__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Modifier__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4092:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:4093:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:4093:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:4094:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__11__Impl"


    // $ANTLR start "rule__Modifier__Group__12"
    // InternalSM2.g:4103:1: rule__Modifier__Group__12 : rule__Modifier__Group__12__Impl ;
    public final void rule__Modifier__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4107:1: ( rule__Modifier__Group__12__Impl )
            // InternalSM2.g:4108:2: rule__Modifier__Group__12__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__12__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__12"


    // $ANTLR start "rule__Modifier__Group__12__Impl"
    // InternalSM2.g:4114:1: rule__Modifier__Group__12__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4118:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4119:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4119:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4120:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12()); 
            // InternalSM2.g:4121:2: ( RULE_EOLINE )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==RULE_EOLINE) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalSM2.g:4121:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__12__Impl"


    // $ANTLR start "rule__Mapping__Group__0"
    // InternalSM2.g:4130:1: rule__Mapping__Group__0 : rule__Mapping__Group__0__Impl rule__Mapping__Group__1 ;
    public final void rule__Mapping__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4134:1: ( rule__Mapping__Group__0__Impl rule__Mapping__Group__1 )
            // InternalSM2.g:4135:2: rule__Mapping__Group__0__Impl rule__Mapping__Group__1
            {
            pushFollow(FOLLOW_11);
            rule__Mapping__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__0"


    // $ANTLR start "rule__Mapping__Group__0__Impl"
    // InternalSM2.g:4142:1: rule__Mapping__Group__0__Impl : ( 'mapping' ) ;
    public final void rule__Mapping__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4146:1: ( ( 'mapping' ) )
            // InternalSM2.g:4147:1: ( 'mapping' )
            {
            // InternalSM2.g:4147:1: ( 'mapping' )
            // InternalSM2.g:4148:2: 'mapping'
            {
             before(grammarAccess.getMappingAccess().getMappingKeyword_0()); 
            match(input,80,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getMappingKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__0__Impl"


    // $ANTLR start "rule__Mapping__Group__1"
    // InternalSM2.g:4157:1: rule__Mapping__Group__1 : rule__Mapping__Group__1__Impl rule__Mapping__Group__2 ;
    public final void rule__Mapping__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4161:1: ( rule__Mapping__Group__1__Impl rule__Mapping__Group__2 )
            // InternalSM2.g:4162:2: rule__Mapping__Group__1__Impl rule__Mapping__Group__2
            {
            pushFollow(FOLLOW_36);
            rule__Mapping__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__1"


    // $ANTLR start "rule__Mapping__Group__1__Impl"
    // InternalSM2.g:4169:1: rule__Mapping__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Mapping__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4173:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:4174:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:4174:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:4175:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__1__Impl"


    // $ANTLR start "rule__Mapping__Group__2"
    // InternalSM2.g:4184:1: rule__Mapping__Group__2 : rule__Mapping__Group__2__Impl rule__Mapping__Group__3 ;
    public final void rule__Mapping__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4188:1: ( rule__Mapping__Group__2__Impl rule__Mapping__Group__3 )
            // InternalSM2.g:4189:2: rule__Mapping__Group__2__Impl rule__Mapping__Group__3
            {
            pushFollow(FOLLOW_37);
            rule__Mapping__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__2"


    // $ANTLR start "rule__Mapping__Group__2__Impl"
    // InternalSM2.g:4196:1: rule__Mapping__Group__2__Impl : ( ( rule__Mapping__TypeAssignment_2 ) ) ;
    public final void rule__Mapping__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4200:1: ( ( ( rule__Mapping__TypeAssignment_2 ) ) )
            // InternalSM2.g:4201:1: ( ( rule__Mapping__TypeAssignment_2 ) )
            {
            // InternalSM2.g:4201:1: ( ( rule__Mapping__TypeAssignment_2 ) )
            // InternalSM2.g:4202:2: ( rule__Mapping__TypeAssignment_2 )
            {
             before(grammarAccess.getMappingAccess().getTypeAssignment_2()); 
            // InternalSM2.g:4203:2: ( rule__Mapping__TypeAssignment_2 )
            // InternalSM2.g:4203:3: rule__Mapping__TypeAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__TypeAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getTypeAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__2__Impl"


    // $ANTLR start "rule__Mapping__Group__3"
    // InternalSM2.g:4211:1: rule__Mapping__Group__3 : rule__Mapping__Group__3__Impl rule__Mapping__Group__4 ;
    public final void rule__Mapping__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4215:1: ( rule__Mapping__Group__3__Impl rule__Mapping__Group__4 )
            // InternalSM2.g:4216:2: rule__Mapping__Group__3__Impl rule__Mapping__Group__4
            {
            pushFollow(FOLLOW_32);
            rule__Mapping__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__3"


    // $ANTLR start "rule__Mapping__Group__3__Impl"
    // InternalSM2.g:4223:1: rule__Mapping__Group__3__Impl : ( '=>' ) ;
    public final void rule__Mapping__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4227:1: ( ( '=>' ) )
            // InternalSM2.g:4228:1: ( '=>' )
            {
            // InternalSM2.g:4228:1: ( '=>' )
            // InternalSM2.g:4229:2: '=>'
            {
             before(grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3()); 
            match(input,81,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__3__Impl"


    // $ANTLR start "rule__Mapping__Group__4"
    // InternalSM2.g:4238:1: rule__Mapping__Group__4 : rule__Mapping__Group__4__Impl rule__Mapping__Group__5 ;
    public final void rule__Mapping__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4242:1: ( rule__Mapping__Group__4__Impl rule__Mapping__Group__5 )
            // InternalSM2.g:4243:2: rule__Mapping__Group__4__Impl rule__Mapping__Group__5
            {
            pushFollow(FOLLOW_13);
            rule__Mapping__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__4"


    // $ANTLR start "rule__Mapping__Group__4__Impl"
    // InternalSM2.g:4250:1: rule__Mapping__Group__4__Impl : ( ( rule__Mapping__ExprAssignment_4 ) ) ;
    public final void rule__Mapping__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4254:1: ( ( ( rule__Mapping__ExprAssignment_4 ) ) )
            // InternalSM2.g:4255:1: ( ( rule__Mapping__ExprAssignment_4 ) )
            {
            // InternalSM2.g:4255:1: ( ( rule__Mapping__ExprAssignment_4 ) )
            // InternalSM2.g:4256:2: ( rule__Mapping__ExprAssignment_4 )
            {
             before(grammarAccess.getMappingAccess().getExprAssignment_4()); 
            // InternalSM2.g:4257:2: ( rule__Mapping__ExprAssignment_4 )
            // InternalSM2.g:4257:3: rule__Mapping__ExprAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__ExprAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getExprAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__4__Impl"


    // $ANTLR start "rule__Mapping__Group__5"
    // InternalSM2.g:4265:1: rule__Mapping__Group__5 : rule__Mapping__Group__5__Impl rule__Mapping__Group__6 ;
    public final void rule__Mapping__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4269:1: ( rule__Mapping__Group__5__Impl rule__Mapping__Group__6 )
            // InternalSM2.g:4270:2: rule__Mapping__Group__5__Impl rule__Mapping__Group__6
            {
            pushFollow(FOLLOW_38);
            rule__Mapping__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__5"


    // $ANTLR start "rule__Mapping__Group__5__Impl"
    // InternalSM2.g:4277:1: rule__Mapping__Group__5__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Mapping__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4281:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:4282:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:4282:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:4283:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__5__Impl"


    // $ANTLR start "rule__Mapping__Group__6"
    // InternalSM2.g:4292:1: rule__Mapping__Group__6 : rule__Mapping__Group__6__Impl rule__Mapping__Group__7 ;
    public final void rule__Mapping__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4296:1: ( rule__Mapping__Group__6__Impl rule__Mapping__Group__7 )
            // InternalSM2.g:4297:2: rule__Mapping__Group__6__Impl rule__Mapping__Group__7
            {
            pushFollow(FOLLOW_38);
            rule__Mapping__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__6"


    // $ANTLR start "rule__Mapping__Group__6__Impl"
    // InternalSM2.g:4304:1: rule__Mapping__Group__6__Impl : ( ( rule__Mapping__VisibilityAssignment_6 )? ) ;
    public final void rule__Mapping__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4308:1: ( ( ( rule__Mapping__VisibilityAssignment_6 )? ) )
            // InternalSM2.g:4309:1: ( ( rule__Mapping__VisibilityAssignment_6 )? )
            {
            // InternalSM2.g:4309:1: ( ( rule__Mapping__VisibilityAssignment_6 )? )
            // InternalSM2.g:4310:2: ( rule__Mapping__VisibilityAssignment_6 )?
            {
             before(grammarAccess.getMappingAccess().getVisibilityAssignment_6()); 
            // InternalSM2.g:4311:2: ( rule__Mapping__VisibilityAssignment_6 )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( ((LA41_0>=50 && LA41_0<=52)) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalSM2.g:4311:3: rule__Mapping__VisibilityAssignment_6
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mapping__VisibilityAssignment_6();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMappingAccess().getVisibilityAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__6__Impl"


    // $ANTLR start "rule__Mapping__Group__7"
    // InternalSM2.g:4319:1: rule__Mapping__Group__7 : rule__Mapping__Group__7__Impl rule__Mapping__Group__8 ;
    public final void rule__Mapping__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4323:1: ( rule__Mapping__Group__7__Impl rule__Mapping__Group__8 )
            // InternalSM2.g:4324:2: rule__Mapping__Group__7__Impl rule__Mapping__Group__8
            {
            pushFollow(FOLLOW_10);
            rule__Mapping__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__7"


    // $ANTLR start "rule__Mapping__Group__7__Impl"
    // InternalSM2.g:4331:1: rule__Mapping__Group__7__Impl : ( ( rule__Mapping__NameMappingAssignment_7 ) ) ;
    public final void rule__Mapping__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4335:1: ( ( ( rule__Mapping__NameMappingAssignment_7 ) ) )
            // InternalSM2.g:4336:1: ( ( rule__Mapping__NameMappingAssignment_7 ) )
            {
            // InternalSM2.g:4336:1: ( ( rule__Mapping__NameMappingAssignment_7 ) )
            // InternalSM2.g:4337:2: ( rule__Mapping__NameMappingAssignment_7 )
            {
             before(grammarAccess.getMappingAccess().getNameMappingAssignment_7()); 
            // InternalSM2.g:4338:2: ( rule__Mapping__NameMappingAssignment_7 )
            // InternalSM2.g:4338:3: rule__Mapping__NameMappingAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__NameMappingAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getNameMappingAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__7__Impl"


    // $ANTLR start "rule__Mapping__Group__8"
    // InternalSM2.g:4346:1: rule__Mapping__Group__8 : rule__Mapping__Group__8__Impl ;
    public final void rule__Mapping__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4350:1: ( rule__Mapping__Group__8__Impl )
            // InternalSM2.g:4351:2: rule__Mapping__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__8"


    // $ANTLR start "rule__Mapping__Group__8__Impl"
    // InternalSM2.g:4357:1: rule__Mapping__Group__8__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Mapping__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4361:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4362:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4362:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4363:2: RULE_SEMICOLON
            {
             before(grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__8__Impl"


    // $ANTLR start "rule__Struct__Group__0"
    // InternalSM2.g:4373:1: rule__Struct__Group__0 : rule__Struct__Group__0__Impl rule__Struct__Group__1 ;
    public final void rule__Struct__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4377:1: ( rule__Struct__Group__0__Impl rule__Struct__Group__1 )
            // InternalSM2.g:4378:2: rule__Struct__Group__0__Impl rule__Struct__Group__1
            {
            pushFollow(FOLLOW_16);
            rule__Struct__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__0"


    // $ANTLR start "rule__Struct__Group__0__Impl"
    // InternalSM2.g:4385:1: rule__Struct__Group__0__Impl : ( 'struct' ) ;
    public final void rule__Struct__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4389:1: ( ( 'struct' ) )
            // InternalSM2.g:4390:1: ( 'struct' )
            {
            // InternalSM2.g:4390:1: ( 'struct' )
            // InternalSM2.g:4391:2: 'struct'
            {
             before(grammarAccess.getStructAccess().getStructKeyword_0()); 
            match(input,82,FOLLOW_2); 
             after(grammarAccess.getStructAccess().getStructKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__0__Impl"


    // $ANTLR start "rule__Struct__Group__1"
    // InternalSM2.g:4400:1: rule__Struct__Group__1 : rule__Struct__Group__1__Impl rule__Struct__Group__2 ;
    public final void rule__Struct__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4404:1: ( rule__Struct__Group__1__Impl rule__Struct__Group__2 )
            // InternalSM2.g:4405:2: rule__Struct__Group__1__Impl rule__Struct__Group__2
            {
            pushFollow(FOLLOW_29);
            rule__Struct__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__1"


    // $ANTLR start "rule__Struct__Group__1__Impl"
    // InternalSM2.g:4412:1: rule__Struct__Group__1__Impl : ( ( rule__Struct__NameStructAssignment_1 ) ) ;
    public final void rule__Struct__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4416:1: ( ( ( rule__Struct__NameStructAssignment_1 ) ) )
            // InternalSM2.g:4417:1: ( ( rule__Struct__NameStructAssignment_1 ) )
            {
            // InternalSM2.g:4417:1: ( ( rule__Struct__NameStructAssignment_1 ) )
            // InternalSM2.g:4418:2: ( rule__Struct__NameStructAssignment_1 )
            {
             before(grammarAccess.getStructAccess().getNameStructAssignment_1()); 
            // InternalSM2.g:4419:2: ( rule__Struct__NameStructAssignment_1 )
            // InternalSM2.g:4419:3: rule__Struct__NameStructAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Struct__NameStructAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getStructAccess().getNameStructAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__1__Impl"


    // $ANTLR start "rule__Struct__Group__2"
    // InternalSM2.g:4427:1: rule__Struct__Group__2 : rule__Struct__Group__2__Impl rule__Struct__Group__3 ;
    public final void rule__Struct__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4431:1: ( rule__Struct__Group__2__Impl rule__Struct__Group__3 )
            // InternalSM2.g:4432:2: rule__Struct__Group__2__Impl rule__Struct__Group__3
            {
            pushFollow(FOLLOW_39);
            rule__Struct__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__2"


    // $ANTLR start "rule__Struct__Group__2__Impl"
    // InternalSM2.g:4439:1: rule__Struct__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Struct__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4443:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:4444:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:4444:1: ( RULE_OPENKEY )
            // InternalSM2.g:4445:2: RULE_OPENKEY
            {
             before(grammarAccess.getStructAccess().getOPENKEYTerminalRuleCall_2()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getStructAccess().getOPENKEYTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__2__Impl"


    // $ANTLR start "rule__Struct__Group__3"
    // InternalSM2.g:4454:1: rule__Struct__Group__3 : rule__Struct__Group__3__Impl rule__Struct__Group__4 ;
    public final void rule__Struct__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4458:1: ( rule__Struct__Group__3__Impl rule__Struct__Group__4 )
            // InternalSM2.g:4459:2: rule__Struct__Group__3__Impl rule__Struct__Group__4
            {
            pushFollow(FOLLOW_39);
            rule__Struct__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__3"


    // $ANTLR start "rule__Struct__Group__3__Impl"
    // InternalSM2.g:4466:1: rule__Struct__Group__3__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Struct__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4470:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4471:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4471:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4472:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getStructAccess().getEOLINETerminalRuleCall_3()); 
            // InternalSM2.g:4473:2: ( RULE_EOLINE )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==RULE_EOLINE) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalSM2.g:4473:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getStructAccess().getEOLINETerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__3__Impl"


    // $ANTLR start "rule__Struct__Group__4"
    // InternalSM2.g:4481:1: rule__Struct__Group__4 : rule__Struct__Group__4__Impl rule__Struct__Group__5 ;
    public final void rule__Struct__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4485:1: ( rule__Struct__Group__4__Impl rule__Struct__Group__5 )
            // InternalSM2.g:4486:2: rule__Struct__Group__4__Impl rule__Struct__Group__5
            {
            pushFollow(FOLLOW_31);
            rule__Struct__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__4"


    // $ANTLR start "rule__Struct__Group__4__Impl"
    // InternalSM2.g:4493:1: rule__Struct__Group__4__Impl : ( ( rule__Struct__PropertiesAssignment_4 ) ) ;
    public final void rule__Struct__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4497:1: ( ( ( rule__Struct__PropertiesAssignment_4 ) ) )
            // InternalSM2.g:4498:1: ( ( rule__Struct__PropertiesAssignment_4 ) )
            {
            // InternalSM2.g:4498:1: ( ( rule__Struct__PropertiesAssignment_4 ) )
            // InternalSM2.g:4499:2: ( rule__Struct__PropertiesAssignment_4 )
            {
             before(grammarAccess.getStructAccess().getPropertiesAssignment_4()); 
            // InternalSM2.g:4500:2: ( rule__Struct__PropertiesAssignment_4 )
            // InternalSM2.g:4500:3: rule__Struct__PropertiesAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Struct__PropertiesAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getStructAccess().getPropertiesAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__4__Impl"


    // $ANTLR start "rule__Struct__Group__5"
    // InternalSM2.g:4508:1: rule__Struct__Group__5 : rule__Struct__Group__5__Impl rule__Struct__Group__6 ;
    public final void rule__Struct__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4512:1: ( rule__Struct__Group__5__Impl rule__Struct__Group__6 )
            // InternalSM2.g:4513:2: rule__Struct__Group__5__Impl rule__Struct__Group__6
            {
            pushFollow(FOLLOW_14);
            rule__Struct__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__5"


    // $ANTLR start "rule__Struct__Group__5__Impl"
    // InternalSM2.g:4520:1: rule__Struct__Group__5__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Struct__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4524:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:4525:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:4525:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:4526:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getStructAccess().getCLOSEKEYTerminalRuleCall_5()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getStructAccess().getCLOSEKEYTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__5__Impl"


    // $ANTLR start "rule__Struct__Group__6"
    // InternalSM2.g:4535:1: rule__Struct__Group__6 : rule__Struct__Group__6__Impl ;
    public final void rule__Struct__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4539:1: ( rule__Struct__Group__6__Impl )
            // InternalSM2.g:4540:2: rule__Struct__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Struct__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__6"


    // $ANTLR start "rule__Struct__Group__6__Impl"
    // InternalSM2.g:4546:1: rule__Struct__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Struct__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4550:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4551:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4551:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4552:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getStructAccess().getEOLINETerminalRuleCall_6()); 
            // InternalSM2.g:4553:2: ( RULE_EOLINE )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==RULE_EOLINE) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalSM2.g:4553:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getStructAccess().getEOLINETerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__6__Impl"


    // $ANTLR start "rule__Enum__Group__0"
    // InternalSM2.g:4562:1: rule__Enum__Group__0 : rule__Enum__Group__0__Impl rule__Enum__Group__1 ;
    public final void rule__Enum__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4566:1: ( rule__Enum__Group__0__Impl rule__Enum__Group__1 )
            // InternalSM2.g:4567:2: rule__Enum__Group__0__Impl rule__Enum__Group__1
            {
            pushFollow(FOLLOW_16);
            rule__Enum__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__0"


    // $ANTLR start "rule__Enum__Group__0__Impl"
    // InternalSM2.g:4574:1: rule__Enum__Group__0__Impl : ( 'enum' ) ;
    public final void rule__Enum__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4578:1: ( ( 'enum' ) )
            // InternalSM2.g:4579:1: ( 'enum' )
            {
            // InternalSM2.g:4579:1: ( 'enum' )
            // InternalSM2.g:4580:2: 'enum'
            {
             before(grammarAccess.getEnumAccess().getEnumKeyword_0()); 
            match(input,83,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getEnumKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__0__Impl"


    // $ANTLR start "rule__Enum__Group__1"
    // InternalSM2.g:4589:1: rule__Enum__Group__1 : rule__Enum__Group__1__Impl rule__Enum__Group__2 ;
    public final void rule__Enum__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4593:1: ( rule__Enum__Group__1__Impl rule__Enum__Group__2 )
            // InternalSM2.g:4594:2: rule__Enum__Group__1__Impl rule__Enum__Group__2
            {
            pushFollow(FOLLOW_29);
            rule__Enum__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__1"


    // $ANTLR start "rule__Enum__Group__1__Impl"
    // InternalSM2.g:4601:1: rule__Enum__Group__1__Impl : ( RULE_ID ) ;
    public final void rule__Enum__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4605:1: ( ( RULE_ID ) )
            // InternalSM2.g:4606:1: ( RULE_ID )
            {
            // InternalSM2.g:4606:1: ( RULE_ID )
            // InternalSM2.g:4607:2: RULE_ID
            {
             before(grammarAccess.getEnumAccess().getIDTerminalRuleCall_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getIDTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__1__Impl"


    // $ANTLR start "rule__Enum__Group__2"
    // InternalSM2.g:4616:1: rule__Enum__Group__2 : rule__Enum__Group__2__Impl rule__Enum__Group__3 ;
    public final void rule__Enum__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4620:1: ( rule__Enum__Group__2__Impl rule__Enum__Group__3 )
            // InternalSM2.g:4621:2: rule__Enum__Group__2__Impl rule__Enum__Group__3
            {
            pushFollow(FOLLOW_32);
            rule__Enum__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__2"


    // $ANTLR start "rule__Enum__Group__2__Impl"
    // InternalSM2.g:4628:1: rule__Enum__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Enum__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4632:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:4633:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:4633:1: ( RULE_OPENKEY )
            // InternalSM2.g:4634:2: RULE_OPENKEY
            {
             before(grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__2__Impl"


    // $ANTLR start "rule__Enum__Group__3"
    // InternalSM2.g:4643:1: rule__Enum__Group__3 : rule__Enum__Group__3__Impl rule__Enum__Group__4 ;
    public final void rule__Enum__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4647:1: ( rule__Enum__Group__3__Impl rule__Enum__Group__4 )
            // InternalSM2.g:4648:2: rule__Enum__Group__3__Impl rule__Enum__Group__4
            {
            pushFollow(FOLLOW_40);
            rule__Enum__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__3"


    // $ANTLR start "rule__Enum__Group__3__Impl"
    // InternalSM2.g:4655:1: rule__Enum__Group__3__Impl : ( RULE_STRING ) ;
    public final void rule__Enum__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4659:1: ( ( RULE_STRING ) )
            // InternalSM2.g:4660:1: ( RULE_STRING )
            {
            // InternalSM2.g:4660:1: ( RULE_STRING )
            // InternalSM2.g:4661:2: RULE_STRING
            {
             before(grammarAccess.getEnumAccess().getSTRINGTerminalRuleCall_3()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getSTRINGTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__3__Impl"


    // $ANTLR start "rule__Enum__Group__4"
    // InternalSM2.g:4670:1: rule__Enum__Group__4 : rule__Enum__Group__4__Impl rule__Enum__Group__5 ;
    public final void rule__Enum__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4674:1: ( rule__Enum__Group__4__Impl rule__Enum__Group__5 )
            // InternalSM2.g:4675:2: rule__Enum__Group__4__Impl rule__Enum__Group__5
            {
            pushFollow(FOLLOW_40);
            rule__Enum__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__4"


    // $ANTLR start "rule__Enum__Group__4__Impl"
    // InternalSM2.g:4682:1: rule__Enum__Group__4__Impl : ( ( RULE_COMMA )? ) ;
    public final void rule__Enum__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4686:1: ( ( ( RULE_COMMA )? ) )
            // InternalSM2.g:4687:1: ( ( RULE_COMMA )? )
            {
            // InternalSM2.g:4687:1: ( ( RULE_COMMA )? )
            // InternalSM2.g:4688:2: ( RULE_COMMA )?
            {
             before(grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_4()); 
            // InternalSM2.g:4689:2: ( RULE_COMMA )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==RULE_COMMA) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:4689:3: RULE_COMMA
                    {
                    match(input,RULE_COMMA,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__4__Impl"


    // $ANTLR start "rule__Enum__Group__5"
    // InternalSM2.g:4697:1: rule__Enum__Group__5 : rule__Enum__Group__5__Impl rule__Enum__Group__6 ;
    public final void rule__Enum__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4701:1: ( rule__Enum__Group__5__Impl rule__Enum__Group__6 )
            // InternalSM2.g:4702:2: rule__Enum__Group__5__Impl rule__Enum__Group__6
            {
            pushFollow(FOLLOW_10);
            rule__Enum__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__5"


    // $ANTLR start "rule__Enum__Group__5__Impl"
    // InternalSM2.g:4709:1: rule__Enum__Group__5__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Enum__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4713:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:4714:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:4714:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:4715:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_5()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__5__Impl"


    // $ANTLR start "rule__Enum__Group__6"
    // InternalSM2.g:4724:1: rule__Enum__Group__6 : rule__Enum__Group__6__Impl rule__Enum__Group__7 ;
    public final void rule__Enum__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4728:1: ( rule__Enum__Group__6__Impl rule__Enum__Group__7 )
            // InternalSM2.g:4729:2: rule__Enum__Group__6__Impl rule__Enum__Group__7
            {
            pushFollow(FOLLOW_14);
            rule__Enum__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__6"


    // $ANTLR start "rule__Enum__Group__6__Impl"
    // InternalSM2.g:4736:1: rule__Enum__Group__6__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Enum__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4740:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4741:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4741:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4742:2: RULE_SEMICOLON
            {
             before(grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_6()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__6__Impl"


    // $ANTLR start "rule__Enum__Group__7"
    // InternalSM2.g:4751:1: rule__Enum__Group__7 : rule__Enum__Group__7__Impl ;
    public final void rule__Enum__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4755:1: ( rule__Enum__Group__7__Impl )
            // InternalSM2.g:4756:2: rule__Enum__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Enum__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__7"


    // $ANTLR start "rule__Enum__Group__7__Impl"
    // InternalSM2.g:4762:1: rule__Enum__Group__7__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Enum__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4766:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4767:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4767:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4768:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_7()); 
            // InternalSM2.g:4769:2: ( RULE_EOLINE )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==RULE_EOLINE) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalSM2.g:4769:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__7__Impl"


    // $ANTLR start "rule__Property__Group__0"
    // InternalSM2.g:4778:1: rule__Property__Group__0 : rule__Property__Group__0__Impl rule__Property__Group__1 ;
    public final void rule__Property__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4782:1: ( rule__Property__Group__0__Impl rule__Property__Group__1 )
            // InternalSM2.g:4783:2: rule__Property__Group__0__Impl rule__Property__Group__1
            {
            pushFollow(FOLLOW_38);
            rule__Property__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__0"


    // $ANTLR start "rule__Property__Group__0__Impl"
    // InternalSM2.g:4790:1: rule__Property__Group__0__Impl : ( ( rule__Property__TypeAssignment_0 ) ) ;
    public final void rule__Property__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4794:1: ( ( ( rule__Property__TypeAssignment_0 ) ) )
            // InternalSM2.g:4795:1: ( ( rule__Property__TypeAssignment_0 ) )
            {
            // InternalSM2.g:4795:1: ( ( rule__Property__TypeAssignment_0 ) )
            // InternalSM2.g:4796:2: ( rule__Property__TypeAssignment_0 )
            {
             before(grammarAccess.getPropertyAccess().getTypeAssignment_0()); 
            // InternalSM2.g:4797:2: ( rule__Property__TypeAssignment_0 )
            // InternalSM2.g:4797:3: rule__Property__TypeAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Property__TypeAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getPropertyAccess().getTypeAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__0__Impl"


    // $ANTLR start "rule__Property__Group__1"
    // InternalSM2.g:4805:1: rule__Property__Group__1 : rule__Property__Group__1__Impl rule__Property__Group__2 ;
    public final void rule__Property__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4809:1: ( rule__Property__Group__1__Impl rule__Property__Group__2 )
            // InternalSM2.g:4810:2: rule__Property__Group__1__Impl rule__Property__Group__2
            {
            pushFollow(FOLLOW_38);
            rule__Property__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__1"


    // $ANTLR start "rule__Property__Group__1__Impl"
    // InternalSM2.g:4817:1: rule__Property__Group__1__Impl : ( ( rule__Property__VisibilityAssignment_1 )? ) ;
    public final void rule__Property__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4821:1: ( ( ( rule__Property__VisibilityAssignment_1 )? ) )
            // InternalSM2.g:4822:1: ( ( rule__Property__VisibilityAssignment_1 )? )
            {
            // InternalSM2.g:4822:1: ( ( rule__Property__VisibilityAssignment_1 )? )
            // InternalSM2.g:4823:2: ( rule__Property__VisibilityAssignment_1 )?
            {
             before(grammarAccess.getPropertyAccess().getVisibilityAssignment_1()); 
            // InternalSM2.g:4824:2: ( rule__Property__VisibilityAssignment_1 )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( ((LA46_0>=50 && LA46_0<=52)) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:4824:3: rule__Property__VisibilityAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__VisibilityAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPropertyAccess().getVisibilityAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__1__Impl"


    // $ANTLR start "rule__Property__Group__2"
    // InternalSM2.g:4832:1: rule__Property__Group__2 : rule__Property__Group__2__Impl rule__Property__Group__3 ;
    public final void rule__Property__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4836:1: ( rule__Property__Group__2__Impl rule__Property__Group__3 )
            // InternalSM2.g:4837:2: rule__Property__Group__2__Impl rule__Property__Group__3
            {
            pushFollow(FOLLOW_41);
            rule__Property__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__2"


    // $ANTLR start "rule__Property__Group__2__Impl"
    // InternalSM2.g:4844:1: rule__Property__Group__2__Impl : ( ( rule__Property__NamePropertyAssignment_2 ) ) ;
    public final void rule__Property__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4848:1: ( ( ( rule__Property__NamePropertyAssignment_2 ) ) )
            // InternalSM2.g:4849:1: ( ( rule__Property__NamePropertyAssignment_2 ) )
            {
            // InternalSM2.g:4849:1: ( ( rule__Property__NamePropertyAssignment_2 ) )
            // InternalSM2.g:4850:2: ( rule__Property__NamePropertyAssignment_2 )
            {
             before(grammarAccess.getPropertyAccess().getNamePropertyAssignment_2()); 
            // InternalSM2.g:4851:2: ( rule__Property__NamePropertyAssignment_2 )
            // InternalSM2.g:4851:3: rule__Property__NamePropertyAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Property__NamePropertyAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getPropertyAccess().getNamePropertyAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__2__Impl"


    // $ANTLR start "rule__Property__Group__3"
    // InternalSM2.g:4859:1: rule__Property__Group__3 : rule__Property__Group__3__Impl rule__Property__Group__4 ;
    public final void rule__Property__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4863:1: ( rule__Property__Group__3__Impl rule__Property__Group__4 )
            // InternalSM2.g:4864:2: rule__Property__Group__3__Impl rule__Property__Group__4
            {
            pushFollow(FOLLOW_42);
            rule__Property__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__3"


    // $ANTLR start "rule__Property__Group__3__Impl"
    // InternalSM2.g:4871:1: rule__Property__Group__3__Impl : ( '=' ) ;
    public final void rule__Property__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4875:1: ( ( '=' ) )
            // InternalSM2.g:4876:1: ( '=' )
            {
            // InternalSM2.g:4876:1: ( '=' )
            // InternalSM2.g:4877:2: '='
            {
             before(grammarAccess.getPropertyAccess().getEqualsSignKeyword_3()); 
            match(input,84,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getEqualsSignKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__3__Impl"


    // $ANTLR start "rule__Property__Group__4"
    // InternalSM2.g:4886:1: rule__Property__Group__4 : rule__Property__Group__4__Impl rule__Property__Group__5 ;
    public final void rule__Property__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4890:1: ( rule__Property__Group__4__Impl rule__Property__Group__5 )
            // InternalSM2.g:4891:2: rule__Property__Group__4__Impl rule__Property__Group__5
            {
            pushFollow(FOLLOW_42);
            rule__Property__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__4"


    // $ANTLR start "rule__Property__Group__4__Impl"
    // InternalSM2.g:4898:1: rule__Property__Group__4__Impl : ( ( rule__Property__Alternatives_4 )? ) ;
    public final void rule__Property__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4902:1: ( ( ( rule__Property__Alternatives_4 )? ) )
            // InternalSM2.g:4903:1: ( ( rule__Property__Alternatives_4 )? )
            {
            // InternalSM2.g:4903:1: ( ( rule__Property__Alternatives_4 )? )
            // InternalSM2.g:4904:2: ( rule__Property__Alternatives_4 )?
            {
             before(grammarAccess.getPropertyAccess().getAlternatives_4()); 
            // InternalSM2.g:4905:2: ( rule__Property__Alternatives_4 )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==RULE_INT||LA47_0==RULE_STRING) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalSM2.g:4905:3: rule__Property__Alternatives_4
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__Alternatives_4();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPropertyAccess().getAlternatives_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__4__Impl"


    // $ANTLR start "rule__Property__Group__5"
    // InternalSM2.g:4913:1: rule__Property__Group__5 : rule__Property__Group__5__Impl rule__Property__Group__6 ;
    public final void rule__Property__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4917:1: ( rule__Property__Group__5__Impl rule__Property__Group__6 )
            // InternalSM2.g:4918:2: rule__Property__Group__5__Impl rule__Property__Group__6
            {
            pushFollow(FOLLOW_14);
            rule__Property__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__5"


    // $ANTLR start "rule__Property__Group__5__Impl"
    // InternalSM2.g:4925:1: rule__Property__Group__5__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Property__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4929:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4930:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4930:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4931:2: RULE_SEMICOLON
            {
             before(grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_5()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__5__Impl"


    // $ANTLR start "rule__Property__Group__6"
    // InternalSM2.g:4940:1: rule__Property__Group__6 : rule__Property__Group__6__Impl ;
    public final void rule__Property__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4944:1: ( rule__Property__Group__6__Impl )
            // InternalSM2.g:4945:2: rule__Property__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Property__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__6"


    // $ANTLR start "rule__Property__Group__6__Impl"
    // InternalSM2.g:4951:1: rule__Property__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Property__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4955:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4956:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4956:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4957:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6()); 
            // InternalSM2.g:4958:2: ( RULE_EOLINE )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==RULE_EOLINE) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalSM2.g:4958:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__6__Impl"


    // $ANTLR start "rule__InputParam__Group__0"
    // InternalSM2.g:4967:1: rule__InputParam__Group__0 : rule__InputParam__Group__0__Impl rule__InputParam__Group__1 ;
    public final void rule__InputParam__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4971:1: ( rule__InputParam__Group__0__Impl rule__InputParam__Group__1 )
            // InternalSM2.g:4972:2: rule__InputParam__Group__0__Impl rule__InputParam__Group__1
            {
            pushFollow(FOLLOW_16);
            rule__InputParam__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InputParam__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__0"


    // $ANTLR start "rule__InputParam__Group__0__Impl"
    // InternalSM2.g:4979:1: rule__InputParam__Group__0__Impl : ( ruleSingularType ) ;
    public final void rule__InputParam__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4983:1: ( ( ruleSingularType ) )
            // InternalSM2.g:4984:1: ( ruleSingularType )
            {
            // InternalSM2.g:4984:1: ( ruleSingularType )
            // InternalSM2.g:4985:2: ruleSingularType
            {
             before(grammarAccess.getInputParamAccess().getSingularTypeParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;

             after(grammarAccess.getInputParamAccess().getSingularTypeParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__0__Impl"


    // $ANTLR start "rule__InputParam__Group__1"
    // InternalSM2.g:4994:1: rule__InputParam__Group__1 : rule__InputParam__Group__1__Impl rule__InputParam__Group__2 ;
    public final void rule__InputParam__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4998:1: ( rule__InputParam__Group__1__Impl rule__InputParam__Group__2 )
            // InternalSM2.g:4999:2: rule__InputParam__Group__1__Impl rule__InputParam__Group__2
            {
            pushFollow(FOLLOW_43);
            rule__InputParam__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InputParam__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__1"


    // $ANTLR start "rule__InputParam__Group__1__Impl"
    // InternalSM2.g:5006:1: rule__InputParam__Group__1__Impl : ( ( rule__InputParam__NameParamAssignment_1 ) ) ;
    public final void rule__InputParam__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5010:1: ( ( ( rule__InputParam__NameParamAssignment_1 ) ) )
            // InternalSM2.g:5011:1: ( ( rule__InputParam__NameParamAssignment_1 ) )
            {
            // InternalSM2.g:5011:1: ( ( rule__InputParam__NameParamAssignment_1 ) )
            // InternalSM2.g:5012:2: ( rule__InputParam__NameParamAssignment_1 )
            {
             before(grammarAccess.getInputParamAccess().getNameParamAssignment_1()); 
            // InternalSM2.g:5013:2: ( rule__InputParam__NameParamAssignment_1 )
            // InternalSM2.g:5013:3: rule__InputParam__NameParamAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__NameParamAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getInputParamAccess().getNameParamAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__1__Impl"


    // $ANTLR start "rule__InputParam__Group__2"
    // InternalSM2.g:5021:1: rule__InputParam__Group__2 : rule__InputParam__Group__2__Impl ;
    public final void rule__InputParam__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5025:1: ( rule__InputParam__Group__2__Impl )
            // InternalSM2.g:5026:2: rule__InputParam__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__2"


    // $ANTLR start "rule__InputParam__Group__2__Impl"
    // InternalSM2.g:5032:1: rule__InputParam__Group__2__Impl : ( ( RULE_COMMA )? ) ;
    public final void rule__InputParam__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5036:1: ( ( ( RULE_COMMA )? ) )
            // InternalSM2.g:5037:1: ( ( RULE_COMMA )? )
            {
            // InternalSM2.g:5037:1: ( ( RULE_COMMA )? )
            // InternalSM2.g:5038:2: ( RULE_COMMA )?
            {
             before(grammarAccess.getInputParamAccess().getCOMMATerminalRuleCall_2()); 
            // InternalSM2.g:5039:2: ( RULE_COMMA )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==RULE_COMMA) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // InternalSM2.g:5039:3: RULE_COMMA
                    {
                    match(input,RULE_COMMA,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getInputParamAccess().getCOMMATerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__2__Impl"


    // $ANTLR start "rule__Restriction__Group__0"
    // InternalSM2.g:5048:1: rule__Restriction__Group__0 : rule__Restriction__Group__0__Impl rule__Restriction__Group__1 ;
    public final void rule__Restriction__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5052:1: ( rule__Restriction__Group__0__Impl rule__Restriction__Group__1 )
            // InternalSM2.g:5053:2: rule__Restriction__Group__0__Impl rule__Restriction__Group__1
            {
            pushFollow(FOLLOW_11);
            rule__Restriction__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__0"


    // $ANTLR start "rule__Restriction__Group__0__Impl"
    // InternalSM2.g:5060:1: rule__Restriction__Group__0__Impl : ( 'require' ) ;
    public final void rule__Restriction__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5064:1: ( ( 'require' ) )
            // InternalSM2.g:5065:1: ( 'require' )
            {
            // InternalSM2.g:5065:1: ( 'require' )
            // InternalSM2.g:5066:2: 'require'
            {
             before(grammarAccess.getRestrictionAccess().getRequireKeyword_0()); 
            match(input,85,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getRequireKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__0__Impl"


    // $ANTLR start "rule__Restriction__Group__1"
    // InternalSM2.g:5075:1: rule__Restriction__Group__1 : rule__Restriction__Group__1__Impl rule__Restriction__Group__2 ;
    public final void rule__Restriction__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5079:1: ( rule__Restriction__Group__1__Impl rule__Restriction__Group__2 )
            // InternalSM2.g:5080:2: rule__Restriction__Group__1__Impl rule__Restriction__Group__2
            {
            pushFollow(FOLLOW_12);
            rule__Restriction__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__1"


    // $ANTLR start "rule__Restriction__Group__1__Impl"
    // InternalSM2.g:5087:1: rule__Restriction__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Restriction__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5091:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:5092:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:5092:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:5093:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__1__Impl"


    // $ANTLR start "rule__Restriction__Group__2"
    // InternalSM2.g:5102:1: rule__Restriction__Group__2 : rule__Restriction__Group__2__Impl rule__Restriction__Group__3 ;
    public final void rule__Restriction__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5106:1: ( rule__Restriction__Group__2__Impl rule__Restriction__Group__3 )
            // InternalSM2.g:5107:2: rule__Restriction__Group__2__Impl rule__Restriction__Group__3
            {
            pushFollow(FOLLOW_44);
            rule__Restriction__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__2"


    // $ANTLR start "rule__Restriction__Group__2__Impl"
    // InternalSM2.g:5114:1: rule__Restriction__Group__2__Impl : ( ( rule__Restriction__ExprAssignment_2 ) ) ;
    public final void rule__Restriction__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5118:1: ( ( ( rule__Restriction__ExprAssignment_2 ) ) )
            // InternalSM2.g:5119:1: ( ( rule__Restriction__ExprAssignment_2 ) )
            {
            // InternalSM2.g:5119:1: ( ( rule__Restriction__ExprAssignment_2 ) )
            // InternalSM2.g:5120:2: ( rule__Restriction__ExprAssignment_2 )
            {
             before(grammarAccess.getRestrictionAccess().getExprAssignment_2()); 
            // InternalSM2.g:5121:2: ( rule__Restriction__ExprAssignment_2 )
            // InternalSM2.g:5121:3: rule__Restriction__ExprAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__ExprAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getExprAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__2__Impl"


    // $ANTLR start "rule__Restriction__Group__3"
    // InternalSM2.g:5129:1: rule__Restriction__Group__3 : rule__Restriction__Group__3__Impl rule__Restriction__Group__4 ;
    public final void rule__Restriction__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5133:1: ( rule__Restriction__Group__3__Impl rule__Restriction__Group__4 )
            // InternalSM2.g:5134:2: rule__Restriction__Group__3__Impl rule__Restriction__Group__4
            {
            pushFollow(FOLLOW_12);
            rule__Restriction__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__3"


    // $ANTLR start "rule__Restriction__Group__3__Impl"
    // InternalSM2.g:5141:1: rule__Restriction__Group__3__Impl : ( ( rule__Restriction__OperatorAssignment_3 ) ) ;
    public final void rule__Restriction__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5145:1: ( ( ( rule__Restriction__OperatorAssignment_3 ) ) )
            // InternalSM2.g:5146:1: ( ( rule__Restriction__OperatorAssignment_3 ) )
            {
            // InternalSM2.g:5146:1: ( ( rule__Restriction__OperatorAssignment_3 ) )
            // InternalSM2.g:5147:2: ( rule__Restriction__OperatorAssignment_3 )
            {
             before(grammarAccess.getRestrictionAccess().getOperatorAssignment_3()); 
            // InternalSM2.g:5148:2: ( rule__Restriction__OperatorAssignment_3 )
            // InternalSM2.g:5148:3: rule__Restriction__OperatorAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__OperatorAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getOperatorAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__3__Impl"


    // $ANTLR start "rule__Restriction__Group__4"
    // InternalSM2.g:5156:1: rule__Restriction__Group__4 : rule__Restriction__Group__4__Impl rule__Restriction__Group__5 ;
    public final void rule__Restriction__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5160:1: ( rule__Restriction__Group__4__Impl rule__Restriction__Group__5 )
            // InternalSM2.g:5161:2: rule__Restriction__Group__4__Impl rule__Restriction__Group__5
            {
            pushFollow(FOLLOW_13);
            rule__Restriction__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__4"


    // $ANTLR start "rule__Restriction__Group__4__Impl"
    // InternalSM2.g:5168:1: rule__Restriction__Group__4__Impl : ( ( rule__Restriction__ExprAssignment_4 ) ) ;
    public final void rule__Restriction__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5172:1: ( ( ( rule__Restriction__ExprAssignment_4 ) ) )
            // InternalSM2.g:5173:1: ( ( rule__Restriction__ExprAssignment_4 ) )
            {
            // InternalSM2.g:5173:1: ( ( rule__Restriction__ExprAssignment_4 ) )
            // InternalSM2.g:5174:2: ( rule__Restriction__ExprAssignment_4 )
            {
             before(grammarAccess.getRestrictionAccess().getExprAssignment_4()); 
            // InternalSM2.g:5175:2: ( rule__Restriction__ExprAssignment_4 )
            // InternalSM2.g:5175:3: rule__Restriction__ExprAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__ExprAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getExprAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__4__Impl"


    // $ANTLR start "rule__Restriction__Group__5"
    // InternalSM2.g:5183:1: rule__Restriction__Group__5 : rule__Restriction__Group__5__Impl rule__Restriction__Group__6 ;
    public final void rule__Restriction__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5187:1: ( rule__Restriction__Group__5__Impl rule__Restriction__Group__6 )
            // InternalSM2.g:5188:2: rule__Restriction__Group__5__Impl rule__Restriction__Group__6
            {
            pushFollow(FOLLOW_10);
            rule__Restriction__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__5"


    // $ANTLR start "rule__Restriction__Group__5__Impl"
    // InternalSM2.g:5195:1: rule__Restriction__Group__5__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Restriction__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5199:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:5200:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:5200:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:5201:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__5__Impl"


    // $ANTLR start "rule__Restriction__Group__6"
    // InternalSM2.g:5210:1: rule__Restriction__Group__6 : rule__Restriction__Group__6__Impl rule__Restriction__Group__7 ;
    public final void rule__Restriction__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5214:1: ( rule__Restriction__Group__6__Impl rule__Restriction__Group__7 )
            // InternalSM2.g:5215:2: rule__Restriction__Group__6__Impl rule__Restriction__Group__7
            {
            pushFollow(FOLLOW_14);
            rule__Restriction__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__6"


    // $ANTLR start "rule__Restriction__Group__6__Impl"
    // InternalSM2.g:5222:1: rule__Restriction__Group__6__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Restriction__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5226:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:5227:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:5227:1: ( RULE_SEMICOLON )
            // InternalSM2.g:5228:2: RULE_SEMICOLON
            {
             before(grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__6__Impl"


    // $ANTLR start "rule__Restriction__Group__7"
    // InternalSM2.g:5237:1: rule__Restriction__Group__7 : rule__Restriction__Group__7__Impl ;
    public final void rule__Restriction__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5241:1: ( rule__Restriction__Group__7__Impl )
            // InternalSM2.g:5242:2: rule__Restriction__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__7"


    // $ANTLR start "rule__Restriction__Group__7__Impl"
    // InternalSM2.g:5248:1: rule__Restriction__Group__7__Impl : ( RULE_EOLINE ) ;
    public final void rule__Restriction__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5252:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:5253:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:5253:1: ( RULE_EOLINE )
            // InternalSM2.g:5254:2: RULE_EOLINE
            {
             before(grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__7__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__0"
    // InternalSM2.g:5264:1: rule__RestrictionGas__Group__0 : rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1 ;
    public final void rule__RestrictionGas__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5268:1: ( rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1 )
            // InternalSM2.g:5269:2: rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1
            {
            pushFollow(FOLLOW_11);
            rule__RestrictionGas__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__0"


    // $ANTLR start "rule__RestrictionGas__Group__0__Impl"
    // InternalSM2.g:5276:1: rule__RestrictionGas__Group__0__Impl : ( 'require' ) ;
    public final void rule__RestrictionGas__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5280:1: ( ( 'require' ) )
            // InternalSM2.g:5281:1: ( 'require' )
            {
            // InternalSM2.g:5281:1: ( 'require' )
            // InternalSM2.g:5282:2: 'require'
            {
             before(grammarAccess.getRestrictionGasAccess().getRequireKeyword_0()); 
            match(input,85,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getRequireKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__0__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__1"
    // InternalSM2.g:5291:1: rule__RestrictionGas__Group__1 : rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2 ;
    public final void rule__RestrictionGas__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5295:1: ( rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2 )
            // InternalSM2.g:5296:2: rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2
            {
            pushFollow(FOLLOW_12);
            rule__RestrictionGas__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__1"


    // $ANTLR start "rule__RestrictionGas__Group__1__Impl"
    // InternalSM2.g:5303:1: rule__RestrictionGas__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__RestrictionGas__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5307:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:5308:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:5308:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:5309:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__1__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__2"
    // InternalSM2.g:5318:1: rule__RestrictionGas__Group__2 : rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3 ;
    public final void rule__RestrictionGas__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5322:1: ( rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3 )
            // InternalSM2.g:5323:2: rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3
            {
            pushFollow(FOLLOW_44);
            rule__RestrictionGas__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__2"


    // $ANTLR start "rule__RestrictionGas__Group__2__Impl"
    // InternalSM2.g:5330:1: rule__RestrictionGas__Group__2__Impl : ( ( rule__RestrictionGas__ExprAssignment_2 ) ) ;
    public final void rule__RestrictionGas__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5334:1: ( ( ( rule__RestrictionGas__ExprAssignment_2 ) ) )
            // InternalSM2.g:5335:1: ( ( rule__RestrictionGas__ExprAssignment_2 ) )
            {
            // InternalSM2.g:5335:1: ( ( rule__RestrictionGas__ExprAssignment_2 ) )
            // InternalSM2.g:5336:2: ( rule__RestrictionGas__ExprAssignment_2 )
            {
             before(grammarAccess.getRestrictionGasAccess().getExprAssignment_2()); 
            // InternalSM2.g:5337:2: ( rule__RestrictionGas__ExprAssignment_2 )
            // InternalSM2.g:5337:3: rule__RestrictionGas__ExprAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__ExprAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getExprAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__2__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__3"
    // InternalSM2.g:5345:1: rule__RestrictionGas__Group__3 : rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4 ;
    public final void rule__RestrictionGas__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5349:1: ( rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4 )
            // InternalSM2.g:5350:2: rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4
            {
            pushFollow(FOLLOW_45);
            rule__RestrictionGas__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__3"


    // $ANTLR start "rule__RestrictionGas__Group__3__Impl"
    // InternalSM2.g:5357:1: rule__RestrictionGas__Group__3__Impl : ( ( rule__RestrictionGas__OperatorAssignment_3 ) ) ;
    public final void rule__RestrictionGas__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5361:1: ( ( ( rule__RestrictionGas__OperatorAssignment_3 ) ) )
            // InternalSM2.g:5362:1: ( ( rule__RestrictionGas__OperatorAssignment_3 ) )
            {
            // InternalSM2.g:5362:1: ( ( rule__RestrictionGas__OperatorAssignment_3 ) )
            // InternalSM2.g:5363:2: ( rule__RestrictionGas__OperatorAssignment_3 )
            {
             before(grammarAccess.getRestrictionGasAccess().getOperatorAssignment_3()); 
            // InternalSM2.g:5364:2: ( rule__RestrictionGas__OperatorAssignment_3 )
            // InternalSM2.g:5364:3: rule__RestrictionGas__OperatorAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__OperatorAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getOperatorAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__3__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__4"
    // InternalSM2.g:5372:1: rule__RestrictionGas__Group__4 : rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5 ;
    public final void rule__RestrictionGas__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5376:1: ( rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5 )
            // InternalSM2.g:5377:2: rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5
            {
            pushFollow(FOLLOW_46);
            rule__RestrictionGas__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__4"


    // $ANTLR start "rule__RestrictionGas__Group__4__Impl"
    // InternalSM2.g:5384:1: rule__RestrictionGas__Group__4__Impl : ( ( rule__RestrictionGas__AmountAssignment_4 ) ) ;
    public final void rule__RestrictionGas__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5388:1: ( ( ( rule__RestrictionGas__AmountAssignment_4 ) ) )
            // InternalSM2.g:5389:1: ( ( rule__RestrictionGas__AmountAssignment_4 ) )
            {
            // InternalSM2.g:5389:1: ( ( rule__RestrictionGas__AmountAssignment_4 ) )
            // InternalSM2.g:5390:2: ( rule__RestrictionGas__AmountAssignment_4 )
            {
             before(grammarAccess.getRestrictionGasAccess().getAmountAssignment_4()); 
            // InternalSM2.g:5391:2: ( rule__RestrictionGas__AmountAssignment_4 )
            // InternalSM2.g:5391:3: rule__RestrictionGas__AmountAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__AmountAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getAmountAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__4__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__5"
    // InternalSM2.g:5399:1: rule__RestrictionGas__Group__5 : rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6 ;
    public final void rule__RestrictionGas__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5403:1: ( rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6 )
            // InternalSM2.g:5404:2: rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6
            {
            pushFollow(FOLLOW_13);
            rule__RestrictionGas__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__5"


    // $ANTLR start "rule__RestrictionGas__Group__5__Impl"
    // InternalSM2.g:5411:1: rule__RestrictionGas__Group__5__Impl : ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) ) ;
    public final void rule__RestrictionGas__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5415:1: ( ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) ) )
            // InternalSM2.g:5416:1: ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) )
            {
            // InternalSM2.g:5416:1: ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) )
            // InternalSM2.g:5417:2: ( rule__RestrictionGas__TypeCoinAssignment_5 )
            {
             before(grammarAccess.getRestrictionGasAccess().getTypeCoinAssignment_5()); 
            // InternalSM2.g:5418:2: ( rule__RestrictionGas__TypeCoinAssignment_5 )
            // InternalSM2.g:5418:3: rule__RestrictionGas__TypeCoinAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__TypeCoinAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getTypeCoinAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__5__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__6"
    // InternalSM2.g:5426:1: rule__RestrictionGas__Group__6 : rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7 ;
    public final void rule__RestrictionGas__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5430:1: ( rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7 )
            // InternalSM2.g:5431:2: rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7
            {
            pushFollow(FOLLOW_10);
            rule__RestrictionGas__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__6"


    // $ANTLR start "rule__RestrictionGas__Group__6__Impl"
    // InternalSM2.g:5438:1: rule__RestrictionGas__Group__6__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__RestrictionGas__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5442:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:5443:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:5443:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:5444:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__6__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__7"
    // InternalSM2.g:5453:1: rule__RestrictionGas__Group__7 : rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8 ;
    public final void rule__RestrictionGas__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5457:1: ( rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8 )
            // InternalSM2.g:5458:2: rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8
            {
            pushFollow(FOLLOW_14);
            rule__RestrictionGas__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__7"


    // $ANTLR start "rule__RestrictionGas__Group__7__Impl"
    // InternalSM2.g:5465:1: rule__RestrictionGas__Group__7__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__RestrictionGas__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5469:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:5470:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:5470:1: ( RULE_SEMICOLON )
            // InternalSM2.g:5471:2: RULE_SEMICOLON
            {
             before(grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__7__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__8"
    // InternalSM2.g:5480:1: rule__RestrictionGas__Group__8 : rule__RestrictionGas__Group__8__Impl ;
    public final void rule__RestrictionGas__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5484:1: ( rule__RestrictionGas__Group__8__Impl )
            // InternalSM2.g:5485:2: rule__RestrictionGas__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__8"


    // $ANTLR start "rule__RestrictionGas__Group__8__Impl"
    // InternalSM2.g:5491:1: rule__RestrictionGas__Group__8__Impl : ( RULE_EOLINE ) ;
    public final void rule__RestrictionGas__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5495:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:5496:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:5496:1: ( RULE_EOLINE )
            // InternalSM2.g:5497:2: RULE_EOLINE
            {
             before(grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__8__Impl"


    // $ANTLR start "rule__Clause__Group__0"
    // InternalSM2.g:5507:1: rule__Clause__Group__0 : rule__Clause__Group__0__Impl rule__Clause__Group__1 ;
    public final void rule__Clause__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5511:1: ( rule__Clause__Group__0__Impl rule__Clause__Group__1 )
            // InternalSM2.g:5512:2: rule__Clause__Group__0__Impl rule__Clause__Group__1
            {
            pushFollow(FOLLOW_16);
            rule__Clause__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__0"


    // $ANTLR start "rule__Clause__Group__0__Impl"
    // InternalSM2.g:5519:1: rule__Clause__Group__0__Impl : ( 'function' ) ;
    public final void rule__Clause__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5523:1: ( ( 'function' ) )
            // InternalSM2.g:5524:1: ( 'function' )
            {
            // InternalSM2.g:5524:1: ( 'function' )
            // InternalSM2.g:5525:2: 'function'
            {
             before(grammarAccess.getClauseAccess().getFunctionKeyword_0()); 
            match(input,86,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getFunctionKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__0__Impl"


    // $ANTLR start "rule__Clause__Group__1"
    // InternalSM2.g:5534:1: rule__Clause__Group__1 : rule__Clause__Group__1__Impl rule__Clause__Group__2 ;
    public final void rule__Clause__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5538:1: ( rule__Clause__Group__1__Impl rule__Clause__Group__2 )
            // InternalSM2.g:5539:2: rule__Clause__Group__1__Impl rule__Clause__Group__2
            {
            pushFollow(FOLLOW_11);
            rule__Clause__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__1"


    // $ANTLR start "rule__Clause__Group__1__Impl"
    // InternalSM2.g:5546:1: rule__Clause__Group__1__Impl : ( ( rule__Clause__NameFunctionAssignment_1 ) ) ;
    public final void rule__Clause__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5550:1: ( ( ( rule__Clause__NameFunctionAssignment_1 ) ) )
            // InternalSM2.g:5551:1: ( ( rule__Clause__NameFunctionAssignment_1 ) )
            {
            // InternalSM2.g:5551:1: ( ( rule__Clause__NameFunctionAssignment_1 ) )
            // InternalSM2.g:5552:2: ( rule__Clause__NameFunctionAssignment_1 )
            {
             before(grammarAccess.getClauseAccess().getNameFunctionAssignment_1()); 
            // InternalSM2.g:5553:2: ( rule__Clause__NameFunctionAssignment_1 )
            // InternalSM2.g:5553:3: rule__Clause__NameFunctionAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Clause__NameFunctionAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getNameFunctionAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__1__Impl"


    // $ANTLR start "rule__Clause__Group__2"
    // InternalSM2.g:5561:1: rule__Clause__Group__2 : rule__Clause__Group__2__Impl rule__Clause__Group__3 ;
    public final void rule__Clause__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5565:1: ( rule__Clause__Group__2__Impl rule__Clause__Group__3 )
            // InternalSM2.g:5566:2: rule__Clause__Group__2__Impl rule__Clause__Group__3
            {
            pushFollow(FOLLOW_36);
            rule__Clause__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__2"


    // $ANTLR start "rule__Clause__Group__2__Impl"
    // InternalSM2.g:5573:1: rule__Clause__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Clause__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5577:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:5578:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:5578:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:5579:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__2__Impl"


    // $ANTLR start "rule__Clause__Group__3"
    // InternalSM2.g:5588:1: rule__Clause__Group__3 : rule__Clause__Group__3__Impl rule__Clause__Group__4 ;
    public final void rule__Clause__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5592:1: ( rule__Clause__Group__3__Impl rule__Clause__Group__4 )
            // InternalSM2.g:5593:2: rule__Clause__Group__3__Impl rule__Clause__Group__4
            {
            pushFollow(FOLLOW_47);
            rule__Clause__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__3"


    // $ANTLR start "rule__Clause__Group__3__Impl"
    // InternalSM2.g:5600:1: rule__Clause__Group__3__Impl : ( ( rule__Clause__InputParamsAssignment_3 ) ) ;
    public final void rule__Clause__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5604:1: ( ( ( rule__Clause__InputParamsAssignment_3 ) ) )
            // InternalSM2.g:5605:1: ( ( rule__Clause__InputParamsAssignment_3 ) )
            {
            // InternalSM2.g:5605:1: ( ( rule__Clause__InputParamsAssignment_3 ) )
            // InternalSM2.g:5606:2: ( rule__Clause__InputParamsAssignment_3 )
            {
             before(grammarAccess.getClauseAccess().getInputParamsAssignment_3()); 
            // InternalSM2.g:5607:2: ( rule__Clause__InputParamsAssignment_3 )
            // InternalSM2.g:5607:3: rule__Clause__InputParamsAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Clause__InputParamsAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getInputParamsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__3__Impl"


    // $ANTLR start "rule__Clause__Group__4"
    // InternalSM2.g:5615:1: rule__Clause__Group__4 : rule__Clause__Group__4__Impl rule__Clause__Group__5 ;
    public final void rule__Clause__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5619:1: ( rule__Clause__Group__4__Impl rule__Clause__Group__5 )
            // InternalSM2.g:5620:2: rule__Clause__Group__4__Impl rule__Clause__Group__5
            {
            pushFollow(FOLLOW_13);
            rule__Clause__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__4"


    // $ANTLR start "rule__Clause__Group__4__Impl"
    // InternalSM2.g:5627:1: rule__Clause__Group__4__Impl : ( ( rule__Clause__VisibilityAccessAssignment_4 ) ) ;
    public final void rule__Clause__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5631:1: ( ( ( rule__Clause__VisibilityAccessAssignment_4 ) ) )
            // InternalSM2.g:5632:1: ( ( rule__Clause__VisibilityAccessAssignment_4 ) )
            {
            // InternalSM2.g:5632:1: ( ( rule__Clause__VisibilityAccessAssignment_4 ) )
            // InternalSM2.g:5633:2: ( rule__Clause__VisibilityAccessAssignment_4 )
            {
             before(grammarAccess.getClauseAccess().getVisibilityAccessAssignment_4()); 
            // InternalSM2.g:5634:2: ( rule__Clause__VisibilityAccessAssignment_4 )
            // InternalSM2.g:5634:3: rule__Clause__VisibilityAccessAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Clause__VisibilityAccessAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getVisibilityAccessAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__4__Impl"


    // $ANTLR start "rule__Clause__Group__5"
    // InternalSM2.g:5642:1: rule__Clause__Group__5 : rule__Clause__Group__5__Impl rule__Clause__Group__6 ;
    public final void rule__Clause__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5646:1: ( rule__Clause__Group__5__Impl rule__Clause__Group__6 )
            // InternalSM2.g:5647:2: rule__Clause__Group__5__Impl rule__Clause__Group__6
            {
            pushFollow(FOLLOW_29);
            rule__Clause__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__5"


    // $ANTLR start "rule__Clause__Group__5__Impl"
    // InternalSM2.g:5654:1: rule__Clause__Group__5__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Clause__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5658:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:5659:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:5659:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:5660:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__5__Impl"


    // $ANTLR start "rule__Clause__Group__6"
    // InternalSM2.g:5669:1: rule__Clause__Group__6 : rule__Clause__Group__6__Impl rule__Clause__Group__7 ;
    public final void rule__Clause__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5673:1: ( rule__Clause__Group__6__Impl rule__Clause__Group__7 )
            // InternalSM2.g:5674:2: rule__Clause__Group__6__Impl rule__Clause__Group__7
            {
            pushFollow(FOLLOW_14);
            rule__Clause__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__6"


    // $ANTLR start "rule__Clause__Group__6__Impl"
    // InternalSM2.g:5681:1: rule__Clause__Group__6__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Clause__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5685:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:5686:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:5686:1: ( RULE_OPENKEY )
            // InternalSM2.g:5687:2: RULE_OPENKEY
            {
             before(grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_6()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__6__Impl"


    // $ANTLR start "rule__Clause__Group__7"
    // InternalSM2.g:5696:1: rule__Clause__Group__7 : rule__Clause__Group__7__Impl rule__Clause__Group__8 ;
    public final void rule__Clause__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5700:1: ( rule__Clause__Group__7__Impl rule__Clause__Group__8 )
            // InternalSM2.g:5701:2: rule__Clause__Group__7__Impl rule__Clause__Group__8
            {
            pushFollow(FOLLOW_48);
            rule__Clause__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__7"


    // $ANTLR start "rule__Clause__Group__7__Impl"
    // InternalSM2.g:5708:1: rule__Clause__Group__7__Impl : ( RULE_EOLINE ) ;
    public final void rule__Clause__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5712:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:5713:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:5713:1: ( RULE_EOLINE )
            // InternalSM2.g:5714:2: RULE_EOLINE
            {
             before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_7()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__7__Impl"


    // $ANTLR start "rule__Clause__Group__8"
    // InternalSM2.g:5723:1: rule__Clause__Group__8 : rule__Clause__Group__8__Impl rule__Clause__Group__9 ;
    public final void rule__Clause__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5727:1: ( rule__Clause__Group__8__Impl rule__Clause__Group__9 )
            // InternalSM2.g:5728:2: rule__Clause__Group__8__Impl rule__Clause__Group__9
            {
            pushFollow(FOLLOW_48);
            rule__Clause__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__8"


    // $ANTLR start "rule__Clause__Group__8__Impl"
    // InternalSM2.g:5735:1: rule__Clause__Group__8__Impl : ( ( rule__Clause__RestrictionAssignment_8 )? ) ;
    public final void rule__Clause__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5739:1: ( ( ( rule__Clause__RestrictionAssignment_8 )? ) )
            // InternalSM2.g:5740:1: ( ( rule__Clause__RestrictionAssignment_8 )? )
            {
            // InternalSM2.g:5740:1: ( ( rule__Clause__RestrictionAssignment_8 )? )
            // InternalSM2.g:5741:2: ( rule__Clause__RestrictionAssignment_8 )?
            {
             before(grammarAccess.getClauseAccess().getRestrictionAssignment_8()); 
            // InternalSM2.g:5742:2: ( rule__Clause__RestrictionAssignment_8 )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==85) ) {
                alt50=1;
            }
            switch (alt50) {
                case 1 :
                    // InternalSM2.g:5742:3: rule__Clause__RestrictionAssignment_8
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__RestrictionAssignment_8();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getRestrictionAssignment_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__8__Impl"


    // $ANTLR start "rule__Clause__Group__9"
    // InternalSM2.g:5750:1: rule__Clause__Group__9 : rule__Clause__Group__9__Impl rule__Clause__Group__10 ;
    public final void rule__Clause__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5754:1: ( rule__Clause__Group__9__Impl rule__Clause__Group__10 )
            // InternalSM2.g:5755:2: rule__Clause__Group__9__Impl rule__Clause__Group__10
            {
            pushFollow(FOLLOW_48);
            rule__Clause__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__9"


    // $ANTLR start "rule__Clause__Group__9__Impl"
    // InternalSM2.g:5762:1: rule__Clause__Group__9__Impl : ( ( rule__Clause__ExpressionAssignment_9 )? ) ;
    public final void rule__Clause__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5766:1: ( ( ( rule__Clause__ExpressionAssignment_9 )? ) )
            // InternalSM2.g:5767:1: ( ( rule__Clause__ExpressionAssignment_9 )? )
            {
            // InternalSM2.g:5767:1: ( ( rule__Clause__ExpressionAssignment_9 )? )
            // InternalSM2.g:5768:2: ( rule__Clause__ExpressionAssignment_9 )?
            {
             before(grammarAccess.getClauseAccess().getExpressionAssignment_9()); 
            // InternalSM2.g:5769:2: ( rule__Clause__ExpressionAssignment_9 )?
            int alt51=2;
            int LA51_0 = input.LA(1);

            if ( (LA51_0==RULE_STRING||LA51_0==39) ) {
                alt51=1;
            }
            switch (alt51) {
                case 1 :
                    // InternalSM2.g:5769:3: rule__Clause__ExpressionAssignment_9
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__ExpressionAssignment_9();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getExpressionAssignment_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__9__Impl"


    // $ANTLR start "rule__Clause__Group__10"
    // InternalSM2.g:5777:1: rule__Clause__Group__10 : rule__Clause__Group__10__Impl rule__Clause__Group__11 ;
    public final void rule__Clause__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5781:1: ( rule__Clause__Group__10__Impl rule__Clause__Group__11 )
            // InternalSM2.g:5782:2: rule__Clause__Group__10__Impl rule__Clause__Group__11
            {
            pushFollow(FOLLOW_48);
            rule__Clause__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__10"


    // $ANTLR start "rule__Clause__Group__10__Impl"
    // InternalSM2.g:5789:1: rule__Clause__Group__10__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Clause__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5793:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:5794:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:5794:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:5795:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_10()); 
            // InternalSM2.g:5796:2: ( RULE_EOLINE )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==RULE_EOLINE) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalSM2.g:5796:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__10__Impl"


    // $ANTLR start "rule__Clause__Group__11"
    // InternalSM2.g:5804:1: rule__Clause__Group__11 : rule__Clause__Group__11__Impl rule__Clause__Group__12 ;
    public final void rule__Clause__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5808:1: ( rule__Clause__Group__11__Impl rule__Clause__Group__12 )
            // InternalSM2.g:5809:2: rule__Clause__Group__11__Impl rule__Clause__Group__12
            {
            pushFollow(FOLLOW_14);
            rule__Clause__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__11"


    // $ANTLR start "rule__Clause__Group__11__Impl"
    // InternalSM2.g:5816:1: rule__Clause__Group__11__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Clause__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5820:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:5821:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:5821:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:5822:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_11()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__11__Impl"


    // $ANTLR start "rule__Clause__Group__12"
    // InternalSM2.g:5831:1: rule__Clause__Group__12 : rule__Clause__Group__12__Impl ;
    public final void rule__Clause__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5835:1: ( rule__Clause__Group__12__Impl )
            // InternalSM2.g:5836:2: rule__Clause__Group__12__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Clause__Group__12__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__12"


    // $ANTLR start "rule__Clause__Group__12__Impl"
    // InternalSM2.g:5842:1: rule__Clause__Group__12__Impl : ( RULE_EOLINE ) ;
    public final void rule__Clause__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5846:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:5847:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:5847:1: ( RULE_EOLINE )
            // InternalSM2.g:5848:2: RULE_EOLINE
            {
             before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_12()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__12__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__0"
    // InternalSM2.g:5858:1: rule__Selfdestruct__Group__0 : rule__Selfdestruct__Group__0__Impl rule__Selfdestruct__Group__1 ;
    public final void rule__Selfdestruct__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5862:1: ( rule__Selfdestruct__Group__0__Impl rule__Selfdestruct__Group__1 )
            // InternalSM2.g:5863:2: rule__Selfdestruct__Group__0__Impl rule__Selfdestruct__Group__1
            {
            pushFollow(FOLLOW_11);
            rule__Selfdestruct__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__0"


    // $ANTLR start "rule__Selfdestruct__Group__0__Impl"
    // InternalSM2.g:5870:1: rule__Selfdestruct__Group__0__Impl : ( 'selfdesctruct' ) ;
    public final void rule__Selfdestruct__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5874:1: ( ( 'selfdesctruct' ) )
            // InternalSM2.g:5875:1: ( 'selfdesctruct' )
            {
            // InternalSM2.g:5875:1: ( 'selfdesctruct' )
            // InternalSM2.g:5876:2: 'selfdesctruct'
            {
             before(grammarAccess.getSelfdestructAccess().getSelfdesctructKeyword_0()); 
            match(input,87,FOLLOW_2); 
             after(grammarAccess.getSelfdestructAccess().getSelfdesctructKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__0__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__1"
    // InternalSM2.g:5885:1: rule__Selfdestruct__Group__1 : rule__Selfdestruct__Group__1__Impl rule__Selfdestruct__Group__2 ;
    public final void rule__Selfdestruct__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5889:1: ( rule__Selfdestruct__Group__1__Impl rule__Selfdestruct__Group__2 )
            // InternalSM2.g:5890:2: rule__Selfdestruct__Group__1__Impl rule__Selfdestruct__Group__2
            {
            pushFollow(FOLLOW_12);
            rule__Selfdestruct__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__1"


    // $ANTLR start "rule__Selfdestruct__Group__1__Impl"
    // InternalSM2.g:5897:1: rule__Selfdestruct__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Selfdestruct__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5901:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:5902:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:5902:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:5903:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getSelfdestructAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getSelfdestructAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__1__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__2"
    // InternalSM2.g:5912:1: rule__Selfdestruct__Group__2 : rule__Selfdestruct__Group__2__Impl rule__Selfdestruct__Group__3 ;
    public final void rule__Selfdestruct__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5916:1: ( rule__Selfdestruct__Group__2__Impl rule__Selfdestruct__Group__3 )
            // InternalSM2.g:5917:2: rule__Selfdestruct__Group__2__Impl rule__Selfdestruct__Group__3
            {
            pushFollow(FOLLOW_13);
            rule__Selfdestruct__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__2"


    // $ANTLR start "rule__Selfdestruct__Group__2__Impl"
    // InternalSM2.g:5924:1: rule__Selfdestruct__Group__2__Impl : ( ruleSyntaxExpression ) ;
    public final void rule__Selfdestruct__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5928:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:5929:1: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:5929:1: ( ruleSyntaxExpression )
            // InternalSM2.g:5930:2: ruleSyntaxExpression
            {
             before(grammarAccess.getSelfdestructAccess().getSyntaxExpressionParserRuleCall_2()); 
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getSelfdestructAccess().getSyntaxExpressionParserRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__2__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__3"
    // InternalSM2.g:5939:1: rule__Selfdestruct__Group__3 : rule__Selfdestruct__Group__3__Impl rule__Selfdestruct__Group__4 ;
    public final void rule__Selfdestruct__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5943:1: ( rule__Selfdestruct__Group__3__Impl rule__Selfdestruct__Group__4 )
            // InternalSM2.g:5944:2: rule__Selfdestruct__Group__3__Impl rule__Selfdestruct__Group__4
            {
            pushFollow(FOLLOW_10);
            rule__Selfdestruct__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__3"


    // $ANTLR start "rule__Selfdestruct__Group__3__Impl"
    // InternalSM2.g:5951:1: rule__Selfdestruct__Group__3__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Selfdestruct__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5955:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:5956:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:5956:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:5957:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getSelfdestructAccess().getCLOSEPARENTHESISTerminalRuleCall_3()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getSelfdestructAccess().getCLOSEPARENTHESISTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__3__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__4"
    // InternalSM2.g:5966:1: rule__Selfdestruct__Group__4 : rule__Selfdestruct__Group__4__Impl rule__Selfdestruct__Group__5 ;
    public final void rule__Selfdestruct__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5970:1: ( rule__Selfdestruct__Group__4__Impl rule__Selfdestruct__Group__5 )
            // InternalSM2.g:5971:2: rule__Selfdestruct__Group__4__Impl rule__Selfdestruct__Group__5
            {
            pushFollow(FOLLOW_14);
            rule__Selfdestruct__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__4"


    // $ANTLR start "rule__Selfdestruct__Group__4__Impl"
    // InternalSM2.g:5978:1: rule__Selfdestruct__Group__4__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Selfdestruct__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5982:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:5983:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:5983:1: ( RULE_SEMICOLON )
            // InternalSM2.g:5984:2: RULE_SEMICOLON
            {
             before(grammarAccess.getSelfdestructAccess().getSEMICOLONTerminalRuleCall_4()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getSelfdestructAccess().getSEMICOLONTerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__4__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__5"
    // InternalSM2.g:5993:1: rule__Selfdestruct__Group__5 : rule__Selfdestruct__Group__5__Impl ;
    public final void rule__Selfdestruct__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5997:1: ( rule__Selfdestruct__Group__5__Impl )
            // InternalSM2.g:5998:2: rule__Selfdestruct__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__5"


    // $ANTLR start "rule__Selfdestruct__Group__5__Impl"
    // InternalSM2.g:6004:1: rule__Selfdestruct__Group__5__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Selfdestruct__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6008:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:6009:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:6009:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:6010:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getSelfdestructAccess().getEOLINETerminalRuleCall_5()); 
            // InternalSM2.g:6011:2: ( RULE_EOLINE )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==RULE_EOLINE) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // InternalSM2.g:6011:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getSelfdestructAccess().getEOLINETerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__5__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_0__0"
    // InternalSM2.g:6020:1: rule__CryptographycFunctions__Group_0__0 : rule__CryptographycFunctions__Group_0__0__Impl rule__CryptographycFunctions__Group_0__1 ;
    public final void rule__CryptographycFunctions__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6024:1: ( rule__CryptographycFunctions__Group_0__0__Impl rule__CryptographycFunctions__Group_0__1 )
            // InternalSM2.g:6025:2: rule__CryptographycFunctions__Group_0__0__Impl rule__CryptographycFunctions__Group_0__1
            {
            pushFollow(FOLLOW_11);
            rule__CryptographycFunctions__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_0__0"


    // $ANTLR start "rule__CryptographycFunctions__Group_0__0__Impl"
    // InternalSM2.g:6032:1: rule__CryptographycFunctions__Group_0__0__Impl : ( 'keccack256' ) ;
    public final void rule__CryptographycFunctions__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6036:1: ( ( 'keccack256' ) )
            // InternalSM2.g:6037:1: ( 'keccack256' )
            {
            // InternalSM2.g:6037:1: ( 'keccack256' )
            // InternalSM2.g:6038:2: 'keccack256'
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getKeccack256Keyword_0_0()); 
            match(input,88,FOLLOW_2); 
             after(grammarAccess.getCryptographycFunctionsAccess().getKeccack256Keyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_0__0__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_0__1"
    // InternalSM2.g:6047:1: rule__CryptographycFunctions__Group_0__1 : rule__CryptographycFunctions__Group_0__1__Impl rule__CryptographycFunctions__Group_0__2 ;
    public final void rule__CryptographycFunctions__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6051:1: ( rule__CryptographycFunctions__Group_0__1__Impl rule__CryptographycFunctions__Group_0__2 )
            // InternalSM2.g:6052:2: rule__CryptographycFunctions__Group_0__1__Impl rule__CryptographycFunctions__Group_0__2
            {
            pushFollow(FOLLOW_32);
            rule__CryptographycFunctions__Group_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_0__1"


    // $ANTLR start "rule__CryptographycFunctions__Group_0__1__Impl"
    // InternalSM2.g:6059:1: rule__CryptographycFunctions__Group_0__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__CryptographycFunctions__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6063:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:6064:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:6064:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:6065:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_0_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_0__1__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_0__2"
    // InternalSM2.g:6074:1: rule__CryptographycFunctions__Group_0__2 : rule__CryptographycFunctions__Group_0__2__Impl rule__CryptographycFunctions__Group_0__3 ;
    public final void rule__CryptographycFunctions__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6078:1: ( rule__CryptographycFunctions__Group_0__2__Impl rule__CryptographycFunctions__Group_0__3 )
            // InternalSM2.g:6079:2: rule__CryptographycFunctions__Group_0__2__Impl rule__CryptographycFunctions__Group_0__3
            {
            pushFollow(FOLLOW_13);
            rule__CryptographycFunctions__Group_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_0__2"


    // $ANTLR start "rule__CryptographycFunctions__Group_0__2__Impl"
    // InternalSM2.g:6086:1: rule__CryptographycFunctions__Group_0__2__Impl : ( RULE_STRING ) ;
    public final void rule__CryptographycFunctions__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6090:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6091:1: ( RULE_STRING )
            {
            // InternalSM2.g:6091:1: ( RULE_STRING )
            // InternalSM2.g:6092:2: RULE_STRING
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_0_2()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_0__2__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_0__3"
    // InternalSM2.g:6101:1: rule__CryptographycFunctions__Group_0__3 : rule__CryptographycFunctions__Group_0__3__Impl rule__CryptographycFunctions__Group_0__4 ;
    public final void rule__CryptographycFunctions__Group_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6105:1: ( rule__CryptographycFunctions__Group_0__3__Impl rule__CryptographycFunctions__Group_0__4 )
            // InternalSM2.g:6106:2: rule__CryptographycFunctions__Group_0__3__Impl rule__CryptographycFunctions__Group_0__4
            {
            pushFollow(FOLLOW_10);
            rule__CryptographycFunctions__Group_0__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_0__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_0__3"


    // $ANTLR start "rule__CryptographycFunctions__Group_0__3__Impl"
    // InternalSM2.g:6113:1: rule__CryptographycFunctions__Group_0__3__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__CryptographycFunctions__Group_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6117:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:6118:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:6118:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:6119:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_0_3()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_0__3__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_0__4"
    // InternalSM2.g:6128:1: rule__CryptographycFunctions__Group_0__4 : rule__CryptographycFunctions__Group_0__4__Impl ;
    public final void rule__CryptographycFunctions__Group_0__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6132:1: ( rule__CryptographycFunctions__Group_0__4__Impl )
            // InternalSM2.g:6133:2: rule__CryptographycFunctions__Group_0__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_0__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_0__4"


    // $ANTLR start "rule__CryptographycFunctions__Group_0__4__Impl"
    // InternalSM2.g:6139:1: rule__CryptographycFunctions__Group_0__4__Impl : ( ( RULE_SEMICOLON )? ) ;
    public final void rule__CryptographycFunctions__Group_0__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6143:1: ( ( ( RULE_SEMICOLON )? ) )
            // InternalSM2.g:6144:1: ( ( RULE_SEMICOLON )? )
            {
            // InternalSM2.g:6144:1: ( ( RULE_SEMICOLON )? )
            // InternalSM2.g:6145:2: ( RULE_SEMICOLON )?
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_0_4()); 
            // InternalSM2.g:6146:2: ( RULE_SEMICOLON )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==RULE_SEMICOLON) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalSM2.g:6146:3: RULE_SEMICOLON
                    {
                    match(input,RULE_SEMICOLON,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_0_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_0__4__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_1__0"
    // InternalSM2.g:6155:1: rule__CryptographycFunctions__Group_1__0 : rule__CryptographycFunctions__Group_1__0__Impl rule__CryptographycFunctions__Group_1__1 ;
    public final void rule__CryptographycFunctions__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6159:1: ( rule__CryptographycFunctions__Group_1__0__Impl rule__CryptographycFunctions__Group_1__1 )
            // InternalSM2.g:6160:2: rule__CryptographycFunctions__Group_1__0__Impl rule__CryptographycFunctions__Group_1__1
            {
            pushFollow(FOLLOW_11);
            rule__CryptographycFunctions__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_1__0"


    // $ANTLR start "rule__CryptographycFunctions__Group_1__0__Impl"
    // InternalSM2.g:6167:1: rule__CryptographycFunctions__Group_1__0__Impl : ( 'sha256' ) ;
    public final void rule__CryptographycFunctions__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6171:1: ( ( 'sha256' ) )
            // InternalSM2.g:6172:1: ( 'sha256' )
            {
            // InternalSM2.g:6172:1: ( 'sha256' )
            // InternalSM2.g:6173:2: 'sha256'
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getSha256Keyword_1_0()); 
            match(input,89,FOLLOW_2); 
             after(grammarAccess.getCryptographycFunctionsAccess().getSha256Keyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_1__0__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_1__1"
    // InternalSM2.g:6182:1: rule__CryptographycFunctions__Group_1__1 : rule__CryptographycFunctions__Group_1__1__Impl rule__CryptographycFunctions__Group_1__2 ;
    public final void rule__CryptographycFunctions__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6186:1: ( rule__CryptographycFunctions__Group_1__1__Impl rule__CryptographycFunctions__Group_1__2 )
            // InternalSM2.g:6187:2: rule__CryptographycFunctions__Group_1__1__Impl rule__CryptographycFunctions__Group_1__2
            {
            pushFollow(FOLLOW_32);
            rule__CryptographycFunctions__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_1__1"


    // $ANTLR start "rule__CryptographycFunctions__Group_1__1__Impl"
    // InternalSM2.g:6194:1: rule__CryptographycFunctions__Group_1__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__CryptographycFunctions__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6198:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:6199:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:6199:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:6200:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_1_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_1__1__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_1__2"
    // InternalSM2.g:6209:1: rule__CryptographycFunctions__Group_1__2 : rule__CryptographycFunctions__Group_1__2__Impl rule__CryptographycFunctions__Group_1__3 ;
    public final void rule__CryptographycFunctions__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6213:1: ( rule__CryptographycFunctions__Group_1__2__Impl rule__CryptographycFunctions__Group_1__3 )
            // InternalSM2.g:6214:2: rule__CryptographycFunctions__Group_1__2__Impl rule__CryptographycFunctions__Group_1__3
            {
            pushFollow(FOLLOW_13);
            rule__CryptographycFunctions__Group_1__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_1__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_1__2"


    // $ANTLR start "rule__CryptographycFunctions__Group_1__2__Impl"
    // InternalSM2.g:6221:1: rule__CryptographycFunctions__Group_1__2__Impl : ( RULE_STRING ) ;
    public final void rule__CryptographycFunctions__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6225:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6226:1: ( RULE_STRING )
            {
            // InternalSM2.g:6226:1: ( RULE_STRING )
            // InternalSM2.g:6227:2: RULE_STRING
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_1_2()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_1__2__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_1__3"
    // InternalSM2.g:6236:1: rule__CryptographycFunctions__Group_1__3 : rule__CryptographycFunctions__Group_1__3__Impl rule__CryptographycFunctions__Group_1__4 ;
    public final void rule__CryptographycFunctions__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6240:1: ( rule__CryptographycFunctions__Group_1__3__Impl rule__CryptographycFunctions__Group_1__4 )
            // InternalSM2.g:6241:2: rule__CryptographycFunctions__Group_1__3__Impl rule__CryptographycFunctions__Group_1__4
            {
            pushFollow(FOLLOW_10);
            rule__CryptographycFunctions__Group_1__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_1__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_1__3"


    // $ANTLR start "rule__CryptographycFunctions__Group_1__3__Impl"
    // InternalSM2.g:6248:1: rule__CryptographycFunctions__Group_1__3__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__CryptographycFunctions__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6252:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:6253:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:6253:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:6254:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_1_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_1__3__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_1__4"
    // InternalSM2.g:6263:1: rule__CryptographycFunctions__Group_1__4 : rule__CryptographycFunctions__Group_1__4__Impl ;
    public final void rule__CryptographycFunctions__Group_1__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6267:1: ( rule__CryptographycFunctions__Group_1__4__Impl )
            // InternalSM2.g:6268:2: rule__CryptographycFunctions__Group_1__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_1__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_1__4"


    // $ANTLR start "rule__CryptographycFunctions__Group_1__4__Impl"
    // InternalSM2.g:6274:1: rule__CryptographycFunctions__Group_1__4__Impl : ( ( RULE_SEMICOLON )? ) ;
    public final void rule__CryptographycFunctions__Group_1__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6278:1: ( ( ( RULE_SEMICOLON )? ) )
            // InternalSM2.g:6279:1: ( ( RULE_SEMICOLON )? )
            {
            // InternalSM2.g:6279:1: ( ( RULE_SEMICOLON )? )
            // InternalSM2.g:6280:2: ( RULE_SEMICOLON )?
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_1_4()); 
            // InternalSM2.g:6281:2: ( RULE_SEMICOLON )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==RULE_SEMICOLON) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // InternalSM2.g:6281:3: RULE_SEMICOLON
                    {
                    match(input,RULE_SEMICOLON,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_1_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_1__4__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_2__0"
    // InternalSM2.g:6290:1: rule__CryptographycFunctions__Group_2__0 : rule__CryptographycFunctions__Group_2__0__Impl rule__CryptographycFunctions__Group_2__1 ;
    public final void rule__CryptographycFunctions__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6294:1: ( rule__CryptographycFunctions__Group_2__0__Impl rule__CryptographycFunctions__Group_2__1 )
            // InternalSM2.g:6295:2: rule__CryptographycFunctions__Group_2__0__Impl rule__CryptographycFunctions__Group_2__1
            {
            pushFollow(FOLLOW_11);
            rule__CryptographycFunctions__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_2__0"


    // $ANTLR start "rule__CryptographycFunctions__Group_2__0__Impl"
    // InternalSM2.g:6302:1: rule__CryptographycFunctions__Group_2__0__Impl : ( 'sha3' ) ;
    public final void rule__CryptographycFunctions__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6306:1: ( ( 'sha3' ) )
            // InternalSM2.g:6307:1: ( 'sha3' )
            {
            // InternalSM2.g:6307:1: ( 'sha3' )
            // InternalSM2.g:6308:2: 'sha3'
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getSha3Keyword_2_0()); 
            match(input,90,FOLLOW_2); 
             after(grammarAccess.getCryptographycFunctionsAccess().getSha3Keyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_2__0__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_2__1"
    // InternalSM2.g:6317:1: rule__CryptographycFunctions__Group_2__1 : rule__CryptographycFunctions__Group_2__1__Impl rule__CryptographycFunctions__Group_2__2 ;
    public final void rule__CryptographycFunctions__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6321:1: ( rule__CryptographycFunctions__Group_2__1__Impl rule__CryptographycFunctions__Group_2__2 )
            // InternalSM2.g:6322:2: rule__CryptographycFunctions__Group_2__1__Impl rule__CryptographycFunctions__Group_2__2
            {
            pushFollow(FOLLOW_32);
            rule__CryptographycFunctions__Group_2__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_2__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_2__1"


    // $ANTLR start "rule__CryptographycFunctions__Group_2__1__Impl"
    // InternalSM2.g:6329:1: rule__CryptographycFunctions__Group_2__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__CryptographycFunctions__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6333:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:6334:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:6334:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:6335:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_2_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getCryptographycFunctionsAccess().getOPENPARENTHESISTerminalRuleCall_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_2__1__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_2__2"
    // InternalSM2.g:6344:1: rule__CryptographycFunctions__Group_2__2 : rule__CryptographycFunctions__Group_2__2__Impl rule__CryptographycFunctions__Group_2__3 ;
    public final void rule__CryptographycFunctions__Group_2__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6348:1: ( rule__CryptographycFunctions__Group_2__2__Impl rule__CryptographycFunctions__Group_2__3 )
            // InternalSM2.g:6349:2: rule__CryptographycFunctions__Group_2__2__Impl rule__CryptographycFunctions__Group_2__3
            {
            pushFollow(FOLLOW_13);
            rule__CryptographycFunctions__Group_2__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_2__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_2__2"


    // $ANTLR start "rule__CryptographycFunctions__Group_2__2__Impl"
    // InternalSM2.g:6356:1: rule__CryptographycFunctions__Group_2__2__Impl : ( RULE_STRING ) ;
    public final void rule__CryptographycFunctions__Group_2__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6360:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6361:1: ( RULE_STRING )
            {
            // InternalSM2.g:6361:1: ( RULE_STRING )
            // InternalSM2.g:6362:2: RULE_STRING
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_2_2()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getCryptographycFunctionsAccess().getSTRINGTerminalRuleCall_2_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_2__2__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_2__3"
    // InternalSM2.g:6371:1: rule__CryptographycFunctions__Group_2__3 : rule__CryptographycFunctions__Group_2__3__Impl rule__CryptographycFunctions__Group_2__4 ;
    public final void rule__CryptographycFunctions__Group_2__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6375:1: ( rule__CryptographycFunctions__Group_2__3__Impl rule__CryptographycFunctions__Group_2__4 )
            // InternalSM2.g:6376:2: rule__CryptographycFunctions__Group_2__3__Impl rule__CryptographycFunctions__Group_2__4
            {
            pushFollow(FOLLOW_10);
            rule__CryptographycFunctions__Group_2__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_2__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_2__3"


    // $ANTLR start "rule__CryptographycFunctions__Group_2__3__Impl"
    // InternalSM2.g:6383:1: rule__CryptographycFunctions__Group_2__3__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__CryptographycFunctions__Group_2__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6387:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:6388:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:6388:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:6389:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_2_3()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getCryptographycFunctionsAccess().getCLOSEPARENTHESISTerminalRuleCall_2_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_2__3__Impl"


    // $ANTLR start "rule__CryptographycFunctions__Group_2__4"
    // InternalSM2.g:6398:1: rule__CryptographycFunctions__Group_2__4 : rule__CryptographycFunctions__Group_2__4__Impl ;
    public final void rule__CryptographycFunctions__Group_2__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6402:1: ( rule__CryptographycFunctions__Group_2__4__Impl )
            // InternalSM2.g:6403:2: rule__CryptographycFunctions__Group_2__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__CryptographycFunctions__Group_2__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_2__4"


    // $ANTLR start "rule__CryptographycFunctions__Group_2__4__Impl"
    // InternalSM2.g:6409:1: rule__CryptographycFunctions__Group_2__4__Impl : ( ( RULE_SEMICOLON )? ) ;
    public final void rule__CryptographycFunctions__Group_2__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6413:1: ( ( ( RULE_SEMICOLON )? ) )
            // InternalSM2.g:6414:1: ( ( RULE_SEMICOLON )? )
            {
            // InternalSM2.g:6414:1: ( ( RULE_SEMICOLON )? )
            // InternalSM2.g:6415:2: ( RULE_SEMICOLON )?
            {
             before(grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_2_4()); 
            // InternalSM2.g:6416:2: ( RULE_SEMICOLON )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==RULE_SEMICOLON) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalSM2.g:6416:3: RULE_SEMICOLON
                    {
                    match(input,RULE_SEMICOLON,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getCryptographycFunctionsAccess().getSEMICOLONTerminalRuleCall_2_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CryptographycFunctions__Group_2__4__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group__0"
    // InternalSM2.g:6425:1: rule__SyntaxExpression__Group__0 : rule__SyntaxExpression__Group__0__Impl rule__SyntaxExpression__Group__1 ;
    public final void rule__SyntaxExpression__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6429:1: ( rule__SyntaxExpression__Group__0__Impl rule__SyntaxExpression__Group__1 )
            // InternalSM2.g:6430:2: rule__SyntaxExpression__Group__0__Impl rule__SyntaxExpression__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__SyntaxExpression__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group__0"


    // $ANTLR start "rule__SyntaxExpression__Group__0__Impl"
    // InternalSM2.g:6437:1: rule__SyntaxExpression__Group__0__Impl : ( RULE_STRING ) ;
    public final void rule__SyntaxExpression__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6441:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6442:1: ( RULE_STRING )
            {
            // InternalSM2.g:6442:1: ( RULE_STRING )
            // InternalSM2.g:6443:2: RULE_STRING
            {
             before(grammarAccess.getSyntaxExpressionAccess().getSTRINGTerminalRuleCall_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getSTRINGTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group__0__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group__1"
    // InternalSM2.g:6452:1: rule__SyntaxExpression__Group__1 : rule__SyntaxExpression__Group__1__Impl ;
    public final void rule__SyntaxExpression__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6456:1: ( rule__SyntaxExpression__Group__1__Impl )
            // InternalSM2.g:6457:2: rule__SyntaxExpression__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group__1"


    // $ANTLR start "rule__SyntaxExpression__Group__1__Impl"
    // InternalSM2.g:6463:1: rule__SyntaxExpression__Group__1__Impl : ( ( rule__SyntaxExpression__Group_1__0 )? ) ;
    public final void rule__SyntaxExpression__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6467:1: ( ( ( rule__SyntaxExpression__Group_1__0 )? ) )
            // InternalSM2.g:6468:1: ( ( rule__SyntaxExpression__Group_1__0 )? )
            {
            // InternalSM2.g:6468:1: ( ( rule__SyntaxExpression__Group_1__0 )? )
            // InternalSM2.g:6469:2: ( rule__SyntaxExpression__Group_1__0 )?
            {
             before(grammarAccess.getSyntaxExpressionAccess().getGroup_1()); 
            // InternalSM2.g:6470:2: ( rule__SyntaxExpression__Group_1__0 )?
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==RULE_SEMICOLON) ) {
                alt57=1;
            }
            switch (alt57) {
                case 1 :
                    // InternalSM2.g:6470:3: rule__SyntaxExpression__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__Group_1__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSyntaxExpressionAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group__1__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1__0"
    // InternalSM2.g:6479:1: rule__SyntaxExpression__Group_1__0 : rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1 ;
    public final void rule__SyntaxExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6483:1: ( rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1 )
            // InternalSM2.g:6484:2: rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1
            {
            pushFollow(FOLLOW_14);
            rule__SyntaxExpression__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__0"


    // $ANTLR start "rule__SyntaxExpression__Group_1__0__Impl"
    // InternalSM2.g:6491:1: rule__SyntaxExpression__Group_1__0__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__SyntaxExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6495:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:6496:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:6496:1: ( RULE_SEMICOLON )
            // InternalSM2.g:6497:2: RULE_SEMICOLON
            {
             before(grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_0()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__0__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1__1"
    // InternalSM2.g:6506:1: rule__SyntaxExpression__Group_1__1 : rule__SyntaxExpression__Group_1__1__Impl ;
    public final void rule__SyntaxExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6510:1: ( rule__SyntaxExpression__Group_1__1__Impl )
            // InternalSM2.g:6511:2: rule__SyntaxExpression__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__1"


    // $ANTLR start "rule__SyntaxExpression__Group_1__1__Impl"
    // InternalSM2.g:6517:1: rule__SyntaxExpression__Group_1__1__Impl : ( RULE_EOLINE ) ;
    public final void rule__SyntaxExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6521:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:6522:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:6522:1: ( RULE_EOLINE )
            // InternalSM2.g:6523:2: RULE_EOLINE
            {
             before(grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__1__Impl"


    // $ANTLR start "rule__ShortComment__Group__0"
    // InternalSM2.g:6533:1: rule__ShortComment__Group__0 : rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1 ;
    public final void rule__ShortComment__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6537:1: ( rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1 )
            // InternalSM2.g:6538:2: rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1
            {
            pushFollow(FOLLOW_32);
            rule__ShortComment__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__0"


    // $ANTLR start "rule__ShortComment__Group__0__Impl"
    // InternalSM2.g:6545:1: rule__ShortComment__Group__0__Impl : ( '//' ) ;
    public final void rule__ShortComment__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6549:1: ( ( '//' ) )
            // InternalSM2.g:6550:1: ( '//' )
            {
            // InternalSM2.g:6550:1: ( '//' )
            // InternalSM2.g:6551:2: '//'
            {
             before(grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0()); 
            match(input,91,FOLLOW_2); 
             after(grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__0__Impl"


    // $ANTLR start "rule__ShortComment__Group__1"
    // InternalSM2.g:6560:1: rule__ShortComment__Group__1 : rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2 ;
    public final void rule__ShortComment__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6564:1: ( rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2 )
            // InternalSM2.g:6565:2: rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2
            {
            pushFollow(FOLLOW_14);
            rule__ShortComment__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__1"


    // $ANTLR start "rule__ShortComment__Group__1__Impl"
    // InternalSM2.g:6572:1: rule__ShortComment__Group__1__Impl : ( RULE_STRING ) ;
    public final void rule__ShortComment__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6576:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6577:1: ( RULE_STRING )
            {
            // InternalSM2.g:6577:1: ( RULE_STRING )
            // InternalSM2.g:6578:2: RULE_STRING
            {
             before(grammarAccess.getShortCommentAccess().getSTRINGTerminalRuleCall_1()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getShortCommentAccess().getSTRINGTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__1__Impl"


    // $ANTLR start "rule__ShortComment__Group__2"
    // InternalSM2.g:6587:1: rule__ShortComment__Group__2 : rule__ShortComment__Group__2__Impl ;
    public final void rule__ShortComment__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6591:1: ( rule__ShortComment__Group__2__Impl )
            // InternalSM2.g:6592:2: rule__ShortComment__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__2"


    // $ANTLR start "rule__ShortComment__Group__2__Impl"
    // InternalSM2.g:6598:1: rule__ShortComment__Group__2__Impl : ( RULE_EOLINE ) ;
    public final void rule__ShortComment__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6602:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:6603:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:6603:1: ( RULE_EOLINE )
            // InternalSM2.g:6604:2: RULE_EOLINE
            {
             before(grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__2__Impl"


    // $ANTLR start "rule__LongComment__Group__0"
    // InternalSM2.g:6614:1: rule__LongComment__Group__0 : rule__LongComment__Group__0__Impl rule__LongComment__Group__1 ;
    public final void rule__LongComment__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6618:1: ( rule__LongComment__Group__0__Impl rule__LongComment__Group__1 )
            // InternalSM2.g:6619:2: rule__LongComment__Group__0__Impl rule__LongComment__Group__1
            {
            pushFollow(FOLLOW_32);
            rule__LongComment__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LongComment__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__0"


    // $ANTLR start "rule__LongComment__Group__0__Impl"
    // InternalSM2.g:6626:1: rule__LongComment__Group__0__Impl : ( '/*' ) ;
    public final void rule__LongComment__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6630:1: ( ( '/*' ) )
            // InternalSM2.g:6631:1: ( '/*' )
            {
            // InternalSM2.g:6631:1: ( '/*' )
            // InternalSM2.g:6632:2: '/*'
            {
             before(grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0()); 
            match(input,92,FOLLOW_2); 
             after(grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__0__Impl"


    // $ANTLR start "rule__LongComment__Group__1"
    // InternalSM2.g:6641:1: rule__LongComment__Group__1 : rule__LongComment__Group__1__Impl rule__LongComment__Group__2 ;
    public final void rule__LongComment__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6645:1: ( rule__LongComment__Group__1__Impl rule__LongComment__Group__2 )
            // InternalSM2.g:6646:2: rule__LongComment__Group__1__Impl rule__LongComment__Group__2
            {
            pushFollow(FOLLOW_49);
            rule__LongComment__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LongComment__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__1"


    // $ANTLR start "rule__LongComment__Group__1__Impl"
    // InternalSM2.g:6653:1: rule__LongComment__Group__1__Impl : ( RULE_STRING ) ;
    public final void rule__LongComment__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6657:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6658:1: ( RULE_STRING )
            {
            // InternalSM2.g:6658:1: ( RULE_STRING )
            // InternalSM2.g:6659:2: RULE_STRING
            {
             before(grammarAccess.getLongCommentAccess().getSTRINGTerminalRuleCall_1()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getLongCommentAccess().getSTRINGTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__1__Impl"


    // $ANTLR start "rule__LongComment__Group__2"
    // InternalSM2.g:6668:1: rule__LongComment__Group__2 : rule__LongComment__Group__2__Impl ;
    public final void rule__LongComment__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6672:1: ( rule__LongComment__Group__2__Impl )
            // InternalSM2.g:6673:2: rule__LongComment__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__2"


    // $ANTLR start "rule__LongComment__Group__2__Impl"
    // InternalSM2.g:6679:1: rule__LongComment__Group__2__Impl : ( '*/' ) ;
    public final void rule__LongComment__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6683:1: ( ( '*/' ) )
            // InternalSM2.g:6684:1: ( '*/' )
            {
            // InternalSM2.g:6684:1: ( '*/' )
            // InternalSM2.g:6685:2: '*/'
            {
             before(grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2()); 
            match(input,93,FOLLOW_2); 
             after(grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__2__Impl"


    // $ANTLR start "rule__NegationExpression__Group__0"
    // InternalSM2.g:6695:1: rule__NegationExpression__Group__0 : rule__NegationExpression__Group__0__Impl rule__NegationExpression__Group__1 ;
    public final void rule__NegationExpression__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6699:1: ( rule__NegationExpression__Group__0__Impl rule__NegationExpression__Group__1 )
            // InternalSM2.g:6700:2: rule__NegationExpression__Group__0__Impl rule__NegationExpression__Group__1
            {
            pushFollow(FOLLOW_32);
            rule__NegationExpression__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__NegationExpression__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegationExpression__Group__0"


    // $ANTLR start "rule__NegationExpression__Group__0__Impl"
    // InternalSM2.g:6707:1: rule__NegationExpression__Group__0__Impl : ( ruleLogicalUnaryOperator ) ;
    public final void rule__NegationExpression__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6711:1: ( ( ruleLogicalUnaryOperator ) )
            // InternalSM2.g:6712:1: ( ruleLogicalUnaryOperator )
            {
            // InternalSM2.g:6712:1: ( ruleLogicalUnaryOperator )
            // InternalSM2.g:6713:2: ruleLogicalUnaryOperator
            {
             before(grammarAccess.getNegationExpressionAccess().getLogicalUnaryOperatorParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleLogicalUnaryOperator();

            state._fsp--;

             after(grammarAccess.getNegationExpressionAccess().getLogicalUnaryOperatorParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegationExpression__Group__0__Impl"


    // $ANTLR start "rule__NegationExpression__Group__1"
    // InternalSM2.g:6722:1: rule__NegationExpression__Group__1 : rule__NegationExpression__Group__1__Impl ;
    public final void rule__NegationExpression__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6726:1: ( rule__NegationExpression__Group__1__Impl )
            // InternalSM2.g:6727:2: rule__NegationExpression__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__NegationExpression__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegationExpression__Group__1"


    // $ANTLR start "rule__NegationExpression__Group__1__Impl"
    // InternalSM2.g:6733:1: rule__NegationExpression__Group__1__Impl : ( RULE_STRING ) ;
    public final void rule__NegationExpression__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6737:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6738:1: ( RULE_STRING )
            {
            // InternalSM2.g:6738:1: ( RULE_STRING )
            // InternalSM2.g:6739:2: RULE_STRING
            {
             before(grammarAccess.getNegationExpressionAccess().getSTRINGTerminalRuleCall_1()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getNegationExpressionAccess().getSTRINGTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegationExpression__Group__1__Impl"


    // $ANTLR start "rule__File__VersionAssignment_0"
    // InternalSM2.g:6749:1: rule__File__VersionAssignment_0 : ( ruleVersion ) ;
    public final void rule__File__VersionAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6753:1: ( ( ruleVersion ) )
            // InternalSM2.g:6754:2: ( ruleVersion )
            {
            // InternalSM2.g:6754:2: ( ruleVersion )
            // InternalSM2.g:6755:3: ruleVersion
            {
             before(grammarAccess.getFileAccess().getVersionVersionParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleVersion();

            state._fsp--;

             after(grammarAccess.getFileAccess().getVersionVersionParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__File__VersionAssignment_0"


    // $ANTLR start "rule__File__AttributesAssignment_2"
    // InternalSM2.g:6764:1: rule__File__AttributesAssignment_2 : ( ruleAttributes ) ;
    public final void rule__File__AttributesAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6768:1: ( ( ruleAttributes ) )
            // InternalSM2.g:6769:2: ( ruleAttributes )
            {
            // InternalSM2.g:6769:2: ( ruleAttributes )
            // InternalSM2.g:6770:3: ruleAttributes
            {
             before(grammarAccess.getFileAccess().getAttributesAttributesParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleAttributes();

            state._fsp--;

             after(grammarAccess.getFileAccess().getAttributesAttributesParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__File__AttributesAssignment_2"


    // $ANTLR start "rule__File__ContractAssignment_3"
    // InternalSM2.g:6779:1: rule__File__ContractAssignment_3 : ( ruleContract ) ;
    public final void rule__File__ContractAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6783:1: ( ( ruleContract ) )
            // InternalSM2.g:6784:2: ( ruleContract )
            {
            // InternalSM2.g:6784:2: ( ruleContract )
            // InternalSM2.g:6785:3: ruleContract
            {
             before(grammarAccess.getFileAccess().getContractContractParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleContract();

            state._fsp--;

             after(grammarAccess.getFileAccess().getContractContractParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__File__ContractAssignment_3"


    // $ANTLR start "rule__File__CommentsAssignment_4"
    // InternalSM2.g:6794:1: rule__File__CommentsAssignment_4 : ( ruleComment ) ;
    public final void rule__File__CommentsAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6798:1: ( ( ruleComment ) )
            // InternalSM2.g:6799:2: ( ruleComment )
            {
            // InternalSM2.g:6799:2: ( ruleComment )
            // InternalSM2.g:6800:3: ruleComment
            {
             before(grammarAccess.getFileAccess().getCommentsCommentParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleComment();

            state._fsp--;

             after(grammarAccess.getFileAccess().getCommentsCommentParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__File__CommentsAssignment_4"


    // $ANTLR start "rule__Contract__NameContractAssignment_1"
    // InternalSM2.g:6809:1: rule__Contract__NameContractAssignment_1 : ( RULE_ID ) ;
    public final void rule__Contract__NameContractAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6813:1: ( ( RULE_ID ) )
            // InternalSM2.g:6814:2: ( RULE_ID )
            {
            // InternalSM2.g:6814:2: ( RULE_ID )
            // InternalSM2.g:6815:3: RULE_ID
            {
             before(grammarAccess.getContractAccess().getNameContractIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getContractAccess().getNameContractIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__NameContractAssignment_1"


    // $ANTLR start "rule__Contract__NameContractFatherAssignment_2_1"
    // InternalSM2.g:6824:1: rule__Contract__NameContractFatherAssignment_2_1 : ( ( RULE_ID ) ) ;
    public final void rule__Contract__NameContractFatherAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6828:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:6829:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:6829:2: ( ( RULE_ID ) )
            // InternalSM2.g:6830:3: ( RULE_ID )
            {
             before(grammarAccess.getContractAccess().getNameContractFatherContractCrossReference_2_1_0()); 
            // InternalSM2.g:6831:3: ( RULE_ID )
            // InternalSM2.g:6832:4: RULE_ID
            {
             before(grammarAccess.getContractAccess().getNameContractFatherContractIDTerminalRuleCall_2_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getContractAccess().getNameContractFatherContractIDTerminalRuleCall_2_1_0_1()); 

            }

             after(grammarAccess.getContractAccess().getNameContractFatherContractCrossReference_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__NameContractFatherAssignment_2_1"


    // $ANTLR start "rule__Contract__ConstructorAssignment_5"
    // InternalSM2.g:6843:1: rule__Contract__ConstructorAssignment_5 : ( ruleConstructor ) ;
    public final void rule__Contract__ConstructorAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6847:1: ( ( ruleConstructor ) )
            // InternalSM2.g:6848:2: ( ruleConstructor )
            {
            // InternalSM2.g:6848:2: ( ruleConstructor )
            // InternalSM2.g:6849:3: ruleConstructor
            {
             before(grammarAccess.getContractAccess().getConstructorConstructorParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleConstructor();

            state._fsp--;

             after(grammarAccess.getContractAccess().getConstructorConstructorParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__ConstructorAssignment_5"


    // $ANTLR start "rule__Contract__CommentsAssignment_6"
    // InternalSM2.g:6858:1: rule__Contract__CommentsAssignment_6 : ( ruleComment ) ;
    public final void rule__Contract__CommentsAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6862:1: ( ( ruleComment ) )
            // InternalSM2.g:6863:2: ( ruleComment )
            {
            // InternalSM2.g:6863:2: ( ruleComment )
            // InternalSM2.g:6864:3: ruleComment
            {
             before(grammarAccess.getContractAccess().getCommentsCommentParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleComment();

            state._fsp--;

             after(grammarAccess.getContractAccess().getCommentsCommentParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__CommentsAssignment_6"


    // $ANTLR start "rule__Contract__AttributesAssignment_7"
    // InternalSM2.g:6873:1: rule__Contract__AttributesAssignment_7 : ( ruleAttributes ) ;
    public final void rule__Contract__AttributesAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6877:1: ( ( ruleAttributes ) )
            // InternalSM2.g:6878:2: ( ruleAttributes )
            {
            // InternalSM2.g:6878:2: ( ruleAttributes )
            // InternalSM2.g:6879:3: ruleAttributes
            {
             before(grammarAccess.getContractAccess().getAttributesAttributesParserRuleCall_7_0()); 
            pushFollow(FOLLOW_2);
            ruleAttributes();

            state._fsp--;

             after(grammarAccess.getContractAccess().getAttributesAttributesParserRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__AttributesAssignment_7"


    // $ANTLR start "rule__Contract__ModifierAssignment_8"
    // InternalSM2.g:6888:1: rule__Contract__ModifierAssignment_8 : ( ruleModifier ) ;
    public final void rule__Contract__ModifierAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6892:1: ( ( ruleModifier ) )
            // InternalSM2.g:6893:2: ( ruleModifier )
            {
            // InternalSM2.g:6893:2: ( ruleModifier )
            // InternalSM2.g:6894:3: ruleModifier
            {
             before(grammarAccess.getContractAccess().getModifierModifierParserRuleCall_8_0()); 
            pushFollow(FOLLOW_2);
            ruleModifier();

            state._fsp--;

             after(grammarAccess.getContractAccess().getModifierModifierParserRuleCall_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__ModifierAssignment_8"


    // $ANTLR start "rule__Contract__ClausesAssignment_9"
    // InternalSM2.g:6903:1: rule__Contract__ClausesAssignment_9 : ( ruleClause ) ;
    public final void rule__Contract__ClausesAssignment_9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6907:1: ( ( ruleClause ) )
            // InternalSM2.g:6908:2: ( ruleClause )
            {
            // InternalSM2.g:6908:2: ( ruleClause )
            // InternalSM2.g:6909:3: ruleClause
            {
             before(grammarAccess.getContractAccess().getClausesClauseParserRuleCall_9_0()); 
            pushFollow(FOLLOW_2);
            ruleClause();

            state._fsp--;

             after(grammarAccess.getContractAccess().getClausesClauseParserRuleCall_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Contract__ClausesAssignment_9"


    // $ANTLR start "rule__Version__SymbolAssignment_2"
    // InternalSM2.g:6918:1: rule__Version__SymbolAssignment_2 : ( ( rule__Version__SymbolAlternatives_2_0 ) ) ;
    public final void rule__Version__SymbolAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6922:1: ( ( ( rule__Version__SymbolAlternatives_2_0 ) ) )
            // InternalSM2.g:6923:2: ( ( rule__Version__SymbolAlternatives_2_0 ) )
            {
            // InternalSM2.g:6923:2: ( ( rule__Version__SymbolAlternatives_2_0 ) )
            // InternalSM2.g:6924:3: ( rule__Version__SymbolAlternatives_2_0 )
            {
             before(grammarAccess.getVersionAccess().getSymbolAlternatives_2_0()); 
            // InternalSM2.g:6925:3: ( rule__Version__SymbolAlternatives_2_0 )
            // InternalSM2.g:6925:4: rule__Version__SymbolAlternatives_2_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAlternatives_2_0();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getSymbolAlternatives_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAssignment_2"


    // $ANTLR start "rule__Version__NumberVersionAssignment_3"
    // InternalSM2.g:6933:1: rule__Version__NumberVersionAssignment_3 : ( RULE_NUMVERSION1 ) ;
    public final void rule__Version__NumberVersionAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6937:1: ( ( RULE_NUMVERSION1 ) )
            // InternalSM2.g:6938:2: ( RULE_NUMVERSION1 )
            {
            // InternalSM2.g:6938:2: ( RULE_NUMVERSION1 )
            // InternalSM2.g:6939:3: RULE_NUMVERSION1
            {
             before(grammarAccess.getVersionAccess().getNumberVersionNUMVERSION1TerminalRuleCall_3_0()); 
            match(input,RULE_NUMVERSION1,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersionNUMVERSION1TerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionAssignment_3"


    // $ANTLR start "rule__Version__NumberVersion2Assignment_5"
    // InternalSM2.g:6948:1: rule__Version__NumberVersion2Assignment_5 : ( RULE_NUMVERSION2 ) ;
    public final void rule__Version__NumberVersion2Assignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6952:1: ( ( RULE_NUMVERSION2 ) )
            // InternalSM2.g:6953:2: ( RULE_NUMVERSION2 )
            {
            // InternalSM2.g:6953:2: ( RULE_NUMVERSION2 )
            // InternalSM2.g:6954:3: RULE_NUMVERSION2
            {
             before(grammarAccess.getVersionAccess().getNumberVersion2NUMVERSION2TerminalRuleCall_5_0()); 
            match(input,RULE_NUMVERSION2,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersion2NUMVERSION2TerminalRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion2Assignment_5"


    // $ANTLR start "rule__Version__NumberVersion3Assignment_7"
    // InternalSM2.g:6963:1: rule__Version__NumberVersion3Assignment_7 : ( RULE_NUMVERSION3 ) ;
    public final void rule__Version__NumberVersion3Assignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6967:1: ( ( RULE_NUMVERSION3 ) )
            // InternalSM2.g:6968:2: ( RULE_NUMVERSION3 )
            {
            // InternalSM2.g:6968:2: ( RULE_NUMVERSION3 )
            // InternalSM2.g:6969:3: RULE_NUMVERSION3
            {
             before(grammarAccess.getVersionAccess().getNumberVersion3NUMVERSION3TerminalRuleCall_7_0()); 
            match(input,RULE_NUMVERSION3,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersion3NUMVERSION3TerminalRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion3Assignment_7"


    // $ANTLR start "rule__Version__OptionalversionAssignment_8"
    // InternalSM2.g:6978:1: rule__Version__OptionalversionAssignment_8 : ( ( RULE_ID ) ) ;
    public final void rule__Version__OptionalversionAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6982:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:6983:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:6983:2: ( ( RULE_ID ) )
            // InternalSM2.g:6984:3: ( RULE_ID )
            {
             before(grammarAccess.getVersionAccess().getOptionalversionVersionCrossReference_8_0()); 
            // InternalSM2.g:6985:3: ( RULE_ID )
            // InternalSM2.g:6986:4: RULE_ID
            {
             before(grammarAccess.getVersionAccess().getOptionalversionVersionIDTerminalRuleCall_8_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getOptionalversionVersionIDTerminalRuleCall_8_0_1()); 

            }

             after(grammarAccess.getVersionAccess().getOptionalversionVersionCrossReference_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__OptionalversionAssignment_8"


    // $ANTLR start "rule__Constructor__InputParamsAssignment_2"
    // InternalSM2.g:6997:1: rule__Constructor__InputParamsAssignment_2 : ( ruleInputParam ) ;
    public final void rule__Constructor__InputParamsAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7001:1: ( ( ruleInputParam ) )
            // InternalSM2.g:7002:2: ( ruleInputParam )
            {
            // InternalSM2.g:7002:2: ( ruleInputParam )
            // InternalSM2.g:7003:3: ruleInputParam
            {
             before(grammarAccess.getConstructorAccess().getInputParamsInputParamParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleInputParam();

            state._fsp--;

             after(grammarAccess.getConstructorAccess().getInputParamsInputParamParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__InputParamsAssignment_2"


    // $ANTLR start "rule__Constructor__TypeAssignment_3"
    // InternalSM2.g:7012:1: rule__Constructor__TypeAssignment_3 : ( ( rule__Constructor__TypeAlternatives_3_0 ) ) ;
    public final void rule__Constructor__TypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7016:1: ( ( ( rule__Constructor__TypeAlternatives_3_0 ) ) )
            // InternalSM2.g:7017:2: ( ( rule__Constructor__TypeAlternatives_3_0 ) )
            {
            // InternalSM2.g:7017:2: ( ( rule__Constructor__TypeAlternatives_3_0 ) )
            // InternalSM2.g:7018:3: ( rule__Constructor__TypeAlternatives_3_0 )
            {
             before(grammarAccess.getConstructorAccess().getTypeAlternatives_3_0()); 
            // InternalSM2.g:7019:3: ( rule__Constructor__TypeAlternatives_3_0 )
            // InternalSM2.g:7019:4: rule__Constructor__TypeAlternatives_3_0
            {
            pushFollow(FOLLOW_2);
            rule__Constructor__TypeAlternatives_3_0();

            state._fsp--;


            }

             after(grammarAccess.getConstructorAccess().getTypeAlternatives_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__TypeAssignment_3"


    // $ANTLR start "rule__Constructor__AttributesAssignment_6"
    // InternalSM2.g:7027:1: rule__Constructor__AttributesAssignment_6 : ( ruleAttributes ) ;
    public final void rule__Constructor__AttributesAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7031:1: ( ( ruleAttributes ) )
            // InternalSM2.g:7032:2: ( ruleAttributes )
            {
            // InternalSM2.g:7032:2: ( ruleAttributes )
            // InternalSM2.g:7033:3: ruleAttributes
            {
             before(grammarAccess.getConstructorAccess().getAttributesAttributesParserRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleAttributes();

            state._fsp--;

             after(grammarAccess.getConstructorAccess().getAttributesAttributesParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__AttributesAssignment_6"


    // $ANTLR start "rule__Modifier__NameModifierAssignment_1"
    // InternalSM2.g:7042:1: rule__Modifier__NameModifierAssignment_1 : ( RULE_ID ) ;
    public final void rule__Modifier__NameModifierAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7046:1: ( ( RULE_ID ) )
            // InternalSM2.g:7047:2: ( RULE_ID )
            {
            // InternalSM2.g:7047:2: ( RULE_ID )
            // InternalSM2.g:7048:3: RULE_ID
            {
             before(grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__NameModifierAssignment_1"


    // $ANTLR start "rule__Modifier__InputParamsAssignment_3"
    // InternalSM2.g:7057:1: rule__Modifier__InputParamsAssignment_3 : ( ruleInputParam ) ;
    public final void rule__Modifier__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7061:1: ( ( ruleInputParam ) )
            // InternalSM2.g:7062:2: ( ruleInputParam )
            {
            // InternalSM2.g:7062:2: ( ruleInputParam )
            // InternalSM2.g:7063:3: ruleInputParam
            {
             before(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleInputParam();

            state._fsp--;

             after(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__InputParamsAssignment_3"


    // $ANTLR start "rule__Modifier__ExprAssignment_7"
    // InternalSM2.g:7072:1: rule__Modifier__ExprAssignment_7 : ( RULE_STRING ) ;
    public final void rule__Modifier__ExprAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7076:1: ( ( RULE_STRING ) )
            // InternalSM2.g:7077:2: ( RULE_STRING )
            {
            // InternalSM2.g:7077:2: ( RULE_STRING )
            // InternalSM2.g:7078:3: RULE_STRING
            {
             before(grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__ExprAssignment_7"


    // $ANTLR start "rule__SingularType__INTAssignment_0"
    // InternalSM2.g:7087:1: rule__SingularType__INTAssignment_0 : ( ( 'int' ) ) ;
    public final void rule__SingularType__INTAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7091:1: ( ( ( 'int' ) ) )
            // InternalSM2.g:7092:2: ( ( 'int' ) )
            {
            // InternalSM2.g:7092:2: ( ( 'int' ) )
            // InternalSM2.g:7093:3: ( 'int' )
            {
             before(grammarAccess.getSingularTypeAccess().getINTIntKeyword_0_0()); 
            // InternalSM2.g:7094:3: ( 'int' )
            // InternalSM2.g:7095:4: 'int'
            {
             before(grammarAccess.getSingularTypeAccess().getINTIntKeyword_0_0()); 
            match(input,94,FOLLOW_2); 
             after(grammarAccess.getSingularTypeAccess().getINTIntKeyword_0_0()); 

            }

             after(grammarAccess.getSingularTypeAccess().getINTIntKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingularType__INTAssignment_0"


    // $ANTLR start "rule__SingularType__UINTAssignment_1"
    // InternalSM2.g:7106:1: rule__SingularType__UINTAssignment_1 : ( ( 'uint' ) ) ;
    public final void rule__SingularType__UINTAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7110:1: ( ( ( 'uint' ) ) )
            // InternalSM2.g:7111:2: ( ( 'uint' ) )
            {
            // InternalSM2.g:7111:2: ( ( 'uint' ) )
            // InternalSM2.g:7112:3: ( 'uint' )
            {
             before(grammarAccess.getSingularTypeAccess().getUINTUintKeyword_1_0()); 
            // InternalSM2.g:7113:3: ( 'uint' )
            // InternalSM2.g:7114:4: 'uint'
            {
             before(grammarAccess.getSingularTypeAccess().getUINTUintKeyword_1_0()); 
            match(input,95,FOLLOW_2); 
             after(grammarAccess.getSingularTypeAccess().getUINTUintKeyword_1_0()); 

            }

             after(grammarAccess.getSingularTypeAccess().getUINTUintKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingularType__UINTAssignment_1"


    // $ANTLR start "rule__SingularType__UINT8Assignment_2"
    // InternalSM2.g:7125:1: rule__SingularType__UINT8Assignment_2 : ( ( 'uint8' ) ) ;
    public final void rule__SingularType__UINT8Assignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7129:1: ( ( ( 'uint8' ) ) )
            // InternalSM2.g:7130:2: ( ( 'uint8' ) )
            {
            // InternalSM2.g:7130:2: ( ( 'uint8' ) )
            // InternalSM2.g:7131:3: ( 'uint8' )
            {
             before(grammarAccess.getSingularTypeAccess().getUINT8Uint8Keyword_2_0()); 
            // InternalSM2.g:7132:3: ( 'uint8' )
            // InternalSM2.g:7133:4: 'uint8'
            {
             before(grammarAccess.getSingularTypeAccess().getUINT8Uint8Keyword_2_0()); 
            match(input,96,FOLLOW_2); 
             after(grammarAccess.getSingularTypeAccess().getUINT8Uint8Keyword_2_0()); 

            }

             after(grammarAccess.getSingularTypeAccess().getUINT8Uint8Keyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingularType__UINT8Assignment_2"


    // $ANTLR start "rule__SingularType__STRINGAssignment_3"
    // InternalSM2.g:7144:1: rule__SingularType__STRINGAssignment_3 : ( ( 'string' ) ) ;
    public final void rule__SingularType__STRINGAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7148:1: ( ( ( 'string' ) ) )
            // InternalSM2.g:7149:2: ( ( 'string' ) )
            {
            // InternalSM2.g:7149:2: ( ( 'string' ) )
            // InternalSM2.g:7150:3: ( 'string' )
            {
             before(grammarAccess.getSingularTypeAccess().getSTRINGStringKeyword_3_0()); 
            // InternalSM2.g:7151:3: ( 'string' )
            // InternalSM2.g:7152:4: 'string'
            {
             before(grammarAccess.getSingularTypeAccess().getSTRINGStringKeyword_3_0()); 
            match(input,97,FOLLOW_2); 
             after(grammarAccess.getSingularTypeAccess().getSTRINGStringKeyword_3_0()); 

            }

             after(grammarAccess.getSingularTypeAccess().getSTRINGStringKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingularType__STRINGAssignment_3"


    // $ANTLR start "rule__SingularType__ADDRESSAssignment_4"
    // InternalSM2.g:7163:1: rule__SingularType__ADDRESSAssignment_4 : ( ( 'address' ) ) ;
    public final void rule__SingularType__ADDRESSAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7167:1: ( ( ( 'address' ) ) )
            // InternalSM2.g:7168:2: ( ( 'address' ) )
            {
            // InternalSM2.g:7168:2: ( ( 'address' ) )
            // InternalSM2.g:7169:3: ( 'address' )
            {
             before(grammarAccess.getSingularTypeAccess().getADDRESSAddressKeyword_4_0()); 
            // InternalSM2.g:7170:3: ( 'address' )
            // InternalSM2.g:7171:4: 'address'
            {
             before(grammarAccess.getSingularTypeAccess().getADDRESSAddressKeyword_4_0()); 
            match(input,98,FOLLOW_2); 
             after(grammarAccess.getSingularTypeAccess().getADDRESSAddressKeyword_4_0()); 

            }

             after(grammarAccess.getSingularTypeAccess().getADDRESSAddressKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingularType__ADDRESSAssignment_4"


    // $ANTLR start "rule__SingularType__ADDRESSPAYABLEAssignment_5"
    // InternalSM2.g:7182:1: rule__SingularType__ADDRESSPAYABLEAssignment_5 : ( ( 'address payable' ) ) ;
    public final void rule__SingularType__ADDRESSPAYABLEAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7186:1: ( ( ( 'address payable' ) ) )
            // InternalSM2.g:7187:2: ( ( 'address payable' ) )
            {
            // InternalSM2.g:7187:2: ( ( 'address payable' ) )
            // InternalSM2.g:7188:3: ( 'address payable' )
            {
             before(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEAddressPayableKeyword_5_0()); 
            // InternalSM2.g:7189:3: ( 'address payable' )
            // InternalSM2.g:7190:4: 'address payable'
            {
             before(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEAddressPayableKeyword_5_0()); 
            match(input,99,FOLLOW_2); 
             after(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEAddressPayableKeyword_5_0()); 

            }

             after(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEAddressPayableKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingularType__ADDRESSPAYABLEAssignment_5"


    // $ANTLR start "rule__SingularType__DOUBLEAssignment_6"
    // InternalSM2.g:7201:1: rule__SingularType__DOUBLEAssignment_6 : ( ( 'double' ) ) ;
    public final void rule__SingularType__DOUBLEAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7205:1: ( ( ( 'double' ) ) )
            // InternalSM2.g:7206:2: ( ( 'double' ) )
            {
            // InternalSM2.g:7206:2: ( ( 'double' ) )
            // InternalSM2.g:7207:3: ( 'double' )
            {
             before(grammarAccess.getSingularTypeAccess().getDOUBLEDoubleKeyword_6_0()); 
            // InternalSM2.g:7208:3: ( 'double' )
            // InternalSM2.g:7209:4: 'double'
            {
             before(grammarAccess.getSingularTypeAccess().getDOUBLEDoubleKeyword_6_0()); 
            match(input,100,FOLLOW_2); 
             after(grammarAccess.getSingularTypeAccess().getDOUBLEDoubleKeyword_6_0()); 

            }

             after(grammarAccess.getSingularTypeAccess().getDOUBLEDoubleKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingularType__DOUBLEAssignment_6"


    // $ANTLR start "rule__SingularType__BOOLEANAssignment_7"
    // InternalSM2.g:7220:1: rule__SingularType__BOOLEANAssignment_7 : ( ( 'bool' ) ) ;
    public final void rule__SingularType__BOOLEANAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7224:1: ( ( ( 'bool' ) ) )
            // InternalSM2.g:7225:2: ( ( 'bool' ) )
            {
            // InternalSM2.g:7225:2: ( ( 'bool' ) )
            // InternalSM2.g:7226:3: ( 'bool' )
            {
             before(grammarAccess.getSingularTypeAccess().getBOOLEANBoolKeyword_7_0()); 
            // InternalSM2.g:7227:3: ( 'bool' )
            // InternalSM2.g:7228:4: 'bool'
            {
             before(grammarAccess.getSingularTypeAccess().getBOOLEANBoolKeyword_7_0()); 
            match(input,101,FOLLOW_2); 
             after(grammarAccess.getSingularTypeAccess().getBOOLEANBoolKeyword_7_0()); 

            }

             after(grammarAccess.getSingularTypeAccess().getBOOLEANBoolKeyword_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingularType__BOOLEANAssignment_7"


    // $ANTLR start "rule__Mapping__TypeAssignment_2"
    // InternalSM2.g:7239:1: rule__Mapping__TypeAssignment_2 : ( ruleSingularType ) ;
    public final void rule__Mapping__TypeAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7243:1: ( ( ruleSingularType ) )
            // InternalSM2.g:7244:2: ( ruleSingularType )
            {
            // InternalSM2.g:7244:2: ( ruleSingularType )
            // InternalSM2.g:7245:3: ruleSingularType
            {
             before(grammarAccess.getMappingAccess().getTypeSingularTypeParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;

             after(grammarAccess.getMappingAccess().getTypeSingularTypeParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__TypeAssignment_2"


    // $ANTLR start "rule__Mapping__ExprAssignment_4"
    // InternalSM2.g:7254:1: rule__Mapping__ExprAssignment_4 : ( RULE_STRING ) ;
    public final void rule__Mapping__ExprAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7258:1: ( ( RULE_STRING ) )
            // InternalSM2.g:7259:2: ( RULE_STRING )
            {
            // InternalSM2.g:7259:2: ( RULE_STRING )
            // InternalSM2.g:7260:3: RULE_STRING
            {
             before(grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__ExprAssignment_4"


    // $ANTLR start "rule__Mapping__VisibilityAssignment_6"
    // InternalSM2.g:7269:1: rule__Mapping__VisibilityAssignment_6 : ( ruleVisibility ) ;
    public final void rule__Mapping__VisibilityAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7273:1: ( ( ruleVisibility ) )
            // InternalSM2.g:7274:2: ( ruleVisibility )
            {
            // InternalSM2.g:7274:2: ( ruleVisibility )
            // InternalSM2.g:7275:3: ruleVisibility
            {
             before(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__VisibilityAssignment_6"


    // $ANTLR start "rule__Mapping__NameMappingAssignment_7"
    // InternalSM2.g:7284:1: rule__Mapping__NameMappingAssignment_7 : ( RULE_ID ) ;
    public final void rule__Mapping__NameMappingAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7288:1: ( ( RULE_ID ) )
            // InternalSM2.g:7289:2: ( RULE_ID )
            {
            // InternalSM2.g:7289:2: ( RULE_ID )
            // InternalSM2.g:7290:3: RULE_ID
            {
             before(grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__NameMappingAssignment_7"


    // $ANTLR start "rule__Struct__NameStructAssignment_1"
    // InternalSM2.g:7299:1: rule__Struct__NameStructAssignment_1 : ( RULE_ID ) ;
    public final void rule__Struct__NameStructAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7303:1: ( ( RULE_ID ) )
            // InternalSM2.g:7304:2: ( RULE_ID )
            {
            // InternalSM2.g:7304:2: ( RULE_ID )
            // InternalSM2.g:7305:3: RULE_ID
            {
             before(grammarAccess.getStructAccess().getNameStructIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getStructAccess().getNameStructIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__NameStructAssignment_1"


    // $ANTLR start "rule__Struct__PropertiesAssignment_4"
    // InternalSM2.g:7314:1: rule__Struct__PropertiesAssignment_4 : ( ruleProperty ) ;
    public final void rule__Struct__PropertiesAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7318:1: ( ( ruleProperty ) )
            // InternalSM2.g:7319:2: ( ruleProperty )
            {
            // InternalSM2.g:7319:2: ( ruleProperty )
            // InternalSM2.g:7320:3: ruleProperty
            {
             before(grammarAccess.getStructAccess().getPropertiesPropertyParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleProperty();

            state._fsp--;

             after(grammarAccess.getStructAccess().getPropertiesPropertyParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__PropertiesAssignment_4"


    // $ANTLR start "rule__Property__TypeAssignment_0"
    // InternalSM2.g:7329:1: rule__Property__TypeAssignment_0 : ( ruleSingularType ) ;
    public final void rule__Property__TypeAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7333:1: ( ( ruleSingularType ) )
            // InternalSM2.g:7334:2: ( ruleSingularType )
            {
            // InternalSM2.g:7334:2: ( ruleSingularType )
            // InternalSM2.g:7335:3: ruleSingularType
            {
             before(grammarAccess.getPropertyAccess().getTypeSingularTypeParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;

             after(grammarAccess.getPropertyAccess().getTypeSingularTypeParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__TypeAssignment_0"


    // $ANTLR start "rule__Property__VisibilityAssignment_1"
    // InternalSM2.g:7344:1: rule__Property__VisibilityAssignment_1 : ( ruleVisibility ) ;
    public final void rule__Property__VisibilityAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7348:1: ( ( ruleVisibility ) )
            // InternalSM2.g:7349:2: ( ruleVisibility )
            {
            // InternalSM2.g:7349:2: ( ruleVisibility )
            // InternalSM2.g:7350:3: ruleVisibility
            {
             before(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__VisibilityAssignment_1"


    // $ANTLR start "rule__Property__NamePropertyAssignment_2"
    // InternalSM2.g:7359:1: rule__Property__NamePropertyAssignment_2 : ( RULE_ID ) ;
    public final void rule__Property__NamePropertyAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7363:1: ( ( RULE_ID ) )
            // InternalSM2.g:7364:2: ( RULE_ID )
            {
            // InternalSM2.g:7364:2: ( RULE_ID )
            // InternalSM2.g:7365:3: RULE_ID
            {
             before(grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__NamePropertyAssignment_2"


    // $ANTLR start "rule__Property__InicializationAssignment_4_0"
    // InternalSM2.g:7374:1: rule__Property__InicializationAssignment_4_0 : ( RULE_STRING ) ;
    public final void rule__Property__InicializationAssignment_4_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7378:1: ( ( RULE_STRING ) )
            // InternalSM2.g:7379:2: ( RULE_STRING )
            {
            // InternalSM2.g:7379:2: ( RULE_STRING )
            // InternalSM2.g:7380:3: RULE_STRING
            {
             before(grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__InicializationAssignment_4_0"


    // $ANTLR start "rule__InputParam__NameParamAssignment_1"
    // InternalSM2.g:7389:1: rule__InputParam__NameParamAssignment_1 : ( RULE_ID ) ;
    public final void rule__InputParam__NameParamAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7393:1: ( ( RULE_ID ) )
            // InternalSM2.g:7394:2: ( RULE_ID )
            {
            // InternalSM2.g:7394:2: ( RULE_ID )
            // InternalSM2.g:7395:3: RULE_ID
            {
             before(grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__NameParamAssignment_1"


    // $ANTLR start "rule__Restriction__ExprAssignment_2"
    // InternalSM2.g:7404:1: rule__Restriction__ExprAssignment_2 : ( ruleSyntaxExpression ) ;
    public final void rule__Restriction__ExprAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7408:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:7409:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:7409:2: ( ruleSyntaxExpression )
            // InternalSM2.g:7410:3: ruleSyntaxExpression
            {
             before(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__ExprAssignment_2"


    // $ANTLR start "rule__Restriction__OperatorAssignment_3"
    // InternalSM2.g:7419:1: rule__Restriction__OperatorAssignment_3 : ( ruleComparationOperator ) ;
    public final void rule__Restriction__OperatorAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7423:1: ( ( ruleComparationOperator ) )
            // InternalSM2.g:7424:2: ( ruleComparationOperator )
            {
            // InternalSM2.g:7424:2: ( ruleComparationOperator )
            // InternalSM2.g:7425:3: ruleComparationOperator
            {
             before(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleComparationOperator();

            state._fsp--;

             after(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__OperatorAssignment_3"


    // $ANTLR start "rule__Restriction__ExprAssignment_4"
    // InternalSM2.g:7434:1: rule__Restriction__ExprAssignment_4 : ( ruleSyntaxExpression ) ;
    public final void rule__Restriction__ExprAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7438:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:7439:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:7439:2: ( ruleSyntaxExpression )
            // InternalSM2.g:7440:3: ruleSyntaxExpression
            {
             before(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__ExprAssignment_4"


    // $ANTLR start "rule__RestrictionGas__ExprAssignment_2"
    // InternalSM2.g:7449:1: rule__RestrictionGas__ExprAssignment_2 : ( ruleSyntaxExpression ) ;
    public final void rule__RestrictionGas__ExprAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7453:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:7454:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:7454:2: ( ruleSyntaxExpression )
            // InternalSM2.g:7455:3: ruleSyntaxExpression
            {
             before(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__ExprAssignment_2"


    // $ANTLR start "rule__RestrictionGas__OperatorAssignment_3"
    // InternalSM2.g:7464:1: rule__RestrictionGas__OperatorAssignment_3 : ( ruleComparationOperator ) ;
    public final void rule__RestrictionGas__OperatorAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7468:1: ( ( ruleComparationOperator ) )
            // InternalSM2.g:7469:2: ( ruleComparationOperator )
            {
            // InternalSM2.g:7469:2: ( ruleComparationOperator )
            // InternalSM2.g:7470:3: ruleComparationOperator
            {
             before(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleComparationOperator();

            state._fsp--;

             after(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__OperatorAssignment_3"


    // $ANTLR start "rule__RestrictionGas__AmountAssignment_4"
    // InternalSM2.g:7479:1: rule__RestrictionGas__AmountAssignment_4 : ( RULE_INT ) ;
    public final void rule__RestrictionGas__AmountAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7483:1: ( ( RULE_INT ) )
            // InternalSM2.g:7484:2: ( RULE_INT )
            {
            // InternalSM2.g:7484:2: ( RULE_INT )
            // InternalSM2.g:7485:3: RULE_INT
            {
             before(grammarAccess.getRestrictionGasAccess().getAmountINTTerminalRuleCall_4_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getAmountINTTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__AmountAssignment_4"


    // $ANTLR start "rule__RestrictionGas__TypeCoinAssignment_5"
    // InternalSM2.g:7494:1: rule__RestrictionGas__TypeCoinAssignment_5 : ( ruleCoin ) ;
    public final void rule__RestrictionGas__TypeCoinAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7498:1: ( ( ruleCoin ) )
            // InternalSM2.g:7499:2: ( ruleCoin )
            {
            // InternalSM2.g:7499:2: ( ruleCoin )
            // InternalSM2.g:7500:3: ruleCoin
            {
             before(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleCoin();

            state._fsp--;

             after(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__TypeCoinAssignment_5"


    // $ANTLR start "rule__Clause__NameFunctionAssignment_1"
    // InternalSM2.g:7509:1: rule__Clause__NameFunctionAssignment_1 : ( RULE_ID ) ;
    public final void rule__Clause__NameFunctionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7513:1: ( ( RULE_ID ) )
            // InternalSM2.g:7514:2: ( RULE_ID )
            {
            // InternalSM2.g:7514:2: ( RULE_ID )
            // InternalSM2.g:7515:3: RULE_ID
            {
             before(grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__NameFunctionAssignment_1"


    // $ANTLR start "rule__Clause__InputParamsAssignment_3"
    // InternalSM2.g:7524:1: rule__Clause__InputParamsAssignment_3 : ( ruleInputParam ) ;
    public final void rule__Clause__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7528:1: ( ( ruleInputParam ) )
            // InternalSM2.g:7529:2: ( ruleInputParam )
            {
            // InternalSM2.g:7529:2: ( ruleInputParam )
            // InternalSM2.g:7530:3: ruleInputParam
            {
             before(grammarAccess.getClauseAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleInputParam();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getInputParamsInputParamParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__InputParamsAssignment_3"


    // $ANTLR start "rule__Clause__VisibilityAccessAssignment_4"
    // InternalSM2.g:7539:1: rule__Clause__VisibilityAccessAssignment_4 : ( ruleVisibility ) ;
    public final void rule__Clause__VisibilityAccessAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7543:1: ( ( ruleVisibility ) )
            // InternalSM2.g:7544:2: ( ruleVisibility )
            {
            // InternalSM2.g:7544:2: ( ruleVisibility )
            // InternalSM2.g:7545:3: ruleVisibility
            {
             before(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__VisibilityAccessAssignment_4"


    // $ANTLR start "rule__Clause__RestrictionAssignment_8"
    // InternalSM2.g:7554:1: rule__Clause__RestrictionAssignment_8 : ( ruleRestrictionClause ) ;
    public final void rule__Clause__RestrictionAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7558:1: ( ( ruleRestrictionClause ) )
            // InternalSM2.g:7559:2: ( ruleRestrictionClause )
            {
            // InternalSM2.g:7559:2: ( ruleRestrictionClause )
            // InternalSM2.g:7560:3: ruleRestrictionClause
            {
             before(grammarAccess.getClauseAccess().getRestrictionRestrictionClauseParserRuleCall_8_0()); 
            pushFollow(FOLLOW_2);
            ruleRestrictionClause();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getRestrictionRestrictionClauseParserRuleCall_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__RestrictionAssignment_8"


    // $ANTLR start "rule__Clause__ExpressionAssignment_9"
    // InternalSM2.g:7569:1: rule__Clause__ExpressionAssignment_9 : ( ruleExpression ) ;
    public final void rule__Clause__ExpressionAssignment_9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7573:1: ( ( ruleExpression ) )
            // InternalSM2.g:7574:2: ( ruleExpression )
            {
            // InternalSM2.g:7574:2: ( ruleExpression )
            // InternalSM2.g:7575:3: ruleExpression
            {
             before(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_9_0()); 
            pushFollow(FOLLOW_2);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__ExpressionAssignment_9"

    // Delegated rules


    protected DFA15 dfa15 = new DFA15(this);
    static final String dfa_1s = "\16\uffff";
    static final String dfa_2s = "\1\125\1\7\1\15\1\11\1\12\6\5\1\60\2\uffff";
    static final String dfa_3s = "\1\125\1\7\1\15\1\76\1\12\6\15\1\76\2\uffff";
    static final String dfa_4s = "\14\uffff\1\1\1\2";
    static final String dfa_5s = "\16\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\4\46\uffff\1\5\1\7\11\uffff\1\6\1\10\1\11\1\12",
            "\1\13",
            "\1\15\7\uffff\1\14",
            "\1\15\7\uffff\1\14",
            "\1\15\7\uffff\1\14",
            "\1\15\7\uffff\1\14",
            "\1\15\7\uffff\1\14",
            "\1\15\7\uffff\1\14",
            "\1\5\1\7\11\uffff\1\6\1\10\1\11\1\12",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA15 extends DFA {

        public DFA15(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 15;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "1298:1: rule__RestrictionClause__Alternatives : ( ( ruleRestriction ) | ( ruleRestrictionGas ) );";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000000L,0x0000000000002000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L,0x00000000000D0100L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000012L,0x00000000000D0000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000000L,0x0000000018000000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000002L,0x0000000018000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x00001F0000000000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000008000002000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000800L,0x0000000000000200L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000000400L,0x0000000000001000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000001010L,0x00000000184D4000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000000002L,0x0000000000004000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000000002L,0x0000000000400000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0003800000000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x000C000000000000L,0x0000003FC0000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000000000002L,0x0000003FC0000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000000010L,0x00000000000D0000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000000000100L,0x0000003FC0000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000000000002400L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000000400L,0x0000000000008000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000000000000000L,0x0000003FC0000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x001C000000000010L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000000000400L,0x0000003FC0000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000000000005000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000000000L,0x0000000000100000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000000002220L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x7803000000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x07E0000000000000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x001C000000000000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000008000003400L,0x0000000000200000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});

}