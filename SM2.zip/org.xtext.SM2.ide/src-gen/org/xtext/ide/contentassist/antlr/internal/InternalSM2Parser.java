package org.xtext.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_OPENKEY", "RULE_CLOSEKEY", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_COMMA", "RULE_NUMBER", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'^'", "'>'", "'>='", "'int'", "'uint'", "'uint8'", "'uint256'", "'string'", "'address'", "'address payable'", "'double'", "'bool'", "'public'", "'private'", "'internal'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'<'", "'<='", "'=='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'", "'solidity'", "'is'", "'.'", "'import'", "'as'", "'event'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'enum'", "'='", "'require'", "'function'", "'selfdesctruct'", "'//'", "'/*'", "'*/'", "'pragma'", "'contract'"
    };
    public static final int T__50=50;
    public static final int RULE_OPENPARENTHESIS=10;
    public static final int T__19=19;
    public static final int RULE_EOLINE=7;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int RULE_CLOSEKEY=9;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int RULE_COMMA=12;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=5;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=15;
    public static final int T__23=23;
    public static final int T__67=67;
    public static final int T__24=24;
    public static final int T__68=68;
    public static final int T__25=25;
    public static final int T__69=69;
    public static final int RULE_SEMICOLON=6;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__20=20;
    public static final int T__64=64;
    public static final int T__21=21;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int RULE_STRING=14;
    public static final int RULE_SL_COMMENT=16;
    public static final int T__37=37;
    public static final int RULE_OPENKEY=8;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int RULE_CLOSEPARENTHESIS=11;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=17;
    public static final int RULE_ANY_OTHER=18;
    public static final int RULE_NUMBER=13;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }


    	private SM2GrammarAccess grammarAccess;

    	public void setGrammarAccess(SM2GrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleSmartContract"
    // InternalSM2.g:53:1: entryRuleSmartContract : ruleSmartContract EOF ;
    public final void entryRuleSmartContract() throws RecognitionException {
        try {
            // InternalSM2.g:54:1: ( ruleSmartContract EOF )
            // InternalSM2.g:55:1: ruleSmartContract EOF
            {
             before(grammarAccess.getSmartContractRule()); 
            pushFollow(FOLLOW_1);
            ruleSmartContract();

            state._fsp--;

             after(grammarAccess.getSmartContractRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSmartContract"


    // $ANTLR start "ruleSmartContract"
    // InternalSM2.g:62:1: ruleSmartContract : ( ( rule__SmartContract__Group__0 ) ) ;
    public final void ruleSmartContract() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:66:2: ( ( ( rule__SmartContract__Group__0 ) ) )
            // InternalSM2.g:67:2: ( ( rule__SmartContract__Group__0 ) )
            {
            // InternalSM2.g:67:2: ( ( rule__SmartContract__Group__0 ) )
            // InternalSM2.g:68:3: ( rule__SmartContract__Group__0 )
            {
             before(grammarAccess.getSmartContractAccess().getGroup()); 
            // InternalSM2.g:69:3: ( rule__SmartContract__Group__0 )
            // InternalSM2.g:69:4: rule__SmartContract__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSmartContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:78:1: entryRuleVersion : ruleVersion EOF ;
    public final void entryRuleVersion() throws RecognitionException {
        try {
            // InternalSM2.g:79:1: ( ruleVersion EOF )
            // InternalSM2.g:80:1: ruleVersion EOF
            {
             before(grammarAccess.getVersionRule()); 
            pushFollow(FOLLOW_1);
            ruleVersion();

            state._fsp--;

             after(grammarAccess.getVersionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:87:1: ruleVersion : ( ( rule__Version__Group__0 ) ) ;
    public final void ruleVersion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:91:2: ( ( ( rule__Version__Group__0 ) ) )
            // InternalSM2.g:92:2: ( ( rule__Version__Group__0 ) )
            {
            // InternalSM2.g:92:2: ( ( rule__Version__Group__0 ) )
            // InternalSM2.g:93:3: ( rule__Version__Group__0 )
            {
             before(grammarAccess.getVersionAccess().getGroup()); 
            // InternalSM2.g:94:3: ( rule__Version__Group__0 )
            // InternalSM2.g:94:4: rule__Version__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleImport"
    // InternalSM2.g:103:1: entryRuleImport : ruleImport EOF ;
    public final void entryRuleImport() throws RecognitionException {
        try {
            // InternalSM2.g:104:1: ( ruleImport EOF )
            // InternalSM2.g:105:1: ruleImport EOF
            {
             before(grammarAccess.getImportRule()); 
            pushFollow(FOLLOW_1);
            ruleImport();

            state._fsp--;

             after(grammarAccess.getImportRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2.g:112:1: ruleImport : ( ( rule__Import__Group__0 ) ) ;
    public final void ruleImport() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:116:2: ( ( ( rule__Import__Group__0 ) ) )
            // InternalSM2.g:117:2: ( ( rule__Import__Group__0 ) )
            {
            // InternalSM2.g:117:2: ( ( rule__Import__Group__0 ) )
            // InternalSM2.g:118:3: ( rule__Import__Group__0 )
            {
             before(grammarAccess.getImportAccess().getGroup()); 
            // InternalSM2.g:119:3: ( rule__Import__Group__0 )
            // InternalSM2.g:119:4: rule__Import__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getImportAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:128:1: entryRuleAttributes : ruleAttributes EOF ;
    public final void entryRuleAttributes() throws RecognitionException {
        try {
            // InternalSM2.g:129:1: ( ruleAttributes EOF )
            // InternalSM2.g:130:1: ruleAttributes EOF
            {
             before(grammarAccess.getAttributesRule()); 
            pushFollow(FOLLOW_1);
            ruleAttributes();

            state._fsp--;

             after(grammarAccess.getAttributesRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:137:1: ruleAttributes : ( ( rule__Attributes__Alternatives ) ) ;
    public final void ruleAttributes() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:141:2: ( ( ( rule__Attributes__Alternatives ) ) )
            // InternalSM2.g:142:2: ( ( rule__Attributes__Alternatives ) )
            {
            // InternalSM2.g:142:2: ( ( rule__Attributes__Alternatives ) )
            // InternalSM2.g:143:3: ( rule__Attributes__Alternatives )
            {
             before(grammarAccess.getAttributesAccess().getAlternatives()); 
            // InternalSM2.g:144:3: ( rule__Attributes__Alternatives )
            // InternalSM2.g:144:4: rule__Attributes__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Attributes__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getAttributesAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleEvent"
    // InternalSM2.g:153:1: entryRuleEvent : ruleEvent EOF ;
    public final void entryRuleEvent() throws RecognitionException {
        try {
            // InternalSM2.g:154:1: ( ruleEvent EOF )
            // InternalSM2.g:155:1: ruleEvent EOF
            {
             before(grammarAccess.getEventRule()); 
            pushFollow(FOLLOW_1);
            ruleEvent();

            state._fsp--;

             after(grammarAccess.getEventRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalSM2.g:162:1: ruleEvent : ( ( rule__Event__Group__0 ) ) ;
    public final void ruleEvent() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:166:2: ( ( ( rule__Event__Group__0 ) ) )
            // InternalSM2.g:167:2: ( ( rule__Event__Group__0 ) )
            {
            // InternalSM2.g:167:2: ( ( rule__Event__Group__0 ) )
            // InternalSM2.g:168:3: ( rule__Event__Group__0 )
            {
             before(grammarAccess.getEventAccess().getGroup()); 
            // InternalSM2.g:169:3: ( rule__Event__Group__0 )
            // InternalSM2.g:169:4: rule__Event__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Event__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEventAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:178:1: entryRuleModifier : ruleModifier EOF ;
    public final void entryRuleModifier() throws RecognitionException {
        try {
            // InternalSM2.g:179:1: ( ruleModifier EOF )
            // InternalSM2.g:180:1: ruleModifier EOF
            {
             before(grammarAccess.getModifierRule()); 
            pushFollow(FOLLOW_1);
            ruleModifier();

            state._fsp--;

             after(grammarAccess.getModifierRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:187:1: ruleModifier : ( ( rule__Modifier__Group__0 ) ) ;
    public final void ruleModifier() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:191:2: ( ( ( rule__Modifier__Group__0 ) ) )
            // InternalSM2.g:192:2: ( ( rule__Modifier__Group__0 ) )
            {
            // InternalSM2.g:192:2: ( ( rule__Modifier__Group__0 ) )
            // InternalSM2.g:193:3: ( rule__Modifier__Group__0 )
            {
             before(grammarAccess.getModifierAccess().getGroup()); 
            // InternalSM2.g:194:3: ( rule__Modifier__Group__0 )
            // InternalSM2.g:194:4: rule__Modifier__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getModifierAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:203:1: entryRuleDataType : ruleDataType EOF ;
    public final void entryRuleDataType() throws RecognitionException {
        try {
            // InternalSM2.g:204:1: ( ruleDataType EOF )
            // InternalSM2.g:205:1: ruleDataType EOF
            {
             before(grammarAccess.getDataTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleDataType();

            state._fsp--;

             after(grammarAccess.getDataTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:212:1: ruleDataType : ( ( rule__DataType__Alternatives ) ) ;
    public final void ruleDataType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:216:2: ( ( ( rule__DataType__Alternatives ) ) )
            // InternalSM2.g:217:2: ( ( rule__DataType__Alternatives ) )
            {
            // InternalSM2.g:217:2: ( ( rule__DataType__Alternatives ) )
            // InternalSM2.g:218:3: ( rule__DataType__Alternatives )
            {
             before(grammarAccess.getDataTypeAccess().getAlternatives()); 
            // InternalSM2.g:219:3: ( rule__DataType__Alternatives )
            // InternalSM2.g:219:4: rule__DataType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__DataType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getDataTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2.g:228:1: entryRuleCompositeType : ruleCompositeType EOF ;
    public final void entryRuleCompositeType() throws RecognitionException {
        try {
            // InternalSM2.g:229:1: ( ruleCompositeType EOF )
            // InternalSM2.g:230:1: ruleCompositeType EOF
            {
             before(grammarAccess.getCompositeTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleCompositeType();

            state._fsp--;

             after(grammarAccess.getCompositeTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2.g:237:1: ruleCompositeType : ( ( rule__CompositeType__Alternatives ) ) ;
    public final void ruleCompositeType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:241:2: ( ( ( rule__CompositeType__Alternatives ) ) )
            // InternalSM2.g:242:2: ( ( rule__CompositeType__Alternatives ) )
            {
            // InternalSM2.g:242:2: ( ( rule__CompositeType__Alternatives ) )
            // InternalSM2.g:243:3: ( rule__CompositeType__Alternatives )
            {
             before(grammarAccess.getCompositeTypeAccess().getAlternatives()); 
            // InternalSM2.g:244:3: ( rule__CompositeType__Alternatives )
            // InternalSM2.g:244:4: rule__CompositeType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__CompositeType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCompositeTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:253:1: entryRuleMapping : ruleMapping EOF ;
    public final void entryRuleMapping() throws RecognitionException {
        try {
            // InternalSM2.g:254:1: ( ruleMapping EOF )
            // InternalSM2.g:255:1: ruleMapping EOF
            {
             before(grammarAccess.getMappingRule()); 
            pushFollow(FOLLOW_1);
            ruleMapping();

            state._fsp--;

             after(grammarAccess.getMappingRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:262:1: ruleMapping : ( ( rule__Mapping__Group__0 ) ) ;
    public final void ruleMapping() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:266:2: ( ( ( rule__Mapping__Group__0 ) ) )
            // InternalSM2.g:267:2: ( ( rule__Mapping__Group__0 ) )
            {
            // InternalSM2.g:267:2: ( ( rule__Mapping__Group__0 ) )
            // InternalSM2.g:268:3: ( rule__Mapping__Group__0 )
            {
             before(grammarAccess.getMappingAccess().getGroup()); 
            // InternalSM2.g:269:3: ( rule__Mapping__Group__0 )
            // InternalSM2.g:269:4: rule__Mapping__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:278:1: entryRuleStruct : ruleStruct EOF ;
    public final void entryRuleStruct() throws RecognitionException {
        try {
            // InternalSM2.g:279:1: ( ruleStruct EOF )
            // InternalSM2.g:280:1: ruleStruct EOF
            {
             before(grammarAccess.getStructRule()); 
            pushFollow(FOLLOW_1);
            ruleStruct();

            state._fsp--;

             after(grammarAccess.getStructRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:287:1: ruleStruct : ( ( rule__Struct__Group__0 ) ) ;
    public final void ruleStruct() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:291:2: ( ( ( rule__Struct__Group__0 ) ) )
            // InternalSM2.g:292:2: ( ( rule__Struct__Group__0 ) )
            {
            // InternalSM2.g:292:2: ( ( rule__Struct__Group__0 ) )
            // InternalSM2.g:293:3: ( rule__Struct__Group__0 )
            {
             before(grammarAccess.getStructAccess().getGroup()); 
            // InternalSM2.g:294:3: ( rule__Struct__Group__0 )
            // InternalSM2.g:294:4: rule__Struct__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Struct__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStructAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:303:1: entryRuleEnum : ruleEnum EOF ;
    public final void entryRuleEnum() throws RecognitionException {
        try {
            // InternalSM2.g:304:1: ( ruleEnum EOF )
            // InternalSM2.g:305:1: ruleEnum EOF
            {
             before(grammarAccess.getEnumRule()); 
            pushFollow(FOLLOW_1);
            ruleEnum();

            state._fsp--;

             after(grammarAccess.getEnumRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:312:1: ruleEnum : ( ( rule__Enum__Group__0 ) ) ;
    public final void ruleEnum() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:316:2: ( ( ( rule__Enum__Group__0 ) ) )
            // InternalSM2.g:317:2: ( ( rule__Enum__Group__0 ) )
            {
            // InternalSM2.g:317:2: ( ( rule__Enum__Group__0 ) )
            // InternalSM2.g:318:3: ( rule__Enum__Group__0 )
            {
             before(grammarAccess.getEnumAccess().getGroup()); 
            // InternalSM2.g:319:3: ( rule__Enum__Group__0 )
            // InternalSM2.g:319:4: rule__Enum__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Enum__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEnumAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:328:1: entryRuleProperty : ruleProperty EOF ;
    public final void entryRuleProperty() throws RecognitionException {
        try {
            // InternalSM2.g:329:1: ( ruleProperty EOF )
            // InternalSM2.g:330:1: ruleProperty EOF
            {
             before(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_1);
            ruleProperty();

            state._fsp--;

             after(grammarAccess.getPropertyRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:337:1: ruleProperty : ( ( rule__Property__Group__0 ) ) ;
    public final void ruleProperty() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:341:2: ( ( ( rule__Property__Group__0 ) ) )
            // InternalSM2.g:342:2: ( ( rule__Property__Group__0 ) )
            {
            // InternalSM2.g:342:2: ( ( rule__Property__Group__0 ) )
            // InternalSM2.g:343:3: ( rule__Property__Group__0 )
            {
             before(grammarAccess.getPropertyAccess().getGroup()); 
            // InternalSM2.g:344:3: ( rule__Property__Group__0 )
            // InternalSM2.g:344:4: rule__Property__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Property__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPropertyAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:353:1: entryRuleInputParam : ruleInputParam EOF ;
    public final void entryRuleInputParam() throws RecognitionException {
        try {
            // InternalSM2.g:354:1: ( ruleInputParam EOF )
            // InternalSM2.g:355:1: ruleInputParam EOF
            {
             before(grammarAccess.getInputParamRule()); 
            pushFollow(FOLLOW_1);
            ruleInputParam();

            state._fsp--;

             after(grammarAccess.getInputParamRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:362:1: ruleInputParam : ( ( rule__InputParam__Group__0 ) ) ;
    public final void ruleInputParam() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:366:2: ( ( ( rule__InputParam__Group__0 ) ) )
            // InternalSM2.g:367:2: ( ( rule__InputParam__Group__0 ) )
            {
            // InternalSM2.g:367:2: ( ( rule__InputParam__Group__0 ) )
            // InternalSM2.g:368:3: ( rule__InputParam__Group__0 )
            {
             before(grammarAccess.getInputParamAccess().getGroup()); 
            // InternalSM2.g:369:3: ( rule__InputParam__Group__0 )
            // InternalSM2.g:369:4: rule__InputParam__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getInputParamAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:378:1: entryRuleRestriction : ruleRestriction EOF ;
    public final void entryRuleRestriction() throws RecognitionException {
        try {
            // InternalSM2.g:379:1: ( ruleRestriction EOF )
            // InternalSM2.g:380:1: ruleRestriction EOF
            {
             before(grammarAccess.getRestrictionRule()); 
            pushFollow(FOLLOW_1);
            ruleRestriction();

            state._fsp--;

             after(grammarAccess.getRestrictionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:387:1: ruleRestriction : ( ( rule__Restriction__Group__0 ) ) ;
    public final void ruleRestriction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:391:2: ( ( ( rule__Restriction__Group__0 ) ) )
            // InternalSM2.g:392:2: ( ( rule__Restriction__Group__0 ) )
            {
            // InternalSM2.g:392:2: ( ( rule__Restriction__Group__0 ) )
            // InternalSM2.g:393:3: ( rule__Restriction__Group__0 )
            {
             before(grammarAccess.getRestrictionAccess().getGroup()); 
            // InternalSM2.g:394:3: ( rule__Restriction__Group__0 )
            // InternalSM2.g:394:4: rule__Restriction__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:403:1: entryRuleRestrictionGas : ruleRestrictionGas EOF ;
    public final void entryRuleRestrictionGas() throws RecognitionException {
        try {
            // InternalSM2.g:404:1: ( ruleRestrictionGas EOF )
            // InternalSM2.g:405:1: ruleRestrictionGas EOF
            {
             before(grammarAccess.getRestrictionGasRule()); 
            pushFollow(FOLLOW_1);
            ruleRestrictionGas();

            state._fsp--;

             after(grammarAccess.getRestrictionGasRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:412:1: ruleRestrictionGas : ( ( rule__RestrictionGas__Group__0 ) ) ;
    public final void ruleRestrictionGas() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:416:2: ( ( ( rule__RestrictionGas__Group__0 ) ) )
            // InternalSM2.g:417:2: ( ( rule__RestrictionGas__Group__0 ) )
            {
            // InternalSM2.g:417:2: ( ( rule__RestrictionGas__Group__0 ) )
            // InternalSM2.g:418:3: ( rule__RestrictionGas__Group__0 )
            {
             before(grammarAccess.getRestrictionGasAccess().getGroup()); 
            // InternalSM2.g:419:3: ( rule__RestrictionGas__Group__0 )
            // InternalSM2.g:419:4: rule__RestrictionGas__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2.g:428:1: entryRuleClause : ruleClause EOF ;
    public final void entryRuleClause() throws RecognitionException {
        try {
            // InternalSM2.g:429:1: ( ruleClause EOF )
            // InternalSM2.g:430:1: ruleClause EOF
            {
             before(grammarAccess.getClauseRule()); 
            pushFollow(FOLLOW_1);
            ruleClause();

            state._fsp--;

             after(grammarAccess.getClauseRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2.g:437:1: ruleClause : ( ( rule__Clause__Group__0 ) ) ;
    public final void ruleClause() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:441:2: ( ( ( rule__Clause__Group__0 ) ) )
            // InternalSM2.g:442:2: ( ( rule__Clause__Group__0 ) )
            {
            // InternalSM2.g:442:2: ( ( rule__Clause__Group__0 ) )
            // InternalSM2.g:443:3: ( rule__Clause__Group__0 )
            {
             before(grammarAccess.getClauseAccess().getGroup()); 
            // InternalSM2.g:444:3: ( rule__Clause__Group__0 )
            // InternalSM2.g:444:4: rule__Clause__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Clause__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRuleSelfdestruct"
    // InternalSM2.g:453:1: entryRuleSelfdestruct : ruleSelfdestruct EOF ;
    public final void entryRuleSelfdestruct() throws RecognitionException {
        try {
            // InternalSM2.g:454:1: ( ruleSelfdestruct EOF )
            // InternalSM2.g:455:1: ruleSelfdestruct EOF
            {
             before(grammarAccess.getSelfdestructRule()); 
            pushFollow(FOLLOW_1);
            ruleSelfdestruct();

            state._fsp--;

             after(grammarAccess.getSelfdestructRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSelfdestruct"


    // $ANTLR start "ruleSelfdestruct"
    // InternalSM2.g:462:1: ruleSelfdestruct : ( ( rule__Selfdestruct__Group__0 ) ) ;
    public final void ruleSelfdestruct() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:466:2: ( ( ( rule__Selfdestruct__Group__0 ) ) )
            // InternalSM2.g:467:2: ( ( rule__Selfdestruct__Group__0 ) )
            {
            // InternalSM2.g:467:2: ( ( rule__Selfdestruct__Group__0 ) )
            // InternalSM2.g:468:3: ( rule__Selfdestruct__Group__0 )
            {
             before(grammarAccess.getSelfdestructAccess().getGroup()); 
            // InternalSM2.g:469:3: ( rule__Selfdestruct__Group__0 )
            // InternalSM2.g:469:4: rule__Selfdestruct__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSelfdestructAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSelfdestruct"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:478:1: entryRuleExpression : ruleExpression EOF ;
    public final void entryRuleExpression() throws RecognitionException {
        try {
            // InternalSM2.g:479:1: ( ruleExpression EOF )
            // InternalSM2.g:480:1: ruleExpression EOF
            {
             before(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:487:1: ruleExpression : ( ( rule__Expression__Alternatives ) ) ;
    public final void ruleExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:491:2: ( ( ( rule__Expression__Alternatives ) ) )
            // InternalSM2.g:492:2: ( ( rule__Expression__Alternatives ) )
            {
            // InternalSM2.g:492:2: ( ( rule__Expression__Alternatives ) )
            // InternalSM2.g:493:3: ( rule__Expression__Alternatives )
            {
             before(grammarAccess.getExpressionAccess().getAlternatives()); 
            // InternalSM2.g:494:3: ( rule__Expression__Alternatives )
            // InternalSM2.g:494:4: rule__Expression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Expression__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getExpressionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleArithmethicalExpression"
    // InternalSM2.g:503:1: entryRuleArithmethicalExpression : ruleArithmethicalExpression EOF ;
    public final void entryRuleArithmethicalExpression() throws RecognitionException {
        try {
            // InternalSM2.g:504:1: ( ruleArithmethicalExpression EOF )
            // InternalSM2.g:505:1: ruleArithmethicalExpression EOF
            {
             before(grammarAccess.getArithmethicalExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleArithmethicalExpression();

            state._fsp--;

             after(grammarAccess.getArithmethicalExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleArithmethicalExpression"


    // $ANTLR start "ruleArithmethicalExpression"
    // InternalSM2.g:512:1: ruleArithmethicalExpression : ( ( rule__ArithmethicalExpression__Alternatives ) ) ;
    public final void ruleArithmethicalExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:516:2: ( ( ( rule__ArithmethicalExpression__Alternatives ) ) )
            // InternalSM2.g:517:2: ( ( rule__ArithmethicalExpression__Alternatives ) )
            {
            // InternalSM2.g:517:2: ( ( rule__ArithmethicalExpression__Alternatives ) )
            // InternalSM2.g:518:3: ( rule__ArithmethicalExpression__Alternatives )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getAlternatives()); 
            // InternalSM2.g:519:3: ( rule__ArithmethicalExpression__Alternatives )
            // InternalSM2.g:519:4: rule__ArithmethicalExpression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleArithmethicalExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:528:1: entryRuleSyntaxExpression : ruleSyntaxExpression EOF ;
    public final void entryRuleSyntaxExpression() throws RecognitionException {
        try {
            // InternalSM2.g:529:1: ( ruleSyntaxExpression EOF )
            // InternalSM2.g:530:1: ruleSyntaxExpression EOF
            {
             before(grammarAccess.getSyntaxExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getSyntaxExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:537:1: ruleSyntaxExpression : ( ( rule__SyntaxExpression__Alternatives ) ) ;
    public final void ruleSyntaxExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:541:2: ( ( ( rule__SyntaxExpression__Alternatives ) ) )
            // InternalSM2.g:542:2: ( ( rule__SyntaxExpression__Alternatives ) )
            {
            // InternalSM2.g:542:2: ( ( rule__SyntaxExpression__Alternatives ) )
            // InternalSM2.g:543:3: ( rule__SyntaxExpression__Alternatives )
            {
             before(grammarAccess.getSyntaxExpressionAccess().getAlternatives()); 
            // InternalSM2.g:544:3: ( rule__SyntaxExpression__Alternatives )
            // InternalSM2.g:544:4: rule__SyntaxExpression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getSyntaxExpressionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:553:1: entryRuleComment : ruleComment EOF ;
    public final void entryRuleComment() throws RecognitionException {
        try {
            // InternalSM2.g:554:1: ( ruleComment EOF )
            // InternalSM2.g:555:1: ruleComment EOF
            {
             before(grammarAccess.getCommentRule()); 
            pushFollow(FOLLOW_1);
            ruleComment();

            state._fsp--;

             after(grammarAccess.getCommentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:562:1: ruleComment : ( ( rule__Comment__Alternatives ) ) ;
    public final void ruleComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:566:2: ( ( ( rule__Comment__Alternatives ) ) )
            // InternalSM2.g:567:2: ( ( rule__Comment__Alternatives ) )
            {
            // InternalSM2.g:567:2: ( ( rule__Comment__Alternatives ) )
            // InternalSM2.g:568:3: ( rule__Comment__Alternatives )
            {
             before(grammarAccess.getCommentAccess().getAlternatives()); 
            // InternalSM2.g:569:3: ( rule__Comment__Alternatives )
            // InternalSM2.g:569:4: rule__Comment__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Comment__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCommentAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:578:1: entryRuleShortComment : ruleShortComment EOF ;
    public final void entryRuleShortComment() throws RecognitionException {
        try {
            // InternalSM2.g:579:1: ( ruleShortComment EOF )
            // InternalSM2.g:580:1: ruleShortComment EOF
            {
             before(grammarAccess.getShortCommentRule()); 
            pushFollow(FOLLOW_1);
            ruleShortComment();

            state._fsp--;

             after(grammarAccess.getShortCommentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:587:1: ruleShortComment : ( ( rule__ShortComment__Group__0 ) ) ;
    public final void ruleShortComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:591:2: ( ( ( rule__ShortComment__Group__0 ) ) )
            // InternalSM2.g:592:2: ( ( rule__ShortComment__Group__0 ) )
            {
            // InternalSM2.g:592:2: ( ( rule__ShortComment__Group__0 ) )
            // InternalSM2.g:593:3: ( rule__ShortComment__Group__0 )
            {
             before(grammarAccess.getShortCommentAccess().getGroup()); 
            // InternalSM2.g:594:3: ( rule__ShortComment__Group__0 )
            // InternalSM2.g:594:4: rule__ShortComment__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getShortCommentAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:603:1: entryRuleLongComment : ruleLongComment EOF ;
    public final void entryRuleLongComment() throws RecognitionException {
        try {
            // InternalSM2.g:604:1: ( ruleLongComment EOF )
            // InternalSM2.g:605:1: ruleLongComment EOF
            {
             before(grammarAccess.getLongCommentRule()); 
            pushFollow(FOLLOW_1);
            ruleLongComment();

            state._fsp--;

             after(grammarAccess.getLongCommentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:612:1: ruleLongComment : ( ( rule__LongComment__Group__0 ) ) ;
    public final void ruleLongComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:616:2: ( ( ( rule__LongComment__Group__0 ) ) )
            // InternalSM2.g:617:2: ( ( rule__LongComment__Group__0 ) )
            {
            // InternalSM2.g:617:2: ( ( rule__LongComment__Group__0 ) )
            // InternalSM2.g:618:3: ( rule__LongComment__Group__0 )
            {
             before(grammarAccess.getLongCommentAccess().getGroup()); 
            // InternalSM2.g:619:3: ( rule__LongComment__Group__0 )
            // InternalSM2.g:619:4: rule__LongComment__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLongCommentAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "ruleSingularType"
    // InternalSM2.g:628:1: ruleSingularType : ( ( rule__SingularType__Alternatives ) ) ;
    public final void ruleSingularType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:632:1: ( ( ( rule__SingularType__Alternatives ) ) )
            // InternalSM2.g:633:2: ( ( rule__SingularType__Alternatives ) )
            {
            // InternalSM2.g:633:2: ( ( rule__SingularType__Alternatives ) )
            // InternalSM2.g:634:3: ( rule__SingularType__Alternatives )
            {
             before(grammarAccess.getSingularTypeAccess().getAlternatives()); 
            // InternalSM2.g:635:3: ( rule__SingularType__Alternatives )
            // InternalSM2.g:635:4: rule__SingularType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__SingularType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getSingularTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:644:1: ruleVisibility : ( ( rule__Visibility__Alternatives ) ) ;
    public final void ruleVisibility() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:648:1: ( ( ( rule__Visibility__Alternatives ) ) )
            // InternalSM2.g:649:2: ( ( rule__Visibility__Alternatives ) )
            {
            // InternalSM2.g:649:2: ( ( rule__Visibility__Alternatives ) )
            // InternalSM2.g:650:3: ( rule__Visibility__Alternatives )
            {
             before(grammarAccess.getVisibilityAccess().getAlternatives()); 
            // InternalSM2.g:651:3: ( rule__Visibility__Alternatives )
            // InternalSM2.g:651:4: rule__Visibility__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Visibility__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getVisibilityAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:660:1: ruleCoin : ( ( rule__Coin__Alternatives ) ) ;
    public final void ruleCoin() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:664:1: ( ( ( rule__Coin__Alternatives ) ) )
            // InternalSM2.g:665:2: ( ( rule__Coin__Alternatives ) )
            {
            // InternalSM2.g:665:2: ( ( rule__Coin__Alternatives ) )
            // InternalSM2.g:666:3: ( rule__Coin__Alternatives )
            {
             before(grammarAccess.getCoinAccess().getAlternatives()); 
            // InternalSM2.g:667:3: ( rule__Coin__Alternatives )
            // InternalSM2.g:667:4: rule__Coin__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Coin__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCoinAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:676:1: ruleComparationOperator : ( ( rule__ComparationOperator__Alternatives ) ) ;
    public final void ruleComparationOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:680:1: ( ( ( rule__ComparationOperator__Alternatives ) ) )
            // InternalSM2.g:681:2: ( ( rule__ComparationOperator__Alternatives ) )
            {
            // InternalSM2.g:681:2: ( ( rule__ComparationOperator__Alternatives ) )
            // InternalSM2.g:682:3: ( rule__ComparationOperator__Alternatives )
            {
             before(grammarAccess.getComparationOperatorAccess().getAlternatives()); 
            // InternalSM2.g:683:3: ( rule__ComparationOperator__Alternatives )
            // InternalSM2.g:683:4: rule__ComparationOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ComparationOperator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getComparationOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:692:1: ruleLogicalPairOperator : ( ( rule__LogicalPairOperator__Alternatives ) ) ;
    public final void ruleLogicalPairOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:696:1: ( ( ( rule__LogicalPairOperator__Alternatives ) ) )
            // InternalSM2.g:697:2: ( ( rule__LogicalPairOperator__Alternatives ) )
            {
            // InternalSM2.g:697:2: ( ( rule__LogicalPairOperator__Alternatives ) )
            // InternalSM2.g:698:3: ( rule__LogicalPairOperator__Alternatives )
            {
             before(grammarAccess.getLogicalPairOperatorAccess().getAlternatives()); 
            // InternalSM2.g:699:3: ( rule__LogicalPairOperator__Alternatives )
            // InternalSM2.g:699:4: rule__LogicalPairOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__LogicalPairOperator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getLogicalPairOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:708:1: ruleArithmeticalOperator : ( ( rule__ArithmeticalOperator__Alternatives ) ) ;
    public final void ruleArithmeticalOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:712:1: ( ( ( rule__ArithmeticalOperator__Alternatives ) ) )
            // InternalSM2.g:713:2: ( ( rule__ArithmeticalOperator__Alternatives ) )
            {
            // InternalSM2.g:713:2: ( ( rule__ArithmeticalOperator__Alternatives ) )
            // InternalSM2.g:714:3: ( rule__ArithmeticalOperator__Alternatives )
            {
             before(grammarAccess.getArithmeticalOperatorAccess().getAlternatives()); 
            // InternalSM2.g:715:3: ( rule__ArithmeticalOperator__Alternatives )
            // InternalSM2.g:715:4: rule__ArithmeticalOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ArithmeticalOperator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getArithmeticalOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleArithmeticalOperator"


    // $ANTLR start "rule__Version__SymbolAlternatives_0_0"
    // InternalSM2.g:723:1: rule__Version__SymbolAlternatives_0_0 : ( ( '^' ) | ( '>' ) | ( '>=' ) );
    public final void rule__Version__SymbolAlternatives_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:727:1: ( ( '^' ) | ( '>' ) | ( '>=' ) )
            int alt1=3;
            switch ( input.LA(1) ) {
            case 19:
                {
                alt1=1;
                }
                break;
            case 20:
                {
                alt1=2;
                }
                break;
            case 21:
                {
                alt1=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // InternalSM2.g:728:2: ( '^' )
                    {
                    // InternalSM2.g:728:2: ( '^' )
                    // InternalSM2.g:729:3: '^'
                    {
                     before(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 
                    match(input,19,FOLLOW_2); 
                     after(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:734:2: ( '>' )
                    {
                    // InternalSM2.g:734:2: ( '>' )
                    // InternalSM2.g:735:3: '>'
                    {
                     before(grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_0_0_1()); 
                    match(input,20,FOLLOW_2); 
                     after(grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_0_0_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:740:2: ( '>=' )
                    {
                    // InternalSM2.g:740:2: ( '>=' )
                    // InternalSM2.g:741:3: '>='
                    {
                     before(grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_0_0_2()); 
                    match(input,21,FOLLOW_2); 
                     after(grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_0_0_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAlternatives_0_0"


    // $ANTLR start "rule__Attributes__Alternatives"
    // InternalSM2.g:750:1: rule__Attributes__Alternatives : ( ( ruleProperty ) | ( ruleDataType ) );
    public final void rule__Attributes__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:754:1: ( ( ruleProperty ) | ( ruleDataType ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( ((LA2_0>=22 && LA2_0<=30)) ) {
                alt2=1;
            }
            else if ( (LA2_0==RULE_ID||LA2_0==58||(LA2_0>=60 && LA2_0<=61)) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalSM2.g:755:2: ( ruleProperty )
                    {
                    // InternalSM2.g:755:2: ( ruleProperty )
                    // InternalSM2.g:756:3: ruleProperty
                    {
                     before(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleProperty();

                    state._fsp--;

                     after(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:761:2: ( ruleDataType )
                    {
                    // InternalSM2.g:761:2: ( ruleDataType )
                    // InternalSM2.g:762:3: ruleDataType
                    {
                     before(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleDataType();

                    state._fsp--;

                     after(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attributes__Alternatives"


    // $ANTLR start "rule__DataType__Alternatives"
    // InternalSM2.g:771:1: rule__DataType__Alternatives : ( ( ruleCompositeType ) | ( ruleEnum ) | ( RULE_ID ) );
    public final void rule__DataType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:775:1: ( ( ruleCompositeType ) | ( ruleEnum ) | ( RULE_ID ) )
            int alt3=3;
            switch ( input.LA(1) ) {
            case 58:
            case 60:
                {
                alt3=1;
                }
                break;
            case 61:
                {
                alt3=2;
                }
                break;
            case RULE_ID:
                {
                alt3=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalSM2.g:776:2: ( ruleCompositeType )
                    {
                    // InternalSM2.g:776:2: ( ruleCompositeType )
                    // InternalSM2.g:777:3: ruleCompositeType
                    {
                     before(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleCompositeType();

                    state._fsp--;

                     after(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:782:2: ( ruleEnum )
                    {
                    // InternalSM2.g:782:2: ( ruleEnum )
                    // InternalSM2.g:783:3: ruleEnum
                    {
                     before(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleEnum();

                    state._fsp--;

                     after(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:788:2: ( RULE_ID )
                    {
                    // InternalSM2.g:788:2: ( RULE_ID )
                    // InternalSM2.g:789:3: RULE_ID
                    {
                     before(grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataType__Alternatives"


    // $ANTLR start "rule__CompositeType__Alternatives"
    // InternalSM2.g:798:1: rule__CompositeType__Alternatives : ( ( ruleMapping ) | ( ruleStruct ) );
    public final void rule__CompositeType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:802:1: ( ( ruleMapping ) | ( ruleStruct ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==58) ) {
                alt4=1;
            }
            else if ( (LA4_0==60) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalSM2.g:803:2: ( ruleMapping )
                    {
                    // InternalSM2.g:803:2: ( ruleMapping )
                    // InternalSM2.g:804:3: ruleMapping
                    {
                     before(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleMapping();

                    state._fsp--;

                     after(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:809:2: ( ruleStruct )
                    {
                    // InternalSM2.g:809:2: ( ruleStruct )
                    // InternalSM2.g:810:3: ruleStruct
                    {
                     before(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleStruct();

                    state._fsp--;

                     after(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CompositeType__Alternatives"


    // $ANTLR start "rule__Property__Alternatives_4"
    // InternalSM2.g:819:1: rule__Property__Alternatives_4 : ( ( ( rule__Property__InicializationAssignment_4_0 ) ) | ( RULE_INT ) );
    public final void rule__Property__Alternatives_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:823:1: ( ( ( rule__Property__InicializationAssignment_4_0 ) ) | ( RULE_INT ) )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==RULE_STRING) ) {
                alt5=1;
            }
            else if ( (LA5_0==RULE_INT) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalSM2.g:824:2: ( ( rule__Property__InicializationAssignment_4_0 ) )
                    {
                    // InternalSM2.g:824:2: ( ( rule__Property__InicializationAssignment_4_0 ) )
                    // InternalSM2.g:825:3: ( rule__Property__InicializationAssignment_4_0 )
                    {
                     before(grammarAccess.getPropertyAccess().getInicializationAssignment_4_0()); 
                    // InternalSM2.g:826:3: ( rule__Property__InicializationAssignment_4_0 )
                    // InternalSM2.g:826:4: rule__Property__InicializationAssignment_4_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__InicializationAssignment_4_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPropertyAccess().getInicializationAssignment_4_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:830:2: ( RULE_INT )
                    {
                    // InternalSM2.g:830:2: ( RULE_INT )
                    // InternalSM2.g:831:3: RULE_INT
                    {
                     before(grammarAccess.getPropertyAccess().getINTTerminalRuleCall_4_1()); 
                    match(input,RULE_INT,FOLLOW_2); 
                     after(grammarAccess.getPropertyAccess().getINTTerminalRuleCall_4_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Alternatives_4"


    // $ANTLR start "rule__Expression__Alternatives"
    // InternalSM2.g:840:1: rule__Expression__Alternatives : ( ( ruleArithmethicalExpression ) | ( ruleSyntaxExpression ) );
    public final void rule__Expression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:844:1: ( ( ruleArithmethicalExpression ) | ( ruleSyntaxExpression ) )
            int alt6=2;
            switch ( input.LA(1) ) {
            case RULE_OPENPARENTHESIS:
                {
                alt6=1;
                }
                break;
            case RULE_INT:
                {
                int LA6_2 = input.LA(2);

                if ( (LA6_2==EOF||(LA6_2>=RULE_SEMICOLON && LA6_2<=RULE_EOLINE)||LA6_2==RULE_CLOSEKEY) ) {
                    alt6=2;
                }
                else if ( ((LA6_2>=46 && LA6_2<=49)) ) {
                    alt6=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 2, input);

                    throw nvae;
                }
                }
                break;
            case RULE_STRING:
                {
                alt6=2;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // InternalSM2.g:845:2: ( ruleArithmethicalExpression )
                    {
                    // InternalSM2.g:845:2: ( ruleArithmethicalExpression )
                    // InternalSM2.g:846:3: ruleArithmethicalExpression
                    {
                     before(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleArithmethicalExpression();

                    state._fsp--;

                     after(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:851:2: ( ruleSyntaxExpression )
                    {
                    // InternalSM2.g:851:2: ( ruleSyntaxExpression )
                    // InternalSM2.g:852:3: ruleSyntaxExpression
                    {
                     before(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleSyntaxExpression();

                    state._fsp--;

                     after(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Expression__Alternatives"


    // $ANTLR start "rule__ArithmethicalExpression__Alternatives"
    // InternalSM2.g:861:1: rule__ArithmethicalExpression__Alternatives : ( ( ( rule__ArithmethicalExpression__Group_0__0 ) ) | ( ( rule__ArithmethicalExpression__Group_1__0 ) ) );
    public final void rule__ArithmethicalExpression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:865:1: ( ( ( rule__ArithmethicalExpression__Group_0__0 ) ) | ( ( rule__ArithmethicalExpression__Group_1__0 ) ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==RULE_OPENPARENTHESIS) ) {
                alt7=1;
            }
            else if ( (LA7_0==RULE_INT) ) {
                alt7=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalSM2.g:866:2: ( ( rule__ArithmethicalExpression__Group_0__0 ) )
                    {
                    // InternalSM2.g:866:2: ( ( rule__ArithmethicalExpression__Group_0__0 ) )
                    // InternalSM2.g:867:3: ( rule__ArithmethicalExpression__Group_0__0 )
                    {
                     before(grammarAccess.getArithmethicalExpressionAccess().getGroup_0()); 
                    // InternalSM2.g:868:3: ( rule__ArithmethicalExpression__Group_0__0 )
                    // InternalSM2.g:868:4: rule__ArithmethicalExpression__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getArithmethicalExpressionAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:872:2: ( ( rule__ArithmethicalExpression__Group_1__0 ) )
                    {
                    // InternalSM2.g:872:2: ( ( rule__ArithmethicalExpression__Group_1__0 ) )
                    // InternalSM2.g:873:3: ( rule__ArithmethicalExpression__Group_1__0 )
                    {
                     before(grammarAccess.getArithmethicalExpressionAccess().getGroup_1()); 
                    // InternalSM2.g:874:3: ( rule__ArithmethicalExpression__Group_1__0 )
                    // InternalSM2.g:874:4: rule__ArithmethicalExpression__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getArithmethicalExpressionAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Alternatives"


    // $ANTLR start "rule__SyntaxExpression__Alternatives"
    // InternalSM2.g:882:1: rule__SyntaxExpression__Alternatives : ( ( ( rule__SyntaxExpression__TextAssignment_0 ) ) | ( ( rule__SyntaxExpression__Group_1__0 ) ) );
    public final void rule__SyntaxExpression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:886:1: ( ( ( rule__SyntaxExpression__TextAssignment_0 ) ) | ( ( rule__SyntaxExpression__Group_1__0 ) ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==RULE_STRING) ) {
                alt8=1;
            }
            else if ( (LA8_0==RULE_INT) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalSM2.g:887:2: ( ( rule__SyntaxExpression__TextAssignment_0 ) )
                    {
                    // InternalSM2.g:887:2: ( ( rule__SyntaxExpression__TextAssignment_0 ) )
                    // InternalSM2.g:888:3: ( rule__SyntaxExpression__TextAssignment_0 )
                    {
                     before(grammarAccess.getSyntaxExpressionAccess().getTextAssignment_0()); 
                    // InternalSM2.g:889:3: ( rule__SyntaxExpression__TextAssignment_0 )
                    // InternalSM2.g:889:4: rule__SyntaxExpression__TextAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__TextAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getSyntaxExpressionAccess().getTextAssignment_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:893:2: ( ( rule__SyntaxExpression__Group_1__0 ) )
                    {
                    // InternalSM2.g:893:2: ( ( rule__SyntaxExpression__Group_1__0 ) )
                    // InternalSM2.g:894:3: ( rule__SyntaxExpression__Group_1__0 )
                    {
                     before(grammarAccess.getSyntaxExpressionAccess().getGroup_1()); 
                    // InternalSM2.g:895:3: ( rule__SyntaxExpression__Group_1__0 )
                    // InternalSM2.g:895:4: rule__SyntaxExpression__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getSyntaxExpressionAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Alternatives"


    // $ANTLR start "rule__Comment__Alternatives"
    // InternalSM2.g:903:1: rule__Comment__Alternatives : ( ( ruleShortComment ) | ( ruleLongComment ) );
    public final void rule__Comment__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:907:1: ( ( ruleShortComment ) | ( ruleLongComment ) )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==66) ) {
                alt9=1;
            }
            else if ( (LA9_0==67) ) {
                alt9=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // InternalSM2.g:908:2: ( ruleShortComment )
                    {
                    // InternalSM2.g:908:2: ( ruleShortComment )
                    // InternalSM2.g:909:3: ruleShortComment
                    {
                     before(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleShortComment();

                    state._fsp--;

                     after(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:914:2: ( ruleLongComment )
                    {
                    // InternalSM2.g:914:2: ( ruleLongComment )
                    // InternalSM2.g:915:3: ruleLongComment
                    {
                     before(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleLongComment();

                    state._fsp--;

                     after(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Comment__Alternatives"


    // $ANTLR start "rule__SingularType__Alternatives"
    // InternalSM2.g:924:1: rule__SingularType__Alternatives : ( ( ( 'int' ) ) | ( ( 'uint' ) ) | ( ( 'uint8' ) ) | ( ( 'uint256' ) ) | ( ( 'string' ) ) | ( ( 'address' ) ) | ( ( 'address payable' ) ) | ( ( 'double' ) ) | ( ( 'bool' ) ) );
    public final void rule__SingularType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:928:1: ( ( ( 'int' ) ) | ( ( 'uint' ) ) | ( ( 'uint8' ) ) | ( ( 'uint256' ) ) | ( ( 'string' ) ) | ( ( 'address' ) ) | ( ( 'address payable' ) ) | ( ( 'double' ) ) | ( ( 'bool' ) ) )
            int alt10=9;
            switch ( input.LA(1) ) {
            case 22:
                {
                alt10=1;
                }
                break;
            case 23:
                {
                alt10=2;
                }
                break;
            case 24:
                {
                alt10=3;
                }
                break;
            case 25:
                {
                alt10=4;
                }
                break;
            case 26:
                {
                alt10=5;
                }
                break;
            case 27:
                {
                alt10=6;
                }
                break;
            case 28:
                {
                alt10=7;
                }
                break;
            case 29:
                {
                alt10=8;
                }
                break;
            case 30:
                {
                alt10=9;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }

            switch (alt10) {
                case 1 :
                    // InternalSM2.g:929:2: ( ( 'int' ) )
                    {
                    // InternalSM2.g:929:2: ( ( 'int' ) )
                    // InternalSM2.g:930:3: ( 'int' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:931:3: ( 'int' )
                    // InternalSM2.g:931:4: 'int'
                    {
                    match(input,22,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:935:2: ( ( 'uint' ) )
                    {
                    // InternalSM2.g:935:2: ( ( 'uint' ) )
                    // InternalSM2.g:936:3: ( 'uint' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:937:3: ( 'uint' )
                    // InternalSM2.g:937:4: 'uint'
                    {
                    match(input,23,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:941:2: ( ( 'uint8' ) )
                    {
                    // InternalSM2.g:941:2: ( ( 'uint8' ) )
                    // InternalSM2.g:942:3: ( 'uint8' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2()); 
                    // InternalSM2.g:943:3: ( 'uint8' )
                    // InternalSM2.g:943:4: 'uint8'
                    {
                    match(input,24,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:947:2: ( ( 'uint256' ) )
                    {
                    // InternalSM2.g:947:2: ( ( 'uint256' ) )
                    // InternalSM2.g:948:3: ( 'uint256' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3()); 
                    // InternalSM2.g:949:3: ( 'uint256' )
                    // InternalSM2.g:949:4: 'uint256'
                    {
                    match(input,25,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:953:2: ( ( 'string' ) )
                    {
                    // InternalSM2.g:953:2: ( ( 'string' ) )
                    // InternalSM2.g:954:3: ( 'string' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4()); 
                    // InternalSM2.g:955:3: ( 'string' )
                    // InternalSM2.g:955:4: 'string'
                    {
                    match(input,26,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:959:2: ( ( 'address' ) )
                    {
                    // InternalSM2.g:959:2: ( ( 'address' ) )
                    // InternalSM2.g:960:3: ( 'address' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5()); 
                    // InternalSM2.g:961:3: ( 'address' )
                    // InternalSM2.g:961:4: 'address'
                    {
                    match(input,27,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5()); 

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:965:2: ( ( 'address payable' ) )
                    {
                    // InternalSM2.g:965:2: ( ( 'address payable' ) )
                    // InternalSM2.g:966:3: ( 'address payable' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6()); 
                    // InternalSM2.g:967:3: ( 'address payable' )
                    // InternalSM2.g:967:4: 'address payable'
                    {
                    match(input,28,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6()); 

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:971:2: ( ( 'double' ) )
                    {
                    // InternalSM2.g:971:2: ( ( 'double' ) )
                    // InternalSM2.g:972:3: ( 'double' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7()); 
                    // InternalSM2.g:973:3: ( 'double' )
                    // InternalSM2.g:973:4: 'double'
                    {
                    match(input,29,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7()); 

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:977:2: ( ( 'bool' ) )
                    {
                    // InternalSM2.g:977:2: ( ( 'bool' ) )
                    // InternalSM2.g:978:3: ( 'bool' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8()); 
                    // InternalSM2.g:979:3: ( 'bool' )
                    // InternalSM2.g:979:4: 'bool'
                    {
                    match(input,30,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingularType__Alternatives"


    // $ANTLR start "rule__Visibility__Alternatives"
    // InternalSM2.g:987:1: rule__Visibility__Alternatives : ( ( ( 'public' ) ) | ( ( 'private' ) ) | ( ( 'internal' ) ) );
    public final void rule__Visibility__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:991:1: ( ( ( 'public' ) ) | ( ( 'private' ) ) | ( ( 'internal' ) ) )
            int alt11=3;
            switch ( input.LA(1) ) {
            case 31:
                {
                alt11=1;
                }
                break;
            case 32:
                {
                alt11=2;
                }
                break;
            case 33:
                {
                alt11=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }

            switch (alt11) {
                case 1 :
                    // InternalSM2.g:992:2: ( ( 'public' ) )
                    {
                    // InternalSM2.g:992:2: ( ( 'public' ) )
                    // InternalSM2.g:993:3: ( 'public' )
                    {
                     before(grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:994:3: ( 'public' )
                    // InternalSM2.g:994:4: 'public'
                    {
                    match(input,31,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:998:2: ( ( 'private' ) )
                    {
                    // InternalSM2.g:998:2: ( ( 'private' ) )
                    // InternalSM2.g:999:3: ( 'private' )
                    {
                     before(grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1000:3: ( 'private' )
                    // InternalSM2.g:1000:4: 'private'
                    {
                    match(input,32,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1004:2: ( ( 'internal' ) )
                    {
                    // InternalSM2.g:1004:2: ( ( 'internal' ) )
                    // InternalSM2.g:1005:3: ( 'internal' )
                    {
                     before(grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1006:3: ( 'internal' )
                    // InternalSM2.g:1006:4: 'internal'
                    {
                    match(input,33,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Visibility__Alternatives"


    // $ANTLR start "rule__Coin__Alternatives"
    // InternalSM2.g:1014:1: rule__Coin__Alternatives : ( ( ( 'ether' ) ) | ( ( 'wei' ) ) | ( ( 'gwei' ) ) | ( ( 'pwei' ) ) | ( ( 'finney' ) ) | ( ( 'szabo' ) ) );
    public final void rule__Coin__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1018:1: ( ( ( 'ether' ) ) | ( ( 'wei' ) ) | ( ( 'gwei' ) ) | ( ( 'pwei' ) ) | ( ( 'finney' ) ) | ( ( 'szabo' ) ) )
            int alt12=6;
            switch ( input.LA(1) ) {
            case 34:
                {
                alt12=1;
                }
                break;
            case 35:
                {
                alt12=2;
                }
                break;
            case 36:
                {
                alt12=3;
                }
                break;
            case 37:
                {
                alt12=4;
                }
                break;
            case 38:
                {
                alt12=5;
                }
                break;
            case 39:
                {
                alt12=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }

            switch (alt12) {
                case 1 :
                    // InternalSM2.g:1019:2: ( ( 'ether' ) )
                    {
                    // InternalSM2.g:1019:2: ( ( 'ether' ) )
                    // InternalSM2.g:1020:3: ( 'ether' )
                    {
                     before(grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1021:3: ( 'ether' )
                    // InternalSM2.g:1021:4: 'ether'
                    {
                    match(input,34,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1025:2: ( ( 'wei' ) )
                    {
                    // InternalSM2.g:1025:2: ( ( 'wei' ) )
                    // InternalSM2.g:1026:3: ( 'wei' )
                    {
                     before(grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1027:3: ( 'wei' )
                    // InternalSM2.g:1027:4: 'wei'
                    {
                    match(input,35,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1031:2: ( ( 'gwei' ) )
                    {
                    // InternalSM2.g:1031:2: ( ( 'gwei' ) )
                    // InternalSM2.g:1032:3: ( 'gwei' )
                    {
                     before(grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1033:3: ( 'gwei' )
                    // InternalSM2.g:1033:4: 'gwei'
                    {
                    match(input,36,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1037:2: ( ( 'pwei' ) )
                    {
                    // InternalSM2.g:1037:2: ( ( 'pwei' ) )
                    // InternalSM2.g:1038:3: ( 'pwei' )
                    {
                     before(grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3()); 
                    // InternalSM2.g:1039:3: ( 'pwei' )
                    // InternalSM2.g:1039:4: 'pwei'
                    {
                    match(input,37,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1043:2: ( ( 'finney' ) )
                    {
                    // InternalSM2.g:1043:2: ( ( 'finney' ) )
                    // InternalSM2.g:1044:3: ( 'finney' )
                    {
                     before(grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4()); 
                    // InternalSM2.g:1045:3: ( 'finney' )
                    // InternalSM2.g:1045:4: 'finney'
                    {
                    match(input,38,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1049:2: ( ( 'szabo' ) )
                    {
                    // InternalSM2.g:1049:2: ( ( 'szabo' ) )
                    // InternalSM2.g:1050:3: ( 'szabo' )
                    {
                     before(grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5()); 
                    // InternalSM2.g:1051:3: ( 'szabo' )
                    // InternalSM2.g:1051:4: 'szabo'
                    {
                    match(input,39,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coin__Alternatives"


    // $ANTLR start "rule__ComparationOperator__Alternatives"
    // InternalSM2.g:1059:1: rule__ComparationOperator__Alternatives : ( ( ( '>' ) ) | ( ( '<' ) ) | ( ( '>=' ) ) | ( ( '<=' ) ) | ( ( '==' ) ) | ( ( '!=' ) ) );
    public final void rule__ComparationOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1063:1: ( ( ( '>' ) ) | ( ( '<' ) ) | ( ( '>=' ) ) | ( ( '<=' ) ) | ( ( '==' ) ) | ( ( '!=' ) ) )
            int alt13=6;
            switch ( input.LA(1) ) {
            case 20:
                {
                alt13=1;
                }
                break;
            case 40:
                {
                alt13=2;
                }
                break;
            case 21:
                {
                alt13=3;
                }
                break;
            case 41:
                {
                alt13=4;
                }
                break;
            case 42:
                {
                alt13=5;
                }
                break;
            case 43:
                {
                alt13=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }

            switch (alt13) {
                case 1 :
                    // InternalSM2.g:1064:2: ( ( '>' ) )
                    {
                    // InternalSM2.g:1064:2: ( ( '>' ) )
                    // InternalSM2.g:1065:3: ( '>' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1066:3: ( '>' )
                    // InternalSM2.g:1066:4: '>'
                    {
                    match(input,20,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1070:2: ( ( '<' ) )
                    {
                    // InternalSM2.g:1070:2: ( ( '<' ) )
                    // InternalSM2.g:1071:3: ( '<' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1072:3: ( '<' )
                    // InternalSM2.g:1072:4: '<'
                    {
                    match(input,40,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1076:2: ( ( '>=' ) )
                    {
                    // InternalSM2.g:1076:2: ( ( '>=' ) )
                    // InternalSM2.g:1077:3: ( '>=' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1078:3: ( '>=' )
                    // InternalSM2.g:1078:4: '>='
                    {
                    match(input,21,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1082:2: ( ( '<=' ) )
                    {
                    // InternalSM2.g:1082:2: ( ( '<=' ) )
                    // InternalSM2.g:1083:3: ( '<=' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3()); 
                    // InternalSM2.g:1084:3: ( '<=' )
                    // InternalSM2.g:1084:4: '<='
                    {
                    match(input,41,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1088:2: ( ( '==' ) )
                    {
                    // InternalSM2.g:1088:2: ( ( '==' ) )
                    // InternalSM2.g:1089:3: ( '==' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4()); 
                    // InternalSM2.g:1090:3: ( '==' )
                    // InternalSM2.g:1090:4: '=='
                    {
                    match(input,42,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1094:2: ( ( '!=' ) )
                    {
                    // InternalSM2.g:1094:2: ( ( '!=' ) )
                    // InternalSM2.g:1095:3: ( '!=' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5()); 
                    // InternalSM2.g:1096:3: ( '!=' )
                    // InternalSM2.g:1096:4: '!='
                    {
                    match(input,43,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparationOperator__Alternatives"


    // $ANTLR start "rule__LogicalPairOperator__Alternatives"
    // InternalSM2.g:1104:1: rule__LogicalPairOperator__Alternatives : ( ( ( '&&' ) ) | ( ( '||' ) ) );
    public final void rule__LogicalPairOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1108:1: ( ( ( '&&' ) ) | ( ( '||' ) ) )
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==44) ) {
                alt14=1;
            }
            else if ( (LA14_0==45) ) {
                alt14=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }
            switch (alt14) {
                case 1 :
                    // InternalSM2.g:1109:2: ( ( '&&' ) )
                    {
                    // InternalSM2.g:1109:2: ( ( '&&' ) )
                    // InternalSM2.g:1110:3: ( '&&' )
                    {
                     before(grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1111:3: ( '&&' )
                    // InternalSM2.g:1111:4: '&&'
                    {
                    match(input,44,FOLLOW_2); 

                    }

                     after(grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1115:2: ( ( '||' ) )
                    {
                    // InternalSM2.g:1115:2: ( ( '||' ) )
                    // InternalSM2.g:1116:3: ( '||' )
                    {
                     before(grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1117:3: ( '||' )
                    // InternalSM2.g:1117:4: '||'
                    {
                    match(input,45,FOLLOW_2); 

                    }

                     after(grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicalPairOperator__Alternatives"


    // $ANTLR start "rule__ArithmeticalOperator__Alternatives"
    // InternalSM2.g:1125:1: rule__ArithmeticalOperator__Alternatives : ( ( ( '+' ) ) | ( ( '-' ) ) | ( ( '*' ) ) | ( ( '/' ) ) );
    public final void rule__ArithmeticalOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1129:1: ( ( ( '+' ) ) | ( ( '-' ) ) | ( ( '*' ) ) | ( ( '/' ) ) )
            int alt15=4;
            switch ( input.LA(1) ) {
            case 46:
                {
                alt15=1;
                }
                break;
            case 47:
                {
                alt15=2;
                }
                break;
            case 48:
                {
                alt15=3;
                }
                break;
            case 49:
                {
                alt15=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }

            switch (alt15) {
                case 1 :
                    // InternalSM2.g:1130:2: ( ( '+' ) )
                    {
                    // InternalSM2.g:1130:2: ( ( '+' ) )
                    // InternalSM2.g:1131:3: ( '+' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1132:3: ( '+' )
                    // InternalSM2.g:1132:4: '+'
                    {
                    match(input,46,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1136:2: ( ( '-' ) )
                    {
                    // InternalSM2.g:1136:2: ( ( '-' ) )
                    // InternalSM2.g:1137:3: ( '-' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1138:3: ( '-' )
                    // InternalSM2.g:1138:4: '-'
                    {
                    match(input,47,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1142:2: ( ( '*' ) )
                    {
                    // InternalSM2.g:1142:2: ( ( '*' ) )
                    // InternalSM2.g:1143:3: ( '*' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1144:3: ( '*' )
                    // InternalSM2.g:1144:4: '*'
                    {
                    match(input,48,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1148:2: ( ( '/' ) )
                    {
                    // InternalSM2.g:1148:2: ( ( '/' ) )
                    // InternalSM2.g:1149:3: ( '/' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3()); 
                    // InternalSM2.g:1150:3: ( '/' )
                    // InternalSM2.g:1150:4: '/'
                    {
                    match(input,49,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmeticalOperator__Alternatives"


    // $ANTLR start "rule__SmartContract__Group__0"
    // InternalSM2.g:1158:1: rule__SmartContract__Group__0 : rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1 ;
    public final void rule__SmartContract__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1162:1: ( rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1 )
            // InternalSM2.g:1163:2: rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__SmartContract__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__0"


    // $ANTLR start "rule__SmartContract__Group__0__Impl"
    // InternalSM2.g:1170:1: rule__SmartContract__Group__0__Impl : ( ( rule__SmartContract__CompilerAssignment_0 ) ) ;
    public final void rule__SmartContract__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1174:1: ( ( ( rule__SmartContract__CompilerAssignment_0 ) ) )
            // InternalSM2.g:1175:1: ( ( rule__SmartContract__CompilerAssignment_0 ) )
            {
            // InternalSM2.g:1175:1: ( ( rule__SmartContract__CompilerAssignment_0 ) )
            // InternalSM2.g:1176:2: ( rule__SmartContract__CompilerAssignment_0 )
            {
             before(grammarAccess.getSmartContractAccess().getCompilerAssignment_0()); 
            // InternalSM2.g:1177:2: ( rule__SmartContract__CompilerAssignment_0 )
            // InternalSM2.g:1177:3: rule__SmartContract__CompilerAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__CompilerAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getCompilerAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__0__Impl"


    // $ANTLR start "rule__SmartContract__Group__1"
    // InternalSM2.g:1185:1: rule__SmartContract__Group__1 : rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2 ;
    public final void rule__SmartContract__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1189:1: ( rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2 )
            // InternalSM2.g:1190:2: rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__SmartContract__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__1"


    // $ANTLR start "rule__SmartContract__Group__1__Impl"
    // InternalSM2.g:1197:1: rule__SmartContract__Group__1__Impl : ( 'solidity' ) ;
    public final void rule__SmartContract__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1201:1: ( ( 'solidity' ) )
            // InternalSM2.g:1202:1: ( 'solidity' )
            {
            // InternalSM2.g:1202:1: ( 'solidity' )
            // InternalSM2.g:1203:2: 'solidity'
            {
             before(grammarAccess.getSmartContractAccess().getSolidityKeyword_1()); 
            match(input,50,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getSolidityKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__1__Impl"


    // $ANTLR start "rule__SmartContract__Group__2"
    // InternalSM2.g:1212:1: rule__SmartContract__Group__2 : rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3 ;
    public final void rule__SmartContract__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1216:1: ( rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3 )
            // InternalSM2.g:1217:2: rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__SmartContract__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__2"


    // $ANTLR start "rule__SmartContract__Group__2__Impl"
    // InternalSM2.g:1224:1: rule__SmartContract__Group__2__Impl : ( ( rule__SmartContract__VersionCompilerAssignment_2 ) ) ;
    public final void rule__SmartContract__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1228:1: ( ( ( rule__SmartContract__VersionCompilerAssignment_2 ) ) )
            // InternalSM2.g:1229:1: ( ( rule__SmartContract__VersionCompilerAssignment_2 ) )
            {
            // InternalSM2.g:1229:1: ( ( rule__SmartContract__VersionCompilerAssignment_2 ) )
            // InternalSM2.g:1230:2: ( rule__SmartContract__VersionCompilerAssignment_2 )
            {
             before(grammarAccess.getSmartContractAccess().getVersionCompilerAssignment_2()); 
            // InternalSM2.g:1231:2: ( rule__SmartContract__VersionCompilerAssignment_2 )
            // InternalSM2.g:1231:3: rule__SmartContract__VersionCompilerAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__VersionCompilerAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getVersionCompilerAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__2__Impl"


    // $ANTLR start "rule__SmartContract__Group__3"
    // InternalSM2.g:1239:1: rule__SmartContract__Group__3 : rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4 ;
    public final void rule__SmartContract__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1243:1: ( rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4 )
            // InternalSM2.g:1244:2: rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__3"


    // $ANTLR start "rule__SmartContract__Group__3__Impl"
    // InternalSM2.g:1251:1: rule__SmartContract__Group__3__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__SmartContract__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1255:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:1256:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:1256:1: ( RULE_SEMICOLON )
            // InternalSM2.g:1257:2: RULE_SEMICOLON
            {
             before(grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__3__Impl"


    // $ANTLR start "rule__SmartContract__Group__4"
    // InternalSM2.g:1266:1: rule__SmartContract__Group__4 : rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5 ;
    public final void rule__SmartContract__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1270:1: ( rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5 )
            // InternalSM2.g:1271:2: rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__4"


    // $ANTLR start "rule__SmartContract__Group__4__Impl"
    // InternalSM2.g:1278:1: rule__SmartContract__Group__4__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__SmartContract__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1282:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:1283:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:1283:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:1284:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4()); 
            // InternalSM2.g:1285:2: ( RULE_EOLINE )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==RULE_EOLINE) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalSM2.g:1285:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__4__Impl"


    // $ANTLR start "rule__SmartContract__Group__5"
    // InternalSM2.g:1293:1: rule__SmartContract__Group__5 : rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6 ;
    public final void rule__SmartContract__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1297:1: ( rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6 )
            // InternalSM2.g:1298:2: rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__5"


    // $ANTLR start "rule__SmartContract__Group__5__Impl"
    // InternalSM2.g:1305:1: rule__SmartContract__Group__5__Impl : ( ( rule__SmartContract__ImportsAssignment_5 )* ) ;
    public final void rule__SmartContract__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1309:1: ( ( ( rule__SmartContract__ImportsAssignment_5 )* ) )
            // InternalSM2.g:1310:1: ( ( rule__SmartContract__ImportsAssignment_5 )* )
            {
            // InternalSM2.g:1310:1: ( ( rule__SmartContract__ImportsAssignment_5 )* )
            // InternalSM2.g:1311:2: ( rule__SmartContract__ImportsAssignment_5 )*
            {
             before(grammarAccess.getSmartContractAccess().getImportsAssignment_5()); 
            // InternalSM2.g:1312:2: ( rule__SmartContract__ImportsAssignment_5 )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( (LA17_0==53) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalSM2.g:1312:3: rule__SmartContract__ImportsAssignment_5
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__SmartContract__ImportsAssignment_5();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getImportsAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__5__Impl"


    // $ANTLR start "rule__SmartContract__Group__6"
    // InternalSM2.g:1320:1: rule__SmartContract__Group__6 : rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7 ;
    public final void rule__SmartContract__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1324:1: ( rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7 )
            // InternalSM2.g:1325:2: rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7
            {
            pushFollow(FOLLOW_8);
            rule__SmartContract__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__6"


    // $ANTLR start "rule__SmartContract__Group__6__Impl"
    // InternalSM2.g:1332:1: rule__SmartContract__Group__6__Impl : ( ( rule__SmartContract__ContractAssignment_6 ) ) ;
    public final void rule__SmartContract__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1336:1: ( ( ( rule__SmartContract__ContractAssignment_6 ) ) )
            // InternalSM2.g:1337:1: ( ( rule__SmartContract__ContractAssignment_6 ) )
            {
            // InternalSM2.g:1337:1: ( ( rule__SmartContract__ContractAssignment_6 ) )
            // InternalSM2.g:1338:2: ( rule__SmartContract__ContractAssignment_6 )
            {
             before(grammarAccess.getSmartContractAccess().getContractAssignment_6()); 
            // InternalSM2.g:1339:2: ( rule__SmartContract__ContractAssignment_6 )
            // InternalSM2.g:1339:3: rule__SmartContract__ContractAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__ContractAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getContractAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__6__Impl"


    // $ANTLR start "rule__SmartContract__Group__7"
    // InternalSM2.g:1347:1: rule__SmartContract__Group__7 : rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8 ;
    public final void rule__SmartContract__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1351:1: ( rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8 )
            // InternalSM2.g:1352:2: rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8
            {
            pushFollow(FOLLOW_9);
            rule__SmartContract__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__7"


    // $ANTLR start "rule__SmartContract__Group__7__Impl"
    // InternalSM2.g:1359:1: rule__SmartContract__Group__7__Impl : ( ( rule__SmartContract__NameContractAssignment_7 ) ) ;
    public final void rule__SmartContract__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1363:1: ( ( ( rule__SmartContract__NameContractAssignment_7 ) ) )
            // InternalSM2.g:1364:1: ( ( rule__SmartContract__NameContractAssignment_7 ) )
            {
            // InternalSM2.g:1364:1: ( ( rule__SmartContract__NameContractAssignment_7 ) )
            // InternalSM2.g:1365:2: ( rule__SmartContract__NameContractAssignment_7 )
            {
             before(grammarAccess.getSmartContractAccess().getNameContractAssignment_7()); 
            // InternalSM2.g:1366:2: ( rule__SmartContract__NameContractAssignment_7 )
            // InternalSM2.g:1366:3: rule__SmartContract__NameContractAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__NameContractAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getNameContractAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__7__Impl"


    // $ANTLR start "rule__SmartContract__Group__8"
    // InternalSM2.g:1374:1: rule__SmartContract__Group__8 : rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9 ;
    public final void rule__SmartContract__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1378:1: ( rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9 )
            // InternalSM2.g:1379:2: rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9
            {
            pushFollow(FOLLOW_9);
            rule__SmartContract__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__8"


    // $ANTLR start "rule__SmartContract__Group__8__Impl"
    // InternalSM2.g:1386:1: rule__SmartContract__Group__8__Impl : ( ( rule__SmartContract__Group_8__0 )? ) ;
    public final void rule__SmartContract__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1390:1: ( ( ( rule__SmartContract__Group_8__0 )? ) )
            // InternalSM2.g:1391:1: ( ( rule__SmartContract__Group_8__0 )? )
            {
            // InternalSM2.g:1391:1: ( ( rule__SmartContract__Group_8__0 )? )
            // InternalSM2.g:1392:2: ( rule__SmartContract__Group_8__0 )?
            {
             before(grammarAccess.getSmartContractAccess().getGroup_8()); 
            // InternalSM2.g:1393:2: ( rule__SmartContract__Group_8__0 )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==51) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalSM2.g:1393:3: rule__SmartContract__Group_8__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SmartContract__Group_8__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSmartContractAccess().getGroup_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__8__Impl"


    // $ANTLR start "rule__SmartContract__Group__9"
    // InternalSM2.g:1401:1: rule__SmartContract__Group__9 : rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10 ;
    public final void rule__SmartContract__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1405:1: ( rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10 )
            // InternalSM2.g:1406:2: rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__9"


    // $ANTLR start "rule__SmartContract__Group__9__Impl"
    // InternalSM2.g:1413:1: rule__SmartContract__Group__9__Impl : ( RULE_OPENKEY ) ;
    public final void rule__SmartContract__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1417:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:1418:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:1418:1: ( RULE_OPENKEY )
            // InternalSM2.g:1419:2: RULE_OPENKEY
            {
             before(grammarAccess.getSmartContractAccess().getOPENKEYTerminalRuleCall_9()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getOPENKEYTerminalRuleCall_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__9__Impl"


    // $ANTLR start "rule__SmartContract__Group__10"
    // InternalSM2.g:1428:1: rule__SmartContract__Group__10 : rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11 ;
    public final void rule__SmartContract__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1432:1: ( rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11 )
            // InternalSM2.g:1433:2: rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__10"


    // $ANTLR start "rule__SmartContract__Group__10__Impl"
    // InternalSM2.g:1440:1: rule__SmartContract__Group__10__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__SmartContract__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1444:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:1445:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:1445:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:1446:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_10()); 
            // InternalSM2.g:1447:2: ( RULE_EOLINE )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==RULE_EOLINE) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalSM2.g:1447:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__10__Impl"


    // $ANTLR start "rule__SmartContract__Group__11"
    // InternalSM2.g:1455:1: rule__SmartContract__Group__11 : rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12 ;
    public final void rule__SmartContract__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1459:1: ( rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12 )
            // InternalSM2.g:1460:2: rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__11"


    // $ANTLR start "rule__SmartContract__Group__11__Impl"
    // InternalSM2.g:1467:1: rule__SmartContract__Group__11__Impl : ( ( rule__SmartContract__AttributesAssignment_11 )* ) ;
    public final void rule__SmartContract__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1471:1: ( ( ( rule__SmartContract__AttributesAssignment_11 )* ) )
            // InternalSM2.g:1472:1: ( ( rule__SmartContract__AttributesAssignment_11 )* )
            {
            // InternalSM2.g:1472:1: ( ( rule__SmartContract__AttributesAssignment_11 )* )
            // InternalSM2.g:1473:2: ( rule__SmartContract__AttributesAssignment_11 )*
            {
             before(grammarAccess.getSmartContractAccess().getAttributesAssignment_11()); 
            // InternalSM2.g:1474:2: ( rule__SmartContract__AttributesAssignment_11 )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==RULE_ID||(LA20_0>=22 && LA20_0<=30)||LA20_0==58||(LA20_0>=60 && LA20_0<=61)) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalSM2.g:1474:3: rule__SmartContract__AttributesAssignment_11
            	    {
            	    pushFollow(FOLLOW_11);
            	    rule__SmartContract__AttributesAssignment_11();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getAttributesAssignment_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__11__Impl"


    // $ANTLR start "rule__SmartContract__Group__12"
    // InternalSM2.g:1482:1: rule__SmartContract__Group__12 : rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13 ;
    public final void rule__SmartContract__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1486:1: ( rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13 )
            // InternalSM2.g:1487:2: rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__12"


    // $ANTLR start "rule__SmartContract__Group__12__Impl"
    // InternalSM2.g:1494:1: rule__SmartContract__Group__12__Impl : ( ( rule__SmartContract__EventsAssignment_12 )* ) ;
    public final void rule__SmartContract__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1498:1: ( ( ( rule__SmartContract__EventsAssignment_12 )* ) )
            // InternalSM2.g:1499:1: ( ( rule__SmartContract__EventsAssignment_12 )* )
            {
            // InternalSM2.g:1499:1: ( ( rule__SmartContract__EventsAssignment_12 )* )
            // InternalSM2.g:1500:2: ( rule__SmartContract__EventsAssignment_12 )*
            {
             before(grammarAccess.getSmartContractAccess().getEventsAssignment_12()); 
            // InternalSM2.g:1501:2: ( rule__SmartContract__EventsAssignment_12 )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==55) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalSM2.g:1501:3: rule__SmartContract__EventsAssignment_12
            	    {
            	    pushFollow(FOLLOW_12);
            	    rule__SmartContract__EventsAssignment_12();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getEventsAssignment_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__12__Impl"


    // $ANTLR start "rule__SmartContract__Group__13"
    // InternalSM2.g:1509:1: rule__SmartContract__Group__13 : rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14 ;
    public final void rule__SmartContract__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1513:1: ( rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14 )
            // InternalSM2.g:1514:2: rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__13"


    // $ANTLR start "rule__SmartContract__Group__13__Impl"
    // InternalSM2.g:1521:1: rule__SmartContract__Group__13__Impl : ( ( rule__SmartContract__ModifierAssignment_13 )* ) ;
    public final void rule__SmartContract__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1525:1: ( ( ( rule__SmartContract__ModifierAssignment_13 )* ) )
            // InternalSM2.g:1526:1: ( ( rule__SmartContract__ModifierAssignment_13 )* )
            {
            // InternalSM2.g:1526:1: ( ( rule__SmartContract__ModifierAssignment_13 )* )
            // InternalSM2.g:1527:2: ( rule__SmartContract__ModifierAssignment_13 )*
            {
             before(grammarAccess.getSmartContractAccess().getModifierAssignment_13()); 
            // InternalSM2.g:1528:2: ( rule__SmartContract__ModifierAssignment_13 )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0==56) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // InternalSM2.g:1528:3: rule__SmartContract__ModifierAssignment_13
            	    {
            	    pushFollow(FOLLOW_13);
            	    rule__SmartContract__ModifierAssignment_13();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getModifierAssignment_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__13__Impl"


    // $ANTLR start "rule__SmartContract__Group__14"
    // InternalSM2.g:1536:1: rule__SmartContract__Group__14 : rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15 ;
    public final void rule__SmartContract__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1540:1: ( rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15 )
            // InternalSM2.g:1541:2: rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__14__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__15();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__14"


    // $ANTLR start "rule__SmartContract__Group__14__Impl"
    // InternalSM2.g:1548:1: rule__SmartContract__Group__14__Impl : ( ( rule__SmartContract__ClausesAssignment_14 )* ) ;
    public final void rule__SmartContract__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1552:1: ( ( ( rule__SmartContract__ClausesAssignment_14 )* ) )
            // InternalSM2.g:1553:1: ( ( rule__SmartContract__ClausesAssignment_14 )* )
            {
            // InternalSM2.g:1553:1: ( ( rule__SmartContract__ClausesAssignment_14 )* )
            // InternalSM2.g:1554:2: ( rule__SmartContract__ClausesAssignment_14 )*
            {
             before(grammarAccess.getSmartContractAccess().getClausesAssignment_14()); 
            // InternalSM2.g:1555:2: ( rule__SmartContract__ClausesAssignment_14 )*
            loop23:
            do {
                int alt23=2;
                int LA23_0 = input.LA(1);

                if ( (LA23_0==64) ) {
                    alt23=1;
                }


                switch (alt23) {
            	case 1 :
            	    // InternalSM2.g:1555:3: rule__SmartContract__ClausesAssignment_14
            	    {
            	    pushFollow(FOLLOW_14);
            	    rule__SmartContract__ClausesAssignment_14();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop23;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getClausesAssignment_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__14__Impl"


    // $ANTLR start "rule__SmartContract__Group__15"
    // InternalSM2.g:1563:1: rule__SmartContract__Group__15 : rule__SmartContract__Group__15__Impl rule__SmartContract__Group__16 ;
    public final void rule__SmartContract__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1567:1: ( rule__SmartContract__Group__15__Impl rule__SmartContract__Group__16 )
            // InternalSM2.g:1568:2: rule__SmartContract__Group__15__Impl rule__SmartContract__Group__16
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__15__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__16();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__15"


    // $ANTLR start "rule__SmartContract__Group__15__Impl"
    // InternalSM2.g:1575:1: rule__SmartContract__Group__15__Impl : ( ( rule__SmartContract__CommentsAssignment_15 )* ) ;
    public final void rule__SmartContract__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1579:1: ( ( ( rule__SmartContract__CommentsAssignment_15 )* ) )
            // InternalSM2.g:1580:1: ( ( rule__SmartContract__CommentsAssignment_15 )* )
            {
            // InternalSM2.g:1580:1: ( ( rule__SmartContract__CommentsAssignment_15 )* )
            // InternalSM2.g:1581:2: ( rule__SmartContract__CommentsAssignment_15 )*
            {
             before(grammarAccess.getSmartContractAccess().getCommentsAssignment_15()); 
            // InternalSM2.g:1582:2: ( rule__SmartContract__CommentsAssignment_15 )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( ((LA24_0>=66 && LA24_0<=67)) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalSM2.g:1582:3: rule__SmartContract__CommentsAssignment_15
            	    {
            	    pushFollow(FOLLOW_15);
            	    rule__SmartContract__CommentsAssignment_15();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getCommentsAssignment_15()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__15__Impl"


    // $ANTLR start "rule__SmartContract__Group__16"
    // InternalSM2.g:1590:1: rule__SmartContract__Group__16 : rule__SmartContract__Group__16__Impl ;
    public final void rule__SmartContract__Group__16() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1594:1: ( rule__SmartContract__Group__16__Impl )
            // InternalSM2.g:1595:2: rule__SmartContract__Group__16__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__16__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__16"


    // $ANTLR start "rule__SmartContract__Group__16__Impl"
    // InternalSM2.g:1601:1: rule__SmartContract__Group__16__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__SmartContract__Group__16__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1605:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:1606:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:1606:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:1607:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_16()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_16()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__16__Impl"


    // $ANTLR start "rule__SmartContract__Group_8__0"
    // InternalSM2.g:1617:1: rule__SmartContract__Group_8__0 : rule__SmartContract__Group_8__0__Impl rule__SmartContract__Group_8__1 ;
    public final void rule__SmartContract__Group_8__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1621:1: ( rule__SmartContract__Group_8__0__Impl rule__SmartContract__Group_8__1 )
            // InternalSM2.g:1622:2: rule__SmartContract__Group_8__0__Impl rule__SmartContract__Group_8__1
            {
            pushFollow(FOLLOW_8);
            rule__SmartContract__Group_8__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group_8__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__0"


    // $ANTLR start "rule__SmartContract__Group_8__0__Impl"
    // InternalSM2.g:1629:1: rule__SmartContract__Group_8__0__Impl : ( 'is' ) ;
    public final void rule__SmartContract__Group_8__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1633:1: ( ( 'is' ) )
            // InternalSM2.g:1634:1: ( 'is' )
            {
            // InternalSM2.g:1634:1: ( 'is' )
            // InternalSM2.g:1635:2: 'is'
            {
             before(grammarAccess.getSmartContractAccess().getIsKeyword_8_0()); 
            match(input,51,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getIsKeyword_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__0__Impl"


    // $ANTLR start "rule__SmartContract__Group_8__1"
    // InternalSM2.g:1644:1: rule__SmartContract__Group_8__1 : rule__SmartContract__Group_8__1__Impl ;
    public final void rule__SmartContract__Group_8__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1648:1: ( rule__SmartContract__Group_8__1__Impl )
            // InternalSM2.g:1649:2: rule__SmartContract__Group_8__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group_8__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__1"


    // $ANTLR start "rule__SmartContract__Group_8__1__Impl"
    // InternalSM2.g:1655:1: rule__SmartContract__Group_8__1__Impl : ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) ) ;
    public final void rule__SmartContract__Group_8__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1659:1: ( ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) ) )
            // InternalSM2.g:1660:1: ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) )
            {
            // InternalSM2.g:1660:1: ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) )
            // InternalSM2.g:1661:2: ( rule__SmartContract__NameContractFatherAssignment_8_1 )
            {
             before(grammarAccess.getSmartContractAccess().getNameContractFatherAssignment_8_1()); 
            // InternalSM2.g:1662:2: ( rule__SmartContract__NameContractFatherAssignment_8_1 )
            // InternalSM2.g:1662:3: rule__SmartContract__NameContractFatherAssignment_8_1
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__NameContractFatherAssignment_8_1();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getNameContractFatherAssignment_8_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__1__Impl"


    // $ANTLR start "rule__Version__Group__0"
    // InternalSM2.g:1671:1: rule__Version__Group__0 : rule__Version__Group__0__Impl rule__Version__Group__1 ;
    public final void rule__Version__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1675:1: ( rule__Version__Group__0__Impl rule__Version__Group__1 )
            // InternalSM2.g:1676:2: rule__Version__Group__0__Impl rule__Version__Group__1
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__0"


    // $ANTLR start "rule__Version__Group__0__Impl"
    // InternalSM2.g:1683:1: rule__Version__Group__0__Impl : ( ( rule__Version__SymbolAssignment_0 ) ) ;
    public final void rule__Version__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1687:1: ( ( ( rule__Version__SymbolAssignment_0 ) ) )
            // InternalSM2.g:1688:1: ( ( rule__Version__SymbolAssignment_0 ) )
            {
            // InternalSM2.g:1688:1: ( ( rule__Version__SymbolAssignment_0 ) )
            // InternalSM2.g:1689:2: ( rule__Version__SymbolAssignment_0 )
            {
             before(grammarAccess.getVersionAccess().getSymbolAssignment_0()); 
            // InternalSM2.g:1690:2: ( rule__Version__SymbolAssignment_0 )
            // InternalSM2.g:1690:3: rule__Version__SymbolAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getSymbolAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__0__Impl"


    // $ANTLR start "rule__Version__Group__1"
    // InternalSM2.g:1698:1: rule__Version__Group__1 : rule__Version__Group__1__Impl rule__Version__Group__2 ;
    public final void rule__Version__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1702:1: ( rule__Version__Group__1__Impl rule__Version__Group__2 )
            // InternalSM2.g:1703:2: rule__Version__Group__1__Impl rule__Version__Group__2
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__1"


    // $ANTLR start "rule__Version__Group__1__Impl"
    // InternalSM2.g:1710:1: rule__Version__Group__1__Impl : ( ( rule__Version__NumberVersionAssignment_1 ) ) ;
    public final void rule__Version__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1714:1: ( ( ( rule__Version__NumberVersionAssignment_1 ) ) )
            // InternalSM2.g:1715:1: ( ( rule__Version__NumberVersionAssignment_1 ) )
            {
            // InternalSM2.g:1715:1: ( ( rule__Version__NumberVersionAssignment_1 ) )
            // InternalSM2.g:1716:2: ( rule__Version__NumberVersionAssignment_1 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersionAssignment_1()); 
            // InternalSM2.g:1717:2: ( rule__Version__NumberVersionAssignment_1 )
            // InternalSM2.g:1717:3: rule__Version__NumberVersionAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersionAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__1__Impl"


    // $ANTLR start "rule__Version__Group__2"
    // InternalSM2.g:1725:1: rule__Version__Group__2 : rule__Version__Group__2__Impl rule__Version__Group__3 ;
    public final void rule__Version__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1729:1: ( rule__Version__Group__2__Impl rule__Version__Group__3 )
            // InternalSM2.g:1730:2: rule__Version__Group__2__Impl rule__Version__Group__3
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__2"


    // $ANTLR start "rule__Version__Group__2__Impl"
    // InternalSM2.g:1737:1: rule__Version__Group__2__Impl : ( '.' ) ;
    public final void rule__Version__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1741:1: ( ( '.' ) )
            // InternalSM2.g:1742:1: ( '.' )
            {
            // InternalSM2.g:1742:1: ( '.' )
            // InternalSM2.g:1743:2: '.'
            {
             before(grammarAccess.getVersionAccess().getFullStopKeyword_2()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getFullStopKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__2__Impl"


    // $ANTLR start "rule__Version__Group__3"
    // InternalSM2.g:1752:1: rule__Version__Group__3 : rule__Version__Group__3__Impl rule__Version__Group__4 ;
    public final void rule__Version__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1756:1: ( rule__Version__Group__3__Impl rule__Version__Group__4 )
            // InternalSM2.g:1757:2: rule__Version__Group__3__Impl rule__Version__Group__4
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__3"


    // $ANTLR start "rule__Version__Group__3__Impl"
    // InternalSM2.g:1764:1: rule__Version__Group__3__Impl : ( ( rule__Version__NumberVersion2Assignment_3 ) ) ;
    public final void rule__Version__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1768:1: ( ( ( rule__Version__NumberVersion2Assignment_3 ) ) )
            // InternalSM2.g:1769:1: ( ( rule__Version__NumberVersion2Assignment_3 ) )
            {
            // InternalSM2.g:1769:1: ( ( rule__Version__NumberVersion2Assignment_3 ) )
            // InternalSM2.g:1770:2: ( rule__Version__NumberVersion2Assignment_3 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersion2Assignment_3()); 
            // InternalSM2.g:1771:2: ( rule__Version__NumberVersion2Assignment_3 )
            // InternalSM2.g:1771:3: rule__Version__NumberVersion2Assignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion2Assignment_3();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersion2Assignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__3__Impl"


    // $ANTLR start "rule__Version__Group__4"
    // InternalSM2.g:1779:1: rule__Version__Group__4 : rule__Version__Group__4__Impl rule__Version__Group__5 ;
    public final void rule__Version__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1783:1: ( rule__Version__Group__4__Impl rule__Version__Group__5 )
            // InternalSM2.g:1784:2: rule__Version__Group__4__Impl rule__Version__Group__5
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__4"


    // $ANTLR start "rule__Version__Group__4__Impl"
    // InternalSM2.g:1791:1: rule__Version__Group__4__Impl : ( '.' ) ;
    public final void rule__Version__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1795:1: ( ( '.' ) )
            // InternalSM2.g:1796:1: ( '.' )
            {
            // InternalSM2.g:1796:1: ( '.' )
            // InternalSM2.g:1797:2: '.'
            {
             before(grammarAccess.getVersionAccess().getFullStopKeyword_4()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getFullStopKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__4__Impl"


    // $ANTLR start "rule__Version__Group__5"
    // InternalSM2.g:1806:1: rule__Version__Group__5 : rule__Version__Group__5__Impl rule__Version__Group__6 ;
    public final void rule__Version__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1810:1: ( rule__Version__Group__5__Impl rule__Version__Group__6 )
            // InternalSM2.g:1811:2: rule__Version__Group__5__Impl rule__Version__Group__6
            {
            pushFollow(FOLLOW_8);
            rule__Version__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__5"


    // $ANTLR start "rule__Version__Group__5__Impl"
    // InternalSM2.g:1818:1: rule__Version__Group__5__Impl : ( ( rule__Version__NumberVersion3Assignment_5 ) ) ;
    public final void rule__Version__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1822:1: ( ( ( rule__Version__NumberVersion3Assignment_5 ) ) )
            // InternalSM2.g:1823:1: ( ( rule__Version__NumberVersion3Assignment_5 ) )
            {
            // InternalSM2.g:1823:1: ( ( rule__Version__NumberVersion3Assignment_5 ) )
            // InternalSM2.g:1824:2: ( rule__Version__NumberVersion3Assignment_5 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersion3Assignment_5()); 
            // InternalSM2.g:1825:2: ( rule__Version__NumberVersion3Assignment_5 )
            // InternalSM2.g:1825:3: rule__Version__NumberVersion3Assignment_5
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion3Assignment_5();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersion3Assignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__5__Impl"


    // $ANTLR start "rule__Version__Group__6"
    // InternalSM2.g:1833:1: rule__Version__Group__6 : rule__Version__Group__6__Impl ;
    public final void rule__Version__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1837:1: ( rule__Version__Group__6__Impl )
            // InternalSM2.g:1838:2: rule__Version__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__6"


    // $ANTLR start "rule__Version__Group__6__Impl"
    // InternalSM2.g:1844:1: rule__Version__Group__6__Impl : ( ( rule__Version__OptionalversionAssignment_6 )? ) ;
    public final void rule__Version__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1848:1: ( ( ( rule__Version__OptionalversionAssignment_6 )? ) )
            // InternalSM2.g:1849:1: ( ( rule__Version__OptionalversionAssignment_6 )? )
            {
            // InternalSM2.g:1849:1: ( ( rule__Version__OptionalversionAssignment_6 )? )
            // InternalSM2.g:1850:2: ( rule__Version__OptionalversionAssignment_6 )?
            {
             before(grammarAccess.getVersionAccess().getOptionalversionAssignment_6()); 
            // InternalSM2.g:1851:2: ( rule__Version__OptionalversionAssignment_6 )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==RULE_ID) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalSM2.g:1851:3: rule__Version__OptionalversionAssignment_6
                    {
                    pushFollow(FOLLOW_2);
                    rule__Version__OptionalversionAssignment_6();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getVersionAccess().getOptionalversionAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__6__Impl"


    // $ANTLR start "rule__Import__Group__0"
    // InternalSM2.g:1860:1: rule__Import__Group__0 : rule__Import__Group__0__Impl rule__Import__Group__1 ;
    public final void rule__Import__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1864:1: ( rule__Import__Group__0__Impl rule__Import__Group__1 )
            // InternalSM2.g:1865:2: rule__Import__Group__0__Impl rule__Import__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Import__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0"


    // $ANTLR start "rule__Import__Group__0__Impl"
    // InternalSM2.g:1872:1: rule__Import__Group__0__Impl : ( 'import' ) ;
    public final void rule__Import__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1876:1: ( ( 'import' ) )
            // InternalSM2.g:1877:1: ( 'import' )
            {
            // InternalSM2.g:1877:1: ( 'import' )
            // InternalSM2.g:1878:2: 'import'
            {
             before(grammarAccess.getImportAccess().getImportKeyword_0()); 
            match(input,53,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getImportKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0__Impl"


    // $ANTLR start "rule__Import__Group__1"
    // InternalSM2.g:1887:1: rule__Import__Group__1 : rule__Import__Group__1__Impl rule__Import__Group__2 ;
    public final void rule__Import__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1891:1: ( rule__Import__Group__1__Impl rule__Import__Group__2 )
            // InternalSM2.g:1892:2: rule__Import__Group__1__Impl rule__Import__Group__2
            {
            pushFollow(FOLLOW_18);
            rule__Import__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1"


    // $ANTLR start "rule__Import__Group__1__Impl"
    // InternalSM2.g:1899:1: rule__Import__Group__1__Impl : ( ( rule__Import__NameLibraryAssignment_1 ) ) ;
    public final void rule__Import__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1903:1: ( ( ( rule__Import__NameLibraryAssignment_1 ) ) )
            // InternalSM2.g:1904:1: ( ( rule__Import__NameLibraryAssignment_1 ) )
            {
            // InternalSM2.g:1904:1: ( ( rule__Import__NameLibraryAssignment_1 ) )
            // InternalSM2.g:1905:2: ( rule__Import__NameLibraryAssignment_1 )
            {
             before(grammarAccess.getImportAccess().getNameLibraryAssignment_1()); 
            // InternalSM2.g:1906:2: ( rule__Import__NameLibraryAssignment_1 )
            // InternalSM2.g:1906:3: rule__Import__NameLibraryAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Import__NameLibraryAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getImportAccess().getNameLibraryAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1__Impl"


    // $ANTLR start "rule__Import__Group__2"
    // InternalSM2.g:1914:1: rule__Import__Group__2 : rule__Import__Group__2__Impl rule__Import__Group__3 ;
    public final void rule__Import__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1918:1: ( rule__Import__Group__2__Impl rule__Import__Group__3 )
            // InternalSM2.g:1919:2: rule__Import__Group__2__Impl rule__Import__Group__3
            {
            pushFollow(FOLLOW_18);
            rule__Import__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__2"


    // $ANTLR start "rule__Import__Group__2__Impl"
    // InternalSM2.g:1926:1: rule__Import__Group__2__Impl : ( ( rule__Import__Group_2__0 )? ) ;
    public final void rule__Import__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1930:1: ( ( ( rule__Import__Group_2__0 )? ) )
            // InternalSM2.g:1931:1: ( ( rule__Import__Group_2__0 )? )
            {
            // InternalSM2.g:1931:1: ( ( rule__Import__Group_2__0 )? )
            // InternalSM2.g:1932:2: ( rule__Import__Group_2__0 )?
            {
             before(grammarAccess.getImportAccess().getGroup_2()); 
            // InternalSM2.g:1933:2: ( rule__Import__Group_2__0 )?
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==54) ) {
                alt26=1;
            }
            switch (alt26) {
                case 1 :
                    // InternalSM2.g:1933:3: rule__Import__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Import__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getImportAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__2__Impl"


    // $ANTLR start "rule__Import__Group__3"
    // InternalSM2.g:1941:1: rule__Import__Group__3 : rule__Import__Group__3__Impl rule__Import__Group__4 ;
    public final void rule__Import__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1945:1: ( rule__Import__Group__3__Impl rule__Import__Group__4 )
            // InternalSM2.g:1946:2: rule__Import__Group__3__Impl rule__Import__Group__4
            {
            pushFollow(FOLLOW_19);
            rule__Import__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__3"


    // $ANTLR start "rule__Import__Group__3__Impl"
    // InternalSM2.g:1953:1: rule__Import__Group__3__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Import__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1957:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:1958:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:1958:1: ( RULE_SEMICOLON )
            // InternalSM2.g:1959:2: RULE_SEMICOLON
            {
             before(grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_3()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__3__Impl"


    // $ANTLR start "rule__Import__Group__4"
    // InternalSM2.g:1968:1: rule__Import__Group__4 : rule__Import__Group__4__Impl ;
    public final void rule__Import__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1972:1: ( rule__Import__Group__4__Impl )
            // InternalSM2.g:1973:2: rule__Import__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__4"


    // $ANTLR start "rule__Import__Group__4__Impl"
    // InternalSM2.g:1979:1: rule__Import__Group__4__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Import__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1983:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:1984:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:1984:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:1985:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getImportAccess().getEOLINETerminalRuleCall_4()); 
            // InternalSM2.g:1986:2: ( RULE_EOLINE )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==RULE_EOLINE) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalSM2.g:1986:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getImportAccess().getEOLINETerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__4__Impl"


    // $ANTLR start "rule__Import__Group_2__0"
    // InternalSM2.g:1995:1: rule__Import__Group_2__0 : rule__Import__Group_2__0__Impl rule__Import__Group_2__1 ;
    public final void rule__Import__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1999:1: ( rule__Import__Group_2__0__Impl rule__Import__Group_2__1 )
            // InternalSM2.g:2000:2: rule__Import__Group_2__0__Impl rule__Import__Group_2__1
            {
            pushFollow(FOLLOW_8);
            rule__Import__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__0"


    // $ANTLR start "rule__Import__Group_2__0__Impl"
    // InternalSM2.g:2007:1: rule__Import__Group_2__0__Impl : ( 'as' ) ;
    public final void rule__Import__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2011:1: ( ( 'as' ) )
            // InternalSM2.g:2012:1: ( 'as' )
            {
            // InternalSM2.g:2012:1: ( 'as' )
            // InternalSM2.g:2013:2: 'as'
            {
             before(grammarAccess.getImportAccess().getAsKeyword_2_0()); 
            match(input,54,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getAsKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__0__Impl"


    // $ANTLR start "rule__Import__Group_2__1"
    // InternalSM2.g:2022:1: rule__Import__Group_2__1 : rule__Import__Group_2__1__Impl ;
    public final void rule__Import__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2026:1: ( rule__Import__Group_2__1__Impl )
            // InternalSM2.g:2027:2: rule__Import__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__1"


    // $ANTLR start "rule__Import__Group_2__1__Impl"
    // InternalSM2.g:2033:1: rule__Import__Group_2__1__Impl : ( ( rule__Import__AliasAssignment_2_1 ) ) ;
    public final void rule__Import__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2037:1: ( ( ( rule__Import__AliasAssignment_2_1 ) ) )
            // InternalSM2.g:2038:1: ( ( rule__Import__AliasAssignment_2_1 ) )
            {
            // InternalSM2.g:2038:1: ( ( rule__Import__AliasAssignment_2_1 ) )
            // InternalSM2.g:2039:2: ( rule__Import__AliasAssignment_2_1 )
            {
             before(grammarAccess.getImportAccess().getAliasAssignment_2_1()); 
            // InternalSM2.g:2040:2: ( rule__Import__AliasAssignment_2_1 )
            // InternalSM2.g:2040:3: rule__Import__AliasAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Import__AliasAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getImportAccess().getAliasAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__1__Impl"


    // $ANTLR start "rule__Event__Group__0"
    // InternalSM2.g:2049:1: rule__Event__Group__0 : rule__Event__Group__0__Impl rule__Event__Group__1 ;
    public final void rule__Event__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2053:1: ( rule__Event__Group__0__Impl rule__Event__Group__1 )
            // InternalSM2.g:2054:2: rule__Event__Group__0__Impl rule__Event__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Event__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Event__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__0"


    // $ANTLR start "rule__Event__Group__0__Impl"
    // InternalSM2.g:2061:1: rule__Event__Group__0__Impl : ( 'event' ) ;
    public final void rule__Event__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2065:1: ( ( 'event' ) )
            // InternalSM2.g:2066:1: ( 'event' )
            {
            // InternalSM2.g:2066:1: ( 'event' )
            // InternalSM2.g:2067:2: 'event'
            {
             before(grammarAccess.getEventAccess().getEventKeyword_0()); 
            match(input,55,FOLLOW_2); 
             after(grammarAccess.getEventAccess().getEventKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__0__Impl"


    // $ANTLR start "rule__Event__Group__1"
    // InternalSM2.g:2076:1: rule__Event__Group__1 : rule__Event__Group__1__Impl rule__Event__Group__2 ;
    public final void rule__Event__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2080:1: ( rule__Event__Group__1__Impl rule__Event__Group__2 )
            // InternalSM2.g:2081:2: rule__Event__Group__1__Impl rule__Event__Group__2
            {
            pushFollow(FOLLOW_20);
            rule__Event__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Event__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__1"


    // $ANTLR start "rule__Event__Group__1__Impl"
    // InternalSM2.g:2088:1: rule__Event__Group__1__Impl : ( ( rule__Event__NameEventAssignment_1 ) ) ;
    public final void rule__Event__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2092:1: ( ( ( rule__Event__NameEventAssignment_1 ) ) )
            // InternalSM2.g:2093:1: ( ( rule__Event__NameEventAssignment_1 ) )
            {
            // InternalSM2.g:2093:1: ( ( rule__Event__NameEventAssignment_1 ) )
            // InternalSM2.g:2094:2: ( rule__Event__NameEventAssignment_1 )
            {
             before(grammarAccess.getEventAccess().getNameEventAssignment_1()); 
            // InternalSM2.g:2095:2: ( rule__Event__NameEventAssignment_1 )
            // InternalSM2.g:2095:3: rule__Event__NameEventAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Event__NameEventAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEventAccess().getNameEventAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__1__Impl"


    // $ANTLR start "rule__Event__Group__2"
    // InternalSM2.g:2103:1: rule__Event__Group__2 : rule__Event__Group__2__Impl rule__Event__Group__3 ;
    public final void rule__Event__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2107:1: ( rule__Event__Group__2__Impl rule__Event__Group__3 )
            // InternalSM2.g:2108:2: rule__Event__Group__2__Impl rule__Event__Group__3
            {
            pushFollow(FOLLOW_21);
            rule__Event__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Event__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__2"


    // $ANTLR start "rule__Event__Group__2__Impl"
    // InternalSM2.g:2115:1: rule__Event__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Event__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2119:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:2120:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:2120:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:2121:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__2__Impl"


    // $ANTLR start "rule__Event__Group__3"
    // InternalSM2.g:2130:1: rule__Event__Group__3 : rule__Event__Group__3__Impl rule__Event__Group__4 ;
    public final void rule__Event__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2134:1: ( rule__Event__Group__3__Impl rule__Event__Group__4 )
            // InternalSM2.g:2135:2: rule__Event__Group__3__Impl rule__Event__Group__4
            {
            pushFollow(FOLLOW_21);
            rule__Event__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Event__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__3"


    // $ANTLR start "rule__Event__Group__3__Impl"
    // InternalSM2.g:2142:1: rule__Event__Group__3__Impl : ( ( rule__Event__InputParamsAssignment_3 )* ) ;
    public final void rule__Event__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2146:1: ( ( ( rule__Event__InputParamsAssignment_3 )* ) )
            // InternalSM2.g:2147:1: ( ( rule__Event__InputParamsAssignment_3 )* )
            {
            // InternalSM2.g:2147:1: ( ( rule__Event__InputParamsAssignment_3 )* )
            // InternalSM2.g:2148:2: ( rule__Event__InputParamsAssignment_3 )*
            {
             before(grammarAccess.getEventAccess().getInputParamsAssignment_3()); 
            // InternalSM2.g:2149:2: ( rule__Event__InputParamsAssignment_3 )*
            loop28:
            do {
                int alt28=2;
                int LA28_0 = input.LA(1);

                if ( ((LA28_0>=22 && LA28_0<=30)) ) {
                    alt28=1;
                }


                switch (alt28) {
            	case 1 :
            	    // InternalSM2.g:2149:3: rule__Event__InputParamsAssignment_3
            	    {
            	    pushFollow(FOLLOW_22);
            	    rule__Event__InputParamsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop28;
                }
            } while (true);

             after(grammarAccess.getEventAccess().getInputParamsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__3__Impl"


    // $ANTLR start "rule__Event__Group__4"
    // InternalSM2.g:2157:1: rule__Event__Group__4 : rule__Event__Group__4__Impl rule__Event__Group__5 ;
    public final void rule__Event__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2161:1: ( rule__Event__Group__4__Impl rule__Event__Group__5 )
            // InternalSM2.g:2162:2: rule__Event__Group__4__Impl rule__Event__Group__5
            {
            pushFollow(FOLLOW_5);
            rule__Event__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Event__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__4"


    // $ANTLR start "rule__Event__Group__4__Impl"
    // InternalSM2.g:2169:1: rule__Event__Group__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Event__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2173:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2174:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2174:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2175:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__4__Impl"


    // $ANTLR start "rule__Event__Group__5"
    // InternalSM2.g:2184:1: rule__Event__Group__5 : rule__Event__Group__5__Impl rule__Event__Group__6 ;
    public final void rule__Event__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2188:1: ( rule__Event__Group__5__Impl rule__Event__Group__6 )
            // InternalSM2.g:2189:2: rule__Event__Group__5__Impl rule__Event__Group__6
            {
            pushFollow(FOLLOW_19);
            rule__Event__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Event__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__5"


    // $ANTLR start "rule__Event__Group__5__Impl"
    // InternalSM2.g:2196:1: rule__Event__Group__5__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Event__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2200:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:2201:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:2201:1: ( RULE_SEMICOLON )
            // InternalSM2.g:2202:2: RULE_SEMICOLON
            {
             before(grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__5__Impl"


    // $ANTLR start "rule__Event__Group__6"
    // InternalSM2.g:2211:1: rule__Event__Group__6 : rule__Event__Group__6__Impl ;
    public final void rule__Event__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2215:1: ( rule__Event__Group__6__Impl )
            // InternalSM2.g:2216:2: rule__Event__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Event__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__6"


    // $ANTLR start "rule__Event__Group__6__Impl"
    // InternalSM2.g:2222:1: rule__Event__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Event__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2226:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2227:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2227:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2228:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6()); 
            // InternalSM2.g:2229:2: ( RULE_EOLINE )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==RULE_EOLINE) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalSM2.g:2229:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__6__Impl"


    // $ANTLR start "rule__Modifier__Group__0"
    // InternalSM2.g:2238:1: rule__Modifier__Group__0 : rule__Modifier__Group__0__Impl rule__Modifier__Group__1 ;
    public final void rule__Modifier__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2242:1: ( rule__Modifier__Group__0__Impl rule__Modifier__Group__1 )
            // InternalSM2.g:2243:2: rule__Modifier__Group__0__Impl rule__Modifier__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Modifier__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__0"


    // $ANTLR start "rule__Modifier__Group__0__Impl"
    // InternalSM2.g:2250:1: rule__Modifier__Group__0__Impl : ( 'modifier' ) ;
    public final void rule__Modifier__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2254:1: ( ( 'modifier' ) )
            // InternalSM2.g:2255:1: ( 'modifier' )
            {
            // InternalSM2.g:2255:1: ( 'modifier' )
            // InternalSM2.g:2256:2: 'modifier'
            {
             before(grammarAccess.getModifierAccess().getModifierKeyword_0()); 
            match(input,56,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getModifierKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__0__Impl"


    // $ANTLR start "rule__Modifier__Group__1"
    // InternalSM2.g:2265:1: rule__Modifier__Group__1 : rule__Modifier__Group__1__Impl rule__Modifier__Group__2 ;
    public final void rule__Modifier__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2269:1: ( rule__Modifier__Group__1__Impl rule__Modifier__Group__2 )
            // InternalSM2.g:2270:2: rule__Modifier__Group__1__Impl rule__Modifier__Group__2
            {
            pushFollow(FOLLOW_20);
            rule__Modifier__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__1"


    // $ANTLR start "rule__Modifier__Group__1__Impl"
    // InternalSM2.g:2277:1: rule__Modifier__Group__1__Impl : ( ( rule__Modifier__NameModifierAssignment_1 ) ) ;
    public final void rule__Modifier__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2281:1: ( ( ( rule__Modifier__NameModifierAssignment_1 ) ) )
            // InternalSM2.g:2282:1: ( ( rule__Modifier__NameModifierAssignment_1 ) )
            {
            // InternalSM2.g:2282:1: ( ( rule__Modifier__NameModifierAssignment_1 ) )
            // InternalSM2.g:2283:2: ( rule__Modifier__NameModifierAssignment_1 )
            {
             before(grammarAccess.getModifierAccess().getNameModifierAssignment_1()); 
            // InternalSM2.g:2284:2: ( rule__Modifier__NameModifierAssignment_1 )
            // InternalSM2.g:2284:3: rule__Modifier__NameModifierAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__NameModifierAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getModifierAccess().getNameModifierAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__1__Impl"


    // $ANTLR start "rule__Modifier__Group__2"
    // InternalSM2.g:2292:1: rule__Modifier__Group__2 : rule__Modifier__Group__2__Impl rule__Modifier__Group__3 ;
    public final void rule__Modifier__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2296:1: ( rule__Modifier__Group__2__Impl rule__Modifier__Group__3 )
            // InternalSM2.g:2297:2: rule__Modifier__Group__2__Impl rule__Modifier__Group__3
            {
            pushFollow(FOLLOW_21);
            rule__Modifier__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__2"


    // $ANTLR start "rule__Modifier__Group__2__Impl"
    // InternalSM2.g:2304:1: rule__Modifier__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Modifier__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2308:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:2309:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:2309:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:2310:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__2__Impl"


    // $ANTLR start "rule__Modifier__Group__3"
    // InternalSM2.g:2319:1: rule__Modifier__Group__3 : rule__Modifier__Group__3__Impl rule__Modifier__Group__4 ;
    public final void rule__Modifier__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2323:1: ( rule__Modifier__Group__3__Impl rule__Modifier__Group__4 )
            // InternalSM2.g:2324:2: rule__Modifier__Group__3__Impl rule__Modifier__Group__4
            {
            pushFollow(FOLLOW_21);
            rule__Modifier__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__3"


    // $ANTLR start "rule__Modifier__Group__3__Impl"
    // InternalSM2.g:2331:1: rule__Modifier__Group__3__Impl : ( ( rule__Modifier__InputParamsAssignment_3 )* ) ;
    public final void rule__Modifier__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2335:1: ( ( ( rule__Modifier__InputParamsAssignment_3 )* ) )
            // InternalSM2.g:2336:1: ( ( rule__Modifier__InputParamsAssignment_3 )* )
            {
            // InternalSM2.g:2336:1: ( ( rule__Modifier__InputParamsAssignment_3 )* )
            // InternalSM2.g:2337:2: ( rule__Modifier__InputParamsAssignment_3 )*
            {
             before(grammarAccess.getModifierAccess().getInputParamsAssignment_3()); 
            // InternalSM2.g:2338:2: ( rule__Modifier__InputParamsAssignment_3 )*
            loop30:
            do {
                int alt30=2;
                int LA30_0 = input.LA(1);

                if ( ((LA30_0>=22 && LA30_0<=30)) ) {
                    alt30=1;
                }


                switch (alt30) {
            	case 1 :
            	    // InternalSM2.g:2338:3: rule__Modifier__InputParamsAssignment_3
            	    {
            	    pushFollow(FOLLOW_22);
            	    rule__Modifier__InputParamsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop30;
                }
            } while (true);

             after(grammarAccess.getModifierAccess().getInputParamsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__3__Impl"


    // $ANTLR start "rule__Modifier__Group__4"
    // InternalSM2.g:2346:1: rule__Modifier__Group__4 : rule__Modifier__Group__4__Impl rule__Modifier__Group__5 ;
    public final void rule__Modifier__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2350:1: ( rule__Modifier__Group__4__Impl rule__Modifier__Group__5 )
            // InternalSM2.g:2351:2: rule__Modifier__Group__4__Impl rule__Modifier__Group__5
            {
            pushFollow(FOLLOW_23);
            rule__Modifier__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__4"


    // $ANTLR start "rule__Modifier__Group__4__Impl"
    // InternalSM2.g:2358:1: rule__Modifier__Group__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Modifier__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2362:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2363:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2363:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2364:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__4__Impl"


    // $ANTLR start "rule__Modifier__Group__5"
    // InternalSM2.g:2373:1: rule__Modifier__Group__5 : rule__Modifier__Group__5__Impl rule__Modifier__Group__6 ;
    public final void rule__Modifier__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2377:1: ( rule__Modifier__Group__5__Impl rule__Modifier__Group__6 )
            // InternalSM2.g:2378:2: rule__Modifier__Group__5__Impl rule__Modifier__Group__6
            {
            pushFollow(FOLLOW_24);
            rule__Modifier__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__5"


    // $ANTLR start "rule__Modifier__Group__5__Impl"
    // InternalSM2.g:2385:1: rule__Modifier__Group__5__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Modifier__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2389:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:2390:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:2390:1: ( RULE_OPENKEY )
            // InternalSM2.g:2391:2: RULE_OPENKEY
            {
             before(grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__5__Impl"


    // $ANTLR start "rule__Modifier__Group__6"
    // InternalSM2.g:2400:1: rule__Modifier__Group__6 : rule__Modifier__Group__6__Impl rule__Modifier__Group__7 ;
    public final void rule__Modifier__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2404:1: ( rule__Modifier__Group__6__Impl rule__Modifier__Group__7 )
            // InternalSM2.g:2405:2: rule__Modifier__Group__6__Impl rule__Modifier__Group__7
            {
            pushFollow(FOLLOW_24);
            rule__Modifier__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__6"


    // $ANTLR start "rule__Modifier__Group__6__Impl"
    // InternalSM2.g:2412:1: rule__Modifier__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2416:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2417:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2417:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2418:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6()); 
            // InternalSM2.g:2419:2: ( RULE_EOLINE )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==RULE_EOLINE) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalSM2.g:2419:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__6__Impl"


    // $ANTLR start "rule__Modifier__Group__7"
    // InternalSM2.g:2427:1: rule__Modifier__Group__7 : rule__Modifier__Group__7__Impl rule__Modifier__Group__8 ;
    public final void rule__Modifier__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2431:1: ( rule__Modifier__Group__7__Impl rule__Modifier__Group__8 )
            // InternalSM2.g:2432:2: rule__Modifier__Group__7__Impl rule__Modifier__Group__8
            {
            pushFollow(FOLLOW_5);
            rule__Modifier__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__7"


    // $ANTLR start "rule__Modifier__Group__7__Impl"
    // InternalSM2.g:2439:1: rule__Modifier__Group__7__Impl : ( ( rule__Modifier__ExprAssignment_7 ) ) ;
    public final void rule__Modifier__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2443:1: ( ( ( rule__Modifier__ExprAssignment_7 ) ) )
            // InternalSM2.g:2444:1: ( ( rule__Modifier__ExprAssignment_7 ) )
            {
            // InternalSM2.g:2444:1: ( ( rule__Modifier__ExprAssignment_7 ) )
            // InternalSM2.g:2445:2: ( rule__Modifier__ExprAssignment_7 )
            {
             before(grammarAccess.getModifierAccess().getExprAssignment_7()); 
            // InternalSM2.g:2446:2: ( rule__Modifier__ExprAssignment_7 )
            // InternalSM2.g:2446:3: rule__Modifier__ExprAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__ExprAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getModifierAccess().getExprAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__7__Impl"


    // $ANTLR start "rule__Modifier__Group__8"
    // InternalSM2.g:2454:1: rule__Modifier__Group__8 : rule__Modifier__Group__8__Impl rule__Modifier__Group__9 ;
    public final void rule__Modifier__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2458:1: ( rule__Modifier__Group__8__Impl rule__Modifier__Group__9 )
            // InternalSM2.g:2459:2: rule__Modifier__Group__8__Impl rule__Modifier__Group__9
            {
            pushFollow(FOLLOW_25);
            rule__Modifier__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__8"


    // $ANTLR start "rule__Modifier__Group__8__Impl"
    // InternalSM2.g:2466:1: rule__Modifier__Group__8__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Modifier__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2470:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:2471:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:2471:1: ( RULE_SEMICOLON )
            // InternalSM2.g:2472:2: RULE_SEMICOLON
            {
             before(grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__8__Impl"


    // $ANTLR start "rule__Modifier__Group__9"
    // InternalSM2.g:2481:1: rule__Modifier__Group__9 : rule__Modifier__Group__9__Impl rule__Modifier__Group__10 ;
    public final void rule__Modifier__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2485:1: ( rule__Modifier__Group__9__Impl rule__Modifier__Group__10 )
            // InternalSM2.g:2486:2: rule__Modifier__Group__9__Impl rule__Modifier__Group__10
            {
            pushFollow(FOLLOW_25);
            rule__Modifier__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__9"


    // $ANTLR start "rule__Modifier__Group__9__Impl"
    // InternalSM2.g:2493:1: rule__Modifier__Group__9__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2497:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2498:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2498:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2499:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9()); 
            // InternalSM2.g:2500:2: ( RULE_EOLINE )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==RULE_EOLINE) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalSM2.g:2500:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__9__Impl"


    // $ANTLR start "rule__Modifier__Group__10"
    // InternalSM2.g:2508:1: rule__Modifier__Group__10 : rule__Modifier__Group__10__Impl rule__Modifier__Group__11 ;
    public final void rule__Modifier__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2512:1: ( rule__Modifier__Group__10__Impl rule__Modifier__Group__11 )
            // InternalSM2.g:2513:2: rule__Modifier__Group__10__Impl rule__Modifier__Group__11
            {
            pushFollow(FOLLOW_26);
            rule__Modifier__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__10"


    // $ANTLR start "rule__Modifier__Group__10__Impl"
    // InternalSM2.g:2520:1: rule__Modifier__Group__10__Impl : ( '_;' ) ;
    public final void rule__Modifier__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2524:1: ( ( '_;' ) )
            // InternalSM2.g:2525:1: ( '_;' )
            {
            // InternalSM2.g:2525:1: ( '_;' )
            // InternalSM2.g:2526:2: '_;'
            {
             before(grammarAccess.getModifierAccess().get_Keyword_10()); 
            match(input,57,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().get_Keyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__10__Impl"


    // $ANTLR start "rule__Modifier__Group__11"
    // InternalSM2.g:2535:1: rule__Modifier__Group__11 : rule__Modifier__Group__11__Impl rule__Modifier__Group__12 ;
    public final void rule__Modifier__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2539:1: ( rule__Modifier__Group__11__Impl rule__Modifier__Group__12 )
            // InternalSM2.g:2540:2: rule__Modifier__Group__11__Impl rule__Modifier__Group__12
            {
            pushFollow(FOLLOW_19);
            rule__Modifier__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__11"


    // $ANTLR start "rule__Modifier__Group__11__Impl"
    // InternalSM2.g:2547:1: rule__Modifier__Group__11__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Modifier__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2551:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:2552:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:2552:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:2553:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__11__Impl"


    // $ANTLR start "rule__Modifier__Group__12"
    // InternalSM2.g:2562:1: rule__Modifier__Group__12 : rule__Modifier__Group__12__Impl ;
    public final void rule__Modifier__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2566:1: ( rule__Modifier__Group__12__Impl )
            // InternalSM2.g:2567:2: rule__Modifier__Group__12__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__12__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__12"


    // $ANTLR start "rule__Modifier__Group__12__Impl"
    // InternalSM2.g:2573:1: rule__Modifier__Group__12__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2577:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2578:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2578:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2579:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12()); 
            // InternalSM2.g:2580:2: ( RULE_EOLINE )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==RULE_EOLINE) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // InternalSM2.g:2580:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__12__Impl"


    // $ANTLR start "rule__Mapping__Group__0"
    // InternalSM2.g:2589:1: rule__Mapping__Group__0 : rule__Mapping__Group__0__Impl rule__Mapping__Group__1 ;
    public final void rule__Mapping__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2593:1: ( rule__Mapping__Group__0__Impl rule__Mapping__Group__1 )
            // InternalSM2.g:2594:2: rule__Mapping__Group__0__Impl rule__Mapping__Group__1
            {
            pushFollow(FOLLOW_20);
            rule__Mapping__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__0"


    // $ANTLR start "rule__Mapping__Group__0__Impl"
    // InternalSM2.g:2601:1: rule__Mapping__Group__0__Impl : ( 'mapping' ) ;
    public final void rule__Mapping__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2605:1: ( ( 'mapping' ) )
            // InternalSM2.g:2606:1: ( 'mapping' )
            {
            // InternalSM2.g:2606:1: ( 'mapping' )
            // InternalSM2.g:2607:2: 'mapping'
            {
             before(grammarAccess.getMappingAccess().getMappingKeyword_0()); 
            match(input,58,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getMappingKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__0__Impl"


    // $ANTLR start "rule__Mapping__Group__1"
    // InternalSM2.g:2616:1: rule__Mapping__Group__1 : rule__Mapping__Group__1__Impl rule__Mapping__Group__2 ;
    public final void rule__Mapping__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2620:1: ( rule__Mapping__Group__1__Impl rule__Mapping__Group__2 )
            // InternalSM2.g:2621:2: rule__Mapping__Group__1__Impl rule__Mapping__Group__2
            {
            pushFollow(FOLLOW_27);
            rule__Mapping__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__1"


    // $ANTLR start "rule__Mapping__Group__1__Impl"
    // InternalSM2.g:2628:1: rule__Mapping__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Mapping__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2632:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:2633:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:2633:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:2634:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__1__Impl"


    // $ANTLR start "rule__Mapping__Group__2"
    // InternalSM2.g:2643:1: rule__Mapping__Group__2 : rule__Mapping__Group__2__Impl rule__Mapping__Group__3 ;
    public final void rule__Mapping__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2647:1: ( rule__Mapping__Group__2__Impl rule__Mapping__Group__3 )
            // InternalSM2.g:2648:2: rule__Mapping__Group__2__Impl rule__Mapping__Group__3
            {
            pushFollow(FOLLOW_28);
            rule__Mapping__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__2"


    // $ANTLR start "rule__Mapping__Group__2__Impl"
    // InternalSM2.g:2655:1: rule__Mapping__Group__2__Impl : ( ( rule__Mapping__TypeAssignment_2 ) ) ;
    public final void rule__Mapping__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2659:1: ( ( ( rule__Mapping__TypeAssignment_2 ) ) )
            // InternalSM2.g:2660:1: ( ( rule__Mapping__TypeAssignment_2 ) )
            {
            // InternalSM2.g:2660:1: ( ( rule__Mapping__TypeAssignment_2 ) )
            // InternalSM2.g:2661:2: ( rule__Mapping__TypeAssignment_2 )
            {
             before(grammarAccess.getMappingAccess().getTypeAssignment_2()); 
            // InternalSM2.g:2662:2: ( rule__Mapping__TypeAssignment_2 )
            // InternalSM2.g:2662:3: rule__Mapping__TypeAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__TypeAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getTypeAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__2__Impl"


    // $ANTLR start "rule__Mapping__Group__3"
    // InternalSM2.g:2670:1: rule__Mapping__Group__3 : rule__Mapping__Group__3__Impl rule__Mapping__Group__4 ;
    public final void rule__Mapping__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2674:1: ( rule__Mapping__Group__3__Impl rule__Mapping__Group__4 )
            // InternalSM2.g:2675:2: rule__Mapping__Group__3__Impl rule__Mapping__Group__4
            {
            pushFollow(FOLLOW_29);
            rule__Mapping__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__3"


    // $ANTLR start "rule__Mapping__Group__3__Impl"
    // InternalSM2.g:2682:1: rule__Mapping__Group__3__Impl : ( '=>' ) ;
    public final void rule__Mapping__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2686:1: ( ( '=>' ) )
            // InternalSM2.g:2687:1: ( '=>' )
            {
            // InternalSM2.g:2687:1: ( '=>' )
            // InternalSM2.g:2688:2: '=>'
            {
             before(grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3()); 
            match(input,59,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__3__Impl"


    // $ANTLR start "rule__Mapping__Group__4"
    // InternalSM2.g:2697:1: rule__Mapping__Group__4 : rule__Mapping__Group__4__Impl rule__Mapping__Group__5 ;
    public final void rule__Mapping__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2701:1: ( rule__Mapping__Group__4__Impl rule__Mapping__Group__5 )
            // InternalSM2.g:2702:2: rule__Mapping__Group__4__Impl rule__Mapping__Group__5
            {
            pushFollow(FOLLOW_30);
            rule__Mapping__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__4"


    // $ANTLR start "rule__Mapping__Group__4__Impl"
    // InternalSM2.g:2709:1: rule__Mapping__Group__4__Impl : ( ( rule__Mapping__ExprAssignment_4 ) ) ;
    public final void rule__Mapping__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2713:1: ( ( ( rule__Mapping__ExprAssignment_4 ) ) )
            // InternalSM2.g:2714:1: ( ( rule__Mapping__ExprAssignment_4 ) )
            {
            // InternalSM2.g:2714:1: ( ( rule__Mapping__ExprAssignment_4 ) )
            // InternalSM2.g:2715:2: ( rule__Mapping__ExprAssignment_4 )
            {
             before(grammarAccess.getMappingAccess().getExprAssignment_4()); 
            // InternalSM2.g:2716:2: ( rule__Mapping__ExprAssignment_4 )
            // InternalSM2.g:2716:3: rule__Mapping__ExprAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__ExprAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getExprAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__4__Impl"


    // $ANTLR start "rule__Mapping__Group__5"
    // InternalSM2.g:2724:1: rule__Mapping__Group__5 : rule__Mapping__Group__5__Impl rule__Mapping__Group__6 ;
    public final void rule__Mapping__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2728:1: ( rule__Mapping__Group__5__Impl rule__Mapping__Group__6 )
            // InternalSM2.g:2729:2: rule__Mapping__Group__5__Impl rule__Mapping__Group__6
            {
            pushFollow(FOLLOW_31);
            rule__Mapping__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__5"


    // $ANTLR start "rule__Mapping__Group__5__Impl"
    // InternalSM2.g:2736:1: rule__Mapping__Group__5__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Mapping__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2740:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2741:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2741:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2742:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__5__Impl"


    // $ANTLR start "rule__Mapping__Group__6"
    // InternalSM2.g:2751:1: rule__Mapping__Group__6 : rule__Mapping__Group__6__Impl rule__Mapping__Group__7 ;
    public final void rule__Mapping__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2755:1: ( rule__Mapping__Group__6__Impl rule__Mapping__Group__7 )
            // InternalSM2.g:2756:2: rule__Mapping__Group__6__Impl rule__Mapping__Group__7
            {
            pushFollow(FOLLOW_31);
            rule__Mapping__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__6"


    // $ANTLR start "rule__Mapping__Group__6__Impl"
    // InternalSM2.g:2763:1: rule__Mapping__Group__6__Impl : ( ( rule__Mapping__VisibilityAssignment_6 )? ) ;
    public final void rule__Mapping__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2767:1: ( ( ( rule__Mapping__VisibilityAssignment_6 )? ) )
            // InternalSM2.g:2768:1: ( ( rule__Mapping__VisibilityAssignment_6 )? )
            {
            // InternalSM2.g:2768:1: ( ( rule__Mapping__VisibilityAssignment_6 )? )
            // InternalSM2.g:2769:2: ( rule__Mapping__VisibilityAssignment_6 )?
            {
             before(grammarAccess.getMappingAccess().getVisibilityAssignment_6()); 
            // InternalSM2.g:2770:2: ( rule__Mapping__VisibilityAssignment_6 )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( ((LA34_0>=31 && LA34_0<=33)) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalSM2.g:2770:3: rule__Mapping__VisibilityAssignment_6
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mapping__VisibilityAssignment_6();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMappingAccess().getVisibilityAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__6__Impl"


    // $ANTLR start "rule__Mapping__Group__7"
    // InternalSM2.g:2778:1: rule__Mapping__Group__7 : rule__Mapping__Group__7__Impl rule__Mapping__Group__8 ;
    public final void rule__Mapping__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2782:1: ( rule__Mapping__Group__7__Impl rule__Mapping__Group__8 )
            // InternalSM2.g:2783:2: rule__Mapping__Group__7__Impl rule__Mapping__Group__8
            {
            pushFollow(FOLLOW_5);
            rule__Mapping__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__7"


    // $ANTLR start "rule__Mapping__Group__7__Impl"
    // InternalSM2.g:2790:1: rule__Mapping__Group__7__Impl : ( ( rule__Mapping__NameMappingAssignment_7 ) ) ;
    public final void rule__Mapping__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2794:1: ( ( ( rule__Mapping__NameMappingAssignment_7 ) ) )
            // InternalSM2.g:2795:1: ( ( rule__Mapping__NameMappingAssignment_7 ) )
            {
            // InternalSM2.g:2795:1: ( ( rule__Mapping__NameMappingAssignment_7 ) )
            // InternalSM2.g:2796:2: ( rule__Mapping__NameMappingAssignment_7 )
            {
             before(grammarAccess.getMappingAccess().getNameMappingAssignment_7()); 
            // InternalSM2.g:2797:2: ( rule__Mapping__NameMappingAssignment_7 )
            // InternalSM2.g:2797:3: rule__Mapping__NameMappingAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__NameMappingAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getNameMappingAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__7__Impl"


    // $ANTLR start "rule__Mapping__Group__8"
    // InternalSM2.g:2805:1: rule__Mapping__Group__8 : rule__Mapping__Group__8__Impl ;
    public final void rule__Mapping__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2809:1: ( rule__Mapping__Group__8__Impl )
            // InternalSM2.g:2810:2: rule__Mapping__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__8"


    // $ANTLR start "rule__Mapping__Group__8__Impl"
    // InternalSM2.g:2816:1: rule__Mapping__Group__8__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Mapping__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2820:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:2821:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:2821:1: ( RULE_SEMICOLON )
            // InternalSM2.g:2822:2: RULE_SEMICOLON
            {
             before(grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__8__Impl"


    // $ANTLR start "rule__Struct__Group__0"
    // InternalSM2.g:2832:1: rule__Struct__Group__0 : rule__Struct__Group__0__Impl rule__Struct__Group__1 ;
    public final void rule__Struct__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2836:1: ( rule__Struct__Group__0__Impl rule__Struct__Group__1 )
            // InternalSM2.g:2837:2: rule__Struct__Group__0__Impl rule__Struct__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Struct__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__0"


    // $ANTLR start "rule__Struct__Group__0__Impl"
    // InternalSM2.g:2844:1: rule__Struct__Group__0__Impl : ( 'struct' ) ;
    public final void rule__Struct__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2848:1: ( ( 'struct' ) )
            // InternalSM2.g:2849:1: ( 'struct' )
            {
            // InternalSM2.g:2849:1: ( 'struct' )
            // InternalSM2.g:2850:2: 'struct'
            {
             before(grammarAccess.getStructAccess().getStructKeyword_0()); 
            match(input,60,FOLLOW_2); 
             after(grammarAccess.getStructAccess().getStructKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__0__Impl"


    // $ANTLR start "rule__Struct__Group__1"
    // InternalSM2.g:2859:1: rule__Struct__Group__1 : rule__Struct__Group__1__Impl rule__Struct__Group__2 ;
    public final void rule__Struct__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2863:1: ( rule__Struct__Group__1__Impl rule__Struct__Group__2 )
            // InternalSM2.g:2864:2: rule__Struct__Group__1__Impl rule__Struct__Group__2
            {
            pushFollow(FOLLOW_23);
            rule__Struct__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__1"


    // $ANTLR start "rule__Struct__Group__1__Impl"
    // InternalSM2.g:2871:1: rule__Struct__Group__1__Impl : ( ( rule__Struct__NameStructAssignment_1 ) ) ;
    public final void rule__Struct__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2875:1: ( ( ( rule__Struct__NameStructAssignment_1 ) ) )
            // InternalSM2.g:2876:1: ( ( rule__Struct__NameStructAssignment_1 ) )
            {
            // InternalSM2.g:2876:1: ( ( rule__Struct__NameStructAssignment_1 ) )
            // InternalSM2.g:2877:2: ( rule__Struct__NameStructAssignment_1 )
            {
             before(grammarAccess.getStructAccess().getNameStructAssignment_1()); 
            // InternalSM2.g:2878:2: ( rule__Struct__NameStructAssignment_1 )
            // InternalSM2.g:2878:3: rule__Struct__NameStructAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Struct__NameStructAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getStructAccess().getNameStructAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__1__Impl"


    // $ANTLR start "rule__Struct__Group__2"
    // InternalSM2.g:2886:1: rule__Struct__Group__2 : rule__Struct__Group__2__Impl rule__Struct__Group__3 ;
    public final void rule__Struct__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2890:1: ( rule__Struct__Group__2__Impl rule__Struct__Group__3 )
            // InternalSM2.g:2891:2: rule__Struct__Group__2__Impl rule__Struct__Group__3
            {
            pushFollow(FOLLOW_32);
            rule__Struct__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__2"


    // $ANTLR start "rule__Struct__Group__2__Impl"
    // InternalSM2.g:2898:1: rule__Struct__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Struct__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2902:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:2903:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:2903:1: ( RULE_OPENKEY )
            // InternalSM2.g:2904:2: RULE_OPENKEY
            {
             before(grammarAccess.getStructAccess().getOPENKEYTerminalRuleCall_2()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getStructAccess().getOPENKEYTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__2__Impl"


    // $ANTLR start "rule__Struct__Group__3"
    // InternalSM2.g:2913:1: rule__Struct__Group__3 : rule__Struct__Group__3__Impl rule__Struct__Group__4 ;
    public final void rule__Struct__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2917:1: ( rule__Struct__Group__3__Impl rule__Struct__Group__4 )
            // InternalSM2.g:2918:2: rule__Struct__Group__3__Impl rule__Struct__Group__4
            {
            pushFollow(FOLLOW_32);
            rule__Struct__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__3"


    // $ANTLR start "rule__Struct__Group__3__Impl"
    // InternalSM2.g:2925:1: rule__Struct__Group__3__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Struct__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2929:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2930:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2930:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2931:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getStructAccess().getEOLINETerminalRuleCall_3()); 
            // InternalSM2.g:2932:2: ( RULE_EOLINE )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==RULE_EOLINE) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalSM2.g:2932:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getStructAccess().getEOLINETerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__3__Impl"


    // $ANTLR start "rule__Struct__Group__4"
    // InternalSM2.g:2940:1: rule__Struct__Group__4 : rule__Struct__Group__4__Impl rule__Struct__Group__5 ;
    public final void rule__Struct__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2944:1: ( rule__Struct__Group__4__Impl rule__Struct__Group__5 )
            // InternalSM2.g:2945:2: rule__Struct__Group__4__Impl rule__Struct__Group__5
            {
            pushFollow(FOLLOW_26);
            rule__Struct__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__4"


    // $ANTLR start "rule__Struct__Group__4__Impl"
    // InternalSM2.g:2952:1: rule__Struct__Group__4__Impl : ( ( rule__Struct__PropertiesAssignment_4 ) ) ;
    public final void rule__Struct__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2956:1: ( ( ( rule__Struct__PropertiesAssignment_4 ) ) )
            // InternalSM2.g:2957:1: ( ( rule__Struct__PropertiesAssignment_4 ) )
            {
            // InternalSM2.g:2957:1: ( ( rule__Struct__PropertiesAssignment_4 ) )
            // InternalSM2.g:2958:2: ( rule__Struct__PropertiesAssignment_4 )
            {
             before(grammarAccess.getStructAccess().getPropertiesAssignment_4()); 
            // InternalSM2.g:2959:2: ( rule__Struct__PropertiesAssignment_4 )
            // InternalSM2.g:2959:3: rule__Struct__PropertiesAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Struct__PropertiesAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getStructAccess().getPropertiesAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__4__Impl"


    // $ANTLR start "rule__Struct__Group__5"
    // InternalSM2.g:2967:1: rule__Struct__Group__5 : rule__Struct__Group__5__Impl rule__Struct__Group__6 ;
    public final void rule__Struct__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2971:1: ( rule__Struct__Group__5__Impl rule__Struct__Group__6 )
            // InternalSM2.g:2972:2: rule__Struct__Group__5__Impl rule__Struct__Group__6
            {
            pushFollow(FOLLOW_19);
            rule__Struct__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__5"


    // $ANTLR start "rule__Struct__Group__5__Impl"
    // InternalSM2.g:2979:1: rule__Struct__Group__5__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Struct__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2983:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:2984:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:2984:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:2985:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getStructAccess().getCLOSEKEYTerminalRuleCall_5()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getStructAccess().getCLOSEKEYTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__5__Impl"


    // $ANTLR start "rule__Struct__Group__6"
    // InternalSM2.g:2994:1: rule__Struct__Group__6 : rule__Struct__Group__6__Impl ;
    public final void rule__Struct__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2998:1: ( rule__Struct__Group__6__Impl )
            // InternalSM2.g:2999:2: rule__Struct__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Struct__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__6"


    // $ANTLR start "rule__Struct__Group__6__Impl"
    // InternalSM2.g:3005:1: rule__Struct__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Struct__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3009:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3010:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3010:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3011:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getStructAccess().getEOLINETerminalRuleCall_6()); 
            // InternalSM2.g:3012:2: ( RULE_EOLINE )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==RULE_EOLINE) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalSM2.g:3012:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getStructAccess().getEOLINETerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__6__Impl"


    // $ANTLR start "rule__Enum__Group__0"
    // InternalSM2.g:3021:1: rule__Enum__Group__0 : rule__Enum__Group__0__Impl rule__Enum__Group__1 ;
    public final void rule__Enum__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3025:1: ( rule__Enum__Group__0__Impl rule__Enum__Group__1 )
            // InternalSM2.g:3026:2: rule__Enum__Group__0__Impl rule__Enum__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Enum__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__0"


    // $ANTLR start "rule__Enum__Group__0__Impl"
    // InternalSM2.g:3033:1: rule__Enum__Group__0__Impl : ( 'enum' ) ;
    public final void rule__Enum__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3037:1: ( ( 'enum' ) )
            // InternalSM2.g:3038:1: ( 'enum' )
            {
            // InternalSM2.g:3038:1: ( 'enum' )
            // InternalSM2.g:3039:2: 'enum'
            {
             before(grammarAccess.getEnumAccess().getEnumKeyword_0()); 
            match(input,61,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getEnumKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__0__Impl"


    // $ANTLR start "rule__Enum__Group__1"
    // InternalSM2.g:3048:1: rule__Enum__Group__1 : rule__Enum__Group__1__Impl rule__Enum__Group__2 ;
    public final void rule__Enum__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3052:1: ( rule__Enum__Group__1__Impl rule__Enum__Group__2 )
            // InternalSM2.g:3053:2: rule__Enum__Group__1__Impl rule__Enum__Group__2
            {
            pushFollow(FOLLOW_23);
            rule__Enum__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__1"


    // $ANTLR start "rule__Enum__Group__1__Impl"
    // InternalSM2.g:3060:1: rule__Enum__Group__1__Impl : ( ( rule__Enum__NameEnumAssignment_1 ) ) ;
    public final void rule__Enum__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3064:1: ( ( ( rule__Enum__NameEnumAssignment_1 ) ) )
            // InternalSM2.g:3065:1: ( ( rule__Enum__NameEnumAssignment_1 ) )
            {
            // InternalSM2.g:3065:1: ( ( rule__Enum__NameEnumAssignment_1 ) )
            // InternalSM2.g:3066:2: ( rule__Enum__NameEnumAssignment_1 )
            {
             before(grammarAccess.getEnumAccess().getNameEnumAssignment_1()); 
            // InternalSM2.g:3067:2: ( rule__Enum__NameEnumAssignment_1 )
            // InternalSM2.g:3067:3: rule__Enum__NameEnumAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Enum__NameEnumAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEnumAccess().getNameEnumAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__1__Impl"


    // $ANTLR start "rule__Enum__Group__2"
    // InternalSM2.g:3075:1: rule__Enum__Group__2 : rule__Enum__Group__2__Impl rule__Enum__Group__3 ;
    public final void rule__Enum__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3079:1: ( rule__Enum__Group__2__Impl rule__Enum__Group__3 )
            // InternalSM2.g:3080:2: rule__Enum__Group__2__Impl rule__Enum__Group__3
            {
            pushFollow(FOLLOW_29);
            rule__Enum__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__2"


    // $ANTLR start "rule__Enum__Group__2__Impl"
    // InternalSM2.g:3087:1: rule__Enum__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Enum__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3091:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:3092:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:3092:1: ( RULE_OPENKEY )
            // InternalSM2.g:3093:2: RULE_OPENKEY
            {
             before(grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__2__Impl"


    // $ANTLR start "rule__Enum__Group__3"
    // InternalSM2.g:3102:1: rule__Enum__Group__3 : rule__Enum__Group__3__Impl rule__Enum__Group__4 ;
    public final void rule__Enum__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3106:1: ( rule__Enum__Group__3__Impl rule__Enum__Group__4 )
            // InternalSM2.g:3107:2: rule__Enum__Group__3__Impl rule__Enum__Group__4
            {
            pushFollow(FOLLOW_33);
            rule__Enum__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__3"


    // $ANTLR start "rule__Enum__Group__3__Impl"
    // InternalSM2.g:3114:1: rule__Enum__Group__3__Impl : ( ( rule__Enum__ExprAssignment_3 ) ) ;
    public final void rule__Enum__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3118:1: ( ( ( rule__Enum__ExprAssignment_3 ) ) )
            // InternalSM2.g:3119:1: ( ( rule__Enum__ExprAssignment_3 ) )
            {
            // InternalSM2.g:3119:1: ( ( rule__Enum__ExprAssignment_3 ) )
            // InternalSM2.g:3120:2: ( rule__Enum__ExprAssignment_3 )
            {
             before(grammarAccess.getEnumAccess().getExprAssignment_3()); 
            // InternalSM2.g:3121:2: ( rule__Enum__ExprAssignment_3 )
            // InternalSM2.g:3121:3: rule__Enum__ExprAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Enum__ExprAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getEnumAccess().getExprAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__3__Impl"


    // $ANTLR start "rule__Enum__Group__4"
    // InternalSM2.g:3129:1: rule__Enum__Group__4 : rule__Enum__Group__4__Impl rule__Enum__Group__5 ;
    public final void rule__Enum__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3133:1: ( rule__Enum__Group__4__Impl rule__Enum__Group__5 )
            // InternalSM2.g:3134:2: rule__Enum__Group__4__Impl rule__Enum__Group__5
            {
            pushFollow(FOLLOW_33);
            rule__Enum__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__4"


    // $ANTLR start "rule__Enum__Group__4__Impl"
    // InternalSM2.g:3141:1: rule__Enum__Group__4__Impl : ( ( RULE_COMMA )? ) ;
    public final void rule__Enum__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3145:1: ( ( ( RULE_COMMA )? ) )
            // InternalSM2.g:3146:1: ( ( RULE_COMMA )? )
            {
            // InternalSM2.g:3146:1: ( ( RULE_COMMA )? )
            // InternalSM2.g:3147:2: ( RULE_COMMA )?
            {
             before(grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_4()); 
            // InternalSM2.g:3148:2: ( RULE_COMMA )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==RULE_COMMA) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalSM2.g:3148:3: RULE_COMMA
                    {
                    match(input,RULE_COMMA,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__4__Impl"


    // $ANTLR start "rule__Enum__Group__5"
    // InternalSM2.g:3156:1: rule__Enum__Group__5 : rule__Enum__Group__5__Impl rule__Enum__Group__6 ;
    public final void rule__Enum__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3160:1: ( rule__Enum__Group__5__Impl rule__Enum__Group__6 )
            // InternalSM2.g:3161:2: rule__Enum__Group__5__Impl rule__Enum__Group__6
            {
            pushFollow(FOLLOW_5);
            rule__Enum__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__5"


    // $ANTLR start "rule__Enum__Group__5__Impl"
    // InternalSM2.g:3168:1: rule__Enum__Group__5__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Enum__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3172:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:3173:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:3173:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:3174:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_5()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__5__Impl"


    // $ANTLR start "rule__Enum__Group__6"
    // InternalSM2.g:3183:1: rule__Enum__Group__6 : rule__Enum__Group__6__Impl rule__Enum__Group__7 ;
    public final void rule__Enum__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3187:1: ( rule__Enum__Group__6__Impl rule__Enum__Group__7 )
            // InternalSM2.g:3188:2: rule__Enum__Group__6__Impl rule__Enum__Group__7
            {
            pushFollow(FOLLOW_19);
            rule__Enum__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__6"


    // $ANTLR start "rule__Enum__Group__6__Impl"
    // InternalSM2.g:3195:1: rule__Enum__Group__6__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Enum__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3199:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3200:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3200:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3201:2: RULE_SEMICOLON
            {
             before(grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_6()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__6__Impl"


    // $ANTLR start "rule__Enum__Group__7"
    // InternalSM2.g:3210:1: rule__Enum__Group__7 : rule__Enum__Group__7__Impl ;
    public final void rule__Enum__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3214:1: ( rule__Enum__Group__7__Impl )
            // InternalSM2.g:3215:2: rule__Enum__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Enum__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__7"


    // $ANTLR start "rule__Enum__Group__7__Impl"
    // InternalSM2.g:3221:1: rule__Enum__Group__7__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Enum__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3225:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3226:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3226:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3227:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_7()); 
            // InternalSM2.g:3228:2: ( RULE_EOLINE )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==RULE_EOLINE) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:3228:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__7__Impl"


    // $ANTLR start "rule__Property__Group__0"
    // InternalSM2.g:3237:1: rule__Property__Group__0 : rule__Property__Group__0__Impl rule__Property__Group__1 ;
    public final void rule__Property__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3241:1: ( rule__Property__Group__0__Impl rule__Property__Group__1 )
            // InternalSM2.g:3242:2: rule__Property__Group__0__Impl rule__Property__Group__1
            {
            pushFollow(FOLLOW_31);
            rule__Property__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__0"


    // $ANTLR start "rule__Property__Group__0__Impl"
    // InternalSM2.g:3249:1: rule__Property__Group__0__Impl : ( ( rule__Property__TypeAssignment_0 ) ) ;
    public final void rule__Property__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3253:1: ( ( ( rule__Property__TypeAssignment_0 ) ) )
            // InternalSM2.g:3254:1: ( ( rule__Property__TypeAssignment_0 ) )
            {
            // InternalSM2.g:3254:1: ( ( rule__Property__TypeAssignment_0 ) )
            // InternalSM2.g:3255:2: ( rule__Property__TypeAssignment_0 )
            {
             before(grammarAccess.getPropertyAccess().getTypeAssignment_0()); 
            // InternalSM2.g:3256:2: ( rule__Property__TypeAssignment_0 )
            // InternalSM2.g:3256:3: rule__Property__TypeAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Property__TypeAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getPropertyAccess().getTypeAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__0__Impl"


    // $ANTLR start "rule__Property__Group__1"
    // InternalSM2.g:3264:1: rule__Property__Group__1 : rule__Property__Group__1__Impl rule__Property__Group__2 ;
    public final void rule__Property__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3268:1: ( rule__Property__Group__1__Impl rule__Property__Group__2 )
            // InternalSM2.g:3269:2: rule__Property__Group__1__Impl rule__Property__Group__2
            {
            pushFollow(FOLLOW_31);
            rule__Property__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__1"


    // $ANTLR start "rule__Property__Group__1__Impl"
    // InternalSM2.g:3276:1: rule__Property__Group__1__Impl : ( ( rule__Property__VisibilityAssignment_1 )? ) ;
    public final void rule__Property__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3280:1: ( ( ( rule__Property__VisibilityAssignment_1 )? ) )
            // InternalSM2.g:3281:1: ( ( rule__Property__VisibilityAssignment_1 )? )
            {
            // InternalSM2.g:3281:1: ( ( rule__Property__VisibilityAssignment_1 )? )
            // InternalSM2.g:3282:2: ( rule__Property__VisibilityAssignment_1 )?
            {
             before(grammarAccess.getPropertyAccess().getVisibilityAssignment_1()); 
            // InternalSM2.g:3283:2: ( rule__Property__VisibilityAssignment_1 )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( ((LA39_0>=31 && LA39_0<=33)) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalSM2.g:3283:3: rule__Property__VisibilityAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__VisibilityAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPropertyAccess().getVisibilityAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__1__Impl"


    // $ANTLR start "rule__Property__Group__2"
    // InternalSM2.g:3291:1: rule__Property__Group__2 : rule__Property__Group__2__Impl rule__Property__Group__3 ;
    public final void rule__Property__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3295:1: ( rule__Property__Group__2__Impl rule__Property__Group__3 )
            // InternalSM2.g:3296:2: rule__Property__Group__2__Impl rule__Property__Group__3
            {
            pushFollow(FOLLOW_34);
            rule__Property__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__2"


    // $ANTLR start "rule__Property__Group__2__Impl"
    // InternalSM2.g:3303:1: rule__Property__Group__2__Impl : ( ( rule__Property__NamePropertyAssignment_2 ) ) ;
    public final void rule__Property__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3307:1: ( ( ( rule__Property__NamePropertyAssignment_2 ) ) )
            // InternalSM2.g:3308:1: ( ( rule__Property__NamePropertyAssignment_2 ) )
            {
            // InternalSM2.g:3308:1: ( ( rule__Property__NamePropertyAssignment_2 ) )
            // InternalSM2.g:3309:2: ( rule__Property__NamePropertyAssignment_2 )
            {
             before(grammarAccess.getPropertyAccess().getNamePropertyAssignment_2()); 
            // InternalSM2.g:3310:2: ( rule__Property__NamePropertyAssignment_2 )
            // InternalSM2.g:3310:3: rule__Property__NamePropertyAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Property__NamePropertyAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getPropertyAccess().getNamePropertyAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__2__Impl"


    // $ANTLR start "rule__Property__Group__3"
    // InternalSM2.g:3318:1: rule__Property__Group__3 : rule__Property__Group__3__Impl rule__Property__Group__4 ;
    public final void rule__Property__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3322:1: ( rule__Property__Group__3__Impl rule__Property__Group__4 )
            // InternalSM2.g:3323:2: rule__Property__Group__3__Impl rule__Property__Group__4
            {
            pushFollow(FOLLOW_35);
            rule__Property__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__3"


    // $ANTLR start "rule__Property__Group__3__Impl"
    // InternalSM2.g:3330:1: rule__Property__Group__3__Impl : ( '=' ) ;
    public final void rule__Property__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3334:1: ( ( '=' ) )
            // InternalSM2.g:3335:1: ( '=' )
            {
            // InternalSM2.g:3335:1: ( '=' )
            // InternalSM2.g:3336:2: '='
            {
             before(grammarAccess.getPropertyAccess().getEqualsSignKeyword_3()); 
            match(input,62,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getEqualsSignKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__3__Impl"


    // $ANTLR start "rule__Property__Group__4"
    // InternalSM2.g:3345:1: rule__Property__Group__4 : rule__Property__Group__4__Impl rule__Property__Group__5 ;
    public final void rule__Property__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3349:1: ( rule__Property__Group__4__Impl rule__Property__Group__5 )
            // InternalSM2.g:3350:2: rule__Property__Group__4__Impl rule__Property__Group__5
            {
            pushFollow(FOLLOW_35);
            rule__Property__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__4"


    // $ANTLR start "rule__Property__Group__4__Impl"
    // InternalSM2.g:3357:1: rule__Property__Group__4__Impl : ( ( rule__Property__Alternatives_4 )? ) ;
    public final void rule__Property__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3361:1: ( ( ( rule__Property__Alternatives_4 )? ) )
            // InternalSM2.g:3362:1: ( ( rule__Property__Alternatives_4 )? )
            {
            // InternalSM2.g:3362:1: ( ( rule__Property__Alternatives_4 )? )
            // InternalSM2.g:3363:2: ( rule__Property__Alternatives_4 )?
            {
             before(grammarAccess.getPropertyAccess().getAlternatives_4()); 
            // InternalSM2.g:3364:2: ( rule__Property__Alternatives_4 )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==RULE_INT||LA40_0==RULE_STRING) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalSM2.g:3364:3: rule__Property__Alternatives_4
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__Alternatives_4();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPropertyAccess().getAlternatives_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__4__Impl"


    // $ANTLR start "rule__Property__Group__5"
    // InternalSM2.g:3372:1: rule__Property__Group__5 : rule__Property__Group__5__Impl rule__Property__Group__6 ;
    public final void rule__Property__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3376:1: ( rule__Property__Group__5__Impl rule__Property__Group__6 )
            // InternalSM2.g:3377:2: rule__Property__Group__5__Impl rule__Property__Group__6
            {
            pushFollow(FOLLOW_19);
            rule__Property__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__5"


    // $ANTLR start "rule__Property__Group__5__Impl"
    // InternalSM2.g:3384:1: rule__Property__Group__5__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Property__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3388:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3389:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3389:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3390:2: RULE_SEMICOLON
            {
             before(grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_5()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__5__Impl"


    // $ANTLR start "rule__Property__Group__6"
    // InternalSM2.g:3399:1: rule__Property__Group__6 : rule__Property__Group__6__Impl ;
    public final void rule__Property__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3403:1: ( rule__Property__Group__6__Impl )
            // InternalSM2.g:3404:2: rule__Property__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Property__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__6"


    // $ANTLR start "rule__Property__Group__6__Impl"
    // InternalSM2.g:3410:1: rule__Property__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Property__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3414:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3415:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3415:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3416:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6()); 
            // InternalSM2.g:3417:2: ( RULE_EOLINE )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==RULE_EOLINE) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalSM2.g:3417:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__6__Impl"


    // $ANTLR start "rule__InputParam__Group__0"
    // InternalSM2.g:3426:1: rule__InputParam__Group__0 : rule__InputParam__Group__0__Impl rule__InputParam__Group__1 ;
    public final void rule__InputParam__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3430:1: ( rule__InputParam__Group__0__Impl rule__InputParam__Group__1 )
            // InternalSM2.g:3431:2: rule__InputParam__Group__0__Impl rule__InputParam__Group__1
            {
            pushFollow(FOLLOW_36);
            rule__InputParam__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InputParam__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__0"


    // $ANTLR start "rule__InputParam__Group__0__Impl"
    // InternalSM2.g:3438:1: rule__InputParam__Group__0__Impl : ( ( rule__InputParam__Group_0__0 ) ) ;
    public final void rule__InputParam__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3442:1: ( ( ( rule__InputParam__Group_0__0 ) ) )
            // InternalSM2.g:3443:1: ( ( rule__InputParam__Group_0__0 ) )
            {
            // InternalSM2.g:3443:1: ( ( rule__InputParam__Group_0__0 ) )
            // InternalSM2.g:3444:2: ( rule__InputParam__Group_0__0 )
            {
             before(grammarAccess.getInputParamAccess().getGroup_0()); 
            // InternalSM2.g:3445:2: ( rule__InputParam__Group_0__0 )
            // InternalSM2.g:3445:3: rule__InputParam__Group_0__0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__0();

            state._fsp--;


            }

             after(grammarAccess.getInputParamAccess().getGroup_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__0__Impl"


    // $ANTLR start "rule__InputParam__Group__1"
    // InternalSM2.g:3453:1: rule__InputParam__Group__1 : rule__InputParam__Group__1__Impl ;
    public final void rule__InputParam__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3457:1: ( rule__InputParam__Group__1__Impl )
            // InternalSM2.g:3458:2: rule__InputParam__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__1"


    // $ANTLR start "rule__InputParam__Group__1__Impl"
    // InternalSM2.g:3464:1: rule__InputParam__Group__1__Impl : ( ( RULE_COMMA )? ) ;
    public final void rule__InputParam__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3468:1: ( ( ( RULE_COMMA )? ) )
            // InternalSM2.g:3469:1: ( ( RULE_COMMA )? )
            {
            // InternalSM2.g:3469:1: ( ( RULE_COMMA )? )
            // InternalSM2.g:3470:2: ( RULE_COMMA )?
            {
             before(grammarAccess.getInputParamAccess().getCOMMATerminalRuleCall_1()); 
            // InternalSM2.g:3471:2: ( RULE_COMMA )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==RULE_COMMA) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalSM2.g:3471:3: RULE_COMMA
                    {
                    match(input,RULE_COMMA,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getInputParamAccess().getCOMMATerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__1__Impl"


    // $ANTLR start "rule__InputParam__Group_0__0"
    // InternalSM2.g:3480:1: rule__InputParam__Group_0__0 : rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1 ;
    public final void rule__InputParam__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3484:1: ( rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1 )
            // InternalSM2.g:3485:2: rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1
            {
            pushFollow(FOLLOW_8);
            rule__InputParam__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__0"


    // $ANTLR start "rule__InputParam__Group_0__0__Impl"
    // InternalSM2.g:3492:1: rule__InputParam__Group_0__0__Impl : ( ( rule__InputParam__TypeAssignment_0_0 ) ) ;
    public final void rule__InputParam__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3496:1: ( ( ( rule__InputParam__TypeAssignment_0_0 ) ) )
            // InternalSM2.g:3497:1: ( ( rule__InputParam__TypeAssignment_0_0 ) )
            {
            // InternalSM2.g:3497:1: ( ( rule__InputParam__TypeAssignment_0_0 ) )
            // InternalSM2.g:3498:2: ( rule__InputParam__TypeAssignment_0_0 )
            {
             before(grammarAccess.getInputParamAccess().getTypeAssignment_0_0()); 
            // InternalSM2.g:3499:2: ( rule__InputParam__TypeAssignment_0_0 )
            // InternalSM2.g:3499:3: rule__InputParam__TypeAssignment_0_0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__TypeAssignment_0_0();

            state._fsp--;


            }

             after(grammarAccess.getInputParamAccess().getTypeAssignment_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__0__Impl"


    // $ANTLR start "rule__InputParam__Group_0__1"
    // InternalSM2.g:3507:1: rule__InputParam__Group_0__1 : rule__InputParam__Group_0__1__Impl ;
    public final void rule__InputParam__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3511:1: ( rule__InputParam__Group_0__1__Impl )
            // InternalSM2.g:3512:2: rule__InputParam__Group_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__1"


    // $ANTLR start "rule__InputParam__Group_0__1__Impl"
    // InternalSM2.g:3518:1: rule__InputParam__Group_0__1__Impl : ( ( rule__InputParam__NameParamAssignment_0_1 ) ) ;
    public final void rule__InputParam__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3522:1: ( ( ( rule__InputParam__NameParamAssignment_0_1 ) ) )
            // InternalSM2.g:3523:1: ( ( rule__InputParam__NameParamAssignment_0_1 ) )
            {
            // InternalSM2.g:3523:1: ( ( rule__InputParam__NameParamAssignment_0_1 ) )
            // InternalSM2.g:3524:2: ( rule__InputParam__NameParamAssignment_0_1 )
            {
             before(grammarAccess.getInputParamAccess().getNameParamAssignment_0_1()); 
            // InternalSM2.g:3525:2: ( rule__InputParam__NameParamAssignment_0_1 )
            // InternalSM2.g:3525:3: rule__InputParam__NameParamAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__NameParamAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getInputParamAccess().getNameParamAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__1__Impl"


    // $ANTLR start "rule__Restriction__Group__0"
    // InternalSM2.g:3534:1: rule__Restriction__Group__0 : rule__Restriction__Group__0__Impl rule__Restriction__Group__1 ;
    public final void rule__Restriction__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3538:1: ( rule__Restriction__Group__0__Impl rule__Restriction__Group__1 )
            // InternalSM2.g:3539:2: rule__Restriction__Group__0__Impl rule__Restriction__Group__1
            {
            pushFollow(FOLLOW_20);
            rule__Restriction__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__0"


    // $ANTLR start "rule__Restriction__Group__0__Impl"
    // InternalSM2.g:3546:1: rule__Restriction__Group__0__Impl : ( 'require' ) ;
    public final void rule__Restriction__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3550:1: ( ( 'require' ) )
            // InternalSM2.g:3551:1: ( 'require' )
            {
            // InternalSM2.g:3551:1: ( 'require' )
            // InternalSM2.g:3552:2: 'require'
            {
             before(grammarAccess.getRestrictionAccess().getRequireKeyword_0()); 
            match(input,63,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getRequireKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__0__Impl"


    // $ANTLR start "rule__Restriction__Group__1"
    // InternalSM2.g:3561:1: rule__Restriction__Group__1 : rule__Restriction__Group__1__Impl rule__Restriction__Group__2 ;
    public final void rule__Restriction__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3565:1: ( rule__Restriction__Group__1__Impl rule__Restriction__Group__2 )
            // InternalSM2.g:3566:2: rule__Restriction__Group__1__Impl rule__Restriction__Group__2
            {
            pushFollow(FOLLOW_37);
            rule__Restriction__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__1"


    // $ANTLR start "rule__Restriction__Group__1__Impl"
    // InternalSM2.g:3573:1: rule__Restriction__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Restriction__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3577:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:3578:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:3578:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:3579:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__1__Impl"


    // $ANTLR start "rule__Restriction__Group__2"
    // InternalSM2.g:3588:1: rule__Restriction__Group__2 : rule__Restriction__Group__2__Impl rule__Restriction__Group__3 ;
    public final void rule__Restriction__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3592:1: ( rule__Restriction__Group__2__Impl rule__Restriction__Group__3 )
            // InternalSM2.g:3593:2: rule__Restriction__Group__2__Impl rule__Restriction__Group__3
            {
            pushFollow(FOLLOW_38);
            rule__Restriction__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__2"


    // $ANTLR start "rule__Restriction__Group__2__Impl"
    // InternalSM2.g:3600:1: rule__Restriction__Group__2__Impl : ( ( rule__Restriction__ExprAssignment_2 ) ) ;
    public final void rule__Restriction__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3604:1: ( ( ( rule__Restriction__ExprAssignment_2 ) ) )
            // InternalSM2.g:3605:1: ( ( rule__Restriction__ExprAssignment_2 ) )
            {
            // InternalSM2.g:3605:1: ( ( rule__Restriction__ExprAssignment_2 ) )
            // InternalSM2.g:3606:2: ( rule__Restriction__ExprAssignment_2 )
            {
             before(grammarAccess.getRestrictionAccess().getExprAssignment_2()); 
            // InternalSM2.g:3607:2: ( rule__Restriction__ExprAssignment_2 )
            // InternalSM2.g:3607:3: rule__Restriction__ExprAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__ExprAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getExprAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__2__Impl"


    // $ANTLR start "rule__Restriction__Group__3"
    // InternalSM2.g:3615:1: rule__Restriction__Group__3 : rule__Restriction__Group__3__Impl rule__Restriction__Group__4 ;
    public final void rule__Restriction__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3619:1: ( rule__Restriction__Group__3__Impl rule__Restriction__Group__4 )
            // InternalSM2.g:3620:2: rule__Restriction__Group__3__Impl rule__Restriction__Group__4
            {
            pushFollow(FOLLOW_37);
            rule__Restriction__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__3"


    // $ANTLR start "rule__Restriction__Group__3__Impl"
    // InternalSM2.g:3627:1: rule__Restriction__Group__3__Impl : ( ( rule__Restriction__OperatorAssignment_3 ) ) ;
    public final void rule__Restriction__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3631:1: ( ( ( rule__Restriction__OperatorAssignment_3 ) ) )
            // InternalSM2.g:3632:1: ( ( rule__Restriction__OperatorAssignment_3 ) )
            {
            // InternalSM2.g:3632:1: ( ( rule__Restriction__OperatorAssignment_3 ) )
            // InternalSM2.g:3633:2: ( rule__Restriction__OperatorAssignment_3 )
            {
             before(grammarAccess.getRestrictionAccess().getOperatorAssignment_3()); 
            // InternalSM2.g:3634:2: ( rule__Restriction__OperatorAssignment_3 )
            // InternalSM2.g:3634:3: rule__Restriction__OperatorAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__OperatorAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getOperatorAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__3__Impl"


    // $ANTLR start "rule__Restriction__Group__4"
    // InternalSM2.g:3642:1: rule__Restriction__Group__4 : rule__Restriction__Group__4__Impl rule__Restriction__Group__5 ;
    public final void rule__Restriction__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3646:1: ( rule__Restriction__Group__4__Impl rule__Restriction__Group__5 )
            // InternalSM2.g:3647:2: rule__Restriction__Group__4__Impl rule__Restriction__Group__5
            {
            pushFollow(FOLLOW_30);
            rule__Restriction__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__4"


    // $ANTLR start "rule__Restriction__Group__4__Impl"
    // InternalSM2.g:3654:1: rule__Restriction__Group__4__Impl : ( ( rule__Restriction__ExprAssignment_4 ) ) ;
    public final void rule__Restriction__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3658:1: ( ( ( rule__Restriction__ExprAssignment_4 ) ) )
            // InternalSM2.g:3659:1: ( ( rule__Restriction__ExprAssignment_4 ) )
            {
            // InternalSM2.g:3659:1: ( ( rule__Restriction__ExprAssignment_4 ) )
            // InternalSM2.g:3660:2: ( rule__Restriction__ExprAssignment_4 )
            {
             before(grammarAccess.getRestrictionAccess().getExprAssignment_4()); 
            // InternalSM2.g:3661:2: ( rule__Restriction__ExprAssignment_4 )
            // InternalSM2.g:3661:3: rule__Restriction__ExprAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__ExprAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getExprAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__4__Impl"


    // $ANTLR start "rule__Restriction__Group__5"
    // InternalSM2.g:3669:1: rule__Restriction__Group__5 : rule__Restriction__Group__5__Impl rule__Restriction__Group__6 ;
    public final void rule__Restriction__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3673:1: ( rule__Restriction__Group__5__Impl rule__Restriction__Group__6 )
            // InternalSM2.g:3674:2: rule__Restriction__Group__5__Impl rule__Restriction__Group__6
            {
            pushFollow(FOLLOW_5);
            rule__Restriction__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__5"


    // $ANTLR start "rule__Restriction__Group__5__Impl"
    // InternalSM2.g:3681:1: rule__Restriction__Group__5__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Restriction__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3685:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:3686:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:3686:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:3687:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__5__Impl"


    // $ANTLR start "rule__Restriction__Group__6"
    // InternalSM2.g:3696:1: rule__Restriction__Group__6 : rule__Restriction__Group__6__Impl rule__Restriction__Group__7 ;
    public final void rule__Restriction__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3700:1: ( rule__Restriction__Group__6__Impl rule__Restriction__Group__7 )
            // InternalSM2.g:3701:2: rule__Restriction__Group__6__Impl rule__Restriction__Group__7
            {
            pushFollow(FOLLOW_19);
            rule__Restriction__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__6"


    // $ANTLR start "rule__Restriction__Group__6__Impl"
    // InternalSM2.g:3708:1: rule__Restriction__Group__6__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Restriction__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3712:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3713:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3713:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3714:2: RULE_SEMICOLON
            {
             before(grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__6__Impl"


    // $ANTLR start "rule__Restriction__Group__7"
    // InternalSM2.g:3723:1: rule__Restriction__Group__7 : rule__Restriction__Group__7__Impl ;
    public final void rule__Restriction__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3727:1: ( rule__Restriction__Group__7__Impl )
            // InternalSM2.g:3728:2: rule__Restriction__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__7"


    // $ANTLR start "rule__Restriction__Group__7__Impl"
    // InternalSM2.g:3734:1: rule__Restriction__Group__7__Impl : ( RULE_EOLINE ) ;
    public final void rule__Restriction__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3738:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:3739:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:3739:1: ( RULE_EOLINE )
            // InternalSM2.g:3740:2: RULE_EOLINE
            {
             before(grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__7__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__0"
    // InternalSM2.g:3750:1: rule__RestrictionGas__Group__0 : rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1 ;
    public final void rule__RestrictionGas__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3754:1: ( rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1 )
            // InternalSM2.g:3755:2: rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1
            {
            pushFollow(FOLLOW_20);
            rule__RestrictionGas__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__0"


    // $ANTLR start "rule__RestrictionGas__Group__0__Impl"
    // InternalSM2.g:3762:1: rule__RestrictionGas__Group__0__Impl : ( 'require' ) ;
    public final void rule__RestrictionGas__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3766:1: ( ( 'require' ) )
            // InternalSM2.g:3767:1: ( 'require' )
            {
            // InternalSM2.g:3767:1: ( 'require' )
            // InternalSM2.g:3768:2: 'require'
            {
             before(grammarAccess.getRestrictionGasAccess().getRequireKeyword_0()); 
            match(input,63,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getRequireKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__0__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__1"
    // InternalSM2.g:3777:1: rule__RestrictionGas__Group__1 : rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2 ;
    public final void rule__RestrictionGas__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3781:1: ( rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2 )
            // InternalSM2.g:3782:2: rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2
            {
            pushFollow(FOLLOW_37);
            rule__RestrictionGas__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__1"


    // $ANTLR start "rule__RestrictionGas__Group__1__Impl"
    // InternalSM2.g:3789:1: rule__RestrictionGas__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__RestrictionGas__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3793:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:3794:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:3794:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:3795:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__1__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__2"
    // InternalSM2.g:3804:1: rule__RestrictionGas__Group__2 : rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3 ;
    public final void rule__RestrictionGas__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3808:1: ( rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3 )
            // InternalSM2.g:3809:2: rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3
            {
            pushFollow(FOLLOW_38);
            rule__RestrictionGas__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__2"


    // $ANTLR start "rule__RestrictionGas__Group__2__Impl"
    // InternalSM2.g:3816:1: rule__RestrictionGas__Group__2__Impl : ( ( rule__RestrictionGas__ExprAssignment_2 ) ) ;
    public final void rule__RestrictionGas__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3820:1: ( ( ( rule__RestrictionGas__ExprAssignment_2 ) ) )
            // InternalSM2.g:3821:1: ( ( rule__RestrictionGas__ExprAssignment_2 ) )
            {
            // InternalSM2.g:3821:1: ( ( rule__RestrictionGas__ExprAssignment_2 ) )
            // InternalSM2.g:3822:2: ( rule__RestrictionGas__ExprAssignment_2 )
            {
             before(grammarAccess.getRestrictionGasAccess().getExprAssignment_2()); 
            // InternalSM2.g:3823:2: ( rule__RestrictionGas__ExprAssignment_2 )
            // InternalSM2.g:3823:3: rule__RestrictionGas__ExprAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__ExprAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getExprAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__2__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__3"
    // InternalSM2.g:3831:1: rule__RestrictionGas__Group__3 : rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4 ;
    public final void rule__RestrictionGas__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3835:1: ( rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4 )
            // InternalSM2.g:3836:2: rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4
            {
            pushFollow(FOLLOW_39);
            rule__RestrictionGas__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__3"


    // $ANTLR start "rule__RestrictionGas__Group__3__Impl"
    // InternalSM2.g:3843:1: rule__RestrictionGas__Group__3__Impl : ( ( rule__RestrictionGas__OperatorAssignment_3 ) ) ;
    public final void rule__RestrictionGas__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3847:1: ( ( ( rule__RestrictionGas__OperatorAssignment_3 ) ) )
            // InternalSM2.g:3848:1: ( ( rule__RestrictionGas__OperatorAssignment_3 ) )
            {
            // InternalSM2.g:3848:1: ( ( rule__RestrictionGas__OperatorAssignment_3 ) )
            // InternalSM2.g:3849:2: ( rule__RestrictionGas__OperatorAssignment_3 )
            {
             before(grammarAccess.getRestrictionGasAccess().getOperatorAssignment_3()); 
            // InternalSM2.g:3850:2: ( rule__RestrictionGas__OperatorAssignment_3 )
            // InternalSM2.g:3850:3: rule__RestrictionGas__OperatorAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__OperatorAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getOperatorAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__3__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__4"
    // InternalSM2.g:3858:1: rule__RestrictionGas__Group__4 : rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5 ;
    public final void rule__RestrictionGas__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3862:1: ( rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5 )
            // InternalSM2.g:3863:2: rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5
            {
            pushFollow(FOLLOW_40);
            rule__RestrictionGas__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__4"


    // $ANTLR start "rule__RestrictionGas__Group__4__Impl"
    // InternalSM2.g:3870:1: rule__RestrictionGas__Group__4__Impl : ( ( rule__RestrictionGas__AmountAssignment_4 ) ) ;
    public final void rule__RestrictionGas__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3874:1: ( ( ( rule__RestrictionGas__AmountAssignment_4 ) ) )
            // InternalSM2.g:3875:1: ( ( rule__RestrictionGas__AmountAssignment_4 ) )
            {
            // InternalSM2.g:3875:1: ( ( rule__RestrictionGas__AmountAssignment_4 ) )
            // InternalSM2.g:3876:2: ( rule__RestrictionGas__AmountAssignment_4 )
            {
             before(grammarAccess.getRestrictionGasAccess().getAmountAssignment_4()); 
            // InternalSM2.g:3877:2: ( rule__RestrictionGas__AmountAssignment_4 )
            // InternalSM2.g:3877:3: rule__RestrictionGas__AmountAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__AmountAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getAmountAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__4__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__5"
    // InternalSM2.g:3885:1: rule__RestrictionGas__Group__5 : rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6 ;
    public final void rule__RestrictionGas__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3889:1: ( rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6 )
            // InternalSM2.g:3890:2: rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6
            {
            pushFollow(FOLLOW_30);
            rule__RestrictionGas__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__5"


    // $ANTLR start "rule__RestrictionGas__Group__5__Impl"
    // InternalSM2.g:3897:1: rule__RestrictionGas__Group__5__Impl : ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) ) ;
    public final void rule__RestrictionGas__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3901:1: ( ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) ) )
            // InternalSM2.g:3902:1: ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) )
            {
            // InternalSM2.g:3902:1: ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) )
            // InternalSM2.g:3903:2: ( rule__RestrictionGas__TypeCoinAssignment_5 )
            {
             before(grammarAccess.getRestrictionGasAccess().getTypeCoinAssignment_5()); 
            // InternalSM2.g:3904:2: ( rule__RestrictionGas__TypeCoinAssignment_5 )
            // InternalSM2.g:3904:3: rule__RestrictionGas__TypeCoinAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__TypeCoinAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getTypeCoinAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__5__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__6"
    // InternalSM2.g:3912:1: rule__RestrictionGas__Group__6 : rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7 ;
    public final void rule__RestrictionGas__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3916:1: ( rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7 )
            // InternalSM2.g:3917:2: rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7
            {
            pushFollow(FOLLOW_5);
            rule__RestrictionGas__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__6"


    // $ANTLR start "rule__RestrictionGas__Group__6__Impl"
    // InternalSM2.g:3924:1: rule__RestrictionGas__Group__6__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__RestrictionGas__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3928:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:3929:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:3929:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:3930:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__6__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__7"
    // InternalSM2.g:3939:1: rule__RestrictionGas__Group__7 : rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8 ;
    public final void rule__RestrictionGas__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3943:1: ( rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8 )
            // InternalSM2.g:3944:2: rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8
            {
            pushFollow(FOLLOW_19);
            rule__RestrictionGas__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__7"


    // $ANTLR start "rule__RestrictionGas__Group__7__Impl"
    // InternalSM2.g:3951:1: rule__RestrictionGas__Group__7__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__RestrictionGas__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3955:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3956:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3956:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3957:2: RULE_SEMICOLON
            {
             before(grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__7__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__8"
    // InternalSM2.g:3966:1: rule__RestrictionGas__Group__8 : rule__RestrictionGas__Group__8__Impl ;
    public final void rule__RestrictionGas__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3970:1: ( rule__RestrictionGas__Group__8__Impl )
            // InternalSM2.g:3971:2: rule__RestrictionGas__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__8"


    // $ANTLR start "rule__RestrictionGas__Group__8__Impl"
    // InternalSM2.g:3977:1: rule__RestrictionGas__Group__8__Impl : ( RULE_EOLINE ) ;
    public final void rule__RestrictionGas__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3981:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:3982:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:3982:1: ( RULE_EOLINE )
            // InternalSM2.g:3983:2: RULE_EOLINE
            {
             before(grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__8__Impl"


    // $ANTLR start "rule__Clause__Group__0"
    // InternalSM2.g:3993:1: rule__Clause__Group__0 : rule__Clause__Group__0__Impl rule__Clause__Group__1 ;
    public final void rule__Clause__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3997:1: ( rule__Clause__Group__0__Impl rule__Clause__Group__1 )
            // InternalSM2.g:3998:2: rule__Clause__Group__0__Impl rule__Clause__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Clause__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__0"


    // $ANTLR start "rule__Clause__Group__0__Impl"
    // InternalSM2.g:4005:1: rule__Clause__Group__0__Impl : ( 'function' ) ;
    public final void rule__Clause__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4009:1: ( ( 'function' ) )
            // InternalSM2.g:4010:1: ( 'function' )
            {
            // InternalSM2.g:4010:1: ( 'function' )
            // InternalSM2.g:4011:2: 'function'
            {
             before(grammarAccess.getClauseAccess().getFunctionKeyword_0()); 
            match(input,64,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getFunctionKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__0__Impl"


    // $ANTLR start "rule__Clause__Group__1"
    // InternalSM2.g:4020:1: rule__Clause__Group__1 : rule__Clause__Group__1__Impl rule__Clause__Group__2 ;
    public final void rule__Clause__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4024:1: ( rule__Clause__Group__1__Impl rule__Clause__Group__2 )
            // InternalSM2.g:4025:2: rule__Clause__Group__1__Impl rule__Clause__Group__2
            {
            pushFollow(FOLLOW_20);
            rule__Clause__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__1"


    // $ANTLR start "rule__Clause__Group__1__Impl"
    // InternalSM2.g:4032:1: rule__Clause__Group__1__Impl : ( ( rule__Clause__NameFunctionAssignment_1 ) ) ;
    public final void rule__Clause__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4036:1: ( ( ( rule__Clause__NameFunctionAssignment_1 ) ) )
            // InternalSM2.g:4037:1: ( ( rule__Clause__NameFunctionAssignment_1 ) )
            {
            // InternalSM2.g:4037:1: ( ( rule__Clause__NameFunctionAssignment_1 ) )
            // InternalSM2.g:4038:2: ( rule__Clause__NameFunctionAssignment_1 )
            {
             before(grammarAccess.getClauseAccess().getNameFunctionAssignment_1()); 
            // InternalSM2.g:4039:2: ( rule__Clause__NameFunctionAssignment_1 )
            // InternalSM2.g:4039:3: rule__Clause__NameFunctionAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Clause__NameFunctionAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getNameFunctionAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__1__Impl"


    // $ANTLR start "rule__Clause__Group__2"
    // InternalSM2.g:4047:1: rule__Clause__Group__2 : rule__Clause__Group__2__Impl rule__Clause__Group__3 ;
    public final void rule__Clause__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4051:1: ( rule__Clause__Group__2__Impl rule__Clause__Group__3 )
            // InternalSM2.g:4052:2: rule__Clause__Group__2__Impl rule__Clause__Group__3
            {
            pushFollow(FOLLOW_8);
            rule__Clause__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__2"


    // $ANTLR start "rule__Clause__Group__2__Impl"
    // InternalSM2.g:4059:1: rule__Clause__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Clause__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4063:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:4064:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:4064:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:4065:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__2__Impl"


    // $ANTLR start "rule__Clause__Group__3"
    // InternalSM2.g:4074:1: rule__Clause__Group__3 : rule__Clause__Group__3__Impl rule__Clause__Group__4 ;
    public final void rule__Clause__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4078:1: ( rule__Clause__Group__3__Impl rule__Clause__Group__4 )
            // InternalSM2.g:4079:2: rule__Clause__Group__3__Impl rule__Clause__Group__4
            {
            pushFollow(FOLLOW_41);
            rule__Clause__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__3"


    // $ANTLR start "rule__Clause__Group__3__Impl"
    // InternalSM2.g:4086:1: rule__Clause__Group__3__Impl : ( ( rule__Clause__InputParamsAssignment_3 ) ) ;
    public final void rule__Clause__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4090:1: ( ( ( rule__Clause__InputParamsAssignment_3 ) ) )
            // InternalSM2.g:4091:1: ( ( rule__Clause__InputParamsAssignment_3 ) )
            {
            // InternalSM2.g:4091:1: ( ( rule__Clause__InputParamsAssignment_3 ) )
            // InternalSM2.g:4092:2: ( rule__Clause__InputParamsAssignment_3 )
            {
             before(grammarAccess.getClauseAccess().getInputParamsAssignment_3()); 
            // InternalSM2.g:4093:2: ( rule__Clause__InputParamsAssignment_3 )
            // InternalSM2.g:4093:3: rule__Clause__InputParamsAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Clause__InputParamsAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getInputParamsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__3__Impl"


    // $ANTLR start "rule__Clause__Group__4"
    // InternalSM2.g:4101:1: rule__Clause__Group__4 : rule__Clause__Group__4__Impl rule__Clause__Group__5 ;
    public final void rule__Clause__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4105:1: ( rule__Clause__Group__4__Impl rule__Clause__Group__5 )
            // InternalSM2.g:4106:2: rule__Clause__Group__4__Impl rule__Clause__Group__5
            {
            pushFollow(FOLLOW_42);
            rule__Clause__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__4"


    // $ANTLR start "rule__Clause__Group__4__Impl"
    // InternalSM2.g:4113:1: rule__Clause__Group__4__Impl : ( ( rule__Clause__VisibilityAccessAssignment_4 ) ) ;
    public final void rule__Clause__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4117:1: ( ( ( rule__Clause__VisibilityAccessAssignment_4 ) ) )
            // InternalSM2.g:4118:1: ( ( rule__Clause__VisibilityAccessAssignment_4 ) )
            {
            // InternalSM2.g:4118:1: ( ( rule__Clause__VisibilityAccessAssignment_4 ) )
            // InternalSM2.g:4119:2: ( rule__Clause__VisibilityAccessAssignment_4 )
            {
             before(grammarAccess.getClauseAccess().getVisibilityAccessAssignment_4()); 
            // InternalSM2.g:4120:2: ( rule__Clause__VisibilityAccessAssignment_4 )
            // InternalSM2.g:4120:3: rule__Clause__VisibilityAccessAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Clause__VisibilityAccessAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getVisibilityAccessAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__4__Impl"


    // $ANTLR start "rule__Clause__Group__5"
    // InternalSM2.g:4128:1: rule__Clause__Group__5 : rule__Clause__Group__5__Impl rule__Clause__Group__6 ;
    public final void rule__Clause__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4132:1: ( rule__Clause__Group__5__Impl rule__Clause__Group__6 )
            // InternalSM2.g:4133:2: rule__Clause__Group__5__Impl rule__Clause__Group__6
            {
            pushFollow(FOLLOW_42);
            rule__Clause__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__5"


    // $ANTLR start "rule__Clause__Group__5__Impl"
    // InternalSM2.g:4140:1: rule__Clause__Group__5__Impl : ( ( rule__Clause__ModifierAssignment_5 )? ) ;
    public final void rule__Clause__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4144:1: ( ( ( rule__Clause__ModifierAssignment_5 )? ) )
            // InternalSM2.g:4145:1: ( ( rule__Clause__ModifierAssignment_5 )? )
            {
            // InternalSM2.g:4145:1: ( ( rule__Clause__ModifierAssignment_5 )? )
            // InternalSM2.g:4146:2: ( rule__Clause__ModifierAssignment_5 )?
            {
             before(grammarAccess.getClauseAccess().getModifierAssignment_5()); 
            // InternalSM2.g:4147:2: ( rule__Clause__ModifierAssignment_5 )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==RULE_ID) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalSM2.g:4147:3: rule__Clause__ModifierAssignment_5
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__ModifierAssignment_5();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getModifierAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__5__Impl"


    // $ANTLR start "rule__Clause__Group__6"
    // InternalSM2.g:4155:1: rule__Clause__Group__6 : rule__Clause__Group__6__Impl rule__Clause__Group__7 ;
    public final void rule__Clause__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4159:1: ( rule__Clause__Group__6__Impl rule__Clause__Group__7 )
            // InternalSM2.g:4160:2: rule__Clause__Group__6__Impl rule__Clause__Group__7
            {
            pushFollow(FOLLOW_23);
            rule__Clause__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__6"


    // $ANTLR start "rule__Clause__Group__6__Impl"
    // InternalSM2.g:4167:1: rule__Clause__Group__6__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Clause__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4171:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:4172:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:4172:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:4173:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__6__Impl"


    // $ANTLR start "rule__Clause__Group__7"
    // InternalSM2.g:4182:1: rule__Clause__Group__7 : rule__Clause__Group__7__Impl rule__Clause__Group__8 ;
    public final void rule__Clause__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4186:1: ( rule__Clause__Group__7__Impl rule__Clause__Group__8 )
            // InternalSM2.g:4187:2: rule__Clause__Group__7__Impl rule__Clause__Group__8
            {
            pushFollow(FOLLOW_19);
            rule__Clause__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__7"


    // $ANTLR start "rule__Clause__Group__7__Impl"
    // InternalSM2.g:4194:1: rule__Clause__Group__7__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Clause__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4198:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:4199:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:4199:1: ( RULE_OPENKEY )
            // InternalSM2.g:4200:2: RULE_OPENKEY
            {
             before(grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_7()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__7__Impl"


    // $ANTLR start "rule__Clause__Group__8"
    // InternalSM2.g:4209:1: rule__Clause__Group__8 : rule__Clause__Group__8__Impl rule__Clause__Group__9 ;
    public final void rule__Clause__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4213:1: ( rule__Clause__Group__8__Impl rule__Clause__Group__9 )
            // InternalSM2.g:4214:2: rule__Clause__Group__8__Impl rule__Clause__Group__9
            {
            pushFollow(FOLLOW_43);
            rule__Clause__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__8"


    // $ANTLR start "rule__Clause__Group__8__Impl"
    // InternalSM2.g:4221:1: rule__Clause__Group__8__Impl : ( RULE_EOLINE ) ;
    public final void rule__Clause__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4225:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:4226:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:4226:1: ( RULE_EOLINE )
            // InternalSM2.g:4227:2: RULE_EOLINE
            {
             before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_8()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__8__Impl"


    // $ANTLR start "rule__Clause__Group__9"
    // InternalSM2.g:4236:1: rule__Clause__Group__9 : rule__Clause__Group__9__Impl rule__Clause__Group__10 ;
    public final void rule__Clause__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4240:1: ( rule__Clause__Group__9__Impl rule__Clause__Group__10 )
            // InternalSM2.g:4241:2: rule__Clause__Group__9__Impl rule__Clause__Group__10
            {
            pushFollow(FOLLOW_43);
            rule__Clause__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__9"


    // $ANTLR start "rule__Clause__Group__9__Impl"
    // InternalSM2.g:4248:1: rule__Clause__Group__9__Impl : ( ( rule__Clause__RestrictionAssignment_9 )? ) ;
    public final void rule__Clause__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4252:1: ( ( ( rule__Clause__RestrictionAssignment_9 )? ) )
            // InternalSM2.g:4253:1: ( ( rule__Clause__RestrictionAssignment_9 )? )
            {
            // InternalSM2.g:4253:1: ( ( rule__Clause__RestrictionAssignment_9 )? )
            // InternalSM2.g:4254:2: ( rule__Clause__RestrictionAssignment_9 )?
            {
             before(grammarAccess.getClauseAccess().getRestrictionAssignment_9()); 
            // InternalSM2.g:4255:2: ( rule__Clause__RestrictionAssignment_9 )?
            int alt44=2;
            alt44 = dfa44.predict(input);
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:4255:3: rule__Clause__RestrictionAssignment_9
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__RestrictionAssignment_9();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getRestrictionAssignment_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__9__Impl"


    // $ANTLR start "rule__Clause__Group__10"
    // InternalSM2.g:4263:1: rule__Clause__Group__10 : rule__Clause__Group__10__Impl rule__Clause__Group__11 ;
    public final void rule__Clause__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4267:1: ( rule__Clause__Group__10__Impl rule__Clause__Group__11 )
            // InternalSM2.g:4268:2: rule__Clause__Group__10__Impl rule__Clause__Group__11
            {
            pushFollow(FOLLOW_43);
            rule__Clause__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__10"


    // $ANTLR start "rule__Clause__Group__10__Impl"
    // InternalSM2.g:4275:1: rule__Clause__Group__10__Impl : ( ( rule__Clause__RestrictionGasAssignment_10 )? ) ;
    public final void rule__Clause__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4279:1: ( ( ( rule__Clause__RestrictionGasAssignment_10 )? ) )
            // InternalSM2.g:4280:1: ( ( rule__Clause__RestrictionGasAssignment_10 )? )
            {
            // InternalSM2.g:4280:1: ( ( rule__Clause__RestrictionGasAssignment_10 )? )
            // InternalSM2.g:4281:2: ( rule__Clause__RestrictionGasAssignment_10 )?
            {
             before(grammarAccess.getClauseAccess().getRestrictionGasAssignment_10()); 
            // InternalSM2.g:4282:2: ( rule__Clause__RestrictionGasAssignment_10 )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==63) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalSM2.g:4282:3: rule__Clause__RestrictionGasAssignment_10
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__RestrictionGasAssignment_10();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getRestrictionGasAssignment_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__10__Impl"


    // $ANTLR start "rule__Clause__Group__11"
    // InternalSM2.g:4290:1: rule__Clause__Group__11 : rule__Clause__Group__11__Impl rule__Clause__Group__12 ;
    public final void rule__Clause__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4294:1: ( rule__Clause__Group__11__Impl rule__Clause__Group__12 )
            // InternalSM2.g:4295:2: rule__Clause__Group__11__Impl rule__Clause__Group__12
            {
            pushFollow(FOLLOW_43);
            rule__Clause__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__11"


    // $ANTLR start "rule__Clause__Group__11__Impl"
    // InternalSM2.g:4302:1: rule__Clause__Group__11__Impl : ( ( rule__Clause__ExpressionAssignment_11 )? ) ;
    public final void rule__Clause__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4306:1: ( ( ( rule__Clause__ExpressionAssignment_11 )? ) )
            // InternalSM2.g:4307:1: ( ( rule__Clause__ExpressionAssignment_11 )? )
            {
            // InternalSM2.g:4307:1: ( ( rule__Clause__ExpressionAssignment_11 )? )
            // InternalSM2.g:4308:2: ( rule__Clause__ExpressionAssignment_11 )?
            {
             before(grammarAccess.getClauseAccess().getExpressionAssignment_11()); 
            // InternalSM2.g:4309:2: ( rule__Clause__ExpressionAssignment_11 )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==RULE_INT||LA46_0==RULE_OPENPARENTHESIS||LA46_0==RULE_STRING) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:4309:3: rule__Clause__ExpressionAssignment_11
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__ExpressionAssignment_11();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getExpressionAssignment_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__11__Impl"


    // $ANTLR start "rule__Clause__Group__12"
    // InternalSM2.g:4317:1: rule__Clause__Group__12 : rule__Clause__Group__12__Impl rule__Clause__Group__13 ;
    public final void rule__Clause__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4321:1: ( rule__Clause__Group__12__Impl rule__Clause__Group__13 )
            // InternalSM2.g:4322:2: rule__Clause__Group__12__Impl rule__Clause__Group__13
            {
            pushFollow(FOLLOW_43);
            rule__Clause__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__12"


    // $ANTLR start "rule__Clause__Group__12__Impl"
    // InternalSM2.g:4329:1: rule__Clause__Group__12__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Clause__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4333:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4334:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4334:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4335:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_12()); 
            // InternalSM2.g:4336:2: ( RULE_EOLINE )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==RULE_EOLINE) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalSM2.g:4336:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__12__Impl"


    // $ANTLR start "rule__Clause__Group__13"
    // InternalSM2.g:4344:1: rule__Clause__Group__13 : rule__Clause__Group__13__Impl rule__Clause__Group__14 ;
    public final void rule__Clause__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4348:1: ( rule__Clause__Group__13__Impl rule__Clause__Group__14 )
            // InternalSM2.g:4349:2: rule__Clause__Group__13__Impl rule__Clause__Group__14
            {
            pushFollow(FOLLOW_19);
            rule__Clause__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__13"


    // $ANTLR start "rule__Clause__Group__13__Impl"
    // InternalSM2.g:4356:1: rule__Clause__Group__13__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Clause__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4360:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:4361:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:4361:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:4362:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_13()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__13__Impl"


    // $ANTLR start "rule__Clause__Group__14"
    // InternalSM2.g:4371:1: rule__Clause__Group__14 : rule__Clause__Group__14__Impl ;
    public final void rule__Clause__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4375:1: ( rule__Clause__Group__14__Impl )
            // InternalSM2.g:4376:2: rule__Clause__Group__14__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Clause__Group__14__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__14"


    // $ANTLR start "rule__Clause__Group__14__Impl"
    // InternalSM2.g:4382:1: rule__Clause__Group__14__Impl : ( RULE_EOLINE ) ;
    public final void rule__Clause__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4386:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:4387:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:4387:1: ( RULE_EOLINE )
            // InternalSM2.g:4388:2: RULE_EOLINE
            {
             before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_14()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__14__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__0"
    // InternalSM2.g:4398:1: rule__Selfdestruct__Group__0 : rule__Selfdestruct__Group__0__Impl rule__Selfdestruct__Group__1 ;
    public final void rule__Selfdestruct__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4402:1: ( rule__Selfdestruct__Group__0__Impl rule__Selfdestruct__Group__1 )
            // InternalSM2.g:4403:2: rule__Selfdestruct__Group__0__Impl rule__Selfdestruct__Group__1
            {
            pushFollow(FOLLOW_20);
            rule__Selfdestruct__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__0"


    // $ANTLR start "rule__Selfdestruct__Group__0__Impl"
    // InternalSM2.g:4410:1: rule__Selfdestruct__Group__0__Impl : ( 'selfdesctruct' ) ;
    public final void rule__Selfdestruct__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4414:1: ( ( 'selfdesctruct' ) )
            // InternalSM2.g:4415:1: ( 'selfdesctruct' )
            {
            // InternalSM2.g:4415:1: ( 'selfdesctruct' )
            // InternalSM2.g:4416:2: 'selfdesctruct'
            {
             before(grammarAccess.getSelfdestructAccess().getSelfdesctructKeyword_0()); 
            match(input,65,FOLLOW_2); 
             after(grammarAccess.getSelfdestructAccess().getSelfdesctructKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__0__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__1"
    // InternalSM2.g:4425:1: rule__Selfdestruct__Group__1 : rule__Selfdestruct__Group__1__Impl rule__Selfdestruct__Group__2 ;
    public final void rule__Selfdestruct__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4429:1: ( rule__Selfdestruct__Group__1__Impl rule__Selfdestruct__Group__2 )
            // InternalSM2.g:4430:2: rule__Selfdestruct__Group__1__Impl rule__Selfdestruct__Group__2
            {
            pushFollow(FOLLOW_30);
            rule__Selfdestruct__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__1"


    // $ANTLR start "rule__Selfdestruct__Group__1__Impl"
    // InternalSM2.g:4437:1: rule__Selfdestruct__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Selfdestruct__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4441:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:4442:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:4442:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:4443:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getSelfdestructAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getSelfdestructAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__1__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__2"
    // InternalSM2.g:4452:1: rule__Selfdestruct__Group__2 : rule__Selfdestruct__Group__2__Impl rule__Selfdestruct__Group__3 ;
    public final void rule__Selfdestruct__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4456:1: ( rule__Selfdestruct__Group__2__Impl rule__Selfdestruct__Group__3 )
            // InternalSM2.g:4457:2: rule__Selfdestruct__Group__2__Impl rule__Selfdestruct__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__Selfdestruct__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__2"


    // $ANTLR start "rule__Selfdestruct__Group__2__Impl"
    // InternalSM2.g:4464:1: rule__Selfdestruct__Group__2__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Selfdestruct__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4468:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:4469:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:4469:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:4470:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getSelfdestructAccess().getCLOSEPARENTHESISTerminalRuleCall_2()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getSelfdestructAccess().getCLOSEPARENTHESISTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__2__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__3"
    // InternalSM2.g:4479:1: rule__Selfdestruct__Group__3 : rule__Selfdestruct__Group__3__Impl rule__Selfdestruct__Group__4 ;
    public final void rule__Selfdestruct__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4483:1: ( rule__Selfdestruct__Group__3__Impl rule__Selfdestruct__Group__4 )
            // InternalSM2.g:4484:2: rule__Selfdestruct__Group__3__Impl rule__Selfdestruct__Group__4
            {
            pushFollow(FOLLOW_19);
            rule__Selfdestruct__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__3"


    // $ANTLR start "rule__Selfdestruct__Group__3__Impl"
    // InternalSM2.g:4491:1: rule__Selfdestruct__Group__3__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Selfdestruct__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4495:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4496:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4496:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4497:2: RULE_SEMICOLON
            {
             before(grammarAccess.getSelfdestructAccess().getSEMICOLONTerminalRuleCall_3()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getSelfdestructAccess().getSEMICOLONTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__3__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__4"
    // InternalSM2.g:4506:1: rule__Selfdestruct__Group__4 : rule__Selfdestruct__Group__4__Impl ;
    public final void rule__Selfdestruct__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4510:1: ( rule__Selfdestruct__Group__4__Impl )
            // InternalSM2.g:4511:2: rule__Selfdestruct__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__4"


    // $ANTLR start "rule__Selfdestruct__Group__4__Impl"
    // InternalSM2.g:4517:1: rule__Selfdestruct__Group__4__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Selfdestruct__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4521:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4522:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4522:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4523:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getSelfdestructAccess().getEOLINETerminalRuleCall_4()); 
            // InternalSM2.g:4524:2: ( RULE_EOLINE )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==RULE_EOLINE) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalSM2.g:4524:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getSelfdestructAccess().getEOLINETerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__4__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__0"
    // InternalSM2.g:4533:1: rule__ArithmethicalExpression__Group_0__0 : rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1 ;
    public final void rule__ArithmethicalExpression__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4537:1: ( rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1 )
            // InternalSM2.g:4538:2: rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1
            {
            pushFollow(FOLLOW_39);
            rule__ArithmethicalExpression__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__0__Impl"
    // InternalSM2.g:4545:1: rule__ArithmethicalExpression__Group_0__0__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__ArithmethicalExpression__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4549:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:4550:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:4550:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:4551:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__1"
    // InternalSM2.g:4560:1: rule__ArithmethicalExpression__Group_0__1 : rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2 ;
    public final void rule__ArithmethicalExpression__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4564:1: ( rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2 )
            // InternalSM2.g:4565:2: rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2
            {
            pushFollow(FOLLOW_44);
            rule__ArithmethicalExpression__Group_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__1__Impl"
    // InternalSM2.g:4572:1: rule__ArithmethicalExpression__Group_0__1__Impl : ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4576:1: ( ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) ) )
            // InternalSM2.g:4577:1: ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) )
            {
            // InternalSM2.g:4577:1: ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) )
            // InternalSM2.g:4578:2: ( rule__ArithmethicalExpression__Op1Assignment_0_1 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_0_1()); 
            // InternalSM2.g:4579:2: ( rule__ArithmethicalExpression__Op1Assignment_0_1 )
            // InternalSM2.g:4579:3: rule__ArithmethicalExpression__Op1Assignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op1Assignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__1__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__2"
    // InternalSM2.g:4587:1: rule__ArithmethicalExpression__Group_0__2 : rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3 ;
    public final void rule__ArithmethicalExpression__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4591:1: ( rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3 )
            // InternalSM2.g:4592:2: rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3
            {
            pushFollow(FOLLOW_39);
            rule__ArithmethicalExpression__Group_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__2"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__2__Impl"
    // InternalSM2.g:4599:1: rule__ArithmethicalExpression__Group_0__2__Impl : ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4603:1: ( ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) ) )
            // InternalSM2.g:4604:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) )
            {
            // InternalSM2.g:4604:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) )
            // InternalSM2.g:4605:2: ( rule__ArithmethicalExpression__OperatorAssignment_0_2 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_0_2()); 
            // InternalSM2.g:4606:2: ( rule__ArithmethicalExpression__OperatorAssignment_0_2 )
            // InternalSM2.g:4606:3: rule__ArithmethicalExpression__OperatorAssignment_0_2
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__OperatorAssignment_0_2();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__2__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__3"
    // InternalSM2.g:4614:1: rule__ArithmethicalExpression__Group_0__3 : rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4 ;
    public final void rule__ArithmethicalExpression__Group_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4618:1: ( rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4 )
            // InternalSM2.g:4619:2: rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4
            {
            pushFollow(FOLLOW_30);
            rule__ArithmethicalExpression__Group_0__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__3"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__3__Impl"
    // InternalSM2.g:4626:1: rule__ArithmethicalExpression__Group_0__3__Impl : ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4630:1: ( ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) ) )
            // InternalSM2.g:4631:1: ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) )
            {
            // InternalSM2.g:4631:1: ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) )
            // InternalSM2.g:4632:2: ( rule__ArithmethicalExpression__Op2Assignment_0_3 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_0_3()); 
            // InternalSM2.g:4633:2: ( rule__ArithmethicalExpression__Op2Assignment_0_3 )
            // InternalSM2.g:4633:3: rule__ArithmethicalExpression__Op2Assignment_0_3
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op2Assignment_0_3();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__3__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__4"
    // InternalSM2.g:4641:1: rule__ArithmethicalExpression__Group_0__4 : rule__ArithmethicalExpression__Group_0__4__Impl ;
    public final void rule__ArithmethicalExpression__Group_0__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4645:1: ( rule__ArithmethicalExpression__Group_0__4__Impl )
            // InternalSM2.g:4646:2: rule__ArithmethicalExpression__Group_0__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__4"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__4__Impl"
    // InternalSM2.g:4652:1: rule__ArithmethicalExpression__Group_0__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__ArithmethicalExpression__Group_0__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4656:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:4657:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:4657:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:4658:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__4__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__0"
    // InternalSM2.g:4668:1: rule__ArithmethicalExpression__Group_1__0 : rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1 ;
    public final void rule__ArithmethicalExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4672:1: ( rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1 )
            // InternalSM2.g:4673:2: rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1
            {
            pushFollow(FOLLOW_44);
            rule__ArithmethicalExpression__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__0__Impl"
    // InternalSM2.g:4680:1: rule__ArithmethicalExpression__Group_1__0__Impl : ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4684:1: ( ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) ) )
            // InternalSM2.g:4685:1: ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) )
            {
            // InternalSM2.g:4685:1: ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) )
            // InternalSM2.g:4686:2: ( rule__ArithmethicalExpression__Op1Assignment_1_0 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_1_0()); 
            // InternalSM2.g:4687:2: ( rule__ArithmethicalExpression__Op1Assignment_1_0 )
            // InternalSM2.g:4687:3: rule__ArithmethicalExpression__Op1Assignment_1_0
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op1Assignment_1_0();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__1"
    // InternalSM2.g:4695:1: rule__ArithmethicalExpression__Group_1__1 : rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2 ;
    public final void rule__ArithmethicalExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4699:1: ( rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2 )
            // InternalSM2.g:4700:2: rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2
            {
            pushFollow(FOLLOW_39);
            rule__ArithmethicalExpression__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__1__Impl"
    // InternalSM2.g:4707:1: rule__ArithmethicalExpression__Group_1__1__Impl : ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4711:1: ( ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) ) )
            // InternalSM2.g:4712:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) )
            {
            // InternalSM2.g:4712:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) )
            // InternalSM2.g:4713:2: ( rule__ArithmethicalExpression__OperatorAssignment_1_1 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_1_1()); 
            // InternalSM2.g:4714:2: ( rule__ArithmethicalExpression__OperatorAssignment_1_1 )
            // InternalSM2.g:4714:3: rule__ArithmethicalExpression__OperatorAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__OperatorAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__1__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__2"
    // InternalSM2.g:4722:1: rule__ArithmethicalExpression__Group_1__2 : rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3 ;
    public final void rule__ArithmethicalExpression__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4726:1: ( rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3 )
            // InternalSM2.g:4727:2: rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3
            {
            pushFollow(FOLLOW_5);
            rule__ArithmethicalExpression__Group_1__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__2"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__2__Impl"
    // InternalSM2.g:4734:1: rule__ArithmethicalExpression__Group_1__2__Impl : ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4738:1: ( ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) ) )
            // InternalSM2.g:4739:1: ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) )
            {
            // InternalSM2.g:4739:1: ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) )
            // InternalSM2.g:4740:2: ( rule__ArithmethicalExpression__Op2Assignment_1_2 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_1_2()); 
            // InternalSM2.g:4741:2: ( rule__ArithmethicalExpression__Op2Assignment_1_2 )
            // InternalSM2.g:4741:3: rule__ArithmethicalExpression__Op2Assignment_1_2
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op2Assignment_1_2();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__2__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__3"
    // InternalSM2.g:4749:1: rule__ArithmethicalExpression__Group_1__3 : rule__ArithmethicalExpression__Group_1__3__Impl ;
    public final void rule__ArithmethicalExpression__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4753:1: ( rule__ArithmethicalExpression__Group_1__3__Impl )
            // InternalSM2.g:4754:2: rule__ArithmethicalExpression__Group_1__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__3"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__3__Impl"
    // InternalSM2.g:4760:1: rule__ArithmethicalExpression__Group_1__3__Impl : ( ( rule__ArithmethicalExpression__Group_1_3__0 )? ) ;
    public final void rule__ArithmethicalExpression__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4764:1: ( ( ( rule__ArithmethicalExpression__Group_1_3__0 )? ) )
            // InternalSM2.g:4765:1: ( ( rule__ArithmethicalExpression__Group_1_3__0 )? )
            {
            // InternalSM2.g:4765:1: ( ( rule__ArithmethicalExpression__Group_1_3__0 )? )
            // InternalSM2.g:4766:2: ( rule__ArithmethicalExpression__Group_1_3__0 )?
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getGroup_1_3()); 
            // InternalSM2.g:4767:2: ( rule__ArithmethicalExpression__Group_1_3__0 )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==RULE_SEMICOLON) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // InternalSM2.g:4767:3: rule__ArithmethicalExpression__Group_1_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_1_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getArithmethicalExpressionAccess().getGroup_1_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__3__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__0"
    // InternalSM2.g:4776:1: rule__ArithmethicalExpression__Group_1_3__0 : rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1 ;
    public final void rule__ArithmethicalExpression__Group_1_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4780:1: ( rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1 )
            // InternalSM2.g:4781:2: rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1
            {
            pushFollow(FOLLOW_19);
            rule__ArithmethicalExpression__Group_1_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__0__Impl"
    // InternalSM2.g:4788:1: rule__ArithmethicalExpression__Group_1_3__0__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__ArithmethicalExpression__Group_1_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4792:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4793:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4793:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4794:2: RULE_SEMICOLON
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__1"
    // InternalSM2.g:4803:1: rule__ArithmethicalExpression__Group_1_3__1 : rule__ArithmethicalExpression__Group_1_3__1__Impl ;
    public final void rule__ArithmethicalExpression__Group_1_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4807:1: ( rule__ArithmethicalExpression__Group_1_3__1__Impl )
            // InternalSM2.g:4808:2: rule__ArithmethicalExpression__Group_1_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__1__Impl"
    // InternalSM2.g:4814:1: rule__ArithmethicalExpression__Group_1_3__1__Impl : ( RULE_EOLINE ) ;
    public final void rule__ArithmethicalExpression__Group_1_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4818:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:4819:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:4819:1: ( RULE_EOLINE )
            // InternalSM2.g:4820:2: RULE_EOLINE
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__1__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1__0"
    // InternalSM2.g:4830:1: rule__SyntaxExpression__Group_1__0 : rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1 ;
    public final void rule__SyntaxExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4834:1: ( rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1 )
            // InternalSM2.g:4835:2: rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1
            {
            pushFollow(FOLLOW_5);
            rule__SyntaxExpression__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__0"


    // $ANTLR start "rule__SyntaxExpression__Group_1__0__Impl"
    // InternalSM2.g:4842:1: rule__SyntaxExpression__Group_1__0__Impl : ( RULE_INT ) ;
    public final void rule__SyntaxExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4846:1: ( ( RULE_INT ) )
            // InternalSM2.g:4847:1: ( RULE_INT )
            {
            // InternalSM2.g:4847:1: ( RULE_INT )
            // InternalSM2.g:4848:2: RULE_INT
            {
             before(grammarAccess.getSyntaxExpressionAccess().getINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__0__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1__1"
    // InternalSM2.g:4857:1: rule__SyntaxExpression__Group_1__1 : rule__SyntaxExpression__Group_1__1__Impl ;
    public final void rule__SyntaxExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4861:1: ( rule__SyntaxExpression__Group_1__1__Impl )
            // InternalSM2.g:4862:2: rule__SyntaxExpression__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__1"


    // $ANTLR start "rule__SyntaxExpression__Group_1__1__Impl"
    // InternalSM2.g:4868:1: rule__SyntaxExpression__Group_1__1__Impl : ( ( rule__SyntaxExpression__Group_1_1__0 )? ) ;
    public final void rule__SyntaxExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4872:1: ( ( ( rule__SyntaxExpression__Group_1_1__0 )? ) )
            // InternalSM2.g:4873:1: ( ( rule__SyntaxExpression__Group_1_1__0 )? )
            {
            // InternalSM2.g:4873:1: ( ( rule__SyntaxExpression__Group_1_1__0 )? )
            // InternalSM2.g:4874:2: ( rule__SyntaxExpression__Group_1_1__0 )?
            {
             before(grammarAccess.getSyntaxExpressionAccess().getGroup_1_1()); 
            // InternalSM2.g:4875:2: ( rule__SyntaxExpression__Group_1_1__0 )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==RULE_SEMICOLON) ) {
                alt50=1;
            }
            switch (alt50) {
                case 1 :
                    // InternalSM2.g:4875:3: rule__SyntaxExpression__Group_1_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__Group_1_1__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSyntaxExpressionAccess().getGroup_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__1__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__0"
    // InternalSM2.g:4884:1: rule__SyntaxExpression__Group_1_1__0 : rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1 ;
    public final void rule__SyntaxExpression__Group_1_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4888:1: ( rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1 )
            // InternalSM2.g:4889:2: rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1
            {
            pushFollow(FOLLOW_19);
            rule__SyntaxExpression__Group_1_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__0"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__0__Impl"
    // InternalSM2.g:4896:1: rule__SyntaxExpression__Group_1_1__0__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__SyntaxExpression__Group_1_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4900:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4901:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4901:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4902:2: RULE_SEMICOLON
            {
             before(grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__0__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__1"
    // InternalSM2.g:4911:1: rule__SyntaxExpression__Group_1_1__1 : rule__SyntaxExpression__Group_1_1__1__Impl ;
    public final void rule__SyntaxExpression__Group_1_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4915:1: ( rule__SyntaxExpression__Group_1_1__1__Impl )
            // InternalSM2.g:4916:2: rule__SyntaxExpression__Group_1_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__1"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__1__Impl"
    // InternalSM2.g:4922:1: rule__SyntaxExpression__Group_1_1__1__Impl : ( RULE_EOLINE ) ;
    public final void rule__SyntaxExpression__Group_1_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4926:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:4927:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:4927:1: ( RULE_EOLINE )
            // InternalSM2.g:4928:2: RULE_EOLINE
            {
             before(grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__1__Impl"


    // $ANTLR start "rule__ShortComment__Group__0"
    // InternalSM2.g:4938:1: rule__ShortComment__Group__0 : rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1 ;
    public final void rule__ShortComment__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4942:1: ( rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1 )
            // InternalSM2.g:4943:2: rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1
            {
            pushFollow(FOLLOW_29);
            rule__ShortComment__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__0"


    // $ANTLR start "rule__ShortComment__Group__0__Impl"
    // InternalSM2.g:4950:1: rule__ShortComment__Group__0__Impl : ( '//' ) ;
    public final void rule__ShortComment__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4954:1: ( ( '//' ) )
            // InternalSM2.g:4955:1: ( '//' )
            {
            // InternalSM2.g:4955:1: ( '//' )
            // InternalSM2.g:4956:2: '//'
            {
             before(grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0()); 
            match(input,66,FOLLOW_2); 
             after(grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__0__Impl"


    // $ANTLR start "rule__ShortComment__Group__1"
    // InternalSM2.g:4965:1: rule__ShortComment__Group__1 : rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2 ;
    public final void rule__ShortComment__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4969:1: ( rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2 )
            // InternalSM2.g:4970:2: rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2
            {
            pushFollow(FOLLOW_19);
            rule__ShortComment__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__1"


    // $ANTLR start "rule__ShortComment__Group__1__Impl"
    // InternalSM2.g:4977:1: rule__ShortComment__Group__1__Impl : ( ( rule__ShortComment__ExprAssignment_1 ) ) ;
    public final void rule__ShortComment__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4981:1: ( ( ( rule__ShortComment__ExprAssignment_1 ) ) )
            // InternalSM2.g:4982:1: ( ( rule__ShortComment__ExprAssignment_1 ) )
            {
            // InternalSM2.g:4982:1: ( ( rule__ShortComment__ExprAssignment_1 ) )
            // InternalSM2.g:4983:2: ( rule__ShortComment__ExprAssignment_1 )
            {
             before(grammarAccess.getShortCommentAccess().getExprAssignment_1()); 
            // InternalSM2.g:4984:2: ( rule__ShortComment__ExprAssignment_1 )
            // InternalSM2.g:4984:3: rule__ShortComment__ExprAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__ExprAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getShortCommentAccess().getExprAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__1__Impl"


    // $ANTLR start "rule__ShortComment__Group__2"
    // InternalSM2.g:4992:1: rule__ShortComment__Group__2 : rule__ShortComment__Group__2__Impl ;
    public final void rule__ShortComment__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4996:1: ( rule__ShortComment__Group__2__Impl )
            // InternalSM2.g:4997:2: rule__ShortComment__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__2"


    // $ANTLR start "rule__ShortComment__Group__2__Impl"
    // InternalSM2.g:5003:1: rule__ShortComment__Group__2__Impl : ( RULE_EOLINE ) ;
    public final void rule__ShortComment__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5007:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:5008:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:5008:1: ( RULE_EOLINE )
            // InternalSM2.g:5009:2: RULE_EOLINE
            {
             before(grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__2__Impl"


    // $ANTLR start "rule__LongComment__Group__0"
    // InternalSM2.g:5019:1: rule__LongComment__Group__0 : rule__LongComment__Group__0__Impl rule__LongComment__Group__1 ;
    public final void rule__LongComment__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5023:1: ( rule__LongComment__Group__0__Impl rule__LongComment__Group__1 )
            // InternalSM2.g:5024:2: rule__LongComment__Group__0__Impl rule__LongComment__Group__1
            {
            pushFollow(FOLLOW_29);
            rule__LongComment__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LongComment__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__0"


    // $ANTLR start "rule__LongComment__Group__0__Impl"
    // InternalSM2.g:5031:1: rule__LongComment__Group__0__Impl : ( '/*' ) ;
    public final void rule__LongComment__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5035:1: ( ( '/*' ) )
            // InternalSM2.g:5036:1: ( '/*' )
            {
            // InternalSM2.g:5036:1: ( '/*' )
            // InternalSM2.g:5037:2: '/*'
            {
             before(grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0()); 
            match(input,67,FOLLOW_2); 
             after(grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__0__Impl"


    // $ANTLR start "rule__LongComment__Group__1"
    // InternalSM2.g:5046:1: rule__LongComment__Group__1 : rule__LongComment__Group__1__Impl rule__LongComment__Group__2 ;
    public final void rule__LongComment__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5050:1: ( rule__LongComment__Group__1__Impl rule__LongComment__Group__2 )
            // InternalSM2.g:5051:2: rule__LongComment__Group__1__Impl rule__LongComment__Group__2
            {
            pushFollow(FOLLOW_45);
            rule__LongComment__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LongComment__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__1"


    // $ANTLR start "rule__LongComment__Group__1__Impl"
    // InternalSM2.g:5058:1: rule__LongComment__Group__1__Impl : ( ( rule__LongComment__ExprAssignment_1 ) ) ;
    public final void rule__LongComment__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5062:1: ( ( ( rule__LongComment__ExprAssignment_1 ) ) )
            // InternalSM2.g:5063:1: ( ( rule__LongComment__ExprAssignment_1 ) )
            {
            // InternalSM2.g:5063:1: ( ( rule__LongComment__ExprAssignment_1 ) )
            // InternalSM2.g:5064:2: ( rule__LongComment__ExprAssignment_1 )
            {
             before(grammarAccess.getLongCommentAccess().getExprAssignment_1()); 
            // InternalSM2.g:5065:2: ( rule__LongComment__ExprAssignment_1 )
            // InternalSM2.g:5065:3: rule__LongComment__ExprAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__ExprAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getLongCommentAccess().getExprAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__1__Impl"


    // $ANTLR start "rule__LongComment__Group__2"
    // InternalSM2.g:5073:1: rule__LongComment__Group__2 : rule__LongComment__Group__2__Impl ;
    public final void rule__LongComment__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5077:1: ( rule__LongComment__Group__2__Impl )
            // InternalSM2.g:5078:2: rule__LongComment__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__2"


    // $ANTLR start "rule__LongComment__Group__2__Impl"
    // InternalSM2.g:5084:1: rule__LongComment__Group__2__Impl : ( '*/' ) ;
    public final void rule__LongComment__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5088:1: ( ( '*/' ) )
            // InternalSM2.g:5089:1: ( '*/' )
            {
            // InternalSM2.g:5089:1: ( '*/' )
            // InternalSM2.g:5090:2: '*/'
            {
             before(grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2()); 
            match(input,68,FOLLOW_2); 
             after(grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__2__Impl"


    // $ANTLR start "rule__SmartContract__CompilerAssignment_0"
    // InternalSM2.g:5100:1: rule__SmartContract__CompilerAssignment_0 : ( ( 'pragma' ) ) ;
    public final void rule__SmartContract__CompilerAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5104:1: ( ( ( 'pragma' ) ) )
            // InternalSM2.g:5105:2: ( ( 'pragma' ) )
            {
            // InternalSM2.g:5105:2: ( ( 'pragma' ) )
            // InternalSM2.g:5106:3: ( 'pragma' )
            {
             before(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 
            // InternalSM2.g:5107:3: ( 'pragma' )
            // InternalSM2.g:5108:4: 'pragma'
            {
             before(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 
            match(input,69,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 

            }

             after(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__CompilerAssignment_0"


    // $ANTLR start "rule__SmartContract__VersionCompilerAssignment_2"
    // InternalSM2.g:5119:1: rule__SmartContract__VersionCompilerAssignment_2 : ( ruleVersion ) ;
    public final void rule__SmartContract__VersionCompilerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5123:1: ( ( ruleVersion ) )
            // InternalSM2.g:5124:2: ( ruleVersion )
            {
            // InternalSM2.g:5124:2: ( ruleVersion )
            // InternalSM2.g:5125:3: ruleVersion
            {
             before(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleVersion();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__VersionCompilerAssignment_2"


    // $ANTLR start "rule__SmartContract__ImportsAssignment_5"
    // InternalSM2.g:5134:1: rule__SmartContract__ImportsAssignment_5 : ( ruleImport ) ;
    public final void rule__SmartContract__ImportsAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5138:1: ( ( ruleImport ) )
            // InternalSM2.g:5139:2: ( ruleImport )
            {
            // InternalSM2.g:5139:2: ( ruleImport )
            // InternalSM2.g:5140:3: ruleImport
            {
             before(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleImport();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ImportsAssignment_5"


    // $ANTLR start "rule__SmartContract__ContractAssignment_6"
    // InternalSM2.g:5149:1: rule__SmartContract__ContractAssignment_6 : ( ( 'contract' ) ) ;
    public final void rule__SmartContract__ContractAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5153:1: ( ( ( 'contract' ) ) )
            // InternalSM2.g:5154:2: ( ( 'contract' ) )
            {
            // InternalSM2.g:5154:2: ( ( 'contract' ) )
            // InternalSM2.g:5155:3: ( 'contract' )
            {
             before(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 
            // InternalSM2.g:5156:3: ( 'contract' )
            // InternalSM2.g:5157:4: 'contract'
            {
             before(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 
            match(input,70,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 

            }

             after(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ContractAssignment_6"


    // $ANTLR start "rule__SmartContract__NameContractAssignment_7"
    // InternalSM2.g:5168:1: rule__SmartContract__NameContractAssignment_7 : ( RULE_ID ) ;
    public final void rule__SmartContract__NameContractAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5172:1: ( ( RULE_ID ) )
            // InternalSM2.g:5173:2: ( RULE_ID )
            {
            // InternalSM2.g:5173:2: ( RULE_ID )
            // InternalSM2.g:5174:3: RULE_ID
            {
             before(grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_7_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__NameContractAssignment_7"


    // $ANTLR start "rule__SmartContract__NameContractFatherAssignment_8_1"
    // InternalSM2.g:5183:1: rule__SmartContract__NameContractFatherAssignment_8_1 : ( RULE_ID ) ;
    public final void rule__SmartContract__NameContractFatherAssignment_8_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5187:1: ( ( RULE_ID ) )
            // InternalSM2.g:5188:2: ( RULE_ID )
            {
            // InternalSM2.g:5188:2: ( RULE_ID )
            // InternalSM2.g:5189:3: RULE_ID
            {
             before(grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_8_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_8_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__NameContractFatherAssignment_8_1"


    // $ANTLR start "rule__SmartContract__AttributesAssignment_11"
    // InternalSM2.g:5198:1: rule__SmartContract__AttributesAssignment_11 : ( ruleAttributes ) ;
    public final void rule__SmartContract__AttributesAssignment_11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5202:1: ( ( ruleAttributes ) )
            // InternalSM2.g:5203:2: ( ruleAttributes )
            {
            // InternalSM2.g:5203:2: ( ruleAttributes )
            // InternalSM2.g:5204:3: ruleAttributes
            {
             before(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_11_0()); 
            pushFollow(FOLLOW_2);
            ruleAttributes();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__AttributesAssignment_11"


    // $ANTLR start "rule__SmartContract__EventsAssignment_12"
    // InternalSM2.g:5213:1: rule__SmartContract__EventsAssignment_12 : ( ruleEvent ) ;
    public final void rule__SmartContract__EventsAssignment_12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5217:1: ( ( ruleEvent ) )
            // InternalSM2.g:5218:2: ( ruleEvent )
            {
            // InternalSM2.g:5218:2: ( ruleEvent )
            // InternalSM2.g:5219:3: ruleEvent
            {
             before(grammarAccess.getSmartContractAccess().getEventsEventParserRuleCall_12_0()); 
            pushFollow(FOLLOW_2);
            ruleEvent();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getEventsEventParserRuleCall_12_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__EventsAssignment_12"


    // $ANTLR start "rule__SmartContract__ModifierAssignment_13"
    // InternalSM2.g:5228:1: rule__SmartContract__ModifierAssignment_13 : ( ruleModifier ) ;
    public final void rule__SmartContract__ModifierAssignment_13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5232:1: ( ( ruleModifier ) )
            // InternalSM2.g:5233:2: ( ruleModifier )
            {
            // InternalSM2.g:5233:2: ( ruleModifier )
            // InternalSM2.g:5234:3: ruleModifier
            {
             before(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_13_0()); 
            pushFollow(FOLLOW_2);
            ruleModifier();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_13_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ModifierAssignment_13"


    // $ANTLR start "rule__SmartContract__ClausesAssignment_14"
    // InternalSM2.g:5243:1: rule__SmartContract__ClausesAssignment_14 : ( ruleClause ) ;
    public final void rule__SmartContract__ClausesAssignment_14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5247:1: ( ( ruleClause ) )
            // InternalSM2.g:5248:2: ( ruleClause )
            {
            // InternalSM2.g:5248:2: ( ruleClause )
            // InternalSM2.g:5249:3: ruleClause
            {
             before(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_14_0()); 
            pushFollow(FOLLOW_2);
            ruleClause();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_14_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ClausesAssignment_14"


    // $ANTLR start "rule__SmartContract__CommentsAssignment_15"
    // InternalSM2.g:5258:1: rule__SmartContract__CommentsAssignment_15 : ( ruleComment ) ;
    public final void rule__SmartContract__CommentsAssignment_15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5262:1: ( ( ruleComment ) )
            // InternalSM2.g:5263:2: ( ruleComment )
            {
            // InternalSM2.g:5263:2: ( ruleComment )
            // InternalSM2.g:5264:3: ruleComment
            {
             before(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_15_0()); 
            pushFollow(FOLLOW_2);
            ruleComment();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_15_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__CommentsAssignment_15"


    // $ANTLR start "rule__Version__SymbolAssignment_0"
    // InternalSM2.g:5273:1: rule__Version__SymbolAssignment_0 : ( ( rule__Version__SymbolAlternatives_0_0 ) ) ;
    public final void rule__Version__SymbolAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5277:1: ( ( ( rule__Version__SymbolAlternatives_0_0 ) ) )
            // InternalSM2.g:5278:2: ( ( rule__Version__SymbolAlternatives_0_0 ) )
            {
            // InternalSM2.g:5278:2: ( ( rule__Version__SymbolAlternatives_0_0 ) )
            // InternalSM2.g:5279:3: ( rule__Version__SymbolAlternatives_0_0 )
            {
             before(grammarAccess.getVersionAccess().getSymbolAlternatives_0_0()); 
            // InternalSM2.g:5280:3: ( rule__Version__SymbolAlternatives_0_0 )
            // InternalSM2.g:5280:4: rule__Version__SymbolAlternatives_0_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAlternatives_0_0();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getSymbolAlternatives_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAssignment_0"


    // $ANTLR start "rule__Version__NumberVersionAssignment_1"
    // InternalSM2.g:5288:1: rule__Version__NumberVersionAssignment_1 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5292:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:5293:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:5293:2: ( RULE_NUMBER )
            // InternalSM2.g:5294:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_1_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionAssignment_1"


    // $ANTLR start "rule__Version__NumberVersion2Assignment_3"
    // InternalSM2.g:5303:1: rule__Version__NumberVersion2Assignment_3 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion2Assignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5307:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:5308:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:5308:2: ( RULE_NUMBER )
            // InternalSM2.g:5309:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_3_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion2Assignment_3"


    // $ANTLR start "rule__Version__NumberVersion3Assignment_5"
    // InternalSM2.g:5318:1: rule__Version__NumberVersion3Assignment_5 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion3Assignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5322:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:5323:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:5323:2: ( RULE_NUMBER )
            // InternalSM2.g:5324:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_5_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion3Assignment_5"


    // $ANTLR start "rule__Version__OptionalversionAssignment_6"
    // InternalSM2.g:5333:1: rule__Version__OptionalversionAssignment_6 : ( ( RULE_ID ) ) ;
    public final void rule__Version__OptionalversionAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5337:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:5338:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:5338:2: ( ( RULE_ID ) )
            // InternalSM2.g:5339:3: ( RULE_ID )
            {
             before(grammarAccess.getVersionAccess().getOptionalversionVersionCrossReference_6_0()); 
            // InternalSM2.g:5340:3: ( RULE_ID )
            // InternalSM2.g:5341:4: RULE_ID
            {
             before(grammarAccess.getVersionAccess().getOptionalversionVersionIDTerminalRuleCall_6_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getOptionalversionVersionIDTerminalRuleCall_6_0_1()); 

            }

             after(grammarAccess.getVersionAccess().getOptionalversionVersionCrossReference_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__OptionalversionAssignment_6"


    // $ANTLR start "rule__Import__NameLibraryAssignment_1"
    // InternalSM2.g:5352:1: rule__Import__NameLibraryAssignment_1 : ( RULE_ID ) ;
    public final void rule__Import__NameLibraryAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5356:1: ( ( RULE_ID ) )
            // InternalSM2.g:5357:2: ( RULE_ID )
            {
            // InternalSM2.g:5357:2: ( RULE_ID )
            // InternalSM2.g:5358:3: RULE_ID
            {
             before(grammarAccess.getImportAccess().getNameLibraryIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getNameLibraryIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__NameLibraryAssignment_1"


    // $ANTLR start "rule__Import__AliasAssignment_2_1"
    // InternalSM2.g:5367:1: rule__Import__AliasAssignment_2_1 : ( RULE_ID ) ;
    public final void rule__Import__AliasAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5371:1: ( ( RULE_ID ) )
            // InternalSM2.g:5372:2: ( RULE_ID )
            {
            // InternalSM2.g:5372:2: ( RULE_ID )
            // InternalSM2.g:5373:3: RULE_ID
            {
             before(grammarAccess.getImportAccess().getAliasIDTerminalRuleCall_2_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getAliasIDTerminalRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__AliasAssignment_2_1"


    // $ANTLR start "rule__Event__NameEventAssignment_1"
    // InternalSM2.g:5382:1: rule__Event__NameEventAssignment_1 : ( RULE_ID ) ;
    public final void rule__Event__NameEventAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5386:1: ( ( RULE_ID ) )
            // InternalSM2.g:5387:2: ( RULE_ID )
            {
            // InternalSM2.g:5387:2: ( RULE_ID )
            // InternalSM2.g:5388:3: RULE_ID
            {
             before(grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__NameEventAssignment_1"


    // $ANTLR start "rule__Event__InputParamsAssignment_3"
    // InternalSM2.g:5397:1: rule__Event__InputParamsAssignment_3 : ( ruleInputParam ) ;
    public final void rule__Event__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5401:1: ( ( ruleInputParam ) )
            // InternalSM2.g:5402:2: ( ruleInputParam )
            {
            // InternalSM2.g:5402:2: ( ruleInputParam )
            // InternalSM2.g:5403:3: ruleInputParam
            {
             before(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleInputParam();

            state._fsp--;

             after(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__InputParamsAssignment_3"


    // $ANTLR start "rule__Modifier__NameModifierAssignment_1"
    // InternalSM2.g:5412:1: rule__Modifier__NameModifierAssignment_1 : ( RULE_ID ) ;
    public final void rule__Modifier__NameModifierAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5416:1: ( ( RULE_ID ) )
            // InternalSM2.g:5417:2: ( RULE_ID )
            {
            // InternalSM2.g:5417:2: ( RULE_ID )
            // InternalSM2.g:5418:3: RULE_ID
            {
             before(grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__NameModifierAssignment_1"


    // $ANTLR start "rule__Modifier__InputParamsAssignment_3"
    // InternalSM2.g:5427:1: rule__Modifier__InputParamsAssignment_3 : ( ruleInputParam ) ;
    public final void rule__Modifier__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5431:1: ( ( ruleInputParam ) )
            // InternalSM2.g:5432:2: ( ruleInputParam )
            {
            // InternalSM2.g:5432:2: ( ruleInputParam )
            // InternalSM2.g:5433:3: ruleInputParam
            {
             before(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleInputParam();

            state._fsp--;

             after(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__InputParamsAssignment_3"


    // $ANTLR start "rule__Modifier__ExprAssignment_7"
    // InternalSM2.g:5442:1: rule__Modifier__ExprAssignment_7 : ( RULE_STRING ) ;
    public final void rule__Modifier__ExprAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5446:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5447:2: ( RULE_STRING )
            {
            // InternalSM2.g:5447:2: ( RULE_STRING )
            // InternalSM2.g:5448:3: RULE_STRING
            {
             before(grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__ExprAssignment_7"


    // $ANTLR start "rule__Mapping__TypeAssignment_2"
    // InternalSM2.g:5457:1: rule__Mapping__TypeAssignment_2 : ( ruleSingularType ) ;
    public final void rule__Mapping__TypeAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5461:1: ( ( ruleSingularType ) )
            // InternalSM2.g:5462:2: ( ruleSingularType )
            {
            // InternalSM2.g:5462:2: ( ruleSingularType )
            // InternalSM2.g:5463:3: ruleSingularType
            {
             before(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;

             after(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__TypeAssignment_2"


    // $ANTLR start "rule__Mapping__ExprAssignment_4"
    // InternalSM2.g:5472:1: rule__Mapping__ExprAssignment_4 : ( RULE_STRING ) ;
    public final void rule__Mapping__ExprAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5476:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5477:2: ( RULE_STRING )
            {
            // InternalSM2.g:5477:2: ( RULE_STRING )
            // InternalSM2.g:5478:3: RULE_STRING
            {
             before(grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__ExprAssignment_4"


    // $ANTLR start "rule__Mapping__VisibilityAssignment_6"
    // InternalSM2.g:5487:1: rule__Mapping__VisibilityAssignment_6 : ( ruleVisibility ) ;
    public final void rule__Mapping__VisibilityAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5491:1: ( ( ruleVisibility ) )
            // InternalSM2.g:5492:2: ( ruleVisibility )
            {
            // InternalSM2.g:5492:2: ( ruleVisibility )
            // InternalSM2.g:5493:3: ruleVisibility
            {
             before(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__VisibilityAssignment_6"


    // $ANTLR start "rule__Mapping__NameMappingAssignment_7"
    // InternalSM2.g:5502:1: rule__Mapping__NameMappingAssignment_7 : ( RULE_ID ) ;
    public final void rule__Mapping__NameMappingAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5506:1: ( ( RULE_ID ) )
            // InternalSM2.g:5507:2: ( RULE_ID )
            {
            // InternalSM2.g:5507:2: ( RULE_ID )
            // InternalSM2.g:5508:3: RULE_ID
            {
             before(grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__NameMappingAssignment_7"


    // $ANTLR start "rule__Struct__NameStructAssignment_1"
    // InternalSM2.g:5517:1: rule__Struct__NameStructAssignment_1 : ( RULE_ID ) ;
    public final void rule__Struct__NameStructAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5521:1: ( ( RULE_ID ) )
            // InternalSM2.g:5522:2: ( RULE_ID )
            {
            // InternalSM2.g:5522:2: ( RULE_ID )
            // InternalSM2.g:5523:3: RULE_ID
            {
             before(grammarAccess.getStructAccess().getNameStructIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getStructAccess().getNameStructIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__NameStructAssignment_1"


    // $ANTLR start "rule__Struct__PropertiesAssignment_4"
    // InternalSM2.g:5532:1: rule__Struct__PropertiesAssignment_4 : ( ruleProperty ) ;
    public final void rule__Struct__PropertiesAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5536:1: ( ( ruleProperty ) )
            // InternalSM2.g:5537:2: ( ruleProperty )
            {
            // InternalSM2.g:5537:2: ( ruleProperty )
            // InternalSM2.g:5538:3: ruleProperty
            {
             before(grammarAccess.getStructAccess().getPropertiesPropertyParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleProperty();

            state._fsp--;

             after(grammarAccess.getStructAccess().getPropertiesPropertyParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__PropertiesAssignment_4"


    // $ANTLR start "rule__Enum__NameEnumAssignment_1"
    // InternalSM2.g:5547:1: rule__Enum__NameEnumAssignment_1 : ( RULE_ID ) ;
    public final void rule__Enum__NameEnumAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5551:1: ( ( RULE_ID ) )
            // InternalSM2.g:5552:2: ( RULE_ID )
            {
            // InternalSM2.g:5552:2: ( RULE_ID )
            // InternalSM2.g:5553:3: RULE_ID
            {
             before(grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__NameEnumAssignment_1"


    // $ANTLR start "rule__Enum__ExprAssignment_3"
    // InternalSM2.g:5562:1: rule__Enum__ExprAssignment_3 : ( RULE_STRING ) ;
    public final void rule__Enum__ExprAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5566:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5567:2: ( RULE_STRING )
            {
            // InternalSM2.g:5567:2: ( RULE_STRING )
            // InternalSM2.g:5568:3: RULE_STRING
            {
             before(grammarAccess.getEnumAccess().getExprSTRINGTerminalRuleCall_3_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getExprSTRINGTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__ExprAssignment_3"


    // $ANTLR start "rule__Property__TypeAssignment_0"
    // InternalSM2.g:5577:1: rule__Property__TypeAssignment_0 : ( ruleSingularType ) ;
    public final void rule__Property__TypeAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5581:1: ( ( ruleSingularType ) )
            // InternalSM2.g:5582:2: ( ruleSingularType )
            {
            // InternalSM2.g:5582:2: ( ruleSingularType )
            // InternalSM2.g:5583:3: ruleSingularType
            {
             before(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;

             after(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__TypeAssignment_0"


    // $ANTLR start "rule__Property__VisibilityAssignment_1"
    // InternalSM2.g:5592:1: rule__Property__VisibilityAssignment_1 : ( ruleVisibility ) ;
    public final void rule__Property__VisibilityAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5596:1: ( ( ruleVisibility ) )
            // InternalSM2.g:5597:2: ( ruleVisibility )
            {
            // InternalSM2.g:5597:2: ( ruleVisibility )
            // InternalSM2.g:5598:3: ruleVisibility
            {
             before(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__VisibilityAssignment_1"


    // $ANTLR start "rule__Property__NamePropertyAssignment_2"
    // InternalSM2.g:5607:1: rule__Property__NamePropertyAssignment_2 : ( RULE_ID ) ;
    public final void rule__Property__NamePropertyAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5611:1: ( ( RULE_ID ) )
            // InternalSM2.g:5612:2: ( RULE_ID )
            {
            // InternalSM2.g:5612:2: ( RULE_ID )
            // InternalSM2.g:5613:3: RULE_ID
            {
             before(grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__NamePropertyAssignment_2"


    // $ANTLR start "rule__Property__InicializationAssignment_4_0"
    // InternalSM2.g:5622:1: rule__Property__InicializationAssignment_4_0 : ( RULE_STRING ) ;
    public final void rule__Property__InicializationAssignment_4_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5626:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5627:2: ( RULE_STRING )
            {
            // InternalSM2.g:5627:2: ( RULE_STRING )
            // InternalSM2.g:5628:3: RULE_STRING
            {
             before(grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__InicializationAssignment_4_0"


    // $ANTLR start "rule__InputParam__TypeAssignment_0_0"
    // InternalSM2.g:5637:1: rule__InputParam__TypeAssignment_0_0 : ( ruleSingularType ) ;
    public final void rule__InputParam__TypeAssignment_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5641:1: ( ( ruleSingularType ) )
            // InternalSM2.g:5642:2: ( ruleSingularType )
            {
            // InternalSM2.g:5642:2: ( ruleSingularType )
            // InternalSM2.g:5643:3: ruleSingularType
            {
             before(grammarAccess.getInputParamAccess().getTypeSingularTypeEnumRuleCall_0_0_0()); 
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;

             after(grammarAccess.getInputParamAccess().getTypeSingularTypeEnumRuleCall_0_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__TypeAssignment_0_0"


    // $ANTLR start "rule__InputParam__NameParamAssignment_0_1"
    // InternalSM2.g:5652:1: rule__InputParam__NameParamAssignment_0_1 : ( RULE_ID ) ;
    public final void rule__InputParam__NameParamAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5656:1: ( ( RULE_ID ) )
            // InternalSM2.g:5657:2: ( RULE_ID )
            {
            // InternalSM2.g:5657:2: ( RULE_ID )
            // InternalSM2.g:5658:3: RULE_ID
            {
             before(grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__NameParamAssignment_0_1"


    // $ANTLR start "rule__Restriction__ExprAssignment_2"
    // InternalSM2.g:5667:1: rule__Restriction__ExprAssignment_2 : ( ruleSyntaxExpression ) ;
    public final void rule__Restriction__ExprAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5671:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:5672:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:5672:2: ( ruleSyntaxExpression )
            // InternalSM2.g:5673:3: ruleSyntaxExpression
            {
             before(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__ExprAssignment_2"


    // $ANTLR start "rule__Restriction__OperatorAssignment_3"
    // InternalSM2.g:5682:1: rule__Restriction__OperatorAssignment_3 : ( ruleComparationOperator ) ;
    public final void rule__Restriction__OperatorAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5686:1: ( ( ruleComparationOperator ) )
            // InternalSM2.g:5687:2: ( ruleComparationOperator )
            {
            // InternalSM2.g:5687:2: ( ruleComparationOperator )
            // InternalSM2.g:5688:3: ruleComparationOperator
            {
             before(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleComparationOperator();

            state._fsp--;

             after(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__OperatorAssignment_3"


    // $ANTLR start "rule__Restriction__ExprAssignment_4"
    // InternalSM2.g:5697:1: rule__Restriction__ExprAssignment_4 : ( ruleSyntaxExpression ) ;
    public final void rule__Restriction__ExprAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5701:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:5702:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:5702:2: ( ruleSyntaxExpression )
            // InternalSM2.g:5703:3: ruleSyntaxExpression
            {
             before(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__ExprAssignment_4"


    // $ANTLR start "rule__RestrictionGas__ExprAssignment_2"
    // InternalSM2.g:5712:1: rule__RestrictionGas__ExprAssignment_2 : ( ruleSyntaxExpression ) ;
    public final void rule__RestrictionGas__ExprAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5716:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:5717:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:5717:2: ( ruleSyntaxExpression )
            // InternalSM2.g:5718:3: ruleSyntaxExpression
            {
             before(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__ExprAssignment_2"


    // $ANTLR start "rule__RestrictionGas__OperatorAssignment_3"
    // InternalSM2.g:5727:1: rule__RestrictionGas__OperatorAssignment_3 : ( ruleComparationOperator ) ;
    public final void rule__RestrictionGas__OperatorAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5731:1: ( ( ruleComparationOperator ) )
            // InternalSM2.g:5732:2: ( ruleComparationOperator )
            {
            // InternalSM2.g:5732:2: ( ruleComparationOperator )
            // InternalSM2.g:5733:3: ruleComparationOperator
            {
             before(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleComparationOperator();

            state._fsp--;

             after(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__OperatorAssignment_3"


    // $ANTLR start "rule__RestrictionGas__AmountAssignment_4"
    // InternalSM2.g:5742:1: rule__RestrictionGas__AmountAssignment_4 : ( RULE_INT ) ;
    public final void rule__RestrictionGas__AmountAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5746:1: ( ( RULE_INT ) )
            // InternalSM2.g:5747:2: ( RULE_INT )
            {
            // InternalSM2.g:5747:2: ( RULE_INT )
            // InternalSM2.g:5748:3: RULE_INT
            {
             before(grammarAccess.getRestrictionGasAccess().getAmountINTTerminalRuleCall_4_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getAmountINTTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__AmountAssignment_4"


    // $ANTLR start "rule__RestrictionGas__TypeCoinAssignment_5"
    // InternalSM2.g:5757:1: rule__RestrictionGas__TypeCoinAssignment_5 : ( ruleCoin ) ;
    public final void rule__RestrictionGas__TypeCoinAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5761:1: ( ( ruleCoin ) )
            // InternalSM2.g:5762:2: ( ruleCoin )
            {
            // InternalSM2.g:5762:2: ( ruleCoin )
            // InternalSM2.g:5763:3: ruleCoin
            {
             before(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleCoin();

            state._fsp--;

             after(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__TypeCoinAssignment_5"


    // $ANTLR start "rule__Clause__NameFunctionAssignment_1"
    // InternalSM2.g:5772:1: rule__Clause__NameFunctionAssignment_1 : ( RULE_ID ) ;
    public final void rule__Clause__NameFunctionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5776:1: ( ( RULE_ID ) )
            // InternalSM2.g:5777:2: ( RULE_ID )
            {
            // InternalSM2.g:5777:2: ( RULE_ID )
            // InternalSM2.g:5778:3: RULE_ID
            {
             before(grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__NameFunctionAssignment_1"


    // $ANTLR start "rule__Clause__InputParamsAssignment_3"
    // InternalSM2.g:5787:1: rule__Clause__InputParamsAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__Clause__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5791:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:5792:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:5792:2: ( ( RULE_ID ) )
            // InternalSM2.g:5793:3: ( RULE_ID )
            {
             before(grammarAccess.getClauseAccess().getInputParamsInputParamCrossReference_3_0()); 
            // InternalSM2.g:5794:3: ( RULE_ID )
            // InternalSM2.g:5795:4: RULE_ID
            {
             before(grammarAccess.getClauseAccess().getInputParamsInputParamIDTerminalRuleCall_3_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getInputParamsInputParamIDTerminalRuleCall_3_0_1()); 

            }

             after(grammarAccess.getClauseAccess().getInputParamsInputParamCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__InputParamsAssignment_3"


    // $ANTLR start "rule__Clause__VisibilityAccessAssignment_4"
    // InternalSM2.g:5806:1: rule__Clause__VisibilityAccessAssignment_4 : ( ruleVisibility ) ;
    public final void rule__Clause__VisibilityAccessAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5810:1: ( ( ruleVisibility ) )
            // InternalSM2.g:5811:2: ( ruleVisibility )
            {
            // InternalSM2.g:5811:2: ( ruleVisibility )
            // InternalSM2.g:5812:3: ruleVisibility
            {
             before(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__VisibilityAccessAssignment_4"


    // $ANTLR start "rule__Clause__ModifierAssignment_5"
    // InternalSM2.g:5821:1: rule__Clause__ModifierAssignment_5 : ( ( RULE_ID ) ) ;
    public final void rule__Clause__ModifierAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5825:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:5826:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:5826:2: ( ( RULE_ID ) )
            // InternalSM2.g:5827:3: ( RULE_ID )
            {
             before(grammarAccess.getClauseAccess().getModifierModifierCrossReference_5_0()); 
            // InternalSM2.g:5828:3: ( RULE_ID )
            // InternalSM2.g:5829:4: RULE_ID
            {
             before(grammarAccess.getClauseAccess().getModifierModifierIDTerminalRuleCall_5_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getModifierModifierIDTerminalRuleCall_5_0_1()); 

            }

             after(grammarAccess.getClauseAccess().getModifierModifierCrossReference_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__ModifierAssignment_5"


    // $ANTLR start "rule__Clause__RestrictionAssignment_9"
    // InternalSM2.g:5840:1: rule__Clause__RestrictionAssignment_9 : ( ruleRestriction ) ;
    public final void rule__Clause__RestrictionAssignment_9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5844:1: ( ( ruleRestriction ) )
            // InternalSM2.g:5845:2: ( ruleRestriction )
            {
            // InternalSM2.g:5845:2: ( ruleRestriction )
            // InternalSM2.g:5846:3: ruleRestriction
            {
             before(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_9_0()); 
            pushFollow(FOLLOW_2);
            ruleRestriction();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__RestrictionAssignment_9"


    // $ANTLR start "rule__Clause__RestrictionGasAssignment_10"
    // InternalSM2.g:5855:1: rule__Clause__RestrictionGasAssignment_10 : ( ruleRestrictionGas ) ;
    public final void rule__Clause__RestrictionGasAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5859:1: ( ( ruleRestrictionGas ) )
            // InternalSM2.g:5860:2: ( ruleRestrictionGas )
            {
            // InternalSM2.g:5860:2: ( ruleRestrictionGas )
            // InternalSM2.g:5861:3: ruleRestrictionGas
            {
             before(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_10_0()); 
            pushFollow(FOLLOW_2);
            ruleRestrictionGas();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__RestrictionGasAssignment_10"


    // $ANTLR start "rule__Clause__ExpressionAssignment_11"
    // InternalSM2.g:5870:1: rule__Clause__ExpressionAssignment_11 : ( ruleExpression ) ;
    public final void rule__Clause__ExpressionAssignment_11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5874:1: ( ( ruleExpression ) )
            // InternalSM2.g:5875:2: ( ruleExpression )
            {
            // InternalSM2.g:5875:2: ( ruleExpression )
            // InternalSM2.g:5876:3: ruleExpression
            {
             before(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_11_0()); 
            pushFollow(FOLLOW_2);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__ExpressionAssignment_11"


    // $ANTLR start "rule__ArithmethicalExpression__Op1Assignment_0_1"
    // InternalSM2.g:5885:1: rule__ArithmethicalExpression__Op1Assignment_0_1 : ( RULE_INT ) ;
    public final void rule__ArithmethicalExpression__Op1Assignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5889:1: ( ( RULE_INT ) )
            // InternalSM2.g:5890:2: ( RULE_INT )
            {
            // InternalSM2.g:5890:2: ( RULE_INT )
            // InternalSM2.g:5891:3: RULE_INT
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_0_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op1Assignment_0_1"


    // $ANTLR start "rule__ArithmethicalExpression__OperatorAssignment_0_2"
    // InternalSM2.g:5900:1: rule__ArithmethicalExpression__OperatorAssignment_0_2 : ( ruleArithmeticalOperator ) ;
    public final void rule__ArithmethicalExpression__OperatorAssignment_0_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5904:1: ( ( ruleArithmeticalOperator ) )
            // InternalSM2.g:5905:2: ( ruleArithmeticalOperator )
            {
            // InternalSM2.g:5905:2: ( ruleArithmeticalOperator )
            // InternalSM2.g:5906:3: ruleArithmeticalOperator
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0()); 
            pushFollow(FOLLOW_2);
            ruleArithmeticalOperator();

            state._fsp--;

             after(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__OperatorAssignment_0_2"


    // $ANTLR start "rule__ArithmethicalExpression__Op2Assignment_0_3"
    // InternalSM2.g:5915:1: rule__ArithmethicalExpression__Op2Assignment_0_3 : ( RULE_INT ) ;
    public final void rule__ArithmethicalExpression__Op2Assignment_0_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5919:1: ( ( RULE_INT ) )
            // InternalSM2.g:5920:2: ( RULE_INT )
            {
            // InternalSM2.g:5920:2: ( RULE_INT )
            // InternalSM2.g:5921:3: RULE_INT
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_0_3_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_0_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op2Assignment_0_3"


    // $ANTLR start "rule__ArithmethicalExpression__Op1Assignment_1_0"
    // InternalSM2.g:5930:1: rule__ArithmethicalExpression__Op1Assignment_1_0 : ( RULE_INT ) ;
    public final void rule__ArithmethicalExpression__Op1Assignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5934:1: ( ( RULE_INT ) )
            // InternalSM2.g:5935:2: ( RULE_INT )
            {
            // InternalSM2.g:5935:2: ( RULE_INT )
            // InternalSM2.g:5936:3: RULE_INT
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_1_0_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op1Assignment_1_0"


    // $ANTLR start "rule__ArithmethicalExpression__OperatorAssignment_1_1"
    // InternalSM2.g:5945:1: rule__ArithmethicalExpression__OperatorAssignment_1_1 : ( ruleArithmeticalOperator ) ;
    public final void rule__ArithmethicalExpression__OperatorAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5949:1: ( ( ruleArithmeticalOperator ) )
            // InternalSM2.g:5950:2: ( ruleArithmeticalOperator )
            {
            // InternalSM2.g:5950:2: ( ruleArithmeticalOperator )
            // InternalSM2.g:5951:3: ruleArithmeticalOperator
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0()); 
            pushFollow(FOLLOW_2);
            ruleArithmeticalOperator();

            state._fsp--;

             after(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__OperatorAssignment_1_1"


    // $ANTLR start "rule__ArithmethicalExpression__Op2Assignment_1_2"
    // InternalSM2.g:5960:1: rule__ArithmethicalExpression__Op2Assignment_1_2 : ( RULE_INT ) ;
    public final void rule__ArithmethicalExpression__Op2Assignment_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5964:1: ( ( RULE_INT ) )
            // InternalSM2.g:5965:2: ( RULE_INT )
            {
            // InternalSM2.g:5965:2: ( RULE_INT )
            // InternalSM2.g:5966:3: RULE_INT
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_1_2_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op2Assignment_1_2"


    // $ANTLR start "rule__SyntaxExpression__TextAssignment_0"
    // InternalSM2.g:5975:1: rule__SyntaxExpression__TextAssignment_0 : ( RULE_STRING ) ;
    public final void rule__SyntaxExpression__TextAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5979:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5980:2: ( RULE_STRING )
            {
            // InternalSM2.g:5980:2: ( RULE_STRING )
            // InternalSM2.g:5981:3: RULE_STRING
            {
             before(grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__TextAssignment_0"


    // $ANTLR start "rule__ShortComment__ExprAssignment_1"
    // InternalSM2.g:5990:1: rule__ShortComment__ExprAssignment_1 : ( RULE_STRING ) ;
    public final void rule__ShortComment__ExprAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5994:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5995:2: ( RULE_STRING )
            {
            // InternalSM2.g:5995:2: ( RULE_STRING )
            // InternalSM2.g:5996:3: RULE_STRING
            {
             before(grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__ExprAssignment_1"


    // $ANTLR start "rule__LongComment__ExprAssignment_1"
    // InternalSM2.g:6005:1: rule__LongComment__ExprAssignment_1 : ( RULE_STRING ) ;
    public final void rule__LongComment__ExprAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6009:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6010:2: ( RULE_STRING )
            {
            // InternalSM2.g:6010:2: ( RULE_STRING )
            // InternalSM2.g:6011:3: RULE_STRING
            {
             before(grammarAccess.getLongCommentAccess().getExprSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getLongCommentAccess().getExprSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__ExprAssignment_1"

    // Delegated rules


    protected DFA44 dfa44 = new DFA44(this);
    static final String dfa_1s = "\20\uffff";
    static final String dfa_2s = "\1\5\1\12\1\uffff\1\5\1\24\1\6\6\5\1\7\1\uffff\1\6\1\24";
    static final String dfa_3s = "\1\77\1\12\1\uffff\1\16\2\53\6\16\1\7\1\uffff\1\47\1\53";
    static final String dfa_4s = "\2\uffff\1\2\12\uffff\1\1\2\uffff";
    static final String dfa_5s = "\20\uffff}>";
    static final String[] dfa_6s = {
            "\1\2\1\uffff\1\2\1\uffff\2\2\3\uffff\1\2\60\uffff\1\1",
            "\1\3",
            "",
            "\1\5\10\uffff\1\4",
            "\1\6\1\10\22\uffff\1\7\1\11\1\12\1\13",
            "\1\14\15\uffff\1\6\1\10\22\uffff\1\7\1\11\1\12\1\13",
            "\1\16\10\uffff\1\15",
            "\1\16\10\uffff\1\15",
            "\1\16\10\uffff\1\15",
            "\1\16\10\uffff\1\15",
            "\1\16\10\uffff\1\15",
            "\1\16\10\uffff\1\15",
            "\1\17",
            "",
            "\1\15\4\uffff\1\15\26\uffff\6\2",
            "\1\6\1\10\22\uffff\1\7\1\11\1\12\1\13"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA44 extends DFA {

        public DFA44(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 44;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "4255:2: ( rule__Clause__RestrictionAssignment_9 )?";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000380000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0020000000000080L,0x0000000000000040L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0020000000000002L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0008000000000100L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x358000007FC00290L,0x000000000000000DL});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x340000007FC00012L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0080000000000002L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0100000000000002L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000001L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000002L,0x000000000000000CL});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0040000000000040L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x000000007FC00800L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x000000007FC00002L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000004080L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0200000000000080L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x000000007FC00000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0800000000000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000380000010L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x000000007FC00080L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000000001200L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000004060L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000000004020L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x00000F0000300000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x000000FC00000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000380000000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000000000810L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x80000000000046A0L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0003C00000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});

}