package org.xtext.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_PARAMSLONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_NOTICELONGCOMENT", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_OPENKEY", "RULE_CLOSEKEY", "RULE_DOT", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_COMMA", "RULE_NUMBER", "RULE_EMAIL", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'>'", "'>='", "'<'", "'<='", "'int'", "'uint'", "'uint8'", "'uint256'", "'string'", "'address'", "'address payable'", "'double'", "'bool'", "'public'", "'private'", "'internal'", "'external'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'=='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'", "'solidity'", "'is'", "'import'", "'as'", "'event'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'enum'", "'='", "'require'", "'function'", "'//'", "'/*'", "'*/'", "'pragma'", "'contract'", "'^'"
    };
    public static final int T__50=50;
    public static final int RULE_OPENPARENTHESIS=17;
    public static final int RULE_EOLINE=13;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int RULE_CLOSEKEY=15;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_PARAMSLONGCOMENT=7;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int RULE_COMMA=19;
    public static final int RULE_RETURNSLONGCOMENT=9;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=5;
    public static final int T__29=29;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=22;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int RULE_SEMICOLON=12;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_TITLELONGCOMENT=10;
    public static final int RULE_STRING=6;
    public static final int RULE_NOTICELONGCOMENT=11;
    public static final int RULE_EMAIL=21;
    public static final int RULE_SL_COMMENT=23;
    public static final int T__37=37;
    public static final int RULE_OPENKEY=14;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int RULE_CLOSEPARENTHESIS=18;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__73=73;
    public static final int RULE_DOT=16;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__74=74;
    public static final int T__31=31;
    public static final int T__75=75;
    public static final int T__32=32;
    public static final int T__76=76;
    public static final int RULE_WS=24;
    public static final int RULE_ANY_OTHER=25;
    public static final int RULE_NUMBER=20;
    public static final int RULE_DEVLONGCOMENT=8;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }


    	private SM2GrammarAccess grammarAccess;

    	public void setGrammarAccess(SM2GrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleSmartContract"
    // InternalSM2.g:53:1: entryRuleSmartContract : ruleSmartContract EOF ;
    public final void entryRuleSmartContract() throws RecognitionException {
        try {
            // InternalSM2.g:54:1: ( ruleSmartContract EOF )
            // InternalSM2.g:55:1: ruleSmartContract EOF
            {
             before(grammarAccess.getSmartContractRule()); 
            pushFollow(FOLLOW_1);
            ruleSmartContract();

            state._fsp--;

             after(grammarAccess.getSmartContractRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSmartContract"


    // $ANTLR start "ruleSmartContract"
    // InternalSM2.g:62:1: ruleSmartContract : ( ( rule__SmartContract__Group__0 ) ) ;
    public final void ruleSmartContract() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:66:2: ( ( ( rule__SmartContract__Group__0 ) ) )
            // InternalSM2.g:67:2: ( ( rule__SmartContract__Group__0 ) )
            {
            // InternalSM2.g:67:2: ( ( rule__SmartContract__Group__0 ) )
            // InternalSM2.g:68:3: ( rule__SmartContract__Group__0 )
            {
             before(grammarAccess.getSmartContractAccess().getGroup()); 
            // InternalSM2.g:69:3: ( rule__SmartContract__Group__0 )
            // InternalSM2.g:69:4: rule__SmartContract__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSmartContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:78:1: entryRuleVersion : ruleVersion EOF ;
    public final void entryRuleVersion() throws RecognitionException {
        try {
            // InternalSM2.g:79:1: ( ruleVersion EOF )
            // InternalSM2.g:80:1: ruleVersion EOF
            {
             before(grammarAccess.getVersionRule()); 
            pushFollow(FOLLOW_1);
            ruleVersion();

            state._fsp--;

             after(grammarAccess.getVersionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:87:1: ruleVersion : ( ( rule__Version__Alternatives ) ) ;
    public final void ruleVersion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:91:2: ( ( ( rule__Version__Alternatives ) ) )
            // InternalSM2.g:92:2: ( ( rule__Version__Alternatives ) )
            {
            // InternalSM2.g:92:2: ( ( rule__Version__Alternatives ) )
            // InternalSM2.g:93:3: ( rule__Version__Alternatives )
            {
             before(grammarAccess.getVersionAccess().getAlternatives()); 
            // InternalSM2.g:94:3: ( rule__Version__Alternatives )
            // InternalSM2.g:94:4: rule__Version__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Version__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleImport"
    // InternalSM2.g:103:1: entryRuleImport : ruleImport EOF ;
    public final void entryRuleImport() throws RecognitionException {
        try {
            // InternalSM2.g:104:1: ( ruleImport EOF )
            // InternalSM2.g:105:1: ruleImport EOF
            {
             before(grammarAccess.getImportRule()); 
            pushFollow(FOLLOW_1);
            ruleImport();

            state._fsp--;

             after(grammarAccess.getImportRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2.g:112:1: ruleImport : ( ( rule__Import__Group__0 ) ) ;
    public final void ruleImport() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:116:2: ( ( ( rule__Import__Group__0 ) ) )
            // InternalSM2.g:117:2: ( ( rule__Import__Group__0 ) )
            {
            // InternalSM2.g:117:2: ( ( rule__Import__Group__0 ) )
            // InternalSM2.g:118:3: ( rule__Import__Group__0 )
            {
             before(grammarAccess.getImportAccess().getGroup()); 
            // InternalSM2.g:119:3: ( rule__Import__Group__0 )
            // InternalSM2.g:119:4: rule__Import__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getImportAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:128:1: entryRuleAttributes : ruleAttributes EOF ;
    public final void entryRuleAttributes() throws RecognitionException {
        try {
            // InternalSM2.g:129:1: ( ruleAttributes EOF )
            // InternalSM2.g:130:1: ruleAttributes EOF
            {
             before(grammarAccess.getAttributesRule()); 
            pushFollow(FOLLOW_1);
            ruleAttributes();

            state._fsp--;

             after(grammarAccess.getAttributesRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:137:1: ruleAttributes : ( ( rule__Attributes__Alternatives ) ) ;
    public final void ruleAttributes() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:141:2: ( ( ( rule__Attributes__Alternatives ) ) )
            // InternalSM2.g:142:2: ( ( rule__Attributes__Alternatives ) )
            {
            // InternalSM2.g:142:2: ( ( rule__Attributes__Alternatives ) )
            // InternalSM2.g:143:3: ( rule__Attributes__Alternatives )
            {
             before(grammarAccess.getAttributesAccess().getAlternatives()); 
            // InternalSM2.g:144:3: ( rule__Attributes__Alternatives )
            // InternalSM2.g:144:4: rule__Attributes__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Attributes__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getAttributesAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleEvent"
    // InternalSM2.g:153:1: entryRuleEvent : ruleEvent EOF ;
    public final void entryRuleEvent() throws RecognitionException {
        try {
            // InternalSM2.g:154:1: ( ruleEvent EOF )
            // InternalSM2.g:155:1: ruleEvent EOF
            {
             before(grammarAccess.getEventRule()); 
            pushFollow(FOLLOW_1);
            ruleEvent();

            state._fsp--;

             after(grammarAccess.getEventRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalSM2.g:162:1: ruleEvent : ( ( rule__Event__Group__0 ) ) ;
    public final void ruleEvent() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:166:2: ( ( ( rule__Event__Group__0 ) ) )
            // InternalSM2.g:167:2: ( ( rule__Event__Group__0 ) )
            {
            // InternalSM2.g:167:2: ( ( rule__Event__Group__0 ) )
            // InternalSM2.g:168:3: ( rule__Event__Group__0 )
            {
             before(grammarAccess.getEventAccess().getGroup()); 
            // InternalSM2.g:169:3: ( rule__Event__Group__0 )
            // InternalSM2.g:169:4: rule__Event__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Event__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEventAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:178:1: entryRuleModifier : ruleModifier EOF ;
    public final void entryRuleModifier() throws RecognitionException {
        try {
            // InternalSM2.g:179:1: ( ruleModifier EOF )
            // InternalSM2.g:180:1: ruleModifier EOF
            {
             before(grammarAccess.getModifierRule()); 
            pushFollow(FOLLOW_1);
            ruleModifier();

            state._fsp--;

             after(grammarAccess.getModifierRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:187:1: ruleModifier : ( ( rule__Modifier__Group__0 ) ) ;
    public final void ruleModifier() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:191:2: ( ( ( rule__Modifier__Group__0 ) ) )
            // InternalSM2.g:192:2: ( ( rule__Modifier__Group__0 ) )
            {
            // InternalSM2.g:192:2: ( ( rule__Modifier__Group__0 ) )
            // InternalSM2.g:193:3: ( rule__Modifier__Group__0 )
            {
             before(grammarAccess.getModifierAccess().getGroup()); 
            // InternalSM2.g:194:3: ( rule__Modifier__Group__0 )
            // InternalSM2.g:194:4: rule__Modifier__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getModifierAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:203:1: entryRuleDataType : ruleDataType EOF ;
    public final void entryRuleDataType() throws RecognitionException {
        try {
            // InternalSM2.g:204:1: ( ruleDataType EOF )
            // InternalSM2.g:205:1: ruleDataType EOF
            {
             before(grammarAccess.getDataTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleDataType();

            state._fsp--;

             after(grammarAccess.getDataTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:212:1: ruleDataType : ( ( rule__DataType__Alternatives ) ) ;
    public final void ruleDataType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:216:2: ( ( ( rule__DataType__Alternatives ) ) )
            // InternalSM2.g:217:2: ( ( rule__DataType__Alternatives ) )
            {
            // InternalSM2.g:217:2: ( ( rule__DataType__Alternatives ) )
            // InternalSM2.g:218:3: ( rule__DataType__Alternatives )
            {
             before(grammarAccess.getDataTypeAccess().getAlternatives()); 
            // InternalSM2.g:219:3: ( rule__DataType__Alternatives )
            // InternalSM2.g:219:4: rule__DataType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__DataType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getDataTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2.g:228:1: entryRuleCompositeType : ruleCompositeType EOF ;
    public final void entryRuleCompositeType() throws RecognitionException {
        try {
            // InternalSM2.g:229:1: ( ruleCompositeType EOF )
            // InternalSM2.g:230:1: ruleCompositeType EOF
            {
             before(grammarAccess.getCompositeTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleCompositeType();

            state._fsp--;

             after(grammarAccess.getCompositeTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2.g:237:1: ruleCompositeType : ( ( rule__CompositeType__Alternatives ) ) ;
    public final void ruleCompositeType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:241:2: ( ( ( rule__CompositeType__Alternatives ) ) )
            // InternalSM2.g:242:2: ( ( rule__CompositeType__Alternatives ) )
            {
            // InternalSM2.g:242:2: ( ( rule__CompositeType__Alternatives ) )
            // InternalSM2.g:243:3: ( rule__CompositeType__Alternatives )
            {
             before(grammarAccess.getCompositeTypeAccess().getAlternatives()); 
            // InternalSM2.g:244:3: ( rule__CompositeType__Alternatives )
            // InternalSM2.g:244:4: rule__CompositeType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__CompositeType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCompositeTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:253:1: entryRuleMapping : ruleMapping EOF ;
    public final void entryRuleMapping() throws RecognitionException {
        try {
            // InternalSM2.g:254:1: ( ruleMapping EOF )
            // InternalSM2.g:255:1: ruleMapping EOF
            {
             before(grammarAccess.getMappingRule()); 
            pushFollow(FOLLOW_1);
            ruleMapping();

            state._fsp--;

             after(grammarAccess.getMappingRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:262:1: ruleMapping : ( ( rule__Mapping__Group__0 ) ) ;
    public final void ruleMapping() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:266:2: ( ( ( rule__Mapping__Group__0 ) ) )
            // InternalSM2.g:267:2: ( ( rule__Mapping__Group__0 ) )
            {
            // InternalSM2.g:267:2: ( ( rule__Mapping__Group__0 ) )
            // InternalSM2.g:268:3: ( rule__Mapping__Group__0 )
            {
             before(grammarAccess.getMappingAccess().getGroup()); 
            // InternalSM2.g:269:3: ( rule__Mapping__Group__0 )
            // InternalSM2.g:269:4: rule__Mapping__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:278:1: entryRuleStruct : ruleStruct EOF ;
    public final void entryRuleStruct() throws RecognitionException {
        try {
            // InternalSM2.g:279:1: ( ruleStruct EOF )
            // InternalSM2.g:280:1: ruleStruct EOF
            {
             before(grammarAccess.getStructRule()); 
            pushFollow(FOLLOW_1);
            ruleStruct();

            state._fsp--;

             after(grammarAccess.getStructRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:287:1: ruleStruct : ( ( rule__Struct__Alternatives ) ) ;
    public final void ruleStruct() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:291:2: ( ( ( rule__Struct__Alternatives ) ) )
            // InternalSM2.g:292:2: ( ( rule__Struct__Alternatives ) )
            {
            // InternalSM2.g:292:2: ( ( rule__Struct__Alternatives ) )
            // InternalSM2.g:293:3: ( rule__Struct__Alternatives )
            {
             before(grammarAccess.getStructAccess().getAlternatives()); 
            // InternalSM2.g:294:3: ( rule__Struct__Alternatives )
            // InternalSM2.g:294:4: rule__Struct__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Struct__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getStructAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRulePersonalizedStruct"
    // InternalSM2.g:303:1: entryRulePersonalizedStruct : rulePersonalizedStruct EOF ;
    public final void entryRulePersonalizedStruct() throws RecognitionException {
        try {
            // InternalSM2.g:304:1: ( rulePersonalizedStruct EOF )
            // InternalSM2.g:305:1: rulePersonalizedStruct EOF
            {
             before(grammarAccess.getPersonalizedStructRule()); 
            pushFollow(FOLLOW_1);
            rulePersonalizedStruct();

            state._fsp--;

             after(grammarAccess.getPersonalizedStructRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePersonalizedStruct"


    // $ANTLR start "rulePersonalizedStruct"
    // InternalSM2.g:312:1: rulePersonalizedStruct : ( ( rule__PersonalizedStruct__Group__0 ) ) ;
    public final void rulePersonalizedStruct() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:316:2: ( ( ( rule__PersonalizedStruct__Group__0 ) ) )
            // InternalSM2.g:317:2: ( ( rule__PersonalizedStruct__Group__0 ) )
            {
            // InternalSM2.g:317:2: ( ( rule__PersonalizedStruct__Group__0 ) )
            // InternalSM2.g:318:3: ( rule__PersonalizedStruct__Group__0 )
            {
             before(grammarAccess.getPersonalizedStructAccess().getGroup()); 
            // InternalSM2.g:319:3: ( rule__PersonalizedStruct__Group__0 )
            // InternalSM2.g:319:4: rule__PersonalizedStruct__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPersonalizedStructAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePersonalizedStruct"


    // $ANTLR start "entryRuleUser"
    // InternalSM2.g:328:1: entryRuleUser : ruleUser EOF ;
    public final void entryRuleUser() throws RecognitionException {
        try {
            // InternalSM2.g:329:1: ( ruleUser EOF )
            // InternalSM2.g:330:1: ruleUser EOF
            {
             before(grammarAccess.getUserRule()); 
            pushFollow(FOLLOW_1);
            ruleUser();

            state._fsp--;

             after(grammarAccess.getUserRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUser"


    // $ANTLR start "ruleUser"
    // InternalSM2.g:337:1: ruleUser : ( ( rule__User__Group__0 ) ) ;
    public final void ruleUser() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:341:2: ( ( ( rule__User__Group__0 ) ) )
            // InternalSM2.g:342:2: ( ( rule__User__Group__0 ) )
            {
            // InternalSM2.g:342:2: ( ( rule__User__Group__0 ) )
            // InternalSM2.g:343:3: ( rule__User__Group__0 )
            {
             before(grammarAccess.getUserAccess().getGroup()); 
            // InternalSM2.g:344:3: ( rule__User__Group__0 )
            // InternalSM2.g:344:4: rule__User__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__User__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getUserAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUser"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:353:1: entryRuleEnum : ruleEnum EOF ;
    public final void entryRuleEnum() throws RecognitionException {
        try {
            // InternalSM2.g:354:1: ( ruleEnum EOF )
            // InternalSM2.g:355:1: ruleEnum EOF
            {
             before(grammarAccess.getEnumRule()); 
            pushFollow(FOLLOW_1);
            ruleEnum();

            state._fsp--;

             after(grammarAccess.getEnumRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:362:1: ruleEnum : ( ( rule__Enum__Group__0 ) ) ;
    public final void ruleEnum() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:366:2: ( ( ( rule__Enum__Group__0 ) ) )
            // InternalSM2.g:367:2: ( ( rule__Enum__Group__0 ) )
            {
            // InternalSM2.g:367:2: ( ( rule__Enum__Group__0 ) )
            // InternalSM2.g:368:3: ( rule__Enum__Group__0 )
            {
             before(grammarAccess.getEnumAccess().getGroup()); 
            // InternalSM2.g:369:3: ( rule__Enum__Group__0 )
            // InternalSM2.g:369:4: rule__Enum__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Enum__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEnumAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:378:1: entryRuleProperty : ruleProperty EOF ;
    public final void entryRuleProperty() throws RecognitionException {
        try {
            // InternalSM2.g:379:1: ( ruleProperty EOF )
            // InternalSM2.g:380:1: ruleProperty EOF
            {
             before(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_1);
            ruleProperty();

            state._fsp--;

             after(grammarAccess.getPropertyRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:387:1: ruleProperty : ( ( rule__Property__Group__0 ) ) ;
    public final void ruleProperty() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:391:2: ( ( ( rule__Property__Group__0 ) ) )
            // InternalSM2.g:392:2: ( ( rule__Property__Group__0 ) )
            {
            // InternalSM2.g:392:2: ( ( rule__Property__Group__0 ) )
            // InternalSM2.g:393:3: ( rule__Property__Group__0 )
            {
             before(grammarAccess.getPropertyAccess().getGroup()); 
            // InternalSM2.g:394:3: ( rule__Property__Group__0 )
            // InternalSM2.g:394:4: rule__Property__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Property__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPropertyAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:403:1: entryRuleInputParam : ruleInputParam EOF ;
    public final void entryRuleInputParam() throws RecognitionException {
        try {
            // InternalSM2.g:404:1: ( ruleInputParam EOF )
            // InternalSM2.g:405:1: ruleInputParam EOF
            {
             before(grammarAccess.getInputParamRule()); 
            pushFollow(FOLLOW_1);
            ruleInputParam();

            state._fsp--;

             after(grammarAccess.getInputParamRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:412:1: ruleInputParam : ( ( rule__InputParam__Group__0 ) ) ;
    public final void ruleInputParam() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:416:2: ( ( ( rule__InputParam__Group__0 ) ) )
            // InternalSM2.g:417:2: ( ( rule__InputParam__Group__0 ) )
            {
            // InternalSM2.g:417:2: ( ( rule__InputParam__Group__0 ) )
            // InternalSM2.g:418:3: ( rule__InputParam__Group__0 )
            {
             before(grammarAccess.getInputParamAccess().getGroup()); 
            // InternalSM2.g:419:3: ( rule__InputParam__Group__0 )
            // InternalSM2.g:419:4: rule__InputParam__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getInputParamAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:428:1: entryRuleRestriction : ruleRestriction EOF ;
    public final void entryRuleRestriction() throws RecognitionException {
        try {
            // InternalSM2.g:429:1: ( ruleRestriction EOF )
            // InternalSM2.g:430:1: ruleRestriction EOF
            {
             before(grammarAccess.getRestrictionRule()); 
            pushFollow(FOLLOW_1);
            ruleRestriction();

            state._fsp--;

             after(grammarAccess.getRestrictionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:437:1: ruleRestriction : ( ( rule__Restriction__Group__0 ) ) ;
    public final void ruleRestriction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:441:2: ( ( ( rule__Restriction__Group__0 ) ) )
            // InternalSM2.g:442:2: ( ( rule__Restriction__Group__0 ) )
            {
            // InternalSM2.g:442:2: ( ( rule__Restriction__Group__0 ) )
            // InternalSM2.g:443:3: ( rule__Restriction__Group__0 )
            {
             before(grammarAccess.getRestrictionAccess().getGroup()); 
            // InternalSM2.g:444:3: ( rule__Restriction__Group__0 )
            // InternalSM2.g:444:4: rule__Restriction__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:453:1: entryRuleRestrictionGas : ruleRestrictionGas EOF ;
    public final void entryRuleRestrictionGas() throws RecognitionException {
        try {
            // InternalSM2.g:454:1: ( ruleRestrictionGas EOF )
            // InternalSM2.g:455:1: ruleRestrictionGas EOF
            {
             before(grammarAccess.getRestrictionGasRule()); 
            pushFollow(FOLLOW_1);
            ruleRestrictionGas();

            state._fsp--;

             after(grammarAccess.getRestrictionGasRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:462:1: ruleRestrictionGas : ( ( rule__RestrictionGas__Group__0 ) ) ;
    public final void ruleRestrictionGas() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:466:2: ( ( ( rule__RestrictionGas__Group__0 ) ) )
            // InternalSM2.g:467:2: ( ( rule__RestrictionGas__Group__0 ) )
            {
            // InternalSM2.g:467:2: ( ( rule__RestrictionGas__Group__0 ) )
            // InternalSM2.g:468:3: ( rule__RestrictionGas__Group__0 )
            {
             before(grammarAccess.getRestrictionGasAccess().getGroup()); 
            // InternalSM2.g:469:3: ( rule__RestrictionGas__Group__0 )
            // InternalSM2.g:469:4: rule__RestrictionGas__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2.g:478:1: entryRuleClause : ruleClause EOF ;
    public final void entryRuleClause() throws RecognitionException {
        try {
            // InternalSM2.g:479:1: ( ruleClause EOF )
            // InternalSM2.g:480:1: ruleClause EOF
            {
             before(grammarAccess.getClauseRule()); 
            pushFollow(FOLLOW_1);
            ruleClause();

            state._fsp--;

             after(grammarAccess.getClauseRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2.g:487:1: ruleClause : ( ( rule__Clause__Group__0 ) ) ;
    public final void ruleClause() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:491:2: ( ( ( rule__Clause__Group__0 ) ) )
            // InternalSM2.g:492:2: ( ( rule__Clause__Group__0 ) )
            {
            // InternalSM2.g:492:2: ( ( rule__Clause__Group__0 ) )
            // InternalSM2.g:493:3: ( rule__Clause__Group__0 )
            {
             before(grammarAccess.getClauseAccess().getGroup()); 
            // InternalSM2.g:494:3: ( rule__Clause__Group__0 )
            // InternalSM2.g:494:4: rule__Clause__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Clause__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:503:1: entryRuleExpression : ruleExpression EOF ;
    public final void entryRuleExpression() throws RecognitionException {
        try {
            // InternalSM2.g:504:1: ( ruleExpression EOF )
            // InternalSM2.g:505:1: ruleExpression EOF
            {
             before(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:512:1: ruleExpression : ( ( rule__Expression__Alternatives ) ) ;
    public final void ruleExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:516:2: ( ( ( rule__Expression__Alternatives ) ) )
            // InternalSM2.g:517:2: ( ( rule__Expression__Alternatives ) )
            {
            // InternalSM2.g:517:2: ( ( rule__Expression__Alternatives ) )
            // InternalSM2.g:518:3: ( rule__Expression__Alternatives )
            {
             before(grammarAccess.getExpressionAccess().getAlternatives()); 
            // InternalSM2.g:519:3: ( rule__Expression__Alternatives )
            // InternalSM2.g:519:4: rule__Expression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Expression__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getExpressionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleArithmethicalExpression"
    // InternalSM2.g:528:1: entryRuleArithmethicalExpression : ruleArithmethicalExpression EOF ;
    public final void entryRuleArithmethicalExpression() throws RecognitionException {
        try {
            // InternalSM2.g:529:1: ( ruleArithmethicalExpression EOF )
            // InternalSM2.g:530:1: ruleArithmethicalExpression EOF
            {
             before(grammarAccess.getArithmethicalExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleArithmethicalExpression();

            state._fsp--;

             after(grammarAccess.getArithmethicalExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleArithmethicalExpression"


    // $ANTLR start "ruleArithmethicalExpression"
    // InternalSM2.g:537:1: ruleArithmethicalExpression : ( ( rule__ArithmethicalExpression__Alternatives ) ) ;
    public final void ruleArithmethicalExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:541:2: ( ( ( rule__ArithmethicalExpression__Alternatives ) ) )
            // InternalSM2.g:542:2: ( ( rule__ArithmethicalExpression__Alternatives ) )
            {
            // InternalSM2.g:542:2: ( ( rule__ArithmethicalExpression__Alternatives ) )
            // InternalSM2.g:543:3: ( rule__ArithmethicalExpression__Alternatives )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getAlternatives()); 
            // InternalSM2.g:544:3: ( rule__ArithmethicalExpression__Alternatives )
            // InternalSM2.g:544:4: rule__ArithmethicalExpression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleArithmethicalExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:553:1: entryRuleSyntaxExpression : ruleSyntaxExpression EOF ;
    public final void entryRuleSyntaxExpression() throws RecognitionException {
        try {
            // InternalSM2.g:554:1: ( ruleSyntaxExpression EOF )
            // InternalSM2.g:555:1: ruleSyntaxExpression EOF
            {
             before(grammarAccess.getSyntaxExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getSyntaxExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:562:1: ruleSyntaxExpression : ( ( rule__SyntaxExpression__Alternatives ) ) ;
    public final void ruleSyntaxExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:566:2: ( ( ( rule__SyntaxExpression__Alternatives ) ) )
            // InternalSM2.g:567:2: ( ( rule__SyntaxExpression__Alternatives ) )
            {
            // InternalSM2.g:567:2: ( ( rule__SyntaxExpression__Alternatives ) )
            // InternalSM2.g:568:3: ( rule__SyntaxExpression__Alternatives )
            {
             before(grammarAccess.getSyntaxExpressionAccess().getAlternatives()); 
            // InternalSM2.g:569:3: ( rule__SyntaxExpression__Alternatives )
            // InternalSM2.g:569:4: rule__SyntaxExpression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getSyntaxExpressionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:578:1: entryRuleComment : ruleComment EOF ;
    public final void entryRuleComment() throws RecognitionException {
        try {
            // InternalSM2.g:579:1: ( ruleComment EOF )
            // InternalSM2.g:580:1: ruleComment EOF
            {
             before(grammarAccess.getCommentRule()); 
            pushFollow(FOLLOW_1);
            ruleComment();

            state._fsp--;

             after(grammarAccess.getCommentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:587:1: ruleComment : ( ( rule__Comment__Alternatives ) ) ;
    public final void ruleComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:591:2: ( ( ( rule__Comment__Alternatives ) ) )
            // InternalSM2.g:592:2: ( ( rule__Comment__Alternatives ) )
            {
            // InternalSM2.g:592:2: ( ( rule__Comment__Alternatives ) )
            // InternalSM2.g:593:3: ( rule__Comment__Alternatives )
            {
             before(grammarAccess.getCommentAccess().getAlternatives()); 
            // InternalSM2.g:594:3: ( rule__Comment__Alternatives )
            // InternalSM2.g:594:4: rule__Comment__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Comment__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCommentAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:603:1: entryRuleShortComment : ruleShortComment EOF ;
    public final void entryRuleShortComment() throws RecognitionException {
        try {
            // InternalSM2.g:604:1: ( ruleShortComment EOF )
            // InternalSM2.g:605:1: ruleShortComment EOF
            {
             before(grammarAccess.getShortCommentRule()); 
            pushFollow(FOLLOW_1);
            ruleShortComment();

            state._fsp--;

             after(grammarAccess.getShortCommentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:612:1: ruleShortComment : ( ( rule__ShortComment__Group__0 ) ) ;
    public final void ruleShortComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:616:2: ( ( ( rule__ShortComment__Group__0 ) ) )
            // InternalSM2.g:617:2: ( ( rule__ShortComment__Group__0 ) )
            {
            // InternalSM2.g:617:2: ( ( rule__ShortComment__Group__0 ) )
            // InternalSM2.g:618:3: ( rule__ShortComment__Group__0 )
            {
             before(grammarAccess.getShortCommentAccess().getGroup()); 
            // InternalSM2.g:619:3: ( rule__ShortComment__Group__0 )
            // InternalSM2.g:619:4: rule__ShortComment__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getShortCommentAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:628:1: entryRuleLongComment : ruleLongComment EOF ;
    public final void entryRuleLongComment() throws RecognitionException {
        try {
            // InternalSM2.g:629:1: ( ruleLongComment EOF )
            // InternalSM2.g:630:1: ruleLongComment EOF
            {
             before(grammarAccess.getLongCommentRule()); 
            pushFollow(FOLLOW_1);
            ruleLongComment();

            state._fsp--;

             after(grammarAccess.getLongCommentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:637:1: ruleLongComment : ( ( rule__LongComment__Group__0 ) ) ;
    public final void ruleLongComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:641:2: ( ( ( rule__LongComment__Group__0 ) ) )
            // InternalSM2.g:642:2: ( ( rule__LongComment__Group__0 ) )
            {
            // InternalSM2.g:642:2: ( ( rule__LongComment__Group__0 ) )
            // InternalSM2.g:643:3: ( rule__LongComment__Group__0 )
            {
             before(grammarAccess.getLongCommentAccess().getGroup()); 
            // InternalSM2.g:644:3: ( rule__LongComment__Group__0 )
            // InternalSM2.g:644:4: rule__LongComment__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLongCommentAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "ruleSingularType"
    // InternalSM2.g:653:1: ruleSingularType : ( ( rule__SingularType__Alternatives ) ) ;
    public final void ruleSingularType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:657:1: ( ( ( rule__SingularType__Alternatives ) ) )
            // InternalSM2.g:658:2: ( ( rule__SingularType__Alternatives ) )
            {
            // InternalSM2.g:658:2: ( ( rule__SingularType__Alternatives ) )
            // InternalSM2.g:659:3: ( rule__SingularType__Alternatives )
            {
             before(grammarAccess.getSingularTypeAccess().getAlternatives()); 
            // InternalSM2.g:660:3: ( rule__SingularType__Alternatives )
            // InternalSM2.g:660:4: rule__SingularType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__SingularType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getSingularTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:669:1: ruleVisibility : ( ( rule__Visibility__Alternatives ) ) ;
    public final void ruleVisibility() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:673:1: ( ( ( rule__Visibility__Alternatives ) ) )
            // InternalSM2.g:674:2: ( ( rule__Visibility__Alternatives ) )
            {
            // InternalSM2.g:674:2: ( ( rule__Visibility__Alternatives ) )
            // InternalSM2.g:675:3: ( rule__Visibility__Alternatives )
            {
             before(grammarAccess.getVisibilityAccess().getAlternatives()); 
            // InternalSM2.g:676:3: ( rule__Visibility__Alternatives )
            // InternalSM2.g:676:4: rule__Visibility__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Visibility__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getVisibilityAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:685:1: ruleCoin : ( ( rule__Coin__Alternatives ) ) ;
    public final void ruleCoin() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:689:1: ( ( ( rule__Coin__Alternatives ) ) )
            // InternalSM2.g:690:2: ( ( rule__Coin__Alternatives ) )
            {
            // InternalSM2.g:690:2: ( ( rule__Coin__Alternatives ) )
            // InternalSM2.g:691:3: ( rule__Coin__Alternatives )
            {
             before(grammarAccess.getCoinAccess().getAlternatives()); 
            // InternalSM2.g:692:3: ( rule__Coin__Alternatives )
            // InternalSM2.g:692:4: rule__Coin__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Coin__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCoinAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:701:1: ruleComparationOperator : ( ( rule__ComparationOperator__Alternatives ) ) ;
    public final void ruleComparationOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:705:1: ( ( ( rule__ComparationOperator__Alternatives ) ) )
            // InternalSM2.g:706:2: ( ( rule__ComparationOperator__Alternatives ) )
            {
            // InternalSM2.g:706:2: ( ( rule__ComparationOperator__Alternatives ) )
            // InternalSM2.g:707:3: ( rule__ComparationOperator__Alternatives )
            {
             before(grammarAccess.getComparationOperatorAccess().getAlternatives()); 
            // InternalSM2.g:708:3: ( rule__ComparationOperator__Alternatives )
            // InternalSM2.g:708:4: rule__ComparationOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ComparationOperator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getComparationOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:717:1: ruleLogicalPairOperator : ( ( rule__LogicalPairOperator__Alternatives ) ) ;
    public final void ruleLogicalPairOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:721:1: ( ( ( rule__LogicalPairOperator__Alternatives ) ) )
            // InternalSM2.g:722:2: ( ( rule__LogicalPairOperator__Alternatives ) )
            {
            // InternalSM2.g:722:2: ( ( rule__LogicalPairOperator__Alternatives ) )
            // InternalSM2.g:723:3: ( rule__LogicalPairOperator__Alternatives )
            {
             before(grammarAccess.getLogicalPairOperatorAccess().getAlternatives()); 
            // InternalSM2.g:724:3: ( rule__LogicalPairOperator__Alternatives )
            // InternalSM2.g:724:4: rule__LogicalPairOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__LogicalPairOperator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getLogicalPairOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:733:1: ruleArithmeticalOperator : ( ( rule__ArithmeticalOperator__Alternatives ) ) ;
    public final void ruleArithmeticalOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:737:1: ( ( ( rule__ArithmeticalOperator__Alternatives ) ) )
            // InternalSM2.g:738:2: ( ( rule__ArithmeticalOperator__Alternatives ) )
            {
            // InternalSM2.g:738:2: ( ( rule__ArithmeticalOperator__Alternatives ) )
            // InternalSM2.g:739:3: ( rule__ArithmeticalOperator__Alternatives )
            {
             before(grammarAccess.getArithmeticalOperatorAccess().getAlternatives()); 
            // InternalSM2.g:740:3: ( rule__ArithmeticalOperator__Alternatives )
            // InternalSM2.g:740:4: rule__ArithmeticalOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ArithmeticalOperator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getArithmeticalOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleArithmeticalOperator"


    // $ANTLR start "rule__Version__Alternatives"
    // InternalSM2.g:748:1: rule__Version__Alternatives : ( ( ( rule__Version__Group_0__0 ) ) | ( ( rule__Version__Group_1__0 ) ) );
    public final void rule__Version__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:752:1: ( ( ( rule__Version__Group_0__0 ) ) | ( ( rule__Version__Group_1__0 ) ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==76) ) {
                alt1=1;
            }
            else if ( ((LA1_0>=26 && LA1_0<=27)) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalSM2.g:753:2: ( ( rule__Version__Group_0__0 ) )
                    {
                    // InternalSM2.g:753:2: ( ( rule__Version__Group_0__0 ) )
                    // InternalSM2.g:754:3: ( rule__Version__Group_0__0 )
                    {
                     before(grammarAccess.getVersionAccess().getGroup_0()); 
                    // InternalSM2.g:755:3: ( rule__Version__Group_0__0 )
                    // InternalSM2.g:755:4: rule__Version__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Version__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getVersionAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:759:2: ( ( rule__Version__Group_1__0 ) )
                    {
                    // InternalSM2.g:759:2: ( ( rule__Version__Group_1__0 ) )
                    // InternalSM2.g:760:3: ( rule__Version__Group_1__0 )
                    {
                     before(grammarAccess.getVersionAccess().getGroup_1()); 
                    // InternalSM2.g:761:3: ( rule__Version__Group_1__0 )
                    // InternalSM2.g:761:4: rule__Version__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Version__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getVersionAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Alternatives"


    // $ANTLR start "rule__Version__SymbolAlternatives_1_0_0"
    // InternalSM2.g:769:1: rule__Version__SymbolAlternatives_1_0_0 : ( ( '>' ) | ( '>=' ) );
    public final void rule__Version__SymbolAlternatives_1_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:773:1: ( ( '>' ) | ( '>=' ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==26) ) {
                alt2=1;
            }
            else if ( (LA2_0==27) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalSM2.g:774:2: ( '>' )
                    {
                    // InternalSM2.g:774:2: ( '>' )
                    // InternalSM2.g:775:3: '>'
                    {
                     before(grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_1_0_0_0()); 
                    match(input,26,FOLLOW_2); 
                     after(grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_1_0_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:780:2: ( '>=' )
                    {
                    // InternalSM2.g:780:2: ( '>=' )
                    // InternalSM2.g:781:3: '>='
                    {
                     before(grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_1_0_0_1()); 
                    match(input,27,FOLLOW_2); 
                     after(grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_1_0_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAlternatives_1_0_0"


    // $ANTLR start "rule__Version__Symbol2Alternatives_1_6_0_0"
    // InternalSM2.g:790:1: rule__Version__Symbol2Alternatives_1_6_0_0 : ( ( '<' ) | ( '<=' ) );
    public final void rule__Version__Symbol2Alternatives_1_6_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:794:1: ( ( '<' ) | ( '<=' ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==28) ) {
                alt3=1;
            }
            else if ( (LA3_0==29) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalSM2.g:795:2: ( '<' )
                    {
                    // InternalSM2.g:795:2: ( '<' )
                    // InternalSM2.g:796:3: '<'
                    {
                     before(grammarAccess.getVersionAccess().getSymbol2LessThanSignKeyword_1_6_0_0_0()); 
                    match(input,28,FOLLOW_2); 
                     after(grammarAccess.getVersionAccess().getSymbol2LessThanSignKeyword_1_6_0_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:801:2: ( '<=' )
                    {
                    // InternalSM2.g:801:2: ( '<=' )
                    // InternalSM2.g:802:3: '<='
                    {
                     before(grammarAccess.getVersionAccess().getSymbol2LessThanSignEqualsSignKeyword_1_6_0_0_1()); 
                    match(input,29,FOLLOW_2); 
                     after(grammarAccess.getVersionAccess().getSymbol2LessThanSignEqualsSignKeyword_1_6_0_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Symbol2Alternatives_1_6_0_0"


    // $ANTLR start "rule__Attributes__Alternatives"
    // InternalSM2.g:811:1: rule__Attributes__Alternatives : ( ( ruleProperty ) | ( ruleDataType ) );
    public final void rule__Attributes__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:815:1: ( ( ruleProperty ) | ( ruleDataType ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( ((LA4_0>=30 && LA4_0<=38)) ) {
                alt4=1;
            }
            else if ( (LA4_0==RULE_ID||LA4_0==64||(LA4_0>=66 && LA4_0<=67)) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalSM2.g:816:2: ( ruleProperty )
                    {
                    // InternalSM2.g:816:2: ( ruleProperty )
                    // InternalSM2.g:817:3: ruleProperty
                    {
                     before(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleProperty();

                    state._fsp--;

                     after(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:822:2: ( ruleDataType )
                    {
                    // InternalSM2.g:822:2: ( ruleDataType )
                    // InternalSM2.g:823:3: ruleDataType
                    {
                     before(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleDataType();

                    state._fsp--;

                     after(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attributes__Alternatives"


    // $ANTLR start "rule__DataType__Alternatives"
    // InternalSM2.g:832:1: rule__DataType__Alternatives : ( ( ruleCompositeType ) | ( ruleEnum ) | ( RULE_ID ) );
    public final void rule__DataType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:836:1: ( ( ruleCompositeType ) | ( ruleEnum ) | ( RULE_ID ) )
            int alt5=3;
            switch ( input.LA(1) ) {
            case 64:
            case 66:
                {
                alt5=1;
                }
                break;
            case 67:
                {
                alt5=2;
                }
                break;
            case RULE_ID:
                {
                alt5=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // InternalSM2.g:837:2: ( ruleCompositeType )
                    {
                    // InternalSM2.g:837:2: ( ruleCompositeType )
                    // InternalSM2.g:838:3: ruleCompositeType
                    {
                     before(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleCompositeType();

                    state._fsp--;

                     after(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:843:2: ( ruleEnum )
                    {
                    // InternalSM2.g:843:2: ( ruleEnum )
                    // InternalSM2.g:844:3: ruleEnum
                    {
                     before(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleEnum();

                    state._fsp--;

                     after(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:849:2: ( RULE_ID )
                    {
                    // InternalSM2.g:849:2: ( RULE_ID )
                    // InternalSM2.g:850:3: RULE_ID
                    {
                     before(grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataType__Alternatives"


    // $ANTLR start "rule__CompositeType__Alternatives"
    // InternalSM2.g:859:1: rule__CompositeType__Alternatives : ( ( ruleMapping ) | ( ruleStruct ) );
    public final void rule__CompositeType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:863:1: ( ( ruleMapping ) | ( ruleStruct ) )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==64) ) {
                alt6=1;
            }
            else if ( (LA6_0==66) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalSM2.g:864:2: ( ruleMapping )
                    {
                    // InternalSM2.g:864:2: ( ruleMapping )
                    // InternalSM2.g:865:3: ruleMapping
                    {
                     before(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleMapping();

                    state._fsp--;

                     after(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:870:2: ( ruleStruct )
                    {
                    // InternalSM2.g:870:2: ( ruleStruct )
                    // InternalSM2.g:871:3: ruleStruct
                    {
                     before(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleStruct();

                    state._fsp--;

                     after(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CompositeType__Alternatives"


    // $ANTLR start "rule__Struct__Alternatives"
    // InternalSM2.g:880:1: rule__Struct__Alternatives : ( ( rulePersonalizedStruct ) | ( ruleUser ) );
    public final void rule__Struct__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:884:1: ( ( rulePersonalizedStruct ) | ( ruleUser ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==66) ) {
                int LA7_1 = input.LA(2);

                if ( (LA7_1==RULE_ID) ) {
                    int LA7_2 = input.LA(3);

                    if ( (LA7_2==RULE_OPENKEY) ) {
                        switch ( input.LA(4) ) {
                        case RULE_EOLINE:
                            {
                            int LA7_4 = input.LA(5);

                            if ( (LA7_4==RULE_STRING) ) {
                                alt7=2;
                            }
                            else if ( ((LA7_4>=30 && LA7_4<=38)) ) {
                                alt7=1;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 7, 4, input);

                                throw nvae;
                            }
                            }
                            break;
                        case RULE_STRING:
                            {
                            alt7=2;
                            }
                            break;
                        case 30:
                        case 31:
                        case 32:
                        case 33:
                        case 34:
                        case 35:
                        case 36:
                        case 37:
                        case 38:
                            {
                            alt7=1;
                            }
                            break;
                        default:
                            NoViableAltException nvae =
                                new NoViableAltException("", 7, 3, input);

                            throw nvae;
                        }

                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 7, 2, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 7, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalSM2.g:885:2: ( rulePersonalizedStruct )
                    {
                    // InternalSM2.g:885:2: ( rulePersonalizedStruct )
                    // InternalSM2.g:886:3: rulePersonalizedStruct
                    {
                     before(grammarAccess.getStructAccess().getPersonalizedStructParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    rulePersonalizedStruct();

                    state._fsp--;

                     after(grammarAccess.getStructAccess().getPersonalizedStructParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:891:2: ( ruleUser )
                    {
                    // InternalSM2.g:891:2: ( ruleUser )
                    // InternalSM2.g:892:3: ruleUser
                    {
                     before(grammarAccess.getStructAccess().getUserParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleUser();

                    state._fsp--;

                     after(grammarAccess.getStructAccess().getUserParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Alternatives"


    // $ANTLR start "rule__Property__Alternatives_4"
    // InternalSM2.g:901:1: rule__Property__Alternatives_4 : ( ( ( rule__Property__InicializationAssignment_4_0 ) ) | ( RULE_INT ) );
    public final void rule__Property__Alternatives_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:905:1: ( ( ( rule__Property__InicializationAssignment_4_0 ) ) | ( RULE_INT ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==RULE_STRING) ) {
                alt8=1;
            }
            else if ( (LA8_0==RULE_INT) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalSM2.g:906:2: ( ( rule__Property__InicializationAssignment_4_0 ) )
                    {
                    // InternalSM2.g:906:2: ( ( rule__Property__InicializationAssignment_4_0 ) )
                    // InternalSM2.g:907:3: ( rule__Property__InicializationAssignment_4_0 )
                    {
                     before(grammarAccess.getPropertyAccess().getInicializationAssignment_4_0()); 
                    // InternalSM2.g:908:3: ( rule__Property__InicializationAssignment_4_0 )
                    // InternalSM2.g:908:4: rule__Property__InicializationAssignment_4_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__InicializationAssignment_4_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPropertyAccess().getInicializationAssignment_4_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:912:2: ( RULE_INT )
                    {
                    // InternalSM2.g:912:2: ( RULE_INT )
                    // InternalSM2.g:913:3: RULE_INT
                    {
                     before(grammarAccess.getPropertyAccess().getINTTerminalRuleCall_4_1()); 
                    match(input,RULE_INT,FOLLOW_2); 
                     after(grammarAccess.getPropertyAccess().getINTTerminalRuleCall_4_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Alternatives_4"


    // $ANTLR start "rule__Expression__Alternatives"
    // InternalSM2.g:922:1: rule__Expression__Alternatives : ( ( ruleArithmethicalExpression ) | ( ruleSyntaxExpression ) );
    public final void rule__Expression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:926:1: ( ( ruleArithmethicalExpression ) | ( ruleSyntaxExpression ) )
            int alt9=2;
            switch ( input.LA(1) ) {
            case RULE_OPENPARENTHESIS:
                {
                alt9=1;
                }
                break;
            case RULE_INT:
                {
                int LA9_2 = input.LA(2);

                if ( ((LA9_2>=53 && LA9_2<=56)) ) {
                    alt9=1;
                }
                else if ( (LA9_2==EOF||(LA9_2>=RULE_SEMICOLON && LA9_2<=RULE_EOLINE)||LA9_2==RULE_CLOSEKEY) ) {
                    alt9=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 9, 2, input);

                    throw nvae;
                }
                }
                break;
            case RULE_STRING:
                {
                alt9=2;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalSM2.g:927:2: ( ruleArithmethicalExpression )
                    {
                    // InternalSM2.g:927:2: ( ruleArithmethicalExpression )
                    // InternalSM2.g:928:3: ruleArithmethicalExpression
                    {
                     before(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleArithmethicalExpression();

                    state._fsp--;

                     after(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:933:2: ( ruleSyntaxExpression )
                    {
                    // InternalSM2.g:933:2: ( ruleSyntaxExpression )
                    // InternalSM2.g:934:3: ruleSyntaxExpression
                    {
                     before(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleSyntaxExpression();

                    state._fsp--;

                     after(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Expression__Alternatives"


    // $ANTLR start "rule__ArithmethicalExpression__Alternatives"
    // InternalSM2.g:943:1: rule__ArithmethicalExpression__Alternatives : ( ( ( rule__ArithmethicalExpression__Group_0__0 ) ) | ( ( rule__ArithmethicalExpression__Group_1__0 ) ) );
    public final void rule__ArithmethicalExpression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:947:1: ( ( ( rule__ArithmethicalExpression__Group_0__0 ) ) | ( ( rule__ArithmethicalExpression__Group_1__0 ) ) )
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==RULE_OPENPARENTHESIS) ) {
                alt10=1;
            }
            else if ( (LA10_0==RULE_INT) ) {
                alt10=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }
            switch (alt10) {
                case 1 :
                    // InternalSM2.g:948:2: ( ( rule__ArithmethicalExpression__Group_0__0 ) )
                    {
                    // InternalSM2.g:948:2: ( ( rule__ArithmethicalExpression__Group_0__0 ) )
                    // InternalSM2.g:949:3: ( rule__ArithmethicalExpression__Group_0__0 )
                    {
                     before(grammarAccess.getArithmethicalExpressionAccess().getGroup_0()); 
                    // InternalSM2.g:950:3: ( rule__ArithmethicalExpression__Group_0__0 )
                    // InternalSM2.g:950:4: rule__ArithmethicalExpression__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getArithmethicalExpressionAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:954:2: ( ( rule__ArithmethicalExpression__Group_1__0 ) )
                    {
                    // InternalSM2.g:954:2: ( ( rule__ArithmethicalExpression__Group_1__0 ) )
                    // InternalSM2.g:955:3: ( rule__ArithmethicalExpression__Group_1__0 )
                    {
                     before(grammarAccess.getArithmethicalExpressionAccess().getGroup_1()); 
                    // InternalSM2.g:956:3: ( rule__ArithmethicalExpression__Group_1__0 )
                    // InternalSM2.g:956:4: rule__ArithmethicalExpression__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getArithmethicalExpressionAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Alternatives"


    // $ANTLR start "rule__SyntaxExpression__Alternatives"
    // InternalSM2.g:964:1: rule__SyntaxExpression__Alternatives : ( ( ( rule__SyntaxExpression__TextAssignment_0 ) ) | ( ( rule__SyntaxExpression__Group_1__0 ) ) );
    public final void rule__SyntaxExpression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:968:1: ( ( ( rule__SyntaxExpression__TextAssignment_0 ) ) | ( ( rule__SyntaxExpression__Group_1__0 ) ) )
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==RULE_STRING) ) {
                alt11=1;
            }
            else if ( (LA11_0==RULE_INT) ) {
                alt11=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalSM2.g:969:2: ( ( rule__SyntaxExpression__TextAssignment_0 ) )
                    {
                    // InternalSM2.g:969:2: ( ( rule__SyntaxExpression__TextAssignment_0 ) )
                    // InternalSM2.g:970:3: ( rule__SyntaxExpression__TextAssignment_0 )
                    {
                     before(grammarAccess.getSyntaxExpressionAccess().getTextAssignment_0()); 
                    // InternalSM2.g:971:3: ( rule__SyntaxExpression__TextAssignment_0 )
                    // InternalSM2.g:971:4: rule__SyntaxExpression__TextAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__TextAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getSyntaxExpressionAccess().getTextAssignment_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:975:2: ( ( rule__SyntaxExpression__Group_1__0 ) )
                    {
                    // InternalSM2.g:975:2: ( ( rule__SyntaxExpression__Group_1__0 ) )
                    // InternalSM2.g:976:3: ( rule__SyntaxExpression__Group_1__0 )
                    {
                     before(grammarAccess.getSyntaxExpressionAccess().getGroup_1()); 
                    // InternalSM2.g:977:3: ( rule__SyntaxExpression__Group_1__0 )
                    // InternalSM2.g:977:4: rule__SyntaxExpression__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getSyntaxExpressionAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Alternatives"


    // $ANTLR start "rule__Comment__Alternatives"
    // InternalSM2.g:985:1: rule__Comment__Alternatives : ( ( ruleShortComment ) | ( ruleLongComment ) );
    public final void rule__Comment__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:989:1: ( ( ruleShortComment ) | ( ruleLongComment ) )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==71) ) {
                alt12=1;
            }
            else if ( (LA12_0==72) ) {
                alt12=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // InternalSM2.g:990:2: ( ruleShortComment )
                    {
                    // InternalSM2.g:990:2: ( ruleShortComment )
                    // InternalSM2.g:991:3: ruleShortComment
                    {
                     before(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleShortComment();

                    state._fsp--;

                     after(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:996:2: ( ruleLongComment )
                    {
                    // InternalSM2.g:996:2: ( ruleLongComment )
                    // InternalSM2.g:997:3: ruleLongComment
                    {
                     before(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleLongComment();

                    state._fsp--;

                     after(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Comment__Alternatives"


    // $ANTLR start "rule__LongComment__ExpressionAlternatives_1_0"
    // InternalSM2.g:1006:1: rule__LongComment__ExpressionAlternatives_1_0 : ( ( RULE_STRING ) | ( RULE_PARAMSLONGCOMENT ) | ( RULE_DEVLONGCOMENT ) | ( RULE_RETURNSLONGCOMENT ) | ( RULE_TITLELONGCOMENT ) | ( RULE_NOTICELONGCOMENT ) );
    public final void rule__LongComment__ExpressionAlternatives_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1010:1: ( ( RULE_STRING ) | ( RULE_PARAMSLONGCOMENT ) | ( RULE_DEVLONGCOMENT ) | ( RULE_RETURNSLONGCOMENT ) | ( RULE_TITLELONGCOMENT ) | ( RULE_NOTICELONGCOMENT ) )
            int alt13=6;
            switch ( input.LA(1) ) {
            case RULE_STRING:
                {
                alt13=1;
                }
                break;
            case RULE_PARAMSLONGCOMENT:
                {
                alt13=2;
                }
                break;
            case RULE_DEVLONGCOMENT:
                {
                alt13=3;
                }
                break;
            case RULE_RETURNSLONGCOMENT:
                {
                alt13=4;
                }
                break;
            case RULE_TITLELONGCOMENT:
                {
                alt13=5;
                }
                break;
            case RULE_NOTICELONGCOMENT:
                {
                alt13=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }

            switch (alt13) {
                case 1 :
                    // InternalSM2.g:1011:2: ( RULE_STRING )
                    {
                    // InternalSM2.g:1011:2: ( RULE_STRING )
                    // InternalSM2.g:1012:3: RULE_STRING
                    {
                     before(grammarAccess.getLongCommentAccess().getExpressionSTRINGTerminalRuleCall_1_0_0()); 
                    match(input,RULE_STRING,FOLLOW_2); 
                     after(grammarAccess.getLongCommentAccess().getExpressionSTRINGTerminalRuleCall_1_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1017:2: ( RULE_PARAMSLONGCOMENT )
                    {
                    // InternalSM2.g:1017:2: ( RULE_PARAMSLONGCOMENT )
                    // InternalSM2.g:1018:3: RULE_PARAMSLONGCOMENT
                    {
                     before(grammarAccess.getLongCommentAccess().getExpressionPARAMSLONGCOMENTTerminalRuleCall_1_0_1()); 
                    match(input,RULE_PARAMSLONGCOMENT,FOLLOW_2); 
                     after(grammarAccess.getLongCommentAccess().getExpressionPARAMSLONGCOMENTTerminalRuleCall_1_0_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1023:2: ( RULE_DEVLONGCOMENT )
                    {
                    // InternalSM2.g:1023:2: ( RULE_DEVLONGCOMENT )
                    // InternalSM2.g:1024:3: RULE_DEVLONGCOMENT
                    {
                     before(grammarAccess.getLongCommentAccess().getExpressionDEVLONGCOMENTTerminalRuleCall_1_0_2()); 
                    match(input,RULE_DEVLONGCOMENT,FOLLOW_2); 
                     after(grammarAccess.getLongCommentAccess().getExpressionDEVLONGCOMENTTerminalRuleCall_1_0_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1029:2: ( RULE_RETURNSLONGCOMENT )
                    {
                    // InternalSM2.g:1029:2: ( RULE_RETURNSLONGCOMENT )
                    // InternalSM2.g:1030:3: RULE_RETURNSLONGCOMENT
                    {
                     before(grammarAccess.getLongCommentAccess().getExpressionRETURNSLONGCOMENTTerminalRuleCall_1_0_3()); 
                    match(input,RULE_RETURNSLONGCOMENT,FOLLOW_2); 
                     after(grammarAccess.getLongCommentAccess().getExpressionRETURNSLONGCOMENTTerminalRuleCall_1_0_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1035:2: ( RULE_TITLELONGCOMENT )
                    {
                    // InternalSM2.g:1035:2: ( RULE_TITLELONGCOMENT )
                    // InternalSM2.g:1036:3: RULE_TITLELONGCOMENT
                    {
                     before(grammarAccess.getLongCommentAccess().getExpressionTITLELONGCOMENTTerminalRuleCall_1_0_4()); 
                    match(input,RULE_TITLELONGCOMENT,FOLLOW_2); 
                     after(grammarAccess.getLongCommentAccess().getExpressionTITLELONGCOMENTTerminalRuleCall_1_0_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1041:2: ( RULE_NOTICELONGCOMENT )
                    {
                    // InternalSM2.g:1041:2: ( RULE_NOTICELONGCOMENT )
                    // InternalSM2.g:1042:3: RULE_NOTICELONGCOMENT
                    {
                     before(grammarAccess.getLongCommentAccess().getExpressionNOTICELONGCOMENTTerminalRuleCall_1_0_5()); 
                    match(input,RULE_NOTICELONGCOMENT,FOLLOW_2); 
                     after(grammarAccess.getLongCommentAccess().getExpressionNOTICELONGCOMENTTerminalRuleCall_1_0_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__ExpressionAlternatives_1_0"


    // $ANTLR start "rule__SingularType__Alternatives"
    // InternalSM2.g:1051:1: rule__SingularType__Alternatives : ( ( ( 'int' ) ) | ( ( 'uint' ) ) | ( ( 'uint8' ) ) | ( ( 'uint256' ) ) | ( ( 'string' ) ) | ( ( 'address' ) ) | ( ( 'address payable' ) ) | ( ( 'double' ) ) | ( ( 'bool' ) ) );
    public final void rule__SingularType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1055:1: ( ( ( 'int' ) ) | ( ( 'uint' ) ) | ( ( 'uint8' ) ) | ( ( 'uint256' ) ) | ( ( 'string' ) ) | ( ( 'address' ) ) | ( ( 'address payable' ) ) | ( ( 'double' ) ) | ( ( 'bool' ) ) )
            int alt14=9;
            switch ( input.LA(1) ) {
            case 30:
                {
                alt14=1;
                }
                break;
            case 31:
                {
                alt14=2;
                }
                break;
            case 32:
                {
                alt14=3;
                }
                break;
            case 33:
                {
                alt14=4;
                }
                break;
            case 34:
                {
                alt14=5;
                }
                break;
            case 35:
                {
                alt14=6;
                }
                break;
            case 36:
                {
                alt14=7;
                }
                break;
            case 37:
                {
                alt14=8;
                }
                break;
            case 38:
                {
                alt14=9;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }

            switch (alt14) {
                case 1 :
                    // InternalSM2.g:1056:2: ( ( 'int' ) )
                    {
                    // InternalSM2.g:1056:2: ( ( 'int' ) )
                    // InternalSM2.g:1057:3: ( 'int' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1058:3: ( 'int' )
                    // InternalSM2.g:1058:4: 'int'
                    {
                    match(input,30,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1062:2: ( ( 'uint' ) )
                    {
                    // InternalSM2.g:1062:2: ( ( 'uint' ) )
                    // InternalSM2.g:1063:3: ( 'uint' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1064:3: ( 'uint' )
                    // InternalSM2.g:1064:4: 'uint'
                    {
                    match(input,31,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1068:2: ( ( 'uint8' ) )
                    {
                    // InternalSM2.g:1068:2: ( ( 'uint8' ) )
                    // InternalSM2.g:1069:3: ( 'uint8' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1070:3: ( 'uint8' )
                    // InternalSM2.g:1070:4: 'uint8'
                    {
                    match(input,32,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1074:2: ( ( 'uint256' ) )
                    {
                    // InternalSM2.g:1074:2: ( ( 'uint256' ) )
                    // InternalSM2.g:1075:3: ( 'uint256' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3()); 
                    // InternalSM2.g:1076:3: ( 'uint256' )
                    // InternalSM2.g:1076:4: 'uint256'
                    {
                    match(input,33,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1080:2: ( ( 'string' ) )
                    {
                    // InternalSM2.g:1080:2: ( ( 'string' ) )
                    // InternalSM2.g:1081:3: ( 'string' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4()); 
                    // InternalSM2.g:1082:3: ( 'string' )
                    // InternalSM2.g:1082:4: 'string'
                    {
                    match(input,34,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1086:2: ( ( 'address' ) )
                    {
                    // InternalSM2.g:1086:2: ( ( 'address' ) )
                    // InternalSM2.g:1087:3: ( 'address' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5()); 
                    // InternalSM2.g:1088:3: ( 'address' )
                    // InternalSM2.g:1088:4: 'address'
                    {
                    match(input,35,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5()); 

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:1092:2: ( ( 'address payable' ) )
                    {
                    // InternalSM2.g:1092:2: ( ( 'address payable' ) )
                    // InternalSM2.g:1093:3: ( 'address payable' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6()); 
                    // InternalSM2.g:1094:3: ( 'address payable' )
                    // InternalSM2.g:1094:4: 'address payable'
                    {
                    match(input,36,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6()); 

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:1098:2: ( ( 'double' ) )
                    {
                    // InternalSM2.g:1098:2: ( ( 'double' ) )
                    // InternalSM2.g:1099:3: ( 'double' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7()); 
                    // InternalSM2.g:1100:3: ( 'double' )
                    // InternalSM2.g:1100:4: 'double'
                    {
                    match(input,37,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7()); 

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:1104:2: ( ( 'bool' ) )
                    {
                    // InternalSM2.g:1104:2: ( ( 'bool' ) )
                    // InternalSM2.g:1105:3: ( 'bool' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8()); 
                    // InternalSM2.g:1106:3: ( 'bool' )
                    // InternalSM2.g:1106:4: 'bool'
                    {
                    match(input,38,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingularType__Alternatives"


    // $ANTLR start "rule__Visibility__Alternatives"
    // InternalSM2.g:1114:1: rule__Visibility__Alternatives : ( ( ( 'public' ) ) | ( ( 'private' ) ) | ( ( 'internal' ) ) | ( ( 'external' ) ) );
    public final void rule__Visibility__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1118:1: ( ( ( 'public' ) ) | ( ( 'private' ) ) | ( ( 'internal' ) ) | ( ( 'external' ) ) )
            int alt15=4;
            switch ( input.LA(1) ) {
            case 39:
                {
                alt15=1;
                }
                break;
            case 40:
                {
                alt15=2;
                }
                break;
            case 41:
                {
                alt15=3;
                }
                break;
            case 42:
                {
                alt15=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }

            switch (alt15) {
                case 1 :
                    // InternalSM2.g:1119:2: ( ( 'public' ) )
                    {
                    // InternalSM2.g:1119:2: ( ( 'public' ) )
                    // InternalSM2.g:1120:3: ( 'public' )
                    {
                     before(grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1121:3: ( 'public' )
                    // InternalSM2.g:1121:4: 'public'
                    {
                    match(input,39,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1125:2: ( ( 'private' ) )
                    {
                    // InternalSM2.g:1125:2: ( ( 'private' ) )
                    // InternalSM2.g:1126:3: ( 'private' )
                    {
                     before(grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1127:3: ( 'private' )
                    // InternalSM2.g:1127:4: 'private'
                    {
                    match(input,40,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1131:2: ( ( 'internal' ) )
                    {
                    // InternalSM2.g:1131:2: ( ( 'internal' ) )
                    // InternalSM2.g:1132:3: ( 'internal' )
                    {
                     before(grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1133:3: ( 'internal' )
                    // InternalSM2.g:1133:4: 'internal'
                    {
                    match(input,41,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1137:2: ( ( 'external' ) )
                    {
                    // InternalSM2.g:1137:2: ( ( 'external' ) )
                    // InternalSM2.g:1138:3: ( 'external' )
                    {
                     before(grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3()); 
                    // InternalSM2.g:1139:3: ( 'external' )
                    // InternalSM2.g:1139:4: 'external'
                    {
                    match(input,42,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Visibility__Alternatives"


    // $ANTLR start "rule__Coin__Alternatives"
    // InternalSM2.g:1147:1: rule__Coin__Alternatives : ( ( ( 'ether' ) ) | ( ( 'wei' ) ) | ( ( 'gwei' ) ) | ( ( 'pwei' ) ) | ( ( 'finney' ) ) | ( ( 'szabo' ) ) );
    public final void rule__Coin__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1151:1: ( ( ( 'ether' ) ) | ( ( 'wei' ) ) | ( ( 'gwei' ) ) | ( ( 'pwei' ) ) | ( ( 'finney' ) ) | ( ( 'szabo' ) ) )
            int alt16=6;
            switch ( input.LA(1) ) {
            case 43:
                {
                alt16=1;
                }
                break;
            case 44:
                {
                alt16=2;
                }
                break;
            case 45:
                {
                alt16=3;
                }
                break;
            case 46:
                {
                alt16=4;
                }
                break;
            case 47:
                {
                alt16=5;
                }
                break;
            case 48:
                {
                alt16=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }

            switch (alt16) {
                case 1 :
                    // InternalSM2.g:1152:2: ( ( 'ether' ) )
                    {
                    // InternalSM2.g:1152:2: ( ( 'ether' ) )
                    // InternalSM2.g:1153:3: ( 'ether' )
                    {
                     before(grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1154:3: ( 'ether' )
                    // InternalSM2.g:1154:4: 'ether'
                    {
                    match(input,43,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1158:2: ( ( 'wei' ) )
                    {
                    // InternalSM2.g:1158:2: ( ( 'wei' ) )
                    // InternalSM2.g:1159:3: ( 'wei' )
                    {
                     before(grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1160:3: ( 'wei' )
                    // InternalSM2.g:1160:4: 'wei'
                    {
                    match(input,44,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1164:2: ( ( 'gwei' ) )
                    {
                    // InternalSM2.g:1164:2: ( ( 'gwei' ) )
                    // InternalSM2.g:1165:3: ( 'gwei' )
                    {
                     before(grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1166:3: ( 'gwei' )
                    // InternalSM2.g:1166:4: 'gwei'
                    {
                    match(input,45,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1170:2: ( ( 'pwei' ) )
                    {
                    // InternalSM2.g:1170:2: ( ( 'pwei' ) )
                    // InternalSM2.g:1171:3: ( 'pwei' )
                    {
                     before(grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3()); 
                    // InternalSM2.g:1172:3: ( 'pwei' )
                    // InternalSM2.g:1172:4: 'pwei'
                    {
                    match(input,46,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1176:2: ( ( 'finney' ) )
                    {
                    // InternalSM2.g:1176:2: ( ( 'finney' ) )
                    // InternalSM2.g:1177:3: ( 'finney' )
                    {
                     before(grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4()); 
                    // InternalSM2.g:1178:3: ( 'finney' )
                    // InternalSM2.g:1178:4: 'finney'
                    {
                    match(input,47,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1182:2: ( ( 'szabo' ) )
                    {
                    // InternalSM2.g:1182:2: ( ( 'szabo' ) )
                    // InternalSM2.g:1183:3: ( 'szabo' )
                    {
                     before(grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5()); 
                    // InternalSM2.g:1184:3: ( 'szabo' )
                    // InternalSM2.g:1184:4: 'szabo'
                    {
                    match(input,48,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coin__Alternatives"


    // $ANTLR start "rule__ComparationOperator__Alternatives"
    // InternalSM2.g:1192:1: rule__ComparationOperator__Alternatives : ( ( ( '>' ) ) | ( ( '<' ) ) | ( ( '>=' ) ) | ( ( '<=' ) ) | ( ( '==' ) ) | ( ( '!=' ) ) );
    public final void rule__ComparationOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1196:1: ( ( ( '>' ) ) | ( ( '<' ) ) | ( ( '>=' ) ) | ( ( '<=' ) ) | ( ( '==' ) ) | ( ( '!=' ) ) )
            int alt17=6;
            switch ( input.LA(1) ) {
            case 26:
                {
                alt17=1;
                }
                break;
            case 28:
                {
                alt17=2;
                }
                break;
            case 27:
                {
                alt17=3;
                }
                break;
            case 29:
                {
                alt17=4;
                }
                break;
            case 49:
                {
                alt17=5;
                }
                break;
            case 50:
                {
                alt17=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // InternalSM2.g:1197:2: ( ( '>' ) )
                    {
                    // InternalSM2.g:1197:2: ( ( '>' ) )
                    // InternalSM2.g:1198:3: ( '>' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1199:3: ( '>' )
                    // InternalSM2.g:1199:4: '>'
                    {
                    match(input,26,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1203:2: ( ( '<' ) )
                    {
                    // InternalSM2.g:1203:2: ( ( '<' ) )
                    // InternalSM2.g:1204:3: ( '<' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1205:3: ( '<' )
                    // InternalSM2.g:1205:4: '<'
                    {
                    match(input,28,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1209:2: ( ( '>=' ) )
                    {
                    // InternalSM2.g:1209:2: ( ( '>=' ) )
                    // InternalSM2.g:1210:3: ( '>=' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1211:3: ( '>=' )
                    // InternalSM2.g:1211:4: '>='
                    {
                    match(input,27,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1215:2: ( ( '<=' ) )
                    {
                    // InternalSM2.g:1215:2: ( ( '<=' ) )
                    // InternalSM2.g:1216:3: ( '<=' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3()); 
                    // InternalSM2.g:1217:3: ( '<=' )
                    // InternalSM2.g:1217:4: '<='
                    {
                    match(input,29,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1221:2: ( ( '==' ) )
                    {
                    // InternalSM2.g:1221:2: ( ( '==' ) )
                    // InternalSM2.g:1222:3: ( '==' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4()); 
                    // InternalSM2.g:1223:3: ( '==' )
                    // InternalSM2.g:1223:4: '=='
                    {
                    match(input,49,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1227:2: ( ( '!=' ) )
                    {
                    // InternalSM2.g:1227:2: ( ( '!=' ) )
                    // InternalSM2.g:1228:3: ( '!=' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5()); 
                    // InternalSM2.g:1229:3: ( '!=' )
                    // InternalSM2.g:1229:4: '!='
                    {
                    match(input,50,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparationOperator__Alternatives"


    // $ANTLR start "rule__LogicalPairOperator__Alternatives"
    // InternalSM2.g:1237:1: rule__LogicalPairOperator__Alternatives : ( ( ( '&&' ) ) | ( ( '||' ) ) );
    public final void rule__LogicalPairOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1241:1: ( ( ( '&&' ) ) | ( ( '||' ) ) )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==51) ) {
                alt18=1;
            }
            else if ( (LA18_0==52) ) {
                alt18=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    // InternalSM2.g:1242:2: ( ( '&&' ) )
                    {
                    // InternalSM2.g:1242:2: ( ( '&&' ) )
                    // InternalSM2.g:1243:3: ( '&&' )
                    {
                     before(grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1244:3: ( '&&' )
                    // InternalSM2.g:1244:4: '&&'
                    {
                    match(input,51,FOLLOW_2); 

                    }

                     after(grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1248:2: ( ( '||' ) )
                    {
                    // InternalSM2.g:1248:2: ( ( '||' ) )
                    // InternalSM2.g:1249:3: ( '||' )
                    {
                     before(grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1250:3: ( '||' )
                    // InternalSM2.g:1250:4: '||'
                    {
                    match(input,52,FOLLOW_2); 

                    }

                     after(grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicalPairOperator__Alternatives"


    // $ANTLR start "rule__ArithmeticalOperator__Alternatives"
    // InternalSM2.g:1258:1: rule__ArithmeticalOperator__Alternatives : ( ( ( '+' ) ) | ( ( '-' ) ) | ( ( '*' ) ) | ( ( '/' ) ) );
    public final void rule__ArithmeticalOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1262:1: ( ( ( '+' ) ) | ( ( '-' ) ) | ( ( '*' ) ) | ( ( '/' ) ) )
            int alt19=4;
            switch ( input.LA(1) ) {
            case 53:
                {
                alt19=1;
                }
                break;
            case 54:
                {
                alt19=2;
                }
                break;
            case 55:
                {
                alt19=3;
                }
                break;
            case 56:
                {
                alt19=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }

            switch (alt19) {
                case 1 :
                    // InternalSM2.g:1263:2: ( ( '+' ) )
                    {
                    // InternalSM2.g:1263:2: ( ( '+' ) )
                    // InternalSM2.g:1264:3: ( '+' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1265:3: ( '+' )
                    // InternalSM2.g:1265:4: '+'
                    {
                    match(input,53,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1269:2: ( ( '-' ) )
                    {
                    // InternalSM2.g:1269:2: ( ( '-' ) )
                    // InternalSM2.g:1270:3: ( '-' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1271:3: ( '-' )
                    // InternalSM2.g:1271:4: '-'
                    {
                    match(input,54,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1275:2: ( ( '*' ) )
                    {
                    // InternalSM2.g:1275:2: ( ( '*' ) )
                    // InternalSM2.g:1276:3: ( '*' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1277:3: ( '*' )
                    // InternalSM2.g:1277:4: '*'
                    {
                    match(input,55,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1281:2: ( ( '/' ) )
                    {
                    // InternalSM2.g:1281:2: ( ( '/' ) )
                    // InternalSM2.g:1282:3: ( '/' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3()); 
                    // InternalSM2.g:1283:3: ( '/' )
                    // InternalSM2.g:1283:4: '/'
                    {
                    match(input,56,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmeticalOperator__Alternatives"


    // $ANTLR start "rule__SmartContract__Group__0"
    // InternalSM2.g:1291:1: rule__SmartContract__Group__0 : rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1 ;
    public final void rule__SmartContract__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1295:1: ( rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1 )
            // InternalSM2.g:1296:2: rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__SmartContract__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__0"


    // $ANTLR start "rule__SmartContract__Group__0__Impl"
    // InternalSM2.g:1303:1: rule__SmartContract__Group__0__Impl : ( ( rule__SmartContract__CompilerAssignment_0 ) ) ;
    public final void rule__SmartContract__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1307:1: ( ( ( rule__SmartContract__CompilerAssignment_0 ) ) )
            // InternalSM2.g:1308:1: ( ( rule__SmartContract__CompilerAssignment_0 ) )
            {
            // InternalSM2.g:1308:1: ( ( rule__SmartContract__CompilerAssignment_0 ) )
            // InternalSM2.g:1309:2: ( rule__SmartContract__CompilerAssignment_0 )
            {
             before(grammarAccess.getSmartContractAccess().getCompilerAssignment_0()); 
            // InternalSM2.g:1310:2: ( rule__SmartContract__CompilerAssignment_0 )
            // InternalSM2.g:1310:3: rule__SmartContract__CompilerAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__CompilerAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getCompilerAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__0__Impl"


    // $ANTLR start "rule__SmartContract__Group__1"
    // InternalSM2.g:1318:1: rule__SmartContract__Group__1 : rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2 ;
    public final void rule__SmartContract__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1322:1: ( rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2 )
            // InternalSM2.g:1323:2: rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__SmartContract__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__1"


    // $ANTLR start "rule__SmartContract__Group__1__Impl"
    // InternalSM2.g:1330:1: rule__SmartContract__Group__1__Impl : ( 'solidity' ) ;
    public final void rule__SmartContract__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1334:1: ( ( 'solidity' ) )
            // InternalSM2.g:1335:1: ( 'solidity' )
            {
            // InternalSM2.g:1335:1: ( 'solidity' )
            // InternalSM2.g:1336:2: 'solidity'
            {
             before(grammarAccess.getSmartContractAccess().getSolidityKeyword_1()); 
            match(input,57,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getSolidityKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__1__Impl"


    // $ANTLR start "rule__SmartContract__Group__2"
    // InternalSM2.g:1345:1: rule__SmartContract__Group__2 : rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3 ;
    public final void rule__SmartContract__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1349:1: ( rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3 )
            // InternalSM2.g:1350:2: rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__SmartContract__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__2"


    // $ANTLR start "rule__SmartContract__Group__2__Impl"
    // InternalSM2.g:1357:1: rule__SmartContract__Group__2__Impl : ( ( rule__SmartContract__VersionCompilerAssignment_2 ) ) ;
    public final void rule__SmartContract__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1361:1: ( ( ( rule__SmartContract__VersionCompilerAssignment_2 ) ) )
            // InternalSM2.g:1362:1: ( ( rule__SmartContract__VersionCompilerAssignment_2 ) )
            {
            // InternalSM2.g:1362:1: ( ( rule__SmartContract__VersionCompilerAssignment_2 ) )
            // InternalSM2.g:1363:2: ( rule__SmartContract__VersionCompilerAssignment_2 )
            {
             before(grammarAccess.getSmartContractAccess().getVersionCompilerAssignment_2()); 
            // InternalSM2.g:1364:2: ( rule__SmartContract__VersionCompilerAssignment_2 )
            // InternalSM2.g:1364:3: rule__SmartContract__VersionCompilerAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__VersionCompilerAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getVersionCompilerAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__2__Impl"


    // $ANTLR start "rule__SmartContract__Group__3"
    // InternalSM2.g:1372:1: rule__SmartContract__Group__3 : rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4 ;
    public final void rule__SmartContract__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1376:1: ( rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4 )
            // InternalSM2.g:1377:2: rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__3"


    // $ANTLR start "rule__SmartContract__Group__3__Impl"
    // InternalSM2.g:1384:1: rule__SmartContract__Group__3__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__SmartContract__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1388:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:1389:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:1389:1: ( RULE_SEMICOLON )
            // InternalSM2.g:1390:2: RULE_SEMICOLON
            {
             before(grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__3__Impl"


    // $ANTLR start "rule__SmartContract__Group__4"
    // InternalSM2.g:1399:1: rule__SmartContract__Group__4 : rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5 ;
    public final void rule__SmartContract__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1403:1: ( rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5 )
            // InternalSM2.g:1404:2: rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__4"


    // $ANTLR start "rule__SmartContract__Group__4__Impl"
    // InternalSM2.g:1411:1: rule__SmartContract__Group__4__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__SmartContract__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1415:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:1416:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:1416:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:1417:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4()); 
            // InternalSM2.g:1418:2: ( RULE_EOLINE )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==RULE_EOLINE) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalSM2.g:1418:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__4__Impl"


    // $ANTLR start "rule__SmartContract__Group__5"
    // InternalSM2.g:1426:1: rule__SmartContract__Group__5 : rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6 ;
    public final void rule__SmartContract__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1430:1: ( rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6 )
            // InternalSM2.g:1431:2: rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__5"


    // $ANTLR start "rule__SmartContract__Group__5__Impl"
    // InternalSM2.g:1438:1: rule__SmartContract__Group__5__Impl : ( ( rule__SmartContract__ImportsAssignment_5 )* ) ;
    public final void rule__SmartContract__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1442:1: ( ( ( rule__SmartContract__ImportsAssignment_5 )* ) )
            // InternalSM2.g:1443:1: ( ( rule__SmartContract__ImportsAssignment_5 )* )
            {
            // InternalSM2.g:1443:1: ( ( rule__SmartContract__ImportsAssignment_5 )* )
            // InternalSM2.g:1444:2: ( rule__SmartContract__ImportsAssignment_5 )*
            {
             before(grammarAccess.getSmartContractAccess().getImportsAssignment_5()); 
            // InternalSM2.g:1445:2: ( rule__SmartContract__ImportsAssignment_5 )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==59) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalSM2.g:1445:3: rule__SmartContract__ImportsAssignment_5
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__SmartContract__ImportsAssignment_5();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getImportsAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__5__Impl"


    // $ANTLR start "rule__SmartContract__Group__6"
    // InternalSM2.g:1453:1: rule__SmartContract__Group__6 : rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7 ;
    public final void rule__SmartContract__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1457:1: ( rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7 )
            // InternalSM2.g:1458:2: rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7
            {
            pushFollow(FOLLOW_8);
            rule__SmartContract__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__6"


    // $ANTLR start "rule__SmartContract__Group__6__Impl"
    // InternalSM2.g:1465:1: rule__SmartContract__Group__6__Impl : ( ( rule__SmartContract__ContractAssignment_6 ) ) ;
    public final void rule__SmartContract__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1469:1: ( ( ( rule__SmartContract__ContractAssignment_6 ) ) )
            // InternalSM2.g:1470:1: ( ( rule__SmartContract__ContractAssignment_6 ) )
            {
            // InternalSM2.g:1470:1: ( ( rule__SmartContract__ContractAssignment_6 ) )
            // InternalSM2.g:1471:2: ( rule__SmartContract__ContractAssignment_6 )
            {
             before(grammarAccess.getSmartContractAccess().getContractAssignment_6()); 
            // InternalSM2.g:1472:2: ( rule__SmartContract__ContractAssignment_6 )
            // InternalSM2.g:1472:3: rule__SmartContract__ContractAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__ContractAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getContractAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__6__Impl"


    // $ANTLR start "rule__SmartContract__Group__7"
    // InternalSM2.g:1480:1: rule__SmartContract__Group__7 : rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8 ;
    public final void rule__SmartContract__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1484:1: ( rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8 )
            // InternalSM2.g:1485:2: rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8
            {
            pushFollow(FOLLOW_9);
            rule__SmartContract__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__7"


    // $ANTLR start "rule__SmartContract__Group__7__Impl"
    // InternalSM2.g:1492:1: rule__SmartContract__Group__7__Impl : ( ( rule__SmartContract__NameContractAssignment_7 ) ) ;
    public final void rule__SmartContract__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1496:1: ( ( ( rule__SmartContract__NameContractAssignment_7 ) ) )
            // InternalSM2.g:1497:1: ( ( rule__SmartContract__NameContractAssignment_7 ) )
            {
            // InternalSM2.g:1497:1: ( ( rule__SmartContract__NameContractAssignment_7 ) )
            // InternalSM2.g:1498:2: ( rule__SmartContract__NameContractAssignment_7 )
            {
             before(grammarAccess.getSmartContractAccess().getNameContractAssignment_7()); 
            // InternalSM2.g:1499:2: ( rule__SmartContract__NameContractAssignment_7 )
            // InternalSM2.g:1499:3: rule__SmartContract__NameContractAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__NameContractAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getNameContractAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__7__Impl"


    // $ANTLR start "rule__SmartContract__Group__8"
    // InternalSM2.g:1507:1: rule__SmartContract__Group__8 : rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9 ;
    public final void rule__SmartContract__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1511:1: ( rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9 )
            // InternalSM2.g:1512:2: rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9
            {
            pushFollow(FOLLOW_9);
            rule__SmartContract__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__8"


    // $ANTLR start "rule__SmartContract__Group__8__Impl"
    // InternalSM2.g:1519:1: rule__SmartContract__Group__8__Impl : ( ( rule__SmartContract__Group_8__0 )? ) ;
    public final void rule__SmartContract__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1523:1: ( ( ( rule__SmartContract__Group_8__0 )? ) )
            // InternalSM2.g:1524:1: ( ( rule__SmartContract__Group_8__0 )? )
            {
            // InternalSM2.g:1524:1: ( ( rule__SmartContract__Group_8__0 )? )
            // InternalSM2.g:1525:2: ( rule__SmartContract__Group_8__0 )?
            {
             before(grammarAccess.getSmartContractAccess().getGroup_8()); 
            // InternalSM2.g:1526:2: ( rule__SmartContract__Group_8__0 )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==58) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalSM2.g:1526:3: rule__SmartContract__Group_8__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SmartContract__Group_8__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSmartContractAccess().getGroup_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__8__Impl"


    // $ANTLR start "rule__SmartContract__Group__9"
    // InternalSM2.g:1534:1: rule__SmartContract__Group__9 : rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10 ;
    public final void rule__SmartContract__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1538:1: ( rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10 )
            // InternalSM2.g:1539:2: rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__9"


    // $ANTLR start "rule__SmartContract__Group__9__Impl"
    // InternalSM2.g:1546:1: rule__SmartContract__Group__9__Impl : ( RULE_OPENKEY ) ;
    public final void rule__SmartContract__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1550:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:1551:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:1551:1: ( RULE_OPENKEY )
            // InternalSM2.g:1552:2: RULE_OPENKEY
            {
             before(grammarAccess.getSmartContractAccess().getOPENKEYTerminalRuleCall_9()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getOPENKEYTerminalRuleCall_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__9__Impl"


    // $ANTLR start "rule__SmartContract__Group__10"
    // InternalSM2.g:1561:1: rule__SmartContract__Group__10 : rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11 ;
    public final void rule__SmartContract__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1565:1: ( rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11 )
            // InternalSM2.g:1566:2: rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__10"


    // $ANTLR start "rule__SmartContract__Group__10__Impl"
    // InternalSM2.g:1573:1: rule__SmartContract__Group__10__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__SmartContract__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1577:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:1578:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:1578:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:1579:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_10()); 
            // InternalSM2.g:1580:2: ( RULE_EOLINE )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==RULE_EOLINE) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalSM2.g:1580:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__10__Impl"


    // $ANTLR start "rule__SmartContract__Group__11"
    // InternalSM2.g:1588:1: rule__SmartContract__Group__11 : rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12 ;
    public final void rule__SmartContract__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1592:1: ( rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12 )
            // InternalSM2.g:1593:2: rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__11"


    // $ANTLR start "rule__SmartContract__Group__11__Impl"
    // InternalSM2.g:1600:1: rule__SmartContract__Group__11__Impl : ( ( rule__SmartContract__AttributesAssignment_11 )* ) ;
    public final void rule__SmartContract__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1604:1: ( ( ( rule__SmartContract__AttributesAssignment_11 )* ) )
            // InternalSM2.g:1605:1: ( ( rule__SmartContract__AttributesAssignment_11 )* )
            {
            // InternalSM2.g:1605:1: ( ( rule__SmartContract__AttributesAssignment_11 )* )
            // InternalSM2.g:1606:2: ( rule__SmartContract__AttributesAssignment_11 )*
            {
             before(grammarAccess.getSmartContractAccess().getAttributesAssignment_11()); 
            // InternalSM2.g:1607:2: ( rule__SmartContract__AttributesAssignment_11 )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( (LA24_0==RULE_ID||(LA24_0>=30 && LA24_0<=38)||LA24_0==64||(LA24_0>=66 && LA24_0<=67)) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalSM2.g:1607:3: rule__SmartContract__AttributesAssignment_11
            	    {
            	    pushFollow(FOLLOW_11);
            	    rule__SmartContract__AttributesAssignment_11();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getAttributesAssignment_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__11__Impl"


    // $ANTLR start "rule__SmartContract__Group__12"
    // InternalSM2.g:1615:1: rule__SmartContract__Group__12 : rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13 ;
    public final void rule__SmartContract__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1619:1: ( rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13 )
            // InternalSM2.g:1620:2: rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__12"


    // $ANTLR start "rule__SmartContract__Group__12__Impl"
    // InternalSM2.g:1627:1: rule__SmartContract__Group__12__Impl : ( ( rule__SmartContract__EventsAssignment_12 )* ) ;
    public final void rule__SmartContract__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1631:1: ( ( ( rule__SmartContract__EventsAssignment_12 )* ) )
            // InternalSM2.g:1632:1: ( ( rule__SmartContract__EventsAssignment_12 )* )
            {
            // InternalSM2.g:1632:1: ( ( rule__SmartContract__EventsAssignment_12 )* )
            // InternalSM2.g:1633:2: ( rule__SmartContract__EventsAssignment_12 )*
            {
             before(grammarAccess.getSmartContractAccess().getEventsAssignment_12()); 
            // InternalSM2.g:1634:2: ( rule__SmartContract__EventsAssignment_12 )*
            loop25:
            do {
                int alt25=2;
                int LA25_0 = input.LA(1);

                if ( (LA25_0==61) ) {
                    alt25=1;
                }


                switch (alt25) {
            	case 1 :
            	    // InternalSM2.g:1634:3: rule__SmartContract__EventsAssignment_12
            	    {
            	    pushFollow(FOLLOW_12);
            	    rule__SmartContract__EventsAssignment_12();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop25;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getEventsAssignment_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__12__Impl"


    // $ANTLR start "rule__SmartContract__Group__13"
    // InternalSM2.g:1642:1: rule__SmartContract__Group__13 : rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14 ;
    public final void rule__SmartContract__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1646:1: ( rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14 )
            // InternalSM2.g:1647:2: rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__13"


    // $ANTLR start "rule__SmartContract__Group__13__Impl"
    // InternalSM2.g:1654:1: rule__SmartContract__Group__13__Impl : ( ( rule__SmartContract__ModifierAssignment_13 )* ) ;
    public final void rule__SmartContract__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1658:1: ( ( ( rule__SmartContract__ModifierAssignment_13 )* ) )
            // InternalSM2.g:1659:1: ( ( rule__SmartContract__ModifierAssignment_13 )* )
            {
            // InternalSM2.g:1659:1: ( ( rule__SmartContract__ModifierAssignment_13 )* )
            // InternalSM2.g:1660:2: ( rule__SmartContract__ModifierAssignment_13 )*
            {
             before(grammarAccess.getSmartContractAccess().getModifierAssignment_13()); 
            // InternalSM2.g:1661:2: ( rule__SmartContract__ModifierAssignment_13 )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0==62) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalSM2.g:1661:3: rule__SmartContract__ModifierAssignment_13
            	    {
            	    pushFollow(FOLLOW_13);
            	    rule__SmartContract__ModifierAssignment_13();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getModifierAssignment_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__13__Impl"


    // $ANTLR start "rule__SmartContract__Group__14"
    // InternalSM2.g:1669:1: rule__SmartContract__Group__14 : rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15 ;
    public final void rule__SmartContract__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1673:1: ( rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15 )
            // InternalSM2.g:1674:2: rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__14__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__15();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__14"


    // $ANTLR start "rule__SmartContract__Group__14__Impl"
    // InternalSM2.g:1681:1: rule__SmartContract__Group__14__Impl : ( ( rule__SmartContract__ClausesAssignment_14 )* ) ;
    public final void rule__SmartContract__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1685:1: ( ( ( rule__SmartContract__ClausesAssignment_14 )* ) )
            // InternalSM2.g:1686:1: ( ( rule__SmartContract__ClausesAssignment_14 )* )
            {
            // InternalSM2.g:1686:1: ( ( rule__SmartContract__ClausesAssignment_14 )* )
            // InternalSM2.g:1687:2: ( rule__SmartContract__ClausesAssignment_14 )*
            {
             before(grammarAccess.getSmartContractAccess().getClausesAssignment_14()); 
            // InternalSM2.g:1688:2: ( rule__SmartContract__ClausesAssignment_14 )*
            loop27:
            do {
                int alt27=2;
                int LA27_0 = input.LA(1);

                if ( (LA27_0==70) ) {
                    alt27=1;
                }


                switch (alt27) {
            	case 1 :
            	    // InternalSM2.g:1688:3: rule__SmartContract__ClausesAssignment_14
            	    {
            	    pushFollow(FOLLOW_14);
            	    rule__SmartContract__ClausesAssignment_14();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop27;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getClausesAssignment_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__14__Impl"


    // $ANTLR start "rule__SmartContract__Group__15"
    // InternalSM2.g:1696:1: rule__SmartContract__Group__15 : rule__SmartContract__Group__15__Impl rule__SmartContract__Group__16 ;
    public final void rule__SmartContract__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1700:1: ( rule__SmartContract__Group__15__Impl rule__SmartContract__Group__16 )
            // InternalSM2.g:1701:2: rule__SmartContract__Group__15__Impl rule__SmartContract__Group__16
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__15__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__16();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__15"


    // $ANTLR start "rule__SmartContract__Group__15__Impl"
    // InternalSM2.g:1708:1: rule__SmartContract__Group__15__Impl : ( ( rule__SmartContract__CommentsAssignment_15 )* ) ;
    public final void rule__SmartContract__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1712:1: ( ( ( rule__SmartContract__CommentsAssignment_15 )* ) )
            // InternalSM2.g:1713:1: ( ( rule__SmartContract__CommentsAssignment_15 )* )
            {
            // InternalSM2.g:1713:1: ( ( rule__SmartContract__CommentsAssignment_15 )* )
            // InternalSM2.g:1714:2: ( rule__SmartContract__CommentsAssignment_15 )*
            {
             before(grammarAccess.getSmartContractAccess().getCommentsAssignment_15()); 
            // InternalSM2.g:1715:2: ( rule__SmartContract__CommentsAssignment_15 )*
            loop28:
            do {
                int alt28=2;
                int LA28_0 = input.LA(1);

                if ( ((LA28_0>=71 && LA28_0<=72)) ) {
                    alt28=1;
                }


                switch (alt28) {
            	case 1 :
            	    // InternalSM2.g:1715:3: rule__SmartContract__CommentsAssignment_15
            	    {
            	    pushFollow(FOLLOW_15);
            	    rule__SmartContract__CommentsAssignment_15();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop28;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getCommentsAssignment_15()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__15__Impl"


    // $ANTLR start "rule__SmartContract__Group__16"
    // InternalSM2.g:1723:1: rule__SmartContract__Group__16 : rule__SmartContract__Group__16__Impl ;
    public final void rule__SmartContract__Group__16() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1727:1: ( rule__SmartContract__Group__16__Impl )
            // InternalSM2.g:1728:2: rule__SmartContract__Group__16__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__16__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__16"


    // $ANTLR start "rule__SmartContract__Group__16__Impl"
    // InternalSM2.g:1734:1: rule__SmartContract__Group__16__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__SmartContract__Group__16__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1738:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:1739:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:1739:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:1740:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_16()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_16()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__16__Impl"


    // $ANTLR start "rule__SmartContract__Group_8__0"
    // InternalSM2.g:1750:1: rule__SmartContract__Group_8__0 : rule__SmartContract__Group_8__0__Impl rule__SmartContract__Group_8__1 ;
    public final void rule__SmartContract__Group_8__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1754:1: ( rule__SmartContract__Group_8__0__Impl rule__SmartContract__Group_8__1 )
            // InternalSM2.g:1755:2: rule__SmartContract__Group_8__0__Impl rule__SmartContract__Group_8__1
            {
            pushFollow(FOLLOW_8);
            rule__SmartContract__Group_8__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group_8__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__0"


    // $ANTLR start "rule__SmartContract__Group_8__0__Impl"
    // InternalSM2.g:1762:1: rule__SmartContract__Group_8__0__Impl : ( 'is' ) ;
    public final void rule__SmartContract__Group_8__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1766:1: ( ( 'is' ) )
            // InternalSM2.g:1767:1: ( 'is' )
            {
            // InternalSM2.g:1767:1: ( 'is' )
            // InternalSM2.g:1768:2: 'is'
            {
             before(grammarAccess.getSmartContractAccess().getIsKeyword_8_0()); 
            match(input,58,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getIsKeyword_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__0__Impl"


    // $ANTLR start "rule__SmartContract__Group_8__1"
    // InternalSM2.g:1777:1: rule__SmartContract__Group_8__1 : rule__SmartContract__Group_8__1__Impl ;
    public final void rule__SmartContract__Group_8__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1781:1: ( rule__SmartContract__Group_8__1__Impl )
            // InternalSM2.g:1782:2: rule__SmartContract__Group_8__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group_8__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__1"


    // $ANTLR start "rule__SmartContract__Group_8__1__Impl"
    // InternalSM2.g:1788:1: rule__SmartContract__Group_8__1__Impl : ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) ) ;
    public final void rule__SmartContract__Group_8__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1792:1: ( ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) ) )
            // InternalSM2.g:1793:1: ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) )
            {
            // InternalSM2.g:1793:1: ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) )
            // InternalSM2.g:1794:2: ( rule__SmartContract__NameContractFatherAssignment_8_1 )
            {
             before(grammarAccess.getSmartContractAccess().getNameContractFatherAssignment_8_1()); 
            // InternalSM2.g:1795:2: ( rule__SmartContract__NameContractFatherAssignment_8_1 )
            // InternalSM2.g:1795:3: rule__SmartContract__NameContractFatherAssignment_8_1
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__NameContractFatherAssignment_8_1();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getNameContractFatherAssignment_8_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__1__Impl"


    // $ANTLR start "rule__Version__Group_0__0"
    // InternalSM2.g:1804:1: rule__Version__Group_0__0 : rule__Version__Group_0__0__Impl rule__Version__Group_0__1 ;
    public final void rule__Version__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1808:1: ( rule__Version__Group_0__0__Impl rule__Version__Group_0__1 )
            // InternalSM2.g:1809:2: rule__Version__Group_0__0__Impl rule__Version__Group_0__1
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__0"


    // $ANTLR start "rule__Version__Group_0__0__Impl"
    // InternalSM2.g:1816:1: rule__Version__Group_0__0__Impl : ( ( rule__Version__SymbolAssignment_0_0 ) ) ;
    public final void rule__Version__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1820:1: ( ( ( rule__Version__SymbolAssignment_0_0 ) ) )
            // InternalSM2.g:1821:1: ( ( rule__Version__SymbolAssignment_0_0 ) )
            {
            // InternalSM2.g:1821:1: ( ( rule__Version__SymbolAssignment_0_0 ) )
            // InternalSM2.g:1822:2: ( rule__Version__SymbolAssignment_0_0 )
            {
             before(grammarAccess.getVersionAccess().getSymbolAssignment_0_0()); 
            // InternalSM2.g:1823:2: ( rule__Version__SymbolAssignment_0_0 )
            // InternalSM2.g:1823:3: rule__Version__SymbolAssignment_0_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAssignment_0_0();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getSymbolAssignment_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__0__Impl"


    // $ANTLR start "rule__Version__Group_0__1"
    // InternalSM2.g:1831:1: rule__Version__Group_0__1 : rule__Version__Group_0__1__Impl rule__Version__Group_0__2 ;
    public final void rule__Version__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1835:1: ( rule__Version__Group_0__1__Impl rule__Version__Group_0__2 )
            // InternalSM2.g:1836:2: rule__Version__Group_0__1__Impl rule__Version__Group_0__2
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__1"


    // $ANTLR start "rule__Version__Group_0__1__Impl"
    // InternalSM2.g:1843:1: rule__Version__Group_0__1__Impl : ( ( rule__Version__NumberVersionAssignment_0_1 ) ) ;
    public final void rule__Version__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1847:1: ( ( ( rule__Version__NumberVersionAssignment_0_1 ) ) )
            // InternalSM2.g:1848:1: ( ( rule__Version__NumberVersionAssignment_0_1 ) )
            {
            // InternalSM2.g:1848:1: ( ( rule__Version__NumberVersionAssignment_0_1 ) )
            // InternalSM2.g:1849:2: ( rule__Version__NumberVersionAssignment_0_1 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersionAssignment_0_1()); 
            // InternalSM2.g:1850:2: ( rule__Version__NumberVersionAssignment_0_1 )
            // InternalSM2.g:1850:3: rule__Version__NumberVersionAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersionAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__1__Impl"


    // $ANTLR start "rule__Version__Group_0__2"
    // InternalSM2.g:1858:1: rule__Version__Group_0__2 : rule__Version__Group_0__2__Impl rule__Version__Group_0__3 ;
    public final void rule__Version__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1862:1: ( rule__Version__Group_0__2__Impl rule__Version__Group_0__3 )
            // InternalSM2.g:1863:2: rule__Version__Group_0__2__Impl rule__Version__Group_0__3
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__2"


    // $ANTLR start "rule__Version__Group_0__2__Impl"
    // InternalSM2.g:1870:1: rule__Version__Group_0__2__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1874:1: ( ( RULE_DOT ) )
            // InternalSM2.g:1875:1: ( RULE_DOT )
            {
            // InternalSM2.g:1875:1: ( RULE_DOT )
            // InternalSM2.g:1876:2: RULE_DOT
            {
             before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_2()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__2__Impl"


    // $ANTLR start "rule__Version__Group_0__3"
    // InternalSM2.g:1885:1: rule__Version__Group_0__3 : rule__Version__Group_0__3__Impl rule__Version__Group_0__4 ;
    public final void rule__Version__Group_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1889:1: ( rule__Version__Group_0__3__Impl rule__Version__Group_0__4 )
            // InternalSM2.g:1890:2: rule__Version__Group_0__3__Impl rule__Version__Group_0__4
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_0__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_0__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__3"


    // $ANTLR start "rule__Version__Group_0__3__Impl"
    // InternalSM2.g:1897:1: rule__Version__Group_0__3__Impl : ( ( rule__Version__NumberVersion2Assignment_0_3 ) ) ;
    public final void rule__Version__Group_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1901:1: ( ( ( rule__Version__NumberVersion2Assignment_0_3 ) ) )
            // InternalSM2.g:1902:1: ( ( rule__Version__NumberVersion2Assignment_0_3 ) )
            {
            // InternalSM2.g:1902:1: ( ( rule__Version__NumberVersion2Assignment_0_3 ) )
            // InternalSM2.g:1903:2: ( rule__Version__NumberVersion2Assignment_0_3 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersion2Assignment_0_3()); 
            // InternalSM2.g:1904:2: ( rule__Version__NumberVersion2Assignment_0_3 )
            // InternalSM2.g:1904:3: rule__Version__NumberVersion2Assignment_0_3
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion2Assignment_0_3();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersion2Assignment_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__3__Impl"


    // $ANTLR start "rule__Version__Group_0__4"
    // InternalSM2.g:1912:1: rule__Version__Group_0__4 : rule__Version__Group_0__4__Impl rule__Version__Group_0__5 ;
    public final void rule__Version__Group_0__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1916:1: ( rule__Version__Group_0__4__Impl rule__Version__Group_0__5 )
            // InternalSM2.g:1917:2: rule__Version__Group_0__4__Impl rule__Version__Group_0__5
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_0__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_0__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__4"


    // $ANTLR start "rule__Version__Group_0__4__Impl"
    // InternalSM2.g:1924:1: rule__Version__Group_0__4__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_0__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1928:1: ( ( RULE_DOT ) )
            // InternalSM2.g:1929:1: ( RULE_DOT )
            {
            // InternalSM2.g:1929:1: ( RULE_DOT )
            // InternalSM2.g:1930:2: RULE_DOT
            {
             before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_4()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__4__Impl"


    // $ANTLR start "rule__Version__Group_0__5"
    // InternalSM2.g:1939:1: rule__Version__Group_0__5 : rule__Version__Group_0__5__Impl ;
    public final void rule__Version__Group_0__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1943:1: ( rule__Version__Group_0__5__Impl )
            // InternalSM2.g:1944:2: rule__Version__Group_0__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group_0__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__5"


    // $ANTLR start "rule__Version__Group_0__5__Impl"
    // InternalSM2.g:1950:1: rule__Version__Group_0__5__Impl : ( ( rule__Version__NumberVersion3Assignment_0_5 ) ) ;
    public final void rule__Version__Group_0__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1954:1: ( ( ( rule__Version__NumberVersion3Assignment_0_5 ) ) )
            // InternalSM2.g:1955:1: ( ( rule__Version__NumberVersion3Assignment_0_5 ) )
            {
            // InternalSM2.g:1955:1: ( ( rule__Version__NumberVersion3Assignment_0_5 ) )
            // InternalSM2.g:1956:2: ( rule__Version__NumberVersion3Assignment_0_5 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersion3Assignment_0_5()); 
            // InternalSM2.g:1957:2: ( rule__Version__NumberVersion3Assignment_0_5 )
            // InternalSM2.g:1957:3: rule__Version__NumberVersion3Assignment_0_5
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion3Assignment_0_5();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersion3Assignment_0_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__5__Impl"


    // $ANTLR start "rule__Version__Group_1__0"
    // InternalSM2.g:1966:1: rule__Version__Group_1__0 : rule__Version__Group_1__0__Impl rule__Version__Group_1__1 ;
    public final void rule__Version__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1970:1: ( rule__Version__Group_1__0__Impl rule__Version__Group_1__1 )
            // InternalSM2.g:1971:2: rule__Version__Group_1__0__Impl rule__Version__Group_1__1
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__0"


    // $ANTLR start "rule__Version__Group_1__0__Impl"
    // InternalSM2.g:1978:1: rule__Version__Group_1__0__Impl : ( ( rule__Version__SymbolAssignment_1_0 ) ) ;
    public final void rule__Version__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1982:1: ( ( ( rule__Version__SymbolAssignment_1_0 ) ) )
            // InternalSM2.g:1983:1: ( ( rule__Version__SymbolAssignment_1_0 ) )
            {
            // InternalSM2.g:1983:1: ( ( rule__Version__SymbolAssignment_1_0 ) )
            // InternalSM2.g:1984:2: ( rule__Version__SymbolAssignment_1_0 )
            {
             before(grammarAccess.getVersionAccess().getSymbolAssignment_1_0()); 
            // InternalSM2.g:1985:2: ( rule__Version__SymbolAssignment_1_0 )
            // InternalSM2.g:1985:3: rule__Version__SymbolAssignment_1_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAssignment_1_0();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getSymbolAssignment_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__0__Impl"


    // $ANTLR start "rule__Version__Group_1__1"
    // InternalSM2.g:1993:1: rule__Version__Group_1__1 : rule__Version__Group_1__1__Impl rule__Version__Group_1__2 ;
    public final void rule__Version__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1997:1: ( rule__Version__Group_1__1__Impl rule__Version__Group_1__2 )
            // InternalSM2.g:1998:2: rule__Version__Group_1__1__Impl rule__Version__Group_1__2
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__1"


    // $ANTLR start "rule__Version__Group_1__1__Impl"
    // InternalSM2.g:2005:1: rule__Version__Group_1__1__Impl : ( ( rule__Version__NumberVersionAssignment_1_1 ) ) ;
    public final void rule__Version__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2009:1: ( ( ( rule__Version__NumberVersionAssignment_1_1 ) ) )
            // InternalSM2.g:2010:1: ( ( rule__Version__NumberVersionAssignment_1_1 ) )
            {
            // InternalSM2.g:2010:1: ( ( rule__Version__NumberVersionAssignment_1_1 ) )
            // InternalSM2.g:2011:2: ( rule__Version__NumberVersionAssignment_1_1 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersionAssignment_1_1()); 
            // InternalSM2.g:2012:2: ( rule__Version__NumberVersionAssignment_1_1 )
            // InternalSM2.g:2012:3: rule__Version__NumberVersionAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersionAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__1__Impl"


    // $ANTLR start "rule__Version__Group_1__2"
    // InternalSM2.g:2020:1: rule__Version__Group_1__2 : rule__Version__Group_1__2__Impl rule__Version__Group_1__3 ;
    public final void rule__Version__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2024:1: ( rule__Version__Group_1__2__Impl rule__Version__Group_1__3 )
            // InternalSM2.g:2025:2: rule__Version__Group_1__2__Impl rule__Version__Group_1__3
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_1__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_1__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__2"


    // $ANTLR start "rule__Version__Group_1__2__Impl"
    // InternalSM2.g:2032:1: rule__Version__Group_1__2__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2036:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2037:1: ( RULE_DOT )
            {
            // InternalSM2.g:2037:1: ( RULE_DOT )
            // InternalSM2.g:2038:2: RULE_DOT
            {
             before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_2()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__2__Impl"


    // $ANTLR start "rule__Version__Group_1__3"
    // InternalSM2.g:2047:1: rule__Version__Group_1__3 : rule__Version__Group_1__3__Impl rule__Version__Group_1__4 ;
    public final void rule__Version__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2051:1: ( rule__Version__Group_1__3__Impl rule__Version__Group_1__4 )
            // InternalSM2.g:2052:2: rule__Version__Group_1__3__Impl rule__Version__Group_1__4
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_1__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_1__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__3"


    // $ANTLR start "rule__Version__Group_1__3__Impl"
    // InternalSM2.g:2059:1: rule__Version__Group_1__3__Impl : ( ( rule__Version__NumberVersion2Assignment_1_3 ) ) ;
    public final void rule__Version__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2063:1: ( ( ( rule__Version__NumberVersion2Assignment_1_3 ) ) )
            // InternalSM2.g:2064:1: ( ( rule__Version__NumberVersion2Assignment_1_3 ) )
            {
            // InternalSM2.g:2064:1: ( ( rule__Version__NumberVersion2Assignment_1_3 ) )
            // InternalSM2.g:2065:2: ( rule__Version__NumberVersion2Assignment_1_3 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersion2Assignment_1_3()); 
            // InternalSM2.g:2066:2: ( rule__Version__NumberVersion2Assignment_1_3 )
            // InternalSM2.g:2066:3: rule__Version__NumberVersion2Assignment_1_3
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion2Assignment_1_3();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersion2Assignment_1_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__3__Impl"


    // $ANTLR start "rule__Version__Group_1__4"
    // InternalSM2.g:2074:1: rule__Version__Group_1__4 : rule__Version__Group_1__4__Impl rule__Version__Group_1__5 ;
    public final void rule__Version__Group_1__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2078:1: ( rule__Version__Group_1__4__Impl rule__Version__Group_1__5 )
            // InternalSM2.g:2079:2: rule__Version__Group_1__4__Impl rule__Version__Group_1__5
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_1__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_1__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__4"


    // $ANTLR start "rule__Version__Group_1__4__Impl"
    // InternalSM2.g:2086:1: rule__Version__Group_1__4__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_1__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2090:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2091:1: ( RULE_DOT )
            {
            // InternalSM2.g:2091:1: ( RULE_DOT )
            // InternalSM2.g:2092:2: RULE_DOT
            {
             before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_4()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__4__Impl"


    // $ANTLR start "rule__Version__Group_1__5"
    // InternalSM2.g:2101:1: rule__Version__Group_1__5 : rule__Version__Group_1__5__Impl rule__Version__Group_1__6 ;
    public final void rule__Version__Group_1__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2105:1: ( rule__Version__Group_1__5__Impl rule__Version__Group_1__6 )
            // InternalSM2.g:2106:2: rule__Version__Group_1__5__Impl rule__Version__Group_1__6
            {
            pushFollow(FOLLOW_18);
            rule__Version__Group_1__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_1__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__5"


    // $ANTLR start "rule__Version__Group_1__5__Impl"
    // InternalSM2.g:2113:1: rule__Version__Group_1__5__Impl : ( ( rule__Version__NumberVersion3Assignment_1_5 ) ) ;
    public final void rule__Version__Group_1__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2117:1: ( ( ( rule__Version__NumberVersion3Assignment_1_5 ) ) )
            // InternalSM2.g:2118:1: ( ( rule__Version__NumberVersion3Assignment_1_5 ) )
            {
            // InternalSM2.g:2118:1: ( ( rule__Version__NumberVersion3Assignment_1_5 ) )
            // InternalSM2.g:2119:2: ( rule__Version__NumberVersion3Assignment_1_5 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersion3Assignment_1_5()); 
            // InternalSM2.g:2120:2: ( rule__Version__NumberVersion3Assignment_1_5 )
            // InternalSM2.g:2120:3: rule__Version__NumberVersion3Assignment_1_5
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion3Assignment_1_5();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersion3Assignment_1_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__5__Impl"


    // $ANTLR start "rule__Version__Group_1__6"
    // InternalSM2.g:2128:1: rule__Version__Group_1__6 : rule__Version__Group_1__6__Impl ;
    public final void rule__Version__Group_1__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2132:1: ( rule__Version__Group_1__6__Impl )
            // InternalSM2.g:2133:2: rule__Version__Group_1__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__6"


    // $ANTLR start "rule__Version__Group_1__6__Impl"
    // InternalSM2.g:2139:1: rule__Version__Group_1__6__Impl : ( ( rule__Version__Group_1_6__0 )? ) ;
    public final void rule__Version__Group_1__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2143:1: ( ( ( rule__Version__Group_1_6__0 )? ) )
            // InternalSM2.g:2144:1: ( ( rule__Version__Group_1_6__0 )? )
            {
            // InternalSM2.g:2144:1: ( ( rule__Version__Group_1_6__0 )? )
            // InternalSM2.g:2145:2: ( rule__Version__Group_1_6__0 )?
            {
             before(grammarAccess.getVersionAccess().getGroup_1_6()); 
            // InternalSM2.g:2146:2: ( rule__Version__Group_1_6__0 )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( ((LA29_0>=28 && LA29_0<=29)) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalSM2.g:2146:3: rule__Version__Group_1_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Version__Group_1_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getVersionAccess().getGroup_1_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__6__Impl"


    // $ANTLR start "rule__Version__Group_1_6__0"
    // InternalSM2.g:2155:1: rule__Version__Group_1_6__0 : rule__Version__Group_1_6__0__Impl rule__Version__Group_1_6__1 ;
    public final void rule__Version__Group_1_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2159:1: ( rule__Version__Group_1_6__0__Impl rule__Version__Group_1_6__1 )
            // InternalSM2.g:2160:2: rule__Version__Group_1_6__0__Impl rule__Version__Group_1_6__1
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_1_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__0"


    // $ANTLR start "rule__Version__Group_1_6__0__Impl"
    // InternalSM2.g:2167:1: rule__Version__Group_1_6__0__Impl : ( ( rule__Version__Symbol2Assignment_1_6_0 ) ) ;
    public final void rule__Version__Group_1_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2171:1: ( ( ( rule__Version__Symbol2Assignment_1_6_0 ) ) )
            // InternalSM2.g:2172:1: ( ( rule__Version__Symbol2Assignment_1_6_0 ) )
            {
            // InternalSM2.g:2172:1: ( ( rule__Version__Symbol2Assignment_1_6_0 ) )
            // InternalSM2.g:2173:2: ( rule__Version__Symbol2Assignment_1_6_0 )
            {
             before(grammarAccess.getVersionAccess().getSymbol2Assignment_1_6_0()); 
            // InternalSM2.g:2174:2: ( rule__Version__Symbol2Assignment_1_6_0 )
            // InternalSM2.g:2174:3: rule__Version__Symbol2Assignment_1_6_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__Symbol2Assignment_1_6_0();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getSymbol2Assignment_1_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__0__Impl"


    // $ANTLR start "rule__Version__Group_1_6__1"
    // InternalSM2.g:2182:1: rule__Version__Group_1_6__1 : rule__Version__Group_1_6__1__Impl rule__Version__Group_1_6__2 ;
    public final void rule__Version__Group_1_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2186:1: ( rule__Version__Group_1_6__1__Impl rule__Version__Group_1_6__2 )
            // InternalSM2.g:2187:2: rule__Version__Group_1_6__1__Impl rule__Version__Group_1_6__2
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_1_6__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__1"


    // $ANTLR start "rule__Version__Group_1_6__1__Impl"
    // InternalSM2.g:2194:1: rule__Version__Group_1_6__1__Impl : ( ( rule__Version__NumberVersionOptionalAssignment_1_6_1 ) ) ;
    public final void rule__Version__Group_1_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2198:1: ( ( ( rule__Version__NumberVersionOptionalAssignment_1_6_1 ) ) )
            // InternalSM2.g:2199:1: ( ( rule__Version__NumberVersionOptionalAssignment_1_6_1 ) )
            {
            // InternalSM2.g:2199:1: ( ( rule__Version__NumberVersionOptionalAssignment_1_6_1 ) )
            // InternalSM2.g:2200:2: ( rule__Version__NumberVersionOptionalAssignment_1_6_1 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersionOptionalAssignment_1_6_1()); 
            // InternalSM2.g:2201:2: ( rule__Version__NumberVersionOptionalAssignment_1_6_1 )
            // InternalSM2.g:2201:3: rule__Version__NumberVersionOptionalAssignment_1_6_1
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionOptionalAssignment_1_6_1();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersionOptionalAssignment_1_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__1__Impl"


    // $ANTLR start "rule__Version__Group_1_6__2"
    // InternalSM2.g:2209:1: rule__Version__Group_1_6__2 : rule__Version__Group_1_6__2__Impl rule__Version__Group_1_6__3 ;
    public final void rule__Version__Group_1_6__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2213:1: ( rule__Version__Group_1_6__2__Impl rule__Version__Group_1_6__3 )
            // InternalSM2.g:2214:2: rule__Version__Group_1_6__2__Impl rule__Version__Group_1_6__3
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_1_6__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__2"


    // $ANTLR start "rule__Version__Group_1_6__2__Impl"
    // InternalSM2.g:2221:1: rule__Version__Group_1_6__2__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_1_6__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2225:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2226:1: ( RULE_DOT )
            {
            // InternalSM2.g:2226:1: ( RULE_DOT )
            // InternalSM2.g:2227:2: RULE_DOT
            {
             before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_2()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__2__Impl"


    // $ANTLR start "rule__Version__Group_1_6__3"
    // InternalSM2.g:2236:1: rule__Version__Group_1_6__3 : rule__Version__Group_1_6__3__Impl rule__Version__Group_1_6__4 ;
    public final void rule__Version__Group_1_6__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2240:1: ( rule__Version__Group_1_6__3__Impl rule__Version__Group_1_6__4 )
            // InternalSM2.g:2241:2: rule__Version__Group_1_6__3__Impl rule__Version__Group_1_6__4
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_1_6__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__3"


    // $ANTLR start "rule__Version__Group_1_6__3__Impl"
    // InternalSM2.g:2248:1: rule__Version__Group_1_6__3__Impl : ( ( rule__Version__NumberVersionOptional2Assignment_1_6_3 ) ) ;
    public final void rule__Version__Group_1_6__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2252:1: ( ( ( rule__Version__NumberVersionOptional2Assignment_1_6_3 ) ) )
            // InternalSM2.g:2253:1: ( ( rule__Version__NumberVersionOptional2Assignment_1_6_3 ) )
            {
            // InternalSM2.g:2253:1: ( ( rule__Version__NumberVersionOptional2Assignment_1_6_3 ) )
            // InternalSM2.g:2254:2: ( rule__Version__NumberVersionOptional2Assignment_1_6_3 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersionOptional2Assignment_1_6_3()); 
            // InternalSM2.g:2255:2: ( rule__Version__NumberVersionOptional2Assignment_1_6_3 )
            // InternalSM2.g:2255:3: rule__Version__NumberVersionOptional2Assignment_1_6_3
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionOptional2Assignment_1_6_3();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersionOptional2Assignment_1_6_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__3__Impl"


    // $ANTLR start "rule__Version__Group_1_6__4"
    // InternalSM2.g:2263:1: rule__Version__Group_1_6__4 : rule__Version__Group_1_6__4__Impl rule__Version__Group_1_6__5 ;
    public final void rule__Version__Group_1_6__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2267:1: ( rule__Version__Group_1_6__4__Impl rule__Version__Group_1_6__5 )
            // InternalSM2.g:2268:2: rule__Version__Group_1_6__4__Impl rule__Version__Group_1_6__5
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_1_6__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__4"


    // $ANTLR start "rule__Version__Group_1_6__4__Impl"
    // InternalSM2.g:2275:1: rule__Version__Group_1_6__4__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_1_6__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2279:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2280:1: ( RULE_DOT )
            {
            // InternalSM2.g:2280:1: ( RULE_DOT )
            // InternalSM2.g:2281:2: RULE_DOT
            {
             before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_4()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__4__Impl"


    // $ANTLR start "rule__Version__Group_1_6__5"
    // InternalSM2.g:2290:1: rule__Version__Group_1_6__5 : rule__Version__Group_1_6__5__Impl ;
    public final void rule__Version__Group_1_6__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2294:1: ( rule__Version__Group_1_6__5__Impl )
            // InternalSM2.g:2295:2: rule__Version__Group_1_6__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__5"


    // $ANTLR start "rule__Version__Group_1_6__5__Impl"
    // InternalSM2.g:2301:1: rule__Version__Group_1_6__5__Impl : ( ( rule__Version__NumberVersionOptional3Assignment_1_6_5 ) ) ;
    public final void rule__Version__Group_1_6__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2305:1: ( ( ( rule__Version__NumberVersionOptional3Assignment_1_6_5 ) ) )
            // InternalSM2.g:2306:1: ( ( rule__Version__NumberVersionOptional3Assignment_1_6_5 ) )
            {
            // InternalSM2.g:2306:1: ( ( rule__Version__NumberVersionOptional3Assignment_1_6_5 ) )
            // InternalSM2.g:2307:2: ( rule__Version__NumberVersionOptional3Assignment_1_6_5 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersionOptional3Assignment_1_6_5()); 
            // InternalSM2.g:2308:2: ( rule__Version__NumberVersionOptional3Assignment_1_6_5 )
            // InternalSM2.g:2308:3: rule__Version__NumberVersionOptional3Assignment_1_6_5
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionOptional3Assignment_1_6_5();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersionOptional3Assignment_1_6_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__5__Impl"


    // $ANTLR start "rule__Import__Group__0"
    // InternalSM2.g:2317:1: rule__Import__Group__0 : rule__Import__Group__0__Impl rule__Import__Group__1 ;
    public final void rule__Import__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2321:1: ( rule__Import__Group__0__Impl rule__Import__Group__1 )
            // InternalSM2.g:2322:2: rule__Import__Group__0__Impl rule__Import__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Import__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0"


    // $ANTLR start "rule__Import__Group__0__Impl"
    // InternalSM2.g:2329:1: rule__Import__Group__0__Impl : ( 'import' ) ;
    public final void rule__Import__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2333:1: ( ( 'import' ) )
            // InternalSM2.g:2334:1: ( 'import' )
            {
            // InternalSM2.g:2334:1: ( 'import' )
            // InternalSM2.g:2335:2: 'import'
            {
             before(grammarAccess.getImportAccess().getImportKeyword_0()); 
            match(input,59,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getImportKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0__Impl"


    // $ANTLR start "rule__Import__Group__1"
    // InternalSM2.g:2344:1: rule__Import__Group__1 : rule__Import__Group__1__Impl rule__Import__Group__2 ;
    public final void rule__Import__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2348:1: ( rule__Import__Group__1__Impl rule__Import__Group__2 )
            // InternalSM2.g:2349:2: rule__Import__Group__1__Impl rule__Import__Group__2
            {
            pushFollow(FOLLOW_19);
            rule__Import__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1"


    // $ANTLR start "rule__Import__Group__1__Impl"
    // InternalSM2.g:2356:1: rule__Import__Group__1__Impl : ( ( rule__Import__NameLibraryAssignment_1 ) ) ;
    public final void rule__Import__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2360:1: ( ( ( rule__Import__NameLibraryAssignment_1 ) ) )
            // InternalSM2.g:2361:1: ( ( rule__Import__NameLibraryAssignment_1 ) )
            {
            // InternalSM2.g:2361:1: ( ( rule__Import__NameLibraryAssignment_1 ) )
            // InternalSM2.g:2362:2: ( rule__Import__NameLibraryAssignment_1 )
            {
             before(grammarAccess.getImportAccess().getNameLibraryAssignment_1()); 
            // InternalSM2.g:2363:2: ( rule__Import__NameLibraryAssignment_1 )
            // InternalSM2.g:2363:3: rule__Import__NameLibraryAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Import__NameLibraryAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getImportAccess().getNameLibraryAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1__Impl"


    // $ANTLR start "rule__Import__Group__2"
    // InternalSM2.g:2371:1: rule__Import__Group__2 : rule__Import__Group__2__Impl rule__Import__Group__3 ;
    public final void rule__Import__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2375:1: ( rule__Import__Group__2__Impl rule__Import__Group__3 )
            // InternalSM2.g:2376:2: rule__Import__Group__2__Impl rule__Import__Group__3
            {
            pushFollow(FOLLOW_19);
            rule__Import__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__2"


    // $ANTLR start "rule__Import__Group__2__Impl"
    // InternalSM2.g:2383:1: rule__Import__Group__2__Impl : ( ( rule__Import__Group_2__0 )? ) ;
    public final void rule__Import__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2387:1: ( ( ( rule__Import__Group_2__0 )? ) )
            // InternalSM2.g:2388:1: ( ( rule__Import__Group_2__0 )? )
            {
            // InternalSM2.g:2388:1: ( ( rule__Import__Group_2__0 )? )
            // InternalSM2.g:2389:2: ( rule__Import__Group_2__0 )?
            {
             before(grammarAccess.getImportAccess().getGroup_2()); 
            // InternalSM2.g:2390:2: ( rule__Import__Group_2__0 )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==60) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalSM2.g:2390:3: rule__Import__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Import__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getImportAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__2__Impl"


    // $ANTLR start "rule__Import__Group__3"
    // InternalSM2.g:2398:1: rule__Import__Group__3 : rule__Import__Group__3__Impl rule__Import__Group__4 ;
    public final void rule__Import__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2402:1: ( rule__Import__Group__3__Impl rule__Import__Group__4 )
            // InternalSM2.g:2403:2: rule__Import__Group__3__Impl rule__Import__Group__4
            {
            pushFollow(FOLLOW_20);
            rule__Import__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__3"


    // $ANTLR start "rule__Import__Group__3__Impl"
    // InternalSM2.g:2410:1: rule__Import__Group__3__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Import__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2414:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:2415:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:2415:1: ( RULE_SEMICOLON )
            // InternalSM2.g:2416:2: RULE_SEMICOLON
            {
             before(grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_3()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__3__Impl"


    // $ANTLR start "rule__Import__Group__4"
    // InternalSM2.g:2425:1: rule__Import__Group__4 : rule__Import__Group__4__Impl ;
    public final void rule__Import__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2429:1: ( rule__Import__Group__4__Impl )
            // InternalSM2.g:2430:2: rule__Import__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__4"


    // $ANTLR start "rule__Import__Group__4__Impl"
    // InternalSM2.g:2436:1: rule__Import__Group__4__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Import__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2440:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2441:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2441:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2442:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getImportAccess().getEOLINETerminalRuleCall_4()); 
            // InternalSM2.g:2443:2: ( RULE_EOLINE )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==RULE_EOLINE) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalSM2.g:2443:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getImportAccess().getEOLINETerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__4__Impl"


    // $ANTLR start "rule__Import__Group_2__0"
    // InternalSM2.g:2452:1: rule__Import__Group_2__0 : rule__Import__Group_2__0__Impl rule__Import__Group_2__1 ;
    public final void rule__Import__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2456:1: ( rule__Import__Group_2__0__Impl rule__Import__Group_2__1 )
            // InternalSM2.g:2457:2: rule__Import__Group_2__0__Impl rule__Import__Group_2__1
            {
            pushFollow(FOLLOW_8);
            rule__Import__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__0"


    // $ANTLR start "rule__Import__Group_2__0__Impl"
    // InternalSM2.g:2464:1: rule__Import__Group_2__0__Impl : ( 'as' ) ;
    public final void rule__Import__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2468:1: ( ( 'as' ) )
            // InternalSM2.g:2469:1: ( 'as' )
            {
            // InternalSM2.g:2469:1: ( 'as' )
            // InternalSM2.g:2470:2: 'as'
            {
             before(grammarAccess.getImportAccess().getAsKeyword_2_0()); 
            match(input,60,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getAsKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__0__Impl"


    // $ANTLR start "rule__Import__Group_2__1"
    // InternalSM2.g:2479:1: rule__Import__Group_2__1 : rule__Import__Group_2__1__Impl ;
    public final void rule__Import__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2483:1: ( rule__Import__Group_2__1__Impl )
            // InternalSM2.g:2484:2: rule__Import__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__1"


    // $ANTLR start "rule__Import__Group_2__1__Impl"
    // InternalSM2.g:2490:1: rule__Import__Group_2__1__Impl : ( ( rule__Import__AliasAssignment_2_1 ) ) ;
    public final void rule__Import__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2494:1: ( ( ( rule__Import__AliasAssignment_2_1 ) ) )
            // InternalSM2.g:2495:1: ( ( rule__Import__AliasAssignment_2_1 ) )
            {
            // InternalSM2.g:2495:1: ( ( rule__Import__AliasAssignment_2_1 ) )
            // InternalSM2.g:2496:2: ( rule__Import__AliasAssignment_2_1 )
            {
             before(grammarAccess.getImportAccess().getAliasAssignment_2_1()); 
            // InternalSM2.g:2497:2: ( rule__Import__AliasAssignment_2_1 )
            // InternalSM2.g:2497:3: rule__Import__AliasAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Import__AliasAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getImportAccess().getAliasAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__1__Impl"


    // $ANTLR start "rule__Event__Group__0"
    // InternalSM2.g:2506:1: rule__Event__Group__0 : rule__Event__Group__0__Impl rule__Event__Group__1 ;
    public final void rule__Event__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2510:1: ( rule__Event__Group__0__Impl rule__Event__Group__1 )
            // InternalSM2.g:2511:2: rule__Event__Group__0__Impl rule__Event__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Event__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Event__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__0"


    // $ANTLR start "rule__Event__Group__0__Impl"
    // InternalSM2.g:2518:1: rule__Event__Group__0__Impl : ( 'event' ) ;
    public final void rule__Event__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2522:1: ( ( 'event' ) )
            // InternalSM2.g:2523:1: ( 'event' )
            {
            // InternalSM2.g:2523:1: ( 'event' )
            // InternalSM2.g:2524:2: 'event'
            {
             before(grammarAccess.getEventAccess().getEventKeyword_0()); 
            match(input,61,FOLLOW_2); 
             after(grammarAccess.getEventAccess().getEventKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__0__Impl"


    // $ANTLR start "rule__Event__Group__1"
    // InternalSM2.g:2533:1: rule__Event__Group__1 : rule__Event__Group__1__Impl rule__Event__Group__2 ;
    public final void rule__Event__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2537:1: ( rule__Event__Group__1__Impl rule__Event__Group__2 )
            // InternalSM2.g:2538:2: rule__Event__Group__1__Impl rule__Event__Group__2
            {
            pushFollow(FOLLOW_21);
            rule__Event__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Event__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__1"


    // $ANTLR start "rule__Event__Group__1__Impl"
    // InternalSM2.g:2545:1: rule__Event__Group__1__Impl : ( ( rule__Event__NameEventAssignment_1 ) ) ;
    public final void rule__Event__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2549:1: ( ( ( rule__Event__NameEventAssignment_1 ) ) )
            // InternalSM2.g:2550:1: ( ( rule__Event__NameEventAssignment_1 ) )
            {
            // InternalSM2.g:2550:1: ( ( rule__Event__NameEventAssignment_1 ) )
            // InternalSM2.g:2551:2: ( rule__Event__NameEventAssignment_1 )
            {
             before(grammarAccess.getEventAccess().getNameEventAssignment_1()); 
            // InternalSM2.g:2552:2: ( rule__Event__NameEventAssignment_1 )
            // InternalSM2.g:2552:3: rule__Event__NameEventAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Event__NameEventAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEventAccess().getNameEventAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__1__Impl"


    // $ANTLR start "rule__Event__Group__2"
    // InternalSM2.g:2560:1: rule__Event__Group__2 : rule__Event__Group__2__Impl rule__Event__Group__3 ;
    public final void rule__Event__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2564:1: ( rule__Event__Group__2__Impl rule__Event__Group__3 )
            // InternalSM2.g:2565:2: rule__Event__Group__2__Impl rule__Event__Group__3
            {
            pushFollow(FOLLOW_22);
            rule__Event__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Event__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__2"


    // $ANTLR start "rule__Event__Group__2__Impl"
    // InternalSM2.g:2572:1: rule__Event__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Event__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2576:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:2577:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:2577:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:2578:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__2__Impl"


    // $ANTLR start "rule__Event__Group__3"
    // InternalSM2.g:2587:1: rule__Event__Group__3 : rule__Event__Group__3__Impl rule__Event__Group__4 ;
    public final void rule__Event__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2591:1: ( rule__Event__Group__3__Impl rule__Event__Group__4 )
            // InternalSM2.g:2592:2: rule__Event__Group__3__Impl rule__Event__Group__4
            {
            pushFollow(FOLLOW_22);
            rule__Event__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Event__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__3"


    // $ANTLR start "rule__Event__Group__3__Impl"
    // InternalSM2.g:2599:1: rule__Event__Group__3__Impl : ( ( rule__Event__InputParamsAssignment_3 )* ) ;
    public final void rule__Event__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2603:1: ( ( ( rule__Event__InputParamsAssignment_3 )* ) )
            // InternalSM2.g:2604:1: ( ( rule__Event__InputParamsAssignment_3 )* )
            {
            // InternalSM2.g:2604:1: ( ( rule__Event__InputParamsAssignment_3 )* )
            // InternalSM2.g:2605:2: ( rule__Event__InputParamsAssignment_3 )*
            {
             before(grammarAccess.getEventAccess().getInputParamsAssignment_3()); 
            // InternalSM2.g:2606:2: ( rule__Event__InputParamsAssignment_3 )*
            loop32:
            do {
                int alt32=2;
                int LA32_0 = input.LA(1);

                if ( ((LA32_0>=30 && LA32_0<=38)) ) {
                    alt32=1;
                }


                switch (alt32) {
            	case 1 :
            	    // InternalSM2.g:2606:3: rule__Event__InputParamsAssignment_3
            	    {
            	    pushFollow(FOLLOW_23);
            	    rule__Event__InputParamsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop32;
                }
            } while (true);

             after(grammarAccess.getEventAccess().getInputParamsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__3__Impl"


    // $ANTLR start "rule__Event__Group__4"
    // InternalSM2.g:2614:1: rule__Event__Group__4 : rule__Event__Group__4__Impl rule__Event__Group__5 ;
    public final void rule__Event__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2618:1: ( rule__Event__Group__4__Impl rule__Event__Group__5 )
            // InternalSM2.g:2619:2: rule__Event__Group__4__Impl rule__Event__Group__5
            {
            pushFollow(FOLLOW_5);
            rule__Event__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Event__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__4"


    // $ANTLR start "rule__Event__Group__4__Impl"
    // InternalSM2.g:2626:1: rule__Event__Group__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Event__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2630:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2631:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2631:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2632:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__4__Impl"


    // $ANTLR start "rule__Event__Group__5"
    // InternalSM2.g:2641:1: rule__Event__Group__5 : rule__Event__Group__5__Impl rule__Event__Group__6 ;
    public final void rule__Event__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2645:1: ( rule__Event__Group__5__Impl rule__Event__Group__6 )
            // InternalSM2.g:2646:2: rule__Event__Group__5__Impl rule__Event__Group__6
            {
            pushFollow(FOLLOW_20);
            rule__Event__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Event__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__5"


    // $ANTLR start "rule__Event__Group__5__Impl"
    // InternalSM2.g:2653:1: rule__Event__Group__5__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Event__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2657:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:2658:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:2658:1: ( RULE_SEMICOLON )
            // InternalSM2.g:2659:2: RULE_SEMICOLON
            {
             before(grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__5__Impl"


    // $ANTLR start "rule__Event__Group__6"
    // InternalSM2.g:2668:1: rule__Event__Group__6 : rule__Event__Group__6__Impl ;
    public final void rule__Event__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2672:1: ( rule__Event__Group__6__Impl )
            // InternalSM2.g:2673:2: rule__Event__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Event__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__6"


    // $ANTLR start "rule__Event__Group__6__Impl"
    // InternalSM2.g:2679:1: rule__Event__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Event__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2683:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2684:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2684:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2685:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6()); 
            // InternalSM2.g:2686:2: ( RULE_EOLINE )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==RULE_EOLINE) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // InternalSM2.g:2686:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__6__Impl"


    // $ANTLR start "rule__Modifier__Group__0"
    // InternalSM2.g:2695:1: rule__Modifier__Group__0 : rule__Modifier__Group__0__Impl rule__Modifier__Group__1 ;
    public final void rule__Modifier__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2699:1: ( rule__Modifier__Group__0__Impl rule__Modifier__Group__1 )
            // InternalSM2.g:2700:2: rule__Modifier__Group__0__Impl rule__Modifier__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Modifier__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__0"


    // $ANTLR start "rule__Modifier__Group__0__Impl"
    // InternalSM2.g:2707:1: rule__Modifier__Group__0__Impl : ( 'modifier' ) ;
    public final void rule__Modifier__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2711:1: ( ( 'modifier' ) )
            // InternalSM2.g:2712:1: ( 'modifier' )
            {
            // InternalSM2.g:2712:1: ( 'modifier' )
            // InternalSM2.g:2713:2: 'modifier'
            {
             before(grammarAccess.getModifierAccess().getModifierKeyword_0()); 
            match(input,62,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getModifierKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__0__Impl"


    // $ANTLR start "rule__Modifier__Group__1"
    // InternalSM2.g:2722:1: rule__Modifier__Group__1 : rule__Modifier__Group__1__Impl rule__Modifier__Group__2 ;
    public final void rule__Modifier__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2726:1: ( rule__Modifier__Group__1__Impl rule__Modifier__Group__2 )
            // InternalSM2.g:2727:2: rule__Modifier__Group__1__Impl rule__Modifier__Group__2
            {
            pushFollow(FOLLOW_21);
            rule__Modifier__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__1"


    // $ANTLR start "rule__Modifier__Group__1__Impl"
    // InternalSM2.g:2734:1: rule__Modifier__Group__1__Impl : ( ( rule__Modifier__NameModifierAssignment_1 ) ) ;
    public final void rule__Modifier__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2738:1: ( ( ( rule__Modifier__NameModifierAssignment_1 ) ) )
            // InternalSM2.g:2739:1: ( ( rule__Modifier__NameModifierAssignment_1 ) )
            {
            // InternalSM2.g:2739:1: ( ( rule__Modifier__NameModifierAssignment_1 ) )
            // InternalSM2.g:2740:2: ( rule__Modifier__NameModifierAssignment_1 )
            {
             before(grammarAccess.getModifierAccess().getNameModifierAssignment_1()); 
            // InternalSM2.g:2741:2: ( rule__Modifier__NameModifierAssignment_1 )
            // InternalSM2.g:2741:3: rule__Modifier__NameModifierAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__NameModifierAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getModifierAccess().getNameModifierAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__1__Impl"


    // $ANTLR start "rule__Modifier__Group__2"
    // InternalSM2.g:2749:1: rule__Modifier__Group__2 : rule__Modifier__Group__2__Impl rule__Modifier__Group__3 ;
    public final void rule__Modifier__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2753:1: ( rule__Modifier__Group__2__Impl rule__Modifier__Group__3 )
            // InternalSM2.g:2754:2: rule__Modifier__Group__2__Impl rule__Modifier__Group__3
            {
            pushFollow(FOLLOW_22);
            rule__Modifier__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__2"


    // $ANTLR start "rule__Modifier__Group__2__Impl"
    // InternalSM2.g:2761:1: rule__Modifier__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Modifier__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2765:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:2766:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:2766:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:2767:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__2__Impl"


    // $ANTLR start "rule__Modifier__Group__3"
    // InternalSM2.g:2776:1: rule__Modifier__Group__3 : rule__Modifier__Group__3__Impl rule__Modifier__Group__4 ;
    public final void rule__Modifier__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2780:1: ( rule__Modifier__Group__3__Impl rule__Modifier__Group__4 )
            // InternalSM2.g:2781:2: rule__Modifier__Group__3__Impl rule__Modifier__Group__4
            {
            pushFollow(FOLLOW_22);
            rule__Modifier__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__3"


    // $ANTLR start "rule__Modifier__Group__3__Impl"
    // InternalSM2.g:2788:1: rule__Modifier__Group__3__Impl : ( ( rule__Modifier__InputParamsAssignment_3 )* ) ;
    public final void rule__Modifier__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2792:1: ( ( ( rule__Modifier__InputParamsAssignment_3 )* ) )
            // InternalSM2.g:2793:1: ( ( rule__Modifier__InputParamsAssignment_3 )* )
            {
            // InternalSM2.g:2793:1: ( ( rule__Modifier__InputParamsAssignment_3 )* )
            // InternalSM2.g:2794:2: ( rule__Modifier__InputParamsAssignment_3 )*
            {
             before(grammarAccess.getModifierAccess().getInputParamsAssignment_3()); 
            // InternalSM2.g:2795:2: ( rule__Modifier__InputParamsAssignment_3 )*
            loop34:
            do {
                int alt34=2;
                int LA34_0 = input.LA(1);

                if ( ((LA34_0>=30 && LA34_0<=38)) ) {
                    alt34=1;
                }


                switch (alt34) {
            	case 1 :
            	    // InternalSM2.g:2795:3: rule__Modifier__InputParamsAssignment_3
            	    {
            	    pushFollow(FOLLOW_23);
            	    rule__Modifier__InputParamsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop34;
                }
            } while (true);

             after(grammarAccess.getModifierAccess().getInputParamsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__3__Impl"


    // $ANTLR start "rule__Modifier__Group__4"
    // InternalSM2.g:2803:1: rule__Modifier__Group__4 : rule__Modifier__Group__4__Impl rule__Modifier__Group__5 ;
    public final void rule__Modifier__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2807:1: ( rule__Modifier__Group__4__Impl rule__Modifier__Group__5 )
            // InternalSM2.g:2808:2: rule__Modifier__Group__4__Impl rule__Modifier__Group__5
            {
            pushFollow(FOLLOW_24);
            rule__Modifier__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__4"


    // $ANTLR start "rule__Modifier__Group__4__Impl"
    // InternalSM2.g:2815:1: rule__Modifier__Group__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Modifier__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2819:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2820:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2820:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2821:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__4__Impl"


    // $ANTLR start "rule__Modifier__Group__5"
    // InternalSM2.g:2830:1: rule__Modifier__Group__5 : rule__Modifier__Group__5__Impl rule__Modifier__Group__6 ;
    public final void rule__Modifier__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2834:1: ( rule__Modifier__Group__5__Impl rule__Modifier__Group__6 )
            // InternalSM2.g:2835:2: rule__Modifier__Group__5__Impl rule__Modifier__Group__6
            {
            pushFollow(FOLLOW_25);
            rule__Modifier__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__5"


    // $ANTLR start "rule__Modifier__Group__5__Impl"
    // InternalSM2.g:2842:1: rule__Modifier__Group__5__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Modifier__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2846:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:2847:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:2847:1: ( RULE_OPENKEY )
            // InternalSM2.g:2848:2: RULE_OPENKEY
            {
             before(grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__5__Impl"


    // $ANTLR start "rule__Modifier__Group__6"
    // InternalSM2.g:2857:1: rule__Modifier__Group__6 : rule__Modifier__Group__6__Impl rule__Modifier__Group__7 ;
    public final void rule__Modifier__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2861:1: ( rule__Modifier__Group__6__Impl rule__Modifier__Group__7 )
            // InternalSM2.g:2862:2: rule__Modifier__Group__6__Impl rule__Modifier__Group__7
            {
            pushFollow(FOLLOW_25);
            rule__Modifier__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__6"


    // $ANTLR start "rule__Modifier__Group__6__Impl"
    // InternalSM2.g:2869:1: rule__Modifier__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2873:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2874:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2874:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2875:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6()); 
            // InternalSM2.g:2876:2: ( RULE_EOLINE )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==RULE_EOLINE) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalSM2.g:2876:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__6__Impl"


    // $ANTLR start "rule__Modifier__Group__7"
    // InternalSM2.g:2884:1: rule__Modifier__Group__7 : rule__Modifier__Group__7__Impl rule__Modifier__Group__8 ;
    public final void rule__Modifier__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2888:1: ( rule__Modifier__Group__7__Impl rule__Modifier__Group__8 )
            // InternalSM2.g:2889:2: rule__Modifier__Group__7__Impl rule__Modifier__Group__8
            {
            pushFollow(FOLLOW_5);
            rule__Modifier__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__7"


    // $ANTLR start "rule__Modifier__Group__7__Impl"
    // InternalSM2.g:2896:1: rule__Modifier__Group__7__Impl : ( ( rule__Modifier__ExprAssignment_7 ) ) ;
    public final void rule__Modifier__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2900:1: ( ( ( rule__Modifier__ExprAssignment_7 ) ) )
            // InternalSM2.g:2901:1: ( ( rule__Modifier__ExprAssignment_7 ) )
            {
            // InternalSM2.g:2901:1: ( ( rule__Modifier__ExprAssignment_7 ) )
            // InternalSM2.g:2902:2: ( rule__Modifier__ExprAssignment_7 )
            {
             before(grammarAccess.getModifierAccess().getExprAssignment_7()); 
            // InternalSM2.g:2903:2: ( rule__Modifier__ExprAssignment_7 )
            // InternalSM2.g:2903:3: rule__Modifier__ExprAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__ExprAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getModifierAccess().getExprAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__7__Impl"


    // $ANTLR start "rule__Modifier__Group__8"
    // InternalSM2.g:2911:1: rule__Modifier__Group__8 : rule__Modifier__Group__8__Impl rule__Modifier__Group__9 ;
    public final void rule__Modifier__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2915:1: ( rule__Modifier__Group__8__Impl rule__Modifier__Group__9 )
            // InternalSM2.g:2916:2: rule__Modifier__Group__8__Impl rule__Modifier__Group__9
            {
            pushFollow(FOLLOW_26);
            rule__Modifier__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__8"


    // $ANTLR start "rule__Modifier__Group__8__Impl"
    // InternalSM2.g:2923:1: rule__Modifier__Group__8__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Modifier__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2927:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:2928:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:2928:1: ( RULE_SEMICOLON )
            // InternalSM2.g:2929:2: RULE_SEMICOLON
            {
             before(grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__8__Impl"


    // $ANTLR start "rule__Modifier__Group__9"
    // InternalSM2.g:2938:1: rule__Modifier__Group__9 : rule__Modifier__Group__9__Impl rule__Modifier__Group__10 ;
    public final void rule__Modifier__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2942:1: ( rule__Modifier__Group__9__Impl rule__Modifier__Group__10 )
            // InternalSM2.g:2943:2: rule__Modifier__Group__9__Impl rule__Modifier__Group__10
            {
            pushFollow(FOLLOW_26);
            rule__Modifier__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__9"


    // $ANTLR start "rule__Modifier__Group__9__Impl"
    // InternalSM2.g:2950:1: rule__Modifier__Group__9__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2954:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2955:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2955:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2956:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9()); 
            // InternalSM2.g:2957:2: ( RULE_EOLINE )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==RULE_EOLINE) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalSM2.g:2957:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__9__Impl"


    // $ANTLR start "rule__Modifier__Group__10"
    // InternalSM2.g:2965:1: rule__Modifier__Group__10 : rule__Modifier__Group__10__Impl rule__Modifier__Group__11 ;
    public final void rule__Modifier__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2969:1: ( rule__Modifier__Group__10__Impl rule__Modifier__Group__11 )
            // InternalSM2.g:2970:2: rule__Modifier__Group__10__Impl rule__Modifier__Group__11
            {
            pushFollow(FOLLOW_27);
            rule__Modifier__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__10"


    // $ANTLR start "rule__Modifier__Group__10__Impl"
    // InternalSM2.g:2977:1: rule__Modifier__Group__10__Impl : ( '_;' ) ;
    public final void rule__Modifier__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2981:1: ( ( '_;' ) )
            // InternalSM2.g:2982:1: ( '_;' )
            {
            // InternalSM2.g:2982:1: ( '_;' )
            // InternalSM2.g:2983:2: '_;'
            {
             before(grammarAccess.getModifierAccess().get_Keyword_10()); 
            match(input,63,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().get_Keyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__10__Impl"


    // $ANTLR start "rule__Modifier__Group__11"
    // InternalSM2.g:2992:1: rule__Modifier__Group__11 : rule__Modifier__Group__11__Impl rule__Modifier__Group__12 ;
    public final void rule__Modifier__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2996:1: ( rule__Modifier__Group__11__Impl rule__Modifier__Group__12 )
            // InternalSM2.g:2997:2: rule__Modifier__Group__11__Impl rule__Modifier__Group__12
            {
            pushFollow(FOLLOW_20);
            rule__Modifier__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__11"


    // $ANTLR start "rule__Modifier__Group__11__Impl"
    // InternalSM2.g:3004:1: rule__Modifier__Group__11__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Modifier__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3008:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:3009:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:3009:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:3010:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__11__Impl"


    // $ANTLR start "rule__Modifier__Group__12"
    // InternalSM2.g:3019:1: rule__Modifier__Group__12 : rule__Modifier__Group__12__Impl ;
    public final void rule__Modifier__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3023:1: ( rule__Modifier__Group__12__Impl )
            // InternalSM2.g:3024:2: rule__Modifier__Group__12__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__12__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__12"


    // $ANTLR start "rule__Modifier__Group__12__Impl"
    // InternalSM2.g:3030:1: rule__Modifier__Group__12__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3034:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3035:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3035:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3036:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12()); 
            // InternalSM2.g:3037:2: ( RULE_EOLINE )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==RULE_EOLINE) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalSM2.g:3037:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__12__Impl"


    // $ANTLR start "rule__Mapping__Group__0"
    // InternalSM2.g:3046:1: rule__Mapping__Group__0 : rule__Mapping__Group__0__Impl rule__Mapping__Group__1 ;
    public final void rule__Mapping__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3050:1: ( rule__Mapping__Group__0__Impl rule__Mapping__Group__1 )
            // InternalSM2.g:3051:2: rule__Mapping__Group__0__Impl rule__Mapping__Group__1
            {
            pushFollow(FOLLOW_21);
            rule__Mapping__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__0"


    // $ANTLR start "rule__Mapping__Group__0__Impl"
    // InternalSM2.g:3058:1: rule__Mapping__Group__0__Impl : ( 'mapping' ) ;
    public final void rule__Mapping__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3062:1: ( ( 'mapping' ) )
            // InternalSM2.g:3063:1: ( 'mapping' )
            {
            // InternalSM2.g:3063:1: ( 'mapping' )
            // InternalSM2.g:3064:2: 'mapping'
            {
             before(grammarAccess.getMappingAccess().getMappingKeyword_0()); 
            match(input,64,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getMappingKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__0__Impl"


    // $ANTLR start "rule__Mapping__Group__1"
    // InternalSM2.g:3073:1: rule__Mapping__Group__1 : rule__Mapping__Group__1__Impl rule__Mapping__Group__2 ;
    public final void rule__Mapping__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3077:1: ( rule__Mapping__Group__1__Impl rule__Mapping__Group__2 )
            // InternalSM2.g:3078:2: rule__Mapping__Group__1__Impl rule__Mapping__Group__2
            {
            pushFollow(FOLLOW_28);
            rule__Mapping__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__1"


    // $ANTLR start "rule__Mapping__Group__1__Impl"
    // InternalSM2.g:3085:1: rule__Mapping__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Mapping__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3089:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:3090:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:3090:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:3091:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__1__Impl"


    // $ANTLR start "rule__Mapping__Group__2"
    // InternalSM2.g:3100:1: rule__Mapping__Group__2 : rule__Mapping__Group__2__Impl rule__Mapping__Group__3 ;
    public final void rule__Mapping__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3104:1: ( rule__Mapping__Group__2__Impl rule__Mapping__Group__3 )
            // InternalSM2.g:3105:2: rule__Mapping__Group__2__Impl rule__Mapping__Group__3
            {
            pushFollow(FOLLOW_29);
            rule__Mapping__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__2"


    // $ANTLR start "rule__Mapping__Group__2__Impl"
    // InternalSM2.g:3112:1: rule__Mapping__Group__2__Impl : ( ( rule__Mapping__TypeAssignment_2 ) ) ;
    public final void rule__Mapping__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3116:1: ( ( ( rule__Mapping__TypeAssignment_2 ) ) )
            // InternalSM2.g:3117:1: ( ( rule__Mapping__TypeAssignment_2 ) )
            {
            // InternalSM2.g:3117:1: ( ( rule__Mapping__TypeAssignment_2 ) )
            // InternalSM2.g:3118:2: ( rule__Mapping__TypeAssignment_2 )
            {
             before(grammarAccess.getMappingAccess().getTypeAssignment_2()); 
            // InternalSM2.g:3119:2: ( rule__Mapping__TypeAssignment_2 )
            // InternalSM2.g:3119:3: rule__Mapping__TypeAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__TypeAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getTypeAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__2__Impl"


    // $ANTLR start "rule__Mapping__Group__3"
    // InternalSM2.g:3127:1: rule__Mapping__Group__3 : rule__Mapping__Group__3__Impl rule__Mapping__Group__4 ;
    public final void rule__Mapping__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3131:1: ( rule__Mapping__Group__3__Impl rule__Mapping__Group__4 )
            // InternalSM2.g:3132:2: rule__Mapping__Group__3__Impl rule__Mapping__Group__4
            {
            pushFollow(FOLLOW_30);
            rule__Mapping__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__3"


    // $ANTLR start "rule__Mapping__Group__3__Impl"
    // InternalSM2.g:3139:1: rule__Mapping__Group__3__Impl : ( '=>' ) ;
    public final void rule__Mapping__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3143:1: ( ( '=>' ) )
            // InternalSM2.g:3144:1: ( '=>' )
            {
            // InternalSM2.g:3144:1: ( '=>' )
            // InternalSM2.g:3145:2: '=>'
            {
             before(grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3()); 
            match(input,65,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__3__Impl"


    // $ANTLR start "rule__Mapping__Group__4"
    // InternalSM2.g:3154:1: rule__Mapping__Group__4 : rule__Mapping__Group__4__Impl rule__Mapping__Group__5 ;
    public final void rule__Mapping__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3158:1: ( rule__Mapping__Group__4__Impl rule__Mapping__Group__5 )
            // InternalSM2.g:3159:2: rule__Mapping__Group__4__Impl rule__Mapping__Group__5
            {
            pushFollow(FOLLOW_31);
            rule__Mapping__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__4"


    // $ANTLR start "rule__Mapping__Group__4__Impl"
    // InternalSM2.g:3166:1: rule__Mapping__Group__4__Impl : ( ( rule__Mapping__ExprAssignment_4 ) ) ;
    public final void rule__Mapping__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3170:1: ( ( ( rule__Mapping__ExprAssignment_4 ) ) )
            // InternalSM2.g:3171:1: ( ( rule__Mapping__ExprAssignment_4 ) )
            {
            // InternalSM2.g:3171:1: ( ( rule__Mapping__ExprAssignment_4 ) )
            // InternalSM2.g:3172:2: ( rule__Mapping__ExprAssignment_4 )
            {
             before(grammarAccess.getMappingAccess().getExprAssignment_4()); 
            // InternalSM2.g:3173:2: ( rule__Mapping__ExprAssignment_4 )
            // InternalSM2.g:3173:3: rule__Mapping__ExprAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__ExprAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getExprAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__4__Impl"


    // $ANTLR start "rule__Mapping__Group__5"
    // InternalSM2.g:3181:1: rule__Mapping__Group__5 : rule__Mapping__Group__5__Impl rule__Mapping__Group__6 ;
    public final void rule__Mapping__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3185:1: ( rule__Mapping__Group__5__Impl rule__Mapping__Group__6 )
            // InternalSM2.g:3186:2: rule__Mapping__Group__5__Impl rule__Mapping__Group__6
            {
            pushFollow(FOLLOW_32);
            rule__Mapping__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__5"


    // $ANTLR start "rule__Mapping__Group__5__Impl"
    // InternalSM2.g:3193:1: rule__Mapping__Group__5__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Mapping__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3197:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:3198:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:3198:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:3199:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__5__Impl"


    // $ANTLR start "rule__Mapping__Group__6"
    // InternalSM2.g:3208:1: rule__Mapping__Group__6 : rule__Mapping__Group__6__Impl rule__Mapping__Group__7 ;
    public final void rule__Mapping__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3212:1: ( rule__Mapping__Group__6__Impl rule__Mapping__Group__7 )
            // InternalSM2.g:3213:2: rule__Mapping__Group__6__Impl rule__Mapping__Group__7
            {
            pushFollow(FOLLOW_32);
            rule__Mapping__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__6"


    // $ANTLR start "rule__Mapping__Group__6__Impl"
    // InternalSM2.g:3220:1: rule__Mapping__Group__6__Impl : ( ( rule__Mapping__VisibilityAssignment_6 )? ) ;
    public final void rule__Mapping__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3224:1: ( ( ( rule__Mapping__VisibilityAssignment_6 )? ) )
            // InternalSM2.g:3225:1: ( ( rule__Mapping__VisibilityAssignment_6 )? )
            {
            // InternalSM2.g:3225:1: ( ( rule__Mapping__VisibilityAssignment_6 )? )
            // InternalSM2.g:3226:2: ( rule__Mapping__VisibilityAssignment_6 )?
            {
             before(grammarAccess.getMappingAccess().getVisibilityAssignment_6()); 
            // InternalSM2.g:3227:2: ( rule__Mapping__VisibilityAssignment_6 )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( ((LA38_0>=39 && LA38_0<=42)) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:3227:3: rule__Mapping__VisibilityAssignment_6
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mapping__VisibilityAssignment_6();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMappingAccess().getVisibilityAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__6__Impl"


    // $ANTLR start "rule__Mapping__Group__7"
    // InternalSM2.g:3235:1: rule__Mapping__Group__7 : rule__Mapping__Group__7__Impl rule__Mapping__Group__8 ;
    public final void rule__Mapping__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3239:1: ( rule__Mapping__Group__7__Impl rule__Mapping__Group__8 )
            // InternalSM2.g:3240:2: rule__Mapping__Group__7__Impl rule__Mapping__Group__8
            {
            pushFollow(FOLLOW_5);
            rule__Mapping__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__7"


    // $ANTLR start "rule__Mapping__Group__7__Impl"
    // InternalSM2.g:3247:1: rule__Mapping__Group__7__Impl : ( ( rule__Mapping__NameMappingAssignment_7 ) ) ;
    public final void rule__Mapping__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3251:1: ( ( ( rule__Mapping__NameMappingAssignment_7 ) ) )
            // InternalSM2.g:3252:1: ( ( rule__Mapping__NameMappingAssignment_7 ) )
            {
            // InternalSM2.g:3252:1: ( ( rule__Mapping__NameMappingAssignment_7 ) )
            // InternalSM2.g:3253:2: ( rule__Mapping__NameMappingAssignment_7 )
            {
             before(grammarAccess.getMappingAccess().getNameMappingAssignment_7()); 
            // InternalSM2.g:3254:2: ( rule__Mapping__NameMappingAssignment_7 )
            // InternalSM2.g:3254:3: rule__Mapping__NameMappingAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__NameMappingAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getNameMappingAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__7__Impl"


    // $ANTLR start "rule__Mapping__Group__8"
    // InternalSM2.g:3262:1: rule__Mapping__Group__8 : rule__Mapping__Group__8__Impl ;
    public final void rule__Mapping__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3266:1: ( rule__Mapping__Group__8__Impl )
            // InternalSM2.g:3267:2: rule__Mapping__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__8"


    // $ANTLR start "rule__Mapping__Group__8__Impl"
    // InternalSM2.g:3273:1: rule__Mapping__Group__8__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Mapping__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3277:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3278:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3278:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3279:2: RULE_SEMICOLON
            {
             before(grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__8__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__0"
    // InternalSM2.g:3289:1: rule__PersonalizedStruct__Group__0 : rule__PersonalizedStruct__Group__0__Impl rule__PersonalizedStruct__Group__1 ;
    public final void rule__PersonalizedStruct__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3293:1: ( rule__PersonalizedStruct__Group__0__Impl rule__PersonalizedStruct__Group__1 )
            // InternalSM2.g:3294:2: rule__PersonalizedStruct__Group__0__Impl rule__PersonalizedStruct__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__PersonalizedStruct__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__0"


    // $ANTLR start "rule__PersonalizedStruct__Group__0__Impl"
    // InternalSM2.g:3301:1: rule__PersonalizedStruct__Group__0__Impl : ( 'struct' ) ;
    public final void rule__PersonalizedStruct__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3305:1: ( ( 'struct' ) )
            // InternalSM2.g:3306:1: ( 'struct' )
            {
            // InternalSM2.g:3306:1: ( 'struct' )
            // InternalSM2.g:3307:2: 'struct'
            {
             before(grammarAccess.getPersonalizedStructAccess().getStructKeyword_0()); 
            match(input,66,FOLLOW_2); 
             after(grammarAccess.getPersonalizedStructAccess().getStructKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__0__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__1"
    // InternalSM2.g:3316:1: rule__PersonalizedStruct__Group__1 : rule__PersonalizedStruct__Group__1__Impl rule__PersonalizedStruct__Group__2 ;
    public final void rule__PersonalizedStruct__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3320:1: ( rule__PersonalizedStruct__Group__1__Impl rule__PersonalizedStruct__Group__2 )
            // InternalSM2.g:3321:2: rule__PersonalizedStruct__Group__1__Impl rule__PersonalizedStruct__Group__2
            {
            pushFollow(FOLLOW_24);
            rule__PersonalizedStruct__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__1"


    // $ANTLR start "rule__PersonalizedStruct__Group__1__Impl"
    // InternalSM2.g:3328:1: rule__PersonalizedStruct__Group__1__Impl : ( ( rule__PersonalizedStruct__NameStructAssignment_1 ) ) ;
    public final void rule__PersonalizedStruct__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3332:1: ( ( ( rule__PersonalizedStruct__NameStructAssignment_1 ) ) )
            // InternalSM2.g:3333:1: ( ( rule__PersonalizedStruct__NameStructAssignment_1 ) )
            {
            // InternalSM2.g:3333:1: ( ( rule__PersonalizedStruct__NameStructAssignment_1 ) )
            // InternalSM2.g:3334:2: ( rule__PersonalizedStruct__NameStructAssignment_1 )
            {
             before(grammarAccess.getPersonalizedStructAccess().getNameStructAssignment_1()); 
            // InternalSM2.g:3335:2: ( rule__PersonalizedStruct__NameStructAssignment_1 )
            // InternalSM2.g:3335:3: rule__PersonalizedStruct__NameStructAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__NameStructAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getPersonalizedStructAccess().getNameStructAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__1__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__2"
    // InternalSM2.g:3343:1: rule__PersonalizedStruct__Group__2 : rule__PersonalizedStruct__Group__2__Impl rule__PersonalizedStruct__Group__3 ;
    public final void rule__PersonalizedStruct__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3347:1: ( rule__PersonalizedStruct__Group__2__Impl rule__PersonalizedStruct__Group__3 )
            // InternalSM2.g:3348:2: rule__PersonalizedStruct__Group__2__Impl rule__PersonalizedStruct__Group__3
            {
            pushFollow(FOLLOW_33);
            rule__PersonalizedStruct__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__2"


    // $ANTLR start "rule__PersonalizedStruct__Group__2__Impl"
    // InternalSM2.g:3355:1: rule__PersonalizedStruct__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__PersonalizedStruct__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3359:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:3360:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:3360:1: ( RULE_OPENKEY )
            // InternalSM2.g:3361:2: RULE_OPENKEY
            {
             before(grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__2__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__3"
    // InternalSM2.g:3370:1: rule__PersonalizedStruct__Group__3 : rule__PersonalizedStruct__Group__3__Impl rule__PersonalizedStruct__Group__4 ;
    public final void rule__PersonalizedStruct__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3374:1: ( rule__PersonalizedStruct__Group__3__Impl rule__PersonalizedStruct__Group__4 )
            // InternalSM2.g:3375:2: rule__PersonalizedStruct__Group__3__Impl rule__PersonalizedStruct__Group__4
            {
            pushFollow(FOLLOW_33);
            rule__PersonalizedStruct__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__3"


    // $ANTLR start "rule__PersonalizedStruct__Group__3__Impl"
    // InternalSM2.g:3382:1: rule__PersonalizedStruct__Group__3__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__PersonalizedStruct__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3386:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3387:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3387:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3388:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3()); 
            // InternalSM2.g:3389:2: ( RULE_EOLINE )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==RULE_EOLINE) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalSM2.g:3389:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__3__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__4"
    // InternalSM2.g:3397:1: rule__PersonalizedStruct__Group__4 : rule__PersonalizedStruct__Group__4__Impl rule__PersonalizedStruct__Group__5 ;
    public final void rule__PersonalizedStruct__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3401:1: ( rule__PersonalizedStruct__Group__4__Impl rule__PersonalizedStruct__Group__5 )
            // InternalSM2.g:3402:2: rule__PersonalizedStruct__Group__4__Impl rule__PersonalizedStruct__Group__5
            {
            pushFollow(FOLLOW_27);
            rule__PersonalizedStruct__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__4"


    // $ANTLR start "rule__PersonalizedStruct__Group__4__Impl"
    // InternalSM2.g:3409:1: rule__PersonalizedStruct__Group__4__Impl : ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) ) ;
    public final void rule__PersonalizedStruct__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3413:1: ( ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) ) )
            // InternalSM2.g:3414:1: ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) )
            {
            // InternalSM2.g:3414:1: ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) )
            // InternalSM2.g:3415:2: ( rule__PersonalizedStruct__PropertiesAssignment_4 )
            {
             before(grammarAccess.getPersonalizedStructAccess().getPropertiesAssignment_4()); 
            // InternalSM2.g:3416:2: ( rule__PersonalizedStruct__PropertiesAssignment_4 )
            // InternalSM2.g:3416:3: rule__PersonalizedStruct__PropertiesAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__PropertiesAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getPersonalizedStructAccess().getPropertiesAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__4__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__5"
    // InternalSM2.g:3424:1: rule__PersonalizedStruct__Group__5 : rule__PersonalizedStruct__Group__5__Impl rule__PersonalizedStruct__Group__6 ;
    public final void rule__PersonalizedStruct__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3428:1: ( rule__PersonalizedStruct__Group__5__Impl rule__PersonalizedStruct__Group__6 )
            // InternalSM2.g:3429:2: rule__PersonalizedStruct__Group__5__Impl rule__PersonalizedStruct__Group__6
            {
            pushFollow(FOLLOW_20);
            rule__PersonalizedStruct__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__5"


    // $ANTLR start "rule__PersonalizedStruct__Group__5__Impl"
    // InternalSM2.g:3436:1: rule__PersonalizedStruct__Group__5__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__PersonalizedStruct__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3440:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:3441:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:3441:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:3442:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__5__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__6"
    // InternalSM2.g:3451:1: rule__PersonalizedStruct__Group__6 : rule__PersonalizedStruct__Group__6__Impl ;
    public final void rule__PersonalizedStruct__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3455:1: ( rule__PersonalizedStruct__Group__6__Impl )
            // InternalSM2.g:3456:2: rule__PersonalizedStruct__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__6"


    // $ANTLR start "rule__PersonalizedStruct__Group__6__Impl"
    // InternalSM2.g:3462:1: rule__PersonalizedStruct__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__PersonalizedStruct__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3466:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3467:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3467:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3468:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6()); 
            // InternalSM2.g:3469:2: ( RULE_EOLINE )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==RULE_EOLINE) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalSM2.g:3469:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__6__Impl"


    // $ANTLR start "rule__User__Group__0"
    // InternalSM2.g:3478:1: rule__User__Group__0 : rule__User__Group__0__Impl rule__User__Group__1 ;
    public final void rule__User__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3482:1: ( rule__User__Group__0__Impl rule__User__Group__1 )
            // InternalSM2.g:3483:2: rule__User__Group__0__Impl rule__User__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__User__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__0"


    // $ANTLR start "rule__User__Group__0__Impl"
    // InternalSM2.g:3490:1: rule__User__Group__0__Impl : ( 'struct' ) ;
    public final void rule__User__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3494:1: ( ( 'struct' ) )
            // InternalSM2.g:3495:1: ( 'struct' )
            {
            // InternalSM2.g:3495:1: ( 'struct' )
            // InternalSM2.g:3496:2: 'struct'
            {
             before(grammarAccess.getUserAccess().getStructKeyword_0()); 
            match(input,66,FOLLOW_2); 
             after(grammarAccess.getUserAccess().getStructKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__0__Impl"


    // $ANTLR start "rule__User__Group__1"
    // InternalSM2.g:3505:1: rule__User__Group__1 : rule__User__Group__1__Impl rule__User__Group__2 ;
    public final void rule__User__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3509:1: ( rule__User__Group__1__Impl rule__User__Group__2 )
            // InternalSM2.g:3510:2: rule__User__Group__1__Impl rule__User__Group__2
            {
            pushFollow(FOLLOW_24);
            rule__User__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__1"


    // $ANTLR start "rule__User__Group__1__Impl"
    // InternalSM2.g:3517:1: rule__User__Group__1__Impl : ( ( rule__User__NameStructAssignment_1 ) ) ;
    public final void rule__User__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3521:1: ( ( ( rule__User__NameStructAssignment_1 ) ) )
            // InternalSM2.g:3522:1: ( ( rule__User__NameStructAssignment_1 ) )
            {
            // InternalSM2.g:3522:1: ( ( rule__User__NameStructAssignment_1 ) )
            // InternalSM2.g:3523:2: ( rule__User__NameStructAssignment_1 )
            {
             before(grammarAccess.getUserAccess().getNameStructAssignment_1()); 
            // InternalSM2.g:3524:2: ( rule__User__NameStructAssignment_1 )
            // InternalSM2.g:3524:3: rule__User__NameStructAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__User__NameStructAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getUserAccess().getNameStructAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__1__Impl"


    // $ANTLR start "rule__User__Group__2"
    // InternalSM2.g:3532:1: rule__User__Group__2 : rule__User__Group__2__Impl rule__User__Group__3 ;
    public final void rule__User__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3536:1: ( rule__User__Group__2__Impl rule__User__Group__3 )
            // InternalSM2.g:3537:2: rule__User__Group__2__Impl rule__User__Group__3
            {
            pushFollow(FOLLOW_25);
            rule__User__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__2"


    // $ANTLR start "rule__User__Group__2__Impl"
    // InternalSM2.g:3544:1: rule__User__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__User__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3548:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:3549:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:3549:1: ( RULE_OPENKEY )
            // InternalSM2.g:3550:2: RULE_OPENKEY
            {
             before(grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__2__Impl"


    // $ANTLR start "rule__User__Group__3"
    // InternalSM2.g:3559:1: rule__User__Group__3 : rule__User__Group__3__Impl rule__User__Group__4 ;
    public final void rule__User__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3563:1: ( rule__User__Group__3__Impl rule__User__Group__4 )
            // InternalSM2.g:3564:2: rule__User__Group__3__Impl rule__User__Group__4
            {
            pushFollow(FOLLOW_25);
            rule__User__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__3"


    // $ANTLR start "rule__User__Group__3__Impl"
    // InternalSM2.g:3571:1: rule__User__Group__3__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3575:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3576:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3576:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3577:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3()); 
            // InternalSM2.g:3578:2: ( RULE_EOLINE )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==RULE_EOLINE) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalSM2.g:3578:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__3__Impl"


    // $ANTLR start "rule__User__Group__4"
    // InternalSM2.g:3586:1: rule__User__Group__4 : rule__User__Group__4__Impl rule__User__Group__5 ;
    public final void rule__User__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3590:1: ( rule__User__Group__4__Impl rule__User__Group__5 )
            // InternalSM2.g:3591:2: rule__User__Group__4__Impl rule__User__Group__5
            {
            pushFollow(FOLLOW_5);
            rule__User__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__4"


    // $ANTLR start "rule__User__Group__4__Impl"
    // InternalSM2.g:3598:1: rule__User__Group__4__Impl : ( ( rule__User__AddressAssignment_4 ) ) ;
    public final void rule__User__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3602:1: ( ( ( rule__User__AddressAssignment_4 ) ) )
            // InternalSM2.g:3603:1: ( ( rule__User__AddressAssignment_4 ) )
            {
            // InternalSM2.g:3603:1: ( ( rule__User__AddressAssignment_4 ) )
            // InternalSM2.g:3604:2: ( rule__User__AddressAssignment_4 )
            {
             before(grammarAccess.getUserAccess().getAddressAssignment_4()); 
            // InternalSM2.g:3605:2: ( rule__User__AddressAssignment_4 )
            // InternalSM2.g:3605:3: rule__User__AddressAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__User__AddressAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getUserAccess().getAddressAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__4__Impl"


    // $ANTLR start "rule__User__Group__5"
    // InternalSM2.g:3613:1: rule__User__Group__5 : rule__User__Group__5__Impl rule__User__Group__6 ;
    public final void rule__User__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3617:1: ( rule__User__Group__5__Impl rule__User__Group__6 )
            // InternalSM2.g:3618:2: rule__User__Group__5__Impl rule__User__Group__6
            {
            pushFollow(FOLLOW_30);
            rule__User__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__5"


    // $ANTLR start "rule__User__Group__5__Impl"
    // InternalSM2.g:3625:1: rule__User__Group__5__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3629:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3630:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3630:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3631:2: RULE_SEMICOLON
            {
             before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_5()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__5__Impl"


    // $ANTLR start "rule__User__Group__6"
    // InternalSM2.g:3640:1: rule__User__Group__6 : rule__User__Group__6__Impl rule__User__Group__7 ;
    public final void rule__User__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3644:1: ( rule__User__Group__6__Impl rule__User__Group__7 )
            // InternalSM2.g:3645:2: rule__User__Group__6__Impl rule__User__Group__7
            {
            pushFollow(FOLLOW_5);
            rule__User__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__6"


    // $ANTLR start "rule__User__Group__6__Impl"
    // InternalSM2.g:3652:1: rule__User__Group__6__Impl : ( ( rule__User__NameUserAssignment_6 ) ) ;
    public final void rule__User__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3656:1: ( ( ( rule__User__NameUserAssignment_6 ) ) )
            // InternalSM2.g:3657:1: ( ( rule__User__NameUserAssignment_6 ) )
            {
            // InternalSM2.g:3657:1: ( ( rule__User__NameUserAssignment_6 ) )
            // InternalSM2.g:3658:2: ( rule__User__NameUserAssignment_6 )
            {
             before(grammarAccess.getUserAccess().getNameUserAssignment_6()); 
            // InternalSM2.g:3659:2: ( rule__User__NameUserAssignment_6 )
            // InternalSM2.g:3659:3: rule__User__NameUserAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__User__NameUserAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getUserAccess().getNameUserAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__6__Impl"


    // $ANTLR start "rule__User__Group__7"
    // InternalSM2.g:3667:1: rule__User__Group__7 : rule__User__Group__7__Impl rule__User__Group__8 ;
    public final void rule__User__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3671:1: ( rule__User__Group__7__Impl rule__User__Group__8 )
            // InternalSM2.g:3672:2: rule__User__Group__7__Impl rule__User__Group__8
            {
            pushFollow(FOLLOW_30);
            rule__User__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__7"


    // $ANTLR start "rule__User__Group__7__Impl"
    // InternalSM2.g:3679:1: rule__User__Group__7__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3683:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3684:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3684:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3685:2: RULE_SEMICOLON
            {
             before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_7()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__7__Impl"


    // $ANTLR start "rule__User__Group__8"
    // InternalSM2.g:3694:1: rule__User__Group__8 : rule__User__Group__8__Impl rule__User__Group__9 ;
    public final void rule__User__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3698:1: ( rule__User__Group__8__Impl rule__User__Group__9 )
            // InternalSM2.g:3699:2: rule__User__Group__8__Impl rule__User__Group__9
            {
            pushFollow(FOLLOW_5);
            rule__User__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__8"


    // $ANTLR start "rule__User__Group__8__Impl"
    // InternalSM2.g:3706:1: rule__User__Group__8__Impl : ( ( rule__User__LastNameUserAssignment_8 ) ) ;
    public final void rule__User__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3710:1: ( ( ( rule__User__LastNameUserAssignment_8 ) ) )
            // InternalSM2.g:3711:1: ( ( rule__User__LastNameUserAssignment_8 ) )
            {
            // InternalSM2.g:3711:1: ( ( rule__User__LastNameUserAssignment_8 ) )
            // InternalSM2.g:3712:2: ( rule__User__LastNameUserAssignment_8 )
            {
             before(grammarAccess.getUserAccess().getLastNameUserAssignment_8()); 
            // InternalSM2.g:3713:2: ( rule__User__LastNameUserAssignment_8 )
            // InternalSM2.g:3713:3: rule__User__LastNameUserAssignment_8
            {
            pushFollow(FOLLOW_2);
            rule__User__LastNameUserAssignment_8();

            state._fsp--;


            }

             after(grammarAccess.getUserAccess().getLastNameUserAssignment_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__8__Impl"


    // $ANTLR start "rule__User__Group__9"
    // InternalSM2.g:3721:1: rule__User__Group__9 : rule__User__Group__9__Impl rule__User__Group__10 ;
    public final void rule__User__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3725:1: ( rule__User__Group__9__Impl rule__User__Group__10 )
            // InternalSM2.g:3726:2: rule__User__Group__9__Impl rule__User__Group__10
            {
            pushFollow(FOLLOW_34);
            rule__User__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__9"


    // $ANTLR start "rule__User__Group__9__Impl"
    // InternalSM2.g:3733:1: rule__User__Group__9__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3737:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3738:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3738:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3739:2: RULE_SEMICOLON
            {
             before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_9()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__9__Impl"


    // $ANTLR start "rule__User__Group__10"
    // InternalSM2.g:3748:1: rule__User__Group__10 : rule__User__Group__10__Impl rule__User__Group__11 ;
    public final void rule__User__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3752:1: ( rule__User__Group__10__Impl rule__User__Group__11 )
            // InternalSM2.g:3753:2: rule__User__Group__10__Impl rule__User__Group__11
            {
            pushFollow(FOLLOW_5);
            rule__User__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__10"


    // $ANTLR start "rule__User__Group__10__Impl"
    // InternalSM2.g:3760:1: rule__User__Group__10__Impl : ( ( rule__User__EmailAssignment_10 ) ) ;
    public final void rule__User__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3764:1: ( ( ( rule__User__EmailAssignment_10 ) ) )
            // InternalSM2.g:3765:1: ( ( rule__User__EmailAssignment_10 ) )
            {
            // InternalSM2.g:3765:1: ( ( rule__User__EmailAssignment_10 ) )
            // InternalSM2.g:3766:2: ( rule__User__EmailAssignment_10 )
            {
             before(grammarAccess.getUserAccess().getEmailAssignment_10()); 
            // InternalSM2.g:3767:2: ( rule__User__EmailAssignment_10 )
            // InternalSM2.g:3767:3: rule__User__EmailAssignment_10
            {
            pushFollow(FOLLOW_2);
            rule__User__EmailAssignment_10();

            state._fsp--;


            }

             after(grammarAccess.getUserAccess().getEmailAssignment_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__10__Impl"


    // $ANTLR start "rule__User__Group__11"
    // InternalSM2.g:3775:1: rule__User__Group__11 : rule__User__Group__11__Impl rule__User__Group__12 ;
    public final void rule__User__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3779:1: ( rule__User__Group__11__Impl rule__User__Group__12 )
            // InternalSM2.g:3780:2: rule__User__Group__11__Impl rule__User__Group__12
            {
            pushFollow(FOLLOW_30);
            rule__User__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__11"


    // $ANTLR start "rule__User__Group__11__Impl"
    // InternalSM2.g:3787:1: rule__User__Group__11__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3791:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3792:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3792:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3793:2: RULE_SEMICOLON
            {
             before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_11()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__11__Impl"


    // $ANTLR start "rule__User__Group__12"
    // InternalSM2.g:3802:1: rule__User__Group__12 : rule__User__Group__12__Impl rule__User__Group__13 ;
    public final void rule__User__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3806:1: ( rule__User__Group__12__Impl rule__User__Group__13 )
            // InternalSM2.g:3807:2: rule__User__Group__12__Impl rule__User__Group__13
            {
            pushFollow(FOLLOW_5);
            rule__User__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__12"


    // $ANTLR start "rule__User__Group__12__Impl"
    // InternalSM2.g:3814:1: rule__User__Group__12__Impl : ( ( rule__User__AmountAccountAssignment_12 ) ) ;
    public final void rule__User__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3818:1: ( ( ( rule__User__AmountAccountAssignment_12 ) ) )
            // InternalSM2.g:3819:1: ( ( rule__User__AmountAccountAssignment_12 ) )
            {
            // InternalSM2.g:3819:1: ( ( rule__User__AmountAccountAssignment_12 ) )
            // InternalSM2.g:3820:2: ( rule__User__AmountAccountAssignment_12 )
            {
             before(grammarAccess.getUserAccess().getAmountAccountAssignment_12()); 
            // InternalSM2.g:3821:2: ( rule__User__AmountAccountAssignment_12 )
            // InternalSM2.g:3821:3: rule__User__AmountAccountAssignment_12
            {
            pushFollow(FOLLOW_2);
            rule__User__AmountAccountAssignment_12();

            state._fsp--;


            }

             after(grammarAccess.getUserAccess().getAmountAccountAssignment_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__12__Impl"


    // $ANTLR start "rule__User__Group__13"
    // InternalSM2.g:3829:1: rule__User__Group__13 : rule__User__Group__13__Impl rule__User__Group__14 ;
    public final void rule__User__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3833:1: ( rule__User__Group__13__Impl rule__User__Group__14 )
            // InternalSM2.g:3834:2: rule__User__Group__13__Impl rule__User__Group__14
            {
            pushFollow(FOLLOW_27);
            rule__User__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__13"


    // $ANTLR start "rule__User__Group__13__Impl"
    // InternalSM2.g:3841:1: rule__User__Group__13__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3845:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3846:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3846:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3847:2: RULE_SEMICOLON
            {
             before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_13()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__13__Impl"


    // $ANTLR start "rule__User__Group__14"
    // InternalSM2.g:3856:1: rule__User__Group__14 : rule__User__Group__14__Impl rule__User__Group__15 ;
    public final void rule__User__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3860:1: ( rule__User__Group__14__Impl rule__User__Group__15 )
            // InternalSM2.g:3861:2: rule__User__Group__14__Impl rule__User__Group__15
            {
            pushFollow(FOLLOW_20);
            rule__User__Group__14__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__User__Group__15();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__14"


    // $ANTLR start "rule__User__Group__14__Impl"
    // InternalSM2.g:3868:1: rule__User__Group__14__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__User__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3872:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:3873:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:3873:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:3874:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_14()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__14__Impl"


    // $ANTLR start "rule__User__Group__15"
    // InternalSM2.g:3883:1: rule__User__Group__15 : rule__User__Group__15__Impl ;
    public final void rule__User__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3887:1: ( rule__User__Group__15__Impl )
            // InternalSM2.g:3888:2: rule__User__Group__15__Impl
            {
            pushFollow(FOLLOW_2);
            rule__User__Group__15__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__15"


    // $ANTLR start "rule__User__Group__15__Impl"
    // InternalSM2.g:3894:1: rule__User__Group__15__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3898:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3899:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3899:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3900:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_15()); 
            // InternalSM2.g:3901:2: ( RULE_EOLINE )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==RULE_EOLINE) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalSM2.g:3901:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_15()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__15__Impl"


    // $ANTLR start "rule__Enum__Group__0"
    // InternalSM2.g:3910:1: rule__Enum__Group__0 : rule__Enum__Group__0__Impl rule__Enum__Group__1 ;
    public final void rule__Enum__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3914:1: ( rule__Enum__Group__0__Impl rule__Enum__Group__1 )
            // InternalSM2.g:3915:2: rule__Enum__Group__0__Impl rule__Enum__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Enum__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__0"


    // $ANTLR start "rule__Enum__Group__0__Impl"
    // InternalSM2.g:3922:1: rule__Enum__Group__0__Impl : ( 'enum' ) ;
    public final void rule__Enum__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3926:1: ( ( 'enum' ) )
            // InternalSM2.g:3927:1: ( 'enum' )
            {
            // InternalSM2.g:3927:1: ( 'enum' )
            // InternalSM2.g:3928:2: 'enum'
            {
             before(grammarAccess.getEnumAccess().getEnumKeyword_0()); 
            match(input,67,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getEnumKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__0__Impl"


    // $ANTLR start "rule__Enum__Group__1"
    // InternalSM2.g:3937:1: rule__Enum__Group__1 : rule__Enum__Group__1__Impl rule__Enum__Group__2 ;
    public final void rule__Enum__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3941:1: ( rule__Enum__Group__1__Impl rule__Enum__Group__2 )
            // InternalSM2.g:3942:2: rule__Enum__Group__1__Impl rule__Enum__Group__2
            {
            pushFollow(FOLLOW_24);
            rule__Enum__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__1"


    // $ANTLR start "rule__Enum__Group__1__Impl"
    // InternalSM2.g:3949:1: rule__Enum__Group__1__Impl : ( ( rule__Enum__NameEnumAssignment_1 ) ) ;
    public final void rule__Enum__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3953:1: ( ( ( rule__Enum__NameEnumAssignment_1 ) ) )
            // InternalSM2.g:3954:1: ( ( rule__Enum__NameEnumAssignment_1 ) )
            {
            // InternalSM2.g:3954:1: ( ( rule__Enum__NameEnumAssignment_1 ) )
            // InternalSM2.g:3955:2: ( rule__Enum__NameEnumAssignment_1 )
            {
             before(grammarAccess.getEnumAccess().getNameEnumAssignment_1()); 
            // InternalSM2.g:3956:2: ( rule__Enum__NameEnumAssignment_1 )
            // InternalSM2.g:3956:3: rule__Enum__NameEnumAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Enum__NameEnumAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEnumAccess().getNameEnumAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__1__Impl"


    // $ANTLR start "rule__Enum__Group__2"
    // InternalSM2.g:3964:1: rule__Enum__Group__2 : rule__Enum__Group__2__Impl rule__Enum__Group__3 ;
    public final void rule__Enum__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3968:1: ( rule__Enum__Group__2__Impl rule__Enum__Group__3 )
            // InternalSM2.g:3969:2: rule__Enum__Group__2__Impl rule__Enum__Group__3
            {
            pushFollow(FOLLOW_30);
            rule__Enum__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__2"


    // $ANTLR start "rule__Enum__Group__2__Impl"
    // InternalSM2.g:3976:1: rule__Enum__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Enum__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3980:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:3981:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:3981:1: ( RULE_OPENKEY )
            // InternalSM2.g:3982:2: RULE_OPENKEY
            {
             before(grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__2__Impl"


    // $ANTLR start "rule__Enum__Group__3"
    // InternalSM2.g:3991:1: rule__Enum__Group__3 : rule__Enum__Group__3__Impl rule__Enum__Group__4 ;
    public final void rule__Enum__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3995:1: ( rule__Enum__Group__3__Impl rule__Enum__Group__4 )
            // InternalSM2.g:3996:2: rule__Enum__Group__3__Impl rule__Enum__Group__4
            {
            pushFollow(FOLLOW_35);
            rule__Enum__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__3"


    // $ANTLR start "rule__Enum__Group__3__Impl"
    // InternalSM2.g:4003:1: rule__Enum__Group__3__Impl : ( ( rule__Enum__ExprAssignment_3 ) ) ;
    public final void rule__Enum__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4007:1: ( ( ( rule__Enum__ExprAssignment_3 ) ) )
            // InternalSM2.g:4008:1: ( ( rule__Enum__ExprAssignment_3 ) )
            {
            // InternalSM2.g:4008:1: ( ( rule__Enum__ExprAssignment_3 ) )
            // InternalSM2.g:4009:2: ( rule__Enum__ExprAssignment_3 )
            {
             before(grammarAccess.getEnumAccess().getExprAssignment_3()); 
            // InternalSM2.g:4010:2: ( rule__Enum__ExprAssignment_3 )
            // InternalSM2.g:4010:3: rule__Enum__ExprAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Enum__ExprAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getEnumAccess().getExprAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__3__Impl"


    // $ANTLR start "rule__Enum__Group__4"
    // InternalSM2.g:4018:1: rule__Enum__Group__4 : rule__Enum__Group__4__Impl rule__Enum__Group__5 ;
    public final void rule__Enum__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4022:1: ( rule__Enum__Group__4__Impl rule__Enum__Group__5 )
            // InternalSM2.g:4023:2: rule__Enum__Group__4__Impl rule__Enum__Group__5
            {
            pushFollow(FOLLOW_35);
            rule__Enum__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__4"


    // $ANTLR start "rule__Enum__Group__4__Impl"
    // InternalSM2.g:4030:1: rule__Enum__Group__4__Impl : ( ( RULE_COMMA )? ) ;
    public final void rule__Enum__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4034:1: ( ( ( RULE_COMMA )? ) )
            // InternalSM2.g:4035:1: ( ( RULE_COMMA )? )
            {
            // InternalSM2.g:4035:1: ( ( RULE_COMMA )? )
            // InternalSM2.g:4036:2: ( RULE_COMMA )?
            {
             before(grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_4()); 
            // InternalSM2.g:4037:2: ( RULE_COMMA )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==RULE_COMMA) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalSM2.g:4037:3: RULE_COMMA
                    {
                    match(input,RULE_COMMA,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__4__Impl"


    // $ANTLR start "rule__Enum__Group__5"
    // InternalSM2.g:4045:1: rule__Enum__Group__5 : rule__Enum__Group__5__Impl rule__Enum__Group__6 ;
    public final void rule__Enum__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4049:1: ( rule__Enum__Group__5__Impl rule__Enum__Group__6 )
            // InternalSM2.g:4050:2: rule__Enum__Group__5__Impl rule__Enum__Group__6
            {
            pushFollow(FOLLOW_5);
            rule__Enum__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__5"


    // $ANTLR start "rule__Enum__Group__5__Impl"
    // InternalSM2.g:4057:1: rule__Enum__Group__5__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Enum__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4061:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:4062:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:4062:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:4063:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_5()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__5__Impl"


    // $ANTLR start "rule__Enum__Group__6"
    // InternalSM2.g:4072:1: rule__Enum__Group__6 : rule__Enum__Group__6__Impl rule__Enum__Group__7 ;
    public final void rule__Enum__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4076:1: ( rule__Enum__Group__6__Impl rule__Enum__Group__7 )
            // InternalSM2.g:4077:2: rule__Enum__Group__6__Impl rule__Enum__Group__7
            {
            pushFollow(FOLLOW_20);
            rule__Enum__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__6"


    // $ANTLR start "rule__Enum__Group__6__Impl"
    // InternalSM2.g:4084:1: rule__Enum__Group__6__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Enum__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4088:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4089:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4089:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4090:2: RULE_SEMICOLON
            {
             before(grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_6()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__6__Impl"


    // $ANTLR start "rule__Enum__Group__7"
    // InternalSM2.g:4099:1: rule__Enum__Group__7 : rule__Enum__Group__7__Impl ;
    public final void rule__Enum__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4103:1: ( rule__Enum__Group__7__Impl )
            // InternalSM2.g:4104:2: rule__Enum__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Enum__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__7"


    // $ANTLR start "rule__Enum__Group__7__Impl"
    // InternalSM2.g:4110:1: rule__Enum__Group__7__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Enum__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4114:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4115:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4115:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4116:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_7()); 
            // InternalSM2.g:4117:2: ( RULE_EOLINE )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==RULE_EOLINE) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:4117:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__7__Impl"


    // $ANTLR start "rule__Property__Group__0"
    // InternalSM2.g:4126:1: rule__Property__Group__0 : rule__Property__Group__0__Impl rule__Property__Group__1 ;
    public final void rule__Property__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4130:1: ( rule__Property__Group__0__Impl rule__Property__Group__1 )
            // InternalSM2.g:4131:2: rule__Property__Group__0__Impl rule__Property__Group__1
            {
            pushFollow(FOLLOW_32);
            rule__Property__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__0"


    // $ANTLR start "rule__Property__Group__0__Impl"
    // InternalSM2.g:4138:1: rule__Property__Group__0__Impl : ( ( rule__Property__TypeAssignment_0 ) ) ;
    public final void rule__Property__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4142:1: ( ( ( rule__Property__TypeAssignment_0 ) ) )
            // InternalSM2.g:4143:1: ( ( rule__Property__TypeAssignment_0 ) )
            {
            // InternalSM2.g:4143:1: ( ( rule__Property__TypeAssignment_0 ) )
            // InternalSM2.g:4144:2: ( rule__Property__TypeAssignment_0 )
            {
             before(grammarAccess.getPropertyAccess().getTypeAssignment_0()); 
            // InternalSM2.g:4145:2: ( rule__Property__TypeAssignment_0 )
            // InternalSM2.g:4145:3: rule__Property__TypeAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Property__TypeAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getPropertyAccess().getTypeAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__0__Impl"


    // $ANTLR start "rule__Property__Group__1"
    // InternalSM2.g:4153:1: rule__Property__Group__1 : rule__Property__Group__1__Impl rule__Property__Group__2 ;
    public final void rule__Property__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4157:1: ( rule__Property__Group__1__Impl rule__Property__Group__2 )
            // InternalSM2.g:4158:2: rule__Property__Group__1__Impl rule__Property__Group__2
            {
            pushFollow(FOLLOW_32);
            rule__Property__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__1"


    // $ANTLR start "rule__Property__Group__1__Impl"
    // InternalSM2.g:4165:1: rule__Property__Group__1__Impl : ( ( rule__Property__VisibilityAssignment_1 )? ) ;
    public final void rule__Property__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4169:1: ( ( ( rule__Property__VisibilityAssignment_1 )? ) )
            // InternalSM2.g:4170:1: ( ( rule__Property__VisibilityAssignment_1 )? )
            {
            // InternalSM2.g:4170:1: ( ( rule__Property__VisibilityAssignment_1 )? )
            // InternalSM2.g:4171:2: ( rule__Property__VisibilityAssignment_1 )?
            {
             before(grammarAccess.getPropertyAccess().getVisibilityAssignment_1()); 
            // InternalSM2.g:4172:2: ( rule__Property__VisibilityAssignment_1 )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( ((LA45_0>=39 && LA45_0<=42)) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalSM2.g:4172:3: rule__Property__VisibilityAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__VisibilityAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPropertyAccess().getVisibilityAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__1__Impl"


    // $ANTLR start "rule__Property__Group__2"
    // InternalSM2.g:4180:1: rule__Property__Group__2 : rule__Property__Group__2__Impl rule__Property__Group__3 ;
    public final void rule__Property__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4184:1: ( rule__Property__Group__2__Impl rule__Property__Group__3 )
            // InternalSM2.g:4185:2: rule__Property__Group__2__Impl rule__Property__Group__3
            {
            pushFollow(FOLLOW_36);
            rule__Property__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__2"


    // $ANTLR start "rule__Property__Group__2__Impl"
    // InternalSM2.g:4192:1: rule__Property__Group__2__Impl : ( ( rule__Property__NamePropertyAssignment_2 ) ) ;
    public final void rule__Property__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4196:1: ( ( ( rule__Property__NamePropertyAssignment_2 ) ) )
            // InternalSM2.g:4197:1: ( ( rule__Property__NamePropertyAssignment_2 ) )
            {
            // InternalSM2.g:4197:1: ( ( rule__Property__NamePropertyAssignment_2 ) )
            // InternalSM2.g:4198:2: ( rule__Property__NamePropertyAssignment_2 )
            {
             before(grammarAccess.getPropertyAccess().getNamePropertyAssignment_2()); 
            // InternalSM2.g:4199:2: ( rule__Property__NamePropertyAssignment_2 )
            // InternalSM2.g:4199:3: rule__Property__NamePropertyAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Property__NamePropertyAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getPropertyAccess().getNamePropertyAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__2__Impl"


    // $ANTLR start "rule__Property__Group__3"
    // InternalSM2.g:4207:1: rule__Property__Group__3 : rule__Property__Group__3__Impl rule__Property__Group__4 ;
    public final void rule__Property__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4211:1: ( rule__Property__Group__3__Impl rule__Property__Group__4 )
            // InternalSM2.g:4212:2: rule__Property__Group__3__Impl rule__Property__Group__4
            {
            pushFollow(FOLLOW_37);
            rule__Property__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__3"


    // $ANTLR start "rule__Property__Group__3__Impl"
    // InternalSM2.g:4219:1: rule__Property__Group__3__Impl : ( '=' ) ;
    public final void rule__Property__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4223:1: ( ( '=' ) )
            // InternalSM2.g:4224:1: ( '=' )
            {
            // InternalSM2.g:4224:1: ( '=' )
            // InternalSM2.g:4225:2: '='
            {
             before(grammarAccess.getPropertyAccess().getEqualsSignKeyword_3()); 
            match(input,68,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getEqualsSignKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__3__Impl"


    // $ANTLR start "rule__Property__Group__4"
    // InternalSM2.g:4234:1: rule__Property__Group__4 : rule__Property__Group__4__Impl rule__Property__Group__5 ;
    public final void rule__Property__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4238:1: ( rule__Property__Group__4__Impl rule__Property__Group__5 )
            // InternalSM2.g:4239:2: rule__Property__Group__4__Impl rule__Property__Group__5
            {
            pushFollow(FOLLOW_37);
            rule__Property__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__4"


    // $ANTLR start "rule__Property__Group__4__Impl"
    // InternalSM2.g:4246:1: rule__Property__Group__4__Impl : ( ( rule__Property__Alternatives_4 )? ) ;
    public final void rule__Property__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4250:1: ( ( ( rule__Property__Alternatives_4 )? ) )
            // InternalSM2.g:4251:1: ( ( rule__Property__Alternatives_4 )? )
            {
            // InternalSM2.g:4251:1: ( ( rule__Property__Alternatives_4 )? )
            // InternalSM2.g:4252:2: ( rule__Property__Alternatives_4 )?
            {
             before(grammarAccess.getPropertyAccess().getAlternatives_4()); 
            // InternalSM2.g:4253:2: ( rule__Property__Alternatives_4 )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( ((LA46_0>=RULE_INT && LA46_0<=RULE_STRING)) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:4253:3: rule__Property__Alternatives_4
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__Alternatives_4();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPropertyAccess().getAlternatives_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__4__Impl"


    // $ANTLR start "rule__Property__Group__5"
    // InternalSM2.g:4261:1: rule__Property__Group__5 : rule__Property__Group__5__Impl rule__Property__Group__6 ;
    public final void rule__Property__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4265:1: ( rule__Property__Group__5__Impl rule__Property__Group__6 )
            // InternalSM2.g:4266:2: rule__Property__Group__5__Impl rule__Property__Group__6
            {
            pushFollow(FOLLOW_20);
            rule__Property__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__5"


    // $ANTLR start "rule__Property__Group__5__Impl"
    // InternalSM2.g:4273:1: rule__Property__Group__5__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Property__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4277:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4278:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4278:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4279:2: RULE_SEMICOLON
            {
             before(grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_5()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__5__Impl"


    // $ANTLR start "rule__Property__Group__6"
    // InternalSM2.g:4288:1: rule__Property__Group__6 : rule__Property__Group__6__Impl ;
    public final void rule__Property__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4292:1: ( rule__Property__Group__6__Impl )
            // InternalSM2.g:4293:2: rule__Property__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Property__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__6"


    // $ANTLR start "rule__Property__Group__6__Impl"
    // InternalSM2.g:4299:1: rule__Property__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Property__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4303:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4304:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4304:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4305:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6()); 
            // InternalSM2.g:4306:2: ( RULE_EOLINE )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==RULE_EOLINE) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalSM2.g:4306:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__6__Impl"


    // $ANTLR start "rule__InputParam__Group__0"
    // InternalSM2.g:4315:1: rule__InputParam__Group__0 : rule__InputParam__Group__0__Impl rule__InputParam__Group__1 ;
    public final void rule__InputParam__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4319:1: ( rule__InputParam__Group__0__Impl rule__InputParam__Group__1 )
            // InternalSM2.g:4320:2: rule__InputParam__Group__0__Impl rule__InputParam__Group__1
            {
            pushFollow(FOLLOW_38);
            rule__InputParam__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InputParam__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__0"


    // $ANTLR start "rule__InputParam__Group__0__Impl"
    // InternalSM2.g:4327:1: rule__InputParam__Group__0__Impl : ( ( rule__InputParam__Group_0__0 ) ) ;
    public final void rule__InputParam__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4331:1: ( ( ( rule__InputParam__Group_0__0 ) ) )
            // InternalSM2.g:4332:1: ( ( rule__InputParam__Group_0__0 ) )
            {
            // InternalSM2.g:4332:1: ( ( rule__InputParam__Group_0__0 ) )
            // InternalSM2.g:4333:2: ( rule__InputParam__Group_0__0 )
            {
             before(grammarAccess.getInputParamAccess().getGroup_0()); 
            // InternalSM2.g:4334:2: ( rule__InputParam__Group_0__0 )
            // InternalSM2.g:4334:3: rule__InputParam__Group_0__0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__0();

            state._fsp--;


            }

             after(grammarAccess.getInputParamAccess().getGroup_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__0__Impl"


    // $ANTLR start "rule__InputParam__Group__1"
    // InternalSM2.g:4342:1: rule__InputParam__Group__1 : rule__InputParam__Group__1__Impl ;
    public final void rule__InputParam__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4346:1: ( rule__InputParam__Group__1__Impl )
            // InternalSM2.g:4347:2: rule__InputParam__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__1"


    // $ANTLR start "rule__InputParam__Group__1__Impl"
    // InternalSM2.g:4353:1: rule__InputParam__Group__1__Impl : ( ( rule__InputParam__CommaAssignment_1 )? ) ;
    public final void rule__InputParam__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4357:1: ( ( ( rule__InputParam__CommaAssignment_1 )? ) )
            // InternalSM2.g:4358:1: ( ( rule__InputParam__CommaAssignment_1 )? )
            {
            // InternalSM2.g:4358:1: ( ( rule__InputParam__CommaAssignment_1 )? )
            // InternalSM2.g:4359:2: ( rule__InputParam__CommaAssignment_1 )?
            {
             before(grammarAccess.getInputParamAccess().getCommaAssignment_1()); 
            // InternalSM2.g:4360:2: ( rule__InputParam__CommaAssignment_1 )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==RULE_COMMA) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalSM2.g:4360:3: rule__InputParam__CommaAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__InputParam__CommaAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getInputParamAccess().getCommaAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__1__Impl"


    // $ANTLR start "rule__InputParam__Group_0__0"
    // InternalSM2.g:4369:1: rule__InputParam__Group_0__0 : rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1 ;
    public final void rule__InputParam__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4373:1: ( rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1 )
            // InternalSM2.g:4374:2: rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1
            {
            pushFollow(FOLLOW_8);
            rule__InputParam__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__0"


    // $ANTLR start "rule__InputParam__Group_0__0__Impl"
    // InternalSM2.g:4381:1: rule__InputParam__Group_0__0__Impl : ( ( rule__InputParam__TypeAssignment_0_0 ) ) ;
    public final void rule__InputParam__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4385:1: ( ( ( rule__InputParam__TypeAssignment_0_0 ) ) )
            // InternalSM2.g:4386:1: ( ( rule__InputParam__TypeAssignment_0_0 ) )
            {
            // InternalSM2.g:4386:1: ( ( rule__InputParam__TypeAssignment_0_0 ) )
            // InternalSM2.g:4387:2: ( rule__InputParam__TypeAssignment_0_0 )
            {
             before(grammarAccess.getInputParamAccess().getTypeAssignment_0_0()); 
            // InternalSM2.g:4388:2: ( rule__InputParam__TypeAssignment_0_0 )
            // InternalSM2.g:4388:3: rule__InputParam__TypeAssignment_0_0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__TypeAssignment_0_0();

            state._fsp--;


            }

             after(grammarAccess.getInputParamAccess().getTypeAssignment_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__0__Impl"


    // $ANTLR start "rule__InputParam__Group_0__1"
    // InternalSM2.g:4396:1: rule__InputParam__Group_0__1 : rule__InputParam__Group_0__1__Impl ;
    public final void rule__InputParam__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4400:1: ( rule__InputParam__Group_0__1__Impl )
            // InternalSM2.g:4401:2: rule__InputParam__Group_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__1"


    // $ANTLR start "rule__InputParam__Group_0__1__Impl"
    // InternalSM2.g:4407:1: rule__InputParam__Group_0__1__Impl : ( ( rule__InputParam__NameParamAssignment_0_1 ) ) ;
    public final void rule__InputParam__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4411:1: ( ( ( rule__InputParam__NameParamAssignment_0_1 ) ) )
            // InternalSM2.g:4412:1: ( ( rule__InputParam__NameParamAssignment_0_1 ) )
            {
            // InternalSM2.g:4412:1: ( ( rule__InputParam__NameParamAssignment_0_1 ) )
            // InternalSM2.g:4413:2: ( rule__InputParam__NameParamAssignment_0_1 )
            {
             before(grammarAccess.getInputParamAccess().getNameParamAssignment_0_1()); 
            // InternalSM2.g:4414:2: ( rule__InputParam__NameParamAssignment_0_1 )
            // InternalSM2.g:4414:3: rule__InputParam__NameParamAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__NameParamAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getInputParamAccess().getNameParamAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__1__Impl"


    // $ANTLR start "rule__Restriction__Group__0"
    // InternalSM2.g:4423:1: rule__Restriction__Group__0 : rule__Restriction__Group__0__Impl rule__Restriction__Group__1 ;
    public final void rule__Restriction__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4427:1: ( rule__Restriction__Group__0__Impl rule__Restriction__Group__1 )
            // InternalSM2.g:4428:2: rule__Restriction__Group__0__Impl rule__Restriction__Group__1
            {
            pushFollow(FOLLOW_21);
            rule__Restriction__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__0"


    // $ANTLR start "rule__Restriction__Group__0__Impl"
    // InternalSM2.g:4435:1: rule__Restriction__Group__0__Impl : ( 'require' ) ;
    public final void rule__Restriction__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4439:1: ( ( 'require' ) )
            // InternalSM2.g:4440:1: ( 'require' )
            {
            // InternalSM2.g:4440:1: ( 'require' )
            // InternalSM2.g:4441:2: 'require'
            {
             before(grammarAccess.getRestrictionAccess().getRequireKeyword_0()); 
            match(input,69,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getRequireKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__0__Impl"


    // $ANTLR start "rule__Restriction__Group__1"
    // InternalSM2.g:4450:1: rule__Restriction__Group__1 : rule__Restriction__Group__1__Impl rule__Restriction__Group__2 ;
    public final void rule__Restriction__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4454:1: ( rule__Restriction__Group__1__Impl rule__Restriction__Group__2 )
            // InternalSM2.g:4455:2: rule__Restriction__Group__1__Impl rule__Restriction__Group__2
            {
            pushFollow(FOLLOW_39);
            rule__Restriction__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__1"


    // $ANTLR start "rule__Restriction__Group__1__Impl"
    // InternalSM2.g:4462:1: rule__Restriction__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Restriction__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4466:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:4467:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:4467:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:4468:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__1__Impl"


    // $ANTLR start "rule__Restriction__Group__2"
    // InternalSM2.g:4477:1: rule__Restriction__Group__2 : rule__Restriction__Group__2__Impl rule__Restriction__Group__3 ;
    public final void rule__Restriction__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4481:1: ( rule__Restriction__Group__2__Impl rule__Restriction__Group__3 )
            // InternalSM2.g:4482:2: rule__Restriction__Group__2__Impl rule__Restriction__Group__3
            {
            pushFollow(FOLLOW_40);
            rule__Restriction__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__2"


    // $ANTLR start "rule__Restriction__Group__2__Impl"
    // InternalSM2.g:4489:1: rule__Restriction__Group__2__Impl : ( ( rule__Restriction__Expr1Assignment_2 ) ) ;
    public final void rule__Restriction__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4493:1: ( ( ( rule__Restriction__Expr1Assignment_2 ) ) )
            // InternalSM2.g:4494:1: ( ( rule__Restriction__Expr1Assignment_2 ) )
            {
            // InternalSM2.g:4494:1: ( ( rule__Restriction__Expr1Assignment_2 ) )
            // InternalSM2.g:4495:2: ( rule__Restriction__Expr1Assignment_2 )
            {
             before(grammarAccess.getRestrictionAccess().getExpr1Assignment_2()); 
            // InternalSM2.g:4496:2: ( rule__Restriction__Expr1Assignment_2 )
            // InternalSM2.g:4496:3: rule__Restriction__Expr1Assignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Expr1Assignment_2();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getExpr1Assignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__2__Impl"


    // $ANTLR start "rule__Restriction__Group__3"
    // InternalSM2.g:4504:1: rule__Restriction__Group__3 : rule__Restriction__Group__3__Impl rule__Restriction__Group__4 ;
    public final void rule__Restriction__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4508:1: ( rule__Restriction__Group__3__Impl rule__Restriction__Group__4 )
            // InternalSM2.g:4509:2: rule__Restriction__Group__3__Impl rule__Restriction__Group__4
            {
            pushFollow(FOLLOW_39);
            rule__Restriction__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__3"


    // $ANTLR start "rule__Restriction__Group__3__Impl"
    // InternalSM2.g:4516:1: rule__Restriction__Group__3__Impl : ( ( rule__Restriction__OperatorAssignment_3 ) ) ;
    public final void rule__Restriction__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4520:1: ( ( ( rule__Restriction__OperatorAssignment_3 ) ) )
            // InternalSM2.g:4521:1: ( ( rule__Restriction__OperatorAssignment_3 ) )
            {
            // InternalSM2.g:4521:1: ( ( rule__Restriction__OperatorAssignment_3 ) )
            // InternalSM2.g:4522:2: ( rule__Restriction__OperatorAssignment_3 )
            {
             before(grammarAccess.getRestrictionAccess().getOperatorAssignment_3()); 
            // InternalSM2.g:4523:2: ( rule__Restriction__OperatorAssignment_3 )
            // InternalSM2.g:4523:3: rule__Restriction__OperatorAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__OperatorAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getOperatorAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__3__Impl"


    // $ANTLR start "rule__Restriction__Group__4"
    // InternalSM2.g:4531:1: rule__Restriction__Group__4 : rule__Restriction__Group__4__Impl rule__Restriction__Group__5 ;
    public final void rule__Restriction__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4535:1: ( rule__Restriction__Group__4__Impl rule__Restriction__Group__5 )
            // InternalSM2.g:4536:2: rule__Restriction__Group__4__Impl rule__Restriction__Group__5
            {
            pushFollow(FOLLOW_31);
            rule__Restriction__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__4"


    // $ANTLR start "rule__Restriction__Group__4__Impl"
    // InternalSM2.g:4543:1: rule__Restriction__Group__4__Impl : ( ( rule__Restriction__Expr2Assignment_4 ) ) ;
    public final void rule__Restriction__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4547:1: ( ( ( rule__Restriction__Expr2Assignment_4 ) ) )
            // InternalSM2.g:4548:1: ( ( rule__Restriction__Expr2Assignment_4 ) )
            {
            // InternalSM2.g:4548:1: ( ( rule__Restriction__Expr2Assignment_4 ) )
            // InternalSM2.g:4549:2: ( rule__Restriction__Expr2Assignment_4 )
            {
             before(grammarAccess.getRestrictionAccess().getExpr2Assignment_4()); 
            // InternalSM2.g:4550:2: ( rule__Restriction__Expr2Assignment_4 )
            // InternalSM2.g:4550:3: rule__Restriction__Expr2Assignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Expr2Assignment_4();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getExpr2Assignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__4__Impl"


    // $ANTLR start "rule__Restriction__Group__5"
    // InternalSM2.g:4558:1: rule__Restriction__Group__5 : rule__Restriction__Group__5__Impl rule__Restriction__Group__6 ;
    public final void rule__Restriction__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4562:1: ( rule__Restriction__Group__5__Impl rule__Restriction__Group__6 )
            // InternalSM2.g:4563:2: rule__Restriction__Group__5__Impl rule__Restriction__Group__6
            {
            pushFollow(FOLLOW_5);
            rule__Restriction__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__5"


    // $ANTLR start "rule__Restriction__Group__5__Impl"
    // InternalSM2.g:4570:1: rule__Restriction__Group__5__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Restriction__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4574:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:4575:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:4575:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:4576:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__5__Impl"


    // $ANTLR start "rule__Restriction__Group__6"
    // InternalSM2.g:4585:1: rule__Restriction__Group__6 : rule__Restriction__Group__6__Impl rule__Restriction__Group__7 ;
    public final void rule__Restriction__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4589:1: ( rule__Restriction__Group__6__Impl rule__Restriction__Group__7 )
            // InternalSM2.g:4590:2: rule__Restriction__Group__6__Impl rule__Restriction__Group__7
            {
            pushFollow(FOLLOW_20);
            rule__Restriction__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__6"


    // $ANTLR start "rule__Restriction__Group__6__Impl"
    // InternalSM2.g:4597:1: rule__Restriction__Group__6__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Restriction__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4601:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4602:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4602:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4603:2: RULE_SEMICOLON
            {
             before(grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__6__Impl"


    // $ANTLR start "rule__Restriction__Group__7"
    // InternalSM2.g:4612:1: rule__Restriction__Group__7 : rule__Restriction__Group__7__Impl ;
    public final void rule__Restriction__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4616:1: ( rule__Restriction__Group__7__Impl )
            // InternalSM2.g:4617:2: rule__Restriction__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__7"


    // $ANTLR start "rule__Restriction__Group__7__Impl"
    // InternalSM2.g:4623:1: rule__Restriction__Group__7__Impl : ( RULE_EOLINE ) ;
    public final void rule__Restriction__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4627:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:4628:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:4628:1: ( RULE_EOLINE )
            // InternalSM2.g:4629:2: RULE_EOLINE
            {
             before(grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__7__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__0"
    // InternalSM2.g:4639:1: rule__RestrictionGas__Group__0 : rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1 ;
    public final void rule__RestrictionGas__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4643:1: ( rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1 )
            // InternalSM2.g:4644:2: rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1
            {
            pushFollow(FOLLOW_21);
            rule__RestrictionGas__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__0"


    // $ANTLR start "rule__RestrictionGas__Group__0__Impl"
    // InternalSM2.g:4651:1: rule__RestrictionGas__Group__0__Impl : ( 'require' ) ;
    public final void rule__RestrictionGas__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4655:1: ( ( 'require' ) )
            // InternalSM2.g:4656:1: ( 'require' )
            {
            // InternalSM2.g:4656:1: ( 'require' )
            // InternalSM2.g:4657:2: 'require'
            {
             before(grammarAccess.getRestrictionGasAccess().getRequireKeyword_0()); 
            match(input,69,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getRequireKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__0__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__1"
    // InternalSM2.g:4666:1: rule__RestrictionGas__Group__1 : rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2 ;
    public final void rule__RestrictionGas__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4670:1: ( rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2 )
            // InternalSM2.g:4671:2: rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2
            {
            pushFollow(FOLLOW_39);
            rule__RestrictionGas__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__1"


    // $ANTLR start "rule__RestrictionGas__Group__1__Impl"
    // InternalSM2.g:4678:1: rule__RestrictionGas__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__RestrictionGas__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4682:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:4683:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:4683:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:4684:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__1__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__2"
    // InternalSM2.g:4693:1: rule__RestrictionGas__Group__2 : rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3 ;
    public final void rule__RestrictionGas__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4697:1: ( rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3 )
            // InternalSM2.g:4698:2: rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3
            {
            pushFollow(FOLLOW_40);
            rule__RestrictionGas__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__2"


    // $ANTLR start "rule__RestrictionGas__Group__2__Impl"
    // InternalSM2.g:4705:1: rule__RestrictionGas__Group__2__Impl : ( ( rule__RestrictionGas__ExprAssignment_2 ) ) ;
    public final void rule__RestrictionGas__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4709:1: ( ( ( rule__RestrictionGas__ExprAssignment_2 ) ) )
            // InternalSM2.g:4710:1: ( ( rule__RestrictionGas__ExprAssignment_2 ) )
            {
            // InternalSM2.g:4710:1: ( ( rule__RestrictionGas__ExprAssignment_2 ) )
            // InternalSM2.g:4711:2: ( rule__RestrictionGas__ExprAssignment_2 )
            {
             before(grammarAccess.getRestrictionGasAccess().getExprAssignment_2()); 
            // InternalSM2.g:4712:2: ( rule__RestrictionGas__ExprAssignment_2 )
            // InternalSM2.g:4712:3: rule__RestrictionGas__ExprAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__ExprAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getExprAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__2__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__3"
    // InternalSM2.g:4720:1: rule__RestrictionGas__Group__3 : rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4 ;
    public final void rule__RestrictionGas__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4724:1: ( rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4 )
            // InternalSM2.g:4725:2: rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4
            {
            pushFollow(FOLLOW_41);
            rule__RestrictionGas__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__3"


    // $ANTLR start "rule__RestrictionGas__Group__3__Impl"
    // InternalSM2.g:4732:1: rule__RestrictionGas__Group__3__Impl : ( ( rule__RestrictionGas__OperatorAssignment_3 ) ) ;
    public final void rule__RestrictionGas__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4736:1: ( ( ( rule__RestrictionGas__OperatorAssignment_3 ) ) )
            // InternalSM2.g:4737:1: ( ( rule__RestrictionGas__OperatorAssignment_3 ) )
            {
            // InternalSM2.g:4737:1: ( ( rule__RestrictionGas__OperatorAssignment_3 ) )
            // InternalSM2.g:4738:2: ( rule__RestrictionGas__OperatorAssignment_3 )
            {
             before(grammarAccess.getRestrictionGasAccess().getOperatorAssignment_3()); 
            // InternalSM2.g:4739:2: ( rule__RestrictionGas__OperatorAssignment_3 )
            // InternalSM2.g:4739:3: rule__RestrictionGas__OperatorAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__OperatorAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getOperatorAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__3__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__4"
    // InternalSM2.g:4747:1: rule__RestrictionGas__Group__4 : rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5 ;
    public final void rule__RestrictionGas__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4751:1: ( rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5 )
            // InternalSM2.g:4752:2: rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5
            {
            pushFollow(FOLLOW_42);
            rule__RestrictionGas__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__4"


    // $ANTLR start "rule__RestrictionGas__Group__4__Impl"
    // InternalSM2.g:4759:1: rule__RestrictionGas__Group__4__Impl : ( ( rule__RestrictionGas__AmountAssignment_4 ) ) ;
    public final void rule__RestrictionGas__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4763:1: ( ( ( rule__RestrictionGas__AmountAssignment_4 ) ) )
            // InternalSM2.g:4764:1: ( ( rule__RestrictionGas__AmountAssignment_4 ) )
            {
            // InternalSM2.g:4764:1: ( ( rule__RestrictionGas__AmountAssignment_4 ) )
            // InternalSM2.g:4765:2: ( rule__RestrictionGas__AmountAssignment_4 )
            {
             before(grammarAccess.getRestrictionGasAccess().getAmountAssignment_4()); 
            // InternalSM2.g:4766:2: ( rule__RestrictionGas__AmountAssignment_4 )
            // InternalSM2.g:4766:3: rule__RestrictionGas__AmountAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__AmountAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getAmountAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__4__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__5"
    // InternalSM2.g:4774:1: rule__RestrictionGas__Group__5 : rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6 ;
    public final void rule__RestrictionGas__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4778:1: ( rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6 )
            // InternalSM2.g:4779:2: rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6
            {
            pushFollow(FOLLOW_31);
            rule__RestrictionGas__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__5"


    // $ANTLR start "rule__RestrictionGas__Group__5__Impl"
    // InternalSM2.g:4786:1: rule__RestrictionGas__Group__5__Impl : ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) ) ;
    public final void rule__RestrictionGas__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4790:1: ( ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) ) )
            // InternalSM2.g:4791:1: ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) )
            {
            // InternalSM2.g:4791:1: ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) )
            // InternalSM2.g:4792:2: ( rule__RestrictionGas__TypeCoinAssignment_5 )
            {
             before(grammarAccess.getRestrictionGasAccess().getTypeCoinAssignment_5()); 
            // InternalSM2.g:4793:2: ( rule__RestrictionGas__TypeCoinAssignment_5 )
            // InternalSM2.g:4793:3: rule__RestrictionGas__TypeCoinAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__TypeCoinAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getTypeCoinAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__5__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__6"
    // InternalSM2.g:4801:1: rule__RestrictionGas__Group__6 : rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7 ;
    public final void rule__RestrictionGas__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4805:1: ( rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7 )
            // InternalSM2.g:4806:2: rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7
            {
            pushFollow(FOLLOW_5);
            rule__RestrictionGas__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__6"


    // $ANTLR start "rule__RestrictionGas__Group__6__Impl"
    // InternalSM2.g:4813:1: rule__RestrictionGas__Group__6__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__RestrictionGas__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4817:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:4818:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:4818:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:4819:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__6__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__7"
    // InternalSM2.g:4828:1: rule__RestrictionGas__Group__7 : rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8 ;
    public final void rule__RestrictionGas__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4832:1: ( rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8 )
            // InternalSM2.g:4833:2: rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8
            {
            pushFollow(FOLLOW_20);
            rule__RestrictionGas__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__7"


    // $ANTLR start "rule__RestrictionGas__Group__7__Impl"
    // InternalSM2.g:4840:1: rule__RestrictionGas__Group__7__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__RestrictionGas__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4844:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4845:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4845:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4846:2: RULE_SEMICOLON
            {
             before(grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__7__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__8"
    // InternalSM2.g:4855:1: rule__RestrictionGas__Group__8 : rule__RestrictionGas__Group__8__Impl ;
    public final void rule__RestrictionGas__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4859:1: ( rule__RestrictionGas__Group__8__Impl )
            // InternalSM2.g:4860:2: rule__RestrictionGas__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__8"


    // $ANTLR start "rule__RestrictionGas__Group__8__Impl"
    // InternalSM2.g:4866:1: rule__RestrictionGas__Group__8__Impl : ( RULE_EOLINE ) ;
    public final void rule__RestrictionGas__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4870:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:4871:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:4871:1: ( RULE_EOLINE )
            // InternalSM2.g:4872:2: RULE_EOLINE
            {
             before(grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__8__Impl"


    // $ANTLR start "rule__Clause__Group__0"
    // InternalSM2.g:4882:1: rule__Clause__Group__0 : rule__Clause__Group__0__Impl rule__Clause__Group__1 ;
    public final void rule__Clause__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4886:1: ( rule__Clause__Group__0__Impl rule__Clause__Group__1 )
            // InternalSM2.g:4887:2: rule__Clause__Group__0__Impl rule__Clause__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Clause__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__0"


    // $ANTLR start "rule__Clause__Group__0__Impl"
    // InternalSM2.g:4894:1: rule__Clause__Group__0__Impl : ( 'function' ) ;
    public final void rule__Clause__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4898:1: ( ( 'function' ) )
            // InternalSM2.g:4899:1: ( 'function' )
            {
            // InternalSM2.g:4899:1: ( 'function' )
            // InternalSM2.g:4900:2: 'function'
            {
             before(grammarAccess.getClauseAccess().getFunctionKeyword_0()); 
            match(input,70,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getFunctionKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__0__Impl"


    // $ANTLR start "rule__Clause__Group__1"
    // InternalSM2.g:4909:1: rule__Clause__Group__1 : rule__Clause__Group__1__Impl rule__Clause__Group__2 ;
    public final void rule__Clause__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4913:1: ( rule__Clause__Group__1__Impl rule__Clause__Group__2 )
            // InternalSM2.g:4914:2: rule__Clause__Group__1__Impl rule__Clause__Group__2
            {
            pushFollow(FOLLOW_21);
            rule__Clause__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__1"


    // $ANTLR start "rule__Clause__Group__1__Impl"
    // InternalSM2.g:4921:1: rule__Clause__Group__1__Impl : ( ( rule__Clause__NameFunctionAssignment_1 ) ) ;
    public final void rule__Clause__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4925:1: ( ( ( rule__Clause__NameFunctionAssignment_1 ) ) )
            // InternalSM2.g:4926:1: ( ( rule__Clause__NameFunctionAssignment_1 ) )
            {
            // InternalSM2.g:4926:1: ( ( rule__Clause__NameFunctionAssignment_1 ) )
            // InternalSM2.g:4927:2: ( rule__Clause__NameFunctionAssignment_1 )
            {
             before(grammarAccess.getClauseAccess().getNameFunctionAssignment_1()); 
            // InternalSM2.g:4928:2: ( rule__Clause__NameFunctionAssignment_1 )
            // InternalSM2.g:4928:3: rule__Clause__NameFunctionAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Clause__NameFunctionAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getNameFunctionAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__1__Impl"


    // $ANTLR start "rule__Clause__Group__2"
    // InternalSM2.g:4936:1: rule__Clause__Group__2 : rule__Clause__Group__2__Impl rule__Clause__Group__3 ;
    public final void rule__Clause__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4940:1: ( rule__Clause__Group__2__Impl rule__Clause__Group__3 )
            // InternalSM2.g:4941:2: rule__Clause__Group__2__Impl rule__Clause__Group__3
            {
            pushFollow(FOLLOW_8);
            rule__Clause__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__2"


    // $ANTLR start "rule__Clause__Group__2__Impl"
    // InternalSM2.g:4948:1: rule__Clause__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Clause__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4952:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:4953:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:4953:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:4954:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__2__Impl"


    // $ANTLR start "rule__Clause__Group__3"
    // InternalSM2.g:4963:1: rule__Clause__Group__3 : rule__Clause__Group__3__Impl rule__Clause__Group__4 ;
    public final void rule__Clause__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4967:1: ( rule__Clause__Group__3__Impl rule__Clause__Group__4 )
            // InternalSM2.g:4968:2: rule__Clause__Group__3__Impl rule__Clause__Group__4
            {
            pushFollow(FOLLOW_43);
            rule__Clause__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__3"


    // $ANTLR start "rule__Clause__Group__3__Impl"
    // InternalSM2.g:4975:1: rule__Clause__Group__3__Impl : ( ( rule__Clause__InputParamsAssignment_3 ) ) ;
    public final void rule__Clause__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4979:1: ( ( ( rule__Clause__InputParamsAssignment_3 ) ) )
            // InternalSM2.g:4980:1: ( ( rule__Clause__InputParamsAssignment_3 ) )
            {
            // InternalSM2.g:4980:1: ( ( rule__Clause__InputParamsAssignment_3 ) )
            // InternalSM2.g:4981:2: ( rule__Clause__InputParamsAssignment_3 )
            {
             before(grammarAccess.getClauseAccess().getInputParamsAssignment_3()); 
            // InternalSM2.g:4982:2: ( rule__Clause__InputParamsAssignment_3 )
            // InternalSM2.g:4982:3: rule__Clause__InputParamsAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Clause__InputParamsAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getInputParamsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__3__Impl"


    // $ANTLR start "rule__Clause__Group__4"
    // InternalSM2.g:4990:1: rule__Clause__Group__4 : rule__Clause__Group__4__Impl rule__Clause__Group__5 ;
    public final void rule__Clause__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4994:1: ( rule__Clause__Group__4__Impl rule__Clause__Group__5 )
            // InternalSM2.g:4995:2: rule__Clause__Group__4__Impl rule__Clause__Group__5
            {
            pushFollow(FOLLOW_44);
            rule__Clause__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__4"


    // $ANTLR start "rule__Clause__Group__4__Impl"
    // InternalSM2.g:5002:1: rule__Clause__Group__4__Impl : ( ( rule__Clause__VisibilityAccessAssignment_4 ) ) ;
    public final void rule__Clause__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5006:1: ( ( ( rule__Clause__VisibilityAccessAssignment_4 ) ) )
            // InternalSM2.g:5007:1: ( ( rule__Clause__VisibilityAccessAssignment_4 ) )
            {
            // InternalSM2.g:5007:1: ( ( rule__Clause__VisibilityAccessAssignment_4 ) )
            // InternalSM2.g:5008:2: ( rule__Clause__VisibilityAccessAssignment_4 )
            {
             before(grammarAccess.getClauseAccess().getVisibilityAccessAssignment_4()); 
            // InternalSM2.g:5009:2: ( rule__Clause__VisibilityAccessAssignment_4 )
            // InternalSM2.g:5009:3: rule__Clause__VisibilityAccessAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Clause__VisibilityAccessAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getVisibilityAccessAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__4__Impl"


    // $ANTLR start "rule__Clause__Group__5"
    // InternalSM2.g:5017:1: rule__Clause__Group__5 : rule__Clause__Group__5__Impl rule__Clause__Group__6 ;
    public final void rule__Clause__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5021:1: ( rule__Clause__Group__5__Impl rule__Clause__Group__6 )
            // InternalSM2.g:5022:2: rule__Clause__Group__5__Impl rule__Clause__Group__6
            {
            pushFollow(FOLLOW_44);
            rule__Clause__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__5"


    // $ANTLR start "rule__Clause__Group__5__Impl"
    // InternalSM2.g:5029:1: rule__Clause__Group__5__Impl : ( ( rule__Clause__ModifierAssignment_5 )? ) ;
    public final void rule__Clause__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5033:1: ( ( ( rule__Clause__ModifierAssignment_5 )? ) )
            // InternalSM2.g:5034:1: ( ( rule__Clause__ModifierAssignment_5 )? )
            {
            // InternalSM2.g:5034:1: ( ( rule__Clause__ModifierAssignment_5 )? )
            // InternalSM2.g:5035:2: ( rule__Clause__ModifierAssignment_5 )?
            {
             before(grammarAccess.getClauseAccess().getModifierAssignment_5()); 
            // InternalSM2.g:5036:2: ( rule__Clause__ModifierAssignment_5 )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==RULE_ID) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // InternalSM2.g:5036:3: rule__Clause__ModifierAssignment_5
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__ModifierAssignment_5();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getModifierAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__5__Impl"


    // $ANTLR start "rule__Clause__Group__6"
    // InternalSM2.g:5044:1: rule__Clause__Group__6 : rule__Clause__Group__6__Impl rule__Clause__Group__7 ;
    public final void rule__Clause__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5048:1: ( rule__Clause__Group__6__Impl rule__Clause__Group__7 )
            // InternalSM2.g:5049:2: rule__Clause__Group__6__Impl rule__Clause__Group__7
            {
            pushFollow(FOLLOW_24);
            rule__Clause__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__6"


    // $ANTLR start "rule__Clause__Group__6__Impl"
    // InternalSM2.g:5056:1: rule__Clause__Group__6__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Clause__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5060:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:5061:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:5061:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:5062:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__6__Impl"


    // $ANTLR start "rule__Clause__Group__7"
    // InternalSM2.g:5071:1: rule__Clause__Group__7 : rule__Clause__Group__7__Impl rule__Clause__Group__8 ;
    public final void rule__Clause__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5075:1: ( rule__Clause__Group__7__Impl rule__Clause__Group__8 )
            // InternalSM2.g:5076:2: rule__Clause__Group__7__Impl rule__Clause__Group__8
            {
            pushFollow(FOLLOW_20);
            rule__Clause__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__7"


    // $ANTLR start "rule__Clause__Group__7__Impl"
    // InternalSM2.g:5083:1: rule__Clause__Group__7__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Clause__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5087:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:5088:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:5088:1: ( RULE_OPENKEY )
            // InternalSM2.g:5089:2: RULE_OPENKEY
            {
             before(grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_7()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__7__Impl"


    // $ANTLR start "rule__Clause__Group__8"
    // InternalSM2.g:5098:1: rule__Clause__Group__8 : rule__Clause__Group__8__Impl rule__Clause__Group__9 ;
    public final void rule__Clause__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5102:1: ( rule__Clause__Group__8__Impl rule__Clause__Group__9 )
            // InternalSM2.g:5103:2: rule__Clause__Group__8__Impl rule__Clause__Group__9
            {
            pushFollow(FOLLOW_45);
            rule__Clause__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__8"


    // $ANTLR start "rule__Clause__Group__8__Impl"
    // InternalSM2.g:5110:1: rule__Clause__Group__8__Impl : ( RULE_EOLINE ) ;
    public final void rule__Clause__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5114:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:5115:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:5115:1: ( RULE_EOLINE )
            // InternalSM2.g:5116:2: RULE_EOLINE
            {
             before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_8()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__8__Impl"


    // $ANTLR start "rule__Clause__Group__9"
    // InternalSM2.g:5125:1: rule__Clause__Group__9 : rule__Clause__Group__9__Impl rule__Clause__Group__10 ;
    public final void rule__Clause__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5129:1: ( rule__Clause__Group__9__Impl rule__Clause__Group__10 )
            // InternalSM2.g:5130:2: rule__Clause__Group__9__Impl rule__Clause__Group__10
            {
            pushFollow(FOLLOW_45);
            rule__Clause__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__9"


    // $ANTLR start "rule__Clause__Group__9__Impl"
    // InternalSM2.g:5137:1: rule__Clause__Group__9__Impl : ( ( rule__Clause__RestrictionAssignment_9 )? ) ;
    public final void rule__Clause__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5141:1: ( ( ( rule__Clause__RestrictionAssignment_9 )? ) )
            // InternalSM2.g:5142:1: ( ( rule__Clause__RestrictionAssignment_9 )? )
            {
            // InternalSM2.g:5142:1: ( ( rule__Clause__RestrictionAssignment_9 )? )
            // InternalSM2.g:5143:2: ( rule__Clause__RestrictionAssignment_9 )?
            {
             before(grammarAccess.getClauseAccess().getRestrictionAssignment_9()); 
            // InternalSM2.g:5144:2: ( rule__Clause__RestrictionAssignment_9 )?
            int alt50=2;
            alt50 = dfa50.predict(input);
            switch (alt50) {
                case 1 :
                    // InternalSM2.g:5144:3: rule__Clause__RestrictionAssignment_9
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__RestrictionAssignment_9();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getRestrictionAssignment_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__9__Impl"


    // $ANTLR start "rule__Clause__Group__10"
    // InternalSM2.g:5152:1: rule__Clause__Group__10 : rule__Clause__Group__10__Impl rule__Clause__Group__11 ;
    public final void rule__Clause__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5156:1: ( rule__Clause__Group__10__Impl rule__Clause__Group__11 )
            // InternalSM2.g:5157:2: rule__Clause__Group__10__Impl rule__Clause__Group__11
            {
            pushFollow(FOLLOW_45);
            rule__Clause__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__10"


    // $ANTLR start "rule__Clause__Group__10__Impl"
    // InternalSM2.g:5164:1: rule__Clause__Group__10__Impl : ( ( rule__Clause__RestrictionGasAssignment_10 )? ) ;
    public final void rule__Clause__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5168:1: ( ( ( rule__Clause__RestrictionGasAssignment_10 )? ) )
            // InternalSM2.g:5169:1: ( ( rule__Clause__RestrictionGasAssignment_10 )? )
            {
            // InternalSM2.g:5169:1: ( ( rule__Clause__RestrictionGasAssignment_10 )? )
            // InternalSM2.g:5170:2: ( rule__Clause__RestrictionGasAssignment_10 )?
            {
             before(grammarAccess.getClauseAccess().getRestrictionGasAssignment_10()); 
            // InternalSM2.g:5171:2: ( rule__Clause__RestrictionGasAssignment_10 )?
            int alt51=2;
            int LA51_0 = input.LA(1);

            if ( (LA51_0==69) ) {
                alt51=1;
            }
            switch (alt51) {
                case 1 :
                    // InternalSM2.g:5171:3: rule__Clause__RestrictionGasAssignment_10
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__RestrictionGasAssignment_10();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getRestrictionGasAssignment_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__10__Impl"


    // $ANTLR start "rule__Clause__Group__11"
    // InternalSM2.g:5179:1: rule__Clause__Group__11 : rule__Clause__Group__11__Impl rule__Clause__Group__12 ;
    public final void rule__Clause__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5183:1: ( rule__Clause__Group__11__Impl rule__Clause__Group__12 )
            // InternalSM2.g:5184:2: rule__Clause__Group__11__Impl rule__Clause__Group__12
            {
            pushFollow(FOLLOW_45);
            rule__Clause__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__11"


    // $ANTLR start "rule__Clause__Group__11__Impl"
    // InternalSM2.g:5191:1: rule__Clause__Group__11__Impl : ( ( rule__Clause__ExpressionAssignment_11 )? ) ;
    public final void rule__Clause__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5195:1: ( ( ( rule__Clause__ExpressionAssignment_11 )? ) )
            // InternalSM2.g:5196:1: ( ( rule__Clause__ExpressionAssignment_11 )? )
            {
            // InternalSM2.g:5196:1: ( ( rule__Clause__ExpressionAssignment_11 )? )
            // InternalSM2.g:5197:2: ( rule__Clause__ExpressionAssignment_11 )?
            {
             before(grammarAccess.getClauseAccess().getExpressionAssignment_11()); 
            // InternalSM2.g:5198:2: ( rule__Clause__ExpressionAssignment_11 )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( ((LA52_0>=RULE_INT && LA52_0<=RULE_STRING)||LA52_0==RULE_OPENPARENTHESIS) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalSM2.g:5198:3: rule__Clause__ExpressionAssignment_11
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__ExpressionAssignment_11();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getExpressionAssignment_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__11__Impl"


    // $ANTLR start "rule__Clause__Group__12"
    // InternalSM2.g:5206:1: rule__Clause__Group__12 : rule__Clause__Group__12__Impl rule__Clause__Group__13 ;
    public final void rule__Clause__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5210:1: ( rule__Clause__Group__12__Impl rule__Clause__Group__13 )
            // InternalSM2.g:5211:2: rule__Clause__Group__12__Impl rule__Clause__Group__13
            {
            pushFollow(FOLLOW_45);
            rule__Clause__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__12"


    // $ANTLR start "rule__Clause__Group__12__Impl"
    // InternalSM2.g:5218:1: rule__Clause__Group__12__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Clause__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5222:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:5223:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:5223:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:5224:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_12()); 
            // InternalSM2.g:5225:2: ( RULE_EOLINE )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==RULE_EOLINE) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // InternalSM2.g:5225:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__12__Impl"


    // $ANTLR start "rule__Clause__Group__13"
    // InternalSM2.g:5233:1: rule__Clause__Group__13 : rule__Clause__Group__13__Impl rule__Clause__Group__14 ;
    public final void rule__Clause__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5237:1: ( rule__Clause__Group__13__Impl rule__Clause__Group__14 )
            // InternalSM2.g:5238:2: rule__Clause__Group__13__Impl rule__Clause__Group__14
            {
            pushFollow(FOLLOW_20);
            rule__Clause__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__13"


    // $ANTLR start "rule__Clause__Group__13__Impl"
    // InternalSM2.g:5245:1: rule__Clause__Group__13__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Clause__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5249:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:5250:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:5250:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:5251:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_13()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__13__Impl"


    // $ANTLR start "rule__Clause__Group__14"
    // InternalSM2.g:5260:1: rule__Clause__Group__14 : rule__Clause__Group__14__Impl ;
    public final void rule__Clause__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5264:1: ( rule__Clause__Group__14__Impl )
            // InternalSM2.g:5265:2: rule__Clause__Group__14__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Clause__Group__14__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__14"


    // $ANTLR start "rule__Clause__Group__14__Impl"
    // InternalSM2.g:5271:1: rule__Clause__Group__14__Impl : ( RULE_EOLINE ) ;
    public final void rule__Clause__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5275:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:5276:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:5276:1: ( RULE_EOLINE )
            // InternalSM2.g:5277:2: RULE_EOLINE
            {
             before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_14()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__14__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__0"
    // InternalSM2.g:5287:1: rule__ArithmethicalExpression__Group_0__0 : rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1 ;
    public final void rule__ArithmethicalExpression__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5291:1: ( rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1 )
            // InternalSM2.g:5292:2: rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1
            {
            pushFollow(FOLLOW_41);
            rule__ArithmethicalExpression__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__0__Impl"
    // InternalSM2.g:5299:1: rule__ArithmethicalExpression__Group_0__0__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__ArithmethicalExpression__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5303:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:5304:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:5304:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:5305:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__1"
    // InternalSM2.g:5314:1: rule__ArithmethicalExpression__Group_0__1 : rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2 ;
    public final void rule__ArithmethicalExpression__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5318:1: ( rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2 )
            // InternalSM2.g:5319:2: rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2
            {
            pushFollow(FOLLOW_46);
            rule__ArithmethicalExpression__Group_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__1__Impl"
    // InternalSM2.g:5326:1: rule__ArithmethicalExpression__Group_0__1__Impl : ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5330:1: ( ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) ) )
            // InternalSM2.g:5331:1: ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) )
            {
            // InternalSM2.g:5331:1: ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) )
            // InternalSM2.g:5332:2: ( rule__ArithmethicalExpression__Op1Assignment_0_1 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_0_1()); 
            // InternalSM2.g:5333:2: ( rule__ArithmethicalExpression__Op1Assignment_0_1 )
            // InternalSM2.g:5333:3: rule__ArithmethicalExpression__Op1Assignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op1Assignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__1__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__2"
    // InternalSM2.g:5341:1: rule__ArithmethicalExpression__Group_0__2 : rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3 ;
    public final void rule__ArithmethicalExpression__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5345:1: ( rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3 )
            // InternalSM2.g:5346:2: rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3
            {
            pushFollow(FOLLOW_41);
            rule__ArithmethicalExpression__Group_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__2"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__2__Impl"
    // InternalSM2.g:5353:1: rule__ArithmethicalExpression__Group_0__2__Impl : ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5357:1: ( ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) ) )
            // InternalSM2.g:5358:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) )
            {
            // InternalSM2.g:5358:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) )
            // InternalSM2.g:5359:2: ( rule__ArithmethicalExpression__OperatorAssignment_0_2 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_0_2()); 
            // InternalSM2.g:5360:2: ( rule__ArithmethicalExpression__OperatorAssignment_0_2 )
            // InternalSM2.g:5360:3: rule__ArithmethicalExpression__OperatorAssignment_0_2
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__OperatorAssignment_0_2();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__2__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__3"
    // InternalSM2.g:5368:1: rule__ArithmethicalExpression__Group_0__3 : rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4 ;
    public final void rule__ArithmethicalExpression__Group_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5372:1: ( rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4 )
            // InternalSM2.g:5373:2: rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4
            {
            pushFollow(FOLLOW_31);
            rule__ArithmethicalExpression__Group_0__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__3"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__3__Impl"
    // InternalSM2.g:5380:1: rule__ArithmethicalExpression__Group_0__3__Impl : ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5384:1: ( ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) ) )
            // InternalSM2.g:5385:1: ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) )
            {
            // InternalSM2.g:5385:1: ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) )
            // InternalSM2.g:5386:2: ( rule__ArithmethicalExpression__Op2Assignment_0_3 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_0_3()); 
            // InternalSM2.g:5387:2: ( rule__ArithmethicalExpression__Op2Assignment_0_3 )
            // InternalSM2.g:5387:3: rule__ArithmethicalExpression__Op2Assignment_0_3
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op2Assignment_0_3();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__3__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__4"
    // InternalSM2.g:5395:1: rule__ArithmethicalExpression__Group_0__4 : rule__ArithmethicalExpression__Group_0__4__Impl ;
    public final void rule__ArithmethicalExpression__Group_0__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5399:1: ( rule__ArithmethicalExpression__Group_0__4__Impl )
            // InternalSM2.g:5400:2: rule__ArithmethicalExpression__Group_0__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__4"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__4__Impl"
    // InternalSM2.g:5406:1: rule__ArithmethicalExpression__Group_0__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__ArithmethicalExpression__Group_0__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5410:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:5411:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:5411:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:5412:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__4__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__0"
    // InternalSM2.g:5422:1: rule__ArithmethicalExpression__Group_1__0 : rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1 ;
    public final void rule__ArithmethicalExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5426:1: ( rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1 )
            // InternalSM2.g:5427:2: rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1
            {
            pushFollow(FOLLOW_46);
            rule__ArithmethicalExpression__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__0__Impl"
    // InternalSM2.g:5434:1: rule__ArithmethicalExpression__Group_1__0__Impl : ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5438:1: ( ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) ) )
            // InternalSM2.g:5439:1: ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) )
            {
            // InternalSM2.g:5439:1: ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) )
            // InternalSM2.g:5440:2: ( rule__ArithmethicalExpression__Op1Assignment_1_0 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_1_0()); 
            // InternalSM2.g:5441:2: ( rule__ArithmethicalExpression__Op1Assignment_1_0 )
            // InternalSM2.g:5441:3: rule__ArithmethicalExpression__Op1Assignment_1_0
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op1Assignment_1_0();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__1"
    // InternalSM2.g:5449:1: rule__ArithmethicalExpression__Group_1__1 : rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2 ;
    public final void rule__ArithmethicalExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5453:1: ( rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2 )
            // InternalSM2.g:5454:2: rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2
            {
            pushFollow(FOLLOW_41);
            rule__ArithmethicalExpression__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__1__Impl"
    // InternalSM2.g:5461:1: rule__ArithmethicalExpression__Group_1__1__Impl : ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5465:1: ( ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) ) )
            // InternalSM2.g:5466:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) )
            {
            // InternalSM2.g:5466:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) )
            // InternalSM2.g:5467:2: ( rule__ArithmethicalExpression__OperatorAssignment_1_1 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_1_1()); 
            // InternalSM2.g:5468:2: ( rule__ArithmethicalExpression__OperatorAssignment_1_1 )
            // InternalSM2.g:5468:3: rule__ArithmethicalExpression__OperatorAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__OperatorAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__1__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__2"
    // InternalSM2.g:5476:1: rule__ArithmethicalExpression__Group_1__2 : rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3 ;
    public final void rule__ArithmethicalExpression__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5480:1: ( rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3 )
            // InternalSM2.g:5481:2: rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3
            {
            pushFollow(FOLLOW_5);
            rule__ArithmethicalExpression__Group_1__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__2"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__2__Impl"
    // InternalSM2.g:5488:1: rule__ArithmethicalExpression__Group_1__2__Impl : ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5492:1: ( ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) ) )
            // InternalSM2.g:5493:1: ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) )
            {
            // InternalSM2.g:5493:1: ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) )
            // InternalSM2.g:5494:2: ( rule__ArithmethicalExpression__Op2Assignment_1_2 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_1_2()); 
            // InternalSM2.g:5495:2: ( rule__ArithmethicalExpression__Op2Assignment_1_2 )
            // InternalSM2.g:5495:3: rule__ArithmethicalExpression__Op2Assignment_1_2
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op2Assignment_1_2();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__2__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__3"
    // InternalSM2.g:5503:1: rule__ArithmethicalExpression__Group_1__3 : rule__ArithmethicalExpression__Group_1__3__Impl ;
    public final void rule__ArithmethicalExpression__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5507:1: ( rule__ArithmethicalExpression__Group_1__3__Impl )
            // InternalSM2.g:5508:2: rule__ArithmethicalExpression__Group_1__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__3"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__3__Impl"
    // InternalSM2.g:5514:1: rule__ArithmethicalExpression__Group_1__3__Impl : ( ( rule__ArithmethicalExpression__Group_1_3__0 )? ) ;
    public final void rule__ArithmethicalExpression__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5518:1: ( ( ( rule__ArithmethicalExpression__Group_1_3__0 )? ) )
            // InternalSM2.g:5519:1: ( ( rule__ArithmethicalExpression__Group_1_3__0 )? )
            {
            // InternalSM2.g:5519:1: ( ( rule__ArithmethicalExpression__Group_1_3__0 )? )
            // InternalSM2.g:5520:2: ( rule__ArithmethicalExpression__Group_1_3__0 )?
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getGroup_1_3()); 
            // InternalSM2.g:5521:2: ( rule__ArithmethicalExpression__Group_1_3__0 )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==RULE_SEMICOLON) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalSM2.g:5521:3: rule__ArithmethicalExpression__Group_1_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_1_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getArithmethicalExpressionAccess().getGroup_1_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__3__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__0"
    // InternalSM2.g:5530:1: rule__ArithmethicalExpression__Group_1_3__0 : rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1 ;
    public final void rule__ArithmethicalExpression__Group_1_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5534:1: ( rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1 )
            // InternalSM2.g:5535:2: rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1
            {
            pushFollow(FOLLOW_20);
            rule__ArithmethicalExpression__Group_1_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__0__Impl"
    // InternalSM2.g:5542:1: rule__ArithmethicalExpression__Group_1_3__0__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__ArithmethicalExpression__Group_1_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5546:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:5547:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:5547:1: ( RULE_SEMICOLON )
            // InternalSM2.g:5548:2: RULE_SEMICOLON
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__1"
    // InternalSM2.g:5557:1: rule__ArithmethicalExpression__Group_1_3__1 : rule__ArithmethicalExpression__Group_1_3__1__Impl ;
    public final void rule__ArithmethicalExpression__Group_1_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5561:1: ( rule__ArithmethicalExpression__Group_1_3__1__Impl )
            // InternalSM2.g:5562:2: rule__ArithmethicalExpression__Group_1_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__1__Impl"
    // InternalSM2.g:5568:1: rule__ArithmethicalExpression__Group_1_3__1__Impl : ( RULE_EOLINE ) ;
    public final void rule__ArithmethicalExpression__Group_1_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5572:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:5573:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:5573:1: ( RULE_EOLINE )
            // InternalSM2.g:5574:2: RULE_EOLINE
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__1__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1__0"
    // InternalSM2.g:5584:1: rule__SyntaxExpression__Group_1__0 : rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1 ;
    public final void rule__SyntaxExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5588:1: ( rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1 )
            // InternalSM2.g:5589:2: rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1
            {
            pushFollow(FOLLOW_5);
            rule__SyntaxExpression__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__0"


    // $ANTLR start "rule__SyntaxExpression__Group_1__0__Impl"
    // InternalSM2.g:5596:1: rule__SyntaxExpression__Group_1__0__Impl : ( RULE_INT ) ;
    public final void rule__SyntaxExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5600:1: ( ( RULE_INT ) )
            // InternalSM2.g:5601:1: ( RULE_INT )
            {
            // InternalSM2.g:5601:1: ( RULE_INT )
            // InternalSM2.g:5602:2: RULE_INT
            {
             before(grammarAccess.getSyntaxExpressionAccess().getINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__0__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1__1"
    // InternalSM2.g:5611:1: rule__SyntaxExpression__Group_1__1 : rule__SyntaxExpression__Group_1__1__Impl ;
    public final void rule__SyntaxExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5615:1: ( rule__SyntaxExpression__Group_1__1__Impl )
            // InternalSM2.g:5616:2: rule__SyntaxExpression__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__1"


    // $ANTLR start "rule__SyntaxExpression__Group_1__1__Impl"
    // InternalSM2.g:5622:1: rule__SyntaxExpression__Group_1__1__Impl : ( ( rule__SyntaxExpression__Group_1_1__0 )? ) ;
    public final void rule__SyntaxExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5626:1: ( ( ( rule__SyntaxExpression__Group_1_1__0 )? ) )
            // InternalSM2.g:5627:1: ( ( rule__SyntaxExpression__Group_1_1__0 )? )
            {
            // InternalSM2.g:5627:1: ( ( rule__SyntaxExpression__Group_1_1__0 )? )
            // InternalSM2.g:5628:2: ( rule__SyntaxExpression__Group_1_1__0 )?
            {
             before(grammarAccess.getSyntaxExpressionAccess().getGroup_1_1()); 
            // InternalSM2.g:5629:2: ( rule__SyntaxExpression__Group_1_1__0 )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==RULE_SEMICOLON) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // InternalSM2.g:5629:3: rule__SyntaxExpression__Group_1_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__Group_1_1__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSyntaxExpressionAccess().getGroup_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__1__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__0"
    // InternalSM2.g:5638:1: rule__SyntaxExpression__Group_1_1__0 : rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1 ;
    public final void rule__SyntaxExpression__Group_1_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5642:1: ( rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1 )
            // InternalSM2.g:5643:2: rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1
            {
            pushFollow(FOLLOW_20);
            rule__SyntaxExpression__Group_1_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__0"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__0__Impl"
    // InternalSM2.g:5650:1: rule__SyntaxExpression__Group_1_1__0__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__SyntaxExpression__Group_1_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5654:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:5655:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:5655:1: ( RULE_SEMICOLON )
            // InternalSM2.g:5656:2: RULE_SEMICOLON
            {
             before(grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0()); 
            match(input,RULE_SEMICOLON,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__0__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__1"
    // InternalSM2.g:5665:1: rule__SyntaxExpression__Group_1_1__1 : rule__SyntaxExpression__Group_1_1__1__Impl ;
    public final void rule__SyntaxExpression__Group_1_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5669:1: ( rule__SyntaxExpression__Group_1_1__1__Impl )
            // InternalSM2.g:5670:2: rule__SyntaxExpression__Group_1_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__1"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__1__Impl"
    // InternalSM2.g:5676:1: rule__SyntaxExpression__Group_1_1__1__Impl : ( RULE_EOLINE ) ;
    public final void rule__SyntaxExpression__Group_1_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5680:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:5681:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:5681:1: ( RULE_EOLINE )
            // InternalSM2.g:5682:2: RULE_EOLINE
            {
             before(grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__1__Impl"


    // $ANTLR start "rule__ShortComment__Group__0"
    // InternalSM2.g:5692:1: rule__ShortComment__Group__0 : rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1 ;
    public final void rule__ShortComment__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5696:1: ( rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1 )
            // InternalSM2.g:5697:2: rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1
            {
            pushFollow(FOLLOW_30);
            rule__ShortComment__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__0"


    // $ANTLR start "rule__ShortComment__Group__0__Impl"
    // InternalSM2.g:5704:1: rule__ShortComment__Group__0__Impl : ( '//' ) ;
    public final void rule__ShortComment__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5708:1: ( ( '//' ) )
            // InternalSM2.g:5709:1: ( '//' )
            {
            // InternalSM2.g:5709:1: ( '//' )
            // InternalSM2.g:5710:2: '//'
            {
             before(grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0()); 
            match(input,71,FOLLOW_2); 
             after(grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__0__Impl"


    // $ANTLR start "rule__ShortComment__Group__1"
    // InternalSM2.g:5719:1: rule__ShortComment__Group__1 : rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2 ;
    public final void rule__ShortComment__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5723:1: ( rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2 )
            // InternalSM2.g:5724:2: rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2
            {
            pushFollow(FOLLOW_20);
            rule__ShortComment__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__1"


    // $ANTLR start "rule__ShortComment__Group__1__Impl"
    // InternalSM2.g:5731:1: rule__ShortComment__Group__1__Impl : ( ( rule__ShortComment__ExprAssignment_1 ) ) ;
    public final void rule__ShortComment__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5735:1: ( ( ( rule__ShortComment__ExprAssignment_1 ) ) )
            // InternalSM2.g:5736:1: ( ( rule__ShortComment__ExprAssignment_1 ) )
            {
            // InternalSM2.g:5736:1: ( ( rule__ShortComment__ExprAssignment_1 ) )
            // InternalSM2.g:5737:2: ( rule__ShortComment__ExprAssignment_1 )
            {
             before(grammarAccess.getShortCommentAccess().getExprAssignment_1()); 
            // InternalSM2.g:5738:2: ( rule__ShortComment__ExprAssignment_1 )
            // InternalSM2.g:5738:3: rule__ShortComment__ExprAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__ExprAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getShortCommentAccess().getExprAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__1__Impl"


    // $ANTLR start "rule__ShortComment__Group__2"
    // InternalSM2.g:5746:1: rule__ShortComment__Group__2 : rule__ShortComment__Group__2__Impl ;
    public final void rule__ShortComment__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5750:1: ( rule__ShortComment__Group__2__Impl )
            // InternalSM2.g:5751:2: rule__ShortComment__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__2"


    // $ANTLR start "rule__ShortComment__Group__2__Impl"
    // InternalSM2.g:5757:1: rule__ShortComment__Group__2__Impl : ( RULE_EOLINE ) ;
    public final void rule__ShortComment__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5761:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:5762:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:5762:1: ( RULE_EOLINE )
            // InternalSM2.g:5763:2: RULE_EOLINE
            {
             before(grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__2__Impl"


    // $ANTLR start "rule__LongComment__Group__0"
    // InternalSM2.g:5773:1: rule__LongComment__Group__0 : rule__LongComment__Group__0__Impl rule__LongComment__Group__1 ;
    public final void rule__LongComment__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5777:1: ( rule__LongComment__Group__0__Impl rule__LongComment__Group__1 )
            // InternalSM2.g:5778:2: rule__LongComment__Group__0__Impl rule__LongComment__Group__1
            {
            pushFollow(FOLLOW_47);
            rule__LongComment__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LongComment__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__0"


    // $ANTLR start "rule__LongComment__Group__0__Impl"
    // InternalSM2.g:5785:1: rule__LongComment__Group__0__Impl : ( '/*' ) ;
    public final void rule__LongComment__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5789:1: ( ( '/*' ) )
            // InternalSM2.g:5790:1: ( '/*' )
            {
            // InternalSM2.g:5790:1: ( '/*' )
            // InternalSM2.g:5791:2: '/*'
            {
             before(grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0()); 
            match(input,72,FOLLOW_2); 
             after(grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__0__Impl"


    // $ANTLR start "rule__LongComment__Group__1"
    // InternalSM2.g:5800:1: rule__LongComment__Group__1 : rule__LongComment__Group__1__Impl rule__LongComment__Group__2 ;
    public final void rule__LongComment__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5804:1: ( rule__LongComment__Group__1__Impl rule__LongComment__Group__2 )
            // InternalSM2.g:5805:2: rule__LongComment__Group__1__Impl rule__LongComment__Group__2
            {
            pushFollow(FOLLOW_48);
            rule__LongComment__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LongComment__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__1"


    // $ANTLR start "rule__LongComment__Group__1__Impl"
    // InternalSM2.g:5812:1: rule__LongComment__Group__1__Impl : ( ( rule__LongComment__ExpressionAssignment_1 ) ) ;
    public final void rule__LongComment__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5816:1: ( ( ( rule__LongComment__ExpressionAssignment_1 ) ) )
            // InternalSM2.g:5817:1: ( ( rule__LongComment__ExpressionAssignment_1 ) )
            {
            // InternalSM2.g:5817:1: ( ( rule__LongComment__ExpressionAssignment_1 ) )
            // InternalSM2.g:5818:2: ( rule__LongComment__ExpressionAssignment_1 )
            {
             before(grammarAccess.getLongCommentAccess().getExpressionAssignment_1()); 
            // InternalSM2.g:5819:2: ( rule__LongComment__ExpressionAssignment_1 )
            // InternalSM2.g:5819:3: rule__LongComment__ExpressionAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__ExpressionAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getLongCommentAccess().getExpressionAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__1__Impl"


    // $ANTLR start "rule__LongComment__Group__2"
    // InternalSM2.g:5827:1: rule__LongComment__Group__2 : rule__LongComment__Group__2__Impl ;
    public final void rule__LongComment__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5831:1: ( rule__LongComment__Group__2__Impl )
            // InternalSM2.g:5832:2: rule__LongComment__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__2"


    // $ANTLR start "rule__LongComment__Group__2__Impl"
    // InternalSM2.g:5838:1: rule__LongComment__Group__2__Impl : ( '*/' ) ;
    public final void rule__LongComment__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5842:1: ( ( '*/' ) )
            // InternalSM2.g:5843:1: ( '*/' )
            {
            // InternalSM2.g:5843:1: ( '*/' )
            // InternalSM2.g:5844:2: '*/'
            {
             before(grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2()); 
            match(input,73,FOLLOW_2); 
             after(grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__2__Impl"


    // $ANTLR start "rule__SmartContract__CompilerAssignment_0"
    // InternalSM2.g:5854:1: rule__SmartContract__CompilerAssignment_0 : ( ( 'pragma' ) ) ;
    public final void rule__SmartContract__CompilerAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5858:1: ( ( ( 'pragma' ) ) )
            // InternalSM2.g:5859:2: ( ( 'pragma' ) )
            {
            // InternalSM2.g:5859:2: ( ( 'pragma' ) )
            // InternalSM2.g:5860:3: ( 'pragma' )
            {
             before(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 
            // InternalSM2.g:5861:3: ( 'pragma' )
            // InternalSM2.g:5862:4: 'pragma'
            {
             before(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 
            match(input,74,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 

            }

             after(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__CompilerAssignment_0"


    // $ANTLR start "rule__SmartContract__VersionCompilerAssignment_2"
    // InternalSM2.g:5873:1: rule__SmartContract__VersionCompilerAssignment_2 : ( ruleVersion ) ;
    public final void rule__SmartContract__VersionCompilerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5877:1: ( ( ruleVersion ) )
            // InternalSM2.g:5878:2: ( ruleVersion )
            {
            // InternalSM2.g:5878:2: ( ruleVersion )
            // InternalSM2.g:5879:3: ruleVersion
            {
             before(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleVersion();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__VersionCompilerAssignment_2"


    // $ANTLR start "rule__SmartContract__ImportsAssignment_5"
    // InternalSM2.g:5888:1: rule__SmartContract__ImportsAssignment_5 : ( ruleImport ) ;
    public final void rule__SmartContract__ImportsAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5892:1: ( ( ruleImport ) )
            // InternalSM2.g:5893:2: ( ruleImport )
            {
            // InternalSM2.g:5893:2: ( ruleImport )
            // InternalSM2.g:5894:3: ruleImport
            {
             before(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleImport();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ImportsAssignment_5"


    // $ANTLR start "rule__SmartContract__ContractAssignment_6"
    // InternalSM2.g:5903:1: rule__SmartContract__ContractAssignment_6 : ( ( 'contract' ) ) ;
    public final void rule__SmartContract__ContractAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5907:1: ( ( ( 'contract' ) ) )
            // InternalSM2.g:5908:2: ( ( 'contract' ) )
            {
            // InternalSM2.g:5908:2: ( ( 'contract' ) )
            // InternalSM2.g:5909:3: ( 'contract' )
            {
             before(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 
            // InternalSM2.g:5910:3: ( 'contract' )
            // InternalSM2.g:5911:4: 'contract'
            {
             before(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 
            match(input,75,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 

            }

             after(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ContractAssignment_6"


    // $ANTLR start "rule__SmartContract__NameContractAssignment_7"
    // InternalSM2.g:5922:1: rule__SmartContract__NameContractAssignment_7 : ( RULE_ID ) ;
    public final void rule__SmartContract__NameContractAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5926:1: ( ( RULE_ID ) )
            // InternalSM2.g:5927:2: ( RULE_ID )
            {
            // InternalSM2.g:5927:2: ( RULE_ID )
            // InternalSM2.g:5928:3: RULE_ID
            {
             before(grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_7_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__NameContractAssignment_7"


    // $ANTLR start "rule__SmartContract__NameContractFatherAssignment_8_1"
    // InternalSM2.g:5937:1: rule__SmartContract__NameContractFatherAssignment_8_1 : ( RULE_ID ) ;
    public final void rule__SmartContract__NameContractFatherAssignment_8_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5941:1: ( ( RULE_ID ) )
            // InternalSM2.g:5942:2: ( RULE_ID )
            {
            // InternalSM2.g:5942:2: ( RULE_ID )
            // InternalSM2.g:5943:3: RULE_ID
            {
             before(grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_8_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_8_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__NameContractFatherAssignment_8_1"


    // $ANTLR start "rule__SmartContract__AttributesAssignment_11"
    // InternalSM2.g:5952:1: rule__SmartContract__AttributesAssignment_11 : ( ruleAttributes ) ;
    public final void rule__SmartContract__AttributesAssignment_11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5956:1: ( ( ruleAttributes ) )
            // InternalSM2.g:5957:2: ( ruleAttributes )
            {
            // InternalSM2.g:5957:2: ( ruleAttributes )
            // InternalSM2.g:5958:3: ruleAttributes
            {
             before(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_11_0()); 
            pushFollow(FOLLOW_2);
            ruleAttributes();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__AttributesAssignment_11"


    // $ANTLR start "rule__SmartContract__EventsAssignment_12"
    // InternalSM2.g:5967:1: rule__SmartContract__EventsAssignment_12 : ( ruleEvent ) ;
    public final void rule__SmartContract__EventsAssignment_12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5971:1: ( ( ruleEvent ) )
            // InternalSM2.g:5972:2: ( ruleEvent )
            {
            // InternalSM2.g:5972:2: ( ruleEvent )
            // InternalSM2.g:5973:3: ruleEvent
            {
             before(grammarAccess.getSmartContractAccess().getEventsEventParserRuleCall_12_0()); 
            pushFollow(FOLLOW_2);
            ruleEvent();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getEventsEventParserRuleCall_12_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__EventsAssignment_12"


    // $ANTLR start "rule__SmartContract__ModifierAssignment_13"
    // InternalSM2.g:5982:1: rule__SmartContract__ModifierAssignment_13 : ( ruleModifier ) ;
    public final void rule__SmartContract__ModifierAssignment_13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5986:1: ( ( ruleModifier ) )
            // InternalSM2.g:5987:2: ( ruleModifier )
            {
            // InternalSM2.g:5987:2: ( ruleModifier )
            // InternalSM2.g:5988:3: ruleModifier
            {
             before(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_13_0()); 
            pushFollow(FOLLOW_2);
            ruleModifier();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_13_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ModifierAssignment_13"


    // $ANTLR start "rule__SmartContract__ClausesAssignment_14"
    // InternalSM2.g:5997:1: rule__SmartContract__ClausesAssignment_14 : ( ruleClause ) ;
    public final void rule__SmartContract__ClausesAssignment_14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6001:1: ( ( ruleClause ) )
            // InternalSM2.g:6002:2: ( ruleClause )
            {
            // InternalSM2.g:6002:2: ( ruleClause )
            // InternalSM2.g:6003:3: ruleClause
            {
             before(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_14_0()); 
            pushFollow(FOLLOW_2);
            ruleClause();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_14_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ClausesAssignment_14"


    // $ANTLR start "rule__SmartContract__CommentsAssignment_15"
    // InternalSM2.g:6012:1: rule__SmartContract__CommentsAssignment_15 : ( ruleComment ) ;
    public final void rule__SmartContract__CommentsAssignment_15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6016:1: ( ( ruleComment ) )
            // InternalSM2.g:6017:2: ( ruleComment )
            {
            // InternalSM2.g:6017:2: ( ruleComment )
            // InternalSM2.g:6018:3: ruleComment
            {
             before(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_15_0()); 
            pushFollow(FOLLOW_2);
            ruleComment();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_15_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__CommentsAssignment_15"


    // $ANTLR start "rule__Version__SymbolAssignment_0_0"
    // InternalSM2.g:6027:1: rule__Version__SymbolAssignment_0_0 : ( ( '^' ) ) ;
    public final void rule__Version__SymbolAssignment_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6031:1: ( ( ( '^' ) ) )
            // InternalSM2.g:6032:2: ( ( '^' ) )
            {
            // InternalSM2.g:6032:2: ( ( '^' ) )
            // InternalSM2.g:6033:3: ( '^' )
            {
             before(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 
            // InternalSM2.g:6034:3: ( '^' )
            // InternalSM2.g:6035:4: '^'
            {
             before(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 
            match(input,76,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 

            }

             after(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAssignment_0_0"


    // $ANTLR start "rule__Version__NumberVersionAssignment_0_1"
    // InternalSM2.g:6046:1: rule__Version__NumberVersionAssignment_0_1 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6050:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6051:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6051:2: ( RULE_NUMBER )
            // InternalSM2.g:6052:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_0_1_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionAssignment_0_1"


    // $ANTLR start "rule__Version__NumberVersion2Assignment_0_3"
    // InternalSM2.g:6061:1: rule__Version__NumberVersion2Assignment_0_3 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion2Assignment_0_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6065:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6066:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6066:2: ( RULE_NUMBER )
            // InternalSM2.g:6067:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_0_3_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_0_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion2Assignment_0_3"


    // $ANTLR start "rule__Version__NumberVersion3Assignment_0_5"
    // InternalSM2.g:6076:1: rule__Version__NumberVersion3Assignment_0_5 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion3Assignment_0_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6080:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6081:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6081:2: ( RULE_NUMBER )
            // InternalSM2.g:6082:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_0_5_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_0_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion3Assignment_0_5"


    // $ANTLR start "rule__Version__SymbolAssignment_1_0"
    // InternalSM2.g:6091:1: rule__Version__SymbolAssignment_1_0 : ( ( rule__Version__SymbolAlternatives_1_0_0 ) ) ;
    public final void rule__Version__SymbolAssignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6095:1: ( ( ( rule__Version__SymbolAlternatives_1_0_0 ) ) )
            // InternalSM2.g:6096:2: ( ( rule__Version__SymbolAlternatives_1_0_0 ) )
            {
            // InternalSM2.g:6096:2: ( ( rule__Version__SymbolAlternatives_1_0_0 ) )
            // InternalSM2.g:6097:3: ( rule__Version__SymbolAlternatives_1_0_0 )
            {
             before(grammarAccess.getVersionAccess().getSymbolAlternatives_1_0_0()); 
            // InternalSM2.g:6098:3: ( rule__Version__SymbolAlternatives_1_0_0 )
            // InternalSM2.g:6098:4: rule__Version__SymbolAlternatives_1_0_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAlternatives_1_0_0();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getSymbolAlternatives_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAssignment_1_0"


    // $ANTLR start "rule__Version__NumberVersionAssignment_1_1"
    // InternalSM2.g:6106:1: rule__Version__NumberVersionAssignment_1_1 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6110:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6111:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6111:2: ( RULE_NUMBER )
            // InternalSM2.g:6112:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_1_1_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionAssignment_1_1"


    // $ANTLR start "rule__Version__NumberVersion2Assignment_1_3"
    // InternalSM2.g:6121:1: rule__Version__NumberVersion2Assignment_1_3 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion2Assignment_1_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6125:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6126:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6126:2: ( RULE_NUMBER )
            // InternalSM2.g:6127:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_1_3_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_1_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion2Assignment_1_3"


    // $ANTLR start "rule__Version__NumberVersion3Assignment_1_5"
    // InternalSM2.g:6136:1: rule__Version__NumberVersion3Assignment_1_5 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion3Assignment_1_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6140:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6141:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6141:2: ( RULE_NUMBER )
            // InternalSM2.g:6142:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_1_5_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_1_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion3Assignment_1_5"


    // $ANTLR start "rule__Version__Symbol2Assignment_1_6_0"
    // InternalSM2.g:6151:1: rule__Version__Symbol2Assignment_1_6_0 : ( ( rule__Version__Symbol2Alternatives_1_6_0_0 ) ) ;
    public final void rule__Version__Symbol2Assignment_1_6_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6155:1: ( ( ( rule__Version__Symbol2Alternatives_1_6_0_0 ) ) )
            // InternalSM2.g:6156:2: ( ( rule__Version__Symbol2Alternatives_1_6_0_0 ) )
            {
            // InternalSM2.g:6156:2: ( ( rule__Version__Symbol2Alternatives_1_6_0_0 ) )
            // InternalSM2.g:6157:3: ( rule__Version__Symbol2Alternatives_1_6_0_0 )
            {
             before(grammarAccess.getVersionAccess().getSymbol2Alternatives_1_6_0_0()); 
            // InternalSM2.g:6158:3: ( rule__Version__Symbol2Alternatives_1_6_0_0 )
            // InternalSM2.g:6158:4: rule__Version__Symbol2Alternatives_1_6_0_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__Symbol2Alternatives_1_6_0_0();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getSymbol2Alternatives_1_6_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Symbol2Assignment_1_6_0"


    // $ANTLR start "rule__Version__NumberVersionOptionalAssignment_1_6_1"
    // InternalSM2.g:6166:1: rule__Version__NumberVersionOptionalAssignment_1_6_1 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionOptionalAssignment_1_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6170:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6171:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6171:2: ( RULE_NUMBER )
            // InternalSM2.g:6172:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersionOptionalNUMBERTerminalRuleCall_1_6_1_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersionOptionalNUMBERTerminalRuleCall_1_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionOptionalAssignment_1_6_1"


    // $ANTLR start "rule__Version__NumberVersionOptional2Assignment_1_6_3"
    // InternalSM2.g:6181:1: rule__Version__NumberVersionOptional2Assignment_1_6_3 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionOptional2Assignment_1_6_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6185:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6186:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6186:2: ( RULE_NUMBER )
            // InternalSM2.g:6187:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersionOptional2NUMBERTerminalRuleCall_1_6_3_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersionOptional2NUMBERTerminalRuleCall_1_6_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionOptional2Assignment_1_6_3"


    // $ANTLR start "rule__Version__NumberVersionOptional3Assignment_1_6_5"
    // InternalSM2.g:6196:1: rule__Version__NumberVersionOptional3Assignment_1_6_5 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionOptional3Assignment_1_6_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6200:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6201:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6201:2: ( RULE_NUMBER )
            // InternalSM2.g:6202:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersionOptional3NUMBERTerminalRuleCall_1_6_5_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersionOptional3NUMBERTerminalRuleCall_1_6_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionOptional3Assignment_1_6_5"


    // $ANTLR start "rule__Import__NameLibraryAssignment_1"
    // InternalSM2.g:6211:1: rule__Import__NameLibraryAssignment_1 : ( RULE_ID ) ;
    public final void rule__Import__NameLibraryAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6215:1: ( ( RULE_ID ) )
            // InternalSM2.g:6216:2: ( RULE_ID )
            {
            // InternalSM2.g:6216:2: ( RULE_ID )
            // InternalSM2.g:6217:3: RULE_ID
            {
             before(grammarAccess.getImportAccess().getNameLibraryIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getNameLibraryIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__NameLibraryAssignment_1"


    // $ANTLR start "rule__Import__AliasAssignment_2_1"
    // InternalSM2.g:6226:1: rule__Import__AliasAssignment_2_1 : ( RULE_ID ) ;
    public final void rule__Import__AliasAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6230:1: ( ( RULE_ID ) )
            // InternalSM2.g:6231:2: ( RULE_ID )
            {
            // InternalSM2.g:6231:2: ( RULE_ID )
            // InternalSM2.g:6232:3: RULE_ID
            {
             before(grammarAccess.getImportAccess().getAliasIDTerminalRuleCall_2_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getAliasIDTerminalRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__AliasAssignment_2_1"


    // $ANTLR start "rule__Event__NameEventAssignment_1"
    // InternalSM2.g:6241:1: rule__Event__NameEventAssignment_1 : ( RULE_ID ) ;
    public final void rule__Event__NameEventAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6245:1: ( ( RULE_ID ) )
            // InternalSM2.g:6246:2: ( RULE_ID )
            {
            // InternalSM2.g:6246:2: ( RULE_ID )
            // InternalSM2.g:6247:3: RULE_ID
            {
             before(grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__NameEventAssignment_1"


    // $ANTLR start "rule__Event__InputParamsAssignment_3"
    // InternalSM2.g:6256:1: rule__Event__InputParamsAssignment_3 : ( ruleInputParam ) ;
    public final void rule__Event__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6260:1: ( ( ruleInputParam ) )
            // InternalSM2.g:6261:2: ( ruleInputParam )
            {
            // InternalSM2.g:6261:2: ( ruleInputParam )
            // InternalSM2.g:6262:3: ruleInputParam
            {
             before(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleInputParam();

            state._fsp--;

             after(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__InputParamsAssignment_3"


    // $ANTLR start "rule__Modifier__NameModifierAssignment_1"
    // InternalSM2.g:6271:1: rule__Modifier__NameModifierAssignment_1 : ( RULE_ID ) ;
    public final void rule__Modifier__NameModifierAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6275:1: ( ( RULE_ID ) )
            // InternalSM2.g:6276:2: ( RULE_ID )
            {
            // InternalSM2.g:6276:2: ( RULE_ID )
            // InternalSM2.g:6277:3: RULE_ID
            {
             before(grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__NameModifierAssignment_1"


    // $ANTLR start "rule__Modifier__InputParamsAssignment_3"
    // InternalSM2.g:6286:1: rule__Modifier__InputParamsAssignment_3 : ( ruleInputParam ) ;
    public final void rule__Modifier__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6290:1: ( ( ruleInputParam ) )
            // InternalSM2.g:6291:2: ( ruleInputParam )
            {
            // InternalSM2.g:6291:2: ( ruleInputParam )
            // InternalSM2.g:6292:3: ruleInputParam
            {
             before(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleInputParam();

            state._fsp--;

             after(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__InputParamsAssignment_3"


    // $ANTLR start "rule__Modifier__ExprAssignment_7"
    // InternalSM2.g:6301:1: rule__Modifier__ExprAssignment_7 : ( RULE_STRING ) ;
    public final void rule__Modifier__ExprAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6305:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6306:2: ( RULE_STRING )
            {
            // InternalSM2.g:6306:2: ( RULE_STRING )
            // InternalSM2.g:6307:3: RULE_STRING
            {
             before(grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__ExprAssignment_7"


    // $ANTLR start "rule__Mapping__TypeAssignment_2"
    // InternalSM2.g:6316:1: rule__Mapping__TypeAssignment_2 : ( ruleSingularType ) ;
    public final void rule__Mapping__TypeAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6320:1: ( ( ruleSingularType ) )
            // InternalSM2.g:6321:2: ( ruleSingularType )
            {
            // InternalSM2.g:6321:2: ( ruleSingularType )
            // InternalSM2.g:6322:3: ruleSingularType
            {
             before(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;

             after(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__TypeAssignment_2"


    // $ANTLR start "rule__Mapping__ExprAssignment_4"
    // InternalSM2.g:6331:1: rule__Mapping__ExprAssignment_4 : ( RULE_STRING ) ;
    public final void rule__Mapping__ExprAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6335:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6336:2: ( RULE_STRING )
            {
            // InternalSM2.g:6336:2: ( RULE_STRING )
            // InternalSM2.g:6337:3: RULE_STRING
            {
             before(grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__ExprAssignment_4"


    // $ANTLR start "rule__Mapping__VisibilityAssignment_6"
    // InternalSM2.g:6346:1: rule__Mapping__VisibilityAssignment_6 : ( ruleVisibility ) ;
    public final void rule__Mapping__VisibilityAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6350:1: ( ( ruleVisibility ) )
            // InternalSM2.g:6351:2: ( ruleVisibility )
            {
            // InternalSM2.g:6351:2: ( ruleVisibility )
            // InternalSM2.g:6352:3: ruleVisibility
            {
             before(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__VisibilityAssignment_6"


    // $ANTLR start "rule__Mapping__NameMappingAssignment_7"
    // InternalSM2.g:6361:1: rule__Mapping__NameMappingAssignment_7 : ( RULE_ID ) ;
    public final void rule__Mapping__NameMappingAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6365:1: ( ( RULE_ID ) )
            // InternalSM2.g:6366:2: ( RULE_ID )
            {
            // InternalSM2.g:6366:2: ( RULE_ID )
            // InternalSM2.g:6367:3: RULE_ID
            {
             before(grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__NameMappingAssignment_7"


    // $ANTLR start "rule__PersonalizedStruct__NameStructAssignment_1"
    // InternalSM2.g:6376:1: rule__PersonalizedStruct__NameStructAssignment_1 : ( RULE_ID ) ;
    public final void rule__PersonalizedStruct__NameStructAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6380:1: ( ( RULE_ID ) )
            // InternalSM2.g:6381:2: ( RULE_ID )
            {
            // InternalSM2.g:6381:2: ( RULE_ID )
            // InternalSM2.g:6382:3: RULE_ID
            {
             before(grammarAccess.getPersonalizedStructAccess().getNameStructIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getPersonalizedStructAccess().getNameStructIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__NameStructAssignment_1"


    // $ANTLR start "rule__PersonalizedStruct__PropertiesAssignment_4"
    // InternalSM2.g:6391:1: rule__PersonalizedStruct__PropertiesAssignment_4 : ( ruleProperty ) ;
    public final void rule__PersonalizedStruct__PropertiesAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6395:1: ( ( ruleProperty ) )
            // InternalSM2.g:6396:2: ( ruleProperty )
            {
            // InternalSM2.g:6396:2: ( ruleProperty )
            // InternalSM2.g:6397:3: ruleProperty
            {
             before(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleProperty();

            state._fsp--;

             after(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__PropertiesAssignment_4"


    // $ANTLR start "rule__User__NameStructAssignment_1"
    // InternalSM2.g:6406:1: rule__User__NameStructAssignment_1 : ( RULE_ID ) ;
    public final void rule__User__NameStructAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6410:1: ( ( RULE_ID ) )
            // InternalSM2.g:6411:2: ( RULE_ID )
            {
            // InternalSM2.g:6411:2: ( RULE_ID )
            // InternalSM2.g:6412:3: RULE_ID
            {
             before(grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__NameStructAssignment_1"


    // $ANTLR start "rule__User__AddressAssignment_4"
    // InternalSM2.g:6421:1: rule__User__AddressAssignment_4 : ( RULE_STRING ) ;
    public final void rule__User__AddressAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6425:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6426:2: ( RULE_STRING )
            {
            // InternalSM2.g:6426:2: ( RULE_STRING )
            // InternalSM2.g:6427:3: RULE_STRING
            {
             before(grammarAccess.getUserAccess().getAddressSTRINGTerminalRuleCall_4_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getUserAccess().getAddressSTRINGTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__AddressAssignment_4"


    // $ANTLR start "rule__User__NameUserAssignment_6"
    // InternalSM2.g:6436:1: rule__User__NameUserAssignment_6 : ( RULE_STRING ) ;
    public final void rule__User__NameUserAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6440:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6441:2: ( RULE_STRING )
            {
            // InternalSM2.g:6441:2: ( RULE_STRING )
            // InternalSM2.g:6442:3: RULE_STRING
            {
             before(grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_6_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__NameUserAssignment_6"


    // $ANTLR start "rule__User__LastNameUserAssignment_8"
    // InternalSM2.g:6451:1: rule__User__LastNameUserAssignment_8 : ( RULE_STRING ) ;
    public final void rule__User__LastNameUserAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6455:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6456:2: ( RULE_STRING )
            {
            // InternalSM2.g:6456:2: ( RULE_STRING )
            // InternalSM2.g:6457:3: RULE_STRING
            {
             before(grammarAccess.getUserAccess().getLastNameUserSTRINGTerminalRuleCall_8_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getUserAccess().getLastNameUserSTRINGTerminalRuleCall_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__LastNameUserAssignment_8"


    // $ANTLR start "rule__User__EmailAssignment_10"
    // InternalSM2.g:6466:1: rule__User__EmailAssignment_10 : ( RULE_EMAIL ) ;
    public final void rule__User__EmailAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6470:1: ( ( RULE_EMAIL ) )
            // InternalSM2.g:6471:2: ( RULE_EMAIL )
            {
            // InternalSM2.g:6471:2: ( RULE_EMAIL )
            // InternalSM2.g:6472:3: RULE_EMAIL
            {
             before(grammarAccess.getUserAccess().getEmailEMAILTerminalRuleCall_10_0()); 
            match(input,RULE_EMAIL,FOLLOW_2); 
             after(grammarAccess.getUserAccess().getEmailEMAILTerminalRuleCall_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__EmailAssignment_10"


    // $ANTLR start "rule__User__AmountAccountAssignment_12"
    // InternalSM2.g:6481:1: rule__User__AmountAccountAssignment_12 : ( RULE_STRING ) ;
    public final void rule__User__AmountAccountAssignment_12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6485:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6486:2: ( RULE_STRING )
            {
            // InternalSM2.g:6486:2: ( RULE_STRING )
            // InternalSM2.g:6487:3: RULE_STRING
            {
             before(grammarAccess.getUserAccess().getAmountAccountSTRINGTerminalRuleCall_12_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getUserAccess().getAmountAccountSTRINGTerminalRuleCall_12_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__AmountAccountAssignment_12"


    // $ANTLR start "rule__Enum__NameEnumAssignment_1"
    // InternalSM2.g:6496:1: rule__Enum__NameEnumAssignment_1 : ( RULE_ID ) ;
    public final void rule__Enum__NameEnumAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6500:1: ( ( RULE_ID ) )
            // InternalSM2.g:6501:2: ( RULE_ID )
            {
            // InternalSM2.g:6501:2: ( RULE_ID )
            // InternalSM2.g:6502:3: RULE_ID
            {
             before(grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__NameEnumAssignment_1"


    // $ANTLR start "rule__Enum__ExprAssignment_3"
    // InternalSM2.g:6511:1: rule__Enum__ExprAssignment_3 : ( RULE_STRING ) ;
    public final void rule__Enum__ExprAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6515:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6516:2: ( RULE_STRING )
            {
            // InternalSM2.g:6516:2: ( RULE_STRING )
            // InternalSM2.g:6517:3: RULE_STRING
            {
             before(grammarAccess.getEnumAccess().getExprSTRINGTerminalRuleCall_3_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getExprSTRINGTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__ExprAssignment_3"


    // $ANTLR start "rule__Property__TypeAssignment_0"
    // InternalSM2.g:6526:1: rule__Property__TypeAssignment_0 : ( ruleSingularType ) ;
    public final void rule__Property__TypeAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6530:1: ( ( ruleSingularType ) )
            // InternalSM2.g:6531:2: ( ruleSingularType )
            {
            // InternalSM2.g:6531:2: ( ruleSingularType )
            // InternalSM2.g:6532:3: ruleSingularType
            {
             before(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;

             after(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__TypeAssignment_0"


    // $ANTLR start "rule__Property__VisibilityAssignment_1"
    // InternalSM2.g:6541:1: rule__Property__VisibilityAssignment_1 : ( ruleVisibility ) ;
    public final void rule__Property__VisibilityAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6545:1: ( ( ruleVisibility ) )
            // InternalSM2.g:6546:2: ( ruleVisibility )
            {
            // InternalSM2.g:6546:2: ( ruleVisibility )
            // InternalSM2.g:6547:3: ruleVisibility
            {
             before(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__VisibilityAssignment_1"


    // $ANTLR start "rule__Property__NamePropertyAssignment_2"
    // InternalSM2.g:6556:1: rule__Property__NamePropertyAssignment_2 : ( RULE_ID ) ;
    public final void rule__Property__NamePropertyAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6560:1: ( ( RULE_ID ) )
            // InternalSM2.g:6561:2: ( RULE_ID )
            {
            // InternalSM2.g:6561:2: ( RULE_ID )
            // InternalSM2.g:6562:3: RULE_ID
            {
             before(grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__NamePropertyAssignment_2"


    // $ANTLR start "rule__Property__InicializationAssignment_4_0"
    // InternalSM2.g:6571:1: rule__Property__InicializationAssignment_4_0 : ( RULE_STRING ) ;
    public final void rule__Property__InicializationAssignment_4_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6575:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6576:2: ( RULE_STRING )
            {
            // InternalSM2.g:6576:2: ( RULE_STRING )
            // InternalSM2.g:6577:3: RULE_STRING
            {
             before(grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__InicializationAssignment_4_0"


    // $ANTLR start "rule__InputParam__TypeAssignment_0_0"
    // InternalSM2.g:6586:1: rule__InputParam__TypeAssignment_0_0 : ( ruleSingularType ) ;
    public final void rule__InputParam__TypeAssignment_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6590:1: ( ( ruleSingularType ) )
            // InternalSM2.g:6591:2: ( ruleSingularType )
            {
            // InternalSM2.g:6591:2: ( ruleSingularType )
            // InternalSM2.g:6592:3: ruleSingularType
            {
             before(grammarAccess.getInputParamAccess().getTypeSingularTypeEnumRuleCall_0_0_0()); 
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;

             after(grammarAccess.getInputParamAccess().getTypeSingularTypeEnumRuleCall_0_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__TypeAssignment_0_0"


    // $ANTLR start "rule__InputParam__NameParamAssignment_0_1"
    // InternalSM2.g:6601:1: rule__InputParam__NameParamAssignment_0_1 : ( RULE_ID ) ;
    public final void rule__InputParam__NameParamAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6605:1: ( ( RULE_ID ) )
            // InternalSM2.g:6606:2: ( RULE_ID )
            {
            // InternalSM2.g:6606:2: ( RULE_ID )
            // InternalSM2.g:6607:3: RULE_ID
            {
             before(grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__NameParamAssignment_0_1"


    // $ANTLR start "rule__InputParam__CommaAssignment_1"
    // InternalSM2.g:6616:1: rule__InputParam__CommaAssignment_1 : ( RULE_COMMA ) ;
    public final void rule__InputParam__CommaAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6620:1: ( ( RULE_COMMA ) )
            // InternalSM2.g:6621:2: ( RULE_COMMA )
            {
            // InternalSM2.g:6621:2: ( RULE_COMMA )
            // InternalSM2.g:6622:3: RULE_COMMA
            {
             before(grammarAccess.getInputParamAccess().getCommaCOMMATerminalRuleCall_1_0()); 
            match(input,RULE_COMMA,FOLLOW_2); 
             after(grammarAccess.getInputParamAccess().getCommaCOMMATerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__CommaAssignment_1"


    // $ANTLR start "rule__Restriction__Expr1Assignment_2"
    // InternalSM2.g:6631:1: rule__Restriction__Expr1Assignment_2 : ( ruleSyntaxExpression ) ;
    public final void rule__Restriction__Expr1Assignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6635:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:6636:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:6636:2: ( ruleSyntaxExpression )
            // InternalSM2.g:6637:3: ruleSyntaxExpression
            {
             before(grammarAccess.getRestrictionAccess().getExpr1SyntaxExpressionParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getRestrictionAccess().getExpr1SyntaxExpressionParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Expr1Assignment_2"


    // $ANTLR start "rule__Restriction__OperatorAssignment_3"
    // InternalSM2.g:6646:1: rule__Restriction__OperatorAssignment_3 : ( ruleComparationOperator ) ;
    public final void rule__Restriction__OperatorAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6650:1: ( ( ruleComparationOperator ) )
            // InternalSM2.g:6651:2: ( ruleComparationOperator )
            {
            // InternalSM2.g:6651:2: ( ruleComparationOperator )
            // InternalSM2.g:6652:3: ruleComparationOperator
            {
             before(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleComparationOperator();

            state._fsp--;

             after(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__OperatorAssignment_3"


    // $ANTLR start "rule__Restriction__Expr2Assignment_4"
    // InternalSM2.g:6661:1: rule__Restriction__Expr2Assignment_4 : ( ruleSyntaxExpression ) ;
    public final void rule__Restriction__Expr2Assignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6665:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:6666:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:6666:2: ( ruleSyntaxExpression )
            // InternalSM2.g:6667:3: ruleSyntaxExpression
            {
             before(grammarAccess.getRestrictionAccess().getExpr2SyntaxExpressionParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getRestrictionAccess().getExpr2SyntaxExpressionParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Expr2Assignment_4"


    // $ANTLR start "rule__RestrictionGas__ExprAssignment_2"
    // InternalSM2.g:6676:1: rule__RestrictionGas__ExprAssignment_2 : ( ruleSyntaxExpression ) ;
    public final void rule__RestrictionGas__ExprAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6680:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:6681:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:6681:2: ( ruleSyntaxExpression )
            // InternalSM2.g:6682:3: ruleSyntaxExpression
            {
             before(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__ExprAssignment_2"


    // $ANTLR start "rule__RestrictionGas__OperatorAssignment_3"
    // InternalSM2.g:6691:1: rule__RestrictionGas__OperatorAssignment_3 : ( ruleComparationOperator ) ;
    public final void rule__RestrictionGas__OperatorAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6695:1: ( ( ruleComparationOperator ) )
            // InternalSM2.g:6696:2: ( ruleComparationOperator )
            {
            // InternalSM2.g:6696:2: ( ruleComparationOperator )
            // InternalSM2.g:6697:3: ruleComparationOperator
            {
             before(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleComparationOperator();

            state._fsp--;

             after(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__OperatorAssignment_3"


    // $ANTLR start "rule__RestrictionGas__AmountAssignment_4"
    // InternalSM2.g:6706:1: rule__RestrictionGas__AmountAssignment_4 : ( RULE_INT ) ;
    public final void rule__RestrictionGas__AmountAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6710:1: ( ( RULE_INT ) )
            // InternalSM2.g:6711:2: ( RULE_INT )
            {
            // InternalSM2.g:6711:2: ( RULE_INT )
            // InternalSM2.g:6712:3: RULE_INT
            {
             before(grammarAccess.getRestrictionGasAccess().getAmountINTTerminalRuleCall_4_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getAmountINTTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__AmountAssignment_4"


    // $ANTLR start "rule__RestrictionGas__TypeCoinAssignment_5"
    // InternalSM2.g:6721:1: rule__RestrictionGas__TypeCoinAssignment_5 : ( ruleCoin ) ;
    public final void rule__RestrictionGas__TypeCoinAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6725:1: ( ( ruleCoin ) )
            // InternalSM2.g:6726:2: ( ruleCoin )
            {
            // InternalSM2.g:6726:2: ( ruleCoin )
            // InternalSM2.g:6727:3: ruleCoin
            {
             before(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleCoin();

            state._fsp--;

             after(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__TypeCoinAssignment_5"


    // $ANTLR start "rule__Clause__NameFunctionAssignment_1"
    // InternalSM2.g:6736:1: rule__Clause__NameFunctionAssignment_1 : ( RULE_ID ) ;
    public final void rule__Clause__NameFunctionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6740:1: ( ( RULE_ID ) )
            // InternalSM2.g:6741:2: ( RULE_ID )
            {
            // InternalSM2.g:6741:2: ( RULE_ID )
            // InternalSM2.g:6742:3: RULE_ID
            {
             before(grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__NameFunctionAssignment_1"


    // $ANTLR start "rule__Clause__InputParamsAssignment_3"
    // InternalSM2.g:6751:1: rule__Clause__InputParamsAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__Clause__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6755:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:6756:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:6756:2: ( ( RULE_ID ) )
            // InternalSM2.g:6757:3: ( RULE_ID )
            {
             before(grammarAccess.getClauseAccess().getInputParamsInputParamCrossReference_3_0()); 
            // InternalSM2.g:6758:3: ( RULE_ID )
            // InternalSM2.g:6759:4: RULE_ID
            {
             before(grammarAccess.getClauseAccess().getInputParamsInputParamIDTerminalRuleCall_3_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getInputParamsInputParamIDTerminalRuleCall_3_0_1()); 

            }

             after(grammarAccess.getClauseAccess().getInputParamsInputParamCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__InputParamsAssignment_3"


    // $ANTLR start "rule__Clause__VisibilityAccessAssignment_4"
    // InternalSM2.g:6770:1: rule__Clause__VisibilityAccessAssignment_4 : ( ruleVisibility ) ;
    public final void rule__Clause__VisibilityAccessAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6774:1: ( ( ruleVisibility ) )
            // InternalSM2.g:6775:2: ( ruleVisibility )
            {
            // InternalSM2.g:6775:2: ( ruleVisibility )
            // InternalSM2.g:6776:3: ruleVisibility
            {
             before(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__VisibilityAccessAssignment_4"


    // $ANTLR start "rule__Clause__ModifierAssignment_5"
    // InternalSM2.g:6785:1: rule__Clause__ModifierAssignment_5 : ( ( RULE_ID ) ) ;
    public final void rule__Clause__ModifierAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6789:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:6790:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:6790:2: ( ( RULE_ID ) )
            // InternalSM2.g:6791:3: ( RULE_ID )
            {
             before(grammarAccess.getClauseAccess().getModifierModifierCrossReference_5_0()); 
            // InternalSM2.g:6792:3: ( RULE_ID )
            // InternalSM2.g:6793:4: RULE_ID
            {
             before(grammarAccess.getClauseAccess().getModifierModifierIDTerminalRuleCall_5_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getModifierModifierIDTerminalRuleCall_5_0_1()); 

            }

             after(grammarAccess.getClauseAccess().getModifierModifierCrossReference_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__ModifierAssignment_5"


    // $ANTLR start "rule__Clause__RestrictionAssignment_9"
    // InternalSM2.g:6804:1: rule__Clause__RestrictionAssignment_9 : ( ruleRestriction ) ;
    public final void rule__Clause__RestrictionAssignment_9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6808:1: ( ( ruleRestriction ) )
            // InternalSM2.g:6809:2: ( ruleRestriction )
            {
            // InternalSM2.g:6809:2: ( ruleRestriction )
            // InternalSM2.g:6810:3: ruleRestriction
            {
             before(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_9_0()); 
            pushFollow(FOLLOW_2);
            ruleRestriction();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__RestrictionAssignment_9"


    // $ANTLR start "rule__Clause__RestrictionGasAssignment_10"
    // InternalSM2.g:6819:1: rule__Clause__RestrictionGasAssignment_10 : ( ruleRestrictionGas ) ;
    public final void rule__Clause__RestrictionGasAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6823:1: ( ( ruleRestrictionGas ) )
            // InternalSM2.g:6824:2: ( ruleRestrictionGas )
            {
            // InternalSM2.g:6824:2: ( ruleRestrictionGas )
            // InternalSM2.g:6825:3: ruleRestrictionGas
            {
             before(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_10_0()); 
            pushFollow(FOLLOW_2);
            ruleRestrictionGas();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__RestrictionGasAssignment_10"


    // $ANTLR start "rule__Clause__ExpressionAssignment_11"
    // InternalSM2.g:6834:1: rule__Clause__ExpressionAssignment_11 : ( ruleExpression ) ;
    public final void rule__Clause__ExpressionAssignment_11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6838:1: ( ( ruleExpression ) )
            // InternalSM2.g:6839:2: ( ruleExpression )
            {
            // InternalSM2.g:6839:2: ( ruleExpression )
            // InternalSM2.g:6840:3: ruleExpression
            {
             before(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_11_0()); 
            pushFollow(FOLLOW_2);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__ExpressionAssignment_11"


    // $ANTLR start "rule__ArithmethicalExpression__Op1Assignment_0_1"
    // InternalSM2.g:6849:1: rule__ArithmethicalExpression__Op1Assignment_0_1 : ( RULE_INT ) ;
    public final void rule__ArithmethicalExpression__Op1Assignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6853:1: ( ( RULE_INT ) )
            // InternalSM2.g:6854:2: ( RULE_INT )
            {
            // InternalSM2.g:6854:2: ( RULE_INT )
            // InternalSM2.g:6855:3: RULE_INT
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_0_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op1Assignment_0_1"


    // $ANTLR start "rule__ArithmethicalExpression__OperatorAssignment_0_2"
    // InternalSM2.g:6864:1: rule__ArithmethicalExpression__OperatorAssignment_0_2 : ( ruleArithmeticalOperator ) ;
    public final void rule__ArithmethicalExpression__OperatorAssignment_0_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6868:1: ( ( ruleArithmeticalOperator ) )
            // InternalSM2.g:6869:2: ( ruleArithmeticalOperator )
            {
            // InternalSM2.g:6869:2: ( ruleArithmeticalOperator )
            // InternalSM2.g:6870:3: ruleArithmeticalOperator
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0()); 
            pushFollow(FOLLOW_2);
            ruleArithmeticalOperator();

            state._fsp--;

             after(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__OperatorAssignment_0_2"


    // $ANTLR start "rule__ArithmethicalExpression__Op2Assignment_0_3"
    // InternalSM2.g:6879:1: rule__ArithmethicalExpression__Op2Assignment_0_3 : ( RULE_INT ) ;
    public final void rule__ArithmethicalExpression__Op2Assignment_0_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6883:1: ( ( RULE_INT ) )
            // InternalSM2.g:6884:2: ( RULE_INT )
            {
            // InternalSM2.g:6884:2: ( RULE_INT )
            // InternalSM2.g:6885:3: RULE_INT
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_0_3_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_0_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op2Assignment_0_3"


    // $ANTLR start "rule__ArithmethicalExpression__Op1Assignment_1_0"
    // InternalSM2.g:6894:1: rule__ArithmethicalExpression__Op1Assignment_1_0 : ( RULE_INT ) ;
    public final void rule__ArithmethicalExpression__Op1Assignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6898:1: ( ( RULE_INT ) )
            // InternalSM2.g:6899:2: ( RULE_INT )
            {
            // InternalSM2.g:6899:2: ( RULE_INT )
            // InternalSM2.g:6900:3: RULE_INT
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_1_0_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op1Assignment_1_0"


    // $ANTLR start "rule__ArithmethicalExpression__OperatorAssignment_1_1"
    // InternalSM2.g:6909:1: rule__ArithmethicalExpression__OperatorAssignment_1_1 : ( ruleArithmeticalOperator ) ;
    public final void rule__ArithmethicalExpression__OperatorAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6913:1: ( ( ruleArithmeticalOperator ) )
            // InternalSM2.g:6914:2: ( ruleArithmeticalOperator )
            {
            // InternalSM2.g:6914:2: ( ruleArithmeticalOperator )
            // InternalSM2.g:6915:3: ruleArithmeticalOperator
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0()); 
            pushFollow(FOLLOW_2);
            ruleArithmeticalOperator();

            state._fsp--;

             after(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__OperatorAssignment_1_1"


    // $ANTLR start "rule__ArithmethicalExpression__Op2Assignment_1_2"
    // InternalSM2.g:6924:1: rule__ArithmethicalExpression__Op2Assignment_1_2 : ( RULE_INT ) ;
    public final void rule__ArithmethicalExpression__Op2Assignment_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6928:1: ( ( RULE_INT ) )
            // InternalSM2.g:6929:2: ( RULE_INT )
            {
            // InternalSM2.g:6929:2: ( RULE_INT )
            // InternalSM2.g:6930:3: RULE_INT
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_1_2_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op2Assignment_1_2"


    // $ANTLR start "rule__SyntaxExpression__TextAssignment_0"
    // InternalSM2.g:6939:1: rule__SyntaxExpression__TextAssignment_0 : ( RULE_STRING ) ;
    public final void rule__SyntaxExpression__TextAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6943:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6944:2: ( RULE_STRING )
            {
            // InternalSM2.g:6944:2: ( RULE_STRING )
            // InternalSM2.g:6945:3: RULE_STRING
            {
             before(grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__TextAssignment_0"


    // $ANTLR start "rule__ShortComment__ExprAssignment_1"
    // InternalSM2.g:6954:1: rule__ShortComment__ExprAssignment_1 : ( RULE_STRING ) ;
    public final void rule__ShortComment__ExprAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6958:1: ( ( RULE_STRING ) )
            // InternalSM2.g:6959:2: ( RULE_STRING )
            {
            // InternalSM2.g:6959:2: ( RULE_STRING )
            // InternalSM2.g:6960:3: RULE_STRING
            {
             before(grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__ExprAssignment_1"


    // $ANTLR start "rule__LongComment__ExpressionAssignment_1"
    // InternalSM2.g:6969:1: rule__LongComment__ExpressionAssignment_1 : ( ( rule__LongComment__ExpressionAlternatives_1_0 ) ) ;
    public final void rule__LongComment__ExpressionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6973:1: ( ( ( rule__LongComment__ExpressionAlternatives_1_0 ) ) )
            // InternalSM2.g:6974:2: ( ( rule__LongComment__ExpressionAlternatives_1_0 ) )
            {
            // InternalSM2.g:6974:2: ( ( rule__LongComment__ExpressionAlternatives_1_0 ) )
            // InternalSM2.g:6975:3: ( rule__LongComment__ExpressionAlternatives_1_0 )
            {
             before(grammarAccess.getLongCommentAccess().getExpressionAlternatives_1_0()); 
            // InternalSM2.g:6976:3: ( rule__LongComment__ExpressionAlternatives_1_0 )
            // InternalSM2.g:6976:4: rule__LongComment__ExpressionAlternatives_1_0
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__ExpressionAlternatives_1_0();

            state._fsp--;


            }

             after(grammarAccess.getLongCommentAccess().getExpressionAlternatives_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__ExpressionAssignment_1"

    // Delegated rules


    protected DFA50 dfa50 = new DFA50(this);
    static final String dfa_1s = "\20\uffff";
    static final String dfa_2s = "\1\5\1\21\1\uffff\1\5\1\32\1\14\6\5\1\15\1\14\1\uffff\1\32";
    static final String dfa_3s = "\1\105\1\21\1\uffff\1\6\2\62\6\6\1\15\1\60\1\uffff\1\62";
    static final String dfa_4s = "\2\uffff\1\2\13\uffff\1\1\1\uffff";
    static final String dfa_5s = "\20\uffff}>";
    static final String[] dfa_6s = {
            "\2\2\6\uffff\1\2\1\uffff\1\2\1\uffff\1\2\63\uffff\1\1",
            "\1\3",
            "",
            "\1\5\1\4",
            "\1\6\1\10\1\7\1\11\23\uffff\1\12\1\13",
            "\1\14\15\uffff\1\6\1\10\1\7\1\11\23\uffff\1\12\1\13",
            "\1\15\1\16",
            "\1\15\1\16",
            "\1\15\1\16",
            "\1\15\1\16",
            "\1\15\1\16",
            "\1\15\1\16",
            "\1\17",
            "\1\16\5\uffff\1\16\30\uffff\6\2",
            "",
            "\1\6\1\10\1\7\1\11\23\uffff\1\12\1\13"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA50 extends DFA {

        public DFA50(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 50;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "5144:2: ( rule__Clause__RestrictionAssignment_9 )?";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x000000000C000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0800000000002000L,0x0000000000000800L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0800000000000002L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0400000000004000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x6000007FC000A010L,0x00000000000001CDL});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000007FC0000012L,0x000000000000000DL});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x2000000000000002L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x4000000000000002L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000040L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000180L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000030000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x1000000000001000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000007FC0040000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000007FC0000002L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000002040L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x8000000000002000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000007FC0000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000078000000010L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000007FC0002000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000088000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000000001060L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000000000060L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x000600003C000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0001F80000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000078000000000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000000000040010L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x000000000002A060L,0x0000000000000020L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x01E0000000000000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000000000000FC0L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L});

}