package org.xtext.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_PARAMSLONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_NOTICELONGCOMENT", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_OPENKEY", "RULE_CLOSEKEY", "RULE_DOT", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_EMAIL", "RULE_NUMBER", "RULE_COMMA", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'>'", "'>='", "'<'", "'<='", "'int'", "'uint'", "'uint8'", "'uint256'", "'string'", "'address'", "'address payable'", "'double'", "'bool'", "'public'", "'private'", "'internal'", "'external'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'=='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'", "'solidity'", "'is'", "'import'", "'as'", "'event'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'='", "'enum'", "'require'", "'function'", "'//'", "'/*'", "'*/'", "'pragma'", "'contract'", "'^'"
    };
    public static final int T__50=50;
    public static final int RULE_OPENPARENTHESIS=17;
    public static final int RULE_EOLINE=13;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int RULE_CLOSEKEY=15;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_PARAMSLONGCOMENT=7;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int RULE_COMMA=21;
    public static final int RULE_RETURNSLONGCOMENT=9;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=5;
    public static final int T__29=29;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=22;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int RULE_SEMICOLON=12;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_TITLELONGCOMENT=10;
    public static final int RULE_STRING=6;
    public static final int RULE_NOTICELONGCOMENT=11;
    public static final int RULE_EMAIL=19;
    public static final int RULE_SL_COMMENT=23;
    public static final int T__37=37;
    public static final int RULE_OPENKEY=14;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int RULE_CLOSEPARENTHESIS=18;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__73=73;
    public static final int RULE_DOT=16;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__74=74;
    public static final int T__31=31;
    public static final int T__75=75;
    public static final int T__32=32;
    public static final int T__76=76;
    public static final int RULE_WS=24;
    public static final int RULE_ANY_OTHER=25;
    public static final int RULE_NUMBER=20;
    public static final int RULE_DEVLONGCOMENT=8;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }


    	private SM2GrammarAccess grammarAccess;

    	public void setGrammarAccess(SM2GrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleSmartContract"
    // InternalSM2.g:54:1: entryRuleSmartContract : ruleSmartContract EOF ;
    public final void entryRuleSmartContract() throws RecognitionException {
        try {
            // InternalSM2.g:55:1: ( ruleSmartContract EOF )
            // InternalSM2.g:56:1: ruleSmartContract EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleSmartContract();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSmartContract"


    // $ANTLR start "ruleSmartContract"
    // InternalSM2.g:63:1: ruleSmartContract : ( ( rule__SmartContract__Group__0 ) ) ;
    public final void ruleSmartContract() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:67:2: ( ( ( rule__SmartContract__Group__0 ) ) )
            // InternalSM2.g:68:2: ( ( rule__SmartContract__Group__0 ) )
            {
            // InternalSM2.g:68:2: ( ( rule__SmartContract__Group__0 ) )
            // InternalSM2.g:69:3: ( rule__SmartContract__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getGroup()); 
            }
            // InternalSM2.g:70:3: ( rule__SmartContract__Group__0 )
            // InternalSM2.g:70:4: rule__SmartContract__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSmartContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:79:1: entryRuleVersion : ruleVersion EOF ;
    public final void entryRuleVersion() throws RecognitionException {
        try {
            // InternalSM2.g:80:1: ( ruleVersion EOF )
            // InternalSM2.g:81:1: ruleVersion EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleVersion();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:88:1: ruleVersion : ( ( rule__Version__Alternatives ) ) ;
    public final void ruleVersion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:92:2: ( ( ( rule__Version__Alternatives ) ) )
            // InternalSM2.g:93:2: ( ( rule__Version__Alternatives ) )
            {
            // InternalSM2.g:93:2: ( ( rule__Version__Alternatives ) )
            // InternalSM2.g:94:3: ( rule__Version__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getAlternatives()); 
            }
            // InternalSM2.g:95:3: ( rule__Version__Alternatives )
            // InternalSM2.g:95:4: rule__Version__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Version__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleImport"
    // InternalSM2.g:104:1: entryRuleImport : ruleImport EOF ;
    public final void entryRuleImport() throws RecognitionException {
        try {
            // InternalSM2.g:105:1: ( ruleImport EOF )
            // InternalSM2.g:106:1: ruleImport EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleImport();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2.g:113:1: ruleImport : ( ( rule__Import__Group__0 ) ) ;
    public final void ruleImport() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:117:2: ( ( ( rule__Import__Group__0 ) ) )
            // InternalSM2.g:118:2: ( ( rule__Import__Group__0 ) )
            {
            // InternalSM2.g:118:2: ( ( rule__Import__Group__0 ) )
            // InternalSM2.g:119:3: ( rule__Import__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getGroup()); 
            }
            // InternalSM2.g:120:3: ( rule__Import__Group__0 )
            // InternalSM2.g:120:4: rule__Import__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:129:1: entryRuleAttributes : ruleAttributes EOF ;
    public final void entryRuleAttributes() throws RecognitionException {
        try {
            // InternalSM2.g:130:1: ( ruleAttributes EOF )
            // InternalSM2.g:131:1: ruleAttributes EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getAttributesRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleAttributes();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getAttributesRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:138:1: ruleAttributes : ( ( rule__Attributes__Alternatives ) ) ;
    public final void ruleAttributes() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:142:2: ( ( ( rule__Attributes__Alternatives ) ) )
            // InternalSM2.g:143:2: ( ( rule__Attributes__Alternatives ) )
            {
            // InternalSM2.g:143:2: ( ( rule__Attributes__Alternatives ) )
            // InternalSM2.g:144:3: ( rule__Attributes__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getAttributesAccess().getAlternatives()); 
            }
            // InternalSM2.g:145:3: ( rule__Attributes__Alternatives )
            // InternalSM2.g:145:4: rule__Attributes__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Attributes__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getAttributesAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleEvent"
    // InternalSM2.g:154:1: entryRuleEvent : ruleEvent EOF ;
    public final void entryRuleEvent() throws RecognitionException {
        try {
            // InternalSM2.g:155:1: ( ruleEvent EOF )
            // InternalSM2.g:156:1: ruleEvent EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleEvent();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalSM2.g:163:1: ruleEvent : ( ( rule__Event__Group__0 ) ) ;
    public final void ruleEvent() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:167:2: ( ( ( rule__Event__Group__0 ) ) )
            // InternalSM2.g:168:2: ( ( rule__Event__Group__0 ) )
            {
            // InternalSM2.g:168:2: ( ( rule__Event__Group__0 ) )
            // InternalSM2.g:169:3: ( rule__Event__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getGroup()); 
            }
            // InternalSM2.g:170:3: ( rule__Event__Group__0 )
            // InternalSM2.g:170:4: rule__Event__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Event__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:179:1: entryRuleModifier : ruleModifier EOF ;
    public final void entryRuleModifier() throws RecognitionException {
        try {
            // InternalSM2.g:180:1: ( ruleModifier EOF )
            // InternalSM2.g:181:1: ruleModifier EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleModifier();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:188:1: ruleModifier : ( ( rule__Modifier__Group__0 ) ) ;
    public final void ruleModifier() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:192:2: ( ( ( rule__Modifier__Group__0 ) ) )
            // InternalSM2.g:193:2: ( ( rule__Modifier__Group__0 ) )
            {
            // InternalSM2.g:193:2: ( ( rule__Modifier__Group__0 ) )
            // InternalSM2.g:194:3: ( rule__Modifier__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getGroup()); 
            }
            // InternalSM2.g:195:3: ( rule__Modifier__Group__0 )
            // InternalSM2.g:195:4: rule__Modifier__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:204:1: entryRuleDataType : ruleDataType EOF ;
    public final void entryRuleDataType() throws RecognitionException {
        try {
            // InternalSM2.g:205:1: ( ruleDataType EOF )
            // InternalSM2.g:206:1: ruleDataType EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getDataTypeRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleDataType();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getDataTypeRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:213:1: ruleDataType : ( ( rule__DataType__Alternatives ) ) ;
    public final void ruleDataType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:217:2: ( ( ( rule__DataType__Alternatives ) ) )
            // InternalSM2.g:218:2: ( ( rule__DataType__Alternatives ) )
            {
            // InternalSM2.g:218:2: ( ( rule__DataType__Alternatives ) )
            // InternalSM2.g:219:3: ( rule__DataType__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getDataTypeAccess().getAlternatives()); 
            }
            // InternalSM2.g:220:3: ( rule__DataType__Alternatives )
            // InternalSM2.g:220:4: rule__DataType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__DataType__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getDataTypeAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2.g:229:1: entryRuleCompositeType : ruleCompositeType EOF ;
    public final void entryRuleCompositeType() throws RecognitionException {
        try {
            // InternalSM2.g:230:1: ( ruleCompositeType EOF )
            // InternalSM2.g:231:1: ruleCompositeType EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getCompositeTypeRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleCompositeType();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getCompositeTypeRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2.g:238:1: ruleCompositeType : ( ( rule__CompositeType__Alternatives ) ) ;
    public final void ruleCompositeType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:242:2: ( ( ( rule__CompositeType__Alternatives ) ) )
            // InternalSM2.g:243:2: ( ( rule__CompositeType__Alternatives ) )
            {
            // InternalSM2.g:243:2: ( ( rule__CompositeType__Alternatives ) )
            // InternalSM2.g:244:3: ( rule__CompositeType__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getCompositeTypeAccess().getAlternatives()); 
            }
            // InternalSM2.g:245:3: ( rule__CompositeType__Alternatives )
            // InternalSM2.g:245:4: rule__CompositeType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__CompositeType__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getCompositeTypeAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:254:1: entryRuleMapping : ruleMapping EOF ;
    public final void entryRuleMapping() throws RecognitionException {
        try {
            // InternalSM2.g:255:1: ( ruleMapping EOF )
            // InternalSM2.g:256:1: ruleMapping EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleMapping();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:263:1: ruleMapping : ( ( rule__Mapping__Group__0 ) ) ;
    public final void ruleMapping() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:267:2: ( ( ( rule__Mapping__Group__0 ) ) )
            // InternalSM2.g:268:2: ( ( rule__Mapping__Group__0 ) )
            {
            // InternalSM2.g:268:2: ( ( rule__Mapping__Group__0 ) )
            // InternalSM2.g:269:3: ( rule__Mapping__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getGroup()); 
            }
            // InternalSM2.g:270:3: ( rule__Mapping__Group__0 )
            // InternalSM2.g:270:4: rule__Mapping__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:279:1: entryRuleStruct : ruleStruct EOF ;
    public final void entryRuleStruct() throws RecognitionException {
        try {
            // InternalSM2.g:280:1: ( ruleStruct EOF )
            // InternalSM2.g:281:1: ruleStruct EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getStructRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleStruct();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getStructRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:288:1: ruleStruct : ( ( rule__Struct__Alternatives ) ) ;
    public final void ruleStruct() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:292:2: ( ( ( rule__Struct__Alternatives ) ) )
            // InternalSM2.g:293:2: ( ( rule__Struct__Alternatives ) )
            {
            // InternalSM2.g:293:2: ( ( rule__Struct__Alternatives ) )
            // InternalSM2.g:294:3: ( rule__Struct__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getStructAccess().getAlternatives()); 
            }
            // InternalSM2.g:295:3: ( rule__Struct__Alternatives )
            // InternalSM2.g:295:4: rule__Struct__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Struct__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getStructAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRulePersonalizedStruct"
    // InternalSM2.g:304:1: entryRulePersonalizedStruct : rulePersonalizedStruct EOF ;
    public final void entryRulePersonalizedStruct() throws RecognitionException {
        try {
            // InternalSM2.g:305:1: ( rulePersonalizedStruct EOF )
            // InternalSM2.g:306:1: rulePersonalizedStruct EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructRule()); 
            }
            pushFollow(FOLLOW_1);
            rulePersonalizedStruct();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePersonalizedStruct"


    // $ANTLR start "rulePersonalizedStruct"
    // InternalSM2.g:313:1: rulePersonalizedStruct : ( ( rule__PersonalizedStruct__Group__0 ) ) ;
    public final void rulePersonalizedStruct() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:317:2: ( ( ( rule__PersonalizedStruct__Group__0 ) ) )
            // InternalSM2.g:318:2: ( ( rule__PersonalizedStruct__Group__0 ) )
            {
            // InternalSM2.g:318:2: ( ( rule__PersonalizedStruct__Group__0 ) )
            // InternalSM2.g:319:3: ( rule__PersonalizedStruct__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getGroup()); 
            }
            // InternalSM2.g:320:3: ( rule__PersonalizedStruct__Group__0 )
            // InternalSM2.g:320:4: rule__PersonalizedStruct__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePersonalizedStruct"


    // $ANTLR start "entryRuleUser"
    // InternalSM2.g:329:1: entryRuleUser : ruleUser EOF ;
    public final void entryRuleUser() throws RecognitionException {
        try {
            // InternalSM2.g:330:1: ( ruleUser EOF )
            // InternalSM2.g:331:1: ruleUser EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleUser();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUser"


    // $ANTLR start "ruleUser"
    // InternalSM2.g:338:1: ruleUser : ( ( rule__User__Group__0 ) ) ;
    public final void ruleUser() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:342:2: ( ( ( rule__User__Group__0 ) ) )
            // InternalSM2.g:343:2: ( ( rule__User__Group__0 ) )
            {
            // InternalSM2.g:343:2: ( ( rule__User__Group__0 ) )
            // InternalSM2.g:344:3: ( rule__User__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getGroup()); 
            }
            // InternalSM2.g:345:3: ( rule__User__Group__0 )
            // InternalSM2.g:345:4: rule__User__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__User__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUser"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:354:1: entryRuleEnum : ruleEnum EOF ;
    public final void entryRuleEnum() throws RecognitionException {
        try {
            // InternalSM2.g:355:1: ( ruleEnum EOF )
            // InternalSM2.g:356:1: ruleEnum EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleEnum();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:363:1: ruleEnum : ( ( rule__Enum__Group__0 ) ) ;
    public final void ruleEnum() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:367:2: ( ( ( rule__Enum__Group__0 ) ) )
            // InternalSM2.g:368:2: ( ( rule__Enum__Group__0 ) )
            {
            // InternalSM2.g:368:2: ( ( rule__Enum__Group__0 ) )
            // InternalSM2.g:369:3: ( rule__Enum__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getGroup()); 
            }
            // InternalSM2.g:370:3: ( rule__Enum__Group__0 )
            // InternalSM2.g:370:4: rule__Enum__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Enum__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:379:1: entryRuleProperty : ruleProperty EOF ;
    public final void entryRuleProperty() throws RecognitionException {
        try {
            // InternalSM2.g:380:1: ( ruleProperty EOF )
            // InternalSM2.g:381:1: ruleProperty EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleProperty();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:388:1: ruleProperty : ( ( rule__Property__Group__0 ) ) ;
    public final void ruleProperty() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:392:2: ( ( ( rule__Property__Group__0 ) ) )
            // InternalSM2.g:393:2: ( ( rule__Property__Group__0 ) )
            {
            // InternalSM2.g:393:2: ( ( rule__Property__Group__0 ) )
            // InternalSM2.g:394:3: ( rule__Property__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getGroup()); 
            }
            // InternalSM2.g:395:3: ( rule__Property__Group__0 )
            // InternalSM2.g:395:4: rule__Property__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Property__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:404:1: entryRuleInputParam : ruleInputParam EOF ;
    public final void entryRuleInputParam() throws RecognitionException {
        try {
            // InternalSM2.g:405:1: ( ruleInputParam EOF )
            // InternalSM2.g:406:1: ruleInputParam EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleInputParam();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:413:1: ruleInputParam : ( ( rule__InputParam__Group__0 ) ) ;
    public final void ruleInputParam() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:417:2: ( ( ( rule__InputParam__Group__0 ) ) )
            // InternalSM2.g:418:2: ( ( rule__InputParam__Group__0 ) )
            {
            // InternalSM2.g:418:2: ( ( rule__InputParam__Group__0 ) )
            // InternalSM2.g:419:3: ( rule__InputParam__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getGroup()); 
            }
            // InternalSM2.g:420:3: ( rule__InputParam__Group__0 )
            // InternalSM2.g:420:4: rule__InputParam__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:429:1: entryRuleRestriction : ruleRestriction EOF ;
    public final void entryRuleRestriction() throws RecognitionException {
        try {
            // InternalSM2.g:430:1: ( ruleRestriction EOF )
            // InternalSM2.g:431:1: ruleRestriction EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleRestriction();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:438:1: ruleRestriction : ( ( rule__Restriction__Group__0 ) ) ;
    public final void ruleRestriction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:442:2: ( ( ( rule__Restriction__Group__0 ) ) )
            // InternalSM2.g:443:2: ( ( rule__Restriction__Group__0 ) )
            {
            // InternalSM2.g:443:2: ( ( rule__Restriction__Group__0 ) )
            // InternalSM2.g:444:3: ( rule__Restriction__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getGroup()); 
            }
            // InternalSM2.g:445:3: ( rule__Restriction__Group__0 )
            // InternalSM2.g:445:4: rule__Restriction__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:454:1: entryRuleRestrictionGas : ruleRestrictionGas EOF ;
    public final void entryRuleRestrictionGas() throws RecognitionException {
        try {
            // InternalSM2.g:455:1: ( ruleRestrictionGas EOF )
            // InternalSM2.g:456:1: ruleRestrictionGas EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:463:1: ruleRestrictionGas : ( ( rule__RestrictionGas__Group__0 ) ) ;
    public final void ruleRestrictionGas() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:467:2: ( ( ( rule__RestrictionGas__Group__0 ) ) )
            // InternalSM2.g:468:2: ( ( rule__RestrictionGas__Group__0 ) )
            {
            // InternalSM2.g:468:2: ( ( rule__RestrictionGas__Group__0 ) )
            // InternalSM2.g:469:3: ( rule__RestrictionGas__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getGroup()); 
            }
            // InternalSM2.g:470:3: ( rule__RestrictionGas__Group__0 )
            // InternalSM2.g:470:4: rule__RestrictionGas__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2.g:479:1: entryRuleClause : ruleClause EOF ;
    public final void entryRuleClause() throws RecognitionException {
        try {
            // InternalSM2.g:480:1: ( ruleClause EOF )
            // InternalSM2.g:481:1: ruleClause EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleClause();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2.g:488:1: ruleClause : ( ( rule__Clause__Group__0 ) ) ;
    public final void ruleClause() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:492:2: ( ( ( rule__Clause__Group__0 ) ) )
            // InternalSM2.g:493:2: ( ( rule__Clause__Group__0 ) )
            {
            // InternalSM2.g:493:2: ( ( rule__Clause__Group__0 ) )
            // InternalSM2.g:494:3: ( rule__Clause__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getGroup()); 
            }
            // InternalSM2.g:495:3: ( rule__Clause__Group__0 )
            // InternalSM2.g:495:4: rule__Clause__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Clause__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:504:1: entryRuleExpression : ruleExpression EOF ;
    public final void entryRuleExpression() throws RecognitionException {
        try {
            // InternalSM2.g:505:1: ( ruleExpression EOF )
            // InternalSM2.g:506:1: ruleExpression EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getExpressionRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:513:1: ruleExpression : ( ( rule__Expression__Alternatives ) ) ;
    public final void ruleExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:517:2: ( ( ( rule__Expression__Alternatives ) ) )
            // InternalSM2.g:518:2: ( ( rule__Expression__Alternatives ) )
            {
            // InternalSM2.g:518:2: ( ( rule__Expression__Alternatives ) )
            // InternalSM2.g:519:3: ( rule__Expression__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getExpressionAccess().getAlternatives()); 
            }
            // InternalSM2.g:520:3: ( rule__Expression__Alternatives )
            // InternalSM2.g:520:4: rule__Expression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Expression__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getExpressionAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleArithmethicalExpression"
    // InternalSM2.g:529:1: entryRuleArithmethicalExpression : ruleArithmethicalExpression EOF ;
    public final void entryRuleArithmethicalExpression() throws RecognitionException {
        try {
            // InternalSM2.g:530:1: ( ruleArithmethicalExpression EOF )
            // InternalSM2.g:531:1: ruleArithmethicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleArithmethicalExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleArithmethicalExpression"


    // $ANTLR start "ruleArithmethicalExpression"
    // InternalSM2.g:538:1: ruleArithmethicalExpression : ( ( rule__ArithmethicalExpression__Alternatives ) ) ;
    public final void ruleArithmethicalExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:542:2: ( ( ( rule__ArithmethicalExpression__Alternatives ) ) )
            // InternalSM2.g:543:2: ( ( rule__ArithmethicalExpression__Alternatives ) )
            {
            // InternalSM2.g:543:2: ( ( rule__ArithmethicalExpression__Alternatives ) )
            // InternalSM2.g:544:3: ( rule__ArithmethicalExpression__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getAlternatives()); 
            }
            // InternalSM2.g:545:3: ( rule__ArithmethicalExpression__Alternatives )
            // InternalSM2.g:545:4: rule__ArithmethicalExpression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleArithmethicalExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:554:1: entryRuleSyntaxExpression : ruleSyntaxExpression EOF ;
    public final void entryRuleSyntaxExpression() throws RecognitionException {
        try {
            // InternalSM2.g:555:1: ( ruleSyntaxExpression EOF )
            // InternalSM2.g:556:1: ruleSyntaxExpression EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSyntaxExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSyntaxExpressionRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:563:1: ruleSyntaxExpression : ( ( rule__SyntaxExpression__Alternatives ) ) ;
    public final void ruleSyntaxExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:567:2: ( ( ( rule__SyntaxExpression__Alternatives ) ) )
            // InternalSM2.g:568:2: ( ( rule__SyntaxExpression__Alternatives ) )
            {
            // InternalSM2.g:568:2: ( ( rule__SyntaxExpression__Alternatives ) )
            // InternalSM2.g:569:3: ( rule__SyntaxExpression__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSyntaxExpressionAccess().getAlternatives()); 
            }
            // InternalSM2.g:570:3: ( rule__SyntaxExpression__Alternatives )
            // InternalSM2.g:570:4: rule__SyntaxExpression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSyntaxExpressionAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:579:1: entryRuleComment : ruleComment EOF ;
    public final void entryRuleComment() throws RecognitionException {
        try {
            // InternalSM2.g:580:1: ( ruleComment EOF )
            // InternalSM2.g:581:1: ruleComment EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleComment();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getCommentRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:588:1: ruleComment : ( ( rule__Comment__Alternatives ) ) ;
    public final void ruleComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:592:2: ( ( ( rule__Comment__Alternatives ) ) )
            // InternalSM2.g:593:2: ( ( rule__Comment__Alternatives ) )
            {
            // InternalSM2.g:593:2: ( ( rule__Comment__Alternatives ) )
            // InternalSM2.g:594:3: ( rule__Comment__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getCommentAccess().getAlternatives()); 
            }
            // InternalSM2.g:595:3: ( rule__Comment__Alternatives )
            // InternalSM2.g:595:4: rule__Comment__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Comment__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getCommentAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:604:1: entryRuleShortComment : ruleShortComment EOF ;
    public final void entryRuleShortComment() throws RecognitionException {
        try {
            // InternalSM2.g:605:1: ( ruleShortComment EOF )
            // InternalSM2.g:606:1: ruleShortComment EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getShortCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleShortComment();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getShortCommentRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:613:1: ruleShortComment : ( ( rule__ShortComment__Group__0 ) ) ;
    public final void ruleShortComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:617:2: ( ( ( rule__ShortComment__Group__0 ) ) )
            // InternalSM2.g:618:2: ( ( rule__ShortComment__Group__0 ) )
            {
            // InternalSM2.g:618:2: ( ( rule__ShortComment__Group__0 ) )
            // InternalSM2.g:619:3: ( rule__ShortComment__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getShortCommentAccess().getGroup()); 
            }
            // InternalSM2.g:620:3: ( rule__ShortComment__Group__0 )
            // InternalSM2.g:620:4: rule__ShortComment__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getShortCommentAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:629:1: entryRuleLongComment : ruleLongComment EOF ;
    public final void entryRuleLongComment() throws RecognitionException {
        try {
            // InternalSM2.g:630:1: ( ruleLongComment EOF )
            // InternalSM2.g:631:1: ruleLongComment EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getLongCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleLongComment();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getLongCommentRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:638:1: ruleLongComment : ( ( rule__LongComment__Group__0 ) ) ;
    public final void ruleLongComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:642:2: ( ( ( rule__LongComment__Group__0 ) ) )
            // InternalSM2.g:643:2: ( ( rule__LongComment__Group__0 ) )
            {
            // InternalSM2.g:643:2: ( ( rule__LongComment__Group__0 ) )
            // InternalSM2.g:644:3: ( rule__LongComment__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getLongCommentAccess().getGroup()); 
            }
            // InternalSM2.g:645:3: ( rule__LongComment__Group__0 )
            // InternalSM2.g:645:4: rule__LongComment__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getLongCommentAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "ruleSingularType"
    // InternalSM2.g:654:1: ruleSingularType : ( ( rule__SingularType__Alternatives ) ) ;
    public final void ruleSingularType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:658:1: ( ( ( rule__SingularType__Alternatives ) ) )
            // InternalSM2.g:659:2: ( ( rule__SingularType__Alternatives ) )
            {
            // InternalSM2.g:659:2: ( ( rule__SingularType__Alternatives ) )
            // InternalSM2.g:660:3: ( rule__SingularType__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSingularTypeAccess().getAlternatives()); 
            }
            // InternalSM2.g:661:3: ( rule__SingularType__Alternatives )
            // InternalSM2.g:661:4: rule__SingularType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__SingularType__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSingularTypeAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:670:1: ruleVisibility : ( ( rule__Visibility__Alternatives ) ) ;
    public final void ruleVisibility() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:674:1: ( ( ( rule__Visibility__Alternatives ) ) )
            // InternalSM2.g:675:2: ( ( rule__Visibility__Alternatives ) )
            {
            // InternalSM2.g:675:2: ( ( rule__Visibility__Alternatives ) )
            // InternalSM2.g:676:3: ( rule__Visibility__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVisibilityAccess().getAlternatives()); 
            }
            // InternalSM2.g:677:3: ( rule__Visibility__Alternatives )
            // InternalSM2.g:677:4: rule__Visibility__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Visibility__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVisibilityAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:686:1: ruleCoin : ( ( rule__Coin__Alternatives ) ) ;
    public final void ruleCoin() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:690:1: ( ( ( rule__Coin__Alternatives ) ) )
            // InternalSM2.g:691:2: ( ( rule__Coin__Alternatives ) )
            {
            // InternalSM2.g:691:2: ( ( rule__Coin__Alternatives ) )
            // InternalSM2.g:692:3: ( rule__Coin__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getCoinAccess().getAlternatives()); 
            }
            // InternalSM2.g:693:3: ( rule__Coin__Alternatives )
            // InternalSM2.g:693:4: rule__Coin__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Coin__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getCoinAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:702:1: ruleComparationOperator : ( ( rule__ComparationOperator__Alternatives ) ) ;
    public final void ruleComparationOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:706:1: ( ( ( rule__ComparationOperator__Alternatives ) ) )
            // InternalSM2.g:707:2: ( ( rule__ComparationOperator__Alternatives ) )
            {
            // InternalSM2.g:707:2: ( ( rule__ComparationOperator__Alternatives ) )
            // InternalSM2.g:708:3: ( rule__ComparationOperator__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getComparationOperatorAccess().getAlternatives()); 
            }
            // InternalSM2.g:709:3: ( rule__ComparationOperator__Alternatives )
            // InternalSM2.g:709:4: rule__ComparationOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ComparationOperator__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getComparationOperatorAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:718:1: ruleLogicalPairOperator : ( ( rule__LogicalPairOperator__Alternatives ) ) ;
    public final void ruleLogicalPairOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:722:1: ( ( ( rule__LogicalPairOperator__Alternatives ) ) )
            // InternalSM2.g:723:2: ( ( rule__LogicalPairOperator__Alternatives ) )
            {
            // InternalSM2.g:723:2: ( ( rule__LogicalPairOperator__Alternatives ) )
            // InternalSM2.g:724:3: ( rule__LogicalPairOperator__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getLogicalPairOperatorAccess().getAlternatives()); 
            }
            // InternalSM2.g:725:3: ( rule__LogicalPairOperator__Alternatives )
            // InternalSM2.g:725:4: rule__LogicalPairOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__LogicalPairOperator__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getLogicalPairOperatorAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:734:1: ruleArithmeticalOperator : ( ( rule__ArithmeticalOperator__Alternatives ) ) ;
    public final void ruleArithmeticalOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:738:1: ( ( ( rule__ArithmeticalOperator__Alternatives ) ) )
            // InternalSM2.g:739:2: ( ( rule__ArithmeticalOperator__Alternatives ) )
            {
            // InternalSM2.g:739:2: ( ( rule__ArithmeticalOperator__Alternatives ) )
            // InternalSM2.g:740:3: ( rule__ArithmeticalOperator__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmeticalOperatorAccess().getAlternatives()); 
            }
            // InternalSM2.g:741:3: ( rule__ArithmeticalOperator__Alternatives )
            // InternalSM2.g:741:4: rule__ArithmeticalOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ArithmeticalOperator__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmeticalOperatorAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleArithmeticalOperator"


    // $ANTLR start "rule__Version__Alternatives"
    // InternalSM2.g:749:1: rule__Version__Alternatives : ( ( ( rule__Version__Group_0__0 ) ) | ( ( rule__Version__Group_1__0 ) ) );
    public final void rule__Version__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:753:1: ( ( ( rule__Version__Group_0__0 ) ) | ( ( rule__Version__Group_1__0 ) ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==76) ) {
                alt1=1;
            }
            else if ( ((LA1_0>=26 && LA1_0<=27)) ) {
                alt1=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalSM2.g:754:2: ( ( rule__Version__Group_0__0 ) )
                    {
                    // InternalSM2.g:754:2: ( ( rule__Version__Group_0__0 ) )
                    // InternalSM2.g:755:3: ( rule__Version__Group_0__0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVersionAccess().getGroup_0()); 
                    }
                    // InternalSM2.g:756:3: ( rule__Version__Group_0__0 )
                    // InternalSM2.g:756:4: rule__Version__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Version__Group_0__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVersionAccess().getGroup_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:760:2: ( ( rule__Version__Group_1__0 ) )
                    {
                    // InternalSM2.g:760:2: ( ( rule__Version__Group_1__0 ) )
                    // InternalSM2.g:761:3: ( rule__Version__Group_1__0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVersionAccess().getGroup_1()); 
                    }
                    // InternalSM2.g:762:3: ( rule__Version__Group_1__0 )
                    // InternalSM2.g:762:4: rule__Version__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Version__Group_1__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVersionAccess().getGroup_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Alternatives"


    // $ANTLR start "rule__Version__SymbolAlternatives_1_0_0"
    // InternalSM2.g:770:1: rule__Version__SymbolAlternatives_1_0_0 : ( ( '>' ) | ( '>=' ) );
    public final void rule__Version__SymbolAlternatives_1_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:774:1: ( ( '>' ) | ( '>=' ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==26) ) {
                alt2=1;
            }
            else if ( (LA2_0==27) ) {
                alt2=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalSM2.g:775:2: ( '>' )
                    {
                    // InternalSM2.g:775:2: ( '>' )
                    // InternalSM2.g:776:3: '>'
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_1_0_0_0()); 
                    }
                    match(input,26,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_1_0_0_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:781:2: ( '>=' )
                    {
                    // InternalSM2.g:781:2: ( '>=' )
                    // InternalSM2.g:782:3: '>='
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_1_0_0_1()); 
                    }
                    match(input,27,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_1_0_0_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAlternatives_1_0_0"


    // $ANTLR start "rule__Version__Symbol2Alternatives_1_6_0_0"
    // InternalSM2.g:791:1: rule__Version__Symbol2Alternatives_1_6_0_0 : ( ( '<' ) | ( '<=' ) );
    public final void rule__Version__Symbol2Alternatives_1_6_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:795:1: ( ( '<' ) | ( '<=' ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==28) ) {
                alt3=1;
            }
            else if ( (LA3_0==29) ) {
                alt3=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalSM2.g:796:2: ( '<' )
                    {
                    // InternalSM2.g:796:2: ( '<' )
                    // InternalSM2.g:797:3: '<'
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVersionAccess().getSymbol2LessThanSignKeyword_1_6_0_0_0()); 
                    }
                    match(input,28,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVersionAccess().getSymbol2LessThanSignKeyword_1_6_0_0_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:802:2: ( '<=' )
                    {
                    // InternalSM2.g:802:2: ( '<=' )
                    // InternalSM2.g:803:3: '<='
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVersionAccess().getSymbol2LessThanSignEqualsSignKeyword_1_6_0_0_1()); 
                    }
                    match(input,29,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVersionAccess().getSymbol2LessThanSignEqualsSignKeyword_1_6_0_0_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Symbol2Alternatives_1_6_0_0"


    // $ANTLR start "rule__Attributes__Alternatives"
    // InternalSM2.g:812:1: rule__Attributes__Alternatives : ( ( ruleProperty ) | ( ruleDataType ) );
    public final void rule__Attributes__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:816:1: ( ( ruleProperty ) | ( ruleDataType ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( ((LA4_0>=30 && LA4_0<=38)) ) {
                alt4=1;
            }
            else if ( (LA4_0==RULE_ID||LA4_0==64||LA4_0==66||LA4_0==68) ) {
                alt4=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalSM2.g:817:2: ( ruleProperty )
                    {
                    // InternalSM2.g:817:2: ( ruleProperty )
                    // InternalSM2.g:818:3: ruleProperty
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleProperty();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:823:2: ( ruleDataType )
                    {
                    // InternalSM2.g:823:2: ( ruleDataType )
                    // InternalSM2.g:824:3: ruleDataType
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleDataType();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attributes__Alternatives"


    // $ANTLR start "rule__DataType__Alternatives"
    // InternalSM2.g:833:1: rule__DataType__Alternatives : ( ( ruleCompositeType ) | ( ruleEnum ) | ( RULE_ID ) );
    public final void rule__DataType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:837:1: ( ( ruleCompositeType ) | ( ruleEnum ) | ( RULE_ID ) )
            int alt5=3;
            switch ( input.LA(1) ) {
            case 64:
            case 66:
                {
                alt5=1;
                }
                break;
            case 68:
                {
                alt5=2;
                }
                break;
            case RULE_ID:
                {
                alt5=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // InternalSM2.g:838:2: ( ruleCompositeType )
                    {
                    // InternalSM2.g:838:2: ( ruleCompositeType )
                    // InternalSM2.g:839:3: ruleCompositeType
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleCompositeType();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:844:2: ( ruleEnum )
                    {
                    // InternalSM2.g:844:2: ( ruleEnum )
                    // InternalSM2.g:845:3: ruleEnum
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleEnum();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:850:2: ( RULE_ID )
                    {
                    // InternalSM2.g:850:2: ( RULE_ID )
                    // InternalSM2.g:851:3: RULE_ID
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2()); 
                    }
                    match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataType__Alternatives"


    // $ANTLR start "rule__CompositeType__Alternatives"
    // InternalSM2.g:860:1: rule__CompositeType__Alternatives : ( ( ruleMapping ) | ( ruleStruct ) );
    public final void rule__CompositeType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:864:1: ( ( ruleMapping ) | ( ruleStruct ) )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==64) ) {
                alt6=1;
            }
            else if ( (LA6_0==66) ) {
                alt6=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalSM2.g:865:2: ( ruleMapping )
                    {
                    // InternalSM2.g:865:2: ( ruleMapping )
                    // InternalSM2.g:866:3: ruleMapping
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleMapping();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:871:2: ( ruleStruct )
                    {
                    // InternalSM2.g:871:2: ( ruleStruct )
                    // InternalSM2.g:872:3: ruleStruct
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleStruct();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CompositeType__Alternatives"


    // $ANTLR start "rule__Struct__Alternatives"
    // InternalSM2.g:881:1: rule__Struct__Alternatives : ( ( ( rule__Struct__TypeStructAssignment_0 ) ) | ( ruleUser ) );
    public final void rule__Struct__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:885:1: ( ( ( rule__Struct__TypeStructAssignment_0 ) ) | ( ruleUser ) )
            int alt7=2;
            alt7 = dfa7.predict(input);
            switch (alt7) {
                case 1 :
                    // InternalSM2.g:886:2: ( ( rule__Struct__TypeStructAssignment_0 ) )
                    {
                    // InternalSM2.g:886:2: ( ( rule__Struct__TypeStructAssignment_0 ) )
                    // InternalSM2.g:887:3: ( rule__Struct__TypeStructAssignment_0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getStructAccess().getTypeStructAssignment_0()); 
                    }
                    // InternalSM2.g:888:3: ( rule__Struct__TypeStructAssignment_0 )
                    // InternalSM2.g:888:4: rule__Struct__TypeStructAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Struct__TypeStructAssignment_0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getStructAccess().getTypeStructAssignment_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:892:2: ( ruleUser )
                    {
                    // InternalSM2.g:892:2: ( ruleUser )
                    // InternalSM2.g:893:3: ruleUser
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getStructAccess().getUserParserRuleCall_1()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleUser();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getStructAccess().getUserParserRuleCall_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Alternatives"


    // $ANTLR start "rule__Property__Alternatives_4"
    // InternalSM2.g:902:1: rule__Property__Alternatives_4 : ( ( ( rule__Property__InicializationAssignment_4_0 ) ) | ( RULE_INT ) );
    public final void rule__Property__Alternatives_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:906:1: ( ( ( rule__Property__InicializationAssignment_4_0 ) ) | ( RULE_INT ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==RULE_STRING) ) {
                alt8=1;
            }
            else if ( (LA8_0==RULE_INT) ) {
                alt8=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalSM2.g:907:2: ( ( rule__Property__InicializationAssignment_4_0 ) )
                    {
                    // InternalSM2.g:907:2: ( ( rule__Property__InicializationAssignment_4_0 ) )
                    // InternalSM2.g:908:3: ( rule__Property__InicializationAssignment_4_0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getPropertyAccess().getInicializationAssignment_4_0()); 
                    }
                    // InternalSM2.g:909:3: ( rule__Property__InicializationAssignment_4_0 )
                    // InternalSM2.g:909:4: rule__Property__InicializationAssignment_4_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__InicializationAssignment_4_0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getPropertyAccess().getInicializationAssignment_4_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:913:2: ( RULE_INT )
                    {
                    // InternalSM2.g:913:2: ( RULE_INT )
                    // InternalSM2.g:914:3: RULE_INT
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getPropertyAccess().getINTTerminalRuleCall_4_1()); 
                    }
                    match(input,RULE_INT,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getPropertyAccess().getINTTerminalRuleCall_4_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Alternatives_4"


    // $ANTLR start "rule__Expression__Alternatives"
    // InternalSM2.g:923:1: rule__Expression__Alternatives : ( ( ruleArithmethicalExpression ) | ( ruleSyntaxExpression ) );
    public final void rule__Expression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:927:1: ( ( ruleArithmethicalExpression ) | ( ruleSyntaxExpression ) )
            int alt9=2;
            switch ( input.LA(1) ) {
            case RULE_OPENPARENTHESIS:
                {
                alt9=1;
                }
                break;
            case RULE_NUMBER:
                {
                int LA9_2 = input.LA(2);

                if ( ((LA9_2>=53 && LA9_2<=56)) ) {
                    alt9=1;
                }
                else if ( (LA9_2==EOF||LA9_2==RULE_STRING||(LA9_2>=RULE_SEMICOLON && LA9_2<=RULE_EOLINE)||LA9_2==RULE_CLOSEKEY||LA9_2==RULE_OPENPARENTHESIS||LA9_2==RULE_NUMBER) ) {
                    alt9=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return ;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 9, 2, input);

                    throw nvae;
                }
                }
                break;
            case RULE_STRING:
                {
                alt9=2;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalSM2.g:928:2: ( ruleArithmethicalExpression )
                    {
                    // InternalSM2.g:928:2: ( ruleArithmethicalExpression )
                    // InternalSM2.g:929:3: ruleArithmethicalExpression
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleArithmethicalExpression();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:934:2: ( ruleSyntaxExpression )
                    {
                    // InternalSM2.g:934:2: ( ruleSyntaxExpression )
                    // InternalSM2.g:935:3: ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Expression__Alternatives"


    // $ANTLR start "rule__ArithmethicalExpression__Alternatives"
    // InternalSM2.g:944:1: rule__ArithmethicalExpression__Alternatives : ( ( ( rule__ArithmethicalExpression__Group_0__0 ) ) | ( ( rule__ArithmethicalExpression__Group_1__0 ) ) );
    public final void rule__ArithmethicalExpression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:948:1: ( ( ( rule__ArithmethicalExpression__Group_0__0 ) ) | ( ( rule__ArithmethicalExpression__Group_1__0 ) ) )
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==RULE_OPENPARENTHESIS) ) {
                alt10=1;
            }
            else if ( (LA10_0==RULE_NUMBER) ) {
                alt10=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }
            switch (alt10) {
                case 1 :
                    // InternalSM2.g:949:2: ( ( rule__ArithmethicalExpression__Group_0__0 ) )
                    {
                    // InternalSM2.g:949:2: ( ( rule__ArithmethicalExpression__Group_0__0 ) )
                    // InternalSM2.g:950:3: ( rule__ArithmethicalExpression__Group_0__0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getArithmethicalExpressionAccess().getGroup_0()); 
                    }
                    // InternalSM2.g:951:3: ( rule__ArithmethicalExpression__Group_0__0 )
                    // InternalSM2.g:951:4: rule__ArithmethicalExpression__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_0__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getArithmethicalExpressionAccess().getGroup_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:955:2: ( ( rule__ArithmethicalExpression__Group_1__0 ) )
                    {
                    // InternalSM2.g:955:2: ( ( rule__ArithmethicalExpression__Group_1__0 ) )
                    // InternalSM2.g:956:3: ( rule__ArithmethicalExpression__Group_1__0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getArithmethicalExpressionAccess().getGroup_1()); 
                    }
                    // InternalSM2.g:957:3: ( rule__ArithmethicalExpression__Group_1__0 )
                    // InternalSM2.g:957:4: rule__ArithmethicalExpression__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_1__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getArithmethicalExpressionAccess().getGroup_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Alternatives"


    // $ANTLR start "rule__SyntaxExpression__Alternatives"
    // InternalSM2.g:965:1: rule__SyntaxExpression__Alternatives : ( ( ( rule__SyntaxExpression__TextAssignment_0 ) ) | ( ( rule__SyntaxExpression__Group_1__0 ) ) );
    public final void rule__SyntaxExpression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:969:1: ( ( ( rule__SyntaxExpression__TextAssignment_0 ) ) | ( ( rule__SyntaxExpression__Group_1__0 ) ) )
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==RULE_STRING) ) {
                alt11=1;
            }
            else if ( (LA11_0==RULE_NUMBER) ) {
                alt11=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalSM2.g:970:2: ( ( rule__SyntaxExpression__TextAssignment_0 ) )
                    {
                    // InternalSM2.g:970:2: ( ( rule__SyntaxExpression__TextAssignment_0 ) )
                    // InternalSM2.g:971:3: ( rule__SyntaxExpression__TextAssignment_0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSyntaxExpressionAccess().getTextAssignment_0()); 
                    }
                    // InternalSM2.g:972:3: ( rule__SyntaxExpression__TextAssignment_0 )
                    // InternalSM2.g:972:4: rule__SyntaxExpression__TextAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__TextAssignment_0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSyntaxExpressionAccess().getTextAssignment_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:976:2: ( ( rule__SyntaxExpression__Group_1__0 ) )
                    {
                    // InternalSM2.g:976:2: ( ( rule__SyntaxExpression__Group_1__0 ) )
                    // InternalSM2.g:977:3: ( rule__SyntaxExpression__Group_1__0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSyntaxExpressionAccess().getGroup_1()); 
                    }
                    // InternalSM2.g:978:3: ( rule__SyntaxExpression__Group_1__0 )
                    // InternalSM2.g:978:4: rule__SyntaxExpression__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__Group_1__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSyntaxExpressionAccess().getGroup_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Alternatives"


    // $ANTLR start "rule__Comment__Alternatives"
    // InternalSM2.g:986:1: rule__Comment__Alternatives : ( ( ruleShortComment ) | ( ruleLongComment ) );
    public final void rule__Comment__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:990:1: ( ( ruleShortComment ) | ( ruleLongComment ) )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==71) ) {
                alt12=1;
            }
            else if ( (LA12_0==72) ) {
                alt12=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // InternalSM2.g:991:2: ( ruleShortComment )
                    {
                    // InternalSM2.g:991:2: ( ruleShortComment )
                    // InternalSM2.g:992:3: ruleShortComment
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleShortComment();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:997:2: ( ruleLongComment )
                    {
                    // InternalSM2.g:997:2: ( ruleLongComment )
                    // InternalSM2.g:998:3: ruleLongComment
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleLongComment();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Comment__Alternatives"


    // $ANTLR start "rule__LongComment__ExpressionAlternatives_1_0"
    // InternalSM2.g:1007:1: rule__LongComment__ExpressionAlternatives_1_0 : ( ( RULE_STRING ) | ( RULE_PARAMSLONGCOMENT ) | ( RULE_DEVLONGCOMENT ) | ( RULE_RETURNSLONGCOMENT ) | ( RULE_TITLELONGCOMENT ) | ( RULE_NOTICELONGCOMENT ) );
    public final void rule__LongComment__ExpressionAlternatives_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1011:1: ( ( RULE_STRING ) | ( RULE_PARAMSLONGCOMENT ) | ( RULE_DEVLONGCOMENT ) | ( RULE_RETURNSLONGCOMENT ) | ( RULE_TITLELONGCOMENT ) | ( RULE_NOTICELONGCOMENT ) )
            int alt13=6;
            switch ( input.LA(1) ) {
            case RULE_STRING:
                {
                alt13=1;
                }
                break;
            case RULE_PARAMSLONGCOMENT:
                {
                alt13=2;
                }
                break;
            case RULE_DEVLONGCOMENT:
                {
                alt13=3;
                }
                break;
            case RULE_RETURNSLONGCOMENT:
                {
                alt13=4;
                }
                break;
            case RULE_TITLELONGCOMENT:
                {
                alt13=5;
                }
                break;
            case RULE_NOTICELONGCOMENT:
                {
                alt13=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }

            switch (alt13) {
                case 1 :
                    // InternalSM2.g:1012:2: ( RULE_STRING )
                    {
                    // InternalSM2.g:1012:2: ( RULE_STRING )
                    // InternalSM2.g:1013:3: RULE_STRING
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLongCommentAccess().getExpressionSTRINGTerminalRuleCall_1_0_0()); 
                    }
                    match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLongCommentAccess().getExpressionSTRINGTerminalRuleCall_1_0_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1018:2: ( RULE_PARAMSLONGCOMENT )
                    {
                    // InternalSM2.g:1018:2: ( RULE_PARAMSLONGCOMENT )
                    // InternalSM2.g:1019:3: RULE_PARAMSLONGCOMENT
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLongCommentAccess().getExpressionPARAMSLONGCOMENTTerminalRuleCall_1_0_1()); 
                    }
                    match(input,RULE_PARAMSLONGCOMENT,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLongCommentAccess().getExpressionPARAMSLONGCOMENTTerminalRuleCall_1_0_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1024:2: ( RULE_DEVLONGCOMENT )
                    {
                    // InternalSM2.g:1024:2: ( RULE_DEVLONGCOMENT )
                    // InternalSM2.g:1025:3: RULE_DEVLONGCOMENT
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLongCommentAccess().getExpressionDEVLONGCOMENTTerminalRuleCall_1_0_2()); 
                    }
                    match(input,RULE_DEVLONGCOMENT,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLongCommentAccess().getExpressionDEVLONGCOMENTTerminalRuleCall_1_0_2()); 
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1030:2: ( RULE_RETURNSLONGCOMENT )
                    {
                    // InternalSM2.g:1030:2: ( RULE_RETURNSLONGCOMENT )
                    // InternalSM2.g:1031:3: RULE_RETURNSLONGCOMENT
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLongCommentAccess().getExpressionRETURNSLONGCOMENTTerminalRuleCall_1_0_3()); 
                    }
                    match(input,RULE_RETURNSLONGCOMENT,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLongCommentAccess().getExpressionRETURNSLONGCOMENTTerminalRuleCall_1_0_3()); 
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1036:2: ( RULE_TITLELONGCOMENT )
                    {
                    // InternalSM2.g:1036:2: ( RULE_TITLELONGCOMENT )
                    // InternalSM2.g:1037:3: RULE_TITLELONGCOMENT
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLongCommentAccess().getExpressionTITLELONGCOMENTTerminalRuleCall_1_0_4()); 
                    }
                    match(input,RULE_TITLELONGCOMENT,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLongCommentAccess().getExpressionTITLELONGCOMENTTerminalRuleCall_1_0_4()); 
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1042:2: ( RULE_NOTICELONGCOMENT )
                    {
                    // InternalSM2.g:1042:2: ( RULE_NOTICELONGCOMENT )
                    // InternalSM2.g:1043:3: RULE_NOTICELONGCOMENT
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLongCommentAccess().getExpressionNOTICELONGCOMENTTerminalRuleCall_1_0_5()); 
                    }
                    match(input,RULE_NOTICELONGCOMENT,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLongCommentAccess().getExpressionNOTICELONGCOMENTTerminalRuleCall_1_0_5()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__ExpressionAlternatives_1_0"


    // $ANTLR start "rule__SingularType__Alternatives"
    // InternalSM2.g:1052:1: rule__SingularType__Alternatives : ( ( ( 'int' ) ) | ( ( 'uint' ) ) | ( ( 'uint8' ) ) | ( ( 'uint256' ) ) | ( ( 'string' ) ) | ( ( 'address' ) ) | ( ( 'address payable' ) ) | ( ( 'double' ) ) | ( ( 'bool' ) ) );
    public final void rule__SingularType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1056:1: ( ( ( 'int' ) ) | ( ( 'uint' ) ) | ( ( 'uint8' ) ) | ( ( 'uint256' ) ) | ( ( 'string' ) ) | ( ( 'address' ) ) | ( ( 'address payable' ) ) | ( ( 'double' ) ) | ( ( 'bool' ) ) )
            int alt14=9;
            switch ( input.LA(1) ) {
            case 30:
                {
                alt14=1;
                }
                break;
            case 31:
                {
                alt14=2;
                }
                break;
            case 32:
                {
                alt14=3;
                }
                break;
            case 33:
                {
                alt14=4;
                }
                break;
            case 34:
                {
                alt14=5;
                }
                break;
            case 35:
                {
                alt14=6;
                }
                break;
            case 36:
                {
                alt14=7;
                }
                break;
            case 37:
                {
                alt14=8;
                }
                break;
            case 38:
                {
                alt14=9;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }

            switch (alt14) {
                case 1 :
                    // InternalSM2.g:1057:2: ( ( 'int' ) )
                    {
                    // InternalSM2.g:1057:2: ( ( 'int' ) )
                    // InternalSM2.g:1058:3: ( 'int' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0()); 
                    }
                    // InternalSM2.g:1059:3: ( 'int' )
                    // InternalSM2.g:1059:4: 'int'
                    {
                    match(input,30,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1063:2: ( ( 'uint' ) )
                    {
                    // InternalSM2.g:1063:2: ( ( 'uint' ) )
                    // InternalSM2.g:1064:3: ( 'uint' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1()); 
                    }
                    // InternalSM2.g:1065:3: ( 'uint' )
                    // InternalSM2.g:1065:4: 'uint'
                    {
                    match(input,31,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1069:2: ( ( 'uint8' ) )
                    {
                    // InternalSM2.g:1069:2: ( ( 'uint8' ) )
                    // InternalSM2.g:1070:3: ( 'uint8' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2()); 
                    }
                    // InternalSM2.g:1071:3: ( 'uint8' )
                    // InternalSM2.g:1071:4: 'uint8'
                    {
                    match(input,32,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2()); 
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1075:2: ( ( 'uint256' ) )
                    {
                    // InternalSM2.g:1075:2: ( ( 'uint256' ) )
                    // InternalSM2.g:1076:3: ( 'uint256' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3()); 
                    }
                    // InternalSM2.g:1077:3: ( 'uint256' )
                    // InternalSM2.g:1077:4: 'uint256'
                    {
                    match(input,33,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3()); 
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1081:2: ( ( 'string' ) )
                    {
                    // InternalSM2.g:1081:2: ( ( 'string' ) )
                    // InternalSM2.g:1082:3: ( 'string' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4()); 
                    }
                    // InternalSM2.g:1083:3: ( 'string' )
                    // InternalSM2.g:1083:4: 'string'
                    {
                    match(input,34,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4()); 
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1087:2: ( ( 'address' ) )
                    {
                    // InternalSM2.g:1087:2: ( ( 'address' ) )
                    // InternalSM2.g:1088:3: ( 'address' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5()); 
                    }
                    // InternalSM2.g:1089:3: ( 'address' )
                    // InternalSM2.g:1089:4: 'address'
                    {
                    match(input,35,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5()); 
                    }

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:1093:2: ( ( 'address payable' ) )
                    {
                    // InternalSM2.g:1093:2: ( ( 'address payable' ) )
                    // InternalSM2.g:1094:3: ( 'address payable' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6()); 
                    }
                    // InternalSM2.g:1095:3: ( 'address payable' )
                    // InternalSM2.g:1095:4: 'address payable'
                    {
                    match(input,36,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6()); 
                    }

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:1099:2: ( ( 'double' ) )
                    {
                    // InternalSM2.g:1099:2: ( ( 'double' ) )
                    // InternalSM2.g:1100:3: ( 'double' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7()); 
                    }
                    // InternalSM2.g:1101:3: ( 'double' )
                    // InternalSM2.g:1101:4: 'double'
                    {
                    match(input,37,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7()); 
                    }

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:1105:2: ( ( 'bool' ) )
                    {
                    // InternalSM2.g:1105:2: ( ( 'bool' ) )
                    // InternalSM2.g:1106:3: ( 'bool' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8()); 
                    }
                    // InternalSM2.g:1107:3: ( 'bool' )
                    // InternalSM2.g:1107:4: 'bool'
                    {
                    match(input,38,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingularType__Alternatives"


    // $ANTLR start "rule__Visibility__Alternatives"
    // InternalSM2.g:1115:1: rule__Visibility__Alternatives : ( ( ( 'public' ) ) | ( ( 'private' ) ) | ( ( 'internal' ) ) | ( ( 'external' ) ) );
    public final void rule__Visibility__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1119:1: ( ( ( 'public' ) ) | ( ( 'private' ) ) | ( ( 'internal' ) ) | ( ( 'external' ) ) )
            int alt15=4;
            switch ( input.LA(1) ) {
            case 39:
                {
                alt15=1;
                }
                break;
            case 40:
                {
                alt15=2;
                }
                break;
            case 41:
                {
                alt15=3;
                }
                break;
            case 42:
                {
                alt15=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }

            switch (alt15) {
                case 1 :
                    // InternalSM2.g:1120:2: ( ( 'public' ) )
                    {
                    // InternalSM2.g:1120:2: ( ( 'public' ) )
                    // InternalSM2.g:1121:3: ( 'public' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0()); 
                    }
                    // InternalSM2.g:1122:3: ( 'public' )
                    // InternalSM2.g:1122:4: 'public'
                    {
                    match(input,39,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1126:2: ( ( 'private' ) )
                    {
                    // InternalSM2.g:1126:2: ( ( 'private' ) )
                    // InternalSM2.g:1127:3: ( 'private' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1()); 
                    }
                    // InternalSM2.g:1128:3: ( 'private' )
                    // InternalSM2.g:1128:4: 'private'
                    {
                    match(input,40,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1132:2: ( ( 'internal' ) )
                    {
                    // InternalSM2.g:1132:2: ( ( 'internal' ) )
                    // InternalSM2.g:1133:3: ( 'internal' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2()); 
                    }
                    // InternalSM2.g:1134:3: ( 'internal' )
                    // InternalSM2.g:1134:4: 'internal'
                    {
                    match(input,41,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2()); 
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1138:2: ( ( 'external' ) )
                    {
                    // InternalSM2.g:1138:2: ( ( 'external' ) )
                    // InternalSM2.g:1139:3: ( 'external' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3()); 
                    }
                    // InternalSM2.g:1140:3: ( 'external' )
                    // InternalSM2.g:1140:4: 'external'
                    {
                    match(input,42,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Visibility__Alternatives"


    // $ANTLR start "rule__Coin__Alternatives"
    // InternalSM2.g:1148:1: rule__Coin__Alternatives : ( ( ( 'ether' ) ) | ( ( 'wei' ) ) | ( ( 'gwei' ) ) | ( ( 'pwei' ) ) | ( ( 'finney' ) ) | ( ( 'szabo' ) ) );
    public final void rule__Coin__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1152:1: ( ( ( 'ether' ) ) | ( ( 'wei' ) ) | ( ( 'gwei' ) ) | ( ( 'pwei' ) ) | ( ( 'finney' ) ) | ( ( 'szabo' ) ) )
            int alt16=6;
            switch ( input.LA(1) ) {
            case 43:
                {
                alt16=1;
                }
                break;
            case 44:
                {
                alt16=2;
                }
                break;
            case 45:
                {
                alt16=3;
                }
                break;
            case 46:
                {
                alt16=4;
                }
                break;
            case 47:
                {
                alt16=5;
                }
                break;
            case 48:
                {
                alt16=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }

            switch (alt16) {
                case 1 :
                    // InternalSM2.g:1153:2: ( ( 'ether' ) )
                    {
                    // InternalSM2.g:1153:2: ( ( 'ether' ) )
                    // InternalSM2.g:1154:3: ( 'ether' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0()); 
                    }
                    // InternalSM2.g:1155:3: ( 'ether' )
                    // InternalSM2.g:1155:4: 'ether'
                    {
                    match(input,43,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1159:2: ( ( 'wei' ) )
                    {
                    // InternalSM2.g:1159:2: ( ( 'wei' ) )
                    // InternalSM2.g:1160:3: ( 'wei' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1()); 
                    }
                    // InternalSM2.g:1161:3: ( 'wei' )
                    // InternalSM2.g:1161:4: 'wei'
                    {
                    match(input,44,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1165:2: ( ( 'gwei' ) )
                    {
                    // InternalSM2.g:1165:2: ( ( 'gwei' ) )
                    // InternalSM2.g:1166:3: ( 'gwei' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2()); 
                    }
                    // InternalSM2.g:1167:3: ( 'gwei' )
                    // InternalSM2.g:1167:4: 'gwei'
                    {
                    match(input,45,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2()); 
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1171:2: ( ( 'pwei' ) )
                    {
                    // InternalSM2.g:1171:2: ( ( 'pwei' ) )
                    // InternalSM2.g:1172:3: ( 'pwei' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3()); 
                    }
                    // InternalSM2.g:1173:3: ( 'pwei' )
                    // InternalSM2.g:1173:4: 'pwei'
                    {
                    match(input,46,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3()); 
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1177:2: ( ( 'finney' ) )
                    {
                    // InternalSM2.g:1177:2: ( ( 'finney' ) )
                    // InternalSM2.g:1178:3: ( 'finney' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4()); 
                    }
                    // InternalSM2.g:1179:3: ( 'finney' )
                    // InternalSM2.g:1179:4: 'finney'
                    {
                    match(input,47,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4()); 
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1183:2: ( ( 'szabo' ) )
                    {
                    // InternalSM2.g:1183:2: ( ( 'szabo' ) )
                    // InternalSM2.g:1184:3: ( 'szabo' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5()); 
                    }
                    // InternalSM2.g:1185:3: ( 'szabo' )
                    // InternalSM2.g:1185:4: 'szabo'
                    {
                    match(input,48,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coin__Alternatives"


    // $ANTLR start "rule__ComparationOperator__Alternatives"
    // InternalSM2.g:1193:1: rule__ComparationOperator__Alternatives : ( ( ( '>' ) ) | ( ( '<' ) ) | ( ( '>=' ) ) | ( ( '<=' ) ) | ( ( '==' ) ) | ( ( '!=' ) ) );
    public final void rule__ComparationOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1197:1: ( ( ( '>' ) ) | ( ( '<' ) ) | ( ( '>=' ) ) | ( ( '<=' ) ) | ( ( '==' ) ) | ( ( '!=' ) ) )
            int alt17=6;
            switch ( input.LA(1) ) {
            case 26:
                {
                alt17=1;
                }
                break;
            case 28:
                {
                alt17=2;
                }
                break;
            case 27:
                {
                alt17=3;
                }
                break;
            case 29:
                {
                alt17=4;
                }
                break;
            case 49:
                {
                alt17=5;
                }
                break;
            case 50:
                {
                alt17=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // InternalSM2.g:1198:2: ( ( '>' ) )
                    {
                    // InternalSM2.g:1198:2: ( ( '>' ) )
                    // InternalSM2.g:1199:3: ( '>' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0()); 
                    }
                    // InternalSM2.g:1200:3: ( '>' )
                    // InternalSM2.g:1200:4: '>'
                    {
                    match(input,26,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1204:2: ( ( '<' ) )
                    {
                    // InternalSM2.g:1204:2: ( ( '<' ) )
                    // InternalSM2.g:1205:3: ( '<' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1()); 
                    }
                    // InternalSM2.g:1206:3: ( '<' )
                    // InternalSM2.g:1206:4: '<'
                    {
                    match(input,28,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1210:2: ( ( '>=' ) )
                    {
                    // InternalSM2.g:1210:2: ( ( '>=' ) )
                    // InternalSM2.g:1211:3: ( '>=' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2()); 
                    }
                    // InternalSM2.g:1212:3: ( '>=' )
                    // InternalSM2.g:1212:4: '>='
                    {
                    match(input,27,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2()); 
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1216:2: ( ( '<=' ) )
                    {
                    // InternalSM2.g:1216:2: ( ( '<=' ) )
                    // InternalSM2.g:1217:3: ( '<=' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3()); 
                    }
                    // InternalSM2.g:1218:3: ( '<=' )
                    // InternalSM2.g:1218:4: '<='
                    {
                    match(input,29,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3()); 
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1222:2: ( ( '==' ) )
                    {
                    // InternalSM2.g:1222:2: ( ( '==' ) )
                    // InternalSM2.g:1223:3: ( '==' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4()); 
                    }
                    // InternalSM2.g:1224:3: ( '==' )
                    // InternalSM2.g:1224:4: '=='
                    {
                    match(input,49,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4()); 
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1228:2: ( ( '!=' ) )
                    {
                    // InternalSM2.g:1228:2: ( ( '!=' ) )
                    // InternalSM2.g:1229:3: ( '!=' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5()); 
                    }
                    // InternalSM2.g:1230:3: ( '!=' )
                    // InternalSM2.g:1230:4: '!='
                    {
                    match(input,50,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparationOperator__Alternatives"


    // $ANTLR start "rule__LogicalPairOperator__Alternatives"
    // InternalSM2.g:1238:1: rule__LogicalPairOperator__Alternatives : ( ( ( '&&' ) ) | ( ( '||' ) ) );
    public final void rule__LogicalPairOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1242:1: ( ( ( '&&' ) ) | ( ( '||' ) ) )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==51) ) {
                alt18=1;
            }
            else if ( (LA18_0==52) ) {
                alt18=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    // InternalSM2.g:1243:2: ( ( '&&' ) )
                    {
                    // InternalSM2.g:1243:2: ( ( '&&' ) )
                    // InternalSM2.g:1244:3: ( '&&' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0()); 
                    }
                    // InternalSM2.g:1245:3: ( '&&' )
                    // InternalSM2.g:1245:4: '&&'
                    {
                    match(input,51,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1249:2: ( ( '||' ) )
                    {
                    // InternalSM2.g:1249:2: ( ( '||' ) )
                    // InternalSM2.g:1250:3: ( '||' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1()); 
                    }
                    // InternalSM2.g:1251:3: ( '||' )
                    // InternalSM2.g:1251:4: '||'
                    {
                    match(input,52,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicalPairOperator__Alternatives"


    // $ANTLR start "rule__ArithmeticalOperator__Alternatives"
    // InternalSM2.g:1259:1: rule__ArithmeticalOperator__Alternatives : ( ( ( '+' ) ) | ( ( '-' ) ) | ( ( '*' ) ) | ( ( '/' ) ) );
    public final void rule__ArithmeticalOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1263:1: ( ( ( '+' ) ) | ( ( '-' ) ) | ( ( '*' ) ) | ( ( '/' ) ) )
            int alt19=4;
            switch ( input.LA(1) ) {
            case 53:
                {
                alt19=1;
                }
                break;
            case 54:
                {
                alt19=2;
                }
                break;
            case 55:
                {
                alt19=3;
                }
                break;
            case 56:
                {
                alt19=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }

            switch (alt19) {
                case 1 :
                    // InternalSM2.g:1264:2: ( ( '+' ) )
                    {
                    // InternalSM2.g:1264:2: ( ( '+' ) )
                    // InternalSM2.g:1265:3: ( '+' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0()); 
                    }
                    // InternalSM2.g:1266:3: ( '+' )
                    // InternalSM2.g:1266:4: '+'
                    {
                    match(input,53,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1270:2: ( ( '-' ) )
                    {
                    // InternalSM2.g:1270:2: ( ( '-' ) )
                    // InternalSM2.g:1271:3: ( '-' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1()); 
                    }
                    // InternalSM2.g:1272:3: ( '-' )
                    // InternalSM2.g:1272:4: '-'
                    {
                    match(input,54,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1276:2: ( ( '*' ) )
                    {
                    // InternalSM2.g:1276:2: ( ( '*' ) )
                    // InternalSM2.g:1277:3: ( '*' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2()); 
                    }
                    // InternalSM2.g:1278:3: ( '*' )
                    // InternalSM2.g:1278:4: '*'
                    {
                    match(input,55,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2()); 
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1282:2: ( ( '/' ) )
                    {
                    // InternalSM2.g:1282:2: ( ( '/' ) )
                    // InternalSM2.g:1283:3: ( '/' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3()); 
                    }
                    // InternalSM2.g:1284:3: ( '/' )
                    // InternalSM2.g:1284:4: '/'
                    {
                    match(input,56,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmeticalOperator__Alternatives"


    // $ANTLR start "rule__SmartContract__Group__0"
    // InternalSM2.g:1292:1: rule__SmartContract__Group__0 : rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1 ;
    public final void rule__SmartContract__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1296:1: ( rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1 )
            // InternalSM2.g:1297:2: rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__SmartContract__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__0"


    // $ANTLR start "rule__SmartContract__Group__0__Impl"
    // InternalSM2.g:1304:1: rule__SmartContract__Group__0__Impl : ( ( rule__SmartContract__CompilerAssignment_0 ) ) ;
    public final void rule__SmartContract__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1308:1: ( ( ( rule__SmartContract__CompilerAssignment_0 ) ) )
            // InternalSM2.g:1309:1: ( ( rule__SmartContract__CompilerAssignment_0 ) )
            {
            // InternalSM2.g:1309:1: ( ( rule__SmartContract__CompilerAssignment_0 ) )
            // InternalSM2.g:1310:2: ( rule__SmartContract__CompilerAssignment_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getCompilerAssignment_0()); 
            }
            // InternalSM2.g:1311:2: ( rule__SmartContract__CompilerAssignment_0 )
            // InternalSM2.g:1311:3: rule__SmartContract__CompilerAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__CompilerAssignment_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getCompilerAssignment_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__0__Impl"


    // $ANTLR start "rule__SmartContract__Group__1"
    // InternalSM2.g:1319:1: rule__SmartContract__Group__1 : rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2 ;
    public final void rule__SmartContract__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1323:1: ( rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2 )
            // InternalSM2.g:1324:2: rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__SmartContract__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__1"


    // $ANTLR start "rule__SmartContract__Group__1__Impl"
    // InternalSM2.g:1331:1: rule__SmartContract__Group__1__Impl : ( 'solidity' ) ;
    public final void rule__SmartContract__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1335:1: ( ( 'solidity' ) )
            // InternalSM2.g:1336:1: ( 'solidity' )
            {
            // InternalSM2.g:1336:1: ( 'solidity' )
            // InternalSM2.g:1337:2: 'solidity'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getSolidityKeyword_1()); 
            }
            match(input,57,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getSolidityKeyword_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__1__Impl"


    // $ANTLR start "rule__SmartContract__Group__2"
    // InternalSM2.g:1346:1: rule__SmartContract__Group__2 : rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3 ;
    public final void rule__SmartContract__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1350:1: ( rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3 )
            // InternalSM2.g:1351:2: rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__SmartContract__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__2"


    // $ANTLR start "rule__SmartContract__Group__2__Impl"
    // InternalSM2.g:1358:1: rule__SmartContract__Group__2__Impl : ( ( rule__SmartContract__VersionCompilerAssignment_2 ) ) ;
    public final void rule__SmartContract__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1362:1: ( ( ( rule__SmartContract__VersionCompilerAssignment_2 ) ) )
            // InternalSM2.g:1363:1: ( ( rule__SmartContract__VersionCompilerAssignment_2 ) )
            {
            // InternalSM2.g:1363:1: ( ( rule__SmartContract__VersionCompilerAssignment_2 ) )
            // InternalSM2.g:1364:2: ( rule__SmartContract__VersionCompilerAssignment_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getVersionCompilerAssignment_2()); 
            }
            // InternalSM2.g:1365:2: ( rule__SmartContract__VersionCompilerAssignment_2 )
            // InternalSM2.g:1365:3: rule__SmartContract__VersionCompilerAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__VersionCompilerAssignment_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getVersionCompilerAssignment_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__2__Impl"


    // $ANTLR start "rule__SmartContract__Group__3"
    // InternalSM2.g:1373:1: rule__SmartContract__Group__3 : rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4 ;
    public final void rule__SmartContract__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1377:1: ( rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4 )
            // InternalSM2.g:1378:2: rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__3"


    // $ANTLR start "rule__SmartContract__Group__3__Impl"
    // InternalSM2.g:1385:1: rule__SmartContract__Group__3__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__SmartContract__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1389:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:1390:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:1390:1: ( RULE_SEMICOLON )
            // InternalSM2.g:1391:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__3__Impl"


    // $ANTLR start "rule__SmartContract__Group__4"
    // InternalSM2.g:1400:1: rule__SmartContract__Group__4 : rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5 ;
    public final void rule__SmartContract__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1404:1: ( rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5 )
            // InternalSM2.g:1405:2: rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__4"


    // $ANTLR start "rule__SmartContract__Group__4__Impl"
    // InternalSM2.g:1412:1: rule__SmartContract__Group__4__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__SmartContract__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1416:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:1417:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:1417:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:1418:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4()); 
            }
            // InternalSM2.g:1419:2: ( RULE_EOLINE )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==RULE_EOLINE) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalSM2.g:1419:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__4__Impl"


    // $ANTLR start "rule__SmartContract__Group__5"
    // InternalSM2.g:1427:1: rule__SmartContract__Group__5 : rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6 ;
    public final void rule__SmartContract__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1431:1: ( rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6 )
            // InternalSM2.g:1432:2: rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__5"


    // $ANTLR start "rule__SmartContract__Group__5__Impl"
    // InternalSM2.g:1439:1: rule__SmartContract__Group__5__Impl : ( ( rule__SmartContract__ImportsAssignment_5 )* ) ;
    public final void rule__SmartContract__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1443:1: ( ( ( rule__SmartContract__ImportsAssignment_5 )* ) )
            // InternalSM2.g:1444:1: ( ( rule__SmartContract__ImportsAssignment_5 )* )
            {
            // InternalSM2.g:1444:1: ( ( rule__SmartContract__ImportsAssignment_5 )* )
            // InternalSM2.g:1445:2: ( rule__SmartContract__ImportsAssignment_5 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getImportsAssignment_5()); 
            }
            // InternalSM2.g:1446:2: ( rule__SmartContract__ImportsAssignment_5 )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==59) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalSM2.g:1446:3: rule__SmartContract__ImportsAssignment_5
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__SmartContract__ImportsAssignment_5();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getImportsAssignment_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__5__Impl"


    // $ANTLR start "rule__SmartContract__Group__6"
    // InternalSM2.g:1454:1: rule__SmartContract__Group__6 : rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7 ;
    public final void rule__SmartContract__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1458:1: ( rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7 )
            // InternalSM2.g:1459:2: rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7
            {
            pushFollow(FOLLOW_8);
            rule__SmartContract__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__6"


    // $ANTLR start "rule__SmartContract__Group__6__Impl"
    // InternalSM2.g:1466:1: rule__SmartContract__Group__6__Impl : ( ( rule__SmartContract__ContractAssignment_6 ) ) ;
    public final void rule__SmartContract__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1470:1: ( ( ( rule__SmartContract__ContractAssignment_6 ) ) )
            // InternalSM2.g:1471:1: ( ( rule__SmartContract__ContractAssignment_6 ) )
            {
            // InternalSM2.g:1471:1: ( ( rule__SmartContract__ContractAssignment_6 ) )
            // InternalSM2.g:1472:2: ( rule__SmartContract__ContractAssignment_6 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getContractAssignment_6()); 
            }
            // InternalSM2.g:1473:2: ( rule__SmartContract__ContractAssignment_6 )
            // InternalSM2.g:1473:3: rule__SmartContract__ContractAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__ContractAssignment_6();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getContractAssignment_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__6__Impl"


    // $ANTLR start "rule__SmartContract__Group__7"
    // InternalSM2.g:1481:1: rule__SmartContract__Group__7 : rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8 ;
    public final void rule__SmartContract__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1485:1: ( rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8 )
            // InternalSM2.g:1486:2: rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8
            {
            pushFollow(FOLLOW_9);
            rule__SmartContract__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__8();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__7"


    // $ANTLR start "rule__SmartContract__Group__7__Impl"
    // InternalSM2.g:1493:1: rule__SmartContract__Group__7__Impl : ( ( rule__SmartContract__NameContractAssignment_7 ) ) ;
    public final void rule__SmartContract__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1497:1: ( ( ( rule__SmartContract__NameContractAssignment_7 ) ) )
            // InternalSM2.g:1498:1: ( ( rule__SmartContract__NameContractAssignment_7 ) )
            {
            // InternalSM2.g:1498:1: ( ( rule__SmartContract__NameContractAssignment_7 ) )
            // InternalSM2.g:1499:2: ( rule__SmartContract__NameContractAssignment_7 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getNameContractAssignment_7()); 
            }
            // InternalSM2.g:1500:2: ( rule__SmartContract__NameContractAssignment_7 )
            // InternalSM2.g:1500:3: rule__SmartContract__NameContractAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__NameContractAssignment_7();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getNameContractAssignment_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__7__Impl"


    // $ANTLR start "rule__SmartContract__Group__8"
    // InternalSM2.g:1508:1: rule__SmartContract__Group__8 : rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9 ;
    public final void rule__SmartContract__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1512:1: ( rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9 )
            // InternalSM2.g:1513:2: rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9
            {
            pushFollow(FOLLOW_9);
            rule__SmartContract__Group__8__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__9();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__8"


    // $ANTLR start "rule__SmartContract__Group__8__Impl"
    // InternalSM2.g:1520:1: rule__SmartContract__Group__8__Impl : ( ( rule__SmartContract__Group_8__0 )? ) ;
    public final void rule__SmartContract__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1524:1: ( ( ( rule__SmartContract__Group_8__0 )? ) )
            // InternalSM2.g:1525:1: ( ( rule__SmartContract__Group_8__0 )? )
            {
            // InternalSM2.g:1525:1: ( ( rule__SmartContract__Group_8__0 )? )
            // InternalSM2.g:1526:2: ( rule__SmartContract__Group_8__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getGroup_8()); 
            }
            // InternalSM2.g:1527:2: ( rule__SmartContract__Group_8__0 )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==58) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalSM2.g:1527:3: rule__SmartContract__Group_8__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SmartContract__Group_8__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getGroup_8()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__8__Impl"


    // $ANTLR start "rule__SmartContract__Group__9"
    // InternalSM2.g:1535:1: rule__SmartContract__Group__9 : rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10 ;
    public final void rule__SmartContract__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1539:1: ( rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10 )
            // InternalSM2.g:1540:2: rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__9__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__10();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__9"


    // $ANTLR start "rule__SmartContract__Group__9__Impl"
    // InternalSM2.g:1547:1: rule__SmartContract__Group__9__Impl : ( RULE_OPENKEY ) ;
    public final void rule__SmartContract__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1551:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:1552:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:1552:1: ( RULE_OPENKEY )
            // InternalSM2.g:1553:2: RULE_OPENKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getOPENKEYTerminalRuleCall_9()); 
            }
            match(input,RULE_OPENKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getOPENKEYTerminalRuleCall_9()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__9__Impl"


    // $ANTLR start "rule__SmartContract__Group__10"
    // InternalSM2.g:1562:1: rule__SmartContract__Group__10 : rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11 ;
    public final void rule__SmartContract__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1566:1: ( rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11 )
            // InternalSM2.g:1567:2: rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__10__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__11();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__10"


    // $ANTLR start "rule__SmartContract__Group__10__Impl"
    // InternalSM2.g:1574:1: rule__SmartContract__Group__10__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__SmartContract__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1578:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:1579:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:1579:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:1580:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_10()); 
            }
            // InternalSM2.g:1581:2: ( RULE_EOLINE )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==RULE_EOLINE) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalSM2.g:1581:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_10()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__10__Impl"


    // $ANTLR start "rule__SmartContract__Group__11"
    // InternalSM2.g:1589:1: rule__SmartContract__Group__11 : rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12 ;
    public final void rule__SmartContract__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1593:1: ( rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12 )
            // InternalSM2.g:1594:2: rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__11__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__12();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__11"


    // $ANTLR start "rule__SmartContract__Group__11__Impl"
    // InternalSM2.g:1601:1: rule__SmartContract__Group__11__Impl : ( ( rule__SmartContract__AttributesAssignment_11 )* ) ;
    public final void rule__SmartContract__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1605:1: ( ( ( rule__SmartContract__AttributesAssignment_11 )* ) )
            // InternalSM2.g:1606:1: ( ( rule__SmartContract__AttributesAssignment_11 )* )
            {
            // InternalSM2.g:1606:1: ( ( rule__SmartContract__AttributesAssignment_11 )* )
            // InternalSM2.g:1607:2: ( rule__SmartContract__AttributesAssignment_11 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getAttributesAssignment_11()); 
            }
            // InternalSM2.g:1608:2: ( rule__SmartContract__AttributesAssignment_11 )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( (LA24_0==RULE_ID||(LA24_0>=30 && LA24_0<=38)||LA24_0==64||LA24_0==66||LA24_0==68) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalSM2.g:1608:3: rule__SmartContract__AttributesAssignment_11
            	    {
            	    pushFollow(FOLLOW_11);
            	    rule__SmartContract__AttributesAssignment_11();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getAttributesAssignment_11()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__11__Impl"


    // $ANTLR start "rule__SmartContract__Group__12"
    // InternalSM2.g:1616:1: rule__SmartContract__Group__12 : rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13 ;
    public final void rule__SmartContract__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1620:1: ( rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13 )
            // InternalSM2.g:1621:2: rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__12__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__13();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__12"


    // $ANTLR start "rule__SmartContract__Group__12__Impl"
    // InternalSM2.g:1628:1: rule__SmartContract__Group__12__Impl : ( ( rule__SmartContract__EventsAssignment_12 )* ) ;
    public final void rule__SmartContract__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1632:1: ( ( ( rule__SmartContract__EventsAssignment_12 )* ) )
            // InternalSM2.g:1633:1: ( ( rule__SmartContract__EventsAssignment_12 )* )
            {
            // InternalSM2.g:1633:1: ( ( rule__SmartContract__EventsAssignment_12 )* )
            // InternalSM2.g:1634:2: ( rule__SmartContract__EventsAssignment_12 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getEventsAssignment_12()); 
            }
            // InternalSM2.g:1635:2: ( rule__SmartContract__EventsAssignment_12 )*
            loop25:
            do {
                int alt25=2;
                int LA25_0 = input.LA(1);

                if ( (LA25_0==61) ) {
                    alt25=1;
                }


                switch (alt25) {
            	case 1 :
            	    // InternalSM2.g:1635:3: rule__SmartContract__EventsAssignment_12
            	    {
            	    pushFollow(FOLLOW_12);
            	    rule__SmartContract__EventsAssignment_12();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop25;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getEventsAssignment_12()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__12__Impl"


    // $ANTLR start "rule__SmartContract__Group__13"
    // InternalSM2.g:1643:1: rule__SmartContract__Group__13 : rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14 ;
    public final void rule__SmartContract__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1647:1: ( rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14 )
            // InternalSM2.g:1648:2: rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__13__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__14();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__13"


    // $ANTLR start "rule__SmartContract__Group__13__Impl"
    // InternalSM2.g:1655:1: rule__SmartContract__Group__13__Impl : ( ( rule__SmartContract__ModifierAssignment_13 )* ) ;
    public final void rule__SmartContract__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1659:1: ( ( ( rule__SmartContract__ModifierAssignment_13 )* ) )
            // InternalSM2.g:1660:1: ( ( rule__SmartContract__ModifierAssignment_13 )* )
            {
            // InternalSM2.g:1660:1: ( ( rule__SmartContract__ModifierAssignment_13 )* )
            // InternalSM2.g:1661:2: ( rule__SmartContract__ModifierAssignment_13 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getModifierAssignment_13()); 
            }
            // InternalSM2.g:1662:2: ( rule__SmartContract__ModifierAssignment_13 )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0==62) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalSM2.g:1662:3: rule__SmartContract__ModifierAssignment_13
            	    {
            	    pushFollow(FOLLOW_13);
            	    rule__SmartContract__ModifierAssignment_13();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getModifierAssignment_13()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__13__Impl"


    // $ANTLR start "rule__SmartContract__Group__14"
    // InternalSM2.g:1670:1: rule__SmartContract__Group__14 : rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15 ;
    public final void rule__SmartContract__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1674:1: ( rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15 )
            // InternalSM2.g:1675:2: rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__14__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__15();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__14"


    // $ANTLR start "rule__SmartContract__Group__14__Impl"
    // InternalSM2.g:1682:1: rule__SmartContract__Group__14__Impl : ( ( rule__SmartContract__ClausesAssignment_14 )* ) ;
    public final void rule__SmartContract__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1686:1: ( ( ( rule__SmartContract__ClausesAssignment_14 )* ) )
            // InternalSM2.g:1687:1: ( ( rule__SmartContract__ClausesAssignment_14 )* )
            {
            // InternalSM2.g:1687:1: ( ( rule__SmartContract__ClausesAssignment_14 )* )
            // InternalSM2.g:1688:2: ( rule__SmartContract__ClausesAssignment_14 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getClausesAssignment_14()); 
            }
            // InternalSM2.g:1689:2: ( rule__SmartContract__ClausesAssignment_14 )*
            loop27:
            do {
                int alt27=2;
                int LA27_0 = input.LA(1);

                if ( (LA27_0==70) ) {
                    alt27=1;
                }


                switch (alt27) {
            	case 1 :
            	    // InternalSM2.g:1689:3: rule__SmartContract__ClausesAssignment_14
            	    {
            	    pushFollow(FOLLOW_14);
            	    rule__SmartContract__ClausesAssignment_14();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop27;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getClausesAssignment_14()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__14__Impl"


    // $ANTLR start "rule__SmartContract__Group__15"
    // InternalSM2.g:1697:1: rule__SmartContract__Group__15 : rule__SmartContract__Group__15__Impl rule__SmartContract__Group__16 ;
    public final void rule__SmartContract__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1701:1: ( rule__SmartContract__Group__15__Impl rule__SmartContract__Group__16 )
            // InternalSM2.g:1702:2: rule__SmartContract__Group__15__Impl rule__SmartContract__Group__16
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__15__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__16();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__15"


    // $ANTLR start "rule__SmartContract__Group__15__Impl"
    // InternalSM2.g:1709:1: rule__SmartContract__Group__15__Impl : ( ( rule__SmartContract__CommentsAssignment_15 )* ) ;
    public final void rule__SmartContract__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1713:1: ( ( ( rule__SmartContract__CommentsAssignment_15 )* ) )
            // InternalSM2.g:1714:1: ( ( rule__SmartContract__CommentsAssignment_15 )* )
            {
            // InternalSM2.g:1714:1: ( ( rule__SmartContract__CommentsAssignment_15 )* )
            // InternalSM2.g:1715:2: ( rule__SmartContract__CommentsAssignment_15 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getCommentsAssignment_15()); 
            }
            // InternalSM2.g:1716:2: ( rule__SmartContract__CommentsAssignment_15 )*
            loop28:
            do {
                int alt28=2;
                int LA28_0 = input.LA(1);

                if ( ((LA28_0>=71 && LA28_0<=72)) ) {
                    alt28=1;
                }


                switch (alt28) {
            	case 1 :
            	    // InternalSM2.g:1716:3: rule__SmartContract__CommentsAssignment_15
            	    {
            	    pushFollow(FOLLOW_15);
            	    rule__SmartContract__CommentsAssignment_15();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop28;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getCommentsAssignment_15()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__15__Impl"


    // $ANTLR start "rule__SmartContract__Group__16"
    // InternalSM2.g:1724:1: rule__SmartContract__Group__16 : rule__SmartContract__Group__16__Impl ;
    public final void rule__SmartContract__Group__16() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1728:1: ( rule__SmartContract__Group__16__Impl )
            // InternalSM2.g:1729:2: rule__SmartContract__Group__16__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__16__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__16"


    // $ANTLR start "rule__SmartContract__Group__16__Impl"
    // InternalSM2.g:1735:1: rule__SmartContract__Group__16__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__SmartContract__Group__16__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1739:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:1740:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:1740:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:1741:2: RULE_CLOSEKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_16()); 
            }
            match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_16()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__16__Impl"


    // $ANTLR start "rule__SmartContract__Group_8__0"
    // InternalSM2.g:1751:1: rule__SmartContract__Group_8__0 : rule__SmartContract__Group_8__0__Impl rule__SmartContract__Group_8__1 ;
    public final void rule__SmartContract__Group_8__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1755:1: ( rule__SmartContract__Group_8__0__Impl rule__SmartContract__Group_8__1 )
            // InternalSM2.g:1756:2: rule__SmartContract__Group_8__0__Impl rule__SmartContract__Group_8__1
            {
            pushFollow(FOLLOW_8);
            rule__SmartContract__Group_8__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group_8__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__0"


    // $ANTLR start "rule__SmartContract__Group_8__0__Impl"
    // InternalSM2.g:1763:1: rule__SmartContract__Group_8__0__Impl : ( 'is' ) ;
    public final void rule__SmartContract__Group_8__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1767:1: ( ( 'is' ) )
            // InternalSM2.g:1768:1: ( 'is' )
            {
            // InternalSM2.g:1768:1: ( 'is' )
            // InternalSM2.g:1769:2: 'is'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getIsKeyword_8_0()); 
            }
            match(input,58,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getIsKeyword_8_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__0__Impl"


    // $ANTLR start "rule__SmartContract__Group_8__1"
    // InternalSM2.g:1778:1: rule__SmartContract__Group_8__1 : rule__SmartContract__Group_8__1__Impl ;
    public final void rule__SmartContract__Group_8__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1782:1: ( rule__SmartContract__Group_8__1__Impl )
            // InternalSM2.g:1783:2: rule__SmartContract__Group_8__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group_8__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__1"


    // $ANTLR start "rule__SmartContract__Group_8__1__Impl"
    // InternalSM2.g:1789:1: rule__SmartContract__Group_8__1__Impl : ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) ) ;
    public final void rule__SmartContract__Group_8__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1793:1: ( ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) ) )
            // InternalSM2.g:1794:1: ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) )
            {
            // InternalSM2.g:1794:1: ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) )
            // InternalSM2.g:1795:2: ( rule__SmartContract__NameContractFatherAssignment_8_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getNameContractFatherAssignment_8_1()); 
            }
            // InternalSM2.g:1796:2: ( rule__SmartContract__NameContractFatherAssignment_8_1 )
            // InternalSM2.g:1796:3: rule__SmartContract__NameContractFatherAssignment_8_1
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__NameContractFatherAssignment_8_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getNameContractFatherAssignment_8_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__1__Impl"


    // $ANTLR start "rule__Version__Group_0__0"
    // InternalSM2.g:1805:1: rule__Version__Group_0__0 : rule__Version__Group_0__0__Impl rule__Version__Group_0__1 ;
    public final void rule__Version__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1809:1: ( rule__Version__Group_0__0__Impl rule__Version__Group_0__1 )
            // InternalSM2.g:1810:2: rule__Version__Group_0__0__Impl rule__Version__Group_0__1
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_0__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_0__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__0"


    // $ANTLR start "rule__Version__Group_0__0__Impl"
    // InternalSM2.g:1817:1: rule__Version__Group_0__0__Impl : ( ( rule__Version__SymbolAssignment_0_0 ) ) ;
    public final void rule__Version__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1821:1: ( ( ( rule__Version__SymbolAssignment_0_0 ) ) )
            // InternalSM2.g:1822:1: ( ( rule__Version__SymbolAssignment_0_0 ) )
            {
            // InternalSM2.g:1822:1: ( ( rule__Version__SymbolAssignment_0_0 ) )
            // InternalSM2.g:1823:2: ( rule__Version__SymbolAssignment_0_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getSymbolAssignment_0_0()); 
            }
            // InternalSM2.g:1824:2: ( rule__Version__SymbolAssignment_0_0 )
            // InternalSM2.g:1824:3: rule__Version__SymbolAssignment_0_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAssignment_0_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getSymbolAssignment_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__0__Impl"


    // $ANTLR start "rule__Version__Group_0__1"
    // InternalSM2.g:1832:1: rule__Version__Group_0__1 : rule__Version__Group_0__1__Impl rule__Version__Group_0__2 ;
    public final void rule__Version__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1836:1: ( rule__Version__Group_0__1__Impl rule__Version__Group_0__2 )
            // InternalSM2.g:1837:2: rule__Version__Group_0__1__Impl rule__Version__Group_0__2
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_0__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_0__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__1"


    // $ANTLR start "rule__Version__Group_0__1__Impl"
    // InternalSM2.g:1844:1: rule__Version__Group_0__1__Impl : ( ( rule__Version__NumberVersionAssignment_0_1 ) ) ;
    public final void rule__Version__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1848:1: ( ( ( rule__Version__NumberVersionAssignment_0_1 ) ) )
            // InternalSM2.g:1849:1: ( ( rule__Version__NumberVersionAssignment_0_1 ) )
            {
            // InternalSM2.g:1849:1: ( ( rule__Version__NumberVersionAssignment_0_1 ) )
            // InternalSM2.g:1850:2: ( rule__Version__NumberVersionAssignment_0_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionAssignment_0_1()); 
            }
            // InternalSM2.g:1851:2: ( rule__Version__NumberVersionAssignment_0_1 )
            // InternalSM2.g:1851:3: rule__Version__NumberVersionAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionAssignment_0_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionAssignment_0_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__1__Impl"


    // $ANTLR start "rule__Version__Group_0__2"
    // InternalSM2.g:1859:1: rule__Version__Group_0__2 : rule__Version__Group_0__2__Impl rule__Version__Group_0__3 ;
    public final void rule__Version__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1863:1: ( rule__Version__Group_0__2__Impl rule__Version__Group_0__3 )
            // InternalSM2.g:1864:2: rule__Version__Group_0__2__Impl rule__Version__Group_0__3
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_0__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_0__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__2"


    // $ANTLR start "rule__Version__Group_0__2__Impl"
    // InternalSM2.g:1871:1: rule__Version__Group_0__2__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1875:1: ( ( RULE_DOT ) )
            // InternalSM2.g:1876:1: ( RULE_DOT )
            {
            // InternalSM2.g:1876:1: ( RULE_DOT )
            // InternalSM2.g:1877:2: RULE_DOT
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_2()); 
            }
            match(input,RULE_DOT,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__2__Impl"


    // $ANTLR start "rule__Version__Group_0__3"
    // InternalSM2.g:1886:1: rule__Version__Group_0__3 : rule__Version__Group_0__3__Impl rule__Version__Group_0__4 ;
    public final void rule__Version__Group_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1890:1: ( rule__Version__Group_0__3__Impl rule__Version__Group_0__4 )
            // InternalSM2.g:1891:2: rule__Version__Group_0__3__Impl rule__Version__Group_0__4
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_0__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_0__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__3"


    // $ANTLR start "rule__Version__Group_0__3__Impl"
    // InternalSM2.g:1898:1: rule__Version__Group_0__3__Impl : ( ( rule__Version__NumberVersion2Assignment_0_3 ) ) ;
    public final void rule__Version__Group_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1902:1: ( ( ( rule__Version__NumberVersion2Assignment_0_3 ) ) )
            // InternalSM2.g:1903:1: ( ( rule__Version__NumberVersion2Assignment_0_3 ) )
            {
            // InternalSM2.g:1903:1: ( ( rule__Version__NumberVersion2Assignment_0_3 ) )
            // InternalSM2.g:1904:2: ( rule__Version__NumberVersion2Assignment_0_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion2Assignment_0_3()); 
            }
            // InternalSM2.g:1905:2: ( rule__Version__NumberVersion2Assignment_0_3 )
            // InternalSM2.g:1905:3: rule__Version__NumberVersion2Assignment_0_3
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion2Assignment_0_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion2Assignment_0_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__3__Impl"


    // $ANTLR start "rule__Version__Group_0__4"
    // InternalSM2.g:1913:1: rule__Version__Group_0__4 : rule__Version__Group_0__4__Impl rule__Version__Group_0__5 ;
    public final void rule__Version__Group_0__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1917:1: ( rule__Version__Group_0__4__Impl rule__Version__Group_0__5 )
            // InternalSM2.g:1918:2: rule__Version__Group_0__4__Impl rule__Version__Group_0__5
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_0__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_0__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__4"


    // $ANTLR start "rule__Version__Group_0__4__Impl"
    // InternalSM2.g:1925:1: rule__Version__Group_0__4__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_0__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1929:1: ( ( RULE_DOT ) )
            // InternalSM2.g:1930:1: ( RULE_DOT )
            {
            // InternalSM2.g:1930:1: ( RULE_DOT )
            // InternalSM2.g:1931:2: RULE_DOT
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_4()); 
            }
            match(input,RULE_DOT,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__4__Impl"


    // $ANTLR start "rule__Version__Group_0__5"
    // InternalSM2.g:1940:1: rule__Version__Group_0__5 : rule__Version__Group_0__5__Impl ;
    public final void rule__Version__Group_0__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1944:1: ( rule__Version__Group_0__5__Impl )
            // InternalSM2.g:1945:2: rule__Version__Group_0__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group_0__5__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__5"


    // $ANTLR start "rule__Version__Group_0__5__Impl"
    // InternalSM2.g:1951:1: rule__Version__Group_0__5__Impl : ( ( rule__Version__NumberVersion3Assignment_0_5 ) ) ;
    public final void rule__Version__Group_0__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1955:1: ( ( ( rule__Version__NumberVersion3Assignment_0_5 ) ) )
            // InternalSM2.g:1956:1: ( ( rule__Version__NumberVersion3Assignment_0_5 ) )
            {
            // InternalSM2.g:1956:1: ( ( rule__Version__NumberVersion3Assignment_0_5 ) )
            // InternalSM2.g:1957:2: ( rule__Version__NumberVersion3Assignment_0_5 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion3Assignment_0_5()); 
            }
            // InternalSM2.g:1958:2: ( rule__Version__NumberVersion3Assignment_0_5 )
            // InternalSM2.g:1958:3: rule__Version__NumberVersion3Assignment_0_5
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion3Assignment_0_5();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion3Assignment_0_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__5__Impl"


    // $ANTLR start "rule__Version__Group_1__0"
    // InternalSM2.g:1967:1: rule__Version__Group_1__0 : rule__Version__Group_1__0__Impl rule__Version__Group_1__1 ;
    public final void rule__Version__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1971:1: ( rule__Version__Group_1__0__Impl rule__Version__Group_1__1 )
            // InternalSM2.g:1972:2: rule__Version__Group_1__0__Impl rule__Version__Group_1__1
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_1__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__0"


    // $ANTLR start "rule__Version__Group_1__0__Impl"
    // InternalSM2.g:1979:1: rule__Version__Group_1__0__Impl : ( ( rule__Version__SymbolAssignment_1_0 ) ) ;
    public final void rule__Version__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1983:1: ( ( ( rule__Version__SymbolAssignment_1_0 ) ) )
            // InternalSM2.g:1984:1: ( ( rule__Version__SymbolAssignment_1_0 ) )
            {
            // InternalSM2.g:1984:1: ( ( rule__Version__SymbolAssignment_1_0 ) )
            // InternalSM2.g:1985:2: ( rule__Version__SymbolAssignment_1_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getSymbolAssignment_1_0()); 
            }
            // InternalSM2.g:1986:2: ( rule__Version__SymbolAssignment_1_0 )
            // InternalSM2.g:1986:3: rule__Version__SymbolAssignment_1_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAssignment_1_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getSymbolAssignment_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__0__Impl"


    // $ANTLR start "rule__Version__Group_1__1"
    // InternalSM2.g:1994:1: rule__Version__Group_1__1 : rule__Version__Group_1__1__Impl rule__Version__Group_1__2 ;
    public final void rule__Version__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1998:1: ( rule__Version__Group_1__1__Impl rule__Version__Group_1__2 )
            // InternalSM2.g:1999:2: rule__Version__Group_1__1__Impl rule__Version__Group_1__2
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_1__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__1"


    // $ANTLR start "rule__Version__Group_1__1__Impl"
    // InternalSM2.g:2006:1: rule__Version__Group_1__1__Impl : ( ( rule__Version__NumberVersionAssignment_1_1 ) ) ;
    public final void rule__Version__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2010:1: ( ( ( rule__Version__NumberVersionAssignment_1_1 ) ) )
            // InternalSM2.g:2011:1: ( ( rule__Version__NumberVersionAssignment_1_1 ) )
            {
            // InternalSM2.g:2011:1: ( ( rule__Version__NumberVersionAssignment_1_1 ) )
            // InternalSM2.g:2012:2: ( rule__Version__NumberVersionAssignment_1_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionAssignment_1_1()); 
            }
            // InternalSM2.g:2013:2: ( rule__Version__NumberVersionAssignment_1_1 )
            // InternalSM2.g:2013:3: rule__Version__NumberVersionAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionAssignment_1_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionAssignment_1_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__1__Impl"


    // $ANTLR start "rule__Version__Group_1__2"
    // InternalSM2.g:2021:1: rule__Version__Group_1__2 : rule__Version__Group_1__2__Impl rule__Version__Group_1__3 ;
    public final void rule__Version__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2025:1: ( rule__Version__Group_1__2__Impl rule__Version__Group_1__3 )
            // InternalSM2.g:2026:2: rule__Version__Group_1__2__Impl rule__Version__Group_1__3
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_1__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__2"


    // $ANTLR start "rule__Version__Group_1__2__Impl"
    // InternalSM2.g:2033:1: rule__Version__Group_1__2__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2037:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2038:1: ( RULE_DOT )
            {
            // InternalSM2.g:2038:1: ( RULE_DOT )
            // InternalSM2.g:2039:2: RULE_DOT
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_2()); 
            }
            match(input,RULE_DOT,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__2__Impl"


    // $ANTLR start "rule__Version__Group_1__3"
    // InternalSM2.g:2048:1: rule__Version__Group_1__3 : rule__Version__Group_1__3__Impl rule__Version__Group_1__4 ;
    public final void rule__Version__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2052:1: ( rule__Version__Group_1__3__Impl rule__Version__Group_1__4 )
            // InternalSM2.g:2053:2: rule__Version__Group_1__3__Impl rule__Version__Group_1__4
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_1__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__3"


    // $ANTLR start "rule__Version__Group_1__3__Impl"
    // InternalSM2.g:2060:1: rule__Version__Group_1__3__Impl : ( ( rule__Version__NumberVersion2Assignment_1_3 ) ) ;
    public final void rule__Version__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2064:1: ( ( ( rule__Version__NumberVersion2Assignment_1_3 ) ) )
            // InternalSM2.g:2065:1: ( ( rule__Version__NumberVersion2Assignment_1_3 ) )
            {
            // InternalSM2.g:2065:1: ( ( rule__Version__NumberVersion2Assignment_1_3 ) )
            // InternalSM2.g:2066:2: ( rule__Version__NumberVersion2Assignment_1_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion2Assignment_1_3()); 
            }
            // InternalSM2.g:2067:2: ( rule__Version__NumberVersion2Assignment_1_3 )
            // InternalSM2.g:2067:3: rule__Version__NumberVersion2Assignment_1_3
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion2Assignment_1_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion2Assignment_1_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__3__Impl"


    // $ANTLR start "rule__Version__Group_1__4"
    // InternalSM2.g:2075:1: rule__Version__Group_1__4 : rule__Version__Group_1__4__Impl rule__Version__Group_1__5 ;
    public final void rule__Version__Group_1__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2079:1: ( rule__Version__Group_1__4__Impl rule__Version__Group_1__5 )
            // InternalSM2.g:2080:2: rule__Version__Group_1__4__Impl rule__Version__Group_1__5
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_1__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__4"


    // $ANTLR start "rule__Version__Group_1__4__Impl"
    // InternalSM2.g:2087:1: rule__Version__Group_1__4__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_1__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2091:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2092:1: ( RULE_DOT )
            {
            // InternalSM2.g:2092:1: ( RULE_DOT )
            // InternalSM2.g:2093:2: RULE_DOT
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_4()); 
            }
            match(input,RULE_DOT,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__4__Impl"


    // $ANTLR start "rule__Version__Group_1__5"
    // InternalSM2.g:2102:1: rule__Version__Group_1__5 : rule__Version__Group_1__5__Impl rule__Version__Group_1__6 ;
    public final void rule__Version__Group_1__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2106:1: ( rule__Version__Group_1__5__Impl rule__Version__Group_1__6 )
            // InternalSM2.g:2107:2: rule__Version__Group_1__5__Impl rule__Version__Group_1__6
            {
            pushFollow(FOLLOW_18);
            rule__Version__Group_1__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__5"


    // $ANTLR start "rule__Version__Group_1__5__Impl"
    // InternalSM2.g:2114:1: rule__Version__Group_1__5__Impl : ( ( rule__Version__NumberVersion3Assignment_1_5 ) ) ;
    public final void rule__Version__Group_1__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2118:1: ( ( ( rule__Version__NumberVersion3Assignment_1_5 ) ) )
            // InternalSM2.g:2119:1: ( ( rule__Version__NumberVersion3Assignment_1_5 ) )
            {
            // InternalSM2.g:2119:1: ( ( rule__Version__NumberVersion3Assignment_1_5 ) )
            // InternalSM2.g:2120:2: ( rule__Version__NumberVersion3Assignment_1_5 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion3Assignment_1_5()); 
            }
            // InternalSM2.g:2121:2: ( rule__Version__NumberVersion3Assignment_1_5 )
            // InternalSM2.g:2121:3: rule__Version__NumberVersion3Assignment_1_5
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion3Assignment_1_5();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion3Assignment_1_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__5__Impl"


    // $ANTLR start "rule__Version__Group_1__6"
    // InternalSM2.g:2129:1: rule__Version__Group_1__6 : rule__Version__Group_1__6__Impl ;
    public final void rule__Version__Group_1__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2133:1: ( rule__Version__Group_1__6__Impl )
            // InternalSM2.g:2134:2: rule__Version__Group_1__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__6__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__6"


    // $ANTLR start "rule__Version__Group_1__6__Impl"
    // InternalSM2.g:2140:1: rule__Version__Group_1__6__Impl : ( ( rule__Version__Group_1_6__0 )? ) ;
    public final void rule__Version__Group_1__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2144:1: ( ( ( rule__Version__Group_1_6__0 )? ) )
            // InternalSM2.g:2145:1: ( ( rule__Version__Group_1_6__0 )? )
            {
            // InternalSM2.g:2145:1: ( ( rule__Version__Group_1_6__0 )? )
            // InternalSM2.g:2146:2: ( rule__Version__Group_1_6__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getGroup_1_6()); 
            }
            // InternalSM2.g:2147:2: ( rule__Version__Group_1_6__0 )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( ((LA29_0>=28 && LA29_0<=29)) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalSM2.g:2147:3: rule__Version__Group_1_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Version__Group_1_6__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getGroup_1_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__6__Impl"


    // $ANTLR start "rule__Version__Group_1_6__0"
    // InternalSM2.g:2156:1: rule__Version__Group_1_6__0 : rule__Version__Group_1_6__0__Impl rule__Version__Group_1_6__1 ;
    public final void rule__Version__Group_1_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2160:1: ( rule__Version__Group_1_6__0__Impl rule__Version__Group_1_6__1 )
            // InternalSM2.g:2161:2: rule__Version__Group_1_6__0__Impl rule__Version__Group_1_6__1
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_1_6__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__0"


    // $ANTLR start "rule__Version__Group_1_6__0__Impl"
    // InternalSM2.g:2168:1: rule__Version__Group_1_6__0__Impl : ( ( rule__Version__Symbol2Assignment_1_6_0 ) ) ;
    public final void rule__Version__Group_1_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2172:1: ( ( ( rule__Version__Symbol2Assignment_1_6_0 ) ) )
            // InternalSM2.g:2173:1: ( ( rule__Version__Symbol2Assignment_1_6_0 ) )
            {
            // InternalSM2.g:2173:1: ( ( rule__Version__Symbol2Assignment_1_6_0 ) )
            // InternalSM2.g:2174:2: ( rule__Version__Symbol2Assignment_1_6_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getSymbol2Assignment_1_6_0()); 
            }
            // InternalSM2.g:2175:2: ( rule__Version__Symbol2Assignment_1_6_0 )
            // InternalSM2.g:2175:3: rule__Version__Symbol2Assignment_1_6_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__Symbol2Assignment_1_6_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getSymbol2Assignment_1_6_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__0__Impl"


    // $ANTLR start "rule__Version__Group_1_6__1"
    // InternalSM2.g:2183:1: rule__Version__Group_1_6__1 : rule__Version__Group_1_6__1__Impl rule__Version__Group_1_6__2 ;
    public final void rule__Version__Group_1_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2187:1: ( rule__Version__Group_1_6__1__Impl rule__Version__Group_1_6__2 )
            // InternalSM2.g:2188:2: rule__Version__Group_1_6__1__Impl rule__Version__Group_1_6__2
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_1_6__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__1"


    // $ANTLR start "rule__Version__Group_1_6__1__Impl"
    // InternalSM2.g:2195:1: rule__Version__Group_1_6__1__Impl : ( ( rule__Version__NumberVersionOptionalAssignment_1_6_1 ) ) ;
    public final void rule__Version__Group_1_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2199:1: ( ( ( rule__Version__NumberVersionOptionalAssignment_1_6_1 ) ) )
            // InternalSM2.g:2200:1: ( ( rule__Version__NumberVersionOptionalAssignment_1_6_1 ) )
            {
            // InternalSM2.g:2200:1: ( ( rule__Version__NumberVersionOptionalAssignment_1_6_1 ) )
            // InternalSM2.g:2201:2: ( rule__Version__NumberVersionOptionalAssignment_1_6_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionOptionalAssignment_1_6_1()); 
            }
            // InternalSM2.g:2202:2: ( rule__Version__NumberVersionOptionalAssignment_1_6_1 )
            // InternalSM2.g:2202:3: rule__Version__NumberVersionOptionalAssignment_1_6_1
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionOptionalAssignment_1_6_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionOptionalAssignment_1_6_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__1__Impl"


    // $ANTLR start "rule__Version__Group_1_6__2"
    // InternalSM2.g:2210:1: rule__Version__Group_1_6__2 : rule__Version__Group_1_6__2__Impl rule__Version__Group_1_6__3 ;
    public final void rule__Version__Group_1_6__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2214:1: ( rule__Version__Group_1_6__2__Impl rule__Version__Group_1_6__3 )
            // InternalSM2.g:2215:2: rule__Version__Group_1_6__2__Impl rule__Version__Group_1_6__3
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_1_6__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__2"


    // $ANTLR start "rule__Version__Group_1_6__2__Impl"
    // InternalSM2.g:2222:1: rule__Version__Group_1_6__2__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_1_6__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2226:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2227:1: ( RULE_DOT )
            {
            // InternalSM2.g:2227:1: ( RULE_DOT )
            // InternalSM2.g:2228:2: RULE_DOT
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_2()); 
            }
            match(input,RULE_DOT,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__2__Impl"


    // $ANTLR start "rule__Version__Group_1_6__3"
    // InternalSM2.g:2237:1: rule__Version__Group_1_6__3 : rule__Version__Group_1_6__3__Impl rule__Version__Group_1_6__4 ;
    public final void rule__Version__Group_1_6__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2241:1: ( rule__Version__Group_1_6__3__Impl rule__Version__Group_1_6__4 )
            // InternalSM2.g:2242:2: rule__Version__Group_1_6__3__Impl rule__Version__Group_1_6__4
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_1_6__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__3"


    // $ANTLR start "rule__Version__Group_1_6__3__Impl"
    // InternalSM2.g:2249:1: rule__Version__Group_1_6__3__Impl : ( ( rule__Version__NumberVersionOptional2Assignment_1_6_3 ) ) ;
    public final void rule__Version__Group_1_6__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2253:1: ( ( ( rule__Version__NumberVersionOptional2Assignment_1_6_3 ) ) )
            // InternalSM2.g:2254:1: ( ( rule__Version__NumberVersionOptional2Assignment_1_6_3 ) )
            {
            // InternalSM2.g:2254:1: ( ( rule__Version__NumberVersionOptional2Assignment_1_6_3 ) )
            // InternalSM2.g:2255:2: ( rule__Version__NumberVersionOptional2Assignment_1_6_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionOptional2Assignment_1_6_3()); 
            }
            // InternalSM2.g:2256:2: ( rule__Version__NumberVersionOptional2Assignment_1_6_3 )
            // InternalSM2.g:2256:3: rule__Version__NumberVersionOptional2Assignment_1_6_3
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionOptional2Assignment_1_6_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionOptional2Assignment_1_6_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__3__Impl"


    // $ANTLR start "rule__Version__Group_1_6__4"
    // InternalSM2.g:2264:1: rule__Version__Group_1_6__4 : rule__Version__Group_1_6__4__Impl rule__Version__Group_1_6__5 ;
    public final void rule__Version__Group_1_6__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2268:1: ( rule__Version__Group_1_6__4__Impl rule__Version__Group_1_6__5 )
            // InternalSM2.g:2269:2: rule__Version__Group_1_6__4__Impl rule__Version__Group_1_6__5
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group_1_6__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__4"


    // $ANTLR start "rule__Version__Group_1_6__4__Impl"
    // InternalSM2.g:2276:1: rule__Version__Group_1_6__4__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_1_6__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2280:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2281:1: ( RULE_DOT )
            {
            // InternalSM2.g:2281:1: ( RULE_DOT )
            // InternalSM2.g:2282:2: RULE_DOT
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_4()); 
            }
            match(input,RULE_DOT,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__4__Impl"


    // $ANTLR start "rule__Version__Group_1_6__5"
    // InternalSM2.g:2291:1: rule__Version__Group_1_6__5 : rule__Version__Group_1_6__5__Impl ;
    public final void rule__Version__Group_1_6__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2295:1: ( rule__Version__Group_1_6__5__Impl )
            // InternalSM2.g:2296:2: rule__Version__Group_1_6__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__5__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__5"


    // $ANTLR start "rule__Version__Group_1_6__5__Impl"
    // InternalSM2.g:2302:1: rule__Version__Group_1_6__5__Impl : ( ( rule__Version__NumberVersionOptional3Assignment_1_6_5 ) ) ;
    public final void rule__Version__Group_1_6__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2306:1: ( ( ( rule__Version__NumberVersionOptional3Assignment_1_6_5 ) ) )
            // InternalSM2.g:2307:1: ( ( rule__Version__NumberVersionOptional3Assignment_1_6_5 ) )
            {
            // InternalSM2.g:2307:1: ( ( rule__Version__NumberVersionOptional3Assignment_1_6_5 ) )
            // InternalSM2.g:2308:2: ( rule__Version__NumberVersionOptional3Assignment_1_6_5 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionOptional3Assignment_1_6_5()); 
            }
            // InternalSM2.g:2309:2: ( rule__Version__NumberVersionOptional3Assignment_1_6_5 )
            // InternalSM2.g:2309:3: rule__Version__NumberVersionOptional3Assignment_1_6_5
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionOptional3Assignment_1_6_5();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionOptional3Assignment_1_6_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__5__Impl"


    // $ANTLR start "rule__Import__Group__0"
    // InternalSM2.g:2318:1: rule__Import__Group__0 : rule__Import__Group__0__Impl rule__Import__Group__1 ;
    public final void rule__Import__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2322:1: ( rule__Import__Group__0__Impl rule__Import__Group__1 )
            // InternalSM2.g:2323:2: rule__Import__Group__0__Impl rule__Import__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Import__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Import__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0"


    // $ANTLR start "rule__Import__Group__0__Impl"
    // InternalSM2.g:2330:1: rule__Import__Group__0__Impl : ( 'import' ) ;
    public final void rule__Import__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2334:1: ( ( 'import' ) )
            // InternalSM2.g:2335:1: ( 'import' )
            {
            // InternalSM2.g:2335:1: ( 'import' )
            // InternalSM2.g:2336:2: 'import'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getImportKeyword_0()); 
            }
            match(input,59,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getImportKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0__Impl"


    // $ANTLR start "rule__Import__Group__1"
    // InternalSM2.g:2345:1: rule__Import__Group__1 : rule__Import__Group__1__Impl rule__Import__Group__2 ;
    public final void rule__Import__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2349:1: ( rule__Import__Group__1__Impl rule__Import__Group__2 )
            // InternalSM2.g:2350:2: rule__Import__Group__1__Impl rule__Import__Group__2
            {
            pushFollow(FOLLOW_19);
            rule__Import__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Import__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1"


    // $ANTLR start "rule__Import__Group__1__Impl"
    // InternalSM2.g:2357:1: rule__Import__Group__1__Impl : ( ( rule__Import__NameLibraryAssignment_1 ) ) ;
    public final void rule__Import__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2361:1: ( ( ( rule__Import__NameLibraryAssignment_1 ) ) )
            // InternalSM2.g:2362:1: ( ( rule__Import__NameLibraryAssignment_1 ) )
            {
            // InternalSM2.g:2362:1: ( ( rule__Import__NameLibraryAssignment_1 ) )
            // InternalSM2.g:2363:2: ( rule__Import__NameLibraryAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getNameLibraryAssignment_1()); 
            }
            // InternalSM2.g:2364:2: ( rule__Import__NameLibraryAssignment_1 )
            // InternalSM2.g:2364:3: rule__Import__NameLibraryAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Import__NameLibraryAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getNameLibraryAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1__Impl"


    // $ANTLR start "rule__Import__Group__2"
    // InternalSM2.g:2372:1: rule__Import__Group__2 : rule__Import__Group__2__Impl rule__Import__Group__3 ;
    public final void rule__Import__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2376:1: ( rule__Import__Group__2__Impl rule__Import__Group__3 )
            // InternalSM2.g:2377:2: rule__Import__Group__2__Impl rule__Import__Group__3
            {
            pushFollow(FOLLOW_19);
            rule__Import__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Import__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__2"


    // $ANTLR start "rule__Import__Group__2__Impl"
    // InternalSM2.g:2384:1: rule__Import__Group__2__Impl : ( ( rule__Import__Group_2__0 )? ) ;
    public final void rule__Import__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2388:1: ( ( ( rule__Import__Group_2__0 )? ) )
            // InternalSM2.g:2389:1: ( ( rule__Import__Group_2__0 )? )
            {
            // InternalSM2.g:2389:1: ( ( rule__Import__Group_2__0 )? )
            // InternalSM2.g:2390:2: ( rule__Import__Group_2__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getGroup_2()); 
            }
            // InternalSM2.g:2391:2: ( rule__Import__Group_2__0 )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==60) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalSM2.g:2391:3: rule__Import__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Import__Group_2__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getGroup_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__2__Impl"


    // $ANTLR start "rule__Import__Group__3"
    // InternalSM2.g:2399:1: rule__Import__Group__3 : rule__Import__Group__3__Impl rule__Import__Group__4 ;
    public final void rule__Import__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2403:1: ( rule__Import__Group__3__Impl rule__Import__Group__4 )
            // InternalSM2.g:2404:2: rule__Import__Group__3__Impl rule__Import__Group__4
            {
            pushFollow(FOLLOW_20);
            rule__Import__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Import__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__3"


    // $ANTLR start "rule__Import__Group__3__Impl"
    // InternalSM2.g:2411:1: rule__Import__Group__3__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Import__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2415:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:2416:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:2416:1: ( RULE_SEMICOLON )
            // InternalSM2.g:2417:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_3()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__3__Impl"


    // $ANTLR start "rule__Import__Group__4"
    // InternalSM2.g:2426:1: rule__Import__Group__4 : rule__Import__Group__4__Impl ;
    public final void rule__Import__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2430:1: ( rule__Import__Group__4__Impl )
            // InternalSM2.g:2431:2: rule__Import__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__4"


    // $ANTLR start "rule__Import__Group__4__Impl"
    // InternalSM2.g:2437:1: rule__Import__Group__4__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Import__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2441:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2442:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2442:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2443:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getEOLINETerminalRuleCall_4()); 
            }
            // InternalSM2.g:2444:2: ( RULE_EOLINE )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==RULE_EOLINE) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalSM2.g:2444:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getEOLINETerminalRuleCall_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__4__Impl"


    // $ANTLR start "rule__Import__Group_2__0"
    // InternalSM2.g:2453:1: rule__Import__Group_2__0 : rule__Import__Group_2__0__Impl rule__Import__Group_2__1 ;
    public final void rule__Import__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2457:1: ( rule__Import__Group_2__0__Impl rule__Import__Group_2__1 )
            // InternalSM2.g:2458:2: rule__Import__Group_2__0__Impl rule__Import__Group_2__1
            {
            pushFollow(FOLLOW_8);
            rule__Import__Group_2__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Import__Group_2__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__0"


    // $ANTLR start "rule__Import__Group_2__0__Impl"
    // InternalSM2.g:2465:1: rule__Import__Group_2__0__Impl : ( 'as' ) ;
    public final void rule__Import__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2469:1: ( ( 'as' ) )
            // InternalSM2.g:2470:1: ( 'as' )
            {
            // InternalSM2.g:2470:1: ( 'as' )
            // InternalSM2.g:2471:2: 'as'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getAsKeyword_2_0()); 
            }
            match(input,60,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getAsKeyword_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__0__Impl"


    // $ANTLR start "rule__Import__Group_2__1"
    // InternalSM2.g:2480:1: rule__Import__Group_2__1 : rule__Import__Group_2__1__Impl ;
    public final void rule__Import__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2484:1: ( rule__Import__Group_2__1__Impl )
            // InternalSM2.g:2485:2: rule__Import__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group_2__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__1"


    // $ANTLR start "rule__Import__Group_2__1__Impl"
    // InternalSM2.g:2491:1: rule__Import__Group_2__1__Impl : ( ( rule__Import__AliasAssignment_2_1 ) ) ;
    public final void rule__Import__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2495:1: ( ( ( rule__Import__AliasAssignment_2_1 ) ) )
            // InternalSM2.g:2496:1: ( ( rule__Import__AliasAssignment_2_1 ) )
            {
            // InternalSM2.g:2496:1: ( ( rule__Import__AliasAssignment_2_1 ) )
            // InternalSM2.g:2497:2: ( rule__Import__AliasAssignment_2_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getAliasAssignment_2_1()); 
            }
            // InternalSM2.g:2498:2: ( rule__Import__AliasAssignment_2_1 )
            // InternalSM2.g:2498:3: rule__Import__AliasAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Import__AliasAssignment_2_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getAliasAssignment_2_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__1__Impl"


    // $ANTLR start "rule__Event__Group__0"
    // InternalSM2.g:2507:1: rule__Event__Group__0 : rule__Event__Group__0__Impl rule__Event__Group__1 ;
    public final void rule__Event__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2511:1: ( rule__Event__Group__0__Impl rule__Event__Group__1 )
            // InternalSM2.g:2512:2: rule__Event__Group__0__Impl rule__Event__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Event__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Event__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__0"


    // $ANTLR start "rule__Event__Group__0__Impl"
    // InternalSM2.g:2519:1: rule__Event__Group__0__Impl : ( 'event' ) ;
    public final void rule__Event__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2523:1: ( ( 'event' ) )
            // InternalSM2.g:2524:1: ( 'event' )
            {
            // InternalSM2.g:2524:1: ( 'event' )
            // InternalSM2.g:2525:2: 'event'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getEventKeyword_0()); 
            }
            match(input,61,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getEventKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__0__Impl"


    // $ANTLR start "rule__Event__Group__1"
    // InternalSM2.g:2534:1: rule__Event__Group__1 : rule__Event__Group__1__Impl rule__Event__Group__2 ;
    public final void rule__Event__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2538:1: ( rule__Event__Group__1__Impl rule__Event__Group__2 )
            // InternalSM2.g:2539:2: rule__Event__Group__1__Impl rule__Event__Group__2
            {
            pushFollow(FOLLOW_21);
            rule__Event__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Event__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__1"


    // $ANTLR start "rule__Event__Group__1__Impl"
    // InternalSM2.g:2546:1: rule__Event__Group__1__Impl : ( ( rule__Event__NameEventAssignment_1 ) ) ;
    public final void rule__Event__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2550:1: ( ( ( rule__Event__NameEventAssignment_1 ) ) )
            // InternalSM2.g:2551:1: ( ( rule__Event__NameEventAssignment_1 ) )
            {
            // InternalSM2.g:2551:1: ( ( rule__Event__NameEventAssignment_1 ) )
            // InternalSM2.g:2552:2: ( rule__Event__NameEventAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getNameEventAssignment_1()); 
            }
            // InternalSM2.g:2553:2: ( rule__Event__NameEventAssignment_1 )
            // InternalSM2.g:2553:3: rule__Event__NameEventAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Event__NameEventAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getNameEventAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__1__Impl"


    // $ANTLR start "rule__Event__Group__2"
    // InternalSM2.g:2561:1: rule__Event__Group__2 : rule__Event__Group__2__Impl rule__Event__Group__3 ;
    public final void rule__Event__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2565:1: ( rule__Event__Group__2__Impl rule__Event__Group__3 )
            // InternalSM2.g:2566:2: rule__Event__Group__2__Impl rule__Event__Group__3
            {
            pushFollow(FOLLOW_22);
            rule__Event__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Event__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__2"


    // $ANTLR start "rule__Event__Group__2__Impl"
    // InternalSM2.g:2573:1: rule__Event__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Event__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2577:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:2578:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:2578:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:2579:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__2__Impl"


    // $ANTLR start "rule__Event__Group__3"
    // InternalSM2.g:2588:1: rule__Event__Group__3 : rule__Event__Group__3__Impl rule__Event__Group__4 ;
    public final void rule__Event__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2592:1: ( rule__Event__Group__3__Impl rule__Event__Group__4 )
            // InternalSM2.g:2593:2: rule__Event__Group__3__Impl rule__Event__Group__4
            {
            pushFollow(FOLLOW_22);
            rule__Event__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Event__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__3"


    // $ANTLR start "rule__Event__Group__3__Impl"
    // InternalSM2.g:2600:1: rule__Event__Group__3__Impl : ( ( rule__Event__InputParamsAssignment_3 )* ) ;
    public final void rule__Event__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2604:1: ( ( ( rule__Event__InputParamsAssignment_3 )* ) )
            // InternalSM2.g:2605:1: ( ( rule__Event__InputParamsAssignment_3 )* )
            {
            // InternalSM2.g:2605:1: ( ( rule__Event__InputParamsAssignment_3 )* )
            // InternalSM2.g:2606:2: ( rule__Event__InputParamsAssignment_3 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getInputParamsAssignment_3()); 
            }
            // InternalSM2.g:2607:2: ( rule__Event__InputParamsAssignment_3 )*
            loop32:
            do {
                int alt32=2;
                int LA32_0 = input.LA(1);

                if ( ((LA32_0>=30 && LA32_0<=38)) ) {
                    alt32=1;
                }


                switch (alt32) {
            	case 1 :
            	    // InternalSM2.g:2607:3: rule__Event__InputParamsAssignment_3
            	    {
            	    pushFollow(FOLLOW_23);
            	    rule__Event__InputParamsAssignment_3();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop32;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getInputParamsAssignment_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__3__Impl"


    // $ANTLR start "rule__Event__Group__4"
    // InternalSM2.g:2615:1: rule__Event__Group__4 : rule__Event__Group__4__Impl rule__Event__Group__5 ;
    public final void rule__Event__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2619:1: ( rule__Event__Group__4__Impl rule__Event__Group__5 )
            // InternalSM2.g:2620:2: rule__Event__Group__4__Impl rule__Event__Group__5
            {
            pushFollow(FOLLOW_5);
            rule__Event__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Event__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__4"


    // $ANTLR start "rule__Event__Group__4__Impl"
    // InternalSM2.g:2627:1: rule__Event__Group__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Event__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2631:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2632:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2632:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2633:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__4__Impl"


    // $ANTLR start "rule__Event__Group__5"
    // InternalSM2.g:2642:1: rule__Event__Group__5 : rule__Event__Group__5__Impl rule__Event__Group__6 ;
    public final void rule__Event__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2646:1: ( rule__Event__Group__5__Impl rule__Event__Group__6 )
            // InternalSM2.g:2647:2: rule__Event__Group__5__Impl rule__Event__Group__6
            {
            pushFollow(FOLLOW_20);
            rule__Event__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Event__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__5"


    // $ANTLR start "rule__Event__Group__5__Impl"
    // InternalSM2.g:2654:1: rule__Event__Group__5__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Event__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2658:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:2659:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:2659:1: ( RULE_SEMICOLON )
            // InternalSM2.g:2660:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__5__Impl"


    // $ANTLR start "rule__Event__Group__6"
    // InternalSM2.g:2669:1: rule__Event__Group__6 : rule__Event__Group__6__Impl ;
    public final void rule__Event__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2673:1: ( rule__Event__Group__6__Impl )
            // InternalSM2.g:2674:2: rule__Event__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Event__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__6"


    // $ANTLR start "rule__Event__Group__6__Impl"
    // InternalSM2.g:2680:1: rule__Event__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Event__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2684:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2685:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2685:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2686:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6()); 
            }
            // InternalSM2.g:2687:2: ( RULE_EOLINE )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==RULE_EOLINE) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // InternalSM2.g:2687:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__6__Impl"


    // $ANTLR start "rule__Modifier__Group__0"
    // InternalSM2.g:2696:1: rule__Modifier__Group__0 : rule__Modifier__Group__0__Impl rule__Modifier__Group__1 ;
    public final void rule__Modifier__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2700:1: ( rule__Modifier__Group__0__Impl rule__Modifier__Group__1 )
            // InternalSM2.g:2701:2: rule__Modifier__Group__0__Impl rule__Modifier__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Modifier__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__0"


    // $ANTLR start "rule__Modifier__Group__0__Impl"
    // InternalSM2.g:2708:1: rule__Modifier__Group__0__Impl : ( 'modifier' ) ;
    public final void rule__Modifier__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2712:1: ( ( 'modifier' ) )
            // InternalSM2.g:2713:1: ( 'modifier' )
            {
            // InternalSM2.g:2713:1: ( 'modifier' )
            // InternalSM2.g:2714:2: 'modifier'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getModifierKeyword_0()); 
            }
            match(input,62,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getModifierKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__0__Impl"


    // $ANTLR start "rule__Modifier__Group__1"
    // InternalSM2.g:2723:1: rule__Modifier__Group__1 : rule__Modifier__Group__1__Impl rule__Modifier__Group__2 ;
    public final void rule__Modifier__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2727:1: ( rule__Modifier__Group__1__Impl rule__Modifier__Group__2 )
            // InternalSM2.g:2728:2: rule__Modifier__Group__1__Impl rule__Modifier__Group__2
            {
            pushFollow(FOLLOW_21);
            rule__Modifier__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__1"


    // $ANTLR start "rule__Modifier__Group__1__Impl"
    // InternalSM2.g:2735:1: rule__Modifier__Group__1__Impl : ( ( rule__Modifier__NameModifierAssignment_1 ) ) ;
    public final void rule__Modifier__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2739:1: ( ( ( rule__Modifier__NameModifierAssignment_1 ) ) )
            // InternalSM2.g:2740:1: ( ( rule__Modifier__NameModifierAssignment_1 ) )
            {
            // InternalSM2.g:2740:1: ( ( rule__Modifier__NameModifierAssignment_1 ) )
            // InternalSM2.g:2741:2: ( rule__Modifier__NameModifierAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getNameModifierAssignment_1()); 
            }
            // InternalSM2.g:2742:2: ( rule__Modifier__NameModifierAssignment_1 )
            // InternalSM2.g:2742:3: rule__Modifier__NameModifierAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__NameModifierAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getNameModifierAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__1__Impl"


    // $ANTLR start "rule__Modifier__Group__2"
    // InternalSM2.g:2750:1: rule__Modifier__Group__2 : rule__Modifier__Group__2__Impl rule__Modifier__Group__3 ;
    public final void rule__Modifier__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2754:1: ( rule__Modifier__Group__2__Impl rule__Modifier__Group__3 )
            // InternalSM2.g:2755:2: rule__Modifier__Group__2__Impl rule__Modifier__Group__3
            {
            pushFollow(FOLLOW_22);
            rule__Modifier__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__2"


    // $ANTLR start "rule__Modifier__Group__2__Impl"
    // InternalSM2.g:2762:1: rule__Modifier__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Modifier__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2766:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:2767:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:2767:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:2768:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__2__Impl"


    // $ANTLR start "rule__Modifier__Group__3"
    // InternalSM2.g:2777:1: rule__Modifier__Group__3 : rule__Modifier__Group__3__Impl rule__Modifier__Group__4 ;
    public final void rule__Modifier__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2781:1: ( rule__Modifier__Group__3__Impl rule__Modifier__Group__4 )
            // InternalSM2.g:2782:2: rule__Modifier__Group__3__Impl rule__Modifier__Group__4
            {
            pushFollow(FOLLOW_22);
            rule__Modifier__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__3"


    // $ANTLR start "rule__Modifier__Group__3__Impl"
    // InternalSM2.g:2789:1: rule__Modifier__Group__3__Impl : ( ( rule__Modifier__InputParamsAssignment_3 )* ) ;
    public final void rule__Modifier__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2793:1: ( ( ( rule__Modifier__InputParamsAssignment_3 )* ) )
            // InternalSM2.g:2794:1: ( ( rule__Modifier__InputParamsAssignment_3 )* )
            {
            // InternalSM2.g:2794:1: ( ( rule__Modifier__InputParamsAssignment_3 )* )
            // InternalSM2.g:2795:2: ( rule__Modifier__InputParamsAssignment_3 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getInputParamsAssignment_3()); 
            }
            // InternalSM2.g:2796:2: ( rule__Modifier__InputParamsAssignment_3 )*
            loop34:
            do {
                int alt34=2;
                int LA34_0 = input.LA(1);

                if ( ((LA34_0>=30 && LA34_0<=38)) ) {
                    alt34=1;
                }


                switch (alt34) {
            	case 1 :
            	    // InternalSM2.g:2796:3: rule__Modifier__InputParamsAssignment_3
            	    {
            	    pushFollow(FOLLOW_23);
            	    rule__Modifier__InputParamsAssignment_3();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop34;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getInputParamsAssignment_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__3__Impl"


    // $ANTLR start "rule__Modifier__Group__4"
    // InternalSM2.g:2804:1: rule__Modifier__Group__4 : rule__Modifier__Group__4__Impl rule__Modifier__Group__5 ;
    public final void rule__Modifier__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2808:1: ( rule__Modifier__Group__4__Impl rule__Modifier__Group__5 )
            // InternalSM2.g:2809:2: rule__Modifier__Group__4__Impl rule__Modifier__Group__5
            {
            pushFollow(FOLLOW_24);
            rule__Modifier__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__4"


    // $ANTLR start "rule__Modifier__Group__4__Impl"
    // InternalSM2.g:2816:1: rule__Modifier__Group__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Modifier__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2820:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2821:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2821:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2822:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__4__Impl"


    // $ANTLR start "rule__Modifier__Group__5"
    // InternalSM2.g:2831:1: rule__Modifier__Group__5 : rule__Modifier__Group__5__Impl rule__Modifier__Group__6 ;
    public final void rule__Modifier__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2835:1: ( rule__Modifier__Group__5__Impl rule__Modifier__Group__6 )
            // InternalSM2.g:2836:2: rule__Modifier__Group__5__Impl rule__Modifier__Group__6
            {
            pushFollow(FOLLOW_25);
            rule__Modifier__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__5"


    // $ANTLR start "rule__Modifier__Group__5__Impl"
    // InternalSM2.g:2843:1: rule__Modifier__Group__5__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Modifier__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2847:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:2848:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:2848:1: ( RULE_OPENKEY )
            // InternalSM2.g:2849:2: RULE_OPENKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5()); 
            }
            match(input,RULE_OPENKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__5__Impl"


    // $ANTLR start "rule__Modifier__Group__6"
    // InternalSM2.g:2858:1: rule__Modifier__Group__6 : rule__Modifier__Group__6__Impl rule__Modifier__Group__7 ;
    public final void rule__Modifier__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2862:1: ( rule__Modifier__Group__6__Impl rule__Modifier__Group__7 )
            // InternalSM2.g:2863:2: rule__Modifier__Group__6__Impl rule__Modifier__Group__7
            {
            pushFollow(FOLLOW_25);
            rule__Modifier__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__6"


    // $ANTLR start "rule__Modifier__Group__6__Impl"
    // InternalSM2.g:2870:1: rule__Modifier__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2874:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2875:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2875:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2876:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6()); 
            }
            // InternalSM2.g:2877:2: ( RULE_EOLINE )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==RULE_EOLINE) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalSM2.g:2877:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__6__Impl"


    // $ANTLR start "rule__Modifier__Group__7"
    // InternalSM2.g:2885:1: rule__Modifier__Group__7 : rule__Modifier__Group__7__Impl rule__Modifier__Group__8 ;
    public final void rule__Modifier__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2889:1: ( rule__Modifier__Group__7__Impl rule__Modifier__Group__8 )
            // InternalSM2.g:2890:2: rule__Modifier__Group__7__Impl rule__Modifier__Group__8
            {
            pushFollow(FOLLOW_5);
            rule__Modifier__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__8();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__7"


    // $ANTLR start "rule__Modifier__Group__7__Impl"
    // InternalSM2.g:2897:1: rule__Modifier__Group__7__Impl : ( ( rule__Modifier__ExprAssignment_7 ) ) ;
    public final void rule__Modifier__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2901:1: ( ( ( rule__Modifier__ExprAssignment_7 ) ) )
            // InternalSM2.g:2902:1: ( ( rule__Modifier__ExprAssignment_7 ) )
            {
            // InternalSM2.g:2902:1: ( ( rule__Modifier__ExprAssignment_7 ) )
            // InternalSM2.g:2903:2: ( rule__Modifier__ExprAssignment_7 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getExprAssignment_7()); 
            }
            // InternalSM2.g:2904:2: ( rule__Modifier__ExprAssignment_7 )
            // InternalSM2.g:2904:3: rule__Modifier__ExprAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__ExprAssignment_7();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getExprAssignment_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__7__Impl"


    // $ANTLR start "rule__Modifier__Group__8"
    // InternalSM2.g:2912:1: rule__Modifier__Group__8 : rule__Modifier__Group__8__Impl rule__Modifier__Group__9 ;
    public final void rule__Modifier__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2916:1: ( rule__Modifier__Group__8__Impl rule__Modifier__Group__9 )
            // InternalSM2.g:2917:2: rule__Modifier__Group__8__Impl rule__Modifier__Group__9
            {
            pushFollow(FOLLOW_26);
            rule__Modifier__Group__8__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__9();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__8"


    // $ANTLR start "rule__Modifier__Group__8__Impl"
    // InternalSM2.g:2924:1: rule__Modifier__Group__8__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Modifier__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2928:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:2929:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:2929:1: ( RULE_SEMICOLON )
            // InternalSM2.g:2930:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__8__Impl"


    // $ANTLR start "rule__Modifier__Group__9"
    // InternalSM2.g:2939:1: rule__Modifier__Group__9 : rule__Modifier__Group__9__Impl rule__Modifier__Group__10 ;
    public final void rule__Modifier__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2943:1: ( rule__Modifier__Group__9__Impl rule__Modifier__Group__10 )
            // InternalSM2.g:2944:2: rule__Modifier__Group__9__Impl rule__Modifier__Group__10
            {
            pushFollow(FOLLOW_26);
            rule__Modifier__Group__9__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__10();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__9"


    // $ANTLR start "rule__Modifier__Group__9__Impl"
    // InternalSM2.g:2951:1: rule__Modifier__Group__9__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2955:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2956:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2956:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2957:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9()); 
            }
            // InternalSM2.g:2958:2: ( RULE_EOLINE )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==RULE_EOLINE) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalSM2.g:2958:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__9__Impl"


    // $ANTLR start "rule__Modifier__Group__10"
    // InternalSM2.g:2966:1: rule__Modifier__Group__10 : rule__Modifier__Group__10__Impl rule__Modifier__Group__11 ;
    public final void rule__Modifier__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2970:1: ( rule__Modifier__Group__10__Impl rule__Modifier__Group__11 )
            // InternalSM2.g:2971:2: rule__Modifier__Group__10__Impl rule__Modifier__Group__11
            {
            pushFollow(FOLLOW_27);
            rule__Modifier__Group__10__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__11();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__10"


    // $ANTLR start "rule__Modifier__Group__10__Impl"
    // InternalSM2.g:2978:1: rule__Modifier__Group__10__Impl : ( '_;' ) ;
    public final void rule__Modifier__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2982:1: ( ( '_;' ) )
            // InternalSM2.g:2983:1: ( '_;' )
            {
            // InternalSM2.g:2983:1: ( '_;' )
            // InternalSM2.g:2984:2: '_;'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().get_Keyword_10()); 
            }
            match(input,63,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().get_Keyword_10()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__10__Impl"


    // $ANTLR start "rule__Modifier__Group__11"
    // InternalSM2.g:2993:1: rule__Modifier__Group__11 : rule__Modifier__Group__11__Impl rule__Modifier__Group__12 ;
    public final void rule__Modifier__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2997:1: ( rule__Modifier__Group__11__Impl rule__Modifier__Group__12 )
            // InternalSM2.g:2998:2: rule__Modifier__Group__11__Impl rule__Modifier__Group__12
            {
            pushFollow(FOLLOW_20);
            rule__Modifier__Group__11__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__12();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__11"


    // $ANTLR start "rule__Modifier__Group__11__Impl"
    // InternalSM2.g:3005:1: rule__Modifier__Group__11__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Modifier__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3009:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:3010:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:3010:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:3011:2: RULE_CLOSEKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11()); 
            }
            match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__11__Impl"


    // $ANTLR start "rule__Modifier__Group__12"
    // InternalSM2.g:3020:1: rule__Modifier__Group__12 : rule__Modifier__Group__12__Impl ;
    public final void rule__Modifier__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3024:1: ( rule__Modifier__Group__12__Impl )
            // InternalSM2.g:3025:2: rule__Modifier__Group__12__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__12__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__12"


    // $ANTLR start "rule__Modifier__Group__12__Impl"
    // InternalSM2.g:3031:1: rule__Modifier__Group__12__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3035:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3036:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3036:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3037:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12()); 
            }
            // InternalSM2.g:3038:2: ( RULE_EOLINE )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==RULE_EOLINE) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalSM2.g:3038:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__12__Impl"


    // $ANTLR start "rule__Mapping__Group__0"
    // InternalSM2.g:3047:1: rule__Mapping__Group__0 : rule__Mapping__Group__0__Impl rule__Mapping__Group__1 ;
    public final void rule__Mapping__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3051:1: ( rule__Mapping__Group__0__Impl rule__Mapping__Group__1 )
            // InternalSM2.g:3052:2: rule__Mapping__Group__0__Impl rule__Mapping__Group__1
            {
            pushFollow(FOLLOW_21);
            rule__Mapping__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__0"


    // $ANTLR start "rule__Mapping__Group__0__Impl"
    // InternalSM2.g:3059:1: rule__Mapping__Group__0__Impl : ( 'mapping' ) ;
    public final void rule__Mapping__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3063:1: ( ( 'mapping' ) )
            // InternalSM2.g:3064:1: ( 'mapping' )
            {
            // InternalSM2.g:3064:1: ( 'mapping' )
            // InternalSM2.g:3065:2: 'mapping'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getMappingKeyword_0()); 
            }
            match(input,64,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getMappingKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__0__Impl"


    // $ANTLR start "rule__Mapping__Group__1"
    // InternalSM2.g:3074:1: rule__Mapping__Group__1 : rule__Mapping__Group__1__Impl rule__Mapping__Group__2 ;
    public final void rule__Mapping__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3078:1: ( rule__Mapping__Group__1__Impl rule__Mapping__Group__2 )
            // InternalSM2.g:3079:2: rule__Mapping__Group__1__Impl rule__Mapping__Group__2
            {
            pushFollow(FOLLOW_28);
            rule__Mapping__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__1"


    // $ANTLR start "rule__Mapping__Group__1__Impl"
    // InternalSM2.g:3086:1: rule__Mapping__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Mapping__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3090:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:3091:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:3091:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:3092:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__1__Impl"


    // $ANTLR start "rule__Mapping__Group__2"
    // InternalSM2.g:3101:1: rule__Mapping__Group__2 : rule__Mapping__Group__2__Impl rule__Mapping__Group__3 ;
    public final void rule__Mapping__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3105:1: ( rule__Mapping__Group__2__Impl rule__Mapping__Group__3 )
            // InternalSM2.g:3106:2: rule__Mapping__Group__2__Impl rule__Mapping__Group__3
            {
            pushFollow(FOLLOW_29);
            rule__Mapping__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__2"


    // $ANTLR start "rule__Mapping__Group__2__Impl"
    // InternalSM2.g:3113:1: rule__Mapping__Group__2__Impl : ( ( rule__Mapping__TypeAssignment_2 ) ) ;
    public final void rule__Mapping__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3117:1: ( ( ( rule__Mapping__TypeAssignment_2 ) ) )
            // InternalSM2.g:3118:1: ( ( rule__Mapping__TypeAssignment_2 ) )
            {
            // InternalSM2.g:3118:1: ( ( rule__Mapping__TypeAssignment_2 ) )
            // InternalSM2.g:3119:2: ( rule__Mapping__TypeAssignment_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getTypeAssignment_2()); 
            }
            // InternalSM2.g:3120:2: ( rule__Mapping__TypeAssignment_2 )
            // InternalSM2.g:3120:3: rule__Mapping__TypeAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__TypeAssignment_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getTypeAssignment_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__2__Impl"


    // $ANTLR start "rule__Mapping__Group__3"
    // InternalSM2.g:3128:1: rule__Mapping__Group__3 : rule__Mapping__Group__3__Impl rule__Mapping__Group__4 ;
    public final void rule__Mapping__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3132:1: ( rule__Mapping__Group__3__Impl rule__Mapping__Group__4 )
            // InternalSM2.g:3133:2: rule__Mapping__Group__3__Impl rule__Mapping__Group__4
            {
            pushFollow(FOLLOW_30);
            rule__Mapping__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__3"


    // $ANTLR start "rule__Mapping__Group__3__Impl"
    // InternalSM2.g:3140:1: rule__Mapping__Group__3__Impl : ( '=>' ) ;
    public final void rule__Mapping__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3144:1: ( ( '=>' ) )
            // InternalSM2.g:3145:1: ( '=>' )
            {
            // InternalSM2.g:3145:1: ( '=>' )
            // InternalSM2.g:3146:2: '=>'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3()); 
            }
            match(input,65,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__3__Impl"


    // $ANTLR start "rule__Mapping__Group__4"
    // InternalSM2.g:3155:1: rule__Mapping__Group__4 : rule__Mapping__Group__4__Impl rule__Mapping__Group__5 ;
    public final void rule__Mapping__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3159:1: ( rule__Mapping__Group__4__Impl rule__Mapping__Group__5 )
            // InternalSM2.g:3160:2: rule__Mapping__Group__4__Impl rule__Mapping__Group__5
            {
            pushFollow(FOLLOW_31);
            rule__Mapping__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__4"


    // $ANTLR start "rule__Mapping__Group__4__Impl"
    // InternalSM2.g:3167:1: rule__Mapping__Group__4__Impl : ( ( rule__Mapping__ExprAssignment_4 ) ) ;
    public final void rule__Mapping__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3171:1: ( ( ( rule__Mapping__ExprAssignment_4 ) ) )
            // InternalSM2.g:3172:1: ( ( rule__Mapping__ExprAssignment_4 ) )
            {
            // InternalSM2.g:3172:1: ( ( rule__Mapping__ExprAssignment_4 ) )
            // InternalSM2.g:3173:2: ( rule__Mapping__ExprAssignment_4 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getExprAssignment_4()); 
            }
            // InternalSM2.g:3174:2: ( rule__Mapping__ExprAssignment_4 )
            // InternalSM2.g:3174:3: rule__Mapping__ExprAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__ExprAssignment_4();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getExprAssignment_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__4__Impl"


    // $ANTLR start "rule__Mapping__Group__5"
    // InternalSM2.g:3182:1: rule__Mapping__Group__5 : rule__Mapping__Group__5__Impl rule__Mapping__Group__6 ;
    public final void rule__Mapping__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3186:1: ( rule__Mapping__Group__5__Impl rule__Mapping__Group__6 )
            // InternalSM2.g:3187:2: rule__Mapping__Group__5__Impl rule__Mapping__Group__6
            {
            pushFollow(FOLLOW_32);
            rule__Mapping__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__5"


    // $ANTLR start "rule__Mapping__Group__5__Impl"
    // InternalSM2.g:3194:1: rule__Mapping__Group__5__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Mapping__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3198:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:3199:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:3199:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:3200:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__5__Impl"


    // $ANTLR start "rule__Mapping__Group__6"
    // InternalSM2.g:3209:1: rule__Mapping__Group__6 : rule__Mapping__Group__6__Impl rule__Mapping__Group__7 ;
    public final void rule__Mapping__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3213:1: ( rule__Mapping__Group__6__Impl rule__Mapping__Group__7 )
            // InternalSM2.g:3214:2: rule__Mapping__Group__6__Impl rule__Mapping__Group__7
            {
            pushFollow(FOLLOW_32);
            rule__Mapping__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__6"


    // $ANTLR start "rule__Mapping__Group__6__Impl"
    // InternalSM2.g:3221:1: rule__Mapping__Group__6__Impl : ( ( rule__Mapping__VisibilityAssignment_6 )? ) ;
    public final void rule__Mapping__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3225:1: ( ( ( rule__Mapping__VisibilityAssignment_6 )? ) )
            // InternalSM2.g:3226:1: ( ( rule__Mapping__VisibilityAssignment_6 )? )
            {
            // InternalSM2.g:3226:1: ( ( rule__Mapping__VisibilityAssignment_6 )? )
            // InternalSM2.g:3227:2: ( rule__Mapping__VisibilityAssignment_6 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getVisibilityAssignment_6()); 
            }
            // InternalSM2.g:3228:2: ( rule__Mapping__VisibilityAssignment_6 )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( ((LA38_0>=39 && LA38_0<=42)) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:3228:3: rule__Mapping__VisibilityAssignment_6
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mapping__VisibilityAssignment_6();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getVisibilityAssignment_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__6__Impl"


    // $ANTLR start "rule__Mapping__Group__7"
    // InternalSM2.g:3236:1: rule__Mapping__Group__7 : rule__Mapping__Group__7__Impl rule__Mapping__Group__8 ;
    public final void rule__Mapping__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3240:1: ( rule__Mapping__Group__7__Impl rule__Mapping__Group__8 )
            // InternalSM2.g:3241:2: rule__Mapping__Group__7__Impl rule__Mapping__Group__8
            {
            pushFollow(FOLLOW_5);
            rule__Mapping__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__8();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__7"


    // $ANTLR start "rule__Mapping__Group__7__Impl"
    // InternalSM2.g:3248:1: rule__Mapping__Group__7__Impl : ( ( rule__Mapping__NameMappingAssignment_7 ) ) ;
    public final void rule__Mapping__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3252:1: ( ( ( rule__Mapping__NameMappingAssignment_7 ) ) )
            // InternalSM2.g:3253:1: ( ( rule__Mapping__NameMappingAssignment_7 ) )
            {
            // InternalSM2.g:3253:1: ( ( rule__Mapping__NameMappingAssignment_7 ) )
            // InternalSM2.g:3254:2: ( rule__Mapping__NameMappingAssignment_7 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getNameMappingAssignment_7()); 
            }
            // InternalSM2.g:3255:2: ( rule__Mapping__NameMappingAssignment_7 )
            // InternalSM2.g:3255:3: rule__Mapping__NameMappingAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__NameMappingAssignment_7();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getNameMappingAssignment_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__7__Impl"


    // $ANTLR start "rule__Mapping__Group__8"
    // InternalSM2.g:3263:1: rule__Mapping__Group__8 : rule__Mapping__Group__8__Impl ;
    public final void rule__Mapping__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3267:1: ( rule__Mapping__Group__8__Impl )
            // InternalSM2.g:3268:2: rule__Mapping__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__8__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__8"


    // $ANTLR start "rule__Mapping__Group__8__Impl"
    // InternalSM2.g:3274:1: rule__Mapping__Group__8__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Mapping__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3278:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3279:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3279:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3280:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__8__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__0"
    // InternalSM2.g:3290:1: rule__PersonalizedStruct__Group__0 : rule__PersonalizedStruct__Group__0__Impl rule__PersonalizedStruct__Group__1 ;
    public final void rule__PersonalizedStruct__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3294:1: ( rule__PersonalizedStruct__Group__0__Impl rule__PersonalizedStruct__Group__1 )
            // InternalSM2.g:3295:2: rule__PersonalizedStruct__Group__0__Impl rule__PersonalizedStruct__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__PersonalizedStruct__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__0"


    // $ANTLR start "rule__PersonalizedStruct__Group__0__Impl"
    // InternalSM2.g:3302:1: rule__PersonalizedStruct__Group__0__Impl : ( 'struct' ) ;
    public final void rule__PersonalizedStruct__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3306:1: ( ( 'struct' ) )
            // InternalSM2.g:3307:1: ( 'struct' )
            {
            // InternalSM2.g:3307:1: ( 'struct' )
            // InternalSM2.g:3308:2: 'struct'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getStructKeyword_0()); 
            }
            match(input,66,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getStructKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__0__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__1"
    // InternalSM2.g:3317:1: rule__PersonalizedStruct__Group__1 : rule__PersonalizedStruct__Group__1__Impl rule__PersonalizedStruct__Group__2 ;
    public final void rule__PersonalizedStruct__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3321:1: ( rule__PersonalizedStruct__Group__1__Impl rule__PersonalizedStruct__Group__2 )
            // InternalSM2.g:3322:2: rule__PersonalizedStruct__Group__1__Impl rule__PersonalizedStruct__Group__2
            {
            pushFollow(FOLLOW_24);
            rule__PersonalizedStruct__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__1"


    // $ANTLR start "rule__PersonalizedStruct__Group__1__Impl"
    // InternalSM2.g:3329:1: rule__PersonalizedStruct__Group__1__Impl : ( ( rule__PersonalizedStruct__NameStructAssignment_1 ) ) ;
    public final void rule__PersonalizedStruct__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3333:1: ( ( ( rule__PersonalizedStruct__NameStructAssignment_1 ) ) )
            // InternalSM2.g:3334:1: ( ( rule__PersonalizedStruct__NameStructAssignment_1 ) )
            {
            // InternalSM2.g:3334:1: ( ( rule__PersonalizedStruct__NameStructAssignment_1 ) )
            // InternalSM2.g:3335:2: ( rule__PersonalizedStruct__NameStructAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getNameStructAssignment_1()); 
            }
            // InternalSM2.g:3336:2: ( rule__PersonalizedStruct__NameStructAssignment_1 )
            // InternalSM2.g:3336:3: rule__PersonalizedStruct__NameStructAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__NameStructAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getNameStructAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__1__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__2"
    // InternalSM2.g:3344:1: rule__PersonalizedStruct__Group__2 : rule__PersonalizedStruct__Group__2__Impl rule__PersonalizedStruct__Group__3 ;
    public final void rule__PersonalizedStruct__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3348:1: ( rule__PersonalizedStruct__Group__2__Impl rule__PersonalizedStruct__Group__3 )
            // InternalSM2.g:3349:2: rule__PersonalizedStruct__Group__2__Impl rule__PersonalizedStruct__Group__3
            {
            pushFollow(FOLLOW_33);
            rule__PersonalizedStruct__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__2"


    // $ANTLR start "rule__PersonalizedStruct__Group__2__Impl"
    // InternalSM2.g:3356:1: rule__PersonalizedStruct__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__PersonalizedStruct__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3360:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:3361:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:3361:1: ( RULE_OPENKEY )
            // InternalSM2.g:3362:2: RULE_OPENKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2()); 
            }
            match(input,RULE_OPENKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__2__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__3"
    // InternalSM2.g:3371:1: rule__PersonalizedStruct__Group__3 : rule__PersonalizedStruct__Group__3__Impl rule__PersonalizedStruct__Group__4 ;
    public final void rule__PersonalizedStruct__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3375:1: ( rule__PersonalizedStruct__Group__3__Impl rule__PersonalizedStruct__Group__4 )
            // InternalSM2.g:3376:2: rule__PersonalizedStruct__Group__3__Impl rule__PersonalizedStruct__Group__4
            {
            pushFollow(FOLLOW_33);
            rule__PersonalizedStruct__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__3"


    // $ANTLR start "rule__PersonalizedStruct__Group__3__Impl"
    // InternalSM2.g:3383:1: rule__PersonalizedStruct__Group__3__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__PersonalizedStruct__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3387:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3388:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3388:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3389:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3()); 
            }
            // InternalSM2.g:3390:2: ( RULE_EOLINE )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==RULE_EOLINE) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalSM2.g:3390:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__3__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__4"
    // InternalSM2.g:3398:1: rule__PersonalizedStruct__Group__4 : rule__PersonalizedStruct__Group__4__Impl rule__PersonalizedStruct__Group__5 ;
    public final void rule__PersonalizedStruct__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3402:1: ( rule__PersonalizedStruct__Group__4__Impl rule__PersonalizedStruct__Group__5 )
            // InternalSM2.g:3403:2: rule__PersonalizedStruct__Group__4__Impl rule__PersonalizedStruct__Group__5
            {
            pushFollow(FOLLOW_27);
            rule__PersonalizedStruct__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__4"


    // $ANTLR start "rule__PersonalizedStruct__Group__4__Impl"
    // InternalSM2.g:3410:1: rule__PersonalizedStruct__Group__4__Impl : ( ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) ) ( ( rule__PersonalizedStruct__PropertiesAssignment_4 )* ) ) ;
    public final void rule__PersonalizedStruct__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3414:1: ( ( ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) ) ( ( rule__PersonalizedStruct__PropertiesAssignment_4 )* ) ) )
            // InternalSM2.g:3415:1: ( ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) ) ( ( rule__PersonalizedStruct__PropertiesAssignment_4 )* ) )
            {
            // InternalSM2.g:3415:1: ( ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) ) ( ( rule__PersonalizedStruct__PropertiesAssignment_4 )* ) )
            // InternalSM2.g:3416:2: ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) ) ( ( rule__PersonalizedStruct__PropertiesAssignment_4 )* )
            {
            // InternalSM2.g:3416:2: ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) )
            // InternalSM2.g:3417:3: ( rule__PersonalizedStruct__PropertiesAssignment_4 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getPropertiesAssignment_4()); 
            }
            // InternalSM2.g:3418:3: ( rule__PersonalizedStruct__PropertiesAssignment_4 )
            // InternalSM2.g:3418:4: rule__PersonalizedStruct__PropertiesAssignment_4
            {
            pushFollow(FOLLOW_34);
            rule__PersonalizedStruct__PropertiesAssignment_4();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getPropertiesAssignment_4()); 
            }

            }

            // InternalSM2.g:3421:2: ( ( rule__PersonalizedStruct__PropertiesAssignment_4 )* )
            // InternalSM2.g:3422:3: ( rule__PersonalizedStruct__PropertiesAssignment_4 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getPropertiesAssignment_4()); 
            }
            // InternalSM2.g:3423:3: ( rule__PersonalizedStruct__PropertiesAssignment_4 )*
            loop40:
            do {
                int alt40=2;
                int LA40_0 = input.LA(1);

                if ( ((LA40_0>=30 && LA40_0<=38)) ) {
                    alt40=1;
                }


                switch (alt40) {
            	case 1 :
            	    // InternalSM2.g:3423:4: rule__PersonalizedStruct__PropertiesAssignment_4
            	    {
            	    pushFollow(FOLLOW_34);
            	    rule__PersonalizedStruct__PropertiesAssignment_4();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop40;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getPropertiesAssignment_4()); 
            }

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__4__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__5"
    // InternalSM2.g:3432:1: rule__PersonalizedStruct__Group__5 : rule__PersonalizedStruct__Group__5__Impl rule__PersonalizedStruct__Group__6 ;
    public final void rule__PersonalizedStruct__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3436:1: ( rule__PersonalizedStruct__Group__5__Impl rule__PersonalizedStruct__Group__6 )
            // InternalSM2.g:3437:2: rule__PersonalizedStruct__Group__5__Impl rule__PersonalizedStruct__Group__6
            {
            pushFollow(FOLLOW_20);
            rule__PersonalizedStruct__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__5"


    // $ANTLR start "rule__PersonalizedStruct__Group__5__Impl"
    // InternalSM2.g:3444:1: rule__PersonalizedStruct__Group__5__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__PersonalizedStruct__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3448:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:3449:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:3449:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:3450:2: RULE_CLOSEKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5()); 
            }
            match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__5__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__6"
    // InternalSM2.g:3459:1: rule__PersonalizedStruct__Group__6 : rule__PersonalizedStruct__Group__6__Impl ;
    public final void rule__PersonalizedStruct__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3463:1: ( rule__PersonalizedStruct__Group__6__Impl )
            // InternalSM2.g:3464:2: rule__PersonalizedStruct__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__6"


    // $ANTLR start "rule__PersonalizedStruct__Group__6__Impl"
    // InternalSM2.g:3470:1: rule__PersonalizedStruct__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__PersonalizedStruct__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3474:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3475:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3475:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3476:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6()); 
            }
            // InternalSM2.g:3477:2: ( RULE_EOLINE )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==RULE_EOLINE) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalSM2.g:3477:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__6__Impl"


    // $ANTLR start "rule__User__Group__0"
    // InternalSM2.g:3486:1: rule__User__Group__0 : rule__User__Group__0__Impl rule__User__Group__1 ;
    public final void rule__User__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3490:1: ( rule__User__Group__0__Impl rule__User__Group__1 )
            // InternalSM2.g:3491:2: rule__User__Group__0__Impl rule__User__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__User__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__0"


    // $ANTLR start "rule__User__Group__0__Impl"
    // InternalSM2.g:3498:1: rule__User__Group__0__Impl : ( 'struct' ) ;
    public final void rule__User__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3502:1: ( ( 'struct' ) )
            // InternalSM2.g:3503:1: ( 'struct' )
            {
            // InternalSM2.g:3503:1: ( 'struct' )
            // InternalSM2.g:3504:2: 'struct'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getStructKeyword_0()); 
            }
            match(input,66,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getStructKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__0__Impl"


    // $ANTLR start "rule__User__Group__1"
    // InternalSM2.g:3513:1: rule__User__Group__1 : rule__User__Group__1__Impl rule__User__Group__2 ;
    public final void rule__User__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3517:1: ( rule__User__Group__1__Impl rule__User__Group__2 )
            // InternalSM2.g:3518:2: rule__User__Group__1__Impl rule__User__Group__2
            {
            pushFollow(FOLLOW_24);
            rule__User__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__1"


    // $ANTLR start "rule__User__Group__1__Impl"
    // InternalSM2.g:3525:1: rule__User__Group__1__Impl : ( ( rule__User__NameStructAssignment_1 ) ) ;
    public final void rule__User__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3529:1: ( ( ( rule__User__NameStructAssignment_1 ) ) )
            // InternalSM2.g:3530:1: ( ( rule__User__NameStructAssignment_1 ) )
            {
            // InternalSM2.g:3530:1: ( ( rule__User__NameStructAssignment_1 ) )
            // InternalSM2.g:3531:2: ( rule__User__NameStructAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getNameStructAssignment_1()); 
            }
            // InternalSM2.g:3532:2: ( rule__User__NameStructAssignment_1 )
            // InternalSM2.g:3532:3: rule__User__NameStructAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__User__NameStructAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getNameStructAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__1__Impl"


    // $ANTLR start "rule__User__Group__2"
    // InternalSM2.g:3540:1: rule__User__Group__2 : rule__User__Group__2__Impl rule__User__Group__3 ;
    public final void rule__User__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3544:1: ( rule__User__Group__2__Impl rule__User__Group__3 )
            // InternalSM2.g:3545:2: rule__User__Group__2__Impl rule__User__Group__3
            {
            pushFollow(FOLLOW_35);
            rule__User__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__2"


    // $ANTLR start "rule__User__Group__2__Impl"
    // InternalSM2.g:3552:1: rule__User__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__User__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3556:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:3557:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:3557:1: ( RULE_OPENKEY )
            // InternalSM2.g:3558:2: RULE_OPENKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2()); 
            }
            match(input,RULE_OPENKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__2__Impl"


    // $ANTLR start "rule__User__Group__3"
    // InternalSM2.g:3567:1: rule__User__Group__3 : rule__User__Group__3__Impl rule__User__Group__4 ;
    public final void rule__User__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3571:1: ( rule__User__Group__3__Impl rule__User__Group__4 )
            // InternalSM2.g:3572:2: rule__User__Group__3__Impl rule__User__Group__4
            {
            pushFollow(FOLLOW_35);
            rule__User__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__3"


    // $ANTLR start "rule__User__Group__3__Impl"
    // InternalSM2.g:3579:1: rule__User__Group__3__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3583:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3584:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3584:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3585:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3()); 
            }
            // InternalSM2.g:3586:2: ( RULE_EOLINE )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==RULE_EOLINE) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalSM2.g:3586:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__3__Impl"


    // $ANTLR start "rule__User__Group__4"
    // InternalSM2.g:3594:1: rule__User__Group__4 : rule__User__Group__4__Impl rule__User__Group__5 ;
    public final void rule__User__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3598:1: ( rule__User__Group__4__Impl rule__User__Group__5 )
            // InternalSM2.g:3599:2: rule__User__Group__4__Impl rule__User__Group__5
            {
            pushFollow(FOLLOW_8);
            rule__User__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__4"


    // $ANTLR start "rule__User__Group__4__Impl"
    // InternalSM2.g:3606:1: rule__User__Group__4__Impl : ( 'address' ) ;
    public final void rule__User__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3610:1: ( ( 'address' ) )
            // InternalSM2.g:3611:1: ( 'address' )
            {
            // InternalSM2.g:3611:1: ( 'address' )
            // InternalSM2.g:3612:2: 'address'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getAddressKeyword_4()); 
            }
            match(input,35,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getAddressKeyword_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__4__Impl"


    // $ANTLR start "rule__User__Group__5"
    // InternalSM2.g:3621:1: rule__User__Group__5 : rule__User__Group__5__Impl rule__User__Group__6 ;
    public final void rule__User__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3625:1: ( rule__User__Group__5__Impl rule__User__Group__6 )
            // InternalSM2.g:3626:2: rule__User__Group__5__Impl rule__User__Group__6
            {
            pushFollow(FOLLOW_36);
            rule__User__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__5"


    // $ANTLR start "rule__User__Group__5__Impl"
    // InternalSM2.g:3633:1: rule__User__Group__5__Impl : ( ( rule__User__IdAdressAssignment_5 ) ) ;
    public final void rule__User__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3637:1: ( ( ( rule__User__IdAdressAssignment_5 ) ) )
            // InternalSM2.g:3638:1: ( ( rule__User__IdAdressAssignment_5 ) )
            {
            // InternalSM2.g:3638:1: ( ( rule__User__IdAdressAssignment_5 ) )
            // InternalSM2.g:3639:2: ( rule__User__IdAdressAssignment_5 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getIdAdressAssignment_5()); 
            }
            // InternalSM2.g:3640:2: ( rule__User__IdAdressAssignment_5 )
            // InternalSM2.g:3640:3: rule__User__IdAdressAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__User__IdAdressAssignment_5();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getIdAdressAssignment_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__5__Impl"


    // $ANTLR start "rule__User__Group__6"
    // InternalSM2.g:3648:1: rule__User__Group__6 : rule__User__Group__6__Impl rule__User__Group__7 ;
    public final void rule__User__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3652:1: ( rule__User__Group__6__Impl rule__User__Group__7 )
            // InternalSM2.g:3653:2: rule__User__Group__6__Impl rule__User__Group__7
            {
            pushFollow(FOLLOW_36);
            rule__User__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__6"


    // $ANTLR start "rule__User__Group__6__Impl"
    // InternalSM2.g:3660:1: rule__User__Group__6__Impl : ( ( rule__User__Group_6__0 )? ) ;
    public final void rule__User__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3664:1: ( ( ( rule__User__Group_6__0 )? ) )
            // InternalSM2.g:3665:1: ( ( rule__User__Group_6__0 )? )
            {
            // InternalSM2.g:3665:1: ( ( rule__User__Group_6__0 )? )
            // InternalSM2.g:3666:2: ( rule__User__Group_6__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getGroup_6()); 
            }
            // InternalSM2.g:3667:2: ( rule__User__Group_6__0 )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==67) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalSM2.g:3667:3: rule__User__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__User__Group_6__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getGroup_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__6__Impl"


    // $ANTLR start "rule__User__Group__7"
    // InternalSM2.g:3675:1: rule__User__Group__7 : rule__User__Group__7__Impl rule__User__Group__8 ;
    public final void rule__User__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3679:1: ( rule__User__Group__7__Impl rule__User__Group__8 )
            // InternalSM2.g:3680:2: rule__User__Group__7__Impl rule__User__Group__8
            {
            pushFollow(FOLLOW_37);
            rule__User__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__8();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__7"


    // $ANTLR start "rule__User__Group__7__Impl"
    // InternalSM2.g:3687:1: rule__User__Group__7__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3691:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3692:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3692:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3693:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_7()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__7__Impl"


    // $ANTLR start "rule__User__Group__8"
    // InternalSM2.g:3702:1: rule__User__Group__8 : rule__User__Group__8__Impl rule__User__Group__9 ;
    public final void rule__User__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3706:1: ( rule__User__Group__8__Impl rule__User__Group__9 )
            // InternalSM2.g:3707:2: rule__User__Group__8__Impl rule__User__Group__9
            {
            pushFollow(FOLLOW_37);
            rule__User__Group__8__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__9();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__8"


    // $ANTLR start "rule__User__Group__8__Impl"
    // InternalSM2.g:3714:1: rule__User__Group__8__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3718:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3719:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3719:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3720:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_8()); 
            }
            // InternalSM2.g:3721:2: ( RULE_EOLINE )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==RULE_EOLINE) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:3721:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_8()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__8__Impl"


    // $ANTLR start "rule__User__Group__9"
    // InternalSM2.g:3729:1: rule__User__Group__9 : rule__User__Group__9__Impl rule__User__Group__10 ;
    public final void rule__User__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3733:1: ( rule__User__Group__9__Impl rule__User__Group__10 )
            // InternalSM2.g:3734:2: rule__User__Group__9__Impl rule__User__Group__10
            {
            pushFollow(FOLLOW_30);
            rule__User__Group__9__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__10();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__9"


    // $ANTLR start "rule__User__Group__9__Impl"
    // InternalSM2.g:3741:1: rule__User__Group__9__Impl : ( 'string' ) ;
    public final void rule__User__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3745:1: ( ( 'string' ) )
            // InternalSM2.g:3746:1: ( 'string' )
            {
            // InternalSM2.g:3746:1: ( 'string' )
            // InternalSM2.g:3747:2: 'string'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getStringKeyword_9()); 
            }
            match(input,34,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getStringKeyword_9()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__9__Impl"


    // $ANTLR start "rule__User__Group__10"
    // InternalSM2.g:3756:1: rule__User__Group__10 : rule__User__Group__10__Impl rule__User__Group__11 ;
    public final void rule__User__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3760:1: ( rule__User__Group__10__Impl rule__User__Group__11 )
            // InternalSM2.g:3761:2: rule__User__Group__10__Impl rule__User__Group__11
            {
            pushFollow(FOLLOW_36);
            rule__User__Group__10__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__11();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__10"


    // $ANTLR start "rule__User__Group__10__Impl"
    // InternalSM2.g:3768:1: rule__User__Group__10__Impl : ( ( rule__User__NameUserAssignment_10 ) ) ;
    public final void rule__User__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3772:1: ( ( ( rule__User__NameUserAssignment_10 ) ) )
            // InternalSM2.g:3773:1: ( ( rule__User__NameUserAssignment_10 ) )
            {
            // InternalSM2.g:3773:1: ( ( rule__User__NameUserAssignment_10 ) )
            // InternalSM2.g:3774:2: ( rule__User__NameUserAssignment_10 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getNameUserAssignment_10()); 
            }
            // InternalSM2.g:3775:2: ( rule__User__NameUserAssignment_10 )
            // InternalSM2.g:3775:3: rule__User__NameUserAssignment_10
            {
            pushFollow(FOLLOW_2);
            rule__User__NameUserAssignment_10();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getNameUserAssignment_10()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__10__Impl"


    // $ANTLR start "rule__User__Group__11"
    // InternalSM2.g:3783:1: rule__User__Group__11 : rule__User__Group__11__Impl rule__User__Group__12 ;
    public final void rule__User__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3787:1: ( rule__User__Group__11__Impl rule__User__Group__12 )
            // InternalSM2.g:3788:2: rule__User__Group__11__Impl rule__User__Group__12
            {
            pushFollow(FOLLOW_36);
            rule__User__Group__11__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__12();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__11"


    // $ANTLR start "rule__User__Group__11__Impl"
    // InternalSM2.g:3795:1: rule__User__Group__11__Impl : ( ( rule__User__Group_11__0 )? ) ;
    public final void rule__User__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3799:1: ( ( ( rule__User__Group_11__0 )? ) )
            // InternalSM2.g:3800:1: ( ( rule__User__Group_11__0 )? )
            {
            // InternalSM2.g:3800:1: ( ( rule__User__Group_11__0 )? )
            // InternalSM2.g:3801:2: ( rule__User__Group_11__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getGroup_11()); 
            }
            // InternalSM2.g:3802:2: ( rule__User__Group_11__0 )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==67) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalSM2.g:3802:3: rule__User__Group_11__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__User__Group_11__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getGroup_11()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__11__Impl"


    // $ANTLR start "rule__User__Group__12"
    // InternalSM2.g:3810:1: rule__User__Group__12 : rule__User__Group__12__Impl rule__User__Group__13 ;
    public final void rule__User__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3814:1: ( rule__User__Group__12__Impl rule__User__Group__13 )
            // InternalSM2.g:3815:2: rule__User__Group__12__Impl rule__User__Group__13
            {
            pushFollow(FOLLOW_37);
            rule__User__Group__12__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__13();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__12"


    // $ANTLR start "rule__User__Group__12__Impl"
    // InternalSM2.g:3822:1: rule__User__Group__12__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3826:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3827:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3827:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3828:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_12()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_12()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__12__Impl"


    // $ANTLR start "rule__User__Group__13"
    // InternalSM2.g:3837:1: rule__User__Group__13 : rule__User__Group__13__Impl rule__User__Group__14 ;
    public final void rule__User__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3841:1: ( rule__User__Group__13__Impl rule__User__Group__14 )
            // InternalSM2.g:3842:2: rule__User__Group__13__Impl rule__User__Group__14
            {
            pushFollow(FOLLOW_37);
            rule__User__Group__13__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__14();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__13"


    // $ANTLR start "rule__User__Group__13__Impl"
    // InternalSM2.g:3849:1: rule__User__Group__13__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3853:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3854:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3854:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3855:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_13()); 
            }
            // InternalSM2.g:3856:2: ( RULE_EOLINE )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==RULE_EOLINE) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:3856:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_13()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__13__Impl"


    // $ANTLR start "rule__User__Group__14"
    // InternalSM2.g:3864:1: rule__User__Group__14 : rule__User__Group__14__Impl rule__User__Group__15 ;
    public final void rule__User__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3868:1: ( rule__User__Group__14__Impl rule__User__Group__15 )
            // InternalSM2.g:3869:2: rule__User__Group__14__Impl rule__User__Group__15
            {
            pushFollow(FOLLOW_30);
            rule__User__Group__14__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__15();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__14"


    // $ANTLR start "rule__User__Group__14__Impl"
    // InternalSM2.g:3876:1: rule__User__Group__14__Impl : ( 'string' ) ;
    public final void rule__User__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3880:1: ( ( 'string' ) )
            // InternalSM2.g:3881:1: ( 'string' )
            {
            // InternalSM2.g:3881:1: ( 'string' )
            // InternalSM2.g:3882:2: 'string'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getStringKeyword_14()); 
            }
            match(input,34,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getStringKeyword_14()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__14__Impl"


    // $ANTLR start "rule__User__Group__15"
    // InternalSM2.g:3891:1: rule__User__Group__15 : rule__User__Group__15__Impl rule__User__Group__16 ;
    public final void rule__User__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3895:1: ( rule__User__Group__15__Impl rule__User__Group__16 )
            // InternalSM2.g:3896:2: rule__User__Group__15__Impl rule__User__Group__16
            {
            pushFollow(FOLLOW_36);
            rule__User__Group__15__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__16();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__15"


    // $ANTLR start "rule__User__Group__15__Impl"
    // InternalSM2.g:3903:1: rule__User__Group__15__Impl : ( ( rule__User__SurnameAssignment_15 ) ) ;
    public final void rule__User__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3907:1: ( ( ( rule__User__SurnameAssignment_15 ) ) )
            // InternalSM2.g:3908:1: ( ( rule__User__SurnameAssignment_15 ) )
            {
            // InternalSM2.g:3908:1: ( ( rule__User__SurnameAssignment_15 ) )
            // InternalSM2.g:3909:2: ( rule__User__SurnameAssignment_15 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSurnameAssignment_15()); 
            }
            // InternalSM2.g:3910:2: ( rule__User__SurnameAssignment_15 )
            // InternalSM2.g:3910:3: rule__User__SurnameAssignment_15
            {
            pushFollow(FOLLOW_2);
            rule__User__SurnameAssignment_15();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSurnameAssignment_15()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__15__Impl"


    // $ANTLR start "rule__User__Group__16"
    // InternalSM2.g:3918:1: rule__User__Group__16 : rule__User__Group__16__Impl rule__User__Group__17 ;
    public final void rule__User__Group__16() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3922:1: ( rule__User__Group__16__Impl rule__User__Group__17 )
            // InternalSM2.g:3923:2: rule__User__Group__16__Impl rule__User__Group__17
            {
            pushFollow(FOLLOW_36);
            rule__User__Group__16__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__17();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__16"


    // $ANTLR start "rule__User__Group__16__Impl"
    // InternalSM2.g:3930:1: rule__User__Group__16__Impl : ( ( rule__User__Group_16__0 )? ) ;
    public final void rule__User__Group__16__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3934:1: ( ( ( rule__User__Group_16__0 )? ) )
            // InternalSM2.g:3935:1: ( ( rule__User__Group_16__0 )? )
            {
            // InternalSM2.g:3935:1: ( ( rule__User__Group_16__0 )? )
            // InternalSM2.g:3936:2: ( rule__User__Group_16__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getGroup_16()); 
            }
            // InternalSM2.g:3937:2: ( rule__User__Group_16__0 )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==67) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalSM2.g:3937:3: rule__User__Group_16__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__User__Group_16__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getGroup_16()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__16__Impl"


    // $ANTLR start "rule__User__Group__17"
    // InternalSM2.g:3945:1: rule__User__Group__17 : rule__User__Group__17__Impl rule__User__Group__18 ;
    public final void rule__User__Group__17() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3949:1: ( rule__User__Group__17__Impl rule__User__Group__18 )
            // InternalSM2.g:3950:2: rule__User__Group__17__Impl rule__User__Group__18
            {
            pushFollow(FOLLOW_37);
            rule__User__Group__17__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__18();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__17"


    // $ANTLR start "rule__User__Group__17__Impl"
    // InternalSM2.g:3957:1: rule__User__Group__17__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__17__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3961:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3962:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3962:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3963:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_17()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_17()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__17__Impl"


    // $ANTLR start "rule__User__Group__18"
    // InternalSM2.g:3972:1: rule__User__Group__18 : rule__User__Group__18__Impl rule__User__Group__19 ;
    public final void rule__User__Group__18() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3976:1: ( rule__User__Group__18__Impl rule__User__Group__19 )
            // InternalSM2.g:3977:2: rule__User__Group__18__Impl rule__User__Group__19
            {
            pushFollow(FOLLOW_37);
            rule__User__Group__18__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__19();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__18"


    // $ANTLR start "rule__User__Group__18__Impl"
    // InternalSM2.g:3984:1: rule__User__Group__18__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__18__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3988:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3989:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3989:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3990:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_18()); 
            }
            // InternalSM2.g:3991:2: ( RULE_EOLINE )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==RULE_EOLINE) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalSM2.g:3991:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_18()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__18__Impl"


    // $ANTLR start "rule__User__Group__19"
    // InternalSM2.g:3999:1: rule__User__Group__19 : rule__User__Group__19__Impl rule__User__Group__20 ;
    public final void rule__User__Group__19() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4003:1: ( rule__User__Group__19__Impl rule__User__Group__20 )
            // InternalSM2.g:4004:2: rule__User__Group__19__Impl rule__User__Group__20
            {
            pushFollow(FOLLOW_30);
            rule__User__Group__19__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__20();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__19"


    // $ANTLR start "rule__User__Group__19__Impl"
    // InternalSM2.g:4011:1: rule__User__Group__19__Impl : ( 'string' ) ;
    public final void rule__User__Group__19__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4015:1: ( ( 'string' ) )
            // InternalSM2.g:4016:1: ( 'string' )
            {
            // InternalSM2.g:4016:1: ( 'string' )
            // InternalSM2.g:4017:2: 'string'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getStringKeyword_19()); 
            }
            match(input,34,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getStringKeyword_19()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__19__Impl"


    // $ANTLR start "rule__User__Group__20"
    // InternalSM2.g:4026:1: rule__User__Group__20 : rule__User__Group__20__Impl rule__User__Group__21 ;
    public final void rule__User__Group__20() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4030:1: ( rule__User__Group__20__Impl rule__User__Group__21 )
            // InternalSM2.g:4031:2: rule__User__Group__20__Impl rule__User__Group__21
            {
            pushFollow(FOLLOW_36);
            rule__User__Group__20__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__21();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__20"


    // $ANTLR start "rule__User__Group__20__Impl"
    // InternalSM2.g:4038:1: rule__User__Group__20__Impl : ( ( rule__User__EmailAssignment_20 ) ) ;
    public final void rule__User__Group__20__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4042:1: ( ( ( rule__User__EmailAssignment_20 ) ) )
            // InternalSM2.g:4043:1: ( ( rule__User__EmailAssignment_20 ) )
            {
            // InternalSM2.g:4043:1: ( ( rule__User__EmailAssignment_20 ) )
            // InternalSM2.g:4044:2: ( rule__User__EmailAssignment_20 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEmailAssignment_20()); 
            }
            // InternalSM2.g:4045:2: ( rule__User__EmailAssignment_20 )
            // InternalSM2.g:4045:3: rule__User__EmailAssignment_20
            {
            pushFollow(FOLLOW_2);
            rule__User__EmailAssignment_20();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEmailAssignment_20()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__20__Impl"


    // $ANTLR start "rule__User__Group__21"
    // InternalSM2.g:4053:1: rule__User__Group__21 : rule__User__Group__21__Impl rule__User__Group__22 ;
    public final void rule__User__Group__21() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4057:1: ( rule__User__Group__21__Impl rule__User__Group__22 )
            // InternalSM2.g:4058:2: rule__User__Group__21__Impl rule__User__Group__22
            {
            pushFollow(FOLLOW_36);
            rule__User__Group__21__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__22();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__21"


    // $ANTLR start "rule__User__Group__21__Impl"
    // InternalSM2.g:4065:1: rule__User__Group__21__Impl : ( ( rule__User__Group_21__0 )? ) ;
    public final void rule__User__Group__21__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4069:1: ( ( ( rule__User__Group_21__0 )? ) )
            // InternalSM2.g:4070:1: ( ( rule__User__Group_21__0 )? )
            {
            // InternalSM2.g:4070:1: ( ( rule__User__Group_21__0 )? )
            // InternalSM2.g:4071:2: ( rule__User__Group_21__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getGroup_21()); 
            }
            // InternalSM2.g:4072:2: ( rule__User__Group_21__0 )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==67) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // InternalSM2.g:4072:3: rule__User__Group_21__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__User__Group_21__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getGroup_21()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__21__Impl"


    // $ANTLR start "rule__User__Group__22"
    // InternalSM2.g:4080:1: rule__User__Group__22 : rule__User__Group__22__Impl rule__User__Group__23 ;
    public final void rule__User__Group__22() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4084:1: ( rule__User__Group__22__Impl rule__User__Group__23 )
            // InternalSM2.g:4085:2: rule__User__Group__22__Impl rule__User__Group__23
            {
            pushFollow(FOLLOW_38);
            rule__User__Group__22__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__23();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__22"


    // $ANTLR start "rule__User__Group__22__Impl"
    // InternalSM2.g:4092:1: rule__User__Group__22__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__22__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4096:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4097:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4097:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4098:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_22()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_22()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__22__Impl"


    // $ANTLR start "rule__User__Group__23"
    // InternalSM2.g:4107:1: rule__User__Group__23 : rule__User__Group__23__Impl rule__User__Group__24 ;
    public final void rule__User__Group__23() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4111:1: ( rule__User__Group__23__Impl rule__User__Group__24 )
            // InternalSM2.g:4112:2: rule__User__Group__23__Impl rule__User__Group__24
            {
            pushFollow(FOLLOW_38);
            rule__User__Group__23__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__24();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__23"


    // $ANTLR start "rule__User__Group__23__Impl"
    // InternalSM2.g:4119:1: rule__User__Group__23__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__23__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4123:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4124:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4124:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4125:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_23()); 
            }
            // InternalSM2.g:4126:2: ( RULE_EOLINE )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==RULE_EOLINE) ) {
                alt50=1;
            }
            switch (alt50) {
                case 1 :
                    // InternalSM2.g:4126:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_23()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__23__Impl"


    // $ANTLR start "rule__User__Group__24"
    // InternalSM2.g:4134:1: rule__User__Group__24 : rule__User__Group__24__Impl rule__User__Group__25 ;
    public final void rule__User__Group__24() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4138:1: ( rule__User__Group__24__Impl rule__User__Group__25 )
            // InternalSM2.g:4139:2: rule__User__Group__24__Impl rule__User__Group__25
            {
            pushFollow(FOLLOW_30);
            rule__User__Group__24__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__25();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__24"


    // $ANTLR start "rule__User__Group__24__Impl"
    // InternalSM2.g:4146:1: rule__User__Group__24__Impl : ( 'uint' ) ;
    public final void rule__User__Group__24__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4150:1: ( ( 'uint' ) )
            // InternalSM2.g:4151:1: ( 'uint' )
            {
            // InternalSM2.g:4151:1: ( 'uint' )
            // InternalSM2.g:4152:2: 'uint'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getUintKeyword_24()); 
            }
            match(input,31,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getUintKeyword_24()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__24__Impl"


    // $ANTLR start "rule__User__Group__25"
    // InternalSM2.g:4161:1: rule__User__Group__25 : rule__User__Group__25__Impl rule__User__Group__26 ;
    public final void rule__User__Group__25() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4165:1: ( rule__User__Group__25__Impl rule__User__Group__26 )
            // InternalSM2.g:4166:2: rule__User__Group__25__Impl rule__User__Group__26
            {
            pushFollow(FOLLOW_36);
            rule__User__Group__25__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__26();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__25"


    // $ANTLR start "rule__User__Group__25__Impl"
    // InternalSM2.g:4173:1: rule__User__Group__25__Impl : ( ( rule__User__AmountAccountAssignment_25 ) ) ;
    public final void rule__User__Group__25__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4177:1: ( ( ( rule__User__AmountAccountAssignment_25 ) ) )
            // InternalSM2.g:4178:1: ( ( rule__User__AmountAccountAssignment_25 ) )
            {
            // InternalSM2.g:4178:1: ( ( rule__User__AmountAccountAssignment_25 ) )
            // InternalSM2.g:4179:2: ( rule__User__AmountAccountAssignment_25 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getAmountAccountAssignment_25()); 
            }
            // InternalSM2.g:4180:2: ( rule__User__AmountAccountAssignment_25 )
            // InternalSM2.g:4180:3: rule__User__AmountAccountAssignment_25
            {
            pushFollow(FOLLOW_2);
            rule__User__AmountAccountAssignment_25();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getAmountAccountAssignment_25()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__25__Impl"


    // $ANTLR start "rule__User__Group__26"
    // InternalSM2.g:4188:1: rule__User__Group__26 : rule__User__Group__26__Impl rule__User__Group__27 ;
    public final void rule__User__Group__26() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4192:1: ( rule__User__Group__26__Impl rule__User__Group__27 )
            // InternalSM2.g:4193:2: rule__User__Group__26__Impl rule__User__Group__27
            {
            pushFollow(FOLLOW_36);
            rule__User__Group__26__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__27();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__26"


    // $ANTLR start "rule__User__Group__26__Impl"
    // InternalSM2.g:4200:1: rule__User__Group__26__Impl : ( ( rule__User__Group_26__0 )? ) ;
    public final void rule__User__Group__26__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4204:1: ( ( ( rule__User__Group_26__0 )? ) )
            // InternalSM2.g:4205:1: ( ( rule__User__Group_26__0 )? )
            {
            // InternalSM2.g:4205:1: ( ( rule__User__Group_26__0 )? )
            // InternalSM2.g:4206:2: ( rule__User__Group_26__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getGroup_26()); 
            }
            // InternalSM2.g:4207:2: ( rule__User__Group_26__0 )?
            int alt51=2;
            int LA51_0 = input.LA(1);

            if ( (LA51_0==67) ) {
                alt51=1;
            }
            switch (alt51) {
                case 1 :
                    // InternalSM2.g:4207:3: rule__User__Group_26__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__User__Group_26__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getGroup_26()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__26__Impl"


    // $ANTLR start "rule__User__Group__27"
    // InternalSM2.g:4215:1: rule__User__Group__27 : rule__User__Group__27__Impl rule__User__Group__28 ;
    public final void rule__User__Group__27() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4219:1: ( rule__User__Group__27__Impl rule__User__Group__28 )
            // InternalSM2.g:4220:2: rule__User__Group__27__Impl rule__User__Group__28
            {
            pushFollow(FOLLOW_39);
            rule__User__Group__27__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__28();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__27"


    // $ANTLR start "rule__User__Group__27__Impl"
    // InternalSM2.g:4227:1: rule__User__Group__27__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__27__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4231:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4232:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4232:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4233:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_27()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_27()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__27__Impl"


    // $ANTLR start "rule__User__Group__28"
    // InternalSM2.g:4242:1: rule__User__Group__28 : rule__User__Group__28__Impl rule__User__Group__29 ;
    public final void rule__User__Group__28() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4246:1: ( rule__User__Group__28__Impl rule__User__Group__29 )
            // InternalSM2.g:4247:2: rule__User__Group__28__Impl rule__User__Group__29
            {
            pushFollow(FOLLOW_39);
            rule__User__Group__28__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__29();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__28"


    // $ANTLR start "rule__User__Group__28__Impl"
    // InternalSM2.g:4254:1: rule__User__Group__28__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__28__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4258:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4259:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4259:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4260:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_28()); 
            }
            // InternalSM2.g:4261:2: ( RULE_EOLINE )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==RULE_EOLINE) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalSM2.g:4261:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_28()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__28__Impl"


    // $ANTLR start "rule__User__Group__29"
    // InternalSM2.g:4269:1: rule__User__Group__29 : rule__User__Group__29__Impl rule__User__Group__30 ;
    public final void rule__User__Group__29() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4273:1: ( rule__User__Group__29__Impl rule__User__Group__30 )
            // InternalSM2.g:4274:2: rule__User__Group__29__Impl rule__User__Group__30
            {
            pushFollow(FOLLOW_20);
            rule__User__Group__29__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__30();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__29"


    // $ANTLR start "rule__User__Group__29__Impl"
    // InternalSM2.g:4281:1: rule__User__Group__29__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__User__Group__29__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4285:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:4286:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:4286:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:4287:2: RULE_CLOSEKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_29()); 
            }
            match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_29()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__29__Impl"


    // $ANTLR start "rule__User__Group__30"
    // InternalSM2.g:4296:1: rule__User__Group__30 : rule__User__Group__30__Impl ;
    public final void rule__User__Group__30() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4300:1: ( rule__User__Group__30__Impl )
            // InternalSM2.g:4301:2: rule__User__Group__30__Impl
            {
            pushFollow(FOLLOW_2);
            rule__User__Group__30__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__30"


    // $ANTLR start "rule__User__Group__30__Impl"
    // InternalSM2.g:4307:1: rule__User__Group__30__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__30__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4311:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4312:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4312:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4313:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_30()); 
            }
            // InternalSM2.g:4314:2: ( RULE_EOLINE )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==RULE_EOLINE) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // InternalSM2.g:4314:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_30()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__30__Impl"


    // $ANTLR start "rule__User__Group_6__0"
    // InternalSM2.g:4323:1: rule__User__Group_6__0 : rule__User__Group_6__0__Impl rule__User__Group_6__1 ;
    public final void rule__User__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4327:1: ( rule__User__Group_6__0__Impl rule__User__Group_6__1 )
            // InternalSM2.g:4328:2: rule__User__Group_6__0__Impl rule__User__Group_6__1
            {
            pushFollow(FOLLOW_30);
            rule__User__Group_6__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group_6__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_6__0"


    // $ANTLR start "rule__User__Group_6__0__Impl"
    // InternalSM2.g:4335:1: rule__User__Group_6__0__Impl : ( '=' ) ;
    public final void rule__User__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4339:1: ( ( '=' ) )
            // InternalSM2.g:4340:1: ( '=' )
            {
            // InternalSM2.g:4340:1: ( '=' )
            // InternalSM2.g:4341:2: '='
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEqualsSignKeyword_6_0()); 
            }
            match(input,67,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEqualsSignKeyword_6_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_6__0__Impl"


    // $ANTLR start "rule__User__Group_6__1"
    // InternalSM2.g:4350:1: rule__User__Group_6__1 : rule__User__Group_6__1__Impl ;
    public final void rule__User__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4354:1: ( rule__User__Group_6__1__Impl )
            // InternalSM2.g:4355:2: rule__User__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__User__Group_6__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_6__1"


    // $ANTLR start "rule__User__Group_6__1__Impl"
    // InternalSM2.g:4361:1: rule__User__Group_6__1__Impl : ( RULE_STRING ) ;
    public final void rule__User__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4365:1: ( ( RULE_STRING ) )
            // InternalSM2.g:4366:1: ( RULE_STRING )
            {
            // InternalSM2.g:4366:1: ( RULE_STRING )
            // InternalSM2.g:4367:2: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_6_1()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_6_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_6__1__Impl"


    // $ANTLR start "rule__User__Group_11__0"
    // InternalSM2.g:4377:1: rule__User__Group_11__0 : rule__User__Group_11__0__Impl rule__User__Group_11__1 ;
    public final void rule__User__Group_11__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4381:1: ( rule__User__Group_11__0__Impl rule__User__Group_11__1 )
            // InternalSM2.g:4382:2: rule__User__Group_11__0__Impl rule__User__Group_11__1
            {
            pushFollow(FOLLOW_30);
            rule__User__Group_11__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group_11__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_11__0"


    // $ANTLR start "rule__User__Group_11__0__Impl"
    // InternalSM2.g:4389:1: rule__User__Group_11__0__Impl : ( '=' ) ;
    public final void rule__User__Group_11__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4393:1: ( ( '=' ) )
            // InternalSM2.g:4394:1: ( '=' )
            {
            // InternalSM2.g:4394:1: ( '=' )
            // InternalSM2.g:4395:2: '='
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEqualsSignKeyword_11_0()); 
            }
            match(input,67,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEqualsSignKeyword_11_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_11__0__Impl"


    // $ANTLR start "rule__User__Group_11__1"
    // InternalSM2.g:4404:1: rule__User__Group_11__1 : rule__User__Group_11__1__Impl ;
    public final void rule__User__Group_11__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4408:1: ( rule__User__Group_11__1__Impl )
            // InternalSM2.g:4409:2: rule__User__Group_11__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__User__Group_11__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_11__1"


    // $ANTLR start "rule__User__Group_11__1__Impl"
    // InternalSM2.g:4415:1: rule__User__Group_11__1__Impl : ( RULE_STRING ) ;
    public final void rule__User__Group_11__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4419:1: ( ( RULE_STRING ) )
            // InternalSM2.g:4420:1: ( RULE_STRING )
            {
            // InternalSM2.g:4420:1: ( RULE_STRING )
            // InternalSM2.g:4421:2: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_11_1()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_11_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_11__1__Impl"


    // $ANTLR start "rule__User__Group_16__0"
    // InternalSM2.g:4431:1: rule__User__Group_16__0 : rule__User__Group_16__0__Impl rule__User__Group_16__1 ;
    public final void rule__User__Group_16__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4435:1: ( rule__User__Group_16__0__Impl rule__User__Group_16__1 )
            // InternalSM2.g:4436:2: rule__User__Group_16__0__Impl rule__User__Group_16__1
            {
            pushFollow(FOLLOW_30);
            rule__User__Group_16__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group_16__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_16__0"


    // $ANTLR start "rule__User__Group_16__0__Impl"
    // InternalSM2.g:4443:1: rule__User__Group_16__0__Impl : ( '=' ) ;
    public final void rule__User__Group_16__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4447:1: ( ( '=' ) )
            // InternalSM2.g:4448:1: ( '=' )
            {
            // InternalSM2.g:4448:1: ( '=' )
            // InternalSM2.g:4449:2: '='
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEqualsSignKeyword_16_0()); 
            }
            match(input,67,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEqualsSignKeyword_16_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_16__0__Impl"


    // $ANTLR start "rule__User__Group_16__1"
    // InternalSM2.g:4458:1: rule__User__Group_16__1 : rule__User__Group_16__1__Impl ;
    public final void rule__User__Group_16__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4462:1: ( rule__User__Group_16__1__Impl )
            // InternalSM2.g:4463:2: rule__User__Group_16__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__User__Group_16__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_16__1"


    // $ANTLR start "rule__User__Group_16__1__Impl"
    // InternalSM2.g:4469:1: rule__User__Group_16__1__Impl : ( RULE_STRING ) ;
    public final void rule__User__Group_16__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4473:1: ( ( RULE_STRING ) )
            // InternalSM2.g:4474:1: ( RULE_STRING )
            {
            // InternalSM2.g:4474:1: ( RULE_STRING )
            // InternalSM2.g:4475:2: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_16_1()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_16_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_16__1__Impl"


    // $ANTLR start "rule__User__Group_21__0"
    // InternalSM2.g:4485:1: rule__User__Group_21__0 : rule__User__Group_21__0__Impl rule__User__Group_21__1 ;
    public final void rule__User__Group_21__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4489:1: ( rule__User__Group_21__0__Impl rule__User__Group_21__1 )
            // InternalSM2.g:4490:2: rule__User__Group_21__0__Impl rule__User__Group_21__1
            {
            pushFollow(FOLLOW_40);
            rule__User__Group_21__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group_21__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_21__0"


    // $ANTLR start "rule__User__Group_21__0__Impl"
    // InternalSM2.g:4497:1: rule__User__Group_21__0__Impl : ( '=' ) ;
    public final void rule__User__Group_21__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4501:1: ( ( '=' ) )
            // InternalSM2.g:4502:1: ( '=' )
            {
            // InternalSM2.g:4502:1: ( '=' )
            // InternalSM2.g:4503:2: '='
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEqualsSignKeyword_21_0()); 
            }
            match(input,67,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEqualsSignKeyword_21_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_21__0__Impl"


    // $ANTLR start "rule__User__Group_21__1"
    // InternalSM2.g:4512:1: rule__User__Group_21__1 : rule__User__Group_21__1__Impl ;
    public final void rule__User__Group_21__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4516:1: ( rule__User__Group_21__1__Impl )
            // InternalSM2.g:4517:2: rule__User__Group_21__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__User__Group_21__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_21__1"


    // $ANTLR start "rule__User__Group_21__1__Impl"
    // InternalSM2.g:4523:1: rule__User__Group_21__1__Impl : ( RULE_EMAIL ) ;
    public final void rule__User__Group_21__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4527:1: ( ( RULE_EMAIL ) )
            // InternalSM2.g:4528:1: ( RULE_EMAIL )
            {
            // InternalSM2.g:4528:1: ( RULE_EMAIL )
            // InternalSM2.g:4529:2: RULE_EMAIL
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEMAILTerminalRuleCall_21_1()); 
            }
            match(input,RULE_EMAIL,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEMAILTerminalRuleCall_21_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_21__1__Impl"


    // $ANTLR start "rule__User__Group_26__0"
    // InternalSM2.g:4539:1: rule__User__Group_26__0 : rule__User__Group_26__0__Impl rule__User__Group_26__1 ;
    public final void rule__User__Group_26__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4543:1: ( rule__User__Group_26__0__Impl rule__User__Group_26__1 )
            // InternalSM2.g:4544:2: rule__User__Group_26__0__Impl rule__User__Group_26__1
            {
            pushFollow(FOLLOW_16);
            rule__User__Group_26__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group_26__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_26__0"


    // $ANTLR start "rule__User__Group_26__0__Impl"
    // InternalSM2.g:4551:1: rule__User__Group_26__0__Impl : ( '=' ) ;
    public final void rule__User__Group_26__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4555:1: ( ( '=' ) )
            // InternalSM2.g:4556:1: ( '=' )
            {
            // InternalSM2.g:4556:1: ( '=' )
            // InternalSM2.g:4557:2: '='
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEqualsSignKeyword_26_0()); 
            }
            match(input,67,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEqualsSignKeyword_26_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_26__0__Impl"


    // $ANTLR start "rule__User__Group_26__1"
    // InternalSM2.g:4566:1: rule__User__Group_26__1 : rule__User__Group_26__1__Impl ;
    public final void rule__User__Group_26__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4570:1: ( rule__User__Group_26__1__Impl )
            // InternalSM2.g:4571:2: rule__User__Group_26__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__User__Group_26__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_26__1"


    // $ANTLR start "rule__User__Group_26__1__Impl"
    // InternalSM2.g:4577:1: rule__User__Group_26__1__Impl : ( RULE_NUMBER ) ;
    public final void rule__User__Group_26__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4581:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:4582:1: ( RULE_NUMBER )
            {
            // InternalSM2.g:4582:1: ( RULE_NUMBER )
            // InternalSM2.g:4583:2: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getNUMBERTerminalRuleCall_26_1()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getNUMBERTerminalRuleCall_26_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_26__1__Impl"


    // $ANTLR start "rule__Enum__Group__0"
    // InternalSM2.g:4593:1: rule__Enum__Group__0 : rule__Enum__Group__0__Impl rule__Enum__Group__1 ;
    public final void rule__Enum__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4597:1: ( rule__Enum__Group__0__Impl rule__Enum__Group__1 )
            // InternalSM2.g:4598:2: rule__Enum__Group__0__Impl rule__Enum__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Enum__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Enum__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__0"


    // $ANTLR start "rule__Enum__Group__0__Impl"
    // InternalSM2.g:4605:1: rule__Enum__Group__0__Impl : ( 'enum' ) ;
    public final void rule__Enum__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4609:1: ( ( 'enum' ) )
            // InternalSM2.g:4610:1: ( 'enum' )
            {
            // InternalSM2.g:4610:1: ( 'enum' )
            // InternalSM2.g:4611:2: 'enum'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getEnumKeyword_0()); 
            }
            match(input,68,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getEnumKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__0__Impl"


    // $ANTLR start "rule__Enum__Group__1"
    // InternalSM2.g:4620:1: rule__Enum__Group__1 : rule__Enum__Group__1__Impl rule__Enum__Group__2 ;
    public final void rule__Enum__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4624:1: ( rule__Enum__Group__1__Impl rule__Enum__Group__2 )
            // InternalSM2.g:4625:2: rule__Enum__Group__1__Impl rule__Enum__Group__2
            {
            pushFollow(FOLLOW_24);
            rule__Enum__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Enum__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__1"


    // $ANTLR start "rule__Enum__Group__1__Impl"
    // InternalSM2.g:4632:1: rule__Enum__Group__1__Impl : ( ( rule__Enum__NameEnumAssignment_1 ) ) ;
    public final void rule__Enum__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4636:1: ( ( ( rule__Enum__NameEnumAssignment_1 ) ) )
            // InternalSM2.g:4637:1: ( ( rule__Enum__NameEnumAssignment_1 ) )
            {
            // InternalSM2.g:4637:1: ( ( rule__Enum__NameEnumAssignment_1 ) )
            // InternalSM2.g:4638:2: ( rule__Enum__NameEnumAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getNameEnumAssignment_1()); 
            }
            // InternalSM2.g:4639:2: ( rule__Enum__NameEnumAssignment_1 )
            // InternalSM2.g:4639:3: rule__Enum__NameEnumAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Enum__NameEnumAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getNameEnumAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__1__Impl"


    // $ANTLR start "rule__Enum__Group__2"
    // InternalSM2.g:4647:1: rule__Enum__Group__2 : rule__Enum__Group__2__Impl rule__Enum__Group__3 ;
    public final void rule__Enum__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4651:1: ( rule__Enum__Group__2__Impl rule__Enum__Group__3 )
            // InternalSM2.g:4652:2: rule__Enum__Group__2__Impl rule__Enum__Group__3
            {
            pushFollow(FOLLOW_30);
            rule__Enum__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Enum__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__2"


    // $ANTLR start "rule__Enum__Group__2__Impl"
    // InternalSM2.g:4659:1: rule__Enum__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Enum__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4663:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:4664:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:4664:1: ( RULE_OPENKEY )
            // InternalSM2.g:4665:2: RULE_OPENKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2()); 
            }
            match(input,RULE_OPENKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__2__Impl"


    // $ANTLR start "rule__Enum__Group__3"
    // InternalSM2.g:4674:1: rule__Enum__Group__3 : rule__Enum__Group__3__Impl rule__Enum__Group__4 ;
    public final void rule__Enum__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4678:1: ( rule__Enum__Group__3__Impl rule__Enum__Group__4 )
            // InternalSM2.g:4679:2: rule__Enum__Group__3__Impl rule__Enum__Group__4
            {
            pushFollow(FOLLOW_27);
            rule__Enum__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Enum__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__3"


    // $ANTLR start "rule__Enum__Group__3__Impl"
    // InternalSM2.g:4686:1: rule__Enum__Group__3__Impl : ( ( ( rule__Enum__Group_3__0 ) ) ( ( rule__Enum__Group_3__0 )* ) ) ;
    public final void rule__Enum__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4690:1: ( ( ( ( rule__Enum__Group_3__0 ) ) ( ( rule__Enum__Group_3__0 )* ) ) )
            // InternalSM2.g:4691:1: ( ( ( rule__Enum__Group_3__0 ) ) ( ( rule__Enum__Group_3__0 )* ) )
            {
            // InternalSM2.g:4691:1: ( ( ( rule__Enum__Group_3__0 ) ) ( ( rule__Enum__Group_3__0 )* ) )
            // InternalSM2.g:4692:2: ( ( rule__Enum__Group_3__0 ) ) ( ( rule__Enum__Group_3__0 )* )
            {
            // InternalSM2.g:4692:2: ( ( rule__Enum__Group_3__0 ) )
            // InternalSM2.g:4693:3: ( rule__Enum__Group_3__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getGroup_3()); 
            }
            // InternalSM2.g:4694:3: ( rule__Enum__Group_3__0 )
            // InternalSM2.g:4694:4: rule__Enum__Group_3__0
            {
            pushFollow(FOLLOW_41);
            rule__Enum__Group_3__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getGroup_3()); 
            }

            }

            // InternalSM2.g:4697:2: ( ( rule__Enum__Group_3__0 )* )
            // InternalSM2.g:4698:3: ( rule__Enum__Group_3__0 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getGroup_3()); 
            }
            // InternalSM2.g:4699:3: ( rule__Enum__Group_3__0 )*
            loop54:
            do {
                int alt54=2;
                int LA54_0 = input.LA(1);

                if ( (LA54_0==RULE_STRING) ) {
                    alt54=1;
                }


                switch (alt54) {
            	case 1 :
            	    // InternalSM2.g:4699:4: rule__Enum__Group_3__0
            	    {
            	    pushFollow(FOLLOW_41);
            	    rule__Enum__Group_3__0();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop54;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getGroup_3()); 
            }

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__3__Impl"


    // $ANTLR start "rule__Enum__Group__4"
    // InternalSM2.g:4708:1: rule__Enum__Group__4 : rule__Enum__Group__4__Impl rule__Enum__Group__5 ;
    public final void rule__Enum__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4712:1: ( rule__Enum__Group__4__Impl rule__Enum__Group__5 )
            // InternalSM2.g:4713:2: rule__Enum__Group__4__Impl rule__Enum__Group__5
            {
            pushFollow(FOLLOW_5);
            rule__Enum__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Enum__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__4"


    // $ANTLR start "rule__Enum__Group__4__Impl"
    // InternalSM2.g:4720:1: rule__Enum__Group__4__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Enum__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4724:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:4725:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:4725:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:4726:2: RULE_CLOSEKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_4()); 
            }
            match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__4__Impl"


    // $ANTLR start "rule__Enum__Group__5"
    // InternalSM2.g:4735:1: rule__Enum__Group__5 : rule__Enum__Group__5__Impl rule__Enum__Group__6 ;
    public final void rule__Enum__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4739:1: ( rule__Enum__Group__5__Impl rule__Enum__Group__6 )
            // InternalSM2.g:4740:2: rule__Enum__Group__5__Impl rule__Enum__Group__6
            {
            pushFollow(FOLLOW_20);
            rule__Enum__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Enum__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__5"


    // $ANTLR start "rule__Enum__Group__5__Impl"
    // InternalSM2.g:4747:1: rule__Enum__Group__5__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Enum__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4751:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4752:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4752:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4753:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_5()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__5__Impl"


    // $ANTLR start "rule__Enum__Group__6"
    // InternalSM2.g:4762:1: rule__Enum__Group__6 : rule__Enum__Group__6__Impl ;
    public final void rule__Enum__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4766:1: ( rule__Enum__Group__6__Impl )
            // InternalSM2.g:4767:2: rule__Enum__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Enum__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__6"


    // $ANTLR start "rule__Enum__Group__6__Impl"
    // InternalSM2.g:4773:1: rule__Enum__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Enum__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4777:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4778:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4778:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4779:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_6()); 
            }
            // InternalSM2.g:4780:2: ( RULE_EOLINE )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==RULE_EOLINE) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // InternalSM2.g:4780:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__6__Impl"


    // $ANTLR start "rule__Enum__Group_3__0"
    // InternalSM2.g:4789:1: rule__Enum__Group_3__0 : rule__Enum__Group_3__0__Impl rule__Enum__Group_3__1 ;
    public final void rule__Enum__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4793:1: ( rule__Enum__Group_3__0__Impl rule__Enum__Group_3__1 )
            // InternalSM2.g:4794:2: rule__Enum__Group_3__0__Impl rule__Enum__Group_3__1
            {
            pushFollow(FOLLOW_42);
            rule__Enum__Group_3__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Enum__Group_3__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group_3__0"


    // $ANTLR start "rule__Enum__Group_3__0__Impl"
    // InternalSM2.g:4801:1: rule__Enum__Group_3__0__Impl : ( RULE_STRING ) ;
    public final void rule__Enum__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4805:1: ( ( RULE_STRING ) )
            // InternalSM2.g:4806:1: ( RULE_STRING )
            {
            // InternalSM2.g:4806:1: ( RULE_STRING )
            // InternalSM2.g:4807:2: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getSTRINGTerminalRuleCall_3_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getSTRINGTerminalRuleCall_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group_3__0__Impl"


    // $ANTLR start "rule__Enum__Group_3__1"
    // InternalSM2.g:4816:1: rule__Enum__Group_3__1 : rule__Enum__Group_3__1__Impl ;
    public final void rule__Enum__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4820:1: ( rule__Enum__Group_3__1__Impl )
            // InternalSM2.g:4821:2: rule__Enum__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Enum__Group_3__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group_3__1"


    // $ANTLR start "rule__Enum__Group_3__1__Impl"
    // InternalSM2.g:4827:1: rule__Enum__Group_3__1__Impl : ( ( RULE_COMMA )? ) ;
    public final void rule__Enum__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4831:1: ( ( ( RULE_COMMA )? ) )
            // InternalSM2.g:4832:1: ( ( RULE_COMMA )? )
            {
            // InternalSM2.g:4832:1: ( ( RULE_COMMA )? )
            // InternalSM2.g:4833:2: ( RULE_COMMA )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_3_1()); 
            }
            // InternalSM2.g:4834:2: ( RULE_COMMA )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==RULE_COMMA) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalSM2.g:4834:3: RULE_COMMA
                    {
                    match(input,RULE_COMMA,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_3_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group_3__1__Impl"


    // $ANTLR start "rule__Property__Group__0"
    // InternalSM2.g:4843:1: rule__Property__Group__0 : rule__Property__Group__0__Impl rule__Property__Group__1 ;
    public final void rule__Property__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4847:1: ( rule__Property__Group__0__Impl rule__Property__Group__1 )
            // InternalSM2.g:4848:2: rule__Property__Group__0__Impl rule__Property__Group__1
            {
            pushFollow(FOLLOW_32);
            rule__Property__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Property__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__0"


    // $ANTLR start "rule__Property__Group__0__Impl"
    // InternalSM2.g:4855:1: rule__Property__Group__0__Impl : ( ( rule__Property__TypeAssignment_0 ) ) ;
    public final void rule__Property__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4859:1: ( ( ( rule__Property__TypeAssignment_0 ) ) )
            // InternalSM2.g:4860:1: ( ( rule__Property__TypeAssignment_0 ) )
            {
            // InternalSM2.g:4860:1: ( ( rule__Property__TypeAssignment_0 ) )
            // InternalSM2.g:4861:2: ( rule__Property__TypeAssignment_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getTypeAssignment_0()); 
            }
            // InternalSM2.g:4862:2: ( rule__Property__TypeAssignment_0 )
            // InternalSM2.g:4862:3: rule__Property__TypeAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Property__TypeAssignment_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getTypeAssignment_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__0__Impl"


    // $ANTLR start "rule__Property__Group__1"
    // InternalSM2.g:4870:1: rule__Property__Group__1 : rule__Property__Group__1__Impl rule__Property__Group__2 ;
    public final void rule__Property__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4874:1: ( rule__Property__Group__1__Impl rule__Property__Group__2 )
            // InternalSM2.g:4875:2: rule__Property__Group__1__Impl rule__Property__Group__2
            {
            pushFollow(FOLLOW_32);
            rule__Property__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Property__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__1"


    // $ANTLR start "rule__Property__Group__1__Impl"
    // InternalSM2.g:4882:1: rule__Property__Group__1__Impl : ( ( rule__Property__VisibilityAssignment_1 )? ) ;
    public final void rule__Property__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4886:1: ( ( ( rule__Property__VisibilityAssignment_1 )? ) )
            // InternalSM2.g:4887:1: ( ( rule__Property__VisibilityAssignment_1 )? )
            {
            // InternalSM2.g:4887:1: ( ( rule__Property__VisibilityAssignment_1 )? )
            // InternalSM2.g:4888:2: ( rule__Property__VisibilityAssignment_1 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getVisibilityAssignment_1()); 
            }
            // InternalSM2.g:4889:2: ( rule__Property__VisibilityAssignment_1 )?
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( ((LA57_0>=39 && LA57_0<=42)) ) {
                alt57=1;
            }
            switch (alt57) {
                case 1 :
                    // InternalSM2.g:4889:3: rule__Property__VisibilityAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__VisibilityAssignment_1();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getVisibilityAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__1__Impl"


    // $ANTLR start "rule__Property__Group__2"
    // InternalSM2.g:4897:1: rule__Property__Group__2 : rule__Property__Group__2__Impl rule__Property__Group__3 ;
    public final void rule__Property__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4901:1: ( rule__Property__Group__2__Impl rule__Property__Group__3 )
            // InternalSM2.g:4902:2: rule__Property__Group__2__Impl rule__Property__Group__3
            {
            pushFollow(FOLLOW_43);
            rule__Property__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Property__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__2"


    // $ANTLR start "rule__Property__Group__2__Impl"
    // InternalSM2.g:4909:1: rule__Property__Group__2__Impl : ( ( rule__Property__NamePropertyAssignment_2 ) ) ;
    public final void rule__Property__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4913:1: ( ( ( rule__Property__NamePropertyAssignment_2 ) ) )
            // InternalSM2.g:4914:1: ( ( rule__Property__NamePropertyAssignment_2 ) )
            {
            // InternalSM2.g:4914:1: ( ( rule__Property__NamePropertyAssignment_2 ) )
            // InternalSM2.g:4915:2: ( rule__Property__NamePropertyAssignment_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getNamePropertyAssignment_2()); 
            }
            // InternalSM2.g:4916:2: ( rule__Property__NamePropertyAssignment_2 )
            // InternalSM2.g:4916:3: rule__Property__NamePropertyAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Property__NamePropertyAssignment_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getNamePropertyAssignment_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__2__Impl"


    // $ANTLR start "rule__Property__Group__3"
    // InternalSM2.g:4924:1: rule__Property__Group__3 : rule__Property__Group__3__Impl rule__Property__Group__4 ;
    public final void rule__Property__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4928:1: ( rule__Property__Group__3__Impl rule__Property__Group__4 )
            // InternalSM2.g:4929:2: rule__Property__Group__3__Impl rule__Property__Group__4
            {
            pushFollow(FOLLOW_44);
            rule__Property__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Property__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__3"


    // $ANTLR start "rule__Property__Group__3__Impl"
    // InternalSM2.g:4936:1: rule__Property__Group__3__Impl : ( '=' ) ;
    public final void rule__Property__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4940:1: ( ( '=' ) )
            // InternalSM2.g:4941:1: ( '=' )
            {
            // InternalSM2.g:4941:1: ( '=' )
            // InternalSM2.g:4942:2: '='
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getEqualsSignKeyword_3()); 
            }
            match(input,67,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getEqualsSignKeyword_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__3__Impl"


    // $ANTLR start "rule__Property__Group__4"
    // InternalSM2.g:4951:1: rule__Property__Group__4 : rule__Property__Group__4__Impl rule__Property__Group__5 ;
    public final void rule__Property__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4955:1: ( rule__Property__Group__4__Impl rule__Property__Group__5 )
            // InternalSM2.g:4956:2: rule__Property__Group__4__Impl rule__Property__Group__5
            {
            pushFollow(FOLLOW_44);
            rule__Property__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Property__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__4"


    // $ANTLR start "rule__Property__Group__4__Impl"
    // InternalSM2.g:4963:1: rule__Property__Group__4__Impl : ( ( rule__Property__Alternatives_4 )? ) ;
    public final void rule__Property__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4967:1: ( ( ( rule__Property__Alternatives_4 )? ) )
            // InternalSM2.g:4968:1: ( ( rule__Property__Alternatives_4 )? )
            {
            // InternalSM2.g:4968:1: ( ( rule__Property__Alternatives_4 )? )
            // InternalSM2.g:4969:2: ( rule__Property__Alternatives_4 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getAlternatives_4()); 
            }
            // InternalSM2.g:4970:2: ( rule__Property__Alternatives_4 )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( ((LA58_0>=RULE_INT && LA58_0<=RULE_STRING)) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // InternalSM2.g:4970:3: rule__Property__Alternatives_4
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__Alternatives_4();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getAlternatives_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__4__Impl"


    // $ANTLR start "rule__Property__Group__5"
    // InternalSM2.g:4978:1: rule__Property__Group__5 : rule__Property__Group__5__Impl rule__Property__Group__6 ;
    public final void rule__Property__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4982:1: ( rule__Property__Group__5__Impl rule__Property__Group__6 )
            // InternalSM2.g:4983:2: rule__Property__Group__5__Impl rule__Property__Group__6
            {
            pushFollow(FOLLOW_20);
            rule__Property__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Property__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__5"


    // $ANTLR start "rule__Property__Group__5__Impl"
    // InternalSM2.g:4990:1: rule__Property__Group__5__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Property__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4994:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4995:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4995:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4996:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_5()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__5__Impl"


    // $ANTLR start "rule__Property__Group__6"
    // InternalSM2.g:5005:1: rule__Property__Group__6 : rule__Property__Group__6__Impl ;
    public final void rule__Property__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5009:1: ( rule__Property__Group__6__Impl )
            // InternalSM2.g:5010:2: rule__Property__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Property__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__6"


    // $ANTLR start "rule__Property__Group__6__Impl"
    // InternalSM2.g:5016:1: rule__Property__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Property__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5020:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:5021:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:5021:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:5022:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6()); 
            }
            // InternalSM2.g:5023:2: ( RULE_EOLINE )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==RULE_EOLINE) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // InternalSM2.g:5023:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__6__Impl"


    // $ANTLR start "rule__InputParam__Group__0"
    // InternalSM2.g:5032:1: rule__InputParam__Group__0 : rule__InputParam__Group__0__Impl rule__InputParam__Group__1 ;
    public final void rule__InputParam__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5036:1: ( rule__InputParam__Group__0__Impl rule__InputParam__Group__1 )
            // InternalSM2.g:5037:2: rule__InputParam__Group__0__Impl rule__InputParam__Group__1
            {
            pushFollow(FOLLOW_42);
            rule__InputParam__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__InputParam__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__0"


    // $ANTLR start "rule__InputParam__Group__0__Impl"
    // InternalSM2.g:5044:1: rule__InputParam__Group__0__Impl : ( ( rule__InputParam__Group_0__0 ) ) ;
    public final void rule__InputParam__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5048:1: ( ( ( rule__InputParam__Group_0__0 ) ) )
            // InternalSM2.g:5049:1: ( ( rule__InputParam__Group_0__0 ) )
            {
            // InternalSM2.g:5049:1: ( ( rule__InputParam__Group_0__0 ) )
            // InternalSM2.g:5050:2: ( rule__InputParam__Group_0__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getGroup_0()); 
            }
            // InternalSM2.g:5051:2: ( rule__InputParam__Group_0__0 )
            // InternalSM2.g:5051:3: rule__InputParam__Group_0__0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getGroup_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__0__Impl"


    // $ANTLR start "rule__InputParam__Group__1"
    // InternalSM2.g:5059:1: rule__InputParam__Group__1 : rule__InputParam__Group__1__Impl ;
    public final void rule__InputParam__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5063:1: ( rule__InputParam__Group__1__Impl )
            // InternalSM2.g:5064:2: rule__InputParam__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__1"


    // $ANTLR start "rule__InputParam__Group__1__Impl"
    // InternalSM2.g:5070:1: rule__InputParam__Group__1__Impl : ( ( rule__InputParam__CommaAssignment_1 )? ) ;
    public final void rule__InputParam__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5074:1: ( ( ( rule__InputParam__CommaAssignment_1 )? ) )
            // InternalSM2.g:5075:1: ( ( rule__InputParam__CommaAssignment_1 )? )
            {
            // InternalSM2.g:5075:1: ( ( rule__InputParam__CommaAssignment_1 )? )
            // InternalSM2.g:5076:2: ( rule__InputParam__CommaAssignment_1 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getCommaAssignment_1()); 
            }
            // InternalSM2.g:5077:2: ( rule__InputParam__CommaAssignment_1 )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==RULE_COMMA) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // InternalSM2.g:5077:3: rule__InputParam__CommaAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__InputParam__CommaAssignment_1();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getCommaAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__1__Impl"


    // $ANTLR start "rule__InputParam__Group_0__0"
    // InternalSM2.g:5086:1: rule__InputParam__Group_0__0 : rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1 ;
    public final void rule__InputParam__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5090:1: ( rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1 )
            // InternalSM2.g:5091:2: rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1
            {
            pushFollow(FOLLOW_8);
            rule__InputParam__Group_0__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__0"


    // $ANTLR start "rule__InputParam__Group_0__0__Impl"
    // InternalSM2.g:5098:1: rule__InputParam__Group_0__0__Impl : ( ( rule__InputParam__TypeAssignment_0_0 ) ) ;
    public final void rule__InputParam__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5102:1: ( ( ( rule__InputParam__TypeAssignment_0_0 ) ) )
            // InternalSM2.g:5103:1: ( ( rule__InputParam__TypeAssignment_0_0 ) )
            {
            // InternalSM2.g:5103:1: ( ( rule__InputParam__TypeAssignment_0_0 ) )
            // InternalSM2.g:5104:2: ( rule__InputParam__TypeAssignment_0_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getTypeAssignment_0_0()); 
            }
            // InternalSM2.g:5105:2: ( rule__InputParam__TypeAssignment_0_0 )
            // InternalSM2.g:5105:3: rule__InputParam__TypeAssignment_0_0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__TypeAssignment_0_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getTypeAssignment_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__0__Impl"


    // $ANTLR start "rule__InputParam__Group_0__1"
    // InternalSM2.g:5113:1: rule__InputParam__Group_0__1 : rule__InputParam__Group_0__1__Impl ;
    public final void rule__InputParam__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5117:1: ( rule__InputParam__Group_0__1__Impl )
            // InternalSM2.g:5118:2: rule__InputParam__Group_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__1"


    // $ANTLR start "rule__InputParam__Group_0__1__Impl"
    // InternalSM2.g:5124:1: rule__InputParam__Group_0__1__Impl : ( ( rule__InputParam__NameParamAssignment_0_1 ) ) ;
    public final void rule__InputParam__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5128:1: ( ( ( rule__InputParam__NameParamAssignment_0_1 ) ) )
            // InternalSM2.g:5129:1: ( ( rule__InputParam__NameParamAssignment_0_1 ) )
            {
            // InternalSM2.g:5129:1: ( ( rule__InputParam__NameParamAssignment_0_1 ) )
            // InternalSM2.g:5130:2: ( rule__InputParam__NameParamAssignment_0_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getNameParamAssignment_0_1()); 
            }
            // InternalSM2.g:5131:2: ( rule__InputParam__NameParamAssignment_0_1 )
            // InternalSM2.g:5131:3: rule__InputParam__NameParamAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__NameParamAssignment_0_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getNameParamAssignment_0_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__1__Impl"


    // $ANTLR start "rule__Restriction__Group__0"
    // InternalSM2.g:5140:1: rule__Restriction__Group__0 : rule__Restriction__Group__0__Impl rule__Restriction__Group__1 ;
    public final void rule__Restriction__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5144:1: ( rule__Restriction__Group__0__Impl rule__Restriction__Group__1 )
            // InternalSM2.g:5145:2: rule__Restriction__Group__0__Impl rule__Restriction__Group__1
            {
            pushFollow(FOLLOW_21);
            rule__Restriction__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__0"


    // $ANTLR start "rule__Restriction__Group__0__Impl"
    // InternalSM2.g:5152:1: rule__Restriction__Group__0__Impl : ( 'require' ) ;
    public final void rule__Restriction__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5156:1: ( ( 'require' ) )
            // InternalSM2.g:5157:1: ( 'require' )
            {
            // InternalSM2.g:5157:1: ( 'require' )
            // InternalSM2.g:5158:2: 'require'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getRequireKeyword_0()); 
            }
            match(input,69,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getRequireKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__0__Impl"


    // $ANTLR start "rule__Restriction__Group__1"
    // InternalSM2.g:5167:1: rule__Restriction__Group__1 : rule__Restriction__Group__1__Impl rule__Restriction__Group__2 ;
    public final void rule__Restriction__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5171:1: ( rule__Restriction__Group__1__Impl rule__Restriction__Group__2 )
            // InternalSM2.g:5172:2: rule__Restriction__Group__1__Impl rule__Restriction__Group__2
            {
            pushFollow(FOLLOW_45);
            rule__Restriction__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__1"


    // $ANTLR start "rule__Restriction__Group__1__Impl"
    // InternalSM2.g:5179:1: rule__Restriction__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Restriction__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5183:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:5184:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:5184:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:5185:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__1__Impl"


    // $ANTLR start "rule__Restriction__Group__2"
    // InternalSM2.g:5194:1: rule__Restriction__Group__2 : rule__Restriction__Group__2__Impl rule__Restriction__Group__3 ;
    public final void rule__Restriction__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5198:1: ( rule__Restriction__Group__2__Impl rule__Restriction__Group__3 )
            // InternalSM2.g:5199:2: rule__Restriction__Group__2__Impl rule__Restriction__Group__3
            {
            pushFollow(FOLLOW_46);
            rule__Restriction__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__2"


    // $ANTLR start "rule__Restriction__Group__2__Impl"
    // InternalSM2.g:5206:1: rule__Restriction__Group__2__Impl : ( ( rule__Restriction__Expr1Assignment_2 ) ) ;
    public final void rule__Restriction__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5210:1: ( ( ( rule__Restriction__Expr1Assignment_2 ) ) )
            // InternalSM2.g:5211:1: ( ( rule__Restriction__Expr1Assignment_2 ) )
            {
            // InternalSM2.g:5211:1: ( ( rule__Restriction__Expr1Assignment_2 ) )
            // InternalSM2.g:5212:2: ( rule__Restriction__Expr1Assignment_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getExpr1Assignment_2()); 
            }
            // InternalSM2.g:5213:2: ( rule__Restriction__Expr1Assignment_2 )
            // InternalSM2.g:5213:3: rule__Restriction__Expr1Assignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Expr1Assignment_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getExpr1Assignment_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__2__Impl"


    // $ANTLR start "rule__Restriction__Group__3"
    // InternalSM2.g:5221:1: rule__Restriction__Group__3 : rule__Restriction__Group__3__Impl rule__Restriction__Group__4 ;
    public final void rule__Restriction__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5225:1: ( rule__Restriction__Group__3__Impl rule__Restriction__Group__4 )
            // InternalSM2.g:5226:2: rule__Restriction__Group__3__Impl rule__Restriction__Group__4
            {
            pushFollow(FOLLOW_45);
            rule__Restriction__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__3"


    // $ANTLR start "rule__Restriction__Group__3__Impl"
    // InternalSM2.g:5233:1: rule__Restriction__Group__3__Impl : ( ( rule__Restriction__OperatorAssignment_3 ) ) ;
    public final void rule__Restriction__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5237:1: ( ( ( rule__Restriction__OperatorAssignment_3 ) ) )
            // InternalSM2.g:5238:1: ( ( rule__Restriction__OperatorAssignment_3 ) )
            {
            // InternalSM2.g:5238:1: ( ( rule__Restriction__OperatorAssignment_3 ) )
            // InternalSM2.g:5239:2: ( rule__Restriction__OperatorAssignment_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getOperatorAssignment_3()); 
            }
            // InternalSM2.g:5240:2: ( rule__Restriction__OperatorAssignment_3 )
            // InternalSM2.g:5240:3: rule__Restriction__OperatorAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__OperatorAssignment_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getOperatorAssignment_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__3__Impl"


    // $ANTLR start "rule__Restriction__Group__4"
    // InternalSM2.g:5248:1: rule__Restriction__Group__4 : rule__Restriction__Group__4__Impl rule__Restriction__Group__5 ;
    public final void rule__Restriction__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5252:1: ( rule__Restriction__Group__4__Impl rule__Restriction__Group__5 )
            // InternalSM2.g:5253:2: rule__Restriction__Group__4__Impl rule__Restriction__Group__5
            {
            pushFollow(FOLLOW_31);
            rule__Restriction__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__4"


    // $ANTLR start "rule__Restriction__Group__4__Impl"
    // InternalSM2.g:5260:1: rule__Restriction__Group__4__Impl : ( ( rule__Restriction__Expr2Assignment_4 ) ) ;
    public final void rule__Restriction__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5264:1: ( ( ( rule__Restriction__Expr2Assignment_4 ) ) )
            // InternalSM2.g:5265:1: ( ( rule__Restriction__Expr2Assignment_4 ) )
            {
            // InternalSM2.g:5265:1: ( ( rule__Restriction__Expr2Assignment_4 ) )
            // InternalSM2.g:5266:2: ( rule__Restriction__Expr2Assignment_4 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getExpr2Assignment_4()); 
            }
            // InternalSM2.g:5267:2: ( rule__Restriction__Expr2Assignment_4 )
            // InternalSM2.g:5267:3: rule__Restriction__Expr2Assignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Expr2Assignment_4();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getExpr2Assignment_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__4__Impl"


    // $ANTLR start "rule__Restriction__Group__5"
    // InternalSM2.g:5275:1: rule__Restriction__Group__5 : rule__Restriction__Group__5__Impl rule__Restriction__Group__6 ;
    public final void rule__Restriction__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5279:1: ( rule__Restriction__Group__5__Impl rule__Restriction__Group__6 )
            // InternalSM2.g:5280:2: rule__Restriction__Group__5__Impl rule__Restriction__Group__6
            {
            pushFollow(FOLLOW_5);
            rule__Restriction__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__5"


    // $ANTLR start "rule__Restriction__Group__5__Impl"
    // InternalSM2.g:5287:1: rule__Restriction__Group__5__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Restriction__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5291:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:5292:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:5292:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:5293:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__5__Impl"


    // $ANTLR start "rule__Restriction__Group__6"
    // InternalSM2.g:5302:1: rule__Restriction__Group__6 : rule__Restriction__Group__6__Impl rule__Restriction__Group__7 ;
    public final void rule__Restriction__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5306:1: ( rule__Restriction__Group__6__Impl rule__Restriction__Group__7 )
            // InternalSM2.g:5307:2: rule__Restriction__Group__6__Impl rule__Restriction__Group__7
            {
            pushFollow(FOLLOW_20);
            rule__Restriction__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__6"


    // $ANTLR start "rule__Restriction__Group__6__Impl"
    // InternalSM2.g:5314:1: rule__Restriction__Group__6__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Restriction__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5318:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:5319:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:5319:1: ( RULE_SEMICOLON )
            // InternalSM2.g:5320:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__6__Impl"


    // $ANTLR start "rule__Restriction__Group__7"
    // InternalSM2.g:5329:1: rule__Restriction__Group__7 : rule__Restriction__Group__7__Impl ;
    public final void rule__Restriction__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5333:1: ( rule__Restriction__Group__7__Impl )
            // InternalSM2.g:5334:2: rule__Restriction__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__7"


    // $ANTLR start "rule__Restriction__Group__7__Impl"
    // InternalSM2.g:5340:1: rule__Restriction__Group__7__Impl : ( RULE_EOLINE ) ;
    public final void rule__Restriction__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5344:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:5345:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:5345:1: ( RULE_EOLINE )
            // InternalSM2.g:5346:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__7__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__0"
    // InternalSM2.g:5356:1: rule__RestrictionGas__Group__0 : rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1 ;
    public final void rule__RestrictionGas__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5360:1: ( rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1 )
            // InternalSM2.g:5361:2: rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1
            {
            pushFollow(FOLLOW_21);
            rule__RestrictionGas__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__0"


    // $ANTLR start "rule__RestrictionGas__Group__0__Impl"
    // InternalSM2.g:5368:1: rule__RestrictionGas__Group__0__Impl : ( 'require' ) ;
    public final void rule__RestrictionGas__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5372:1: ( ( 'require' ) )
            // InternalSM2.g:5373:1: ( 'require' )
            {
            // InternalSM2.g:5373:1: ( 'require' )
            // InternalSM2.g:5374:2: 'require'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getRequireKeyword_0()); 
            }
            match(input,69,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getRequireKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__0__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__1"
    // InternalSM2.g:5383:1: rule__RestrictionGas__Group__1 : rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2 ;
    public final void rule__RestrictionGas__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5387:1: ( rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2 )
            // InternalSM2.g:5388:2: rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2
            {
            pushFollow(FOLLOW_45);
            rule__RestrictionGas__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__1"


    // $ANTLR start "rule__RestrictionGas__Group__1__Impl"
    // InternalSM2.g:5395:1: rule__RestrictionGas__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__RestrictionGas__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5399:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:5400:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:5400:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:5401:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__1__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__2"
    // InternalSM2.g:5410:1: rule__RestrictionGas__Group__2 : rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3 ;
    public final void rule__RestrictionGas__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5414:1: ( rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3 )
            // InternalSM2.g:5415:2: rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3
            {
            pushFollow(FOLLOW_46);
            rule__RestrictionGas__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__2"


    // $ANTLR start "rule__RestrictionGas__Group__2__Impl"
    // InternalSM2.g:5422:1: rule__RestrictionGas__Group__2__Impl : ( ( rule__RestrictionGas__ExprAssignment_2 ) ) ;
    public final void rule__RestrictionGas__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5426:1: ( ( ( rule__RestrictionGas__ExprAssignment_2 ) ) )
            // InternalSM2.g:5427:1: ( ( rule__RestrictionGas__ExprAssignment_2 ) )
            {
            // InternalSM2.g:5427:1: ( ( rule__RestrictionGas__ExprAssignment_2 ) )
            // InternalSM2.g:5428:2: ( rule__RestrictionGas__ExprAssignment_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getExprAssignment_2()); 
            }
            // InternalSM2.g:5429:2: ( rule__RestrictionGas__ExprAssignment_2 )
            // InternalSM2.g:5429:3: rule__RestrictionGas__ExprAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__ExprAssignment_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getExprAssignment_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__2__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__3"
    // InternalSM2.g:5437:1: rule__RestrictionGas__Group__3 : rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4 ;
    public final void rule__RestrictionGas__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5441:1: ( rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4 )
            // InternalSM2.g:5442:2: rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4
            {
            pushFollow(FOLLOW_16);
            rule__RestrictionGas__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__3"


    // $ANTLR start "rule__RestrictionGas__Group__3__Impl"
    // InternalSM2.g:5449:1: rule__RestrictionGas__Group__3__Impl : ( ( rule__RestrictionGas__OperatorAssignment_3 ) ) ;
    public final void rule__RestrictionGas__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5453:1: ( ( ( rule__RestrictionGas__OperatorAssignment_3 ) ) )
            // InternalSM2.g:5454:1: ( ( rule__RestrictionGas__OperatorAssignment_3 ) )
            {
            // InternalSM2.g:5454:1: ( ( rule__RestrictionGas__OperatorAssignment_3 ) )
            // InternalSM2.g:5455:2: ( rule__RestrictionGas__OperatorAssignment_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getOperatorAssignment_3()); 
            }
            // InternalSM2.g:5456:2: ( rule__RestrictionGas__OperatorAssignment_3 )
            // InternalSM2.g:5456:3: rule__RestrictionGas__OperatorAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__OperatorAssignment_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getOperatorAssignment_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__3__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__4"
    // InternalSM2.g:5464:1: rule__RestrictionGas__Group__4 : rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5 ;
    public final void rule__RestrictionGas__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5468:1: ( rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5 )
            // InternalSM2.g:5469:2: rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5
            {
            pushFollow(FOLLOW_47);
            rule__RestrictionGas__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__4"


    // $ANTLR start "rule__RestrictionGas__Group__4__Impl"
    // InternalSM2.g:5476:1: rule__RestrictionGas__Group__4__Impl : ( ( rule__RestrictionGas__AmountAssignment_4 ) ) ;
    public final void rule__RestrictionGas__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5480:1: ( ( ( rule__RestrictionGas__AmountAssignment_4 ) ) )
            // InternalSM2.g:5481:1: ( ( rule__RestrictionGas__AmountAssignment_4 ) )
            {
            // InternalSM2.g:5481:1: ( ( rule__RestrictionGas__AmountAssignment_4 ) )
            // InternalSM2.g:5482:2: ( rule__RestrictionGas__AmountAssignment_4 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getAmountAssignment_4()); 
            }
            // InternalSM2.g:5483:2: ( rule__RestrictionGas__AmountAssignment_4 )
            // InternalSM2.g:5483:3: rule__RestrictionGas__AmountAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__AmountAssignment_4();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getAmountAssignment_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__4__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__5"
    // InternalSM2.g:5491:1: rule__RestrictionGas__Group__5 : rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6 ;
    public final void rule__RestrictionGas__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5495:1: ( rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6 )
            // InternalSM2.g:5496:2: rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6
            {
            pushFollow(FOLLOW_31);
            rule__RestrictionGas__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__5"


    // $ANTLR start "rule__RestrictionGas__Group__5__Impl"
    // InternalSM2.g:5503:1: rule__RestrictionGas__Group__5__Impl : ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) ) ;
    public final void rule__RestrictionGas__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5507:1: ( ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) ) )
            // InternalSM2.g:5508:1: ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) )
            {
            // InternalSM2.g:5508:1: ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) )
            // InternalSM2.g:5509:2: ( rule__RestrictionGas__TypeCoinAssignment_5 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getTypeCoinAssignment_5()); 
            }
            // InternalSM2.g:5510:2: ( rule__RestrictionGas__TypeCoinAssignment_5 )
            // InternalSM2.g:5510:3: rule__RestrictionGas__TypeCoinAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__TypeCoinAssignment_5();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getTypeCoinAssignment_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__5__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__6"
    // InternalSM2.g:5518:1: rule__RestrictionGas__Group__6 : rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7 ;
    public final void rule__RestrictionGas__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5522:1: ( rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7 )
            // InternalSM2.g:5523:2: rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7
            {
            pushFollow(FOLLOW_5);
            rule__RestrictionGas__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__6"


    // $ANTLR start "rule__RestrictionGas__Group__6__Impl"
    // InternalSM2.g:5530:1: rule__RestrictionGas__Group__6__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__RestrictionGas__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5534:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:5535:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:5535:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:5536:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__6__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__7"
    // InternalSM2.g:5545:1: rule__RestrictionGas__Group__7 : rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8 ;
    public final void rule__RestrictionGas__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5549:1: ( rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8 )
            // InternalSM2.g:5550:2: rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8
            {
            pushFollow(FOLLOW_20);
            rule__RestrictionGas__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__8();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__7"


    // $ANTLR start "rule__RestrictionGas__Group__7__Impl"
    // InternalSM2.g:5557:1: rule__RestrictionGas__Group__7__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__RestrictionGas__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5561:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:5562:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:5562:1: ( RULE_SEMICOLON )
            // InternalSM2.g:5563:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__7__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__8"
    // InternalSM2.g:5572:1: rule__RestrictionGas__Group__8 : rule__RestrictionGas__Group__8__Impl ;
    public final void rule__RestrictionGas__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5576:1: ( rule__RestrictionGas__Group__8__Impl )
            // InternalSM2.g:5577:2: rule__RestrictionGas__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__8__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__8"


    // $ANTLR start "rule__RestrictionGas__Group__8__Impl"
    // InternalSM2.g:5583:1: rule__RestrictionGas__Group__8__Impl : ( RULE_EOLINE ) ;
    public final void rule__RestrictionGas__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5587:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:5588:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:5588:1: ( RULE_EOLINE )
            // InternalSM2.g:5589:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__8__Impl"


    // $ANTLR start "rule__Clause__Group__0"
    // InternalSM2.g:5599:1: rule__Clause__Group__0 : rule__Clause__Group__0__Impl rule__Clause__Group__1 ;
    public final void rule__Clause__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5603:1: ( rule__Clause__Group__0__Impl rule__Clause__Group__1 )
            // InternalSM2.g:5604:2: rule__Clause__Group__0__Impl rule__Clause__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Clause__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__0"


    // $ANTLR start "rule__Clause__Group__0__Impl"
    // InternalSM2.g:5611:1: rule__Clause__Group__0__Impl : ( 'function' ) ;
    public final void rule__Clause__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5615:1: ( ( 'function' ) )
            // InternalSM2.g:5616:1: ( 'function' )
            {
            // InternalSM2.g:5616:1: ( 'function' )
            // InternalSM2.g:5617:2: 'function'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getFunctionKeyword_0()); 
            }
            match(input,70,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getFunctionKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__0__Impl"


    // $ANTLR start "rule__Clause__Group__1"
    // InternalSM2.g:5626:1: rule__Clause__Group__1 : rule__Clause__Group__1__Impl rule__Clause__Group__2 ;
    public final void rule__Clause__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5630:1: ( rule__Clause__Group__1__Impl rule__Clause__Group__2 )
            // InternalSM2.g:5631:2: rule__Clause__Group__1__Impl rule__Clause__Group__2
            {
            pushFollow(FOLLOW_21);
            rule__Clause__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__1"


    // $ANTLR start "rule__Clause__Group__1__Impl"
    // InternalSM2.g:5638:1: rule__Clause__Group__1__Impl : ( ( rule__Clause__NameFunctionAssignment_1 ) ) ;
    public final void rule__Clause__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5642:1: ( ( ( rule__Clause__NameFunctionAssignment_1 ) ) )
            // InternalSM2.g:5643:1: ( ( rule__Clause__NameFunctionAssignment_1 ) )
            {
            // InternalSM2.g:5643:1: ( ( rule__Clause__NameFunctionAssignment_1 ) )
            // InternalSM2.g:5644:2: ( rule__Clause__NameFunctionAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getNameFunctionAssignment_1()); 
            }
            // InternalSM2.g:5645:2: ( rule__Clause__NameFunctionAssignment_1 )
            // InternalSM2.g:5645:3: rule__Clause__NameFunctionAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Clause__NameFunctionAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getNameFunctionAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__1__Impl"


    // $ANTLR start "rule__Clause__Group__2"
    // InternalSM2.g:5653:1: rule__Clause__Group__2 : rule__Clause__Group__2__Impl rule__Clause__Group__3 ;
    public final void rule__Clause__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5657:1: ( rule__Clause__Group__2__Impl rule__Clause__Group__3 )
            // InternalSM2.g:5658:2: rule__Clause__Group__2__Impl rule__Clause__Group__3
            {
            pushFollow(FOLLOW_32);
            rule__Clause__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__2"


    // $ANTLR start "rule__Clause__Group__2__Impl"
    // InternalSM2.g:5665:1: rule__Clause__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Clause__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5669:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:5670:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:5670:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:5671:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__2__Impl"


    // $ANTLR start "rule__Clause__Group__3"
    // InternalSM2.g:5680:1: rule__Clause__Group__3 : rule__Clause__Group__3__Impl rule__Clause__Group__4 ;
    public final void rule__Clause__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5684:1: ( rule__Clause__Group__3__Impl rule__Clause__Group__4 )
            // InternalSM2.g:5685:2: rule__Clause__Group__3__Impl rule__Clause__Group__4
            {
            pushFollow(FOLLOW_32);
            rule__Clause__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__3"


    // $ANTLR start "rule__Clause__Group__3__Impl"
    // InternalSM2.g:5692:1: rule__Clause__Group__3__Impl : ( ( rule__Clause__InputParamsAssignment_3 )* ) ;
    public final void rule__Clause__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5696:1: ( ( ( rule__Clause__InputParamsAssignment_3 )* ) )
            // InternalSM2.g:5697:1: ( ( rule__Clause__InputParamsAssignment_3 )* )
            {
            // InternalSM2.g:5697:1: ( ( rule__Clause__InputParamsAssignment_3 )* )
            // InternalSM2.g:5698:2: ( rule__Clause__InputParamsAssignment_3 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getInputParamsAssignment_3()); 
            }
            // InternalSM2.g:5699:2: ( rule__Clause__InputParamsAssignment_3 )*
            loop61:
            do {
                int alt61=2;
                int LA61_0 = input.LA(1);

                if ( (LA61_0==RULE_ID) ) {
                    alt61=1;
                }


                switch (alt61) {
            	case 1 :
            	    // InternalSM2.g:5699:3: rule__Clause__InputParamsAssignment_3
            	    {
            	    pushFollow(FOLLOW_48);
            	    rule__Clause__InputParamsAssignment_3();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop61;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getInputParamsAssignment_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__3__Impl"


    // $ANTLR start "rule__Clause__Group__4"
    // InternalSM2.g:5707:1: rule__Clause__Group__4 : rule__Clause__Group__4__Impl rule__Clause__Group__5 ;
    public final void rule__Clause__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5711:1: ( rule__Clause__Group__4__Impl rule__Clause__Group__5 )
            // InternalSM2.g:5712:2: rule__Clause__Group__4__Impl rule__Clause__Group__5
            {
            pushFollow(FOLLOW_49);
            rule__Clause__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__4"


    // $ANTLR start "rule__Clause__Group__4__Impl"
    // InternalSM2.g:5719:1: rule__Clause__Group__4__Impl : ( ( rule__Clause__VisibilityAccessAssignment_4 ) ) ;
    public final void rule__Clause__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5723:1: ( ( ( rule__Clause__VisibilityAccessAssignment_4 ) ) )
            // InternalSM2.g:5724:1: ( ( rule__Clause__VisibilityAccessAssignment_4 ) )
            {
            // InternalSM2.g:5724:1: ( ( rule__Clause__VisibilityAccessAssignment_4 ) )
            // InternalSM2.g:5725:2: ( rule__Clause__VisibilityAccessAssignment_4 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getVisibilityAccessAssignment_4()); 
            }
            // InternalSM2.g:5726:2: ( rule__Clause__VisibilityAccessAssignment_4 )
            // InternalSM2.g:5726:3: rule__Clause__VisibilityAccessAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Clause__VisibilityAccessAssignment_4();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getVisibilityAccessAssignment_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__4__Impl"


    // $ANTLR start "rule__Clause__Group__5"
    // InternalSM2.g:5734:1: rule__Clause__Group__5 : rule__Clause__Group__5__Impl rule__Clause__Group__6 ;
    public final void rule__Clause__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5738:1: ( rule__Clause__Group__5__Impl rule__Clause__Group__6 )
            // InternalSM2.g:5739:2: rule__Clause__Group__5__Impl rule__Clause__Group__6
            {
            pushFollow(FOLLOW_49);
            rule__Clause__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__5"


    // $ANTLR start "rule__Clause__Group__5__Impl"
    // InternalSM2.g:5746:1: rule__Clause__Group__5__Impl : ( ( rule__Clause__ModifierAssignment_5 )? ) ;
    public final void rule__Clause__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5750:1: ( ( ( rule__Clause__ModifierAssignment_5 )? ) )
            // InternalSM2.g:5751:1: ( ( rule__Clause__ModifierAssignment_5 )? )
            {
            // InternalSM2.g:5751:1: ( ( rule__Clause__ModifierAssignment_5 )? )
            // InternalSM2.g:5752:2: ( rule__Clause__ModifierAssignment_5 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getModifierAssignment_5()); 
            }
            // InternalSM2.g:5753:2: ( rule__Clause__ModifierAssignment_5 )?
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==RULE_ID) ) {
                alt62=1;
            }
            switch (alt62) {
                case 1 :
                    // InternalSM2.g:5753:3: rule__Clause__ModifierAssignment_5
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__ModifierAssignment_5();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getModifierAssignment_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__5__Impl"


    // $ANTLR start "rule__Clause__Group__6"
    // InternalSM2.g:5761:1: rule__Clause__Group__6 : rule__Clause__Group__6__Impl rule__Clause__Group__7 ;
    public final void rule__Clause__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5765:1: ( rule__Clause__Group__6__Impl rule__Clause__Group__7 )
            // InternalSM2.g:5766:2: rule__Clause__Group__6__Impl rule__Clause__Group__7
            {
            pushFollow(FOLLOW_24);
            rule__Clause__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__6"


    // $ANTLR start "rule__Clause__Group__6__Impl"
    // InternalSM2.g:5773:1: rule__Clause__Group__6__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Clause__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5777:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:5778:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:5778:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:5779:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__6__Impl"


    // $ANTLR start "rule__Clause__Group__7"
    // InternalSM2.g:5788:1: rule__Clause__Group__7 : rule__Clause__Group__7__Impl rule__Clause__Group__8 ;
    public final void rule__Clause__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5792:1: ( rule__Clause__Group__7__Impl rule__Clause__Group__8 )
            // InternalSM2.g:5793:2: rule__Clause__Group__7__Impl rule__Clause__Group__8
            {
            pushFollow(FOLLOW_20);
            rule__Clause__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__8();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__7"


    // $ANTLR start "rule__Clause__Group__7__Impl"
    // InternalSM2.g:5800:1: rule__Clause__Group__7__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Clause__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5804:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:5805:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:5805:1: ( RULE_OPENKEY )
            // InternalSM2.g:5806:2: RULE_OPENKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_7()); 
            }
            match(input,RULE_OPENKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__7__Impl"


    // $ANTLR start "rule__Clause__Group__8"
    // InternalSM2.g:5815:1: rule__Clause__Group__8 : rule__Clause__Group__8__Impl rule__Clause__Group__9 ;
    public final void rule__Clause__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5819:1: ( rule__Clause__Group__8__Impl rule__Clause__Group__9 )
            // InternalSM2.g:5820:2: rule__Clause__Group__8__Impl rule__Clause__Group__9
            {
            pushFollow(FOLLOW_50);
            rule__Clause__Group__8__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__9();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__8"


    // $ANTLR start "rule__Clause__Group__8__Impl"
    // InternalSM2.g:5827:1: rule__Clause__Group__8__Impl : ( RULE_EOLINE ) ;
    public final void rule__Clause__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5831:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:5832:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:5832:1: ( RULE_EOLINE )
            // InternalSM2.g:5833:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_8()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_8()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__8__Impl"


    // $ANTLR start "rule__Clause__Group__9"
    // InternalSM2.g:5842:1: rule__Clause__Group__9 : rule__Clause__Group__9__Impl rule__Clause__Group__10 ;
    public final void rule__Clause__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5846:1: ( rule__Clause__Group__9__Impl rule__Clause__Group__10 )
            // InternalSM2.g:5847:2: rule__Clause__Group__9__Impl rule__Clause__Group__10
            {
            pushFollow(FOLLOW_50);
            rule__Clause__Group__9__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__10();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__9"


    // $ANTLR start "rule__Clause__Group__9__Impl"
    // InternalSM2.g:5854:1: rule__Clause__Group__9__Impl : ( ( rule__Clause__RestrictionAssignment_9 )? ) ;
    public final void rule__Clause__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5858:1: ( ( ( rule__Clause__RestrictionAssignment_9 )? ) )
            // InternalSM2.g:5859:1: ( ( rule__Clause__RestrictionAssignment_9 )? )
            {
            // InternalSM2.g:5859:1: ( ( rule__Clause__RestrictionAssignment_9 )? )
            // InternalSM2.g:5860:2: ( rule__Clause__RestrictionAssignment_9 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getRestrictionAssignment_9()); 
            }
            // InternalSM2.g:5861:2: ( rule__Clause__RestrictionAssignment_9 )?
            int alt63=2;
            alt63 = dfa63.predict(input);
            switch (alt63) {
                case 1 :
                    // InternalSM2.g:5861:3: rule__Clause__RestrictionAssignment_9
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__RestrictionAssignment_9();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getRestrictionAssignment_9()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__9__Impl"


    // $ANTLR start "rule__Clause__Group__10"
    // InternalSM2.g:5869:1: rule__Clause__Group__10 : rule__Clause__Group__10__Impl rule__Clause__Group__11 ;
    public final void rule__Clause__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5873:1: ( rule__Clause__Group__10__Impl rule__Clause__Group__11 )
            // InternalSM2.g:5874:2: rule__Clause__Group__10__Impl rule__Clause__Group__11
            {
            pushFollow(FOLLOW_50);
            rule__Clause__Group__10__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__11();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__10"


    // $ANTLR start "rule__Clause__Group__10__Impl"
    // InternalSM2.g:5881:1: rule__Clause__Group__10__Impl : ( ( rule__Clause__RestrictionGasAssignment_10 )? ) ;
    public final void rule__Clause__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5885:1: ( ( ( rule__Clause__RestrictionGasAssignment_10 )? ) )
            // InternalSM2.g:5886:1: ( ( rule__Clause__RestrictionGasAssignment_10 )? )
            {
            // InternalSM2.g:5886:1: ( ( rule__Clause__RestrictionGasAssignment_10 )? )
            // InternalSM2.g:5887:2: ( rule__Clause__RestrictionGasAssignment_10 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getRestrictionGasAssignment_10()); 
            }
            // InternalSM2.g:5888:2: ( rule__Clause__RestrictionGasAssignment_10 )?
            int alt64=2;
            int LA64_0 = input.LA(1);

            if ( (LA64_0==69) ) {
                alt64=1;
            }
            switch (alt64) {
                case 1 :
                    // InternalSM2.g:5888:3: rule__Clause__RestrictionGasAssignment_10
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__RestrictionGasAssignment_10();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getRestrictionGasAssignment_10()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__10__Impl"


    // $ANTLR start "rule__Clause__Group__11"
    // InternalSM2.g:5896:1: rule__Clause__Group__11 : rule__Clause__Group__11__Impl rule__Clause__Group__12 ;
    public final void rule__Clause__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5900:1: ( rule__Clause__Group__11__Impl rule__Clause__Group__12 )
            // InternalSM2.g:5901:2: rule__Clause__Group__11__Impl rule__Clause__Group__12
            {
            pushFollow(FOLLOW_39);
            rule__Clause__Group__11__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__12();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__11"


    // $ANTLR start "rule__Clause__Group__11__Impl"
    // InternalSM2.g:5908:1: rule__Clause__Group__11__Impl : ( ( ( rule__Clause__ExpressionAssignment_11 ) ) ( ( rule__Clause__ExpressionAssignment_11 )* ) ) ;
    public final void rule__Clause__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5912:1: ( ( ( ( rule__Clause__ExpressionAssignment_11 ) ) ( ( rule__Clause__ExpressionAssignment_11 )* ) ) )
            // InternalSM2.g:5913:1: ( ( ( rule__Clause__ExpressionAssignment_11 ) ) ( ( rule__Clause__ExpressionAssignment_11 )* ) )
            {
            // InternalSM2.g:5913:1: ( ( ( rule__Clause__ExpressionAssignment_11 ) ) ( ( rule__Clause__ExpressionAssignment_11 )* ) )
            // InternalSM2.g:5914:2: ( ( rule__Clause__ExpressionAssignment_11 ) ) ( ( rule__Clause__ExpressionAssignment_11 )* )
            {
            // InternalSM2.g:5914:2: ( ( rule__Clause__ExpressionAssignment_11 ) )
            // InternalSM2.g:5915:3: ( rule__Clause__ExpressionAssignment_11 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getExpressionAssignment_11()); 
            }
            // InternalSM2.g:5916:3: ( rule__Clause__ExpressionAssignment_11 )
            // InternalSM2.g:5916:4: rule__Clause__ExpressionAssignment_11
            {
            pushFollow(FOLLOW_51);
            rule__Clause__ExpressionAssignment_11();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getExpressionAssignment_11()); 
            }

            }

            // InternalSM2.g:5919:2: ( ( rule__Clause__ExpressionAssignment_11 )* )
            // InternalSM2.g:5920:3: ( rule__Clause__ExpressionAssignment_11 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getExpressionAssignment_11()); 
            }
            // InternalSM2.g:5921:3: ( rule__Clause__ExpressionAssignment_11 )*
            loop65:
            do {
                int alt65=2;
                int LA65_0 = input.LA(1);

                if ( (LA65_0==RULE_STRING||LA65_0==RULE_OPENPARENTHESIS||LA65_0==RULE_NUMBER) ) {
                    alt65=1;
                }


                switch (alt65) {
            	case 1 :
            	    // InternalSM2.g:5921:4: rule__Clause__ExpressionAssignment_11
            	    {
            	    pushFollow(FOLLOW_51);
            	    rule__Clause__ExpressionAssignment_11();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop65;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getExpressionAssignment_11()); 
            }

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__11__Impl"


    // $ANTLR start "rule__Clause__Group__12"
    // InternalSM2.g:5930:1: rule__Clause__Group__12 : rule__Clause__Group__12__Impl rule__Clause__Group__13 ;
    public final void rule__Clause__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5934:1: ( rule__Clause__Group__12__Impl rule__Clause__Group__13 )
            // InternalSM2.g:5935:2: rule__Clause__Group__12__Impl rule__Clause__Group__13
            {
            pushFollow(FOLLOW_39);
            rule__Clause__Group__12__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__13();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__12"


    // $ANTLR start "rule__Clause__Group__12__Impl"
    // InternalSM2.g:5942:1: rule__Clause__Group__12__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Clause__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5946:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:5947:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:5947:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:5948:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_12()); 
            }
            // InternalSM2.g:5949:2: ( RULE_EOLINE )?
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==RULE_EOLINE) ) {
                alt66=1;
            }
            switch (alt66) {
                case 1 :
                    // InternalSM2.g:5949:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_12()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__12__Impl"


    // $ANTLR start "rule__Clause__Group__13"
    // InternalSM2.g:5957:1: rule__Clause__Group__13 : rule__Clause__Group__13__Impl rule__Clause__Group__14 ;
    public final void rule__Clause__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5961:1: ( rule__Clause__Group__13__Impl rule__Clause__Group__14 )
            // InternalSM2.g:5962:2: rule__Clause__Group__13__Impl rule__Clause__Group__14
            {
            pushFollow(FOLLOW_20);
            rule__Clause__Group__13__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__14();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__13"


    // $ANTLR start "rule__Clause__Group__13__Impl"
    // InternalSM2.g:5969:1: rule__Clause__Group__13__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Clause__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5973:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:5974:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:5974:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:5975:2: RULE_CLOSEKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_13()); 
            }
            match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_13()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__13__Impl"


    // $ANTLR start "rule__Clause__Group__14"
    // InternalSM2.g:5984:1: rule__Clause__Group__14 : rule__Clause__Group__14__Impl ;
    public final void rule__Clause__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5988:1: ( rule__Clause__Group__14__Impl )
            // InternalSM2.g:5989:2: rule__Clause__Group__14__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Clause__Group__14__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__14"


    // $ANTLR start "rule__Clause__Group__14__Impl"
    // InternalSM2.g:5995:1: rule__Clause__Group__14__Impl : ( RULE_EOLINE ) ;
    public final void rule__Clause__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5999:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:6000:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:6000:1: ( RULE_EOLINE )
            // InternalSM2.g:6001:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_14()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_14()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__14__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__0"
    // InternalSM2.g:6011:1: rule__ArithmethicalExpression__Group_0__0 : rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1 ;
    public final void rule__ArithmethicalExpression__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6015:1: ( rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1 )
            // InternalSM2.g:6016:2: rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1
            {
            pushFollow(FOLLOW_16);
            rule__ArithmethicalExpression__Group_0__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__0__Impl"
    // InternalSM2.g:6023:1: rule__ArithmethicalExpression__Group_0__0__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__ArithmethicalExpression__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6027:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:6028:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:6028:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:6029:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__1"
    // InternalSM2.g:6038:1: rule__ArithmethicalExpression__Group_0__1 : rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2 ;
    public final void rule__ArithmethicalExpression__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6042:1: ( rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2 )
            // InternalSM2.g:6043:2: rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2
            {
            pushFollow(FOLLOW_52);
            rule__ArithmethicalExpression__Group_0__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__1__Impl"
    // InternalSM2.g:6050:1: rule__ArithmethicalExpression__Group_0__1__Impl : ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6054:1: ( ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) ) )
            // InternalSM2.g:6055:1: ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) )
            {
            // InternalSM2.g:6055:1: ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) )
            // InternalSM2.g:6056:2: ( rule__ArithmethicalExpression__Op1Assignment_0_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_0_1()); 
            }
            // InternalSM2.g:6057:2: ( rule__ArithmethicalExpression__Op1Assignment_0_1 )
            // InternalSM2.g:6057:3: rule__ArithmethicalExpression__Op1Assignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op1Assignment_0_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_0_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__1__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__2"
    // InternalSM2.g:6065:1: rule__ArithmethicalExpression__Group_0__2 : rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3 ;
    public final void rule__ArithmethicalExpression__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6069:1: ( rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3 )
            // InternalSM2.g:6070:2: rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3
            {
            pushFollow(FOLLOW_16);
            rule__ArithmethicalExpression__Group_0__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__2"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__2__Impl"
    // InternalSM2.g:6077:1: rule__ArithmethicalExpression__Group_0__2__Impl : ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6081:1: ( ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) ) )
            // InternalSM2.g:6082:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) )
            {
            // InternalSM2.g:6082:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) )
            // InternalSM2.g:6083:2: ( rule__ArithmethicalExpression__OperatorAssignment_0_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_0_2()); 
            }
            // InternalSM2.g:6084:2: ( rule__ArithmethicalExpression__OperatorAssignment_0_2 )
            // InternalSM2.g:6084:3: rule__ArithmethicalExpression__OperatorAssignment_0_2
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__OperatorAssignment_0_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_0_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__2__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__3"
    // InternalSM2.g:6092:1: rule__ArithmethicalExpression__Group_0__3 : rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4 ;
    public final void rule__ArithmethicalExpression__Group_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6096:1: ( rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4 )
            // InternalSM2.g:6097:2: rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4
            {
            pushFollow(FOLLOW_31);
            rule__ArithmethicalExpression__Group_0__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__3"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__3__Impl"
    // InternalSM2.g:6104:1: rule__ArithmethicalExpression__Group_0__3__Impl : ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6108:1: ( ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) ) )
            // InternalSM2.g:6109:1: ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) )
            {
            // InternalSM2.g:6109:1: ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) )
            // InternalSM2.g:6110:2: ( rule__ArithmethicalExpression__Op2Assignment_0_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_0_3()); 
            }
            // InternalSM2.g:6111:2: ( rule__ArithmethicalExpression__Op2Assignment_0_3 )
            // InternalSM2.g:6111:3: rule__ArithmethicalExpression__Op2Assignment_0_3
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op2Assignment_0_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_0_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__3__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__4"
    // InternalSM2.g:6119:1: rule__ArithmethicalExpression__Group_0__4 : rule__ArithmethicalExpression__Group_0__4__Impl ;
    public final void rule__ArithmethicalExpression__Group_0__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6123:1: ( rule__ArithmethicalExpression__Group_0__4__Impl )
            // InternalSM2.g:6124:2: rule__ArithmethicalExpression__Group_0__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__4__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__4"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__4__Impl"
    // InternalSM2.g:6130:1: rule__ArithmethicalExpression__Group_0__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__ArithmethicalExpression__Group_0__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6134:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:6135:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:6135:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:6136:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__4__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__0"
    // InternalSM2.g:6146:1: rule__ArithmethicalExpression__Group_1__0 : rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1 ;
    public final void rule__ArithmethicalExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6150:1: ( rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1 )
            // InternalSM2.g:6151:2: rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1
            {
            pushFollow(FOLLOW_52);
            rule__ArithmethicalExpression__Group_1__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__0__Impl"
    // InternalSM2.g:6158:1: rule__ArithmethicalExpression__Group_1__0__Impl : ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6162:1: ( ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) ) )
            // InternalSM2.g:6163:1: ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) )
            {
            // InternalSM2.g:6163:1: ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) )
            // InternalSM2.g:6164:2: ( rule__ArithmethicalExpression__Op1Assignment_1_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_1_0()); 
            }
            // InternalSM2.g:6165:2: ( rule__ArithmethicalExpression__Op1Assignment_1_0 )
            // InternalSM2.g:6165:3: rule__ArithmethicalExpression__Op1Assignment_1_0
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op1Assignment_1_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__1"
    // InternalSM2.g:6173:1: rule__ArithmethicalExpression__Group_1__1 : rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2 ;
    public final void rule__ArithmethicalExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6177:1: ( rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2 )
            // InternalSM2.g:6178:2: rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2
            {
            pushFollow(FOLLOW_16);
            rule__ArithmethicalExpression__Group_1__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__1__Impl"
    // InternalSM2.g:6185:1: rule__ArithmethicalExpression__Group_1__1__Impl : ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6189:1: ( ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) ) )
            // InternalSM2.g:6190:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) )
            {
            // InternalSM2.g:6190:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) )
            // InternalSM2.g:6191:2: ( rule__ArithmethicalExpression__OperatorAssignment_1_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_1_1()); 
            }
            // InternalSM2.g:6192:2: ( rule__ArithmethicalExpression__OperatorAssignment_1_1 )
            // InternalSM2.g:6192:3: rule__ArithmethicalExpression__OperatorAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__OperatorAssignment_1_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_1_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__1__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__2"
    // InternalSM2.g:6200:1: rule__ArithmethicalExpression__Group_1__2 : rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3 ;
    public final void rule__ArithmethicalExpression__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6204:1: ( rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3 )
            // InternalSM2.g:6205:2: rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3
            {
            pushFollow(FOLLOW_5);
            rule__ArithmethicalExpression__Group_1__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__2"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__2__Impl"
    // InternalSM2.g:6212:1: rule__ArithmethicalExpression__Group_1__2__Impl : ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6216:1: ( ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) ) )
            // InternalSM2.g:6217:1: ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) )
            {
            // InternalSM2.g:6217:1: ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) )
            // InternalSM2.g:6218:2: ( rule__ArithmethicalExpression__Op2Assignment_1_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_1_2()); 
            }
            // InternalSM2.g:6219:2: ( rule__ArithmethicalExpression__Op2Assignment_1_2 )
            // InternalSM2.g:6219:3: rule__ArithmethicalExpression__Op2Assignment_1_2
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op2Assignment_1_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_1_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__2__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__3"
    // InternalSM2.g:6227:1: rule__ArithmethicalExpression__Group_1__3 : rule__ArithmethicalExpression__Group_1__3__Impl ;
    public final void rule__ArithmethicalExpression__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6231:1: ( rule__ArithmethicalExpression__Group_1__3__Impl )
            // InternalSM2.g:6232:2: rule__ArithmethicalExpression__Group_1__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__3__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__3"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__3__Impl"
    // InternalSM2.g:6238:1: rule__ArithmethicalExpression__Group_1__3__Impl : ( ( rule__ArithmethicalExpression__Group_1_3__0 )? ) ;
    public final void rule__ArithmethicalExpression__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6242:1: ( ( ( rule__ArithmethicalExpression__Group_1_3__0 )? ) )
            // InternalSM2.g:6243:1: ( ( rule__ArithmethicalExpression__Group_1_3__0 )? )
            {
            // InternalSM2.g:6243:1: ( ( rule__ArithmethicalExpression__Group_1_3__0 )? )
            // InternalSM2.g:6244:2: ( rule__ArithmethicalExpression__Group_1_3__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getGroup_1_3()); 
            }
            // InternalSM2.g:6245:2: ( rule__ArithmethicalExpression__Group_1_3__0 )?
            int alt67=2;
            int LA67_0 = input.LA(1);

            if ( (LA67_0==RULE_SEMICOLON) ) {
                alt67=1;
            }
            switch (alt67) {
                case 1 :
                    // InternalSM2.g:6245:3: rule__ArithmethicalExpression__Group_1_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_1_3__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getGroup_1_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__3__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__0"
    // InternalSM2.g:6254:1: rule__ArithmethicalExpression__Group_1_3__0 : rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1 ;
    public final void rule__ArithmethicalExpression__Group_1_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6258:1: ( rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1 )
            // InternalSM2.g:6259:2: rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1
            {
            pushFollow(FOLLOW_20);
            rule__ArithmethicalExpression__Group_1_3__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1_3__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__0__Impl"
    // InternalSM2.g:6266:1: rule__ArithmethicalExpression__Group_1_3__0__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__ArithmethicalExpression__Group_1_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6270:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:6271:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:6271:1: ( RULE_SEMICOLON )
            // InternalSM2.g:6272:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__1"
    // InternalSM2.g:6281:1: rule__ArithmethicalExpression__Group_1_3__1 : rule__ArithmethicalExpression__Group_1_3__1__Impl ;
    public final void rule__ArithmethicalExpression__Group_1_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6285:1: ( rule__ArithmethicalExpression__Group_1_3__1__Impl )
            // InternalSM2.g:6286:2: rule__ArithmethicalExpression__Group_1_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1_3__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__1__Impl"
    // InternalSM2.g:6292:1: rule__ArithmethicalExpression__Group_1_3__1__Impl : ( RULE_EOLINE ) ;
    public final void rule__ArithmethicalExpression__Group_1_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6296:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:6297:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:6297:1: ( RULE_EOLINE )
            // InternalSM2.g:6298:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__1__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1__0"
    // InternalSM2.g:6308:1: rule__SyntaxExpression__Group_1__0 : rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1 ;
    public final void rule__SyntaxExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6312:1: ( rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1 )
            // InternalSM2.g:6313:2: rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1
            {
            pushFollow(FOLLOW_5);
            rule__SyntaxExpression__Group_1__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__0"


    // $ANTLR start "rule__SyntaxExpression__Group_1__0__Impl"
    // InternalSM2.g:6320:1: rule__SyntaxExpression__Group_1__0__Impl : ( RULE_NUMBER ) ;
    public final void rule__SyntaxExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6324:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6325:1: ( RULE_NUMBER )
            {
            // InternalSM2.g:6325:1: ( RULE_NUMBER )
            // InternalSM2.g:6326:2: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSyntaxExpressionAccess().getNUMBERTerminalRuleCall_1_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSyntaxExpressionAccess().getNUMBERTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__0__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1__1"
    // InternalSM2.g:6335:1: rule__SyntaxExpression__Group_1__1 : rule__SyntaxExpression__Group_1__1__Impl ;
    public final void rule__SyntaxExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6339:1: ( rule__SyntaxExpression__Group_1__1__Impl )
            // InternalSM2.g:6340:2: rule__SyntaxExpression__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__1"


    // $ANTLR start "rule__SyntaxExpression__Group_1__1__Impl"
    // InternalSM2.g:6346:1: rule__SyntaxExpression__Group_1__1__Impl : ( ( rule__SyntaxExpression__Group_1_1__0 )? ) ;
    public final void rule__SyntaxExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6350:1: ( ( ( rule__SyntaxExpression__Group_1_1__0 )? ) )
            // InternalSM2.g:6351:1: ( ( rule__SyntaxExpression__Group_1_1__0 )? )
            {
            // InternalSM2.g:6351:1: ( ( rule__SyntaxExpression__Group_1_1__0 )? )
            // InternalSM2.g:6352:2: ( rule__SyntaxExpression__Group_1_1__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSyntaxExpressionAccess().getGroup_1_1()); 
            }
            // InternalSM2.g:6353:2: ( rule__SyntaxExpression__Group_1_1__0 )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( (LA68_0==RULE_SEMICOLON) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // InternalSM2.g:6353:3: rule__SyntaxExpression__Group_1_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__Group_1_1__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSyntaxExpressionAccess().getGroup_1_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__1__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__0"
    // InternalSM2.g:6362:1: rule__SyntaxExpression__Group_1_1__0 : rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1 ;
    public final void rule__SyntaxExpression__Group_1_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6366:1: ( rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1 )
            // InternalSM2.g:6367:2: rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1
            {
            pushFollow(FOLLOW_20);
            rule__SyntaxExpression__Group_1_1__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1_1__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__0"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__0__Impl"
    // InternalSM2.g:6374:1: rule__SyntaxExpression__Group_1_1__0__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__SyntaxExpression__Group_1_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6378:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:6379:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:6379:1: ( RULE_SEMICOLON )
            // InternalSM2.g:6380:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__0__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__1"
    // InternalSM2.g:6389:1: rule__SyntaxExpression__Group_1_1__1 : rule__SyntaxExpression__Group_1_1__1__Impl ;
    public final void rule__SyntaxExpression__Group_1_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6393:1: ( rule__SyntaxExpression__Group_1_1__1__Impl )
            // InternalSM2.g:6394:2: rule__SyntaxExpression__Group_1_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1_1__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__1"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__1__Impl"
    // InternalSM2.g:6400:1: rule__SyntaxExpression__Group_1_1__1__Impl : ( RULE_EOLINE ) ;
    public final void rule__SyntaxExpression__Group_1_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6404:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:6405:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:6405:1: ( RULE_EOLINE )
            // InternalSM2.g:6406:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__1__Impl"


    // $ANTLR start "rule__ShortComment__Group__0"
    // InternalSM2.g:6416:1: rule__ShortComment__Group__0 : rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1 ;
    public final void rule__ShortComment__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6420:1: ( rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1 )
            // InternalSM2.g:6421:2: rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1
            {
            pushFollow(FOLLOW_30);
            rule__ShortComment__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__0"


    // $ANTLR start "rule__ShortComment__Group__0__Impl"
    // InternalSM2.g:6428:1: rule__ShortComment__Group__0__Impl : ( '//' ) ;
    public final void rule__ShortComment__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6432:1: ( ( '//' ) )
            // InternalSM2.g:6433:1: ( '//' )
            {
            // InternalSM2.g:6433:1: ( '//' )
            // InternalSM2.g:6434:2: '//'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0()); 
            }
            match(input,71,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__0__Impl"


    // $ANTLR start "rule__ShortComment__Group__1"
    // InternalSM2.g:6443:1: rule__ShortComment__Group__1 : rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2 ;
    public final void rule__ShortComment__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6447:1: ( rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2 )
            // InternalSM2.g:6448:2: rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2
            {
            pushFollow(FOLLOW_20);
            rule__ShortComment__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__1"


    // $ANTLR start "rule__ShortComment__Group__1__Impl"
    // InternalSM2.g:6455:1: rule__ShortComment__Group__1__Impl : ( ( rule__ShortComment__ExprAssignment_1 ) ) ;
    public final void rule__ShortComment__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6459:1: ( ( ( rule__ShortComment__ExprAssignment_1 ) ) )
            // InternalSM2.g:6460:1: ( ( rule__ShortComment__ExprAssignment_1 ) )
            {
            // InternalSM2.g:6460:1: ( ( rule__ShortComment__ExprAssignment_1 ) )
            // InternalSM2.g:6461:2: ( rule__ShortComment__ExprAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getShortCommentAccess().getExprAssignment_1()); 
            }
            // InternalSM2.g:6462:2: ( rule__ShortComment__ExprAssignment_1 )
            // InternalSM2.g:6462:3: rule__ShortComment__ExprAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__ExprAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getShortCommentAccess().getExprAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__1__Impl"


    // $ANTLR start "rule__ShortComment__Group__2"
    // InternalSM2.g:6470:1: rule__ShortComment__Group__2 : rule__ShortComment__Group__2__Impl ;
    public final void rule__ShortComment__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6474:1: ( rule__ShortComment__Group__2__Impl )
            // InternalSM2.g:6475:2: rule__ShortComment__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__2"


    // $ANTLR start "rule__ShortComment__Group__2__Impl"
    // InternalSM2.g:6481:1: rule__ShortComment__Group__2__Impl : ( ( RULE_EOLINE ) ) ;
    public final void rule__ShortComment__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6485:1: ( ( ( RULE_EOLINE ) ) )
            // InternalSM2.g:6486:1: ( ( RULE_EOLINE ) )
            {
            // InternalSM2.g:6486:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:6487:2: ( RULE_EOLINE )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2()); 
            }
            // InternalSM2.g:6488:2: ( RULE_EOLINE )
            // InternalSM2.g:6488:3: RULE_EOLINE
            {
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__2__Impl"


    // $ANTLR start "rule__LongComment__Group__0"
    // InternalSM2.g:6497:1: rule__LongComment__Group__0 : rule__LongComment__Group__0__Impl rule__LongComment__Group__1 ;
    public final void rule__LongComment__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6501:1: ( rule__LongComment__Group__0__Impl rule__LongComment__Group__1 )
            // InternalSM2.g:6502:2: rule__LongComment__Group__0__Impl rule__LongComment__Group__1
            {
            pushFollow(FOLLOW_53);
            rule__LongComment__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__0"


    // $ANTLR start "rule__LongComment__Group__0__Impl"
    // InternalSM2.g:6509:1: rule__LongComment__Group__0__Impl : ( '/*' ) ;
    public final void rule__LongComment__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6513:1: ( ( '/*' ) )
            // InternalSM2.g:6514:1: ( '/*' )
            {
            // InternalSM2.g:6514:1: ( '/*' )
            // InternalSM2.g:6515:2: '/*'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0()); 
            }
            match(input,72,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__0__Impl"


    // $ANTLR start "rule__LongComment__Group__1"
    // InternalSM2.g:6524:1: rule__LongComment__Group__1 : rule__LongComment__Group__1__Impl rule__LongComment__Group__2 ;
    public final void rule__LongComment__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6528:1: ( rule__LongComment__Group__1__Impl rule__LongComment__Group__2 )
            // InternalSM2.g:6529:2: rule__LongComment__Group__1__Impl rule__LongComment__Group__2
            {
            pushFollow(FOLLOW_54);
            rule__LongComment__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__1"


    // $ANTLR start "rule__LongComment__Group__1__Impl"
    // InternalSM2.g:6536:1: rule__LongComment__Group__1__Impl : ( ( rule__LongComment__ExpressionAssignment_1 ) ) ;
    public final void rule__LongComment__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6540:1: ( ( ( rule__LongComment__ExpressionAssignment_1 ) ) )
            // InternalSM2.g:6541:1: ( ( rule__LongComment__ExpressionAssignment_1 ) )
            {
            // InternalSM2.g:6541:1: ( ( rule__LongComment__ExpressionAssignment_1 ) )
            // InternalSM2.g:6542:2: ( rule__LongComment__ExpressionAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getLongCommentAccess().getExpressionAssignment_1()); 
            }
            // InternalSM2.g:6543:2: ( rule__LongComment__ExpressionAssignment_1 )
            // InternalSM2.g:6543:3: rule__LongComment__ExpressionAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__ExpressionAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getLongCommentAccess().getExpressionAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__1__Impl"


    // $ANTLR start "rule__LongComment__Group__2"
    // InternalSM2.g:6551:1: rule__LongComment__Group__2 : rule__LongComment__Group__2__Impl ;
    public final void rule__LongComment__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6555:1: ( rule__LongComment__Group__2__Impl )
            // InternalSM2.g:6556:2: rule__LongComment__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__2"


    // $ANTLR start "rule__LongComment__Group__2__Impl"
    // InternalSM2.g:6562:1: rule__LongComment__Group__2__Impl : ( ( '*/' ) ) ;
    public final void rule__LongComment__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6566:1: ( ( ( '*/' ) ) )
            // InternalSM2.g:6567:1: ( ( '*/' ) )
            {
            // InternalSM2.g:6567:1: ( ( '*/' ) )
            // InternalSM2.g:6568:2: ( '*/' )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2()); 
            }
            // InternalSM2.g:6569:2: ( '*/' )
            // InternalSM2.g:6569:3: '*/'
            {
            match(input,73,FOLLOW_2); if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__2__Impl"


    // $ANTLR start "rule__SmartContract__CompilerAssignment_0"
    // InternalSM2.g:6578:1: rule__SmartContract__CompilerAssignment_0 : ( ( 'pragma' ) ) ;
    public final void rule__SmartContract__CompilerAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6582:1: ( ( ( 'pragma' ) ) )
            // InternalSM2.g:6583:2: ( ( 'pragma' ) )
            {
            // InternalSM2.g:6583:2: ( ( 'pragma' ) )
            // InternalSM2.g:6584:3: ( 'pragma' )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 
            }
            // InternalSM2.g:6585:3: ( 'pragma' )
            // InternalSM2.g:6586:4: 'pragma'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 
            }
            match(input,74,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__CompilerAssignment_0"


    // $ANTLR start "rule__SmartContract__VersionCompilerAssignment_2"
    // InternalSM2.g:6597:1: rule__SmartContract__VersionCompilerAssignment_2 : ( ruleVersion ) ;
    public final void rule__SmartContract__VersionCompilerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6601:1: ( ( ruleVersion ) )
            // InternalSM2.g:6602:2: ( ruleVersion )
            {
            // InternalSM2.g:6602:2: ( ruleVersion )
            // InternalSM2.g:6603:3: ruleVersion
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleVersion();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__VersionCompilerAssignment_2"


    // $ANTLR start "rule__SmartContract__ImportsAssignment_5"
    // InternalSM2.g:6612:1: rule__SmartContract__ImportsAssignment_5 : ( ruleImport ) ;
    public final void rule__SmartContract__ImportsAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6616:1: ( ( ruleImport ) )
            // InternalSM2.g:6617:2: ( ruleImport )
            {
            // InternalSM2.g:6617:2: ( ruleImport )
            // InternalSM2.g:6618:3: ruleImport
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_5_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleImport();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ImportsAssignment_5"


    // $ANTLR start "rule__SmartContract__ContractAssignment_6"
    // InternalSM2.g:6627:1: rule__SmartContract__ContractAssignment_6 : ( ( 'contract' ) ) ;
    public final void rule__SmartContract__ContractAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6631:1: ( ( ( 'contract' ) ) )
            // InternalSM2.g:6632:2: ( ( 'contract' ) )
            {
            // InternalSM2.g:6632:2: ( ( 'contract' ) )
            // InternalSM2.g:6633:3: ( 'contract' )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 
            }
            // InternalSM2.g:6634:3: ( 'contract' )
            // InternalSM2.g:6635:4: 'contract'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 
            }
            match(input,75,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ContractAssignment_6"


    // $ANTLR start "rule__SmartContract__NameContractAssignment_7"
    // InternalSM2.g:6646:1: rule__SmartContract__NameContractAssignment_7 : ( RULE_ID ) ;
    public final void rule__SmartContract__NameContractAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6650:1: ( ( RULE_ID ) )
            // InternalSM2.g:6651:2: ( RULE_ID )
            {
            // InternalSM2.g:6651:2: ( RULE_ID )
            // InternalSM2.g:6652:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_7_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_7_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__NameContractAssignment_7"


    // $ANTLR start "rule__SmartContract__NameContractFatherAssignment_8_1"
    // InternalSM2.g:6661:1: rule__SmartContract__NameContractFatherAssignment_8_1 : ( RULE_ID ) ;
    public final void rule__SmartContract__NameContractFatherAssignment_8_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6665:1: ( ( RULE_ID ) )
            // InternalSM2.g:6666:2: ( RULE_ID )
            {
            // InternalSM2.g:6666:2: ( RULE_ID )
            // InternalSM2.g:6667:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_8_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_8_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__NameContractFatherAssignment_8_1"


    // $ANTLR start "rule__SmartContract__AttributesAssignment_11"
    // InternalSM2.g:6676:1: rule__SmartContract__AttributesAssignment_11 : ( ruleAttributes ) ;
    public final void rule__SmartContract__AttributesAssignment_11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6680:1: ( ( ruleAttributes ) )
            // InternalSM2.g:6681:2: ( ruleAttributes )
            {
            // InternalSM2.g:6681:2: ( ruleAttributes )
            // InternalSM2.g:6682:3: ruleAttributes
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_11_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleAttributes();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_11_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__AttributesAssignment_11"


    // $ANTLR start "rule__SmartContract__EventsAssignment_12"
    // InternalSM2.g:6691:1: rule__SmartContract__EventsAssignment_12 : ( ruleEvent ) ;
    public final void rule__SmartContract__EventsAssignment_12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6695:1: ( ( ruleEvent ) )
            // InternalSM2.g:6696:2: ( ruleEvent )
            {
            // InternalSM2.g:6696:2: ( ruleEvent )
            // InternalSM2.g:6697:3: ruleEvent
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getEventsEventParserRuleCall_12_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleEvent();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getEventsEventParserRuleCall_12_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__EventsAssignment_12"


    // $ANTLR start "rule__SmartContract__ModifierAssignment_13"
    // InternalSM2.g:6706:1: rule__SmartContract__ModifierAssignment_13 : ( ruleModifier ) ;
    public final void rule__SmartContract__ModifierAssignment_13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6710:1: ( ( ruleModifier ) )
            // InternalSM2.g:6711:2: ( ruleModifier )
            {
            // InternalSM2.g:6711:2: ( ruleModifier )
            // InternalSM2.g:6712:3: ruleModifier
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_13_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleModifier();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_13_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ModifierAssignment_13"


    // $ANTLR start "rule__SmartContract__ClausesAssignment_14"
    // InternalSM2.g:6721:1: rule__SmartContract__ClausesAssignment_14 : ( ruleClause ) ;
    public final void rule__SmartContract__ClausesAssignment_14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6725:1: ( ( ruleClause ) )
            // InternalSM2.g:6726:2: ( ruleClause )
            {
            // InternalSM2.g:6726:2: ( ruleClause )
            // InternalSM2.g:6727:3: ruleClause
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_14_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleClause();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_14_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ClausesAssignment_14"


    // $ANTLR start "rule__SmartContract__CommentsAssignment_15"
    // InternalSM2.g:6736:1: rule__SmartContract__CommentsAssignment_15 : ( ruleComment ) ;
    public final void rule__SmartContract__CommentsAssignment_15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6740:1: ( ( ruleComment ) )
            // InternalSM2.g:6741:2: ( ruleComment )
            {
            // InternalSM2.g:6741:2: ( ruleComment )
            // InternalSM2.g:6742:3: ruleComment
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_15_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleComment();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_15_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__CommentsAssignment_15"


    // $ANTLR start "rule__Version__SymbolAssignment_0_0"
    // InternalSM2.g:6751:1: rule__Version__SymbolAssignment_0_0 : ( ( '^' ) ) ;
    public final void rule__Version__SymbolAssignment_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6755:1: ( ( ( '^' ) ) )
            // InternalSM2.g:6756:2: ( ( '^' ) )
            {
            // InternalSM2.g:6756:2: ( ( '^' ) )
            // InternalSM2.g:6757:3: ( '^' )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 
            }
            // InternalSM2.g:6758:3: ( '^' )
            // InternalSM2.g:6759:4: '^'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 
            }
            match(input,76,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAssignment_0_0"


    // $ANTLR start "rule__Version__NumberVersionAssignment_0_1"
    // InternalSM2.g:6770:1: rule__Version__NumberVersionAssignment_0_1 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6774:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6775:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6775:2: ( RULE_NUMBER )
            // InternalSM2.g:6776:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_0_1_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_0_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionAssignment_0_1"


    // $ANTLR start "rule__Version__NumberVersion2Assignment_0_3"
    // InternalSM2.g:6785:1: rule__Version__NumberVersion2Assignment_0_3 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion2Assignment_0_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6789:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6790:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6790:2: ( RULE_NUMBER )
            // InternalSM2.g:6791:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_0_3_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_0_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion2Assignment_0_3"


    // $ANTLR start "rule__Version__NumberVersion3Assignment_0_5"
    // InternalSM2.g:6800:1: rule__Version__NumberVersion3Assignment_0_5 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion3Assignment_0_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6804:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6805:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6805:2: ( RULE_NUMBER )
            // InternalSM2.g:6806:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_0_5_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_0_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion3Assignment_0_5"


    // $ANTLR start "rule__Version__SymbolAssignment_1_0"
    // InternalSM2.g:6815:1: rule__Version__SymbolAssignment_1_0 : ( ( rule__Version__SymbolAlternatives_1_0_0 ) ) ;
    public final void rule__Version__SymbolAssignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6819:1: ( ( ( rule__Version__SymbolAlternatives_1_0_0 ) ) )
            // InternalSM2.g:6820:2: ( ( rule__Version__SymbolAlternatives_1_0_0 ) )
            {
            // InternalSM2.g:6820:2: ( ( rule__Version__SymbolAlternatives_1_0_0 ) )
            // InternalSM2.g:6821:3: ( rule__Version__SymbolAlternatives_1_0_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getSymbolAlternatives_1_0_0()); 
            }
            // InternalSM2.g:6822:3: ( rule__Version__SymbolAlternatives_1_0_0 )
            // InternalSM2.g:6822:4: rule__Version__SymbolAlternatives_1_0_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAlternatives_1_0_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getSymbolAlternatives_1_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAssignment_1_0"


    // $ANTLR start "rule__Version__NumberVersionAssignment_1_1"
    // InternalSM2.g:6830:1: rule__Version__NumberVersionAssignment_1_1 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6834:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6835:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6835:2: ( RULE_NUMBER )
            // InternalSM2.g:6836:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_1_1_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_1_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionAssignment_1_1"


    // $ANTLR start "rule__Version__NumberVersion2Assignment_1_3"
    // InternalSM2.g:6845:1: rule__Version__NumberVersion2Assignment_1_3 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion2Assignment_1_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6849:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6850:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6850:2: ( RULE_NUMBER )
            // InternalSM2.g:6851:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_1_3_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_1_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion2Assignment_1_3"


    // $ANTLR start "rule__Version__NumberVersion3Assignment_1_5"
    // InternalSM2.g:6860:1: rule__Version__NumberVersion3Assignment_1_5 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion3Assignment_1_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6864:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6865:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6865:2: ( RULE_NUMBER )
            // InternalSM2.g:6866:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_1_5_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_1_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion3Assignment_1_5"


    // $ANTLR start "rule__Version__Symbol2Assignment_1_6_0"
    // InternalSM2.g:6875:1: rule__Version__Symbol2Assignment_1_6_0 : ( ( rule__Version__Symbol2Alternatives_1_6_0_0 ) ) ;
    public final void rule__Version__Symbol2Assignment_1_6_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6879:1: ( ( ( rule__Version__Symbol2Alternatives_1_6_0_0 ) ) )
            // InternalSM2.g:6880:2: ( ( rule__Version__Symbol2Alternatives_1_6_0_0 ) )
            {
            // InternalSM2.g:6880:2: ( ( rule__Version__Symbol2Alternatives_1_6_0_0 ) )
            // InternalSM2.g:6881:3: ( rule__Version__Symbol2Alternatives_1_6_0_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getSymbol2Alternatives_1_6_0_0()); 
            }
            // InternalSM2.g:6882:3: ( rule__Version__Symbol2Alternatives_1_6_0_0 )
            // InternalSM2.g:6882:4: rule__Version__Symbol2Alternatives_1_6_0_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__Symbol2Alternatives_1_6_0_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getSymbol2Alternatives_1_6_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Symbol2Assignment_1_6_0"


    // $ANTLR start "rule__Version__NumberVersionOptionalAssignment_1_6_1"
    // InternalSM2.g:6890:1: rule__Version__NumberVersionOptionalAssignment_1_6_1 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionOptionalAssignment_1_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6894:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6895:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6895:2: ( RULE_NUMBER )
            // InternalSM2.g:6896:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionOptionalNUMBERTerminalRuleCall_1_6_1_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionOptionalNUMBERTerminalRuleCall_1_6_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionOptionalAssignment_1_6_1"


    // $ANTLR start "rule__Version__NumberVersionOptional2Assignment_1_6_3"
    // InternalSM2.g:6905:1: rule__Version__NumberVersionOptional2Assignment_1_6_3 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionOptional2Assignment_1_6_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6909:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6910:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6910:2: ( RULE_NUMBER )
            // InternalSM2.g:6911:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionOptional2NUMBERTerminalRuleCall_1_6_3_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionOptional2NUMBERTerminalRuleCall_1_6_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionOptional2Assignment_1_6_3"


    // $ANTLR start "rule__Version__NumberVersionOptional3Assignment_1_6_5"
    // InternalSM2.g:6920:1: rule__Version__NumberVersionOptional3Assignment_1_6_5 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionOptional3Assignment_1_6_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6924:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:6925:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:6925:2: ( RULE_NUMBER )
            // InternalSM2.g:6926:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionOptional3NUMBERTerminalRuleCall_1_6_5_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionOptional3NUMBERTerminalRuleCall_1_6_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionOptional3Assignment_1_6_5"


    // $ANTLR start "rule__Import__NameLibraryAssignment_1"
    // InternalSM2.g:6935:1: rule__Import__NameLibraryAssignment_1 : ( RULE_ID ) ;
    public final void rule__Import__NameLibraryAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6939:1: ( ( RULE_ID ) )
            // InternalSM2.g:6940:2: ( RULE_ID )
            {
            // InternalSM2.g:6940:2: ( RULE_ID )
            // InternalSM2.g:6941:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getNameLibraryIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getNameLibraryIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__NameLibraryAssignment_1"


    // $ANTLR start "rule__Import__AliasAssignment_2_1"
    // InternalSM2.g:6950:1: rule__Import__AliasAssignment_2_1 : ( RULE_ID ) ;
    public final void rule__Import__AliasAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6954:1: ( ( RULE_ID ) )
            // InternalSM2.g:6955:2: ( RULE_ID )
            {
            // InternalSM2.g:6955:2: ( RULE_ID )
            // InternalSM2.g:6956:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getAliasIDTerminalRuleCall_2_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getAliasIDTerminalRuleCall_2_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__AliasAssignment_2_1"


    // $ANTLR start "rule__Event__NameEventAssignment_1"
    // InternalSM2.g:6965:1: rule__Event__NameEventAssignment_1 : ( RULE_ID ) ;
    public final void rule__Event__NameEventAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6969:1: ( ( RULE_ID ) )
            // InternalSM2.g:6970:2: ( RULE_ID )
            {
            // InternalSM2.g:6970:2: ( RULE_ID )
            // InternalSM2.g:6971:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__NameEventAssignment_1"


    // $ANTLR start "rule__Event__InputParamsAssignment_3"
    // InternalSM2.g:6980:1: rule__Event__InputParamsAssignment_3 : ( ruleInputParam ) ;
    public final void rule__Event__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6984:1: ( ( ruleInputParam ) )
            // InternalSM2.g:6985:2: ( ruleInputParam )
            {
            // InternalSM2.g:6985:2: ( ruleInputParam )
            // InternalSM2.g:6986:3: ruleInputParam
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleInputParam();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__InputParamsAssignment_3"


    // $ANTLR start "rule__Modifier__NameModifierAssignment_1"
    // InternalSM2.g:6995:1: rule__Modifier__NameModifierAssignment_1 : ( RULE_ID ) ;
    public final void rule__Modifier__NameModifierAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6999:1: ( ( RULE_ID ) )
            // InternalSM2.g:7000:2: ( RULE_ID )
            {
            // InternalSM2.g:7000:2: ( RULE_ID )
            // InternalSM2.g:7001:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__NameModifierAssignment_1"


    // $ANTLR start "rule__Modifier__InputParamsAssignment_3"
    // InternalSM2.g:7010:1: rule__Modifier__InputParamsAssignment_3 : ( ruleInputParam ) ;
    public final void rule__Modifier__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7014:1: ( ( ruleInputParam ) )
            // InternalSM2.g:7015:2: ( ruleInputParam )
            {
            // InternalSM2.g:7015:2: ( ruleInputParam )
            // InternalSM2.g:7016:3: ruleInputParam
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleInputParam();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__InputParamsAssignment_3"


    // $ANTLR start "rule__Modifier__ExprAssignment_7"
    // InternalSM2.g:7025:1: rule__Modifier__ExprAssignment_7 : ( RULE_STRING ) ;
    public final void rule__Modifier__ExprAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7029:1: ( ( RULE_STRING ) )
            // InternalSM2.g:7030:2: ( RULE_STRING )
            {
            // InternalSM2.g:7030:2: ( RULE_STRING )
            // InternalSM2.g:7031:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__ExprAssignment_7"


    // $ANTLR start "rule__Mapping__TypeAssignment_2"
    // InternalSM2.g:7040:1: rule__Mapping__TypeAssignment_2 : ( ruleSingularType ) ;
    public final void rule__Mapping__TypeAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7044:1: ( ( ruleSingularType ) )
            // InternalSM2.g:7045:2: ( ruleSingularType )
            {
            // InternalSM2.g:7045:2: ( ruleSingularType )
            // InternalSM2.g:7046:3: ruleSingularType
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_2_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__TypeAssignment_2"


    // $ANTLR start "rule__Mapping__ExprAssignment_4"
    // InternalSM2.g:7055:1: rule__Mapping__ExprAssignment_4 : ( RULE_STRING ) ;
    public final void rule__Mapping__ExprAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7059:1: ( ( RULE_STRING ) )
            // InternalSM2.g:7060:2: ( RULE_STRING )
            {
            // InternalSM2.g:7060:2: ( RULE_STRING )
            // InternalSM2.g:7061:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__ExprAssignment_4"


    // $ANTLR start "rule__Mapping__VisibilityAssignment_6"
    // InternalSM2.g:7070:1: rule__Mapping__VisibilityAssignment_6 : ( ruleVisibility ) ;
    public final void rule__Mapping__VisibilityAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7074:1: ( ( ruleVisibility ) )
            // InternalSM2.g:7075:2: ( ruleVisibility )
            {
            // InternalSM2.g:7075:2: ( ruleVisibility )
            // InternalSM2.g:7076:3: ruleVisibility
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__VisibilityAssignment_6"


    // $ANTLR start "rule__Mapping__NameMappingAssignment_7"
    // InternalSM2.g:7085:1: rule__Mapping__NameMappingAssignment_7 : ( RULE_ID ) ;
    public final void rule__Mapping__NameMappingAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7089:1: ( ( RULE_ID ) )
            // InternalSM2.g:7090:2: ( RULE_ID )
            {
            // InternalSM2.g:7090:2: ( RULE_ID )
            // InternalSM2.g:7091:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__NameMappingAssignment_7"


    // $ANTLR start "rule__Struct__TypeStructAssignment_0"
    // InternalSM2.g:7100:1: rule__Struct__TypeStructAssignment_0 : ( rulePersonalizedStruct ) ;
    public final void rule__Struct__TypeStructAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7104:1: ( ( rulePersonalizedStruct ) )
            // InternalSM2.g:7105:2: ( rulePersonalizedStruct )
            {
            // InternalSM2.g:7105:2: ( rulePersonalizedStruct )
            // InternalSM2.g:7106:3: rulePersonalizedStruct
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getStructAccess().getTypeStructPersonalizedStructParserRuleCall_0_0()); 
            }
            pushFollow(FOLLOW_2);
            rulePersonalizedStruct();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getStructAccess().getTypeStructPersonalizedStructParserRuleCall_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__TypeStructAssignment_0"


    // $ANTLR start "rule__PersonalizedStruct__NameStructAssignment_1"
    // InternalSM2.g:7115:1: rule__PersonalizedStruct__NameStructAssignment_1 : ( RULE_ID ) ;
    public final void rule__PersonalizedStruct__NameStructAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7119:1: ( ( RULE_ID ) )
            // InternalSM2.g:7120:2: ( RULE_ID )
            {
            // InternalSM2.g:7120:2: ( RULE_ID )
            // InternalSM2.g:7121:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getNameStructIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getNameStructIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__NameStructAssignment_1"


    // $ANTLR start "rule__PersonalizedStruct__PropertiesAssignment_4"
    // InternalSM2.g:7130:1: rule__PersonalizedStruct__PropertiesAssignment_4 : ( ruleProperty ) ;
    public final void rule__PersonalizedStruct__PropertiesAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7134:1: ( ( ruleProperty ) )
            // InternalSM2.g:7135:2: ( ruleProperty )
            {
            // InternalSM2.g:7135:2: ( ruleProperty )
            // InternalSM2.g:7136:3: ruleProperty
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleProperty();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__PropertiesAssignment_4"


    // $ANTLR start "rule__User__NameStructAssignment_1"
    // InternalSM2.g:7145:1: rule__User__NameStructAssignment_1 : ( RULE_ID ) ;
    public final void rule__User__NameStructAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7149:1: ( ( RULE_ID ) )
            // InternalSM2.g:7150:2: ( RULE_ID )
            {
            // InternalSM2.g:7150:2: ( RULE_ID )
            // InternalSM2.g:7151:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__NameStructAssignment_1"


    // $ANTLR start "rule__User__IdAdressAssignment_5"
    // InternalSM2.g:7160:1: rule__User__IdAdressAssignment_5 : ( RULE_ID ) ;
    public final void rule__User__IdAdressAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7164:1: ( ( RULE_ID ) )
            // InternalSM2.g:7165:2: ( RULE_ID )
            {
            // InternalSM2.g:7165:2: ( RULE_ID )
            // InternalSM2.g:7166:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getIdAdressIDTerminalRuleCall_5_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getIdAdressIDTerminalRuleCall_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__IdAdressAssignment_5"


    // $ANTLR start "rule__User__NameUserAssignment_10"
    // InternalSM2.g:7175:1: rule__User__NameUserAssignment_10 : ( RULE_STRING ) ;
    public final void rule__User__NameUserAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7179:1: ( ( RULE_STRING ) )
            // InternalSM2.g:7180:2: ( RULE_STRING )
            {
            // InternalSM2.g:7180:2: ( RULE_STRING )
            // InternalSM2.g:7181:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_10_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_10_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__NameUserAssignment_10"


    // $ANTLR start "rule__User__SurnameAssignment_15"
    // InternalSM2.g:7190:1: rule__User__SurnameAssignment_15 : ( RULE_STRING ) ;
    public final void rule__User__SurnameAssignment_15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7194:1: ( ( RULE_STRING ) )
            // InternalSM2.g:7195:2: ( RULE_STRING )
            {
            // InternalSM2.g:7195:2: ( RULE_STRING )
            // InternalSM2.g:7196:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSurnameSTRINGTerminalRuleCall_15_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSurnameSTRINGTerminalRuleCall_15_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__SurnameAssignment_15"


    // $ANTLR start "rule__User__EmailAssignment_20"
    // InternalSM2.g:7205:1: rule__User__EmailAssignment_20 : ( RULE_STRING ) ;
    public final void rule__User__EmailAssignment_20() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7209:1: ( ( RULE_STRING ) )
            // InternalSM2.g:7210:2: ( RULE_STRING )
            {
            // InternalSM2.g:7210:2: ( RULE_STRING )
            // InternalSM2.g:7211:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEmailSTRINGTerminalRuleCall_20_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEmailSTRINGTerminalRuleCall_20_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__EmailAssignment_20"


    // $ANTLR start "rule__User__AmountAccountAssignment_25"
    // InternalSM2.g:7220:1: rule__User__AmountAccountAssignment_25 : ( RULE_STRING ) ;
    public final void rule__User__AmountAccountAssignment_25() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7224:1: ( ( RULE_STRING ) )
            // InternalSM2.g:7225:2: ( RULE_STRING )
            {
            // InternalSM2.g:7225:2: ( RULE_STRING )
            // InternalSM2.g:7226:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getAmountAccountSTRINGTerminalRuleCall_25_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getAmountAccountSTRINGTerminalRuleCall_25_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__AmountAccountAssignment_25"


    // $ANTLR start "rule__Enum__NameEnumAssignment_1"
    // InternalSM2.g:7235:1: rule__Enum__NameEnumAssignment_1 : ( RULE_ID ) ;
    public final void rule__Enum__NameEnumAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7239:1: ( ( RULE_ID ) )
            // InternalSM2.g:7240:2: ( RULE_ID )
            {
            // InternalSM2.g:7240:2: ( RULE_ID )
            // InternalSM2.g:7241:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__NameEnumAssignment_1"


    // $ANTLR start "rule__Property__TypeAssignment_0"
    // InternalSM2.g:7250:1: rule__Property__TypeAssignment_0 : ( ruleSingularType ) ;
    public final void rule__Property__TypeAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7254:1: ( ( ruleSingularType ) )
            // InternalSM2.g:7255:2: ( ruleSingularType )
            {
            // InternalSM2.g:7255:2: ( ruleSingularType )
            // InternalSM2.g:7256:3: ruleSingularType
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__TypeAssignment_0"


    // $ANTLR start "rule__Property__VisibilityAssignment_1"
    // InternalSM2.g:7265:1: rule__Property__VisibilityAssignment_1 : ( ruleVisibility ) ;
    public final void rule__Property__VisibilityAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7269:1: ( ( ruleVisibility ) )
            // InternalSM2.g:7270:2: ( ruleVisibility )
            {
            // InternalSM2.g:7270:2: ( ruleVisibility )
            // InternalSM2.g:7271:3: ruleVisibility
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__VisibilityAssignment_1"


    // $ANTLR start "rule__Property__NamePropertyAssignment_2"
    // InternalSM2.g:7280:1: rule__Property__NamePropertyAssignment_2 : ( RULE_ID ) ;
    public final void rule__Property__NamePropertyAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7284:1: ( ( RULE_ID ) )
            // InternalSM2.g:7285:2: ( RULE_ID )
            {
            // InternalSM2.g:7285:2: ( RULE_ID )
            // InternalSM2.g:7286:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__NamePropertyAssignment_2"


    // $ANTLR start "rule__Property__InicializationAssignment_4_0"
    // InternalSM2.g:7295:1: rule__Property__InicializationAssignment_4_0 : ( RULE_STRING ) ;
    public final void rule__Property__InicializationAssignment_4_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7299:1: ( ( RULE_STRING ) )
            // InternalSM2.g:7300:2: ( RULE_STRING )
            {
            // InternalSM2.g:7300:2: ( RULE_STRING )
            // InternalSM2.g:7301:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__InicializationAssignment_4_0"


    // $ANTLR start "rule__InputParam__TypeAssignment_0_0"
    // InternalSM2.g:7310:1: rule__InputParam__TypeAssignment_0_0 : ( ruleSingularType ) ;
    public final void rule__InputParam__TypeAssignment_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7314:1: ( ( ruleSingularType ) )
            // InternalSM2.g:7315:2: ( ruleSingularType )
            {
            // InternalSM2.g:7315:2: ( ruleSingularType )
            // InternalSM2.g:7316:3: ruleSingularType
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getTypeSingularTypeEnumRuleCall_0_0_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getTypeSingularTypeEnumRuleCall_0_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__TypeAssignment_0_0"


    // $ANTLR start "rule__InputParam__NameParamAssignment_0_1"
    // InternalSM2.g:7325:1: rule__InputParam__NameParamAssignment_0_1 : ( RULE_ID ) ;
    public final void rule__InputParam__NameParamAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7329:1: ( ( RULE_ID ) )
            // InternalSM2.g:7330:2: ( RULE_ID )
            {
            // InternalSM2.g:7330:2: ( RULE_ID )
            // InternalSM2.g:7331:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__NameParamAssignment_0_1"


    // $ANTLR start "rule__InputParam__CommaAssignment_1"
    // InternalSM2.g:7340:1: rule__InputParam__CommaAssignment_1 : ( RULE_COMMA ) ;
    public final void rule__InputParam__CommaAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7344:1: ( ( RULE_COMMA ) )
            // InternalSM2.g:7345:2: ( RULE_COMMA )
            {
            // InternalSM2.g:7345:2: ( RULE_COMMA )
            // InternalSM2.g:7346:3: RULE_COMMA
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getCommaCOMMATerminalRuleCall_1_0()); 
            }
            match(input,RULE_COMMA,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getCommaCOMMATerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__CommaAssignment_1"


    // $ANTLR start "rule__Restriction__Expr1Assignment_2"
    // InternalSM2.g:7355:1: rule__Restriction__Expr1Assignment_2 : ( ruleSyntaxExpression ) ;
    public final void rule__Restriction__Expr1Assignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7359:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:7360:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:7360:2: ( ruleSyntaxExpression )
            // InternalSM2.g:7361:3: ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getExpr1SyntaxExpressionParserRuleCall_2_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getExpr1SyntaxExpressionParserRuleCall_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Expr1Assignment_2"


    // $ANTLR start "rule__Restriction__OperatorAssignment_3"
    // InternalSM2.g:7370:1: rule__Restriction__OperatorAssignment_3 : ( ruleComparationOperator ) ;
    public final void rule__Restriction__OperatorAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7374:1: ( ( ruleComparationOperator ) )
            // InternalSM2.g:7375:2: ( ruleComparationOperator )
            {
            // InternalSM2.g:7375:2: ( ruleComparationOperator )
            // InternalSM2.g:7376:3: ruleComparationOperator
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleComparationOperator();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__OperatorAssignment_3"


    // $ANTLR start "rule__Restriction__Expr2Assignment_4"
    // InternalSM2.g:7385:1: rule__Restriction__Expr2Assignment_4 : ( ruleSyntaxExpression ) ;
    public final void rule__Restriction__Expr2Assignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7389:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:7390:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:7390:2: ( ruleSyntaxExpression )
            // InternalSM2.g:7391:3: ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getExpr2SyntaxExpressionParserRuleCall_4_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getExpr2SyntaxExpressionParserRuleCall_4_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Expr2Assignment_4"


    // $ANTLR start "rule__RestrictionGas__ExprAssignment_2"
    // InternalSM2.g:7400:1: rule__RestrictionGas__ExprAssignment_2 : ( ruleSyntaxExpression ) ;
    public final void rule__RestrictionGas__ExprAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7404:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:7405:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:7405:2: ( ruleSyntaxExpression )
            // InternalSM2.g:7406:3: ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__ExprAssignment_2"


    // $ANTLR start "rule__RestrictionGas__OperatorAssignment_3"
    // InternalSM2.g:7415:1: rule__RestrictionGas__OperatorAssignment_3 : ( ruleComparationOperator ) ;
    public final void rule__RestrictionGas__OperatorAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7419:1: ( ( ruleComparationOperator ) )
            // InternalSM2.g:7420:2: ( ruleComparationOperator )
            {
            // InternalSM2.g:7420:2: ( ruleComparationOperator )
            // InternalSM2.g:7421:3: ruleComparationOperator
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleComparationOperator();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__OperatorAssignment_3"


    // $ANTLR start "rule__RestrictionGas__AmountAssignment_4"
    // InternalSM2.g:7430:1: rule__RestrictionGas__AmountAssignment_4 : ( RULE_NUMBER ) ;
    public final void rule__RestrictionGas__AmountAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7434:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:7435:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:7435:2: ( RULE_NUMBER )
            // InternalSM2.g:7436:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getAmountNUMBERTerminalRuleCall_4_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getAmountNUMBERTerminalRuleCall_4_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__AmountAssignment_4"


    // $ANTLR start "rule__RestrictionGas__TypeCoinAssignment_5"
    // InternalSM2.g:7445:1: rule__RestrictionGas__TypeCoinAssignment_5 : ( ruleCoin ) ;
    public final void rule__RestrictionGas__TypeCoinAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7449:1: ( ( ruleCoin ) )
            // InternalSM2.g:7450:2: ( ruleCoin )
            {
            // InternalSM2.g:7450:2: ( ruleCoin )
            // InternalSM2.g:7451:3: ruleCoin
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleCoin();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__TypeCoinAssignment_5"


    // $ANTLR start "rule__Clause__NameFunctionAssignment_1"
    // InternalSM2.g:7460:1: rule__Clause__NameFunctionAssignment_1 : ( RULE_ID ) ;
    public final void rule__Clause__NameFunctionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7464:1: ( ( RULE_ID ) )
            // InternalSM2.g:7465:2: ( RULE_ID )
            {
            // InternalSM2.g:7465:2: ( RULE_ID )
            // InternalSM2.g:7466:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__NameFunctionAssignment_1"


    // $ANTLR start "rule__Clause__InputParamsAssignment_3"
    // InternalSM2.g:7475:1: rule__Clause__InputParamsAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__Clause__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7479:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:7480:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:7480:2: ( ( RULE_ID ) )
            // InternalSM2.g:7481:3: ( RULE_ID )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getInputParamsInputParamCrossReference_3_0()); 
            }
            // InternalSM2.g:7482:3: ( RULE_ID )
            // InternalSM2.g:7483:4: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getInputParamsInputParamIDTerminalRuleCall_3_0_1()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getInputParamsInputParamIDTerminalRuleCall_3_0_1()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getInputParamsInputParamCrossReference_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__InputParamsAssignment_3"


    // $ANTLR start "rule__Clause__VisibilityAccessAssignment_4"
    // InternalSM2.g:7494:1: rule__Clause__VisibilityAccessAssignment_4 : ( ruleVisibility ) ;
    public final void rule__Clause__VisibilityAccessAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7498:1: ( ( ruleVisibility ) )
            // InternalSM2.g:7499:2: ( ruleVisibility )
            {
            // InternalSM2.g:7499:2: ( ruleVisibility )
            // InternalSM2.g:7500:3: ruleVisibility
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__VisibilityAccessAssignment_4"


    // $ANTLR start "rule__Clause__ModifierAssignment_5"
    // InternalSM2.g:7509:1: rule__Clause__ModifierAssignment_5 : ( ( RULE_ID ) ) ;
    public final void rule__Clause__ModifierAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7513:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:7514:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:7514:2: ( ( RULE_ID ) )
            // InternalSM2.g:7515:3: ( RULE_ID )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getModifierModifierCrossReference_5_0()); 
            }
            // InternalSM2.g:7516:3: ( RULE_ID )
            // InternalSM2.g:7517:4: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getModifierModifierIDTerminalRuleCall_5_0_1()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getModifierModifierIDTerminalRuleCall_5_0_1()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getModifierModifierCrossReference_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__ModifierAssignment_5"


    // $ANTLR start "rule__Clause__RestrictionAssignment_9"
    // InternalSM2.g:7528:1: rule__Clause__RestrictionAssignment_9 : ( ruleRestriction ) ;
    public final void rule__Clause__RestrictionAssignment_9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7532:1: ( ( ruleRestriction ) )
            // InternalSM2.g:7533:2: ( ruleRestriction )
            {
            // InternalSM2.g:7533:2: ( ruleRestriction )
            // InternalSM2.g:7534:3: ruleRestriction
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_9_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleRestriction();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_9_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__RestrictionAssignment_9"


    // $ANTLR start "rule__Clause__RestrictionGasAssignment_10"
    // InternalSM2.g:7543:1: rule__Clause__RestrictionGasAssignment_10 : ( ruleRestrictionGas ) ;
    public final void rule__Clause__RestrictionGasAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7547:1: ( ( ruleRestrictionGas ) )
            // InternalSM2.g:7548:2: ( ruleRestrictionGas )
            {
            // InternalSM2.g:7548:2: ( ruleRestrictionGas )
            // InternalSM2.g:7549:3: ruleRestrictionGas
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_10_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_10_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__RestrictionGasAssignment_10"


    // $ANTLR start "rule__Clause__ExpressionAssignment_11"
    // InternalSM2.g:7558:1: rule__Clause__ExpressionAssignment_11 : ( ruleExpression ) ;
    public final void rule__Clause__ExpressionAssignment_11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7562:1: ( ( ruleExpression ) )
            // InternalSM2.g:7563:2: ( ruleExpression )
            {
            // InternalSM2.g:7563:2: ( ruleExpression )
            // InternalSM2.g:7564:3: ruleExpression
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_11_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_11_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__ExpressionAssignment_11"


    // $ANTLR start "rule__ArithmethicalExpression__Op1Assignment_0_1"
    // InternalSM2.g:7573:1: rule__ArithmethicalExpression__Op1Assignment_0_1 : ( RULE_NUMBER ) ;
    public final void rule__ArithmethicalExpression__Op1Assignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7577:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:7578:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:7578:2: ( RULE_NUMBER )
            // InternalSM2.g:7579:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp1NUMBERTerminalRuleCall_0_1_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp1NUMBERTerminalRuleCall_0_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op1Assignment_0_1"


    // $ANTLR start "rule__ArithmethicalExpression__OperatorAssignment_0_2"
    // InternalSM2.g:7588:1: rule__ArithmethicalExpression__OperatorAssignment_0_2 : ( ruleArithmeticalOperator ) ;
    public final void rule__ArithmethicalExpression__OperatorAssignment_0_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7592:1: ( ( ruleArithmeticalOperator ) )
            // InternalSM2.g:7593:2: ( ruleArithmeticalOperator )
            {
            // InternalSM2.g:7593:2: ( ruleArithmeticalOperator )
            // InternalSM2.g:7594:3: ruleArithmeticalOperator
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleArithmeticalOperator();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__OperatorAssignment_0_2"


    // $ANTLR start "rule__ArithmethicalExpression__Op2Assignment_0_3"
    // InternalSM2.g:7603:1: rule__ArithmethicalExpression__Op2Assignment_0_3 : ( RULE_NUMBER ) ;
    public final void rule__ArithmethicalExpression__Op2Assignment_0_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7607:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:7608:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:7608:2: ( RULE_NUMBER )
            // InternalSM2.g:7609:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp2NUMBERTerminalRuleCall_0_3_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp2NUMBERTerminalRuleCall_0_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op2Assignment_0_3"


    // $ANTLR start "rule__ArithmethicalExpression__Op1Assignment_1_0"
    // InternalSM2.g:7618:1: rule__ArithmethicalExpression__Op1Assignment_1_0 : ( RULE_NUMBER ) ;
    public final void rule__ArithmethicalExpression__Op1Assignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7622:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:7623:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:7623:2: ( RULE_NUMBER )
            // InternalSM2.g:7624:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp1NUMBERTerminalRuleCall_1_0_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp1NUMBERTerminalRuleCall_1_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op1Assignment_1_0"


    // $ANTLR start "rule__ArithmethicalExpression__OperatorAssignment_1_1"
    // InternalSM2.g:7633:1: rule__ArithmethicalExpression__OperatorAssignment_1_1 : ( ruleArithmeticalOperator ) ;
    public final void rule__ArithmethicalExpression__OperatorAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7637:1: ( ( ruleArithmeticalOperator ) )
            // InternalSM2.g:7638:2: ( ruleArithmeticalOperator )
            {
            // InternalSM2.g:7638:2: ( ruleArithmeticalOperator )
            // InternalSM2.g:7639:3: ruleArithmeticalOperator
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleArithmeticalOperator();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__OperatorAssignment_1_1"


    // $ANTLR start "rule__ArithmethicalExpression__Op2Assignment_1_2"
    // InternalSM2.g:7648:1: rule__ArithmethicalExpression__Op2Assignment_1_2 : ( RULE_NUMBER ) ;
    public final void rule__ArithmethicalExpression__Op2Assignment_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7652:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:7653:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:7653:2: ( RULE_NUMBER )
            // InternalSM2.g:7654:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp2NUMBERTerminalRuleCall_1_2_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp2NUMBERTerminalRuleCall_1_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op2Assignment_1_2"


    // $ANTLR start "rule__SyntaxExpression__TextAssignment_0"
    // InternalSM2.g:7663:1: rule__SyntaxExpression__TextAssignment_0 : ( RULE_STRING ) ;
    public final void rule__SyntaxExpression__TextAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7667:1: ( ( RULE_STRING ) )
            // InternalSM2.g:7668:2: ( RULE_STRING )
            {
            // InternalSM2.g:7668:2: ( RULE_STRING )
            // InternalSM2.g:7669:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__TextAssignment_0"


    // $ANTLR start "rule__ShortComment__ExprAssignment_1"
    // InternalSM2.g:7678:1: rule__ShortComment__ExprAssignment_1 : ( RULE_STRING ) ;
    public final void rule__ShortComment__ExprAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7682:1: ( ( RULE_STRING ) )
            // InternalSM2.g:7683:2: ( RULE_STRING )
            {
            // InternalSM2.g:7683:2: ( RULE_STRING )
            // InternalSM2.g:7684:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__ExprAssignment_1"


    // $ANTLR start "rule__LongComment__ExpressionAssignment_1"
    // InternalSM2.g:7693:1: rule__LongComment__ExpressionAssignment_1 : ( ( rule__LongComment__ExpressionAlternatives_1_0 ) ) ;
    public final void rule__LongComment__ExpressionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7697:1: ( ( ( rule__LongComment__ExpressionAlternatives_1_0 ) ) )
            // InternalSM2.g:7698:2: ( ( rule__LongComment__ExpressionAlternatives_1_0 ) )
            {
            // InternalSM2.g:7698:2: ( ( rule__LongComment__ExpressionAlternatives_1_0 ) )
            // InternalSM2.g:7699:3: ( rule__LongComment__ExpressionAlternatives_1_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getLongCommentAccess().getExpressionAlternatives_1_0()); 
            }
            // InternalSM2.g:7700:3: ( rule__LongComment__ExpressionAlternatives_1_0 )
            // InternalSM2.g:7700:4: rule__LongComment__ExpressionAlternatives_1_0
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__ExpressionAlternatives_1_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getLongCommentAccess().getExpressionAlternatives_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__ExpressionAssignment_1"

    // Delegated rules


    protected DFA7 dfa7 = new DFA7(this);
    protected DFA63 dfa63 = new DFA63(this);
    static final String dfa_1s = "\16\uffff";
    static final String dfa_2s = "\1\102\1\4\1\16\1\15\1\36\1\uffff\1\4\1\14\1\5\1\uffff\1\14\1\15\1\17\1\4";
    static final String dfa_3s = "\1\102\1\4\1\16\2\46\1\uffff\1\52\1\103\1\14\1\uffff\1\14\2\46\1\52";
    static final String dfa_4s = "\5\uffff\1\1\3\uffff\1\2\4\uffff";
    static final String dfa_5s = "\16\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\4\20\uffff\5\5\1\6\3\5",
            "\5\5\1\6\3\5",
            "",
            "\1\7\42\uffff\4\5",
            "\1\11\66\uffff\1\10",
            "\1\5\1\12\5\uffff\1\5",
            "",
            "\1\13",
            "\1\14\1\uffff\1\5\16\uffff\4\5\1\15\4\5",
            "\1\5\16\uffff\4\5\1\15\4\5",
            "\1\5\1\uffff\1\11\40\uffff\4\5"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA7 extends DFA {

        public DFA7(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 7;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "881:1: rule__Struct__Alternatives : ( ( ( rule__Struct__TypeStructAssignment_0 ) ) | ( ruleUser ) );";
        }
    }
    static final String dfa_7s = "\20\uffff";
    static final String dfa_8s = "\1\6\1\21\1\uffff\1\6\1\32\1\14\6\6\1\15\1\14\1\uffff\1\32";
    static final String dfa_9s = "\1\105\1\21\1\uffff\1\24\2\62\6\24\1\15\1\60\1\uffff\1\62";
    static final String dfa_10s = "\2\uffff\1\2\13\uffff\1\1\1\uffff";
    static final String dfa_11s = "\20\uffff}>";
    static final String[] dfa_12s = {
            "\1\2\12\uffff\1\2\2\uffff\1\2\60\uffff\1\1",
            "\1\3",
            "",
            "\1\4\15\uffff\1\5",
            "\1\6\1\10\1\7\1\11\23\uffff\1\12\1\13",
            "\1\14\15\uffff\1\6\1\10\1\7\1\11\23\uffff\1\12\1\13",
            "\1\16\15\uffff\1\15",
            "\1\16\15\uffff\1\15",
            "\1\16\15\uffff\1\15",
            "\1\16\15\uffff\1\15",
            "\1\16\15\uffff\1\15",
            "\1\16\15\uffff\1\15",
            "\1\17",
            "\1\16\5\uffff\1\16\30\uffff\6\2",
            "",
            "\1\6\1\10\1\7\1\11\23\uffff\1\12\1\13"
    };

    static final short[] dfa_7 = DFA.unpackEncodedString(dfa_7s);
    static final char[] dfa_8 = DFA.unpackEncodedStringToUnsignedChars(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final short[] dfa_10 = DFA.unpackEncodedString(dfa_10s);
    static final short[] dfa_11 = DFA.unpackEncodedString(dfa_11s);
    static final short[][] dfa_12 = unpackEncodedStringArray(dfa_12s);

    class DFA63 extends DFA {

        public DFA63(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 63;
            this.eot = dfa_7;
            this.eof = dfa_7;
            this.min = dfa_8;
            this.max = dfa_9;
            this.accept = dfa_10;
            this.special = dfa_11;
            this.transition = dfa_12;
        }
        public String getDescription() {
            return "5861:2: ( rule__Clause__RestrictionAssignment_9 )?";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x000000000C000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0800000000002000L,0x0000000000000800L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0800000000000002L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0400000000004000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x6000007FC000A010L,0x00000000000001D5L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000007FC0000012L,0x0000000000000015L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x2000000000000002L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x4000000000000002L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000040L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000180L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000030000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x1000000000001000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000007FC0040000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000007FC0000002L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000002040L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x8000000000002000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000007FC0000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000078000000010L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000007FC0002000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000007FC0002002L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000800002000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000000000001000L,0x0000000000000008L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000400002000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000080002000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x000000000000A000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000000042L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000008L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000000000001060L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000000000100040L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x000600003C000000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0001F80000000000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000040010L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000000120040L,0x0000000000000020L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0000000000120042L,0x0000000000000020L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x01E0000000000000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0000000000000FC0L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L});

}